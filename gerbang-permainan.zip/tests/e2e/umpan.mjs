// Uji UI umpan balik anonim + deteksi perangkat pada hub yang sudah menyala (default http://localhost:8000, PIN 1234).
// Memakai halaman CLAIM 80 asli lewat gerbang. Data uji: kelas "Umpan Uji" dan satu sesi Multi Permainan baru.
import { chromium, devices } from "playwright-core";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
const akar = fileURLToPath(new URL("../..", import.meta.url));
const base = process.env.GERBANG_URL ?? "http://localhost:8000";
const PIN = process.env.GERBANG_PIN ?? "1234";
const H = { "x-host-token": PIN, "content-type": "application/json" };
const j = async (p, o = {}) => (await fetch(base + p, { headers: H, ...o })).json();
const hasil = [];
const cek = (n, ok, info = "") => { hasil.push(ok); console.log(`${ok ? "✔" : "✘"} ${n}${info ? ` — ${info}` : ""}`); };

const nama = ["Aisyah Rahma", "Bima Prakoso", "Citra Lestari", "Dimas Anggara"];
let k = (await j("/api/kelas")).kelas.find((x) => x.nama === "Umpan Uji");
if (!k) { await j("/api/kelas", { method: "POST", body: JSON.stringify({ nama: "Umpan Uji", daftar: nama.join("\n") }) }); k = (await j("/api/kelas")).kelas.find((x) => x.nama === "Umpan Uji"); }
const sesi = (await j("/api/multi", { method: "POST", body: JSON.stringify({ kelasId: k.id, games: ["route-rush", "claim80", "logic-rush"], judul: "Multi Permainan Uji" }) })).sesi;
const b = await chromium.launch({ channel: "msedge" });
const galat = [];
try {
  // perangkat murid: ponsel Android
  const ctxHp = await b.newContext({ ...devices["Pixel 7"] });
  const hp = await ctxHp.newPage();
  hp.on("pageerror", (e) => galat.push(String(e)));
  await hp.goto(`${base}/games/claim80/`); await hp.waitForTimeout(2500);
  cek("belum dibuka: tanpa popup", (await hp.locator(".gp-overlay").count()) === 0);
  await j(`/api/umpan/${sesi.id}`, { method: "POST", body: JSON.stringify({ aktif: true }) });
  await hp.locator(".gp-overlay").waitFor({ timeout: 12000 });
  cek("popup wajib muncul di halaman siswa game asli", await hp.locator(".gp-overlay").isVisible());
  await hp.getByRole("button", { name: "Lengkapi semua jawaban dulu" }).waitFor();
  cek("tombol kirim terkunci sebelum lengkap", await hp.getByRole("button", { name: "Lengkapi semua jawaban dulu" }).isDisabled());
  await hp.waitForTimeout(600);
  await hp.screenshot({ path: join(akar, "docs", "layar-umpan-siswa-1.png") });
  await hp.locator(".gp-chip", { hasText: "CLAIM 80" }).click();
  for (const nm of ["Route Rush", "CLAIM 80", "Logic Rush"]) await hp.locator(".gp-baris", { hasText: nm }).getByRole("radio", { name: "5 bintang" }).click();
  for (let i = 0; i < 3; i++) await hp.locator(".gp-kuis").nth(i).getByRole("radio", { name: "5", exact: true }).click();
  await hp.locator(".gp-kartu").evaluate((e) => e.scrollIntoView());
  await hp.getByRole("button", { name: "Kirim jawaban" }).scrollIntoViewIfNeeded();
  await hp.waitForTimeout(400);
  await hp.screenshot({ path: join(akar, "docs", "layar-umpan-siswa-2.png") });
  await hp.getByRole("button", { name: "Kirim jawaban" }).click();
  await hp.getByText("Terima kasih!").waitFor({ timeout: 6000 });
  cek("terkirim, tampil ucapan terima kasih", true);
  await hp.waitForTimeout(2600);
  cek("popup tertutup setelah kirim", (await hp.locator(".gp-overlay").count()) === 0);
  await hp.waitForTimeout(5000);
  cek("tidak muncul lagi setelah mengisi", (await hp.locator(".gp-overlay").count()) === 0);
  // proyektor
  await j(`/api/umpan/${sesi.id}`, { method: "POST", body: JSON.stringify({ tampil: true }) });
  const ctxPr = await b.newContext({ viewport: { width: 1440, height: 810 }, deviceScaleFactor: 2 });
  const pr = await ctxPr.newPage();
  // murid (tanpa PIN guru) tidak bisa membuka proyektor maupun host
  const murid = await (await b.newContext({ viewport: { width: 1000, height: 700 } })).newPage();
  for (const p of ["/games/claim80/projector/UJI01", "/games/claim80/host"]) {
    const r = await murid.goto(base + p);
    cek(`murid ditolak di ${p}`, r.status() === 401 && (await murid.getByText("Halaman ini khusus guru.").first().isVisible()));
  }
  await murid.goto(`${base}/games/claim80/`); await murid.waitForTimeout(1500);
  await murid.evaluate(() => { history.pushState({}, "", "/games/claim80/projector/UJI01"); });
  await murid.locator(".gp-guru").waitFor({ timeout: 8000 });
  cek("navigasi di dalam aplikasi ke proyektor juga dikunci", await murid.locator(".gp-guru").isVisible());
  // guru: PIN benar memberi cookie sesi guru
  const login = await ctxPr.request.post(`${base}/api/pin`, { data: { pin: PIN } });
  cek("PIN guru benar memberi cookie sesi", login.ok());
  pr.on("pageerror", (e) => galat.push(String(e)));
  await pr.goto(`${base}/games/claim80/projector/UJI01`); await pr.locator(".gp-layar").waitFor({ timeout: 12000 });
  await pr.waitForTimeout(2200);
  const teks = await pr.locator(".gp-layar").innerText();
  cek("proyektor menampilkan jumlah pengisi", /1\s*\n?.*sudah mengisi/s.test(teks));
  cek("proyektor tanpa nama siswa", !nama.some((n) => teks.includes(n)));
  await pr.screenshot({ path: join(akar, "docs", "layar-umpan-proyektor.png") });
  // perangkat di tab Kelas
  const hub = await (await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 })).newPage();
  hub.on("pageerror", (e) => galat.push(String(e)));
  await hub.goto(base); await hub.evaluate(() => sessionStorage.clear()); await hub.reload();
  await hub.locator("#pin").fill(PIN); await hub.getByRole("button", { name: "Buka" }).click();
  await hub.getByRole("tab", { name: "Kelas" }).click();
  await hub.getByText("Perangkat terdeteksi").waitFor({ timeout: 8000 });
  await hub.waitForTimeout(2500);
  cek("tab Kelas memuat perangkat Android", (await hub.locator("main").innerText()).includes("Android"));
  await hub.evaluate(() => [...document.querySelectorAll(".panel h2")].find((e) => e.textContent === "Perangkat terdeteksi")?.scrollIntoView({ block: "start" }));
  await hub.waitForTimeout(600);
  await hub.screenshot({ path: join(akar, "docs", "layar-perangkat.png") });
  cek("tanpa galat skrip", galat.length === 0, galat.join(" | ").slice(0, 200));
} catch (e) { cek("uji umpan selesai tanpa galat", false, String(e.message ?? e).split("\n")[0]); }
await j(`/api/umpan/${sesi.id}`, { method: "POST", body: JSON.stringify({ aktif: false }) });
await b.close();
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);
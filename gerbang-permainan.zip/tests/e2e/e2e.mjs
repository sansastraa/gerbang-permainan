// Uji E2E dengan GAME ASLI lewat Gerbang (satu origin): node tests/e2e/e2e.mjs [kunci,kunci]
// Memakai Edge sistem lewat playwright-core. Butuh: npm run install:semua && npm run build.
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { chromium } from "playwright-core";
import { fileURLToPath } from "node:url";

const akar = fileURLToPath(new URL("../..", import.meta.url));
const PIN = "guru-e2e-1";
const PORT = Number(process.env.E2E_PORT || 8123);
const base = `http://127.0.0.1:${PORT}`;
const uji = (process.argv[2] ?? "route-rush,logic-rush").split(",");
const hasil = [];
const cek = (nama, ok, info = "") => { hasil.push(ok); console.log(`${ok ? "✔" : "✘"} ${nama}${info ? ` — ${info}` : ""}`); };

// server di folder data sementara agar tidak mengotori data/
const data = mkdtempSync(join(tmpdir(), "gp-e2e-"));
const env = { ...process.env, GERBANG_PIN: PIN, GERBANG_PORT: String(PORT), GERBANG_HOST: "127.0.0.1", GERBANG_DATA: data };
const srv = spawn(process.execPath, ["scripts/start.mjs", "--game", uji.join(",")], { cwd: akar, env });
let log = "";
srv.stdout.on("data", (d) => (log += d));
srv.stderr.on("data", (d) => (log += d));
const tunggu = async (fn, ms = 60000) => { const t = Date.now(); while (Date.now() - t < ms) { try { if (await fn()) return true; } catch { /* belum siap */ } await new Promise((r) => setTimeout(r, 400)); } return false; };
const j = async (path, { metode = "GET", badan, pin = PIN } = {}) => { const r = await fetch(base + path, { method: metode, headers: { "x-host-token": pin, ...(badan ? { "content-type": "application/json" } : {}) }, body: badan && JSON.stringify(badan) }); return { status: r.status, json: await r.json().catch(() => null) }; };

let peramban;
try {
  const siap = await tunggu(async () => { const s = await (await fetch(`${base}/api/status`)).json(); return uji.every((k) => s.games.find((g) => g.key === k)?.hidup); });
  cek("hub dan game menyala", siap, siap ? "" : log.slice(-800));
  if (!siap) throw new Error("server tidak siap");

  peramban = await chromium.launch({ channel: "msedge", headless: true, args: ["--mute-audio", "--autoplay-policy=user-gesture-required"] });
  const ctx = await peramban.newContext({ viewport: { width: 1280, height: 800 } });
  const hub = await ctx.newPage();
  await hub.goto(base);
  await hub.locator(".dunia").nth(4).waitFor();
  await hub.waitForTimeout(1600);
  await hub.screenshot({ path: join(akar, "docs", "layar-gerbang.png") });
  await hub.locator("#pin").fill("salah-salah");
  await hub.getByRole("button", { name: "Buka" }).click();
  await hub.getByText("PIN belum tepat").waitFor();
  cek("PIN salah ditolak", await hub.getByText("PIN belum tepat").isVisible() && (await hub.locator(".dunia.terkunci").count()) === 6);
  await hub.locator("#pin").fill(PIN);
  await hub.getByRole("button", { name: "Buka" }).click();
  await hub.getByRole("tab", { name: "Kelas" }).waitFor();
  cek("PIN benar membuka gerbang", (await hub.locator(".dunia.terkunci").count()) === 0 && (await hub.locator(".dunia").count()) === 6);

  const nama = ["Ani Lestari", "Budi Santoso", "Citra Dewi", "Dodi Pratama"];
  const kls = await j("/api/kelas", { metode: "POST", badan: { nama: "7A", daftar: nama.join("\n") } });
  cek("kelas tersimpan", kls.status === 200);
  await hub.reload();
  await hub.getByRole("tab", { name: "Dunia" }).waitFor();
  await hub.screenshot({ path: join(akar, "docs", "layar-dunia.png") });

  // 1) Serah-terima ke konsol guru game ASLI: daftar siswa muncul tanpa PIN
  for (const key of uji) {
    const indeks = ["route-rush", "claim80", "glacia", "logic-rush", "transit-rush", "tower-peek"].indexOf(key);
    const [pop] = await Promise.all([ctx.waitForEvent("page"), hub.locator(".dunia").nth(indeks).getByRole("button", { name: "Masuk" }).click()]);
    await pop.waitForLoadState("domcontentloaded");
    const tampil = await tunggu(async () => /Citra Dewi|Kelas 7A: 4 siswa|4 siswa dikirim/.test(await pop.locator("body").innerText()), 25000);
    cek(`${key}: konsol guru menerima daftar kelas`, tampil, new URL(pop.url()).pathname);
    cek(`${key}: PIN tidak ada di URL`, !pop.url().includes(PIN));
    await pop.screenshot({ path: join(akar, "docs", `host-${key}.png`) });
    await pop.close();
  }

  // 2) Multi Permainan di dalam hub, hasil dari game ASLI lewat token yang diteruskan
  const k = kls.json.kelas[0];
  const m = (await j("/api/multi", { metode: "POST", badan: { kelasId: k.id, games: uji, aturan: "peringkat" } })).json.sesi;
  const roster = k.siswa.map((s, i) => ({ id: s.id, name: s.nama, absen: i + 1 }));
  for (const key of uji) {
    let gameSesi;
    if (key === "claim80") gameSesi = (await j(`/games/claim80/api/sessions`, { metode: "POST", badan: { className: "7A", roster } })).json?.id;
    if (key === "logic-rush") gameSesi = (await j(`/games/logic-rush/api/sessions`, { metode: "POST", badan: { roster: roster.map((r) => ({ id: r.id, nama: r.name })) } })).json?.id;
    if (!gameSesi) { console.log(`- ${key}: sesi REST tidak dibuat di E2E (tanpa permainan nyata)`); continue; }
    const h = await j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: key, gameSesi } });
    cek(`${key}: summary.json asli terbaca hub dengan token PIN`, h.status === 200, h.status === 200 ? `${h.json.sesi.hasil[key].skor.length} siswa` : JSON.stringify(h.json));
  }
  const anti = await fetch(`${base}/games/claim80/api/host-token`);
  cek("/api/host-token tidak bisa dibaca lewat gerbang", anti.status === 403 || anti.status === 502);
  // skor tempelan (tidak ada murid yang benar-benar main di E2E) supaya ada pemenang
  await j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: uji[0], gameSesi: "manual", json: { students: [{ studentId: k.siswa[2].id, points: 9, name: "x" }, { studentId: k.siswa[1].id, points: 4 }], game: uji[0], siswa: [{ siswaId: k.siswa[2].id, skor: 9 }, { siswaId: k.siswa[1].id, skor: 4 }] } } });
  await hub.reload();
  await hub.getByRole("tab", { name: "Multi Permainan" }).click();
  await hub.locator("table button", { hasText: "Buka" }).first().click();
  await hub.getByText("Hall of Fame sesi").waitFor({ timeout: 8000 }).catch(() => {});
  cek("UI Multi Permainan menampilkan sesi", await hub.getByText("Hall of Fame sesi").isVisible());
  await hub.screenshot({ path: join(akar, "docs", "layar-multi.png") });
  await hub.getByRole("button", { name: /Umumkan pemenang/ }).click();
  await hub.locator(".tangga .t1").waitFor({ timeout: 10000 });
  await hub.waitForTimeout(3500);
  cek("layar pemenang menampilkan juara", (await hub.locator("#umum").innerText()).includes("Citra Dewi"));
  await hub.screenshot({ path: join(akar, "docs", "layar-pemenang.png") });
} catch (e) {
  cek("E2E selesai tanpa galat", false, String(e.message ?? e));
} finally {
  await peramban?.close();
  if (process.platform === "win32") spawnSync("taskkill", ["/pid", String(srv.pid), "/T", "/F"]); else srv.kill();
}
mkdirSync(join(akar, "docs"), { recursive: true });
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);

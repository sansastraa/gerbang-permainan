﻿// Uji UI aplikasi siswa pada hub yang menyala (default http://localhost:8000, PIN 1234): tab Aplikasi, halaman /murid, mode wajib aplikasi.
import { chromium } from "playwright-core";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
const akar = fileURLToPath(new URL("../..", import.meta.url));
const base = process.env.GERBANG_URL ?? "http://localhost:8000";
const PIN = process.env.GERBANG_PIN ?? "1234";
const H = { "x-host-token": PIN, "content-type": "application/json" };
const hasil = [];
const cek = (n, ok, info = "") => { hasil.push(ok); console.log(`${ok ? "✔" : "✘"} ${n}${info ? ` — ${info}` : ""}`); };
const j = async (p, o = {}) => (await fetch(base + p, { headers: H, ...o })).json();
const b = await chromium.launch({ channel: "msedge" });
let wajibAwal = false;
try {
  const awal = await j("/api/aplikasi"); wajibAwal = awal.wajib;
  await j("/api/aplikasi", { method: "POST", body: JSON.stringify({ wajib: false }) });
  const d = await j("/api/aplikasi");
  const pas = await (await fetch(`${base}/api/aplikasi/pasang`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ kode: d.kode, nama: "Pixel 7 (uji)", platform: "android", versi: "1.0" }) })).json();
  cek("perangkat uji dipasangkan dengan kode", pas.ok === true);
  const guru = await (await b.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1.5 })).newPage();
  await guru.goto(base); await guru.evaluate(() => sessionStorage.clear()); await guru.reload();
  await guru.locator("#pin").fill(PIN); await guru.getByRole("button", { name: "Buka" }).click();
  await guru.getByRole("tab", { name: "Aplikasi" }).click();
  await guru.getByText("KODE PASANGAN").waitFor({ timeout: 8000 });
  await guru.waitForTimeout(1800);
  cek("tab Aplikasi menampilkan kode pasangan dan perangkat", (await guru.locator("main").innerText()).includes("Pixel 7 (uji)"));
  await guru.screenshot({ path: join(akar, "docs", "layar-aplikasi.png") });
  await guru.getByRole("switch", { name: "Wajib aplikasi untuk murid" }).click();
  await guru.waitForTimeout(1200);
  cek("sakelar wajib aplikasi menyala", (await guru.getByRole("switch", { name: "Wajib aplikasi untuk murid" }).getAttribute("aria-checked")) === "true");
  // web biasa ditolak, aplikasi (cookie) diterima
  const murid = await (await b.newContext({ viewport: { width: 420, height: 800 } })).newPage();
  const web = await murid.goto(`${base}/games/claim80/`);
  cek("web biasa ditolak saat wajib aplikasi (403)", web.status() === 403 && (await murid.getByText("Mainkan lewat aplikasi Gerbang Siswa.").isVisible()));
  const ctxApl = await b.newContext({ viewport: { width: 420, height: 860 }, deviceScaleFactor: 2 });
  await ctxApl.addCookies([{ name: "gp_app", value: pas.cookie.split("=")[1], url: base }]);
  const apl = await ctxApl.newPage();
  const ok = await apl.goto(`${base}/games/claim80/`);
  cek("perangkat terpasang boleh membuka game", ok.status() === 200);
  await apl.goto(`${base}/murid`); await apl.waitForTimeout(2500);
  cek("halaman /murid memuat daftar game dan segera hadir", (await apl.locator(".m-kartu").count()) >= 5 && (await apl.locator(".segera-kartu").count()) === 9);
  await apl.screenshot({ path: join(akar, "docs", "layar-murid.png") });
} catch (e) { cek("uji aplikasi selesai tanpa galat", false, String(e.message ?? e).split("\n")[0]); }
await j("/api/aplikasi", { method: "POST", body: JSON.stringify({ wajib: wajibAwal, cabut: "semua" }) }).catch(() => {});
await b.close();
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);

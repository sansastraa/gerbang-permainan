// Uji UI presensi pada hub yang sudah menyala (default http://localhost:8000, PIN 1234): node tests/e2e/presensi.mjs
// Memakai/menambah kelas contoh "Presensi Uji" agar data lain tidak tersentuh.
import { chromium } from "playwright-core";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
const akar = fileURLToPath(new URL("../..", import.meta.url));
const base = process.env.GERBANG_URL ?? "http://localhost:8000";
const PIN = process.env.GERBANG_PIN ?? "1234";
const H = { "x-host-token": PIN, "content-type": "application/json" };
const j = async (p, o = {}) => (await fetch(base + p, { headers: H, ...o })).json();
const hasil = [];
const cek = (n, ok, info = "") => { hasil.push(ok); console.log(`${ok ? "✔" : "✘"} ${n}${info ? ` — ${info}` : ""}`); };

let k = (await j("/api/kelas")).kelas.find((x) => x.nama === "Presensi Uji");
if (!k) { await j("/api/kelas", { method: "POST", body: JSON.stringify({ nama: "Presensi Uji", daftar: ["Aisyah Rahma", "Bima Prakoso", "Citra Lestari", "Dimas Anggara", "Elsa Maharani", "Farhan Hakim", "Gita Permata", "Hana Nabila"].join("\n") }) }); k = (await j("/api/kelas")).kelas.find((x) => x.nama === "Presensi Uji"); }
const b = await chromium.launch({ channel: "msedge" });
const p = await (await b.newContext({ viewport: { width: 1280, height: 800 }, deviceScaleFactor: 2 })).newPage();
const galat = [];
p.on("pageerror", (e) => galat.push(String(e)));
p.on("console", (m) => m.type() === "error" && galat.push(m.text()));
try {
  await p.goto(base);
  await p.evaluate(([id]) => { sessionStorage.clear(); localStorage.setItem("gerbang.kelas", id); localStorage.removeItem("gerbang.hanyaHadir"); }, [k.id]);
  await p.reload();
  await p.locator("#pin").fill(PIN); await p.getByRole("button", { name: "Buka" }).click();
  await p.getByRole("tab", { name: "Presensi" }).click();
  await p.getByRole("button", { name: "Semua hadir" }).waitFor();
  await p.getByRole("button", { name: "Kosongkan" }).click().catch(() => {}); p.once("dialog", (d) => d.accept());
  await p.waitForTimeout(500);
  await p.getByRole("button", { name: "Semua hadir" }).click();
  await p.waitForTimeout(700);
  await p.getByRole("group", { name: "Status Bima Prakoso" }).getByRole("button", { name: "Sakit" }).click();
  await p.getByRole("group", { name: "Status Citra Lestari" }).getByRole("button", { name: "Izin" }).click();
  await p.waitForTimeout(900);
  cek("ringkasan hari: 6 dari 8 hadir", await p.getByText("6 dari 8 siswa hadir").first().isVisible());
  await p.waitForTimeout(1500);
  await p.screenshot({ path: join(akar, "docs", "layar-presensi.png") });
  await p.reload(); await p.getByRole("tab", { name: "Presensi" }).click();
  await p.getByText("6 dari 8 siswa hadir").first().waitFor({ timeout: 8000 }).catch(() => {});
  cek("presensi tersimpan setelah muat ulang", await p.getByText("6 dari 8 siswa hadir").first().isVisible());
  await p.getByRole("button", { name: "Rekap dan unduh" }).click();
  await p.locator("table.rekap").waitFor({ timeout: 8000 });
  cek("rekap memuat nama siswa", (await p.locator("table.rekap").innerText()).includes("Aisyah Rahma"));
  await p.waitForTimeout(1500);
  await p.screenshot({ path: join(akar, "docs", "layar-rekap-presensi.png") });
  const [unduh] = await Promise.all([p.waitForEvent("download"), p.getByRole("button", { name: "Unduh CSV" }).click()]);
  cek("CSV terunduh", /presensi-.*\.csv$/.test(unduh.suggestedFilename()), unduh.suggestedFilename());
  await p.getByRole("tab", { name: "Dunia" }).click();
  await p.getByRole("switch", { name: "Hanya siswa yang hadir hari ini" }).click();
  await p.getByText("6 dari 8 siswa hadir hari ini").waitFor({ timeout: 8000 }).catch(() => {});
  cek("Dunia menunjukkan jumlah yang hadir", await p.getByText("6 dari 8 siswa hadir hari ini").isVisible());
  await p.waitForTimeout(1200);
  await p.screenshot({ path: join(akar, "docs", "layar-dunia-hadir.png") });
  cek("tanpa galat di konsol", galat.length === 0, galat.join(" | ").slice(0, 200));
} catch (e) { cek("uji presensi selesai tanpa galat", false, String(e.message ?? e).split("\n")[0]); }
await b.close();
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);
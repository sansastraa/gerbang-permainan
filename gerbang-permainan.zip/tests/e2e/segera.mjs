﻿// Memeriksa kartu abu-abu "segera hadir" di web gerbang (layar terkunci dan tab Dunia): node tests/e2e/segera.mjs
import { chromium } from "playwright-core";
import { fileURLToPath } from "node:url";
import { join } from "node:path";
const akar = fileURLToPath(new URL("../..", import.meta.url));
const base = process.env.GERBANG_URL ?? "http://localhost:8000";
const PIN = process.env.GERBANG_PIN ?? "1234";
const nama = ["Invisible Maze", "The Radius", "Number Target", "Exam with Game", "Card and Play", "Shark Escape", "Escape the Traffic", "Math Puzzle", "Detektif Cilik"];
const hasil = [];
const cek = (n, ok, info = "") => { hasil.push(ok); console.log(`${ok ? "✔" : "✘"} ${n}${info ? ` — ${info}` : ""}`); };
const b = await chromium.launch({ channel: "msedge" });
const p = await (await b.newContext({ viewport: { width: 1280, height: 900 }, deviceScaleFactor: 1.5 })).newPage();
try {
  await p.goto(base); await p.evaluate(() => sessionStorage.clear()); await p.reload();
  await p.locator(".segera-kartu").first().waitFor({ timeout: 10000 });
  const teks = await p.locator(".segera").innerText();
  cek("layar terkunci menampilkan 9 kartu segera hadir", (await p.locator(".segera-kartu").count()) === 9 && nama.every((n) => teks.includes(n)));
  await p.waitForTimeout(1500);
  await p.evaluate(() => document.querySelector(".segera")?.scrollIntoView({ block: "center" })); await p.waitForTimeout(700);
  await p.screenshot({ path: join(akar, "docs", "layar-segera-terkunci.png") });
  cek("kartu tidak bisa diklik (tanpa tombol)", (await p.locator(".segera button, .segera a").count()) === 0);
  await p.locator("#pin").fill(PIN); await p.getByRole("button", { name: "Buka" }).click();
  await p.getByRole("tab", { name: "Kelas" }).waitFor(); await p.waitForTimeout(2500);
  cek("tab Dunia menampilkan 9 kartu segera hadir", (await p.locator(".segera-kartu").count()) === 9);
  await p.evaluate(() => document.querySelector(".segera")?.scrollIntoView({ block: "center" })); await p.waitForTimeout(900);
  await p.screenshot({ path: join(akar, "docs", "layar-segera-dunia.png") });
  await p.getByRole("tab", { name: "Multi Permainan" }).click(); await p.waitForTimeout(1200);
  cek("kartu segera hadir tidak muncul di Multi Permainan", (await p.locator(".segera").count()) === 0);
} catch (e) { cek("uji segera hadir selesai tanpa galat", false, String(e.message ?? e).split("\n")[0]); }
await b.close();
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);

import test from "node:test";
import assert from "node:assert/strict";
import http from "node:http";
import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { buatHub } from "../hub/server.mjs";
import { targetGame } from "../hub/lib/proxy.mjs";

const PIN = "guru-1234";
const dengarkan = (s) => new Promise((ok) => s.listen(0, "127.0.0.1", () => ok(s.address().port)));

/** Server game palsu: melayani summary.json (dengan pemeriksaan token) dan meniru /host. */
function gamePalsu() {
  return http.createServer((req, res) => {
    if (req.url.includes("/api/sessions/G1/summary.json")) {
      if (req.headers["x-host-token"] !== PIN) { res.writeHead(401); return res.end("{}"); }
      res.writeHead(200, { "content-type": "application/json" });
      return res.end(JSON.stringify({ students: [{ studentId: "", name: "?", points: 1 }] }));
    }
    res.writeHead(200, { "content-type": "text/plain", "x-host": req.headers.host ?? "", "x-xff": req.headers["x-forwarded-for"] ?? "" });
    res.end(`game:${req.url}`);
  });
}

async function siapkan() {
  const g = gamePalsu();
  const pg = await dengarkan(g);
  const daftar = targetGame({ RR_TARGET: `http://127.0.0.1:${pg}`, C80_TARGET: "http://127.0.0.1:1", GL_TARGET: "http://127.0.0.1:1", LR_TARGET: "http://127.0.0.1:1", TR_TARGET: "http://127.0.0.1:1" });
  const hub = buatHub({ pin: PIN, dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar, maksGagal: 3 });
  const ph = await dengarkan(hub);
  const base = `http://127.0.0.1:${ph}`;
  const j = async (path, { metode = "GET", badan, pin = PIN } = {}) => {
    const r = await fetch(base + path, { method: metode, headers: { "x-host-token": pin, ...(badan ? { "content-type": "application/json" } : {}) }, body: badan && JSON.stringify(badan) });
    return { status: r.status, json: await r.json().catch(() => null) };
  };
  return { base, j, tutup: () => { hub.close(); g.close(); hub.closeAllConnections?.(); g.closeAllConnections?.(); } };
}

test("PIN salah ditolak, benar diterima, percobaan berulang dibatasi", async () => {
  const t = await siapkan();
  try {
    assert.equal((await t.j("/api/kelas", { pin: "salah" })).status, 401);
    assert.equal((await t.j("/api/pin", { metode: "POST", badan: { pin: "nope" } })).status, 401);
    assert.equal((await t.j("/api/pin", { metode: "POST", badan: { pin: PIN } })).status, 200);
    assert.equal((await t.j("/api/kelas")).status, 200);
    for (let i = 0; i < 4; i++) await t.j("/api/pin", { metode: "POST", badan: { pin: "x" + i } });
    assert.equal((await t.j("/api/pin", { metode: "POST", badan: { pin: PIN } })).status, 429);
  } finally { t.tutup(); }
});

test("proxy meneruskan /games/<key>/*, menjaga Host asli, memblokir /api/host-token", async () => {
  const t = await siapkan();
  try {
    const r = await fetch(`${t.base}/games/route-rush/host?x=1`);
    assert.equal(await r.text(), "game:/games/route-rush/host?x=1");
    assert.match(r.headers.get("x-host"), /^127\.0\.0\.1:\d+$/);
    assert.equal((await fetch(`${t.base}/games/route-rush/api/host-token`)).status, 403);
    const mati = await fetch(`${t.base}/games/claim80/`);
    assert.equal(mati.status, 502); assert.match(await mati.text(), /belum menyala/);
    const st = await (await fetch(`${t.base}/games/_gerbang`)).json();
    assert.equal(st.games["route-rush"].hidup, true); assert.equal(st.games.claim80.hidup, false);
    assert.equal((await fetch(`${t.base}/lib/server.mjs`)).status, 404);
    assert.equal((await fetch(`${t.base}/../package.json`)).status, 404);
  } finally { t.tutup(); }
});

test("kelas -> Multi Permainan -> hasil dari game (token diteruskan) -> Hall of Fame", async () => {
  const t = await siapkan();
  try {
    let k = (await t.j("/api/kelas", { metode: "POST", badan: { nama: "7A", daftar: "Ani\nBudi\nAni\n\nCici" } })).json.kelas[0];
    assert.deepEqual(k.siswa.map((s) => s.nama), ["Ani", "Budi", "Cici"]);
    const idAni = k.siswa[0].id;
    k = (await t.j("/api/kelas", { metode: "POST", badan: { id: k.id, nama: "7A", daftar: "Ani\nBudi\nCici\nDodi" } })).json.kelas[0];
    assert.equal(k.siswa[0].id, idAni); // id stabil
    assert.equal((await t.j("/api/multi", { metode: "POST", badan: { kelasId: k.id, games: ["route-rush"] } })).status, 400);
    const m = (await t.j("/api/multi", { metode: "POST", badan: { kelasId: k.id, games: ["route-rush", "claim80"] } })).json.sesi;
    assert.equal((await t.j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: "glacia", gameSesi: "G1" } })).status, 400);
    // game palsu menjawab dengan token benar; id siswa kosong -> tidak cocok
    const a = await t.j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: "route-rush", gameSesi: "G1" } });
    assert.equal(a.status, 200); assert.equal(a.json.tidakCocok.length, 1);
    const manual = { students: [{ studentId: k.siswa[0].id, points: 9 }, { studentId: k.siswa[1].id, points: 4 }] };
    const b = await t.j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: "claim80", gameSesi: "manual", json: manual } });
    assert.equal(b.json.sesi.hof[0].nama, "Ani"); assert.equal(b.json.sesi.hof[0].total, 10);
    assert.equal((await t.j("/api/hof?kelas=" + k.id)).json.hof[0].nama, "Ani");
    assert.equal((await t.j(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey: "route-rush", gameSesi: "../x" } })).status, 400);
  } finally { t.tutup(); }
});

test("PIN dapat diubah: lama tak berlaku, baru berlaku, game memakai PIN baru", async () => {
  const dipanggil = [];
  const g = gamePalsu();
  const pg = await dengarkan(g);
  const daftar = targetGame({ RR_TARGET: `http://127.0.0.1:${pg}` });
  const hub = buatHub({ pin: "1234", pinBawaan: "1234", dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar, simpanPin: (p) => dipanggil.push(p) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  const kirim = (pin, badan) => fetch(`${base}/api/pin/ubah`, { method: "POST", headers: { "x-host-token": pin, "content-type": "application/json" }, body: JSON.stringify(badan) });
  try {
    const info = await (await fetch(`${base}/api/pin/info`, { headers: { "x-host-token": "1234" } })).json();
    assert.equal(info.bawaan, true);
    assert.equal((await kirim("salah", { pinBaru: "abcd" })).status, 401);
    assert.equal((await kirim("1234", { pinBaru: "ab" })).status, 400);
    assert.equal((await kirim("1234", { pinBaru: "rahasia9" })).status, 200);
    assert.deepEqual(dipanggil, ["rahasia9"]);
    assert.equal((await fetch(`${base}/api/kelas`, { headers: { "x-host-token": "1234" } })).status, 401);
    assert.equal((await fetch(`${base}/api/kelas`, { headers: { "x-host-token": "rahasia9" } })).status, 200);
  } finally { hub.close(); g.close(); hub.closeAllConnections?.(); g.closeAllConnections?.(); }
});

test("PIN dari env tidak bisa diubah", async () => {
  const hub = buatHub({ pin: "envpin1", pinTerkunci: true, dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar: targetGame({}) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  try {
    const r = await fetch(`${base}/api/pin/ubah`, { method: "POST", headers: { "x-host-token": "envpin1", "content-type": "application/json" }, body: JSON.stringify({ pinBaru: "baru1234" }) });
    assert.equal(r.status, 409);
  } finally { hub.close(); hub.closeAllConnections?.(); }
});
test("mode perawatan: murid dapat 503, guru lolos, bisa dibuka lagi, bertahan setelah restart", async () => {
  const g = gamePalsu();
  const pg = await dengarkan(g);
  const daftar = targetGame({ RR_TARGET: `http://127.0.0.1:${pg}` });
  const dir = mkdtempSync(join(tmpdir(), "gp-"));
  const mulai = async () => { const h2 = buatHub({ pin: "1234", dataDir: dir, daftar }); return [h2, `http://127.0.0.1:${await dengarkan(h2)}`]; };
  let [hub, base] = await mulai();
  const H = { "x-host-token": "1234", "content-type": "application/json" };
  const rr = daftar.find((x) => x.key === "route-rush");
  try {
    assert.equal((await fetch(`${base}${rr.prefix}/health`)).status, 200);
    assert.equal((await fetch(`${base}/api/perawatan`, { method: "POST", headers: { "content-type": "application/json" }, body: "{}" })).status, 401);
    assert.equal((await fetch(`${base}/api/perawatan`, { method: "POST", headers: H, body: JSON.stringify({ key: "nama-ngawur", aktif: true }) })).status, 400);
    assert.equal((await fetch(`${base}/api/perawatan`, { method: "POST", headers: H, body: JSON.stringify({ key: "route-rush", aktif: true, pesan: "Ganti <soal>" }) })).status, 200);
    const murid = await fetch(`${base}${rr.prefix}/health`);
    assert.equal(murid.status, 503);
    const html = await murid.text();
    assert.ok(html.includes("Ganti &lt;soal&gt;") && !html.includes("<soal>"));
    assert.equal((await fetch(`${base}${rr.prefix}/health`, { headers: { "x-host-token": "1234" } })).status, 200);
    const st = await (await fetch(`${base}/api/status`)).json();
    assert.equal(st.games.find((x) => x.key === "route-rush").perawatan, true);
    hub.close(); hub.closeAllConnections?.();
    [hub, base] = await mulai();
    assert.equal((await fetch(`${base}${rr.prefix}/health`)).status, 503);
    await fetch(`${base}/api/perawatan`, { method: "POST", headers: H, body: JSON.stringify({ key: "route-rush", aktif: false }) });
    assert.equal((await fetch(`${base}${rr.prefix}/health`)).status, 200);
  } finally { hub.close(); g.close(); hub.closeAllConnections?.(); g.closeAllConnections?.(); }
});
test("presensi: input, rekap, CSV, daftar hadir, dan Multi Permainan hanya yang hadir", async () => {
  const g = gamePalsu();
  const pg = await dengarkan(g);
  const hub = buatHub({ pin: "1234", dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar: targetGame({ RR_TARGET: `http://127.0.0.1:${pg}` }) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  const H = { "x-host-token": "1234", "content-type": "application/json" };
  const j = async (p, o = {}) => { const r = await fetch(base + p, { headers: H, ...o }); return { status: r.status, json: await r.json().catch(() => null), r }; };
  try {
    const k = (await j("/api/kelas", { method: "POST", body: JSON.stringify({ nama: "7A", daftar: "Ani\nBudi\nCici" }) })).json.kelas[0];
    const [a, b, c] = k.siswa;
    assert.equal((await fetch(`${base}/api/presensi?kelas=${k.id}&tanggal=2026-11-06`)).status, 401);
    assert.equal((await j(`/api/presensi?kelas=${k.id}&tanggal=2026-13-40`)).status, 400);
    assert.equal((await j(`/api/presensi/hadir?kelas=${k.id}&tanggal=2026-11-06`)).json.tercatat, false);
    // Multi dengan hanyaHadir sebelum presensi diisi ditolak
    const gm = ["route-rush", "claim80"];
    assert.equal((await j("/api/multi", { method: "POST", body: JSON.stringify({ kelasId: k.id, games: gm, hanyaHadir: true, tanggal: "2026-11-06" }) })).status, 409);
    const simpan = await j("/api/presensi", { method: "POST", body: JSON.stringify({ kelasId: k.id, tanggal: "2026-11-06", status: { [a.id]: "hadir", [b.id]: "sakit", [c.id]: "hadir" } }) });
    assert.equal(simpan.json.ringkas.hadir, 2);
    assert.equal((await j("/api/presensi", { method: "POST", body: JSON.stringify({ kelasId: k.id, tanggal: "2026-11-06", status: { ngawur: "hadir" } }) })).status, 400);
    assert.equal((await j("/api/presensi", { method: "POST", body: JSON.stringify({ kelasId: k.id, tanggal: "2026-11-06", status: { [c.id]: "izin" } }) })).json.ringkas.izin, 1);
    const hadir = (await j(`/api/presensi/hadir?kelas=${k.id}&tanggal=2026-11-06`)).json;
    assert.deepEqual(hadir.siswa.map((s) => s.nama), ["Ani"]);
    const rekap = (await j(`/api/presensi/rekap?kelas=${k.id}&dari=2026-11-01&sampai=2026-11-30`)).json;
    assert.equal(rekap.baris.find((r) => r.nama === "Ani").persen, 100);
    const csv = await (await fetch(`${base}/api/presensi/csv?kelas=${k.id}&dari=2026-11-01&sampai=2026-11-30`, { headers: H })).text();
    assert.ok(csv.includes("Ani"));
    const multi = await j("/api/multi", { method: "POST", body: JSON.stringify({ kelasId: k.id, games: gm, hanyaHadir: true, tanggal: "2026-11-06" }) });
    assert.equal(multi.status, 201);
    assert.deepEqual(multi.json.sesi.siswa.map((s) => s.nama), ["Ani"]);
    // hapus kelas membersihkan presensinya
    await j(`/api/kelas/${k.id}`, { method: "DELETE" });
    assert.equal((await j(`/api/presensi?kelas=${k.id}&tanggal=2026-11-06`)).status, 400);
  } finally { hub.close(); g.close(); hub.closeAllConnections?.(); g.closeAllConnections?.(); }
});
test("umpan balik anonim dan deteksi perangkat: alur lengkap lewat gerbang dengan injeksi skrip", async () => {
  const http = await import("node:http");
  const upstream = http.createServer((req, res) => {
    if (req.url.endsWith("/api/data")) { res.writeHead(200, { "content-type": "application/json" }); return res.end('{"ok":1}'); }
    res.writeHead(200, { "content-type": "text/html; charset=utf-8" });
    res.end("<html><head></head><body>game claim80</body></html>");
  });
  const pu = await dengarkan(upstream);
  const hub = buatHub({ pin: "1234", dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar: targetGame({ C80_TARGET: `http://127.0.0.1:${pu}` }) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  const H = { "x-host-token": "1234", "content-type": "application/json" };
  const post = (p, b, hd = { "content-type": "application/json" }) => fetch(base + p, { method: "POST", headers: hd, body: JSON.stringify(b) }).then(async (r) => ({ status: r.status, json: await r.json().catch(() => null) }));
  try {
    // injeksi: HTML disisipi, JSON tidak disentuh
    const html = await (await fetch(`${base}/games/claim80/`, { headers: { accept: "text/html" } })).text();
    assert.ok(html.includes("/siswa.js") && html.includes("game claim80"));
    assert.equal(await (await fetch(`${base}/games/claim80/api/data`, { headers: { accept: "application/json" } })).text(), '{"ok":1}');
    // kelas, sesi multi
    const k = (await (await fetch(`${base}/api/kelas`, { method: "POST", headers: H, body: JSON.stringify({ nama: "7A", daftar: "Ani\nBudi" }) })).json()).kelas[0];
    const sesi = (await (await fetch(`${base}/api/multi`, { method: "POST", headers: H, body: JSON.stringify({ kelasId: k.id, games: ["route-rush", "claim80"] }) })).json()).sesi;
    const dev1 = "perangkat-satu-1", dev2 = "perangkat-dua-22";
    const ua = { "content-type": "application/json", "user-agent": "Mozilla/5.0 (Linux; Android 13; SM-A135F) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36" };
    // sebelum dibuka: tidak ada popup
    assert.equal((await post("/api/siswa/denyut", { dev: dev1, game: "claim80", peran: "siswa", info: { lebar: 360, tinggi: 800, sentuh: 5 } }, ua)).json.umpan, null);
    assert.equal((await post("/api/siswa/denyut", { dev: "x" })).status, 400);
    // guru membuka umpan balik (PIN wajib)
    assert.equal((await post(`/api/umpan/${sesi.id}`, { aktif: true })).status, 401);
    assert.equal((await post(`/api/umpan/${sesi.id}`, { aktif: true }, H)).json.aktif, true);
    const popup = (await post("/api/siswa/denyut", { dev: dev1, game: "claim80", peran: "siswa" }, ua)).json.umpan;
    assert.equal(popup.sesiId, sesi.id);
    assert.equal(popup.kuis.length, 3);
    // game di luar sesi dan peran guru/proyektor tidak mendapat popup
    assert.equal((await post("/api/siswa/denyut", { dev: dev2, game: "glacia", peran: "siswa" })).json.umpan, null);
    assert.equal((await post("/api/siswa/denyut", { dev: dev2, game: "claim80", peran: "proyektor" })).json.umpan, null);
    // kirim: tidak valid ditolak, valid diterima, ganda diabaikan
    const jawab = { sesiId: sesi.id, dev: dev1, favorit: "claim80", rating: { "route-rush": 4, claim80: 5 }, kuis: [5, 4, 3] };
    assert.equal((await post("/api/umpan/kirim", { ...jawab, kuis: [5, 4, 9] })).status, 400);
    assert.equal((await post("/api/umpan/kirim", jawab)).json.ok, true);
    assert.equal((await post("/api/umpan/kirim", { ...jawab, favorit: "route-rush" })).json.sudah, true);
    assert.equal((await post("/api/siswa/denyut", { dev: dev1, game: "claim80", peran: "siswa" }, ua)).json.umpan, null); // sudah mengisi
    // proyektor hanya melihat bila guru menampilkan; isinya anonim
    assert.equal((await post("/api/siswa/denyut", { dev: dev2, game: "claim80", peran: "proyektor" })).json.layar, null);
    await post(`/api/umpan/${sesi.id}`, { tampil: true }, H);
    const layar = (await post("/api/siswa/denyut", { dev: dev2, game: "claim80", peran: "proyektor" })).json.layar;
    assert.equal(layar.ringkas.jumlah, 1);
    assert.equal(layar.ringkas.favorit.claim80, 1);
    assert.equal(JSON.stringify(layar).includes(dev1), false);
    // perangkat terdeteksi (hanya siswa), tanpa id
    const per = await (await fetch(`${base}/api/perangkat`, { headers: H })).json();
    assert.equal(per.jenis.Ponsel, 1);
    assert.equal(per.perangkat[0].os, "Android");
    assert.equal(JSON.stringify(per).includes(dev1), false);
    // menutup mematikan popup dan tampilan
    await post(`/api/umpan/${sesi.id}`, { aktif: false }, H);
    assert.equal((await post("/api/siswa/denyut", { dev: dev2, game: "claim80", peran: "siswa" })).json.umpan, null);
    assert.equal((await post("/api/umpan/kirim", { ...jawab, dev: dev2 })).status, 409);
  } finally { hub.close(); upstream.close(); hub.closeAllConnections?.(); upstream.closeAllConnections?.(); }
});
test("akses guru: murid tidak bisa membuka host/proyektor tanpa PIN guru; cookie sesi guru membukanya", async () => {
  const http = await import("node:http");
  const upstream = http.createServer((req, res) => { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end(`<html><head></head><body>isi ${req.url}</body></html>`); });
  const pu = await dengarkan(upstream);
  const hub = buatHub({ pin: "1234", dataDir: mkdtempSync(join(tmpdir(), "gp-")), daftar: targetGame({ C80_TARGET: `http://127.0.0.1:${pu}` }) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  const nav = (p, h2 = {}) => fetch(base + p, { headers: { accept: "text/html", ...h2 } });
  try {
    // murid
    assert.equal((await nav("/games/claim80/")).status, 200);
    for (const p of ["/games/claim80/host", "/games/claim80/projector/KODE1", "/games/claim80/station/KODE1"]) {
      const r = await nav(p);
      assert.equal(r.status, 401, p);
      const html = await r.text();
      assert.ok(html.includes("khusus guru") && !html.includes("isi /games"), p);
    }
    assert.equal((await (await fetch(`${base}/api/guru/cek`)).json()).guru, false);
    // PIN salah tidak memberi cookie
    const salah = await fetch(`${base}/api/pin`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ pin: "0000" }) });
    assert.equal(salah.status, 401);
    assert.equal(salah.headers.get("set-cookie"), null);
    // guru: PIN benar -> cookie HttpOnly
    const benar = await fetch(`${base}/api/pin`, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ pin: "1234" }) });
    const sc = benar.headers.get("set-cookie");
    assert.ok(/gerbang_guru=[0-9a-f]{64}/.test(sc) && /HttpOnly/i.test(sc) && /SameSite=Lax/i.test(sc));
    const cookie = sc.split(";")[0];
    assert.equal((await (await fetch(`${base}/api/guru/cek`, { headers: { cookie } })).json()).guru, true);
    for (const p of ["/games/claim80/host", "/games/claim80/projector/KODE1"]) assert.equal((await nav(p, { cookie })).status, 200, p);
    // cookie palsu ditolak; header PIN (dipakai hub) tetap diterima
    assert.equal((await nav("/games/claim80/host", { cookie: `gerbang_guru=${"a".repeat(64)}` })).status, 401);
    assert.equal((await nav("/games/claim80/host", { "x-host-token": "1234" })).status, 200);
    // permintaan non-HTML (aset, API game) tidak digerbang
    assert.equal((await fetch(`${base}/games/claim80/assets/app.js`)).status, 200);
    // ganti PIN membatalkan cookie lama
    const ubah = await fetch(`${base}/api/pin/ubah`, { method: "POST", headers: { "content-type": "application/json", "x-host-token": "1234" }, body: JSON.stringify({ pinBaru: "baru5678" }) });
    assert.equal(ubah.status, 200);
    assert.equal((await nav("/games/claim80/host", { cookie })).status, 401);
    assert.equal((await nav("/games/claim80/host", { cookie: ubah.headers.get("set-cookie").split(";")[0] })).status, 200);
    // keluar menghapus cookie
    const keluar = await fetch(`${base}/api/keluar`, { method: "POST" });
    assert.ok(/Max-Age=0/i.test(keluar.headers.get("set-cookie")));
  } finally { hub.close(); upstream.close(); hub.closeAllConnections?.(); upstream.closeAllConnections?.(); }
});
test("aplikasi siswa: pasangkan perangkat, wajib aplikasi menutup web, peristiwa layar dicatat, cabut", async () => {
  const http = await import("node:http");
  const { mkdirSync, writeFileSync } = await import("node:fs");
  const upstream = http.createServer((req, res) => { res.writeHead(200, { "content-type": "text/html; charset=utf-8" }); res.end("<html><head></head><body>isi game</body></html>"); });
  const pu = await dengarkan(upstream);
  const dir = mkdtempSync(join(tmpdir(), "gp-"));
  const apk = join(dir, "dist"); mkdirSync(apk); writeFileSync(join(apk, "gerbang-siswa.apk"), "APK");
  const hub = buatHub({ pin: "1234", dataDir: dir, apkDir: apk, daftar: targetGame({ C80_TARGET: `http://127.0.0.1:${pu}` }) });
  const base = `http://127.0.0.1:${await dengarkan(hub)}`;
  const H = { "x-host-token": "1234", "content-type": "application/json" };
  const J = { "content-type": "application/json" };
  const nav = (p, h2 = {}) => fetch(base + p, { headers: { accept: "text/html", ...h2 } });
  try {
    const info = await (await fetch(`${base}/api/aplikasi/info`)).json();
    assert.deepEqual(info, { wajib: false, apk: ["gerbang-siswa.apk"] });
    assert.equal((await fetch(`${base}/unduh/gerbang-siswa.apk`)).status, 200);
    assert.equal((await fetch(`${base}/unduh/tidak-ada.apk`)).status, 404);
    assert.equal((await fetch(`${base}/api/aplikasi`)).status, 401);
    const d0 = await (await fetch(`${base}/api/aplikasi`, { headers: H })).json();
    assert.match(d0.kode, /^\d{6}$/);
    // sebelum wajib: web boleh
    assert.equal((await nav("/games/claim80/")).status, 200);
    // pasang: kode salah ditolak, benar memberi cookie
    assert.equal((await fetch(`${base}/api/aplikasi/pasang`, { method: "POST", headers: J, body: JSON.stringify({ kode: "000000" }) })).status, 401);
    const ok = await fetch(`${base}/api/aplikasi/pasang`, { method: "POST", headers: J, body: JSON.stringify({ kode: d0.kode, nama: "Pixel 7", platform: "android", versi: "1.0" }) });
    const pj = await ok.json();
    assert.ok(pj.ok && /^gp_app=a[0-9a-f]+\.[0-9a-f]{64}$/.test(pj.cookie));
    const cookie = pj.cookie;
    // wajib aplikasi
    await fetch(`${base}/api/aplikasi`, { method: "POST", headers: H, body: JSON.stringify({ wajib: true }) });
    const web = await nav("/games/claim80/");
    assert.equal(web.status, 403);
    assert.ok((await web.text()).includes("aplikasi Gerbang Siswa"));
    assert.equal((await nav("/games/claim80/", { cookie })).status, 200);
    assert.equal((await nav("/games/claim80/", { cookie: "gp_app=aabcdefgh.salah" })).status, 403);
    assert.equal((await nav("/games/claim80/", { "x-host-token": "1234" })).status, 200); // guru
    assert.equal((await fetch(`${base}/murid`)).status, 200); // halaman murid tetap terbuka
    // peristiwa layar
    assert.equal((await fetch(`${base}/api/aplikasi/peristiwa`, { method: "POST", headers: J, body: JSON.stringify({ jenis: "tangkap-layar" }) })).status, 401);
    const hdrApl = { ...J, cookie };
    for (const jenis of ["tangkap-layar", "tangkap-layar", "rekam-layar"]) assert.equal((await fetch(`${base}/api/aplikasi/peristiwa`, { method: "POST", headers: hdrApl, body: JSON.stringify({ jenis }) })).status, 200);
    assert.equal((await fetch(`${base}/api/aplikasi/peristiwa`, { method: "POST", headers: hdrApl, body: JSON.stringify({ jenis: "x" }) })).status, 400);
    const d1 = await (await fetch(`${base}/api/aplikasi`, { headers: H })).json();
    assert.equal(d1.perangkat[0].tangkap, 2);
    assert.equal(d1.perangkat[0].rekam, 1);
    assert.equal(JSON.stringify(d1).includes(cookie.split("=")[1].split(".")[1]), false); // token tidak bocor ke daftar
    // cabut: cookie lama tidak sah lagi
    await fetch(`${base}/api/aplikasi`, { method: "POST", headers: H, body: JSON.stringify({ cabut: d1.perangkat[0].id }) });
    assert.equal((await nav("/games/claim80/", { cookie })).status, 403);
  } finally { hub.close(); upstream.close(); hub.closeAllConnections?.(); upstream.closeAllConnections?.(); }
});
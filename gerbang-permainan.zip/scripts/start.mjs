// Menyalakan Gerbang: hub + (opsional) semua game yang sudah dibangun. Pakai: node scripts/start.mjs [--hub-saja] [--game a,b]
// Env: GERBANG_PORT (8000), GERBANG_HOST (0.0.0.0), GERBANG_PIN (PIN guru; bila kosong dibuat acak dan disimpan di data/pin.txt),
//      <KODE>_PORT / <KODE>_TARGET untuk menimpa port atau alamat game (KODE: RR C80 GL LR TR).
import { spawn, spawnSync } from "node:child_process";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { randomBytes } from "node:crypto";
import { fileURLToPath } from "node:url";
import { GAMES, pinSah } from "../hub/lib/katalog.mjs";
import { spesifikasi } from "../hub/lib/proses.mjs";
import { targetGame } from "../hub/lib/proxy.mjs";
import { buatHub } from "../hub/server.mjs";

const akar = fileURLToPath(new URL("..", import.meta.url));
const args = process.argv.slice(2);
const hubSaja = args.includes("--hub-saja");
const pilih = (args[args.indexOf("--game") + 1] ?? "").split(",").filter(Boolean);
const dataDir = process.env.GERBANG_DATA || `${akar}data`;
mkdirSync(dataDir, { recursive: true });

const PIN_BAWAAN = "1234";
function ambilPin() {
  const env = process.env.GERBANG_PIN;
  if (env) { if (!pinSah(env)) throw new Error("GERBANG_PIN harus 4â€“32 karakter ASCII tanpa spasi"); return { pin: env, asal: "GERBANG_PIN" }; }
  const berkas = `${dataDir}/pin.txt`;
  if (existsSync(berkas)) { const p = readFileSync(berkas, "utf8").trim(); if (pinSah(p)) return { pin: p, asal: "data/pin.txt (diubah dari hub)" }; }
  return { pin: PIN_BAWAAN, asal: "bawaan 1234 (ubah lewat tab PIN di hub)" };
}

let { pin, asal, terkunci } = ambilPin();
const rahasia = randomBytes(24).toString("hex");
const daftar = targetGame();
const anak = [];

function nyalakan() {
  if (hubSaja) return;
  {
  for (const g of daftar) {
    if (pilih.length && !pilih.includes(g.key)) continue;
    if (process.env[`${g.kode}_TARGET`]) continue; // game dijalankan di tempat lain
    const port = Number(new URL(g.target).port);
    const sp = spesifikasi(g, { akar, dataDir, pin, port, rahasia });
    const kurang = [sp.hasilBangun, sp.prasyarat].filter((p) => p && !existsSync(p));
    if (kurang.length || !existsSync(`${sp.cwd}/node_modules`)) {
      console.log(`! ${g.label} dilewati: ${kurang.length ? "belum dibangun/disiapkan (npm run build)" : "dependensi belum dipasang (npm run install:semua)"}`);
      continue;
    }
    const p = spawn(sp.jalan.join(" "), { cwd: sp.cwd, shell: true, env: { ...process.env, ...sp.env } });
    const tag = `[${g.key}]`.padEnd(15);
    for (const s of [p.stdout, p.stderr]) s.on("data", (d) => String(d).split(/\r?\n/).filter(Boolean).forEach((l) => console.log(`${tag}${l}`)));
    p.on("exit", (c) => console.log(`${tag}berhenti (${c})`));
    anak.push(p);
  }
  }
}
nyalakan();
function matikan() {
  for (const p of anak.splice(0)) { if (process.platform === "win32") spawnSync("taskkill", ["/pid", String(p.pid), "/T", "/F"]); else p.kill("SIGTERM"); }
}

const portHub = Number(process.env.GERBANG_PORT || 8000);
const host = process.env.GERBANG_HOST || "0.0.0.0";
const fontDir = (() => { const d = fileURLToPath(new URL("../node_modules/@fontsource-variable/plus-jakarta-sans/files", import.meta.url)); return existsSync(d) ? d : null; })();
const hub = buatHub({ pin, pinBawaan: PIN_BAWAAN, pinTerkunci: terkunci, simpanPin: (baru) => { pin = baru; writeFileSync(`${dataDir}/pin.txt`, baru); matikan(); setTimeout(nyalakan, 800); }, dataDir, daftar, fontDir, proto: process.env.GERBANG_PROTO || "http" });
hub.listen(portHub, host, () => {
  console.log(`
Gerbang Permainan di http://localhost:${portHub}`);
  console.log(`PIN guru: ${pin}   (sumber: ${asal})`);
});

function tutup() {
  matikan();
  process.exit(0);
}
process.on("SIGINT", tutup);
process.on("SIGTERM", tutup);
void GAMES;

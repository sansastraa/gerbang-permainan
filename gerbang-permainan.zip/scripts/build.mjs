﻿// Membangun klien semua game dengan BASE_PATH=/games/<key>. Pakai: node scripts/build.mjs [kunci ...]
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { GAMES } from "../hub/lib/katalog.mjs";
import { spesifikasi } from "../hub/lib/proses.mjs";

const akar = fileURLToPath(new URL("..", import.meta.url));
const pilih = process.argv.slice(2);
let gagal = 0;
for (const g of GAMES) {
  if (pilih.length && !pilih.includes(g.key)) continue;
  const sp = spesifikasi(g, { akar, pin: "build-only", port: g.port, rahasia: "build" });
  console.log(`\n== ${g.label}: ${sp.bangun.join(" ")}  (BASE_PATH=${g.prefix})`);
  const r = spawnSync(sp.bangun.join(" "), { cwd: sp.cwd, stdio: "inherit", shell: true, env: { ...process.env, BASE_PATH: g.prefix } });
  if (r.status !== 0) gagal++;
}
process.exit(gagal ? 1 : 0);

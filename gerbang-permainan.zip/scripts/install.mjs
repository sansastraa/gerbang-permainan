﻿// Pasang dependensi semua game. Pakai: node scripts/install.mjs [kunci ...]
// Di Windows dengan jalur panjang skrip pasca-pasang esbuild bisa gagal (ENOENT); cadangannya: pasang tanpa skrip,
// lalu bangun ulang modul native yang memang butuh (better-sqlite3).
import { spawnSync } from "node:child_process";
import { existsSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { GAMES } from "../hub/lib/katalog.mjs";

const akar = fileURLToPath(new URL("..", import.meta.url));
const pilih = process.argv.slice(2);
const npm = (args, cwd) => spawnSync("npm", [...args, "--no-audit", "--no-fund"], { cwd, stdio: "inherit", shell: true }).status === 0;
let gagal = 0;
for (const g of GAMES) {
  if (pilih.length && !pilih.includes(g.key)) continue;
  const cwd = `${akar}games/${g.dir}`;
  const cmd = existsSync(`${cwd}/package-lock.json`) ? "ci" : "install";
  console.log(`\n== ${g.label}: npm ${cmd}`);
  let ok = npm([cmd], cwd);
  if (!ok) {
    console.log("   gagal; mengulang tanpa skrip pasca-pasang lalu membangun ulang better-sqlite3");
    ok = npm([cmd, "--ignore-scripts"], cwd);
    if (ok && existsSync(`${cwd}/node_modules/better-sqlite3`)) ok = npm(["rebuild", "better-sqlite3"], cwd);
  }
  if (!ok) gagal++;
}
process.exit(gagal ? 1 : 0);

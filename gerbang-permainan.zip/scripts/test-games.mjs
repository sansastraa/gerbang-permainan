﻿// Menjalankan tes tiap game: node scripts/test-games.mjs [kunci ...]
import { spawnSync } from "node:child_process";
import { fileURLToPath } from "node:url";
import { GAMES } from "../hub/lib/katalog.mjs";

const akar = fileURLToPath(new URL("..", import.meta.url));
const pilih = process.argv.slice(2);
let gagal = 0;
for (const g of GAMES) {
  if (pilih.length && !pilih.includes(g.key)) continue;
  console.log(`\n== ${g.label}: npm test`);
  if (spawnSync("npm test", { cwd: `${akar}games/${g.dir}`, stdio: "inherit", shell: true }).status !== 0) gagal++;
}
process.exit(gagal ? 1 : 0);

# Laporan Gerbang Permainan

Lokasi kerja: `D:\gerbang-permainan` (jalur pendek wajib; di C: disk penuh dan jalur panjang membuat esbuild gagal `ENOENT`). Sumber game disalin dari `simpeteri13-main/games/*`; yang asli tidak diubah atau dihapus. Salinan lama tanpa node_modules ada di folder scratch sesi dan `C:\gerbang-permainan` (usang, boleh dibuang).

## Terbukti (game asli, Edge, satu origin, `npm run test:e2e`; PIN bawaan 1234, bisa diubah di tab PIN: game ikut restart dan PIN lama ditolak, diuji hidup)
- PIN salah ditolak (pesan + semua dunia tetap terkunci, 5 gagal/menit/IP → 429); PIN benar membuka semua dunia.
- Serah-terima ke konsol guru ASLI: Route Rush (daftar nama tampil), CLAIM 80 (tampil), Logic Rush ("Terhubung… Kelas 7A: 4 siswa", PIN terisi), Transit Rush (tampil). PIN tidak ada di URL.
- Hub menarik `summary.json` CLAIM 80 asli dengan token PIN lewat proxy (0 siswa karena belum ada yang main).
- Multi Permainan di dalam hub: buat sesi, skor tempelan, Hall of Fame sesi, layar **Umumkan pemenang** (hitung mundur, podium, konfeti), juara tiap dunia.
- `npm test` 9 lulus (skor, parser summary, impor nama, serah-terima, PIN, proxy, API dengan server game palsu); `npm run lint` bersih.

## Belum teruji / catatan jujur
- GLACIA kini terpasang, dibangun, bank soal diimpor (7.500 soal, `games/glacia/data/questions.json`), menyala lewat Gerbang dan menerima daftar kelas (E2E 18/18 untuk kelima game). Setelah clone baru jalankan `npm run import-bank` di `games/glacia`.
- Murid benar-benar bermain lalu game mengarahkan kembali ke hub (`?selesai=1&gameSesi=`) belum diuji; pengambilan otomatis hasil game bernilai belum terbukti. Pembuatan sesi REST Logic Rush dan Route Rush di E2E tidak berhasil/tak dicoba.
- Murid memilih nama dari daftar saat join (bukan mengetik) adalah perilaku game; yang terbukti hanya daftar tiba di konsol guru.
- Tes unit tiap game tidak dijalankan ulang di lokasi baru (`npm run test:game`). Route Rush dibangun dengan `build:dev` karena `check-production` menolak aset sementara.
- npm 11 tidak menjalankan skrip pasca-pasang tanpa persetujuan; esbuild dan better-sqlite3 tetap berfungsi pada uji ini.
- Belum diuji: perangkat nyata/ponsel murid, deploy online (HTTPS, WebSocket di balik hosting), Lovable, Product Sans (tidak dibundel, lisensi belum jelas).
- Hall of Fame hanya memakai skor dan waktu, bukan profil per game.

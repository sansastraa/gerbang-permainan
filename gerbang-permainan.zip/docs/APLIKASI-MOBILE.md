# Desain: Gerbang Siswa (aplikasi Android dan iOS)

## Tujuan
Murid bermain lewat **aplikasi sendiri** (.apk dan .app/.ipa) yang terisolasi, bukan lewat web biasa, agar soal dan jawaban tidak bocor lewat tangkap layar, tautan, atau peramban umum.

## Arsitektur
```
Aplikasi murid ──(kode pasangan, sekali)──► Gerbang (hub)
   │  cookie gp_app (HMAC)                   ├─ /murid                 daftar game untuk murid
   └─ WebView terkunci ke alamat gerbang ───►├─ /games/<kunci>/        halaman murid, disaring bila "wajib aplikasi"
                                             ├─ /games/<kunci>/host…   khusus guru (PIN guru)
                                             └─ /api/aplikasi/*        pasang, peristiwa, kelola
```
Satu basis kode web melayani semua perangkat. Aplikasi hanya cangkang: **tidak ada logika permainan di aplikasi**, sehingga game baru otomatis tersedia.

## Aliran pemasangan
1. Guru: tab **Aplikasi** menampilkan kode pasangan 6 angka (`/api/aplikasi`).
2. Murid: mengisi alamat gerbang dan kode. Aplikasi memanggil `POST /api/aplikasi/pasang`.
3. Server membuat id perangkat dan token `HMAC-SHA256(rahasia, "apl:<id>")`, mengembalikan cookie `gp_app=<id>.<token>`. Rahasia disimpan di `data/aplikasi.json` dan dapat diganti dengan "Putuskan semua".
4. Aplikasi menyimpan cookie, memasangnya ke WebView, lalu membuka `/murid`.
5. Salah kode lebih dari 10 kali per menit per IP: ditolak (429).

## Mode "Wajib aplikasi"
Bila menyala, gerbang menolak (403) **navigasi HTML halaman murid** dan **upgrade WebSocket** game tanpa cookie `gp_app` yang sah, kecuali permintaan guru (PIN guru). `/murid` dan halaman hub tetap terbuka. Perangkat yang diputuskan guru kehilangan akses seketika.

## Isolasi
- WebView hanya mengizinkan satu *origin* (alamat gerbang). Navigasi, sumber daya, dan jendela baru ke tempat lain diblokir.
- Halaman guru/proyektor (`/host`, `/operator`, `/projector`, `/display`, `/watch`, `/obs`, `/station`, `/layar`) diblokir di aplikasi, dan di server hanya terbuka dengan PIN guru.
- Tanpa bilah alamat, tanpa debugging WebView, akses berkas dimatikan, cadangan data dimatikan, pilih-teks dan menu konteks dimatikan, cache dibersihkan saat aplikasi berhenti.

## Anti tangkap layar
| | Android | iOS |
| --- | --- | --- |
| Blokir | `FLAG_SECURE` (tangkap, rekam, pratinjau recents) | Secure text field (layar jadi gelap pada tangkapan), penutup saat direkam dan saat berpindah aplikasi |
| Deteksi | `ScreenCaptureCallback` (Android 14+) | `userDidTakeScreenshotNotification`, `UIScreen.isCaptured` |
| Laporan | `POST /api/aplikasi/peristiwa` | sama |
Guru melihat jumlah percobaan tangkap/rekam per perangkat di tab Aplikasi (angka merah).

## Yang tidak bisa dijamin
- Memotret layar dengan kamera lain.
- iOS tidak punya API resmi pemblokir tangkap layar (teknik yang dipakai umum tetapi tidak resmi).
- Perangkat root/jailbreak.
- Penguncian murid di dalam aplikasi: pakai Pin Layar (Android) atau Akses Terpandu/MDM (iOS).

## Titik integrasi di kode
| Bagian | Berkas |
| --- | --- |
| Pasang, kelola, wajib aplikasi, unduh APK | `hub/server.mjs` (`/api/aplikasi/*`, `/unduh/*`) |
| Halaman murid | `hub/public/murid.html` (rute `/murid`) |
| UI guru | `hub/public/app.js` (`tabAplikasi`, kolom "Lewat" di perangkat terdeteksi) |
| Android | `aplikasi/android/` |
| iOS | `aplikasi/ios/` |
| Uji | `tests/hub.test.mjs` ("aplikasi siswa: …") |

## Tahap berikutnya
1. Uji di perangkat nyata (Android 8–15, iOS 15+), termasuk Wi-Fi kelas dan layar kecil.
2. Pemindai QR untuk alamat + kode (satu langkah).
3. Notifikasi "perangkat baru" ke guru, dan pembatasan satu perangkat per siswa bila diperlukan.
4. Penandatanganan rilis (keystore Android, Apple Developer) dan distribusi sekolah (Play Store privat / TestFlight / ABM).
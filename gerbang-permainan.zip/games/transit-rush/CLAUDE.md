# CLAUDE.md — Transit Rush mandiri (Jakarta Brain Map)

Baca `docs/PROGRESS.md`, lalu `docs/SPEC-asli.md` dan `docs/CLAUDE-asli.md` (paket spesifikasi asli; **bagian yang bertentangan digantikan** oleh catatan di bawah).

- Game mandiri di `games/transit-rush`, sejajar route-rush/claim80/glacia/logic-rush. Proyek npm sendiri (workspaces `shared`, `server`, `client`), bukan monorepo pnpm; tanpa better-sqlite3 (sesi disimpan JSONL seperti Logic Rush) agar tidak butuh kompilasi native.
- `shared/src/engine/*.ts` adalah port mekanis dari `shared/reference/*.cjs` (engine asli). **Jangan ubah perilakunya**; `parity.test.ts` membandingkan keluarannya dengan referensi dan `tr.test.ts` menjalankan 11.447 pemeriksaan asli.
- Server berwenang penuh: klien hanya menerima `publicItem`; muatan keluar tak boleh memuat `jawaban`/`penjelasan` sebelum dijawab (tes wajib).
- Peta digambar sendiri (SVG): geometri vektor lin/air/taman/batas diambil dari peta FDTJ 2026-08c (atas permintaan pemilik proyek) dengan `tools/pdf-*.mjs` ke `data/peta_gambar.json`, digambar ulang dengan gaya sendiri tanpa ilustrasi landmark; gambar rasternya TIDAK disalin atau ditampilkan. Peta asli dilindungi hak cipta (penggunaan komersial tanpa izin dilarang): jaga kredit FDTJ di kaki halaman dan `MapCredit`. Watermark `MapCredit` baca logo dari `assets/branding/` bila ada, selain itu teks. Hormati `posisi_perkiraan` dan `segmen_perlu_cek`.
- Rapor selalu menampilkan rentang ketidakpastian + label "norma sementara".
- Semua waktu lewat `Clock` yang disuntik. UI Bahasa Indonesia, tanpa suara peramban. Per milestone: tes hijau, `npm run lint` bersih, catatan di `docs/PROGRESS.md`.
- Dependensi dipasang di `C:\trnm` (jalur pendek) lalu `node_modules` ditautkan dengan junction, karena jalur panjang membuat postinstall esbuild gagal (pola sama dengan Logic Rush).

# CLAUDE.md — TRANSIT RUSH: Jakarta Brain Map

Kamu membangun game kognitif berbasis peta transportasi umum Jakarta: **memori, spasial, numerik, logika**, level 1 (Super Gampang) sampai 10 (EKSTRIM), dengan hasil berupa **profil ala psikometri** (Rasch + tes adaptif). Untuk anak SD (mode Rush) dan umum; mode Arena sampai 40 pemain dengan PIN.

## Baca dulu
1. `docs/SPEC.md` — rancang bangun lengkap.
2. `engine/tr-network.js` (graf, rute, arah, grid), `engine/tr-items.js` (16 jenis soal × 10 level), `engine/tr-irt.js` (EAP, CAT, skor, norma, kalibrasi). **Teruji: `node engine/tr.test.js` → 11.447 pemeriksaan.** Port ke TypeScript tanpa mengubah perilaku.
3. `data/jaringan_jakarta.json` — 335 halte, 25 lin, 44 transit. Dibangun oleh `tools/build_network.py` dari PDF peta. Hormati tanda `segmen_perlu_cek` dan `posisi_perkiraan`.
4. `config/transit-rush.config.json` — mode, level, watermark.

## Aturan
- Gambar peta sendiri (SVG) dari data. **Jangan menyalin/menampilkan gambar peta asli.**
- Watermark "Map by Transport for Jakarta" + logo Transport for Jakarta + logo JakLingko via komponen `MapCredit`. File logo **tidak disertakan**: baca dari `assets/branding/` bila ada (disediakan penyelenggara setelah izin), selain itu tampil teks.
- Server berwenang penuh: klien hanya menerima `publicItem`. Tulis tes yang membuktikannya.
- Rapor selalu menampilkan rentang ketidakpastian dan label "norma sementara" bila berlaku.
- Setiap milestone: tes hijau + catatan di `docs/PROGRESS.md`. Berhenti dan laporkan setelah setiap milestone (SPEC §9).

# TRANSIT RUSH — Jakarta Brain Map

### Spesifikasi Rancang Bangun untuk Claude Code · Draf 1 · November 2026

> Game kognitif berbasis peta transportasi umum Jakarta yang menggabungkan **memori, spasial, numerik, dan logika**. Untuk anak SD sebagai "rush kognitif", tetapi fleksibel untuk umum dari level **Super Gampang (1)** sampai **EKSTRIM (10)**. Hasilnya berupa **profil ala psikometri** (model Rasch + tes adaptif), tetapi tetap terasa seperti permainan.
> Mesin `engine/` **sudah diuji: 11.447 pemeriksaan lulus**, termasuk validasi psikometri dengan peserta simulasi.

---

## 0. Ringkasan

| Hal | Isi |
|---|---|
| Inti | Soal-soal kilat di atas peta jaringan Jakarta: hafal rute, tebak arah, hitung halte dan koin, cari rute terbaik, pecahkan "stasiun misteri" |
| Ranah kemampuan | **Memori · Spasial · Numerik · Logika** (4 jenis soal per ranah, 16 jenis total) |
| Kesulitan | **Level 1–10**: Super Gampang, Gampang, Mudah, Agak Mudah, Sedang, Menantang, Sulit, Sangat Sulit, Ahli, **EKSTRIM** |
| Pemain | Individu; mode kelas sampai **40 pemain dengan PIN**; juga untuk umum |
| Hasil | **Indeks Kognitif Peta (IKP)**, skor per ranah, persentil per kelompok usia, Level Penjelajah 1–10, tipe pemain, selang kepercayaan |
| Data | Jaringan Jakarta: **335 halte/stasiun, 25 lin** (14 koridor Transjakarta, MRT, LRT Jakarta, LRT Jabodebek, KRL, KA Bandara), 44 titik transit antarmoda |
| Watermark | **"Map by Transport for Jakarta" + logo Transport for Jakarta + logo JakLingko**, khusus game ini (§1.3) |

---

## 1. Data peta, atribusi, dan watermark

### 1.1 Sumber data
Data jaringan diambil dari **Peta Integrasi Transportasi Umum Jakarta 2026-08c** (FDTJ / Transport for Jakarta):
- **Urutan halte BRT** dari kode halte di peta (mis. 9-1 Pinang Ranti … 9-26 Pluit).
- **Urutan stasiun rel** dari legenda dan label peta.
- **Posisi** dari koordinat label di PDF peta. Posisi menentukan arah mata angin dan sel grid A–F × 1–8.

Alat `tools/build_network.py` membangun `data/jaringan_jakarta.json`. Dari 39 titik acuan di legenda peta, **32 masuk sel grid yang tepat dan 7 tepat di sel sebelahnya**; tidak ada yang meleset jauh.

### 1.2 Batasan data (wajib dicek manusia)
- Jaringan **disederhanakan untuk permainan**, bukan panduan perjalanan. Lin BRT yang berbentuk putaran atau berhenti satu arah dijadikan urutan sederhana.
- Kode yang tidak tercetak di peta (2-20, 3-13, 6-19) **tidak ditebak**. Segmennya ditandai `segmen_perlu_cek`.
- Lin yang tidak bisa dipastikan urutannya dari peta tidak dimasukkan: perpanjangan LRT Jakarta ke Manggarai, KRL Rangkasbitung setelah Serpong, dan lin rencana/pembangunan.
- 59 posisi halte adalah **perkiraan** (label miring di PDF tidak terbaca) dan ditandai `posisi_perkiraan`.
- Konsol operator menyediakan **editor jaringan** untuk memperbaiki data ini.

### 1.3 Watermark & hak cipta
- Game **menggambar peta skematiknya sendiri** dari data jaringan (SVG). Gambar peta asli **tidak disalin dan tidak ditampilkan**. Peta asli dilindungi UU No. 28/2014 tentang Hak Cipta dan melarang penggunaan komersial tanpa izin.
- Watermark khusus game ini tampil di **pojok kanan bawah** peta, layar hasil, rapor, dan proyektor: **"Map by Transport for Jakarta"** + **logo Transport for Jakarta** + **logo JakLingko**.
- Logo adalah merek milik pemiliknya. Paket ini **tidak menyertakan file logo**. Penyelenggara meletakkan file logo resmi di `assets/branding/` **setelah mendapat izin pemiliknya**. Selama file belum ada, watermark tampil sebagai teks saja.
- Teks atribusi data selalu tampil di halaman "Tentang": sumber peta, versi 2026-08c, dan catatan "disederhanakan untuk permainan".

![Peta skematik yang digambar game, dengan grid A–F × 1–8 dan area watermark](grafik/peta_skematik.png)

---

## 2. Ranah dan 16 jenis soal

| Ranah | Jenis soal | Cara main | Yang dilatih |
|---|---|---|---|
| **Memori** | Hafal Rute | Rute menyala di peta beberapa detik → susun ulang urutan halte | Memori urutan & rute |
| | Halte Hilang | Deret halte satu koridor, lalu satu halte hilang → pilih yang hilang | Memori kerja verbal |
| | Ingat Koridor | Hafal pasangan koridor ↔ halte ujung → jawab satu | Memori asosiasi |
| | Urutan Terbalik | Hafal deret halte → susun dari belakang | Manipulasi memori kerja |
| **Spasial** | Arah Mata Angin | B ada di sebelah mana dari A? (4 atau 8 arah; level 9–10 peta diputar 180°) | Orientasi |
| | Cari Kotak Peta | Halte X ada di kotak A1–F8 mana? (level 9–10 tanpa melihat peta) | Koordinat & peta mental |
| | Mana Paling Dekat | Halte mana yang paling dekat (garis lurus) ke X? | Estimasi jarak |
| | Peta Gelap | Ketuk letak halte di peta tanpa nama | Peta mental |
| **Numerik** | Hitung Halte | Berapa halte dari A ke B? (level 7+ memakai kode halte, mis. 9-4 → 9-21) | Berhitung & selisih |
| | Hitung Koin | Hitung ongkos dengan aturan **Koin Lingko** fiktif yang makin kompleks (batas maksimal, potongan, tambahan waktu) | Aritmetika bertahap |
| | Jam Tiba | Hitung jam tiba dari jumlah halte, waktu pindah, dan jadwal kedatangan kelipatan | Waktu & kelipatan |
| | Deret Kode | Lanjutkan pola kode halte (+1, +2, −3, …) | Pola bilangan |
| **Logika** | Rute Terbaik | Paling sedikit berapa kali pindah lin dari A ke B? | Perencanaan |
| | Stasiun Misteri | Petunjuk berlapis (lin, baris/kolom grid, arah dari landmark, moda) → tebak halte | Deduksi |
| | Ada Gangguan! | Halte X ditutup → berapa kali pindah lin sekarang? | Penalaran kontrafaktual |
| | Benar atau Salah | Pernyataan tunggal → DAN → ATAU/TIDAK → JIKA–MAKA → JIKA(… DAN …) MAKA TIDAK … | Logika proposisi |

Tarif dalam soal Hitung Koin sengaja **fiktif (Koin Lingko)** agar soal tidak keliru jika tarif sungguhan berubah.

### 2.1 Contoh soal dari mesin
- **Hitung Halte, level 1**: "Naik Koridor 8 dari Kedoya Panjang ke Damai. Berapa halte yang dilewati?" → 2
- **Deret Kode, level 10**: "13-1, 13-5, 13-9, ❓, 13-17, 13-21" → 13-13
- **Stasiun Misteri, level 10**: "Hanya dilewati satu lin. Letaknya di sebelah barat Manggarai. Ada di kolom peta 3. Bisa dinaiki dengan Transjakarta." → Pondok Pinang
- **Benar atau Salah, level 10**: "JIKA (Danau Sunter ada di kotak B6 DAN Kramat Jati ada di sebelah selatan Pasar Senen), MAKA TIDAK Tanjung Barat ada di kotak B5." → Benar
- **Hafal Rute, level 10**: rute 16 halte melewati 4 lin, tampil 5 detik, ada 5 halte pengecoh, peta tanpa nama

---

## 3. Level 1–10

| Level | Nama | Contoh perubahan |
|---|---|---|
| 1 | Super Gampang | Hafal 3 halte 10 detik; arah 4 mata angin yang jelas; hitung 1–2 halte; 2 pilihan |
| 2 | Gampang | 4 halte; 3 pilihan |
| 3 | Mudah | 5 halte; pengecoh pertama muncul |
| 4 | Agak Mudah | 8 arah mata angin; aturan koin bertambah |
| 5 | Sedang | Rute dengan 1 kali pindah; pilihan berdekatan di peta |
| 6 | Menantang | Gangguan pasti mengubah rute; 3 petunjuk misteri |
| 7 | Sulit | Hitung lewat kode halte; jadwal kedatangan kelipatan; label peta mulai hilang |
| 8 | Sangat Sulit | Peta tanpa nama; 3 kali pindah lin; logika JIKA–MAKA |
| 9 | Ahli | Peta diputar 180°; cari kotak tanpa peta; aturan waktu di soal koin |
| 10 | **EKSTRIM** | Hafal 20 halte melewati 4 lin dalam 5 detik; ketuk letak halte dengan toleransi 280 satuan peta; pernyataan logika bersarang; 6 petunjuk misteri |

Setiap jenis soal punya kesulitan awal (logit Rasch) **b = dasar + kemiringan × (level − 5,5)**. Hasilnya level 1 ≈ −3 dan level 10 ≈ +3,5. Nilai ini dikalibrasi ulang dari data nyata (§5.6).

---

## 4. Mode permainan

| Mode | Untuk | Cara kerja |
|---|---|---|
| **Rush Kognitif** (bawaan SD) | Anak SD, 8–10 menit | Selalu mulai **super gampang** lalu menyesuaikan kemampuan; timer per soal, streak, poin |
| **Tes Profil** | Rapor ala psikometri, ±15–20 menit | Tes adaptif sampai ketidakpastian per ranah cukup kecil (maks 12–15 soal per ranah) |
| **Arena Kelas** | 1–40 pemain, **PIN 6 digit** | Ronde serentak; jenis & level soal sama untuk semua, tetapi **setiap pemain mendapat soal berbeda** (seed per pemain); papan skor; profil tetap dihitung |
| **Latihan Bebas** | Siapa saja | Pilih jenis soal dan level 1–10 sendiri |
| **Tantangan EKSTRIM** | Umum / juara | Level 8–10 saja, timer ketat, papan rekor |

Parameter yang diatur guru/operator: mode, usia/kelompok, ranah dan jenis soal yang aktif, level minimum/maksimum, durasi, target ketidakpastian, jumlah soal maksimal, timer, serta tampil/tidaknya papan skor.

---

## 5. Psikometri

### 5.1 Model
**Rasch (1PL)**: peluang benar = 1 / (1 + e^−(θ − b)). θ = kemampuan pemain per ranah, b = kesulitan soal.

### 5.2 Estimasi
**EAP** (*expected a posteriori*) dengan kuadratur −6…6. Prior memakai norma kelompok usia; mode Rush memakai prior rendah agar selalu mulai mudah. Ketidakpastian = simpangan baku posterior (SEM).

### 5.3 Tes adaptif (CAT)
Setiap kali memilih soal berikutnya:
1. Pilih **ranah** yang soalnya paling sedikit atau ketidakpastiannya paling besar.
2. Pilih **jenis soal** yang paling jarang dipakai di ranah itu (keseimbangan isi).
3. Pilih **level** yang b-nya paling dekat dengan θ saat ini (paling informatif), dengan variasi acak ±1 level pada 35% soal agar soal tidak monoton dan tidak mudah ditebak.
4. **Berhenti** bila SEM ≤ target (bawaan 0,45) dan minimal 3 soal per ranah terpenuhi, atau bila mencapai maksimal soal.

![Jejak tes adaptif: level naik saat benar, turun saat salah](grafik/jejak_cat.png)

### 5.4 Skor dalam rapor

| Skor | Arti |
|---|---|
| **IKP — Indeks Kognitif Peta** | Kemampuan gabungan, skala standar 100 ± 15 terhadap kelompok usia |
| Skor per ranah | Memori, Spasial, Numerik, Logika (skala sama) |
| Persentil + **rentang 90%** | Posisi terhadap teman seusia, beserta ketidakpastiannya |
| Stanine | 1–9 |
| **Level Penjelajah** | 1–10, setara dengan level soal yang dikuasai sekitar 50% |
| **Tipe pemain** | Si Perekam Rute (memori), Si Kompas Hidup (spasial), Si Kalkulator Halte (numerik), Si Detektif Rute (logika), atau Penjelajah Serba Bisa. Diberikan hanya jika perbedaan antar-ranah **signifikan** (z > 1,96); jika tidak, pemain disebut seimbang |
| Rush | Soal benar per menit |
| Reliabilitas perkiraan | Seberapa konsisten hasilnya |

![Contoh rapor ranah (peserta simulasi)](grafik/rapor_contoh.png)

### 5.5 Norma
Kelompok usia: 7–8, 9–10, 11–12, 13–15, dan 16+ (umum). **Norma bawaan masih sementara** dan ditandai di rapor. Norma wajib diperbarui dari data nyata (minimal ±100 peserta per kelompok) dengan `tools/tr-calibrate.js`.

### 5.6 Kalibrasi soal
Setiap jawaban tersimpan dengan kunci `jenis + level`. Kalibrasi **JML Rasch** (`calibrate()`) memperkirakan ulang b setiap level dari data. Pada uji simulasi, kalibrasi dengan 400 peserta memulihkan kesulitan sejati dengan **r = 0,996**.

### 5.7 Validasi (peserta simulasi, 160 orang, kalibrasi awal sengaja meleset ±0,3)

| Uji | Hasil |
|---|---|
| Kemampuan sejati vs hasil tes — Memori | r = 0,92 (±13 soal) |
| — Spasial | r = 0,90 |
| — Numerik | r = 0,90 |
| — Logika | r = 0,93 |
| Reliabilitas empiris IKP | **0,94** |
| Rata-rata SEM per ranah | 0,54 |
| Kekuatan ranah nyata terdeteksi | 36 dari 40 |
| Salah cap pada profil seimbang | 1 dari 40 |
| Peserta sangat kuat (θ = 4,5) | mencapai soal level 10 |
| Peserta sangat lemah (θ = −4) | tetap di level 1–3 |
| Mode Rush | soal pertama selalu level ≤ 2 |

Anak sungguhan lebih bervariasi daripada peserta simulasi. Angka di atas membuktikan mesin **mampu** mengukur, tetapi validitas nyata baru diketahui setelah uji lapangan.

### 5.8 Etika
Rapor adalah **profil permainan**, bukan tes IQ, alat seleksi, atau diagnosis. Rapor selalu menampilkan rentang ketidakpastian dan label "norma sementara" bila berlaku. Data anak hanya untuk anak, orang tua, dan guru.

---

## 6. Tampilan

| Layar | Isi |
|---|---|
| **Pemain `/play`** | Peta SVG (pinch-zoom), kartu soal, timer, tombol jawab (pilihan / urutan seret / angka / jam / ketuk peta), streak, poin; watermark di peta |
| **Hasil anak** | Bintang, Level Penjelajah, tipe pemain, 2 kekuatan, 1 saran latihan; bahasa positif |
| **Rapor (PDF A4/A5)** | IKP, 4 ranah + persentil + rentang 90%, jejak tes adaptif, tipe, catatan norma; watermark & atribusi |
| **Dasbor guru** | Tabel kelas, sebaran IKP, kekuatan kelas per ranah, butir yang terlalu mudah/sulit, ekspor CSV |
| **Proyektor `/display`** | PIN/QR, ronde, papan skor top 10, statistik kelas positif; watermark |
| **Operator `/operator`** | Buat sesi & PIN, atur mode/level/ranah, editor jaringan, unggah logo, kalibrasi & norma |

Peta digambar oleh komponen `TransitMap`: lin sebagai polyline berwarna, halte sebagai titik, grid A–F × 1–8, dengan mode `label: false` (peta gelap), `putar: 180`, `sorot`, dan `rute`. Komponen `MapCredit` merender watermark dari `config.watermark`.

---

## 7. Arsitektur

| Lapisan | Pilihan |
|---|---|
| Monorepo | pnpm, TypeScript strict |
| `packages/tr-engine` | Port TS dari `engine/tr-network.js`, `tr-items.js`, `tr-irt.js` + seluruh tesnya (perilaku identik) |
| `apps/server` | Node 20, Fastify, Socket.IO, better-sqlite3; LAN atau online |
| `apps/web` | Vite + React + TypeScript, peta SVG |

**Server berwenang penuh**: soal dibangkitkan server (`generate`), dan klien hanya menerima `publicItem` (tanpa jawaban & penjelasan). Penilaian (`check`), estimasi kemampuan, dan pemilihan soal berikutnya terjadi di server. Pembuatan soal rute butuh ±60 ms (dengan cache). Soal untuk ronde Arena dibangkitkan lebih awal.

**Tabel**: `sessions` (pin, mode, config), `players`, `items_served` (id, jenis, level, b, seed, payload, kunci), `responses` (jawaban, benar, sebagian, detik), `ability_snapshots` (θ, SEM per ranah), `reports`, `calibration_runs`, `norms`, `network_versions`, `event_log` (berantai hash).

**Event**: `tr:join`, `tr:item` (publicItem), `tr:answer`, `tr:result` (benar + penjelasan), `tr:progress`, `tr:end` (rapor), `tr:race` (proyektor).

---

## 8. Anti-curang
- Kunci jawaban tidak pernah dikirim sebelum dijawab.
- Seed berbeda per pemain dan per soal: tidak ada dua pemain di arena yang mendapat soal identik.
- Timer dari server.
- Fase hafal ditutup oleh server; data hafal dihapus klien saat fase berganti.
- Bendera: keluar aplikasi > 1,5 detik, jawaban benar terlalu cepat pada level ≥ 8, dan pola sempurna beruntun.
- Bendera tidak menghukum otomatis.

---

## 9. Milestone (Claude Code)

| Kode | Pekerjaan | Selesai jika |
|---|---|---|
| M0 | Monorepo; port engine + tes | `tr.test` lulus di TS |
| M1 | `TransitMap` SVG + `MapCredit` watermark + editor jaringan | Peta sesuai `docs/grafik/peta_skematik.png`; logo dari `assets/branding/` |
| M2 | Server: sesi, PIN (≤ 40), pembangkitan & penilaian soal, CAT | Uji: payload tanpa kunci |
| M3 | Layar pemain: 6 tipe jawaban, fase hafal, timer, streak | Nyaman di HP 360 px |
| M4 | Mode Rush, Tes Profil, Latihan, EKSTRIM | Keempatnya bisa dimainkan |
| M5 | Arena Kelas + proyektor | 40 bot lancar |
| M6 | Rapor PDF + dasbor guru + ekspor | Sesuai §5.4 & §6 |
| M7 | Kalibrasi & norma (`tools/tr-calibrate.js`), anti-curang, event log | Kalibrasi dari data berjalan |

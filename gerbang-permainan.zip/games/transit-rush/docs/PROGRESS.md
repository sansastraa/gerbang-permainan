# Catatan kemajuan Transit Rush

Status: M0–M7 dikerjakan. Integrasi SIMPETERI (menu, halaman peluncur, katalog Multi Permainan, gerbang) selesai. Ringkasan jujur tentang yang belum diuji ada di bagian "Belum diuji".

## M1 — TransitMap + MapCredit + editor jaringan
- `shared/src/peta.ts`: model geometri murni dari data (oktilinear 0/45/90°, grid A–F × 1–8 dari `meta.kolom_x/baris_y`, ketuk/putar 180°). Tes `peta.test.ts`: 335 halte semuanya jatuh di sel grid yang tercatat (0 salah), 25 lin, `posisi_perkiraan` dan `segmen_perlu_cek` dipertahankan.
- `client/src/TransitMap.tsx`: SVG, zoom/geser (roda, seret, cubit), opsi `label/lin/grid/tampil/putar/sorot/rute` dari soal, mode peta gelap, penanda ketuk, mode editor. Halte perkiraan berlingkar putus-putus oranye, segmen perlu cek bergaris putus-putus.
- `MapCredit.tsx`: watermark "Map by Transport for Jakarta" + logo dari `assets/branding/` bila ada (saat ini tidak ada: teks saja, diuji), tampil di peta, hasil, rapor, proyektor, editor.
- Editor jaringan (tab di /host): pilih/seret halte, tandai sudah dicek, simpan ke `DATA_DIR/jaringan-perbaikan.json` (PUT /api/network dengan PIN guru, grid dihitung ulang, engine dibangun ulang untuk soal baru).
- Catatan: gambar peta asli tidak dipakai; kemiripan dengan `docs/grafik/peta_skematik.png` hanya secara pola (peta ini digambar dari data, bukan dicocokkan piksel).

## M2 — server: sesi, PIN, soal, CAT
- `server/src/session.ts` (wasit): PIN 6 angka (maks 40 pemain; ke-41 ditolak), roster SIMPETERI, soal per pemain dengan seed `sesi:pemain:no`, penilaian (`ITEMS.check`), `IRT.record/nextSpec`, poin dan streak, timer dari server (+1,5 dtk toleransi), jawaban ganda/usang ditolak, masuk ulang dengan token, bendera anti-curang (tidak menghukum), log kejadian berantai hash.
- `itemKlien` (daftar putih) + `memoKlien`; harness `server/src/harness.ts` melempar bila muatan keluar selain `tr:result` memuat `jawaban|penjelasan|solution|seed|fase|b`. Tes membuktikan untuk 16 jenis × level 1/6/10.
- Tambahan engine (satu-satunya): `nextSpec` menghormati `opts.ranah` (opsional). Perilaku bawaan tidak berubah (paritas lulus).
- HTTP/Socket.IO (`app.ts`): PIN guru (`x-host-token`), batas percobaan PIN per IP, CORS ke `ALLOWED_ORIGINS`, `BASE_PATH`, `summary.json`, `results.csv`, `statistik.json`, `rapor/:pid`, `jawaban.csv`, `log.jsonl`.

## M3 — layar pemain
`Play.tsx` + `Jawab.tsx`: enam tipe jawaban (pilihan, susun urutan, teks/kotak peta A–F×1–8, angka dengan numpad, jam, ketuk peta), fase hafal dengan hitung mundur, timer, jalur perjalanan (streak/kemajuan), hasil dan penjelasan. e2e di viewport 360 px: tanpa gulir horizontal.

## M4 — Rush, Tes Profil, Latihan, EKSTRIM
Keempatnya bisa dimainkan (tes `session.test.ts`): Rush mulai level ≤ 2 dan berhenti saat durasi habis; Profil berhenti saat SEM/maks tercapai (kuat > lemah, rentang 90% memuat estimasi); Latihan memvalidasi level/jenis; EKSTRIM hanya level 8–10 dan 12 soal; pilihan ranah oleh guru dihormati.

## M5 — Arena + proyektor
Arena: ronde serentak, jenis/level sama dan **seed berbeda per pemain**, papan skor, jeda 6 dtk atau "Ronde berikut" dari guru. `Display.tsx`: PIN/QR, ronde, top 10, statistik positif, watermark. `npm run sim -- arena 40`: 40 bot lewat socket nyata, 40 rapor akhir, 40 baris di summary.json (±12–30 dtk di laptop ini, termasuk jeda).

## M6 — rapor, dasbor, ekspor
Rapor (`Rapor.tsx`): IKP + selang 90%, 4 ranah dengan persentil + selang, stanine, level penjelajah, tipe pemain (hanya bila ≥ 2 ranah diuji), jejak adaptif, saran, label norma sementara, atribusi data. Cetak A4 lewat `window.print()` (simpan sebagai PDF dari dialog cetak peramban; **bukan** pembuat PDF di server). Hasil anak versi ramah. Dasbor guru: tabel kelas, histogram IKP, ketepatan per ranah, butir terlalu mudah/sulit, bendera, ekspor CSV dan summary.json.

## M7 — kalibrasi, anti-curang, log
`shared/src/kalibrasi.ts` (+ `tools/tr-calibrate.ts`, `npm run calibrate -- jawaban.csv`): JML Rasch dari CSV, norma per usia; `terapkanNorma` (n ≥ 30 per kelompok) dipakai server saat start dan mengubah label rapor (tetap "sementara" bila ada kelompok belum terkalibrasi). Tes memulihkan b dengan r > 0,97 dari data simulasi. Bendera: fokus hilang > 1,5 dtk, benar < 3 dtk di level ≥ 8, 15 benar beruntun. Log berantai hash terverifikasi (tes mendeteksi perubahan).

## Gambar ulang peta dari PDF FDTJ 2026-08c (permintaan pengguna)
- Peta sebelumnya keliru karena garis lin hanya menyambung halte secara lurus dan posisi halte berasal dari koordinat label. Sekarang geometri lin (kurva asli), air, taman, batas wilayah, lin rencana, dan penghubung antarmoda diambil dari operasi vektor PDF (`tools/pdf-*.mjs`, pdfjs-dist) dan digambar ulang (`GambarPeta.tsx`) dengan gaya sendiri; ilustrasi landmark dan teks asli tidak dipakai, hanya nama wilayah.
- Posisi halte: 269 dari 335 diselaraskan tepat ke penanda stasiun PDF (tes: jarak < 1,5 satuan), 66 tetap dari label (20 masih `posisi_perkiraan`, turun dari 61). Grid A–F × 1–8 dihitung ulang dari garis grid peta (42 halte pindah sel); semua tes engine (11.447 pemeriksaan + paritas) tetap lulus.
- Logo FDTJ diambil dari path vektor peta ke `assets/branding/fdtj.svg`, tampil di kaki halaman semua layar (`Footer.tsx`).
- Tidak dicocokkan: lin yang tidak ada di jaringan permainan (mis. 3F, 5C, 6A/6B, 9A/9C, 13B, KA Bandara) tetap tergambar di peta tetapi belum punya halte permainan; urutan halte tiap lin masih dari data kurasi lama (belum diverifikasi ulang terhadap PDF).
- Peta asli melarang penggunaan komersial tanpa izin (tercetak di peta): kredit FDTJ dipertahankan.

## Integrasi SIMPETERI
Menu "Transit Rush" di grup `clash-of-git` (`AdminLayout.tsx`), halaman `src/routes/_authenticated/transit-rush.tsx`, `src/lib/transit-rush.ts`, `routeTree.gen.ts` (diedit tangan mengikuti pola), katalog Multi Permainan (`KATALOG_GAME`, `GAME_DI_FOLDER`, `bacaRingkasanTransitRush`, `ukuranProfil`, placeholder alamat), gerbang (`gerbang.mjs`, port 3110), alias Vitest, skrip `tr:*`, `games/README.md`, `AGENTS.md`, `roadmap.md`. Tes: `src/test/transit-rush.test.ts` (sesi asli → summary.json → pembaca). Tes lama yang menghitung daftar game (`game-host`, `gerbang`, `multi-permainan-page`) disesuaikan dari 4 menjadi 5 game.

## Desain
Arah: papan informasi peron + tiket (kertas hangat, tinta, satu aksen kuning garis peron; sudut hampir tajam, bayangan keras tanpa blur, angka monospace, tanpa emoji, penanda kemajuan berbentuk halte belah ketupat). Font Product Sans (lisensi belum jelas, lihat `client/public/fonts/README.md`) + Plus Jakarta Sans.

## Hasil tes terakhir
Engine 11.447 pemeriksaan + paritas, peta, kalibrasi (shared: 11 tes), sesi/HTTP/socket (server: 23 tes), klien (6 tes), e2e Playwright Edge 4/4 (akar dan BASE_PATH), sim arena 40 bot dan rush 20 bot, `npm run lint` bersih, `typecheck` bersih; di akar SIMPETERI `tsc`, seluruh Vitest (106 tes) hijau.

## Belum diuji / keterbatasan jujur
- Tidak diuji dengan anak sungguhan, HP fisik, atau jaringan sekolah; norma masih sementara dan validitas nyata belum diketahui.
- Logo resmi tidak ada (perlu izin); `peta_skematik.png` tidak dicocokkan piksel.
- 61 halte `posisi_perkiraan` dan 3 segmen perlu cek belum diperiksa manusia; editor sudah tersedia.
- Docker tidak dicoba (Dockerfile ditulis menurut pola Logic Rush). Build dengan jalur folder panjang di Windows memerlukan junction (lihat CLAUDE.md).
- Rapor PDF memakai cetak peramban, bukan PDF dari server. Nilai b hasil kalibrasi tidak diterapkan otomatis (hanya norma).
- Tidak ada pembangkit soal terjadwal awal (pre-generate); arena 40 pemain membangkitkan soal serentak saat ronde mulai (dalam uji sim lancar).
- Uji kompatibilitas dengan Multi Permainan di peramban nyata (alur penuh peluncur → game → impor) belum dijalankan; yang diuji adalah kontrak (pesan roster, summary.json, pembaca) dan halaman Multi Permainan lewat Vitest.

---

## M0 — monorepo + port engine + tes (selesai)
- Kerangka `games/transit-rush` (npm workspaces `shared`/`server`/`client`, tsconfig/eslint/prettier seperti Logic Rush).
- Engine asli disalin utuh ke `shared/reference/*.cjs`; port ESM/TS di `shared/src/engine/*.ts` (konversi mekanis `require`→`import`, `module.exports`→`export`; berkas ber-`@ts-nocheck` karena JS padat; fasad bertipe di `shared/src/types.ts` + `index.ts`).
- Tes: `tr.test.ts` (seluruh 11.447 pemeriksaan engine asli, ±60 dtk) + `parity.test.ts` (soal identik JSON-per-JSON untuk 16 jenis × level 1/4/7/10 × 2 seed, `publicItem` tanpa kunci, EAP/norma identik). Hijau.
- Data: `data/jaringan_jakarta.json` (335 halte, 25 lin) dan `config/transit-rush.config.json` disalin tanpa ubahan.
- Belum: tipe ketat untuk engine (masih `any` di balik fasad), `tools/tr-calibrate.js` belum diport (M7).

## Perbaikan setelah uji pengguna (6 Nov)
- Lingkaran stasiun: peta kini menggambar penanda stasiun persis seperti peta FDTJ (cincin hitam untuk BRT, cakram berwarna lin untuk rel); halte permainan tidak lagi menggambar lingkaran sendiri, hanya cincin sorot merah. 13 stasiun MRT Lebak Bulus–Bundaran HI dipasangkan berurutan ke penanda merahnya (tes), 329 dari 335 halte tepat di penanda; 6 halte masih dari label.
- Mode disederhanakan: di depan hanya dua kartu (Rush sendiri-sendiri, Arena serentak); Tes Profil, Latihan, EKSTRIM, ranah, level, dan lainnya di "Pengaturan lanjutan". Ranah aktif berupa ubin interaktif berlencana lin; papan skor/sesi uji berupa saklar.
- Statistik perilaku bermain di rapor (waktu median, pakai waktu, kehabisan waktu, terburu-buru, teliti, tren ketepatan, level awal→akhir, jenis kuat/lemah, gaya bermain, catatan), di hasil anak (satu baris), di `summary.json` (`perilaku`) dan di statistik kelas operator.
- Peringkat langsung: murid (strip + lembar "Peringkat sementara"), operator (KPI langsung, peringkat animasi, daftar pemain), proyektor (lobi dengan tiket nama, soal ronde, jawaban masuk, papan peringkat top 10 beranimasi, tampilan statistik, podium + konfeti, pintasan 1/2/F, latar peta jalur diburamkan).
- Uji: engine test diberi jeda event-loop agar worker Vitest tidak timeout; e2e arena memeriksa proyektor, peringkat murid, dan konsol operator.

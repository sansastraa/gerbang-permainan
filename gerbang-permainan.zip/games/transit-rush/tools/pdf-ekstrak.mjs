﻿import fs from "node:fs";
const pdfjs = await import("file:///C:/trnm/node_modules/pdfjs-dist/legacy/build/pdf.mjs");
const data = new Uint8Array(fs.readFileSync("C:/Users/Administrator/Downloads/2026-08c-Peta-Integrasi-Jakarta-FDTJ-Web-3.pdf"));
const doc = await pdfjs.getDocument({ data, useSystemFonts: true, verbosity: 0 }).promise;
const page = await doc.getPage(1);
const H = page.view[3];
const ol = await page.getOperatorList();
const O = pdfjs.OPS;
const mul = (a, b) => [a[0]*b[0]+a[2]*b[1], a[1]*b[0]+a[3]*b[1], a[0]*b[2]+a[2]*b[3], a[1]*b[2]+a[3]*b[3], a[0]*b[4]+a[2]*b[5]+a[4], a[1]*b[4]+a[3]*b[5]+a[5]];
let ctm = [1,0,0,1,0,0], stack = [], fill = "#000000", stroke = "#000000", lw = 1, dash = [], cap = 0, join = 0;
const hex = (a) => "#" + a.map((v) => Math.round(v).toString(16).padStart(2, "0")).join("");
const items = [];
let curPath = null;
const f2 = (n) => Math.round(n * 10) / 10;
for (let i = 0; i < ol.fnArray.length; i++) {
  const fn = ol.fnArray[i], a = ol.argsArray[i];
  switch (fn) {
    case O.save: stack.push({ ctm: ctm.slice(), fill, stroke, lw, dash, cap, join }); break;
    case O.restore: { const s = stack.pop(); if (s) ({ ctm, fill, stroke, lw, dash, cap, join } = s); break; }
    case O.transform: ctm = mul(ctm, a); break;
    case O.setFillRGBColor: fill = a.length === 1 && typeof a[0] === "string" ? a[0] : typeof a[0] === "string" ? a[0] : hex(a); break;
    case O.setStrokeRGBColor: stroke = typeof a[0] === "string" ? a[0] : hex(a); break;
    case O.setLineWidth: lw = a[0]; break;
    case O.setDash: dash = a[0]; break;
    case O.setLineCap: cap = a[0]; break;
    case O.setLineJoin: join = a[0]; break;
    case O.constructPath: {
      const [op, p] = a; const pts = []; let d = "", j = 0, bb = [1e9,1e9,-1e9,-1e9];
      const T = (x, y) => { const X = ctm[0]*x+ctm[2]*y+ctm[4], Y = H - (ctm[1]*x+ctm[3]*y+ctm[5]); bb = [Math.min(bb[0],X),Math.min(bb[1],Y),Math.max(bb[2],X),Math.max(bb[3],Y)]; return f2(X) + " " + f2(Y); };
      const arr = Array.from(p[0] !== undefined ? Object.values(p[0] ?? {}) : []);
      const flat = Array.isArray(p) ? p : Array.from(a[1]);
      const src = Array.isArray(a[1]) ? (a[1][0] && typeof a[1][0] === "object" ? Object.values(a[1][0]) : a[1]) : [];
      let k = 0;
      while (k < src.length) {
        const c = src[k++];
        if (c === 0) { d += "M" + T(src[k], src[k+1]); k += 2; }
        else if (c === 1) { d += "L" + T(src[k], src[k+1]); k += 2; }
        else if (c === 2) { d += "C" + T(src[k], src[k+1]) + " " + T(src[k+2], src[k+3]) + " " + T(src[k+4], src[k+5]); k += 6; }
        else if (c === 3) { d += "Q" + T(src[k], src[k+1]) + " " + T(src[k+2], src[k+3]); k += 4; }
        else if (c === 4) { d += "Z"; }
        else break;
      }
      const sc = Math.sqrt(Math.abs(ctm[0]*ctm[3]-ctm[1]*ctm[2]));
      const paint = op;
      const it = { d, bb: bb.map(f2), w: f2(lw * sc), dash: dash.length ? dash : undefined, cap, join };
      if (paint === O.stroke || paint === O.closeStroke) items.push({ k: "s", c: stroke, ...it });
      else if (paint === O.fill || paint === O.eoFill) items.push({ k: "f", c: fill, ...it });
      else if (paint === O.fillStroke || paint === O.eoFillStroke || paint === O.closeFillStroke || paint === O.closeEOFillStroke) { items.push({ k: "f", c: fill, ...it }); items.push({ k: "s", c: stroke, ...it }); }
      break;
    }
  }
}
const tc = await page.getTextContent();
const text = tc.items.map((t) => ({ s: t.str, x: f2(t.transform[4]), y: f2(H - t.transform[5]), h: f2(Math.hypot(t.transform[2], t.transform[3])), r: f2(Math.atan2(t.transform[1], t.transform[0]) * 180 / Math.PI), w: f2(t.width) }));
fs.writeFileSync(process.argv[2], JSON.stringify({ H, items, text }));
const g = {};
for (const it of items) { const key = it.k + it.c + (it.k === "s" ? "@" + it.w : ""); g[key] = (g[key] ?? 0) + 1; }
console.log("items", items.length, "text", text.length);
console.log(Object.entries(g).sort((a, b) => b[1] - a[1]).slice(0, 60).map(([k, v]) => k + ":" + v).join("\n"));

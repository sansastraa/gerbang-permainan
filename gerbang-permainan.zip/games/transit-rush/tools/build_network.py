#!/usr/bin/env python3
"""Membangun data/jaringan_jakarta.json dari peta FDTJ 2026-08c.
Urutan halte/stasiun dikurasi dari kode di peta (BRT) dan legenda (rel); posisi diambil
dari koordinat label di PDF (pdftotext -bbox-layout). Jaringan DISEDERHANAKAN untuk permainan.
"""
import json, re, math, unicodedata

LINES_JSON = 'lines.json'
L = [l for l in json.load(open(LINES_JSON)) if l['x0'] < 8350 and l['y0'] > 450 and not (l['y0'] > 6300 and l['x0'] < 1500)]   # buang legenda, judul, catatan kaki

# ---------- Lin (urutan) ----------
# Format halte: "Nama" atau "Nama|kode1,kode2" (kode BRT dari peta). '~' di depan = sambungan belum pasti (perlu cek).
LIN = {
 'BRT': {
  '1': ('Blok M – Kota', '#C8102E', ['Blok M|1-1','ASEAN|1-2','Masjid Agung|1-3','Bundaran Senayan|1-4','Senayan Bank Jakarta|1-5','Polda Metro Jaya|1-6','Bendungan Hilir|1-7','Karet|1-8','Dukuh Atas/Galunggung|1-9,4-17,6-20','Tosari|1-10','Bundaran HI ASTRA|1-11','MH Thamrin|1-12','Kebon Sirih|1-13','Monumen Nasional|1-14,2-21','Harmoni|1-15','Sawah Besar|1-16','Mangga Besar|1-17','Taman Sari|1-18','Glodok|1-19','Kota|1-20,12-6','Kali Besar|1-21,12-23','Museum Sejarah Jakarta|1-22,12-5']),
  '2': ('Pulo Gadung – Monumen Nasional', '#2E3192', ['Pulo Gadung|2-1,4-1','Bermis|2-2','Pulo Mas|2-3','Perintis Kemerdekaan|2-4','Pedongkelan|2-5','Cempaka Mas|2-6','Sumur Batu|2-7','Cempaka Baru|2-8','Pasar Cempaka Putih|2-9','Rawa Selatan|2-10','Galur|2-11','Senen TOYOTA Rangga|2-12,14-1','Senen Raya|2-13,14-2','RSPAD|2-14','Pejambon|2-15','Gambir|2-16','Istiqlal|2-17','Juanda|2-18,3-15','Pecenongan|2-19,3-14','~Monumen Nasional|1-14,2-21','Balai Kota|2-22','Gambir 2|2-23','Kwitang|2-24']),
  '3': ('Kalideres – Monumen Nasional', '#F2C500', ['Kalideres|3-1','Pesakih|3-2','Sumur Bor|3-3','Rawa Buaya|3-4','Jembatan Baru|3-5','Pulo Nangka|3-6','Jembatan Gantung|3-7','Taman Kota|3-8','Damai|3-9,8-17','Jelambar|3-10,8-18','Grogol|3-11','Roxy|3-12','~Pecenongan|2-19,3-14','Juanda|2-18,3-15','Pasar Baru|3-16']),
  '4': ('Pulo Gadung – Galunggung', '#4B2C7F', ['Pulo Gadung|2-1,4-1','Pasar Pulo Gadung|4-2','Pemuda Merdeka|4-3','Layur|4-4','Pemuda Rawamangun|4-5','Velodrome|4-6','Kayu Jati|4-7','Rawamangun|4-8','Simpang Pramuka|4-9','Pramuka Sari|4-10','Utan Kayu|4-11','Pasar Genjing|4-12','Flyover Pramuka|4-13','Manggarai|4-14','Pasar Rumput|4-15','Halimun|4-16','Dukuh Atas/Galunggung|1-9,4-17,6-20']),
  '5': ('Ancol – Kampung Melayu', '#8B5A2B', ['Ancol|5-1','Pademangan|5-2','Gunung Sahari|5-3,12-9','Jembatan Merah|5-4,12-10','Pasar Baru Timur|5-5','Lapangan Banteng|5-6','Jaga Jakarta|5-7','Pal Putih|5-8','Kramat Sentiong|5-9','Salemba|5-10','Paseban|5-11','Matraman|5-12','Tegalan|5-13','Kesatrian|5-14','Matraman Baru|5-15','Bali Mester|5-16','Jatinegara|5-17,11-15','Kampung Melayu|5-18,7-14,11-16']),
  '6': ('Ragunan – Galunggung', '#2E8B57', ['Ragunan|6-1','Simpang Ragunan Ar-Raudhah|6-2','Jati Barat|6-3','Jati Padang|6-4','Pejaten|6-5','Buncit Indah|6-6','Warung Jati|6-7','Warung Buncit|6-8','Duren Tiga|6-9','Mampang Prapatan|6-10','Underpass Kuningan|6-11','Patra Kuningan|6-12','Kuningan|6-13','Rasuna Said|6-14','Karet Kuningan|6-15','Kuningan Madya|6-16','Setiabudi Integritas|6-17','Flyover Kuningan|6-18','~Dukuh Atas/Galunggung|1-9,4-17,6-20']),
  '7': ('Kampung Rambutan – Kampung Melayu', '#E7417A', ['Kampung Rambutan|7-1','Tanah Merdeka|7-2','Flyover Raya Bogor|7-3','Trikora|7-4','Pasar Induk|7-5','Kramat Jati|7-6','Cililitan|7-7','Cawang Cililitan|7-8,10-21','Cawang Sentral|7-9,9-3,10-20','Cawang|7-10,9-4','Cawang Baru|7-11','Gelanggang Remaja|7-12','Bidara Cina|7-13','Kampung Melayu|5-18,7-14,11-16']),
  '8': ('Lebak Bulus – Petojo', '#D6006F', ['Lebak Bulus|8-1','Pondok Pinang|8-2','Underpass Lebak Bulus|8-3','Pondok Indah|8-4','Tanah Kusir|8-5','Bungur|8-6','Kebayoran|8-7','Simprug|8-8','Permata Hijau|8-9','Arteri|8-10','Pos Pengumben|8-11','Kelapa Dua Sasak|8-12','Kebon Jeruk|8-13','Duri Kepa|8-14','Kedoya Panjang|8-15','Kedoya|8-16','Damai|3-9,8-17','Jelambar|3-10,8-18','Grogol Reformasi|8-19,9-20','Tanjung Duren|8-20,9-19','Tomang Raya|8-21','Tarakan|8-22','Petojo|8-23']),
  '9': ('Pinang Ranti – Pluit', '#3C9A3C', ['Pinang Ranti|9-1','Makasar|9-2','Cawang Sentral|7-9,9-3,10-20','Cawang|7-10,9-4','Ciliwung|9-5','Cikoko|9-6','Tebet Eco Park|9-7','Pancoran Tugu|9-8','Pancoran|9-9','Tegal Parang|9-10','Simpang Kuningan|9-11','Denpasar|9-12','Widya Chandra Telkomsel|9-13','Semanggi|9-14','Gerbang Pemuda|9-15','Petamburan|9-16','Kemanggisan|9-17','Kota Bambu|9-18','Tanjung Duren|8-20,9-19','Grogol Reformasi|8-19,9-20','Kali Grogol|9-21','Jembatan Besi|9-22','Jembatan Dua|9-23','Jembatan Tiga|9-24','Penjaringan|9-25,12-25','Pluit|9-26,12-1']),
  '10': ('Tanjung Priok – PGC', '#A61C3C', ['Tanjung Priok|10-1,12-22','Mambo|10-2,12-21','Koja|10-3,12-20','Walikota Jakarta Utara|10-4,12-19','Plumpang|10-5,12-18','Sunter Kelapa Gading|10-6,12-17','Kodamar|10-7','Simpang Cempaka|10-8','Cempaka Putih|10-9','Pulo Mas Bypass|10-10','Kayu Putih Rawasari|10-11','Pemuda Pramuka|10-12','Utan Kayu Rawamangun|10-13','Pisangan|10-14','Flyover Jatinegara|10-15,11-13','Pedati Prumpung|10-16','Kebon Nanas|10-17','Halim|10-18','Simpang Cawang|10-19','Cawang Sentral|7-9,9-3,10-20','Cawang Cililitan|7-8,10-21','PGC|10-22']),
  '11': ('Pulo Gebang – Kampung Melayu', '#00A3E0', ['Pulo Gebang|11-1','Walikota Jakarta Timur|11-2','Penggilingan|11-3','Flyover Pondok Kopi|11-4','Simpang Buaran|11-5','Buaran|11-6','Kampung Sumur|11-7','Klender|11-8','Stasiun Klender|11-9','Cipinang|11-10','Flyover Cipinang|11-11','Pasar Enjo|11-12','Flyover Jatinegara|10-15,11-13','Stasiun Jatinegara|11-14','Jatinegara|5-17,11-15','Kampung Melayu|5-18,7-14,11-16']),
  '12': ('Pluit – Tanjung Priok', '#6CC24A', ['Pluit|9-26,12-1','Pluit Selatan|12-2','Pakin|12-3','Gedong Panjang|12-4','Museum Sejarah Jakarta|1-22,12-5','Kota|1-20,12-6','Mangga Dua Raya|12-7','Mangga Dua|12-8','Gunung Sahari|5-3,12-9','Jembatan Merah|5-4,12-10','Landasan Pacu|12-11,14-6','Danau Agung|12-12,14-7','Danau Sunter|12-13,14-8','Sunter Utara|12-14','Sunter Karya|12-15','Sunter Boulevard Barat|12-16','Sunter Kelapa Gading|10-6,12-17','Plumpang|10-5,12-18','Walikota Jakarta Utara|10-4,12-19','Koja|10-3,12-20','Mambo|10-2,12-21','Tanjung Priok|10-1,12-22']),
  '12R': ('Lin 12 arah balik (Kota – Pluit)', '#6CC24A', ['Kota|1-20,12-6','Kali Besar|1-21,12-23','Bandengan|12-24','Penjaringan|9-25,12-25','Pluit|9-26,12-1']),
  '13': ('Tegal Mampang – CBD Ciledug', '#7B5EA7', ['Tegal Mampang|13-1','Rawa Barat|13-2','Pasar Santa|13-3','CSW|13-4','Mayestik|13-5','Velbak|13-6','Kebayoran Lama|13-7','Seskoal|13-8','Cipulir|13-9','Swadarma|13-10','JORR|13-11','Petukangan D\'MASIV|13-12','Puri Beta 2|13-13','Puri Beta 1|13-14','CBD Ciledug|13-15']),
  '14': ('Senen – Jakarta International Stadium', '#F28C28', ['Senen TOYOTA Rangga|2-12,14-1','Senen Raya|2-13,14-2','Tanah Tinggi|14-3','Kemayoran|14-4','JIEXPO Kemayoran|14-5','Landasan Pacu|12-11,14-6','Danau Agung|12-12,14-7','Danau Sunter|12-13,14-8','Jembatan Item|14-9','Jakarta International Stadium|14-10']),
 },
 'MRT': {
  'M': ('MRT Lin Utara–Selatan', '#E2001A', ['Lebak Bulus BSI','Fatmawati Indomaret','Cipete Raya TUKU','Haji Nawi','Blok A Visa','Blok M BCA','ASEAN Headquarters','Senayan Mastercard','Istora Mandiri','Bendungan Hilir MRT','Setiabudi Astra','Dukuh Atas BNI','Bundaran HI Bank Jakarta']),
 },
 'LRT': {
  'S': ('LRT Jakarta Lin Selatan', '#E97E1A', ['Kelapa Gading LRT','Boulevard Utara','Boulevard Selatan','Pulomas','Equestrian','Velodrome LRT']),
  'CB': ('LRT Jabodebek Lin Cibubur', '#00A19A', ['Dukuh Atas BSI','Setiabudi LRT','Rasuna Said LRT','Kuningan LRT','Pancoran LRT','Cikoko LRT','Ciliwung LRT','Cawang LRT','TMII','Kampung Rambutan LRT','Ciracas','Harjamukti']),
  'BK': ('LRT Jabodebek Lin Bekasi', '#00A19A', ['Cawang LRT','Halim LRT','Jati Bening Baru','Cikunir 1','Cikunir 2','Bekasi Barat','Jatimulya']),
 },
 'KRL': {
  'B': ('KRL Lin Bogor', '#D7282F', ['Jakarta Kota','Jayakarta','Mangga Besar KRL','Sawah Besar KRL','Juanda KRL','Gondangdia','Cikini','Manggarai KRL','Tebet KRL','Cawang KRL','Duren Kalibata','Pasar Minggu Baru','Pasar Minggu','Tanjung Barat','Lenteng Agung','Universitas Pancasila','Universitas Indonesia','Pondok Cina','Depok Baru','Depok','Citayam','Bojong Gede','Cilebut','Bogor']),
  'C': ('KRL Lin Lingkar Cikarang', '#0084C7', ['Cikarang','Metland Telagamurni','Cibitung','Tambun','Bekasi Timur','Bekasi','Kranji','Cakung','Klender Baru','Buaran KRL','Klender KRL','Jatinegara KRL','Pondok Jati','Kramat','Gang Sentiong','Pasar Senen','Kemayoran KRL','Rajawali','Kampung Bandan','Angke','Duri KRL','Tanah Abang','Sudirman KRL','Manggarai KRL','Matraman KRL','Jatinegara KRL']),
  'R': ('KRL Lin Rangkasbitung (s.d. Serpong)', '#5E8C31', ['Tanah Abang','Palmerah','Kebayoran KRL','Pondok Ranji','Jurangmangu','Sudimara','Rawa Buntu','Serpong']),
  'T': ('KRL Lin Tangerang', '#8E3B8E', ['Duri KRL','Grogol KRL','Pesing','Taman Kota KRL','Bojong Indah','Rawa Buaya KRL','Kalideres KRL','Poris','Batu Ceper','Tanah Tinggi KRL','Tangerang']),
  'TP': ('KRL Lin Tanjung Priok', '#E6007E', ['Jakarta Kota','Kampung Bandan','Ancol KRL','Tanjung Priok KRL']),
  'A': ('KA Bandara Soekarno-Hatta', '#003DA5', ['Bandara Soekarno-Hatta','Batu Ceper','Rawa Buaya KRL','Duri KRL','Sudirman Baru BNI City','Manggarai KRL']),
 },
}
# Label di PDF untuk stasiun rel yang namanya sama dengan halte BRT (sufiks ' KRL', ' LRT', ' MRT' hanya pembeda di data)
PDF_NAME = lambda s: re.sub(r' (KRL|LRT|MRT)$', '', s).replace('Lebak Bulus BSI', 'Lebak Bulus').replace('Kelapa Gading LRT', 'Kelapa Gading').replace('Bandara Soekarno-Hatta', 'Soekarno-Hatta Airport').replace('Dukuh Atas BSI', 'Dukuh Atas').replace('Bendungan Hilir MRT', 'Bendungan Hilir')

# ---------- Transit antar-moda (pindah dengan berjalan; nama simpul berbeda) ----------
TRANSFER = [
 ('Blok M', 'Blok M BCA'), ('ASEAN', 'ASEAN Headquarters'), ('Senayan Bank Jakarta', 'Senayan Mastercard'), ('Bendungan Hilir', 'Bendungan Hilir MRT'),
 ('Dukuh Atas/Galunggung', 'Dukuh Atas BNI'), ('Dukuh Atas BNI', 'Dukuh Atas BSI'), ('Dukuh Atas BNI', 'Sudirman KRL'), ('Sudirman KRL', 'Sudirman Baru BNI City'),
 ('Bundaran HI ASTRA', 'Bundaran HI Bank Jakarta'), ('Lebak Bulus', 'Lebak Bulus BSI'), ('Setiabudi Integritas', 'Setiabudi LRT'),
 ('Rasuna Said', 'Rasuna Said LRT'), ('Kuningan', 'Kuningan LRT'), ('Pancoran', 'Pancoran LRT'), ('Cikoko', 'Cikoko LRT'), ('Ciliwung', 'Ciliwung LRT'),
 ('Cawang', 'Cawang LRT'), ('Cawang', 'Cawang KRL'), ('Halim', 'Halim LRT'), ('Kampung Rambutan', 'Kampung Rambutan LRT'),
 ('Manggarai', 'Manggarai KRL'), ('Kota', 'Jakarta Kota'), ('Sawah Besar', 'Sawah Besar KRL'), ('Mangga Besar', 'Mangga Besar KRL'), ('Juanda', 'Juanda KRL'),
 ('Senen TOYOTA Rangga', 'Pasar Senen'), ('Kemayoran', 'Kemayoran KRL'), ('Tanjung Priok', 'Tanjung Priok KRL'), ('Ancol', 'Ancol KRL'),
 ('Grogol', 'Grogol KRL'), ('Rawa Buaya', 'Rawa Buaya KRL'), ('Kalideres', 'Kalideres KRL'), ('Taman Kota', 'Taman Kota KRL'), ('Kebayoran', 'Kebayoran KRL'),
 ('Stasiun Jatinegara', 'Jatinegara KRL'), ('Stasiun Klender', 'Klender KRL'), ('Buaran', 'Buaran KRL'), ('Matraman', 'Matraman KRL'),
 ('Tebet Eco Park', 'Tebet KRL'), ('CSW', 'ASEAN'), ('CSW', 'ASEAN Headquarters'), ('Velodrome', 'Velodrome LRT'), ('Pulo Mas', 'Pulomas'), ('Grogol', 'Grogol Reformasi'),
]

norm = lambda s: re.sub(r'[^a-z0-9]', '', unicodedata.normalize('NFKD', s.lower()))
# kata per kata dari PDF (posisi lebih tepat daripada baris)
WORDS = []
for m in re.finditer(r'<word xMin="([\d.]+)" yMin="([\d.]+)" xMax="([\d.]+)" yMax="([\d.]+)">([^<]*)</word>', open('bbox.html', encoding='utf-8').read()):
    x0, y0, x1, y1, t = float(m[1]), float(m[2]), float(m[3]), float(m[4]), m[5]
    if x0 < 8350 and y0 > 450 and (y1 - y0) < 100 and not (y0 > 6300 and x0 < 1500):   # buang legenda, judul, label wilayah (huruf besar)
        WORDS.append({'t': t, 'x': (x0 + x1) / 2, 'y': (y0 + y1) / 2, 'x0': x0, 'y0': y0, 'x1': x1})
CODE_POS = {}
for w in WORDS:   # kode bisa menempel di kata lain ("Kalideres3-2"): posisi diperkirakan dari letak karakter
    for m in re.finditer(r'(?<![\d-])(\d{1,2}-\d{1,2})(?![\d-])', w['t']):
        frac = (m.start() + len(m[1]) / 2) / max(1, len(w['t']))
        CODE_POS.setdefault(m[1], []).append((w['x0'] + frac * (w['x1'] - w['x0']), w['y']))
def code_neighbors(c):
    a, b = map(int, c.split('-')); return [p for k in (b - 1, b + 1, b - 2, b + 2) for p in CODE_POS.get(f'{a}-{k}', [])]
def cands(name, codes):
    out = []
    for c in codes:
        ps = CODE_POS.get(c, [])
        if len(ps) > 1:   # pilih kemunculan yang paling dekat dengan kode tetangga di koridor yang sama
            nb = code_neighbors(c)
            if nb: ps = sorted(ps, key=lambda p: min(math.hypot(p[0] - q[0], p[1] - q[1]) for q in nb))
        out += ps[:1]
    if out: return out, 'kode'
    toks = [norm(t) for t in PDF_NAME(name).split('/')[0].split() if norm(t)]
    for k, w in enumerate(WORDS):
        if norm(w['t']) != toks[0]: continue
        ok, last = True, w
        for t in toks[1:]:
            nxt = [v for v in WORDS if norm(v['t']) == t and -40 < v['x0'] - last['x1'] < 260 and abs(v['y'] - last['y']) < 40]
            nxt += [v for v in WORDS if norm(v['t']) == t and 0 < v['y0'] - last['y0'] < 140 and abs(v['x0'] - w['x0']) < 400]
            if not nxt: ok = False; break
            last = nxt[0]
        if ok: out.append((w['x'], w['y']))
    return out, 'nama'

stations, lines_out, codes_seen = {}, {}, {}
for mode, group in LIN.items():
    for lid, (label, color, seq) in group.items():
        ids, unsure = [], []
        for k, raw in enumerate(seq):
            u = raw.startswith('~'); raw = raw.lstrip('~')
            name, codes = (raw.split('|') + [''])[:2]
            codes = [c for c in codes.split(',') if c]
            st = stations.setdefault(name, {'id': name, 'nama': name, 'moda': set(), 'lin': set(), 'kode': set(), 'x': None, 'y': None})
            st['moda'].add(mode); st['lin'].add(lid); st['kode'].update(codes)
            ids.append(name)
            if u: unsure.append(k)
        lines_out[lid] = {'id': lid, 'moda': mode, 'nama': label, 'warna': color, 'halte': ids, 'segmen_perlu_cek': unsure}

# Posisi manual untuk label yang miring/terpisah di PDF (diperiksa dengan sel grid di legenda peta)
OVERRIDE = {'Bandara Soekarno-Hatta': (560, 2150), 'Tangerang': (250, 3150), 'Bogor': (4950, 6420), 'Dukuh Atas BSI': (3660, 3880), 'Kalideres': (700, 3060), 'Jatimulya': (7950, 4870)}
for nm, (x, y) in OVERRIDE.items():
    if nm in stations: stations[nm]['x'], stations[nm]['y'], stations[nm]['posisi_manual'] = x, y, True
# posisi: kandidat terdekat ke tetangga yang sudah diketahui (iteratif); tolak kandidat yang terlalu jauh
# dari tetangga (nama sama di tempat lain) atau yang sudah dipakai halte lain
used = [(st['x'], st['y']) for st in stations.values() if st['x'] is not None]
def taken(p): return any(math.hypot(p[0] - q[0], p[1] - q[1]) < 25 for q in used)
for _ in range(5):
    for lid, ln in lines_out.items():
        seq = ln['halte']
        for i, nm in enumerate(seq):
            st = stations[nm]
            if st['x'] is not None: continue
            cs, how = cands(nm, sorted(st['kode']))
            cs = [p for p in cs if not taken(p)]
            if not cs: continue
            ref = [stations[seq[j]] for j in (i - 1, i + 1, i - 2, i + 2) if 0 <= j < len(seq) and stations[seq[j]]['x'] is not None]
            if ref:
                dist = lambda p: min(math.hypot(p[0] - r['x'], p[1] - r['y']) for r in ref)
                best = min(cs, key=dist)
                if dist(best) > 1800 and how != 'kode': continue
            elif how == 'kode' or len(cs) == 1: best = cs[0]
            else: continue
            st['x'], st['y'] = round(best[0]), round(best[1]); used.append((st['x'], st['y']))
# sisa: interpolasi merata di antara dua halte yang posisinya diketahui
for _ in range(3):
    for ln in lines_out.values():
        seq = ln['halte']; known = [i for i, nm in enumerate(seq) if stations[nm]['x'] is not None]
        for a, b in zip(known, known[1:]):
            A, B = stations[seq[a]], stations[seq[b]]
            for k in range(a + 1, b):
                st = stations[seq[k]]
                if st['x'] is None:
                    f = (k - a) / (b - a); st['x'], st['y'], st['posisi_perkiraan'] = round(A['x'] + f * (B['x'] - A['x'])), round(A['y'] + f * (B['y'] - A['y'])), True
        if known:
            for k in range(0, known[0]):
                st = stations[seq[k]]
                if st['x'] is None: r = stations[seq[known[0]]]; st['x'], st['y'], st['posisi_perkiraan'] = r['x'] - 120 * (known[0] - k), r['y'], True
            for k in range(known[-1] + 1, len(seq)):
                st = stations[seq[k]]
                if st['x'] is None: r = stations[seq[known[-1]]]; st['x'], st['y'], st['posisi_perkiraan'] = r['x'] + 120 * (k - known[-1]), r['y'], True

# grid peta A–F × 1–8
COLX = [628, 1679, 2737, 3793, 4851, 5908, 6966, 8022]; ROWY = [1194, 2184, 3174, 4164, 5154, 6144]
def grid(x, y):
    c = min(range(8), key=lambda i: abs(x - COLX[i])); r = min(range(6), key=lambda i: abs(y - ROWY[i]))   # sel = pusat label grid ± setengah lebar sel
    return 'ABCDEF'[r] + str(c + 1)
for st in stations.values():
    if st['x'] is not None: st['grid'] = grid(st['x'], st['y'])
    st['moda'] = sorted(st['moda']); st['lin'] = sorted(st['lin'], key=lambda s: (len(s), s)); st['kode'] = sorted(st['kode'], key=lambda c: tuple(map(int, c.split('-'))))

missing = [s for s in stations.values() if s['x'] is None]
tr = [{'a': a, 'b': b} for a, b in TRANSFER if a in stations and b in stations]
bad = [(a, b) for a, b in TRANSFER if a not in stations or b not in stations]
out = {
 'meta': {'nama': 'Jaringan Jakarta (disederhanakan untuk permainan)', 'sumber': 'Peta Integrasi Transportasi Umum Jakarta 2026-08c (FDTJ / Transport for Jakarta). Data jaringan (nama, urutan, kode) diambil dari peta; gambar peta TIDAK disalin.',
          'peringatan': 'Bukan panduan perjalanan. Beberapa lin BRT berbentuk putaran/satu arah disederhanakan; segmen bertanda perlu dicek manusia.',
          'koordinat': 'Satuan titik PDF peta (9513 × 6727). Grid A–F × 1–8 mengikuti peta.', 'kolom_x': COLX, 'baris_y': ROWY},
 'lin': lines_out, 'halte': sorted(stations.values(), key=lambda s: s['nama']), 'transit': tr,
}
json.dump(out, open('jaringan_jakarta.json', 'w'), ensure_ascii=False, indent=1)
print('halte', len(stations), 'lin', len(lines_out), 'transit', len(tr), 'tanpa posisi', [s['nama'] for s in missing], 'transit tak dikenal', bad)
pk = [s['nama'] for s in stations.values() if s.get('posisi_perkiraan')]
print('posisi perkiraan', len(pk), pk[:40])

import fs from "node:fs";
const dump = JSON.parse(fs.readFileSync(process.argv[2], "utf8"));
const NETRAL = (c) => { const r = parseInt(c.slice(1,3),16), g = parseInt(c.slice(3,5),16), b = parseInt(c.slice(5,7),16); return Math.max(r,g,b) - Math.min(r,g,b) < 18; };
const COKLAT = new Set(["#431f09", "#43200a", "#431d08"]);
const out = [];
const FR = { x0: 76, y0: 770, x1: 8553, y1: 6719 };
const dalam = (bb) => bb[2] > FR.x0 && bb[0] < FR.x1 && bb[3] > FR.y0 && bb[1] < FR.y1 && bb[0] > FR.x0 - 400 && bb[2] < FR.x1 + 400;
for (const it of dump.items) {
  if (!dalam(it.bb)) continue;
  const w = it.bb[2] - it.bb[0], h = it.bb[3] - it.bb[1];
  if (it.k === "f") {
    if (it.c === "#f6f7f4" && w > 8000) out.push({ t: "a", c: it.c, d: it.d });
    else if (it.c === "#ffffff" && w > 6900 && h > 5000) out.push({ t: "a", c: it.c, d: it.d });
    else if (it.c === "#c2c2ca" && w > 7000) out.push({ t: "w", c: "#c2c2ca", d: it.d });
    else if ((it.c === "#c9e9a0" || it.c === "#f2fae6") && (w > 100 || h > 100)) out.push({ t: "p", c: it.c, d: it.d });
    continue;
  }
  if (it.c === "#ffffff" || COKLAT.has(it.c)) continue;
  if (it.c === "#b1aea6" || it.c === "#c8c8c1" || it.c === "#aeaea8" || it.c === "#afaea7" || it.c === "#807d7a" || it.c === "#7f7a75" || it.c === "#efefeb") {
    if (it.w >= 11) out.push({ t: "b", c: it.c, w: it.w, d: it.d, dash: it.dash });
    continue;
  }
  if (it.c === "#100d0f" || it.c === "#0c1020") { if (it.w >= 4) out.push({ t: "x", c: "#100d0f", w: it.w, d: it.d, cap: it.cap, join: it.join }); continue; }
  if (NETRAL(it.c)) continue;
  if (it.w >= 14) out.push({ t: it.dash ? "r" : "l", c: it.c, w: it.w, d: it.d, dash: it.dash, cap: it.cap, join: it.join });
  else if (it.w >= 3.5 && it.dash) out.push({ t: "r", c: it.c, w: it.w, d: it.d, dash: it.dash });
}
// penanda stasiun (lingkaran hitam kecil) dan teks nama wilayah
const penanda = [];
for (const it of dump.items) { if (it.k !== "f" || it.c !== "#100d0f") continue; const w = it.bb[2]-it.bb[0], h = it.bb[3]-it.bb[1]; if (w < 24 || w > 33 || Math.abs(w-h) > 3 || (it.d.match(/C/g)||[]).length < 3) continue; const x = Math.round((it.bb[0]+it.bb[2])/2), y = Math.round((it.bb[1]+it.bb[3])/2); if (x > FR.x0 && x < FR.x1 && y > FR.y0 && y < FR.y1) penanda.push([x, y]); }
const teks = dump.text.filter((t) => t.s.trim() && t.h >= 75 && t.h <= 100 && t.x > FR.x0 && t.x < FR.x1 && t.y > FR.y0 && t.y < FR.y1 && !/[()|]/.test(t.s) && !/^[A-Z ]+$/.test(t.s.trim())).map((t) => ({ s: t.s.trim(), x: Math.round(t.x), y: Math.round(t.y), h: Math.round(t.h), r: t.r }));
fs.writeFileSync(process.argv[3], JSON.stringify({ frame: FR, grid: { xs: [76,1201,2278,3366,4378,5390,6414,7495,8553], ys: [770,1693,2661,3642,4642,5592,6719] }, items: out, penanda, teks }));
const cnt = {}; for (const o of out) cnt[o.t] = (cnt[o.t] ?? 0) + 1;
console.log(JSON.stringify(cnt), "bytes", JSON.stringify(out).length);
// pratinjau SVG
const S = (o) => {
  if (["a","w","p"].includes(o.t)) return `<path d="${o.d}" fill="${o.t === "w" ? "#cfd8e2" : o.c}"/>`;
  const d = o.dash ? ` stroke-dasharray="${o.dash.join(" ")}"` : "";
  const op = o.t === "r" ? ' stroke-opacity=".45"' : "";
  return `<path d="${o.d}" fill="none" stroke="${o.c}" stroke-width="${o.w}" stroke-linecap="${["butt","round","square"][o.cap ?? 1] ?? "round"}" stroke-linejoin="round"${d}${op}/>`;
};
const order = ["a","w","p","b","r","l","x"];
const body = order.map((t) => out.filter((o) => o.t === t).map(S).join("")).join("");
fs.writeFileSync(process.argv[4], `<svg xmlns="http://www.w3.org/2000/svg" viewBox="${FR.x0} ${FR.y0} ${FR.x1-FR.x0} ${FR.y1-FR.y0}" width="1700">${body}</svg>`);

﻿import fs from "node:fs";
const [snap, lap, outNet, outGambar] = process.argv.slice(2);
const net = JSON.parse(fs.readFileSync(snap, "utf8"));
const g = JSON.parse(fs.readFileSync(lap, "utf8"));
const { xs, ys } = g.grid;
const idx = (v, a) => { for (let i = 0; i < a.length - 1; i++) if (v >= a[i] && v < a[i + 1]) return i; return v < a[0] ? 0 : a.length - 2; };
let pindah = 0;
for (const h of net.halte) {
  const gr = "ABCDEF"[idx(h.y, ys)] + (idx(h.x, xs) + 1);
  if (gr !== h.grid) pindah++;
  h.grid = gr;
  h.posisi_sumber = h._snap ? "penanda-peta" : "label";
  delete h._snap;
}
net.meta.grid_batas = g.grid;
net.meta.bingkai = g.frame;
net.meta.posisi = "Posisi halte diselaraskan ke penanda stasiun pada peta FDTJ 2026-08c bila cocok (posisi_sumber = penanda-peta); sisanya dari koordinat label (posisi_sumber = label, ikut ditandai posisi_perkiraan bila ragu).";
fs.writeFileSync(outNet, JSON.stringify(net));
fs.writeFileSync(outGambar, JSON.stringify(g));
console.log("grid berubah untuk", pindah, "halte; penanda-peta:", net.halte.filter((h) => h.posisi_sumber === "penanda-peta").length, "perkiraan:", net.halte.filter((h) => h.posisi_perkiraan).length);

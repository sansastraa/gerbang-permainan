import fs from 'node:fs';
const dump = JSON.parse(fs.readFileSync(process.argv[2], 'utf8'));
const net = JSON.parse(fs.readFileSync(process.argv[3], 'utf8'));
const FR = { x0: 76, y0: 770, x1: 8553, y1: 6719 };
const inFr = (x, y) => x > FR.x0 && x < FR.x1 && y > FR.y0 && y < FR.y1;
// penanda stasiun: lingkaran hitam terisi w~27-30
const marks = [];
for (const it of dump.items) { if (it.k !== 'f' || it.c !== '#100d0f') continue; const w = it.bb[2]-it.bb[0], h = it.bb[3]-it.bb[1]; if (w < 24 || w > 33 || Math.abs(w-h) > 3) continue; if ((it.d.match(/C/g)||[]).length < 3) continue; const x=(it.bb[0]+it.bb[2])/2, y=(it.bb[1]+it.bb[3])/2; if (inFr(x,y)) marks.push({x,y}); }
// penanda stasiun rel: lingkaran putih w~22-26 dengan cincin berwarna
const marks2 = [];
for (const it of dump.items) { if (it.k !== 'f' || it.c !== '#ffffff') continue; const w = it.bb[2]-it.bb[0], h = it.bb[3]-it.bb[1]; if (w < 20 || w > 27 || Math.abs(w-h) > 3 || (it.d.match(/C/g)||[]).length < 3) continue; const x=(it.bb[0]+it.bb[2])/2, y=(it.bb[1]+it.bb[3])/2; if (inFr(x,y) && !marks.some(m => Math.hypot(m.x-x,m.y-y) < 6)) marks2.push({x,y}); }
console.log('penanda', marks.length, 'penanda rel', marks2.length);
const texts = dump.text.filter(t => t.s.trim() && inFr(t.x, t.y) && t.h >= 25);
const rect = (t) => { const r = t.r*Math.PI/180, c = Math.cos(r), s = -Math.sin(r); return { c, s, w: t.w, h: t.h }; };
const dist = (m, t) => { // jarak titik m ke kotak teks (diputar), asal = pangkal-kiri-baseline
  const dx = m.x - t.x, dy = m.y - t.y; const r = rect(t);
  const u = dx*r.c + dy*(-r.s) * -1; // koordinat sepanjang teks
  const a = t.r*Math.PI/180; const ux = Math.cos(a), uy = -Math.sin(a); // arah teks di y-bawah
  const along = dx*ux + dy*uy, across = -dx*uy + dy*ux; // across positif = ke bawah teks
  const ca = Math.max(0, -along, along - t.w), cr = Math.max(0, across - 4, -t.h*0.9 - across);
  return Math.hypot(ca, cr);
};
const tok = (s) => s.split(/\s+/);
const kodeRe = /^\d{1,2}-\d{1,2}$/;
let cocok3 = 0, cocok2 = 0, geser2 = [], cocok = 0, geser = [], tak = [];
for (const h of net.halte) {
  const kand = [];
  for (const t of texts) {
    const ts = t.s.trim();
    const nama = h.nama.replace(/ (KRL|LRT|MRT)$/, '');
    const tk = tok(ts);
    if ((h.kode||[]).length && tk.some(x => (h.kode).includes(x))) kand.push(t);
    else if (ts === h.nama || ts === nama || ts.endsWith(' ' + nama) || ts.endsWith(' ' + h.nama)) kand.push(t);
  }
  let best = null, bd = 1e9;
  for (const t of kand) for (const m of marks) { const d = dist(m, t); if (d < bd) { bd = d; best = m; } }
  if (best && bd < 110) { const jar = Math.hypot(best.x-h.x, best.y-h.y); if (jar < 420) { geser.push(jar); h.x = Math.round(best.x); h.y = Math.round(best.y); h.posisi_perkiraan = false; h._snap = 1; cocok++; continue; } }
  // putaran kedua: penanda terdekat dari posisi lama (posisi lama berasal dari label)
  let b2 = null, d2 = 1e9; for (const m of marks) { const d = Math.hypot(m.x-h.x, m.y-h.y); if (d < d2) { d2 = d; b2 = m; } }
  if (b2 && d2 <= 220) { geser2.push(d2); h.x = Math.round(b2.x); h.y = Math.round(b2.y); if (d2 <= 120) h.posisi_perkiraan = false; h._snap = 2; cocok2++; continue; }
  let b3 = null, d3 = 1e9; for (const m of marks2) { const d = Math.hypot(m.x-h.x, m.y-h.y); if (d < d3) { d3 = d; b3 = m; } }
  if (b3 && d3 <= 140) { h.x = Math.round(b3.x); h.y = Math.round(b3.y); h._snap = 3; cocok3++; continue; }
  tak.push(h.nama + (h.posisi_perkiraan ? ' *':''));
}
geser.sort((a,b)=>a-b);
console.log('cocok', cocok, 'dari', net.halte.length, 'median geser', Math.round(geser[geser.length>>1]), 'p90', Math.round(geser[Math.floor(geser.length*.9)]));
console.log('putaran2', cocok2, 'putaran3 (rel)', cocok3);
console.log('tak cocok', tak.length, tak.slice(0,60).join(' | '));
fs.writeFileSync(process.argv[4], JSON.stringify(net));

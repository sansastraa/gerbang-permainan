// Kalibrasi ulang norma & kesulitan dari data jawaban nyata.
//   npm run calibrate -- jawaban.csv        (kolom: pemain,usia,jenis,level,benar)
// Keluaran: data/kalibrasi.json { b, norma }. Server menerapkan NORMA (kelompok usia n >= 30) saat dinyalakan;
// nilai b hanya dilaporkan untuk ditinjau (tidak menggantikan b bawaan engine).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { kalibrasiDariCsv } from "../shared/src/kalibrasi";

const berkas = process.argv[2];
if (!berkas) {
  console.error("Pemakaian: npm run calibrate -- jawaban.csv");
  process.exit(1);
}
const k = kalibrasiDariCsv(fs.readFileSync(berkas, "utf8"));
const out = path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "data", "kalibrasi.json");
fs.writeFileSync(out, JSON.stringify(k, null, 1));
console.log(`kalibrasi selesai: ${Object.keys(k.b).length} butir; ${Object.entries(k.norma).map(([g, n]) => `${g}: n=${n.n}`).join(", ")}`);

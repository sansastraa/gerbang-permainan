# Transit Rush — Jakarta Brain Map

Game kognitif di atas peta transportasi umum Jakarta: **memori, spasial, numerik, logika**, level 1 (Super Gampang) sampai 10 (EKSTRIM), dengan hasil berupa **profil ala psikometri** (model Rasch + tes adaptif) beserta rentang ketidakpastiannya. Bagian dari Clash of Git di SIMPETERI, tetapi berjalan sebagai server Node sendiri (Express + Socket.IO) yang juga menyajikan layar webnya.

## Menjalankan (dari akar repositori SIMPETERI)

```bash
npm run tr:install   # sekali
npm run tr:dev       # server (3110) + Vite (5200)
npm run tr:build && npm run tr:start   # produksi: satu proses di port 3110
```

Atau langsung di folder ini: `npm install`, `npm run dev`. Di Windows dengan jalur folder panjang, `postinstall` esbuild bisa gagal; pasang dependensi di folder berjalur pendek lalu tautkan `node_modules` dengan junction (cara yang dipakai Logic Rush; lihat `CLAUDE.md`).

| Alamat                | Untuk                                                                      |
| --------------------- | -------------------------------------------------------------------------- |
| `/`                   | murid: masuk dengan PIN 6 angka                                            |
| `/host` (`/operator`) | guru: buat sesi, QR/PIN, dasbor, rapor, ekspor, editor jaringan, kalibrasi |
| `/display?pin=<PIN>`  | proyektor: PIN/QR, ronde, papan skor 10 besar, statistik kelas             |

## Mode

Rush Kognitif (mulai super gampang, durasi menit), Tes Profil (adaptif sampai SEM kecil), Latihan Bebas (pilih jenis dan level), Tantangan EKSTRIM (level 8–10), Arena Kelas (ronde serentak, maks 40 pemain, **soal berbeda per pemain**, papan skor, profil tetap dihitung). 16 jenis soal × 10 level; enam tipe jawaban (pilihan, susun urutan, teks/kotak peta, angka, jam, ketuk peta).

## Server berwenang penuh

Soal dibangkitkan, dinilai, dan dipilih di server. Klien hanya menerima `ItemKlien` (daftar putih kolom: tanpa `jawaban`, `penjelasan`, `fase`, seed, `b`). Fase hafal dikirim terpisah (`tr:memo`) dan ditutup server sebelum soal terkirim; waktu per soal dari server (toleransi 1,5 dtk). Harness tes melempar bila satu muatan keluar (selain `tr:result` setelah dijawab) memuat kunci. Bendera anti-curang (fokus hilang > 1,5 dtk, benar terlalu cepat di level ≥ 8, 15 benar beruntun) hanya dicatat, tidak menghukum. Log kejadian berantai hash di `DATA_DIR/sessions/*.jsonl`.

## Integrasi SIMPETERI

- Halaman peluncur `/transit-rush` (menu Clash of Git) memilih kelas dan mengirim roster lewat `postMessage` (`transitrush:host-ready` / `transitrush:roster`, id = `siswa.id`, maks 40, origin diperiksa).
- `GET /api/sessions/:id/summary.json` (header `x-host-token` = PIN guru; `?includeTest=1` sebelum selesai) → `{ game: "transit-rush", versi: 1, siswa: [{ siswaId, nama, skor, soal, benar, ikp, ikpRentang90, levelPenjelajah, tipe, ranah, bendera, … }] }`, dibaca `bacaRingkasanTransitRush` di Multi Permainan. Tes kontrak: `src/test/transit-rush.test.ts` menjalankan sesi asli lalu membacanya.
- `ALLOWED_ORIGINS` membatasi CORS ke asal SIMPETERI.
- `BASE_PATH=/games/transit-rush` (gerbang satu pintu): `npm run build:base -w client` membangun klien dengan awalan itu; server dan socket.io ikut di bawah awalan. Port bawaan **3110** (3100 dipakai Route Rush uji).

## Peta, hak cipta, dan watermark

Peta digambar ulang dari peta resmi FDTJ 2026-08c: `tools/pdf-ekstrak.mjs` membaca operasi gambar vektor PDF, `pdf-bangun-peta.mjs` memilah lapisan (daratan, air, taman, batas wilayah, lin, lin rencana, penghubung, 328 penanda stasiun, nama wilayah) ke `data/peta_gambar.json`, dan `pdf-snap-halte.mjs` + `pdf-final.mjs` menyelaraskan posisi halte ke penanda stasiun peta (269 dari 335 halte cocok; sisanya memakai koordinat label dan sebagian masih ditandai perkiraan) serta menghitung ulang sel grid A–F × 1–8 dari garis grid peta. Logo FDTJ (vektor dari peta, `assets/branding/fdtj.svg`) tampil di kaki semua layar. Peta asli dilindungi UU No. 28/2014 dan penggunaan komersial tanpa izin dilarang.

Peta digambar sendiri (SVG, `TransitMap`) dari `data/jaringan_jakarta.json`; gambar peta asli tidak disalin atau ditampilkan. Watermark "Map by Transport for Jakarta" (`MapCredit`) tampil di peta, hasil, rapor, dan proyektor. Logo resmi Transport for Jakarta dan JakLingko dibaca dari `assets/branding/` (`transport-for-jakarta.svg`, `jaklingko.svg`) **hanya bila berkas itu ada** (perlu izin pemilik merek); selain itu tampil teks. Data berasal dari Peta Integrasi Transportasi Umum Jakarta 2026-08c (FDTJ / Transport for Jakarta), disederhanakan, bukan panduan perjalanan. Posisi halte berstatus `posisi_perkiraan` dan segmen `segmen_perlu_cek` digambar berbeda dan dapat diperbaiki di Editor jaringan (perbaikan disimpan di `DATA_DIR/jaringan-perbaikan.json`, berlaku untuk soal baru).

## Psikometri dan etika

Rapor selalu menampilkan selang 90% dan label **norma sementara**; ini profil permainan, bukan tes IQ atau alat seleksi. Norma diperbarui lewat `npm run calibrate -- jawaban.csv` (CSV dari tab Kalibrasi); server menerapkan norma untuk kelompok usia dengan n ≥ 30 saat dinyalakan ulang. Nilai kesulitan butir hasil kalibrasi hanya dilaporkan untuk ditinjau, tidak menggantikan b bawaan engine.

## Tes

`npm test` (engine 11.447 pemeriksaan + paritas dengan `shared/reference`, peta, kalibrasi, sesi, HTTP/Socket.IO, klien), `npm run typecheck`, `npm run lint`, `npm run sim -- arena 40` (40 bot lewat socket nyata), `npm run e2e` (Playwright dengan Edge sistem, dua server: akar dan BASE_PATH). Detail per milestone: `docs/PROGRESS.md`.

﻿import { defineConfig } from "@playwright/test";

// Dua server nyata: satu di akar (3115) dan satu di BASE_PATH=/games/transit-rush (3116, klien dibangun terpisah).
export default defineConfig({
  testDir: "e2e",
  use: { channel: "msedge", headless: true },
  timeout: 90000,
  workers: 1,
  webServer: [
    {
      command: "npx tsx ../server/src/main.ts",
      url: "http://localhost:3115/health",
      env: { PORT: "3115", HOST_PIN: "guru-e2e", DATA_DIR: "./test-results/data-akar" },
      reuseExistingServer: false,
      timeout: 60000,
    },
    {
      command: "npx tsx ../server/src/main.ts",
      url: "http://localhost:3116/games/transit-rush/health",
      env: {
        PORT: "3116",
        HOST_PIN: "guru-e2e",
        DATA_DIR: "./test-results/data-base",
        BASE_PATH: "/games/transit-rush",
        STATIC_DIR: "./dist-base",
      },
      reuseExistingServer: false,
      timeout: 60000,
    },
  ],
});

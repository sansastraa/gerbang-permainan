import { expect, test } from "@playwright/test";
import type { Page } from "@playwright/test";

const AKAR = "http://localhost:3115";
const BASE = "http://localhost:3116/games/transit-rush";

let shotSoal = false;
let shotHasil = false;
async function loginGuru(page: Page, origin: string): Promise<void> {
  await page.goto(`${origin}/host`);
  await page.getByLabel("PIN guru").fill("guru-e2e");
  await page.getByRole("button", { name: "Masuk" }).click();
  await expect(page.getByRole("heading", { name: "Buat sesi" })).toBeVisible();
}

async function jawabApaSaja(page: Page): Promise<void> {
  const kartu = page.getByTestId("kartu-soal");
  const hasilAda = page.getByTestId("hasil");
  await expect(kartu.or(hasilAda)).toBeVisible({ timeout: 40000 });
  // mesin lambat: waktu soal bisa habis lebih dulu, hasil (waktu habis) sudah tampil
  if (await hasilAda.isVisible()) return;
  if (!shotSoal) {
    shotSoal = true;
    await page.screenshot({ path: "test-results/soal.png" });
  }
  if (await page.getByTestId("layar-angka").count()) {
    await page.getByRole("button", { name: "1", exact: true }).click();
    await page.getByRole("button", { name: "Kirim jawaban" }).click();
  } else if (await page.getByTestId("jam").count()) {
    await page.getByRole("button", { name: "Kirim jam" }).click();
  } else if (await page.getByLabel("Jawaban", { exact: true }).count()) {
    await page.getByLabel("Jawaban", { exact: true }).fill("1-1");
    await page.getByRole("button", { name: "Kirim jawaban" }).click();
  } else if (await page.getByTestId("susun").count()) {
    await page.locator(".pilihan .opsi").first().click();
    await page.getByRole("button", { name: "Kirim urutan" }).click();
  } else {
    await page.locator(".pilihan .opsi").first().click();
  }
  await expect(page.getByTestId("hasil")).toBeVisible();
  if (!shotHasil) {
    shotHasil = true;
    await page.screenshot({ path: "test-results/hasil.png" });
  }
}

for (const [nama, origin] of [
  ["akar", AKAR],
  ["BASE_PATH /games/transit-rush", BASE],
] as const) {
  test(`alur penuh guru + murid (${nama}): sesi, soal, hasil, rapor dengan rentang, watermark, summary.json`, async ({
    browser,
  }) => {
    const guru = await (await browser.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
    await loginGuru(guru, origin);
    await guru.getByText("Pengaturan lanjutan").click();
    await guru.getByRole("radio", { name: "Tes Profil" }).click();
    for (const d of ["Memori", "Spasial", "Logika"]) await guru.locator(`.ranah-ubin.${d.toLowerCase()}`).click();
    await expect(guru.getByText("1 dari 4 ranah aktif")).toBeVisible();
    await guru.getByLabel("Maks soal per ranah").fill("6");
    await guru.getByRole("button", { name: /Buat sesi/ }).click();
    const pin = (await guru.getByTestId("pin").textContent())!.trim();
    expect(pin).toMatch(/^\d{6}$/);

    const murid = await (await browser.newContext({ viewport: { width: 360, height: 740 } })).newPage();
    await murid.goto(`${origin}/?pin=${pin}`);
    if (origin === AKAR) await murid.screenshot({ path: "test-results/masuk.png" });
    await murid.getByRole("button", { name: "Masuk" }).click();
    await murid.getByLabel("Namamu").fill("Rani");
    await murid.getByRole("button", { name: "Ikut bermain" }).click();
    await expect(murid.getByText("Menunggu guru memulai")).toBeVisible();
    if (origin === AKAR) await murid.screenshot({ path: "test-results/lobi.png" });
    await expect(guru.getByRole("button", { name: /Mulai \(1 pemain\)/ })).toBeVisible();
    await guru.getByRole("button", { name: /Mulai \(1 pemain\)/ }).click();

    for (let i = 0; i < 3; i++) {
      await jawabApaSaja(murid);
      // tanpa tombol lanjut manual pada soal ke-3 agar sesi berhenti di tengah
      await murid.getByRole("button", { name: "Lanjut" }).click();
    }
    // watermark tampil bersama peta/soal
    await expect(murid.getByTestId("map-credit").first()).toContainText("Map by Transport for Jakarta");
    // muat <=360px tanpa gulir horizontal
    expect(await murid.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(true);

    const akhiri = guru.getByRole("button", { name: "Akhiri sesi" });
    if (await akhiri.isVisible()) await akhiri.click();
    await expect(murid.getByTestId("hasil-anak")).toBeVisible();
    await expect(murid.getByTestId("hasil-anak")).toContainText("rentang 90%");
    await expect(murid.getByTestId("hasil-anak")).toContainText("Norma sementara");
    await expect(murid.getByTestId("perilaku-anak")).toContainText("Gaya mainmu");

    await expect(guru.getByText("Hasil kelas")).toBeVisible();
    await guru.getByRole("button", { name: "Rapor" }).first().click();
    await expect(guru.getByTestId("rapor-penuh")).toContainText("rentang 90%");
    await expect(guru.getByTestId("rapor-penuh")).toContainText("Norma sementara");
    await expect(guru.getByTestId("perilaku")).toContainText("Perilaku bermain");
    await expect(guru.getByTestId("perilaku-gaya")).not.toBeEmpty();
    await expect(guru.getByTestId("perilaku-kelas")).toBeVisible();
    await expect(guru.getByTestId("rapor-penuh").getByTestId("map-credit")).toContainText(
      "Map by Transport for Jakarta",
    );

    const sid = (await guru.evaluate(() => JSON.parse(sessionStorage.getItem("transitrush.host.sesi")!))).id as string;
    const r = await fetch(`${origin}/api/sessions/${sid}/summary.json`, { headers: { "x-host-token": "guru-e2e" } });
    const j = (await r.json()) as { game: string; versi: number; siswa: { nama: string; ikp: number | null }[] };
    expect(j.game).toBe("transit-rush");
    expect(j.siswa[0]!.nama).toBe("Rani");
    expect(j.siswa[0]!.ikp).not.toBeNull();
    await guru.screenshot({ path: `test-results/rapor-guru-${nama.startsWith("akar") ? "akar" : "base"}.png` });
  });
}

test("latihan: Peta Gelap (ketuk peta) dan proyektor menampilkan PIN + watermark", async ({ browser }) => {
  const guru = await (await browser.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
  await loginGuru(guru, AKAR);
  await guru.getByText("Pengaturan lanjutan").click();
  await guru.getByRole("radio", { name: "Latihan Bebas" }).click();
  await guru.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await guru.getByTestId("pin").textContent())!.trim();

  const proy = await (await browser.newContext({ viewport: { width: 1280, height: 720 } })).newPage();
  await proy.goto(`${AKAR}/display?pin=${pin}`);
  await expect(proy.getByTestId("pin-display")).toHaveText(pin);
  await expect(proy.getByTestId("map-credit")).toContainText("Map by Transport for Jakarta");
  await proy.screenshot({ path: "test-results/proyektor.png" });

  const murid = await (await browser.newContext({ viewport: { width: 360, height: 740 } })).newPage();
  await murid.goto(`${AKAR}/?pin=${pin}`);
  await murid.getByRole("button", { name: "Masuk" }).click();
  await murid.getByLabel("Namamu").fill("Budi");
  await murid.getByRole("button", { name: "Ikut bermain" }).click();
  await guru.getByRole("button", { name: /Mulai \(1 pemain\)/ }).click();
  await expect(murid.getByTestId("pilih-latihan")).toBeVisible();
  await murid.getByRole("button", { name: "Peta Gelap" }).click();
  const peta = murid.locator(".peta svg").first();
  await expect(peta).toBeVisible();
  const box = (await peta.boundingBox())!;
  await murid.mouse.click(box.x + box.width / 2, box.y + box.height / 2);
  await murid.getByRole("button", { name: "Kunci jawaban" }).click();
  await expect(murid.getByTestId("hasil")).toBeVisible();
  await murid.screenshot({ path: "test-results/latihan-peta-gelap.png" });
});

test("editor jaringan: PIN guru dibutuhkan, halte perkiraan terdaftar, simpan perbaikan", async ({ browser }) => {
  const guru = await (await browser.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
  await loginGuru(guru, AKAR);
  await guru.getByRole("tab", { name: "Editor jaringan" }).click();
  await expect(guru.getByText(/halte masih posisi perkiraan/)).toBeVisible();
  await expect(guru.getByTestId("map-credit").first()).toContainText("Map by Transport for Jakarta");
  await expect(guru.getByTestId("footer-fdtj")).toBeVisible();
  await guru.screenshot({ path: "test-results/editor-jaringan.png", fullPage: true });
});

test("soal berpeta: halte yang disorot tampil di atas gambar ulang peta, footer FDTJ ada di bawah", async ({
  browser,
}) => {
  const guru = await (await browser.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
  await loginGuru(guru, AKAR);
  await guru.getByText("Pengaturan lanjutan").click();
  await guru.getByRole("radio", { name: "Latihan Bebas" }).click();
  await guru.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await guru.getByTestId("pin").textContent())!.trim();
  const murid = await (await browser.newContext({ viewport: { width: 390, height: 900 } })).newPage();
  await murid.goto(`${AKAR}/?pin=${pin}`);
  await murid.getByRole("button", { name: "Masuk" }).click();
  await murid.getByLabel("Namamu").fill("Sari");
  await murid.getByRole("button", { name: "Ikut bermain" }).click();
  await guru.getByRole("button", { name: /Mulai \(1 pemain\)/ }).click();
  await murid.getByRole("button", { name: "Mana Paling Dekat" }).click();
  await expect(murid.getByTestId("kartu-soal")).toBeVisible();
  const peta = murid.locator(".peta").first();
  await expect(peta.locator(".peta-sorot").first()).toBeVisible();
  expect(await peta.locator("svg path").count()).toBeGreaterThan(100);
  await expect(murid.getByTestId("footer-fdtj")).toContainText("FDTJ");
  await expect(murid.getByTestId("footer-fdtj").locator("img")).toBeVisible();
  await murid.screenshot({ path: "test-results/soal-peta.png", fullPage: true });
});

test("buat sesi disederhanakan: hanya dua cara main di depan, mode lain di pengaturan lanjutan", async ({
  browser,
}) => {
  const guru = await (await browser.newContext({ viewport: { width: 1200, height: 900 } })).newPage();
  await loginGuru(guru, AKAR);
  await expect(guru.getByRole("radio", { name: /Rush Kognitif/ })).toBeVisible();
  await expect(guru.getByRole("radio", { name: /Arena Kelas/ })).toBeVisible();
  await expect(guru.getByRole("radio", { name: "Tes Profil" })).toBeHidden();
  await expect(guru.getByRole("radio", { name: "Latihan Bebas" })).toBeHidden();
  await guru.getByText("Pengaturan lanjutan").click();
  await expect(guru.getByRole("radio", { name: "Tantangan EKSTRIM" })).toBeVisible();
  await guru.screenshot({ path: "test-results/buat-sesi.png" });
});

test("arena: proyektor hidup (tiket nama, peringkat, podium), peringkat sementara di murid dan konsol operator", async ({
  browser,
}) => {
  const guru = await (await browser.newContext({ viewport: { width: 1280, height: 1000 } })).newPage();
  await loginGuru(guru, AKAR);
  await guru.getByRole("radio", { name: /Arena Kelas/ }).click();
  await guru.getByText("Pengaturan lanjutan").click();
  await guru.getByLabel("Jumlah ronde").fill("3");
  await guru.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await guru.getByTestId("pin").textContent())!.trim();

  const proy = await (await browser.newContext({ viewport: { width: 1600, height: 900 } })).newPage();
  await proy.goto(`${AKAR}/display?pin=${pin}`);
  await expect(proy.getByTestId("pin-display")).toHaveAttribute("aria-label", pin);

  const gabung = async (nama: string) => {
    const m = await (await browser.newContext({ viewport: { width: 390, height: 860 } })).newPage();
    await m.goto(`${AKAR}/?pin=${pin}`);
    await m.getByRole("button", { name: "Masuk" }).click();
    await m.getByLabel("Namamu").fill(nama);
    await m.getByRole("button", { name: "Ikut bermain" }).click();
    return m;
  };
  const ani = await gabung("Ani");
  const budi = await gabung("Budi");
  await expect(proy.locator(".tiket-nama", { hasText: "Ani" })).toBeVisible();
  await expect(proy.locator(".tiket-nama", { hasText: "Budi" })).toBeVisible();
  await proy.waitForTimeout(1200);
  await proy.screenshot({ path: "test-results/proyektor-lobi.png" });

  await guru.getByRole("button", { name: /Mulai \(2 pemain\)/ }).click();
  await jawabApaSaja(ani);
  await expect(ani.getByTestId("peringkat-btn")).toBeVisible();
  await ani.getByTestId("peringkat-btn").click();
  await expect(ani.getByTestId("sheet-peringkat")).toContainText("Peringkat sementara");
  await ani.waitForTimeout(900);
  await ani.screenshot({ path: "test-results/murid-peringkat.png" });
  await ani.getByRole("button", { name: "Tutup" }).click();
  await jawabApaSaja(budi);

  await expect(proy.getByTestId("per-1")).toBeVisible();
  await expect(proy.getByText(/Ronde 1 dari 3/)).toBeVisible();
  await proy.waitForTimeout(1000);
  await proy.screenshot({ path: "test-results/proyektor-main.png" });
  await proy.keyboard.press("2");
  await expect(proy.getByText("Ketepatan kelas")).toBeVisible();
  await proy.keyboard.press("1");

  await expect(guru.getByTestId("kpi-langsung")).toContainText("Soal terjawab");
  await expect(guru.getByTestId("peringkat")).toBeVisible();
  await guru.screenshot({ path: "test-results/operator-live.png", fullPage: true });

  await guru.getByRole("button", { name: "Akhiri sesi" }).click();
  await expect(proy.getByTestId("podium")).toBeVisible();
  await proy.waitForTimeout(1600);
  await proy.screenshot({ path: "test-results/proyektor-podium.png" });
});

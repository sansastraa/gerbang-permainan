# Font lokal

- `PlusJakartaSans-Variable.ttf` (OFL, lihat `OFL-PlusJakartaSans.txt`) dan `ProductSans-*.ttf` disalin dari `games/route-rush/client/public/fonts`.
- **Lisensi Product Sans belum jelas** (font milik Google, tidak dirilis terbuka). Sebelum dipakai di luar kelas sendiri, pastikan haknya atau ganti ke Plus Jakarta Sans saja (cukup hapus tiga baris `@font-face` ProductSans di `src/styles.css`).

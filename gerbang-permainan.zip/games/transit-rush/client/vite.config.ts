import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

const basePath = (() => {
  let s = (process.env.BASE_PATH ?? "").trim();
  if (!s || s === "/") return "/";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "") + "/";
})();

export default defineConfig({
  base: basePath,
  plugins: [react()],
  server: {
    port: 5200,
    proxy: {
      "/socket.io": { target: "http://localhost:3110", ws: true },
      "/api": "http://localhost:3110",
      "/health": "http://localhost:3110",
    },
  },
  build: { outDir: process.env.BUILD_OUT ?? "dist", sourcemap: false },
  test: { environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"] },
});

// Watermark wajib: "Map by Transport for Jakarta" + logo Transport for Jakarta + logo JakLingko.
// Logo hanya tampil bila berkasnya ada di assets/branding (disediakan penyelenggara setelah izin); selain itu teks.
import type { ReactElement } from "react";
import { ambilKonfig, useAsync } from "./net";

export function MapCredit({
  tema = "terang",
  atribusi = false,
  statis = false,
}: {
  tema?: "terang" | "gelap";
  atribusi?: boolean;
  statis?: boolean;
}): ReactElement {
  const { data } = useAsync(ambilKonfig, []);
  const w = data?.watermark;
  return (
    <div
      className={`kredit kredit-${tema}${statis ? " kredit-statis" : ""}`}
      style={{ opacity: w?.opasitas ?? 0.9 }}
      data-testid="map-credit"
    >
      {w?.logo.map((l) => (
        <img key={l.nama} src={l.url} alt={l.nama} className="kredit-logo" />
      ))}
      <span className="kredit-teks">{w?.teks ?? "Map by Transport for Jakarta"}</span>
      {atribusi && w ? <span className="kredit-atribusi">{w.atribusi}</span> : null}
    </div>
  );
}

// Peta skematik buatan sendiri dari data jaringan (SVG). Bukan gambar peta asli. Zoom/geser: roda, seret, cubit.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent as RPointerEvent, ReactElement } from "react";
import { kePeta, warnaTeks } from "@transit-rush/shared";
import type { PetaModel, PetaOpsi } from "@transit-rush/shared";
import { GambarPeta } from "./GambarPeta";
import { MapCredit } from "./MapCredit";

export interface Tanda {
  x: number;
  y: number;
  r?: number;
  warna?: string;
}
interface Props {
  model: PetaModel;
  opsi?: PetaOpsi | null;
  tinggi?: number | string;
  onTap?: (x: number, y: number) => void;
  tanda?: Tanda[];
  editor?: {
    terpilih: string | null;
    onPilih: (nama: string) => void;
    onGeser: (nama: string, x: number, y: number) => void;
  };
  kredit?: boolean;
  /** sorot lin tertentu (id) agar lin lain memudar */
  fokusLin?: string[];
}
interface View {
  x: number;
  y: number;
  w: number;
  h: number;
}

const BATAS_TAP_PX = 6;

export function TransitMap({
  model,
  opsi,
  tinggi = 320,
  onTap,
  tanda,
  editor,
  kredit = true,
  fokusLin,
}: Props): ReactElement {
  const o: PetaOpsi = opsi ?? {};
  const gelap = o.lin === false;
  const putar = o.putar ?? 0;
  const awal = model.view;
  const [view, setView] = useState<View>(awal);
  const wrap = useRef<HTMLDivElement>(null);
  const svg = useRef<SVGSVGElement>(null);
  const [lebarPx, setLebarPx] = useState(360);
  const ptrs = useRef(new Map<number, { x: number; y: number }>());
  const gerak = useRef<{ x0: number; y0: number; maks: number; geser?: string } | null>(null);
  const cubit = useRef<{ jarak: number; w: number } | null>(null);

  useEffect(() => setView(model.view), [model]);
  useEffect(() => {
    const el = wrap.current;
    if (!el) return;
    const ro = new ResizeObserver(() => setLebarPx(el.clientWidth || 360));
    ro.observe(el);
    setLebarPx(el.clientWidth || 360);
    return () => ro.disconnect();
  }, []);

  const upp = view.w / lebarPx; // unit peta per piksel layar
  const zoom = awal.w / view.w;

  const keTitik = useCallback(
    (cx: number, cy: number): [number, number] => {
      const s = svg.current;
      if (!s) return [0, 0];
      const m = s.getScreenCTM();
      if (!m) return [0, 0];
      const p = s.createSVGPoint();
      p.x = cx;
      p.y = cy;
      const q = p.matrixTransform(m.inverse());
      return kePeta(model, q.x, q.y, putar);
    },
    [model, putar],
  );

  const batasi = useCallback(
    (v: View): View => {
      const w = Math.min(awal.w * 1.2, Math.max(awal.w / 12, v.w));
      const h = w * (awal.h / awal.w);
      return {
        w,
        h,
        x: Math.max(awal.x - w * 0.2, Math.min(awal.x + awal.w - w * 0.8, v.x)),
        y: Math.max(awal.y - h * 0.2, Math.min(awal.y + awal.h - h * 0.8, v.y)),
      };
    },
    [awal],
  );
  const zoomKe = useCallback(
    (faktor: number, cx?: number, cy?: number) =>
      setView((v) => {
        const w = v.w * faktor;
        const px = cx ?? v.x + v.w / 2;
        const py = cy ?? v.y + v.h / 2;
        const rx = (px - v.x) / v.w;
        const ry = (py - v.y) / v.h;
        const h = w * (awal.h / awal.w);
        return batasi({ x: px - rx * w, y: py - ry * h, w, h });
      }),
    [awal, batasi],
  );

  const titikSvg = (e: { clientX: number; clientY: number }): [number, number] => {
    const s = svg.current!;
    const p = s.createSVGPoint();
    p.x = e.clientX;
    p.y = e.clientY;
    const q = p.matrixTransform(s.getScreenCTM()!.inverse());
    return [q.x, q.y];
  };

  const onDown = (e: RPointerEvent<SVGSVGElement>): void => {
    (e.currentTarget as Element).setPointerCapture?.(e.pointerId);
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.current.size === 2) {
      const [a, b] = [...ptrs.current.values()];
      cubit.current = { jarak: Math.hypot(a!.x - b!.x, a!.y - b!.y), w: view.w };
      gerak.current = null;
    } else {
      const el = (e.target as Element).closest("[data-halte]");
      gerak.current = {
        x0: e.clientX,
        y0: e.clientY,
        maks: 0,
        geser: editor && el ? (el.getAttribute("data-halte") ?? undefined) : undefined,
      };
    }
  };
  const onMove = (e: RPointerEvent<SVGSVGElement>): void => {
    const prev = ptrs.current.get(e.pointerId);
    if (!prev) return;
    ptrs.current.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (ptrs.current.size === 2 && cubit.current) {
      const [a, b] = [...ptrs.current.values()];
      const j = Math.hypot(a!.x - b!.x, a!.y - b!.y);
      if (j > 0) {
        const w = cubit.current.w * (cubit.current.jarak / j);
        const [cx, cy] = titikSvg({ clientX: (a!.x + b!.x) / 2, clientY: (a!.y + b!.y) / 2 });
        setView((v) => {
          const h = w * (awal.h / awal.w);
          const rx = (cx - v.x) / v.w;
          const ry = (cy - v.y) / v.h;
          return batasi({ x: cx - rx * w, y: cy - ry * h, w, h });
        });
      }
      return;
    }
    const g = gerak.current;
    if (!g) return;
    g.maks = Math.max(g.maks, Math.hypot(e.clientX - g.x0, e.clientY - g.y0));
    if (g.geser && editor && g.maks > BATAS_TAP_PX) {
      const [x, y] = keTitik(e.clientX, e.clientY);
      editor.onGeser(g.geser, Math.round(x), Math.round(y));
      return;
    }
    if (g.maks <= BATAS_TAP_PX) return;
    const dx = (e.clientX - prev.x) * upp;
    const dy = (e.clientY - prev.y) * upp;
    setView((v) => batasi({ ...v, x: v.x - dx, y: v.y - dy }));
  };
  const onUp = (e: RPointerEvent<SVGSVGElement>): void => {
    ptrs.current.delete(e.pointerId);
    if (ptrs.current.size < 2) cubit.current = null;
    const g = gerak.current;
    if (g && g.maks <= BATAS_TAP_PX && ptrs.current.size === 0) {
      const el = (e.target as Element).closest("[data-halte]");
      if (editor && el) editor.onPilih(el.getAttribute("data-halte")!);
      else if (onTap) {
        const [x, y] = keTitik(e.clientX, e.clientY);
        onTap(x, y);
      }
    }
    if (ptrs.current.size === 0) gerak.current = null;
  };
  const onWheel = (e: React.WheelEvent): void => {
    const [cx, cy] = titikSvg(e);
    zoomKe(e.deltaY > 0 ? 1.18 : 1 / 1.18, cx, cy);
  };

  const sorot = useMemo(() => new Set(o.sorot ?? []), [o.sorot]);
  const rute = useMemo(() => o.rute ?? [], [o.rute]);
  const ruteSet = useMemo(() => new Set(rute), [rute]);
  const fokus = useMemo(() => (fokusLin?.length ? new Set(fokusLin) : null), [fokusLin]);
  const tampilNama = (nama: string, hub: boolean): boolean =>
    sorot.has(nama) ||
    ruteSet.has(nama) ||
    editor?.terpilih === nama ||
    (o.label !== false && (zoom >= 4.2 || (hub && zoom >= 2.6)));

  if (o.tampil === false)
    return (
      <div className="peta peta-kosong" style={{ height: typeof tinggi === "number" ? Math.min(tinggi, 140) : tinggi }}>
        <span>Peta disembunyikan — jawab dari ingatanmu</span>
        {kredit ? <MapCredit /> : null}
      </div>
    );

  const cx = awal.x + awal.w / 2;
  const cy = awal.y + awal.h / 2;
  const x1 = view.x + view.w;
  const y1 = view.y + view.h;
  const terlihat = (x: number, y: number): boolean =>
    x > view.x - 100 && x < x1 + 100 && y > view.y - 100 && y < y1 + 100;
  const fs = 11.5 * upp;

  return (
    <div className={`peta${gelap ? " peta-gelap" : ""}`} ref={wrap} style={{ height: tinggi }}>
      <svg
        ref={svg}
        viewBox={`${view.x} ${view.y} ${view.w} ${view.h}`}
        preserveAspectRatio="xMidYMid meet"
        onPointerDown={onDown}
        onPointerMove={onMove}
        onPointerUp={onUp}
        onPointerCancel={onUp}
        onWheel={onWheel}
        role="img"
        aria-label="Peta skematik jaringan transportasi Jakarta"
        style={{ touchAction: "none", cursor: onTap ? "crosshair" : "grab" }}
      >
        <g transform={putar ? `rotate(${putar} ${cx} ${cy})` : undefined}>
          {o.grid
            ? model.grid.map((g) => (
                <g key={g.kode}>
                  <rect x={g.x} y={g.y} width={g.w} height={g.h} className="peta-sel" />
                  {zoom < 3 ? (
                    <text
                      x={g.x + g.w / 2}
                      y={g.y + g.h / 2}
                      className="peta-sel-teks"
                      fontSize={Math.min(330, 30 * upp)}
                    >
                      {g.kode}
                    </text>
                  ) : null}
                </g>
              ))
            : null}
          {model.gambar ? <GambarPeta g={model.gambar} lin={o.lin !== false} gelap={gelap} /> : null}
          {!model.gambar && o.lin !== false
            ? model.lin.map((l) => {
                const redup = fokus && !fokus.has(l.id);
                const lebar = l.moda === "BRT" ? 38 : 54;
                return (
                  <g key={l.id} opacity={redup ? 0.18 : 1}>
                    {l.segmen.map((s, i) => (
                      <path key={i} d={s.d} className="peta-casing" strokeWidth={lebar + 22} />
                    ))}
                    {l.segmen.map((s, i) => (
                      <path
                        key={i}
                        d={s.d}
                        stroke={l.warna}
                        strokeWidth={lebar}
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        fill="none"
                        strokeDasharray={s.cek ? "70 60" : undefined}
                      >
                        {s.cek ? <title>Segmen ini perlu dicek manusia</title> : null}
                      </path>
                    ))}
                  </g>
                );
              })
            : null}
          {ruteSet.size > 0 && rute.length > 1 ? (
            <polyline
              points={rute
                .map((n) => model.byNama.get(n))
                .filter(Boolean)
                .map((h) => `${h!.x},${h!.y}`)
                .join(" ")}
              className="peta-rute"
              strokeWidth={110}
            />
          ) : null}
          {model.halte.map((h) => {
            const aktif = sorot.has(h.nama) || ruteSet.has(h.nama);
            const pilih = editor?.terpilih === h.nama;
            if (!aktif && !pilih && !terlihat(h.x, h.y)) return null;
            // Dengan gambar ulang, penanda stasiun asli sudah digambar (GambarPeta); lingkaran sendiri hanya untuk sorotan,
            // peta gelap, atau halte yang belum punya penanda (posisi dari label).
            const butuhTitik = !model.gambar || gelap || h.sumber !== "penanda-peta";
            return (
              <g key={h.nama} data-halte={h.nama} style={{ cursor: editor ? "pointer" : undefined }}>
                {editor ? <circle cx={h.x} cy={h.y} r={70} fill="transparent" data-halte={h.nama} /> : null}
                {butuhTitik && !aktif ? (
                  gelap || !model.gambar ? (
                    <circle
                      cx={h.x}
                      cy={h.y}
                      r={model.gambar ? 16 : h.hub ? 27 : 19}
                      className={`peta-halte${h.hub ? " hub" : ""}${gelap ? " gelap" : ""}${h.perkiraan && editor ? " perkiraan" : ""}${pilih ? " pilih" : ""}`}
                    />
                  ) : (
                    <g>
                      <circle cx={h.x} cy={h.y} r={13.5} fill="#100d0f" />
                      <circle cx={h.x} cy={h.y} r={11.5} fill="#fff" />
                      {h.perkiraan && editor ? <circle cx={h.x} cy={h.y} r={32} className="peta-perkiraan" /> : null}
                    </g>
                  )
                ) : null}
                {aktif ? (
                  <g>
                    <circle cx={h.x} cy={h.y} r={50} className="peta-sorot-halo" />
                    <circle cx={h.x} cy={h.y} r={40} className="peta-sorot" />
                  </g>
                ) : null}
                {pilih ? <circle cx={h.x} cy={h.y} r={46} className="peta-pilih" /> : null}
              </g>
            );
          })}{" "}
          {model.halte.map((h) => {
            const aktif = sorot.has(h.nama) || ruteSet.has(h.nama) || editor?.terpilih === h.nama;
            if (!tampilNama(h.nama, h.hub) || (!aktif && !terlihat(h.x, h.y))) return null;
            return (
              <text
                key={h.nama}
                x={h.x + 80}
                y={h.y - 70}
                fontSize={aktif ? fs * 1.15 : fs}
                className={`peta-nama${aktif ? " aktif" : ""}${gelap ? " gelap" : ""}`}
                transform={putar ? `rotate(${180} ${h.x} ${h.y})` : undefined}
                textAnchor={putar ? "end" : "start"}
              >
                {h.nama}
              </text>
            );
          })}
          {(tanda ?? []).map((t, i) => (
            <g key={i}>
              <circle
                cx={t.x}
                cy={t.y}
                r={t.r ?? 90}
                fill="none"
                stroke={t.warna ?? "#d7282f"}
                strokeWidth={26}
                strokeDasharray={t.r ? "40 30" : undefined}
              />
              <circle cx={t.x} cy={t.y} r={26} fill={t.warna ?? "#d7282f"} />
            </g>
          ))}
        </g>
      </svg>
      <div className="peta-kontrol" aria-label="Kontrol peta">
        <button type="button" onClick={() => zoomKe(1 / 1.5)} aria-label="Perbesar">
          +
        </button>
        <button type="button" onClick={() => zoomKe(1.5)} aria-label="Perkecil">
          −
        </button>
        <button type="button" onClick={() => setView(awal)} aria-label="Reset tampilan peta">
          ⤢
        </button>
      </div>
      {kredit ? <MapCredit /> : null}
    </div>
  );
}

export { warnaTeks };

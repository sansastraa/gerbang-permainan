// Layar pemain: masuk dengan PIN, lobi, hafal, soal, hasil, rapor anak.
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { ReactElement } from "react";
import type { Socket } from "socket.io-client";
import { EV, LABEL_MODE, warnaTeks } from "@transit-rush/shared";
import type { HasilKlien, ItemKlien, MemoKlien, Mode, Rapor, StateSesi } from "@transit-rush/shared";
import { Jawab } from "./Jawab";
import { MapCredit } from "./MapCredit";
import { RaporView } from "./Rapor";
import { TransitMap } from "./TransitMap";
import { Peringkat } from "./Peringkat";
import { Digits, KotakPin, LatarJalur, LencanaLin, TandaHasil } from "./ui";
import { ambilKonfig, ambilPeta, api, sambung, useAsync } from "./net";
import type { KonfigServer } from "./net";

const KUNCI = "tr.pemain";
interface Simpan {
  sesiId: string;
  token: string;
}
const bacaSimpan = (): Simpan | null => {
  try {
    return JSON.parse(sessionStorage.getItem(KUNCI) ?? "null") as Simpan | null;
  } catch {
    return null;
  }
};

/** Hitung mundur tampilan saja; waktu sebenarnya dipegang server. */
function useSisa(sisaMs: number | null, kunci: unknown): number | null {
  const [t, setT] = useState<number | null>(sisaMs);
  useEffect(() => {
    if (sisaMs === null) return setT(null);
    const mulai = performance.now();
    setT(sisaMs);
    const id = setInterval(() => setT(Math.max(0, sisaMs - (performance.now() - mulai))), 200);
    return () => clearInterval(id);
  }, [sisaMs, kunci]);
  return t;
}

function Waktu({ sisa, total }: { sisa: number | null; total: number }): ReactElement {
  const f = sisa === null ? 1 : Math.max(0, Math.min(1, sisa / total));
  return (
    <div
      className={`tiket-waktu${f < 0.25 ? " genting" : ""}`}
      role="timer"
      aria-label={`Sisa waktu ${Math.ceil((sisa ?? 0) / 1000)} detik`}
    >
      <i style={{ width: `${f * 100}%` }} />
    </div>
  );
}

function Jalur({ riwayat, kini }: { riwayat: boolean[]; kini: boolean }): ReactElement {
  const tampil = riwayat.slice(-18);
  return (
    <div className="jalur" aria-label={`${riwayat.length} soal dijawab`}>
      {tampil.map((b, i) => (
        <span key={i} style={{ display: "contents" }}>
          <span className={`stop ${b ? "ok" : "no"}`} />
          <span className={`rel${b ? " ok" : ""}`} />
        </span>
      ))}
      <span className={`stop${kini ? " kini" : ""}`} />
    </div>
  );
}

function MemoView({
  memo,
  model,
  konfig,
}: {
  memo: MemoKlien;
  model: NonNullable<ReturnType<typeof usePeta>>;
  konfig: KonfigServer | null;
}): ReactElement {
  const sisa = useSisa(memo.detik * 1000, memo.no);
  const h = memo.hafal as {
    rute?: string[];
    urutan?: string[];
    pasangan?: { kode: string; warna: string; rute: string }[];
    lin?: string[];
  };
  void konfig;
  return (
    <div className="memo" data-testid="memo">
      <h2>Hafalkan dulu! · {memo.nama}</h2>
      <Waktu sisa={sisa} total={memo.detik * 1000} />
      {h.rute ? (
        <>
          <TransitMap
            model={model}
            opsi={{ ...memo.peta, sorot: [h.rute[0]!, h.rute[h.rute.length - 1]!] }}
            tinggi={240}
            kredit
          />
          <div className="rute-list">
            {h.rute.map((s, i) => (
              <span key={s + i} style={{ display: "contents" }}>
                {i > 0 ? <span className="pan">›</span> : null}
                <span className="st">{s}</span>
              </span>
            ))}
          </div>
        </>
      ) : null}
      {h.urutan ? (
        <div className="rute-list">
          {h.urutan.map((s, i) => (
            <span key={s + i} style={{ display: "contents" }}>
              {i > 0 ? <span className="pan">›</span> : null}
              <span className="st">{s}</span>
            </span>
          ))}
        </div>
      ) : null}
      {h.pasangan ? (
        <div className="pasang">
          {h.pasangan.map((p) => (
            <div key={p.kode}>
              <span className="kode-lin" style={{ background: p.warna, color: warnaTeks(p.warna) }}>
                {p.kode}
              </span>
              <span>{p.rute}</span>
            </div>
          ))}
        </div>
      ) : null}
      <div className="muted" style={{ color: "#9db2cf" }}>
        Setelah waktu habis, data ini hilang dan soal muncul.
      </div>
    </div>
  );
}

function usePeta() {
  const { data } = useAsync(() => ambilPeta(), []);
  return data?.model ?? null;
}

function Papan({ papan, saya }: { papan: StateSesi["papan"]; saya?: string | null }): ReactElement {
  return (
    <div className="papan" data-testid="papan">
      {papan.map((p, i) => (
        <div key={p.id} className={`r${p.id === saya ? " saya" : ""}${i === 0 ? " p1" : ""}`}>
          <b>{i + 1}</b>
          <span>{p.nama}</span>
          <span style={{ fontWeight: 700 }}>{p.poin}</span>
        </div>
      ))}
    </div>
  );
}

export function Play(): ReactElement {
  const konfig = useAsync(ambilKonfig, []).data;
  const model = usePeta();
  const sock = useRef<Socket | null>(null);
  const [fase, setFase] = useState<"masuk" | "lobi" | "main" | "selesai">("masuk");
  const [pinIn, setPinIn] = useState(new URLSearchParams(location.search).get("pin") ?? "");
  const [info, setInfo] = useState<{
    id: string;
    nama: string;
    mode: Mode;
    roster: { id: string; name: string; absen: number | null; terpakai: boolean }[];
  } | null>(null);
  const [nama, setNama] = useState("");
  const [usia, setUsia] = useState(10);
  const [galat, setGalat] = useState<string | null>(null);
  const [saya, setSaya] = useState<{ pid: string; nama: string } | null>(null);
  const [st, setSt] = useState<StateSesi | null>(null);
  const [memo, setMemo] = useState<MemoKlien | null>(null);
  const [item, setItem] = useState<ItemKlien | null>(null);
  const [hasil, setHasil] = useState<HasilKlien | null>(null);
  const [kunci, setKunci] = useState(false);
  const [riwayat, setRiwayat] = useState<boolean[]>([]);
  const [rapor, setRapor] = useState<Rapor | null>(null);
  const [pilih, setPilih] = useState(false);
  const [poin, setPoin] = useState(0);
  const [sheet, setSheet] = useState(false);
  const siapKirim = useRef(false);
  const sisa = useSisa(item ? item.sisaMs : null, item?.no);

  const pasang = useCallback((s: Socket) => {
    sock.current?.disconnect();
    sock.current = s;
    s.on(EV.state, (p: StateSesi | { menunggu: string }) => {
      if ("menunggu" in p) return (setPilih(true), setItem(null), setHasil(null), setMemo(null));
      setSt(p);
    });
    s.on(EV.memo, (m: MemoKlien) => (setMemo(m), setItem(null), setHasil(null), setPilih(false), setKunci(false)));
    s.on(EV.item, (i: ItemKlien) => (setItem(i), setMemo(null), setHasil(null), setPilih(false), setKunci(false)));
    s.on(
      EV.result,
      (h: HasilKlien) => (setHasil(h), setKunci(true), setRiwayat((r) => [...r, h.benar]), setPoin(h.total)),
    );
    s.on(EV.progress, (p: { poin: number }) => setPoin(p.poin));
    s.on(EV.end, (r: Rapor | null) => (setRapor(r), setFase("selesai"), setItem(null), setMemo(null)));
    s.on("tr:masuk-ulang", (m: { pid: string; nama: string }) => (setSaya(m), setFase("lobi")));
    s.on("connect_error", (e: Error) => {
      setGalat(e.message);
      if (/tidak ditemukan|salah/i.test(e.message)) {
        try {
          sessionStorage.removeItem(KUNCI);
        } catch {
          /* abaikan */
        }
        s.disconnect();
      }
    });
  }, []);

  // masuk ulang otomatis setelah refresh
  useEffect(() => {
    const sm = bacaSimpan();
    if (sm) pasang(sambung({ peran: "pemain", sesiId: sm.sesiId, token: sm.token }));
    return () => void sock.current?.disconnect();
  }, [pasang]);

  // sesi berjalan -> pemain siap (mode mandiri)
  useEffect(() => {
    if (!st || !saya || st.status !== "berjalan") return;
    setFase((f) => (f === "selesai" ? f : "main"));
    if (st.mode !== "arena" && !siapKirim.current) {
      siapKirim.current = true;
      sock.current?.emit("tr:siap", {}, () => undefined);
    }
  }, [st, saya]);

  // bendera fokus: lama meninggalkan aplikasi dilaporkan ke server (tidak menghukum)
  useEffect(() => {
    let sembunyi = 0;
    const f = (): void => {
      if (document.hidden) sembunyi = performance.now();
      else if (sembunyi) {
        sock.current?.emit("tr:blur", { ms: performance.now() - sembunyi });
        sembunyi = 0;
      }
    };
    document.addEventListener("visibilitychange", f);
    return () => document.removeEventListener("visibilitychange", f);
  }, []);

  async function cekPin(): Promise<void> {
    setGalat(null);
    try {
      const r = await api<NonNullable<typeof info>>("/api/lookup", { body: { pin: pinIn.trim() } });
      setInfo(r);
    } catch (e) {
      setGalat((e as Error).message);
    }
  }
  function masuk(siswaId?: string): void {
    if (!info) return;
    const s = sambung({ peran: "pemain", pin: pinIn.trim() });
    pasang(s);
    s.once("connect", () => {
      s.emit(
        "tr:join",
        { nama: nama.trim() || "Pemain", usia, siswaId },
        (r: { ok: boolean; alasan?: string; pid: string; token: string; pemain: { nama: string } }) => {
          if (!r.ok) return setGalat(r.alasan ?? "Gagal masuk.");
          try {
            sessionStorage.setItem(KUNCI, JSON.stringify({ sesiId: info.id, token: r.token } satisfies Simpan));
          } catch {
            /* abaikan */
          }
          setSaya({ pid: r.pid, nama: r.pemain.nama });
          setFase("lobi");
        },
      );
    });
  }
  const jawab = (resp: unknown): void => {
    if (!item || kunci) return;
    setKunci(true);
    sock.current?.emit("tr:answer", { no: item.no, resp }, (r: { ok: boolean; alasan?: string }) => {
      if (!r.ok) setKunci(false);
    });
  };
  const lanjut = (): void => {
    setHasil(null);
    setItem(null);
    sock.current?.emit("tr:lanjut", {}, () => undefined);
  };
  const keluar = (): void => {
    try {
      sessionStorage.removeItem(KUNCI);
    } catch {
      /* abaikan */
    }
    sock.current?.disconnect();
    location.reload();
  };

  const header = (
    <div className="bar">
      <div className="logo">
        <i>T</i> Transit Rush
      </div>
      <span className="sp" />
      {saya ? <span className="chip">{saya.nama}</span> : null}
      {fase === "main" || fase === "selesai" ? (
        <span data-testid="poin" title="Poin">
          <Digits nilai={poin} lebar={4} />
        </span>
      ) : null}
    </div>
  );

  if (fase === "masuk")
    return (
      <div className="app">
        <div className="hero">
          <LatarJalur />
          <h1>
            Transit
            <br />
            <span>Rush</span>
          </h1>
          <p>Hafal rute, tebak arah, hitung halte. Naik-turun peta transportasi Jakarta dalam beberapa menit.</p>
        </div>
        <div className="main">
          {!info ? (
            <form
              className="kartu"
              style={{ display: "grid", gap: 14 }}
              onSubmit={(e) => (e.preventDefault(), void cekPin())}
            >
              <h2>Kode peron dari gurumu</h2>
              <KotakPin nilai={pinIn} ubah={setPinIn} autoFocus />
              <button className="btn utama besar" disabled={pinIn.length !== 6}>
                Masuk
              </button>
              {galat ? (
                <div role="alert" style={{ color: "var(--merah)" }}>
                  {galat}
                </div>
              ) : null}
            </form>
          ) : (
            <div className="kartu" style={{ display: "grid", gap: 12 }}>
              <h2>{info.nama}</h2>
              <span className="chip gelap" style={{ justifySelf: "start" }}>
                {LABEL_MODE[info.mode]}
              </span>
              {info.roster.length > 0 ? (
                <div className="pilihan" role="group" aria-label="Pilih namamu">
                  {info.roster.map((r) => (
                    <button
                      key={r.id}
                      className="opsi"
                      disabled={r.terpakai}
                      onClick={() => (setNama(r.name), masuk(r.id))}
                    >
                      <span className="i">{r.absen ?? "·"}</span>
                      {r.name}
                      {r.terpakai ? " (sudah masuk)" : ""}
                    </button>
                  ))}
                </div>
              ) : (
                <>
                  <label className="f">
                    Namamu
                    <input
                      className="input"
                      value={nama}
                      onChange={(e) => setNama(e.target.value)}
                      maxLength={40}
                      autoFocus
                    />
                  </label>
                  <label className="f">
                    Usiamu
                    <input
                      className="input"
                      type="number"
                      min={6}
                      max={80}
                      value={usia}
                      onChange={(e) => setUsia(Math.max(6, Math.min(80, Number(e.target.value) || 10)))}
                    />
                  </label>
                  <button className="btn utama besar" disabled={!nama.trim()} onClick={() => masuk()}>
                    Ikut bermain
                  </button>
                </>
              )}
              {galat ? (
                <div role="alert" style={{ color: "var(--merah)" }}>
                  {galat}
                </div>
              ) : null}
            </div>
          )}
        </div>
      </div>
    );

  if (fase === "lobi")
    return (
      <div className="app">
        <div className="hero">
          <LatarJalur />
          <p
            style={{
              margin: 0,
              color: "var(--peron)",
              font: "900 12px var(--f-judul)",
              textTransform: "uppercase",
              letterSpacing: ".1em",
            }}
          >
            Halte keberangkatan
          </p>
          <h1 style={{ fontSize: 34, marginTop: 6 }}>{saya?.nama}</h1>
          <p>Menunggu guru memulai… {st ? `${st.pemain} pemain sudah masuk.` : ""}</p>
          <div className="jalur" style={{ padding: "18px 0 0" }}>
            <span className="stop kini" />
            <span className="rel" />
            <span className="stop" />
            <span className="rel" />
            <span className="stop" />
          </div>
        </div>
        <div className="main">
          {galat ? (
            <div role="alert" style={{ color: "var(--merah)" }}>
              {galat}
            </div>
          ) : null}
        </div>
      </div>
    );

  if (fase === "selesai")
    return (
      <div className="app">
        {header}
        <div className="main">
          {rapor ? (
            <RaporView rapor={rapor} nama={saya?.nama} sesi={st?.nama} mode="anak" />
          ) : (
            <div className="kartu">
              <h2>Selesai!</h2>
              <p className="muted">Belum ada jawaban yang tercatat.</p>
            </div>
          )}
          {st?.papan.length ? (
            <div className="kartu">
              <h2 style={{ marginBottom: 8 }}>Papan skor</h2>
              <Papan papan={st.papan} saya={saya?.pid} />
            </div>
          ) : null}
          <button className="btn hantu besar" onClick={keluar}>
            Keluar
          </button>
        </div>
      </div>
    );

  const arena = st?.mode === "arena";
  const detik = Math.ceil((sisa ?? 0) / 1000);
  return (
    <div className="app">
      {header}
      <Jalur riwayat={riwayat} kini={!!item || !!memo} />
      {st && st.papan.length > 0 ? (
        <div className="strip">
          <button type="button" className="strip-btn" data-testid="peringkat-btn" onClick={() => setSheet(true)}>
            <span className="no">#{Math.max(1, st.papan.findIndex((x) => x.id === saya?.pid) + 1)}</span>
            <span className="info">
              <b>Peringkat sementara</b>
              <small>dari {st.papan.length} pemain · ketuk untuk melihat</small>
            </span>
            <span className="puncak">
              Terdepan
              <b>{st.papan[0]!.poin}</b>
            </span>
          </button>
        </div>
      ) : null}
      {sheet && st ? (
        <>
          <div className="sheet-latar" onClick={() => setSheet(false)} />
          <div className="sheet" role="dialog" aria-label="Peringkat sementara" data-testid="sheet-peringkat">
            <div className="baris" style={{ justifyContent: "space-between" }}>
              <h2>Peringkat sementara</h2>
              <button type="button" className="btn kecil hantu" onClick={() => setSheet(false)}>
                Tutup
              </button>
            </div>
            <Peringkat papan={st.papan} saya={saya?.pid} maks={8} tambahSaya />
            <div className="muted">Peringkat berubah terus selama permainan.</div>
          </div>
        </>
      ) : null}
      <div className="main">
        {arena && st ? (
          <div className="muted" data-testid="ronde">
            Ronde {st.ronde} dari {st.rondeTotal}
          </div>
        ) : null}
        {pilih ? (
          <PilihLatihan
            konfig={konfig}
            min={1}
            kirim={(family, level) =>
              sock.current?.emit(
                "tr:pilih",
                { family, level },
                (r: { ok: boolean; alasan?: string }) => !r.ok && setGalat(r.alasan ?? null),
              )
            }
          />
        ) : null}
        {memo && model ? <MemoView memo={memo} model={model} konfig={konfig} /> : null}
        {item && model && !hasil ? (
          <div className="tiket" data-testid="kartu-soal">
            <div className="tiket-kepala">
              <LencanaLin ranah={item.ranah} />
              <div>
                <div className="jenis">{item.nama}</div>
                <div className="tingkat">
                  Level {item.level} · {item.levelNama}
                </div>
              </div>
              <span className="sp" />
              <Digits nilai={detik} lebar={2} genting={detik <= 5} />
            </div>
            <Waktu sisa={sisa} total={item.batasDetik * 1000} />
            <div className="tiket-isi">
              <p className="tanya" data-testid="tanya">
                {item.tanya.replaceAll("❓", "[ ? ]")}
              </p>
              {item.peta && item.tipe !== "ketuk" ? (
                <TransitMap model={model} opsi={item.peta} tinggi={item.peta.tampil === false ? 90 : 260} />
              ) : null}
              <Jawab key={item.no} item={item} model={model} kunci={kunci} kirim={jawab} />
            </div>
          </div>
        ) : null}
        {hasil ? (
          <div className={`hasil ${hasil.benar ? "benar" : "salah"}`} data-testid="hasil" role="status">
            <div className="hasil-atas">
              <TandaHasil benar={hasil.benar} />
              <h3>
                {hasil.waktuHabis
                  ? "Waktu habis"
                  : hasil.benar
                    ? "Tepat"
                    : hasil.sebagian > 0
                      ? "Hampir tepat"
                      : "Belum tepat"}
              </h3>
              <span className="sp" />
              <div className="skor">
                Poin
                <b>+{hasil.poin}</b>
              </div>
            </div>
            <div className="hasil-isi">
              {hasil.streak > 1 ? <div className="muted">Beruntun {hasil.streak} soal</div> : null}
              {!hasil.benar && hasil.penjelasan ? <div className="kunci">{hasil.penjelasan}</div> : null}
              {arena ? (
                <div className="muted">Menunggu pemain lain…</div>
              ) : (
                <button className="btn utama" onClick={lanjut} autoFocus>
                  Lanjut
                </button>
              )}
            </div>
          </div>
        ) : null}
        {arena && hasil && st?.papan.length ? <Papan papan={st.papan.slice(0, 5)} saya={saya?.pid} /> : null}
        {!item && !memo && !hasil && !pilih ? <div className="kartu muted">Menyiapkan soal…</div> : null}
        {galat ? (
          <div role="alert" style={{ color: "var(--merah)" }}>
            {galat}
          </div>
        ) : null}
        {model ? null : <div className="muted">Memuat peta…</div>}
      </div>
      <div style={{ padding: "0 14px 12px" }}>
        <MapCredit tema="terang" statis />
      </div>
    </div>
  );
}
function PilihLatihan({
  konfig,
  kirim,
}: {
  konfig: KonfigServer | null;
  min: number;
  kirim: (family: string, level: number) => void;
}): ReactElement {
  const [level, setLevel] = useState(3);
  const daftar = useMemo(() => (konfig ? Object.entries(konfig.keluarga) : []), [konfig]);
  return (
    <div className="kartu" style={{ display: "grid", gap: 10 }} data-testid="pilih-latihan">
      <h2>Latihan bebas</h2>
      <label className="f">
        Level: {level} — {konfig?.level[level - 1]}
        <input type="range" min={1} max={10} value={level} onChange={(e) => setLevel(Number(e.target.value))} />
      </label>
      {daftar.map(([ranah, fams]) => (
        <div key={ranah}>
          <div className="muted" style={{ textTransform: "capitalize", marginBottom: 4 }}>
            {ranah}
          </div>
          <div className="grid2">
            {fams.map((f) => (
              <button key={f.key} className="opsi" onClick={() => kirim(f.key, level)}>
                {f.nama}
              </button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

// Rapor / hasil. Selalu menampilkan rentang ketidakpastian 90% dan label "norma sementara".
import type { ReactElement } from "react";
import { RANAH } from "@transit-rush/shared";
import type { Rapor, Ranah } from "@transit-rush/shared";
import { MapCredit } from "./MapCredit";

export const WARNA_RANAH: Record<Ranah, string> = {
  memori: "#7b5ea7",
  spasial: "#0084c7",
  numerik: "#e07b12",
  logika: "#2e8b57",
};
const LABEL: Record<Ranah, string> = { memori: "Memori", spasial: "Spasial", numerik: "Numerik", logika: "Logika" };
const pos = (v: number): number => Math.max(0, Math.min(100, ((v - 55) / 90) * 100));

function Rentang({ skor, lo, hi, warna }: { skor: number; lo: number; hi: number; warna: string }): ReactElement {
  return (
    <div className="rentang" role="img" aria-label={`Skor ${skor}, kemungkinan antara ${lo} dan ${hi}`}>
      <div className="rata" style={{ left: `${pos(100)}%` }} title="Rata-rata kelompok usia = 100" />
      <div
        className="selang"
        style={{ left: `${pos(lo)}%`, width: `${Math.max(2, pos(hi) - pos(lo))}%`, background: warna }}
      />
      <div className="titik" style={{ left: `${pos(skor)}%` }} />
    </div>
  );
}

function bintang(level: number): string {
  const n = level >= 8 ? 5 : level >= 6 ? 4 : level >= 4 ? 3 : level >= 2 ? 2 : 1;
  return "▮".repeat(n) + "▯".repeat(5 - n);
}

function Ubin({ judul, nilai, ket }: { judul: string; nilai: string; ket?: string }): ReactElement {
  return (
    <div className="ubin">
      <span className="muted">{judul}</span>
      <b className="angka">{nilai}</b>
      {ket ? <small>{ket}</small> : null}
    </div>
  );
}

function PerilakuBlok({ p }: { p: NonNullable<Rapor["perilaku"]> }): ReactElement {
  return (
    <section data-testid="perilaku" style={{ display: "grid", gap: 10 }}>
      <div className="baris" style={{ justifyContent: "space-between" }}>
        <h3 style={{ fontSize: 15, textTransform: "uppercase", letterSpacing: ".05em" }}>Perilaku bermain</h3>
        <span className="chip gelap" data-testid="perilaku-gaya">
          {p.gaya}
        </span>
      </div>
      <div className="ubin-baris">
        <Ubin
          judul="Waktu median"
          nilai={`${p.medianDetik} dtk`}
          ket={`tercepat ${p.tercepat} · terlama ${p.terlama}`}
        />
        <Ubin judul="Pakai waktu" nilai={`${p.pakaiWaktuPersen}%`} ket="rata-rata dari batas per soal" />
        <Ubin judul="Kehabisan waktu" nilai={String(p.habis)} ket={`dari ${p.soal} soal`} />
        <Ubin judul="Terburu-buru" nilai={String(p.gegabah)} ket="salah < 20% waktu" />
        <Ubin judul="Teliti" nilai={String(p.cermat)} ket="benar setelah ≥ 50% waktu" />
        <Ubin judul="Beruntun terbaik" nilai={`${p.maksStreak}×`} />
        {p.tren ? (
          <Ubin
            judul="Tren ketepatan"
            nilai={p.tren === "naik" ? "Naik" : p.tren === "turun" ? "Turun" : "Stabil"}
            ket={`${Math.round((p.akurasiAwal ?? 0) * 100)}% → ${Math.round((p.akurasiAkhir ?? 0) * 100)}%`}
          />
        ) : null}
        {p.levelAwal !== null && p.levelAkhir !== null ? (
          <Ubin judul="Level soal" nilai={`${p.levelAwal} → ${p.levelAkhir}`} ket="awal → akhir" />
        ) : null}
        <Ubin
          judul="Fokus hilang"
          nilai={String(p.fokusHilang)}
          ket={p.bendera > p.fokusHilang ? `${p.bendera} bendera` : undefined}
        />
      </div>
      <ul className="catatan-daftar">
        {p.catatan.map((c) => (
          <li key={c}>{c}</li>
        ))}
      </ul>
      <div className="muted">Deskriptif saja: bukan penilaian watak, dan bendera tidak menghukum.</div>
    </section>
  );
}

export function RaporView({
  rapor,
  nama,
  sesi,
  mode = "penuh",
}: {
  rapor: Rapor;
  nama?: string;
  sesi?: string;
  mode?: "penuh" | "anak";
}): ReactElement {
  const diuji = RANAH.filter((d) => rapor.ranah[d].soal > 0);
  const urut = [...diuji].sort((a, b) => rapor.ranah[b].theta - rapor.ranah[a].theta);
  const kuat = urut.slice(0, 2);
  if (mode === "anak")
    return (
      <div className="rapor" data-testid="hasil-anak">
        <div style={{ textAlign: "center" }}>
          <div
            style={{ fontSize: 30, letterSpacing: 4, color: "#14161a" }}
            aria-label={`Bintang untuk level ${rapor.IKP.level}`}
          >
            {bintang(rapor.IKP.level)}
          </div>
          <h2>{nama ? `Kerja bagus, ${nama}!` : "Kerja bagus!"}</h2>
          <p className="muted">Level Penjelajah</p>
          <div style={{ font: "700 56px/1 var(--f-judul)" }}>{rapor.IKP.level}</div>
          <p style={{ fontWeight: 700, margin: "8px 0 0" }}>{rapor.tipe}</p>
        </div>
        <div className="ranah-baris">
          <div className="muted">Kekuatanmu</div>
          {kuat.map((d) => (
            <div key={d} className="baris" style={{ fontWeight: 700 }}>
              <span className={`lencana ${d}`}>{LABEL[d]}</span>
              <span>Level {rapor.ranah[d].level}</span>
            </div>
          ))}
        </div>
        {rapor.perilaku ? (
          <div className="catatan" data-testid="perilaku-anak">
            <b>Gaya mainmu:</b> {rapor.perilaku.gaya}. {rapor.perilaku.catatan[0]}
          </div>
        ) : null}
        <div className="catatan" style={{ background: "#eef7ff", borderColor: "#b5d8f5" }}>
          <b>Saran latihan:</b> {rapor.saran}
        </div>
        <p className="muted" style={{ margin: 0 }}>
          IKP-mu sekitar {rapor.IKP.rentangSkor90[0]}–{rapor.IKP.rentangSkor90[1]} (rentang 90%). Ini profil permainan,
          bukan tes IQ.
          {rapor.normaSementara ? " Norma sementara." : ""}
        </p>
        <MapCredit tema="terang" statis />
      </div>
    );
  return (
    <div className="rapor" data-testid="rapor-penuh">
      <div className="baris" style={{ justifyContent: "space-between", alignItems: "flex-start" }}>
        <div>
          <h2>Rapor Transit Rush{nama ? ` — ${nama}` : ""}</h2>
          <div className="muted">
            {sesi ? `${sesi} · ` : ""}
            {rapor.kelompokUsia}
          </div>
        </div>
        <span className="chip gelap">Norma {rapor.normaSementara ? "sementara" : "kalibrasi"}</span>
      </div>
      <div className="ikp">
        <div>
          <div className="muted">Indeks Kognitif Peta (IKP)</div>
          <div className="angka" data-testid="ikp">
            {rapor.IKP.skorStandar}
          </div>
          <div className="muted" data-testid="ikp-rentang">
            rentang 90%: {rapor.IKP.rentangSkor90[0]}–{rapor.IKP.rentangSkor90[1]}
          </div>
        </div>
        <div style={{ flex: 1, minWidth: 220 }}>
          <Rentang
            skor={rapor.IKP.skorStandar}
            lo={rapor.IKP.rentangSkor90[0]}
            hi={rapor.IKP.rentangSkor90[1]}
            warna="#0f1b2d"
          />
          <div className="muted" style={{ marginTop: 6 }}>
            Persentil {rapor.IKP.persentil} ({rapor.IKP.rentangPersentil90[0]}–{rapor.IKP.rentangPersentil90[1]}) ·
            Stanine {rapor.IKP.stanine} · Level Penjelajah {rapor.IKP.level}
          </div>
        </div>
      </div>
      <div>
        <b>{rapor.tipe}</b>
        <div className="muted">{rapor.kekuatan.teks}</div>
      </div>
      <div style={{ display: "grid", gap: 10 }}>
        {RANAH.map((d) => {
          const r = rapor.ranah[d];
          return (
            <div className="ranah-baris" key={d}>
              <div className="judul">
                <span style={{ color: WARNA_RANAH[d] }}>{LABEL[d]}</span>
                <span>
                  {r.soal === 0
                    ? "tidak diuji"
                    : `${r.skorStandar} (${r.rentangSkor90[0]}–${r.rentangSkor90[1]}) · persentil ${r.persentil}`}
                </span>
              </div>
              {r.soal > 0 ? (
                <Rentang skor={r.skorStandar} lo={r.rentangSkor90[0]} hi={r.rentangSkor90[1]} warna={WARNA_RANAH[d]} />
              ) : null}
              <div className="muted">
                {r.benar}/{r.soal} benar · Level {r.level} · SEM {r.sem}
                {r.medianDetik !== null ? ` · median ${r.medianDetik} dtk` : ""}
              </div>
            </div>
          );
        })}
      </div>
      {rapor.perilaku ? <PerilakuBlok p={rapor.perilaku} /> : null}
      <div>
        <div className="muted" style={{ marginBottom: 4 }}>
          Jejak tes adaptif (tinggi = level soal, hijau = benar)
        </div>
        <div className="jejak" aria-hidden>
          {rapor.jejak.map((j, i) => (
            <i
              key={i}
              title={`${j.family} lv ${j.level}`}
              style={{ height: `${10 + j.level * 9}%`, background: j.benar ? "#2e8b57" : "#d7282f" }}
            />
          ))}
        </div>
      </div>
      <div className="muted">
        Rush: {rapor.rush.benar}/{rapor.rush.soal} benar
        {rapor.rush.benarPerMenit !== null ? ` · ${rapor.rush.benarPerMenit} benar/menit` : ""} · Reliabilitas perkiraan{" "}
        {rapor.reliabilitasPerkiraan}
      </div>
      <div className="catatan">
        <b>Saran:</b> {rapor.saran}
      </div>
      <div className="catatan">
        {rapor.catatanNorma} Selang 90% menunjukkan ketidakpastian pengukuran: selisih kecil antar ranah belum tentu
        bermakna.
      </div>
      <MapCredit tema="terang" atribusi statis />
    </div>
  );
}

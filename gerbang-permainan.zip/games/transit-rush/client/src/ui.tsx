// Komponen visual khas: digit papan keberangkatan, lencana lin, kotak PIN, latar jalur dari data jaringan.
import { useEffect, useMemo, useRef, useState } from "react";
import type { ReactElement } from "react";
import type { Ranah } from "@transit-rush/shared";
import { ambilPeta, useAsync } from "./net";

/** Digit papan flip. Digit yang berubah berkedip singkat (balik). */
export function Digits({
  nilai,
  lebar = 0,
  genting = false,
  terang = false,
}: {
  nilai: number | string;
  lebar?: number;
  genting?: boolean;
  terang?: boolean;
}): ReactElement {
  const teks = String(nilai).padStart(lebar, "0");
  const prev = useRef(teks);
  const lama = prev.current;
  useEffect(() => {
    prev.current = teks;
  });
  return (
    <span
      className={`digits angka${genting ? " genting" : ""}${terang ? " terang" : ""}`}
      aria-label={String(nilai)}
      role="img"
    >
      {[...teks].map((c, i) => (
        <span key={`${i}-${c}`} className={`dg${lama[i] !== undefined && lama[i] !== c ? " baru" : ""}`} aria-hidden>
          {c}
        </span>
      ))}
    </span>
  );
}

const HURUF: Record<Ranah, string> = { memori: "M", spasial: "S", numerik: "N", logika: "L" };
/** Lencana lin: huruf dalam kotak berwarna, seperti penanda koridor di halte. */
export function LencanaLin({ ranah }: { ranah: Ranah }): ReactElement {
  return <span className={`lin ${ranah}`}>{HURUF[ranah]}</span>;
}

/** Enam kotak PIN yang dikendalikan satu input (angka saja). */
export function KotakPin({
  nilai,
  ubah,
  autoFocus = false,
}: {
  nilai: string;
  ubah: (v: string) => void;
  autoFocus?: boolean;
}): ReactElement {
  const [fokus, setFokus] = useState(false);
  return (
    <div className="kotak-pin">
      {[0, 1, 2, 3, 4, 5].map((i) => (
        <span
          key={i}
          className={`k${nilai[i] ? " isi" : ""}${fokus && i === Math.min(nilai.length, 5) ? " aktif" : ""}`}
        >
          {nilai[i] ?? ""}
        </span>
      ))}
      <input
        value={nilai}
        onChange={(e) => ubah(e.target.value.replace(/\D/g, "").slice(0, 6))}
        onFocus={() => setFokus(true)}
        onBlur={() => setFokus(false)}
        inputMode="numeric"
        autoComplete="one-time-code"
        maxLength={6}
        aria-label="PIN sesi"
        autoFocus={autoFocus}
      />
    </div>
  );
}

/**
 * Dekor: garis lin dari peta FDTJ yang digambar ulang, tipis di atas latar malam. Dengan `hidup`, garis tergambar bertahap
 * dan beberapa kereta kecil berjalan menyusuri lin terpanjang.
 */
export function LatarJalur({ hidup = false }: { hidup?: boolean }): ReactElement | null {
  const { data } = useAsync(() => ambilPeta(), []);
  const g = data?.gambar;
  const kereta = useMemo(() => {
    if (!g || !hidup) return [];
    return g.items
      .filter((i) => i.t === "l")
      .sort((a, b) => b.d.length - a.d.length)
      .slice(0, 9)
      .map((i, n) => ({ d: i.d, c: i.c, dur: 38 + ((n * 7) % 26), mulai: -((n * 11) % 40) }));
  }, [g, hidup]);
  if (!data || !g) return <div className="latar" />;
  const f = g.frame;
  const garis = g.items.filter((i) => i.t === "l");
  return (
    <div className={`latar${hidup ? " hidup" : ""}`} aria-hidden>
      <svg viewBox={`${f.x0} ${f.y0} ${f.x1 - f.x0} ${f.y1 - f.y0}`} preserveAspectRatio="xMidYMid slice">
        <g fill="none" strokeLinecap="round" strokeLinejoin="round">
          {garis.map((l, i) => (
            <path
              key={i}
              d={l.d}
              stroke={l.c}
              strokeWidth={(l.w ?? 15) + 12}
              pathLength={1}
              className={hidup ? "garis-gambar" : undefined}
              style={hidup ? { animationDelay: `${(i % 25) * 90}ms` } : undefined}
            />
          ))}
        </g>
        {kereta.map((k, i) => (
          <g key={i}>
            <circle r={46} fill="#fff" opacity={0.95}>
              <animateMotion dur={`${k.dur}s`} begin={`${k.mulai}s`} repeatCount="indefinite" path={k.d} />
            </circle>
            <circle r={26} fill={k.c}>
              <animateMotion dur={`${k.dur}s`} begin={`${k.mulai}s`} repeatCount="indefinite" path={k.d} />
            </circle>
          </g>
        ))}
      </svg>
    </div>
  );
}
/** Tanda centang / silang untuk layar hasil (SVG, bukan emoji). */
export function TandaHasil({ benar }: { benar: boolean }): ReactElement {
  return (
    <span className="tanda">
      <svg
        viewBox="0 0 24 24"
        fill="none"
        stroke={benar ? "#1f8a4c" : "#d7282f"}
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {benar ? <path d="M4 12.5l5 5L20 6.5" /> : <path d="M6 6l12 12M18 6L6 18" />}
      </svg>
    </span>
  );
}

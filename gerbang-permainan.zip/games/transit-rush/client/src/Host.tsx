// Konsol guru/operator: buat sesi, jalankan, lihat dasbor, rapor, ekspor, editor jaringan, kalibrasi.
import { useEffect, useMemo, useRef, useState } from "react";
import type { ReactElement } from "react";
import QRCode from "qrcode";
import type { Socket } from "socket.io-client";
import { EV, LABEL_MODE, RANAH, bangunPeta } from "@transit-rush/shared";
import type { Ranah } from "@transit-rush/shared";
import type { DataJaringan, Mode, PetaGambar, Rapor, RingkasanTR, SesiSettings, StateSesi } from "@transit-rush/shared";
import { READY_MESSAGE, buildKembaliUrl, parseImportMessage, parseManualNames } from "./importRoster";
import type { ImportedRoster, ImportedStudent } from "./importRoster";
import { RaporView, WARNA_RANAH } from "./Rapor";
import { TransitMap } from "./TransitMap";
import { MapCredit } from "./MapCredit";
import { Peringkat } from "./Peringkat";
import { LencanaLin } from "./ui";
import { ambilPeta, api, bacaHostToken, sambung, simpanHostToken } from "./net";
import { BASE, url } from "./url";

const SS = "transitrush.host";
interface Konteks {
  pin: string;
  asal: string;
  roster: ImportedStudent[];
  kelas: string;
  kembali?: string;
  multiSesi?: string;
}
interface HostExtra {
  pemain: {
    id: string;
    nama: string;
    siswaId: string | null;
    absen: number | null;
    online: boolean;
    poin: number;
    soal: number;
    benar: number;
    streak: number;
    selesai: boolean;
    bendera: number;
  }[];
}
interface Statistik {
  perilaku?: {
    pemain: number;
    medianDetikRata: number | null;
    pakaiWaktuRata: number | null;
    habisTotal: number;
    gegabahTotal: number;
    trenNaik: number;
    trenTurun: number;
    gaya: Record<string, number>;
  };
  ranah: Record<string, { soal: number; tepat: number | null; thetaRata: number | null }>;
  terlaluMudah: { nama: string; level: number; tepat: number; n: number }[];
  terlaluSulit: { nama: string; level: number; tepat: number; n: number }[];
  bendera: { pemain: string; jenis: string; detail: string; no: number }[];
}

async function unduh(path: string, nama: string): Promise<void> {
  const r = await fetch(url(path), { headers: { "x-host-token": bacaHostToken() } });
  if (!r.ok) throw new Error("Gagal mengunduh.");
  const blob = await r.blob();
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = nama;
  a.click();
  setTimeout(() => URL.revokeObjectURL(a.href), 2000);
}

export function Host(): ReactElement {
  const [konteks, setKonteks] = useState<Konteks | null>(null);
  const [token, setToken] = useState(bacaHostToken());
  const [sah, setSah] = useState(false);
  const [galat, setGalat] = useState("");
  const [tab, setTab] = useState<"sesi" | "jaringan" | "kalibrasi">("sesi");
  const [sesi, setSesi] = useState<{ id: string; pin: string } | null>(() => {
    try {
      return JSON.parse(sessionStorage.getItem(SS + ".sesi") ?? "null") as { id: string; pin: string } | null;
    } catch {
      return null;
    }
  });

  // SIMPETERI: umumkan siap ke jendela pembuka dan terima daftar siswa (hanya pesan dari opener yang diterima)
  useEffect(() => {
    const onMsg = (e: MessageEvent): void => {
      if (e.source !== window.opener) return;
      const r: ImportedRoster | null = parseImportMessage(e.data);
      if (!r) return;
      if (r.pin) {
        simpanHostToken(r.pin);
        setToken(r.pin);
      }
      setKonteks({
        pin: r.pin ?? "",
        asal: e.origin,
        roster: r.roster,
        kelas: r.kelas,
        ...(r.kembali ? { kembali: r.kembali } : {}),
        ...(r.multiSesi ? { multiSesi: r.multiSesi } : {}),
      });
    };
    window.addEventListener("message", onMsg);
    window.opener?.postMessage({ type: READY_MESSAGE }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  // verifikasi PIN guru
  useEffect(() => {
    simpanHostToken(token);
    api("/api/sessions", { host: true }).then(
      () => (setSah(true), setGalat("")),
      (e: Error) => (setSah(false), setGalat(token ? e.message : "")),
    );
  }, [token]);

  if (!sah)
    return (
      <div className="app">
        <div className="bar">
          <div className="logo">
            <i>T</i> Transit Rush · Guru
          </div>
        </div>
        <div className="main">
          <PinGuru onOk={(p) => setToken(p)} galat={galat} />
        </div>
      </div>
    );

  return (
    <div className="app app-lebar">
      <div className="bar no-print">
        <div className="logo">
          <i>T</i> Transit Rush · Konsol guru
        </div>
        <span className="sp" />
        {konteks?.kelas ? <span className="chip">Kelas {konteks.kelas}</span> : null}
      </div>
      <div className="tab no-print" role="tablist" style={{ padding: "0 14px" }}>
        {(["sesi", "jaringan", "kalibrasi"] as const).map((t) => (
          <button
            key={t}
            role="tab"
            aria-selected={tab === t}
            className={tab === t ? "on" : ""}
            onClick={() => setTab(t)}
          >
            {t === "sesi" ? "Sesi" : t === "jaringan" ? "Editor jaringan" : "Kalibrasi & norma"}
          </button>
        ))}
      </div>
      <div className="main">
        {tab === "sesi" ? (
          sesi ? (
            <Jalankan
              sesi={sesi}
              konteks={konteks}
              keluarSesi={() => (sessionStorage.removeItem(SS + ".sesi"), setSesi(null))}
            />
          ) : (
            <Buat
              konteks={konteks}
              jadi={(s) => (sessionStorage.setItem(SS + ".sesi", JSON.stringify(s)), setSesi(s))}
            />
          )
        ) : tab === "jaringan" ? (
          <EditorJaringan />
        ) : (
          <Kalibrasi sesiId={sesi?.id ?? null} />
        )}
      </div>
    </div>
  );
}

function PinGuru({ onOk, galat }: { onOk: (p: string) => void; galat: string }): ReactElement {
  const [v, setV] = useState("");
  return (
    <form
      className="kartu"
      style={{ display: "grid", gap: 10, maxWidth: 420 }}
      onSubmit={(e) => (e.preventDefault(), onOk(v.trim()))}
    >
      <h2>PIN guru</h2>
      <p className="muted" style={{ margin: 0 }}>
        PIN guru tercetak di konsol server saat dinyalakan (atau diisi lewat HOST_PIN).
      </p>
      <input
        className="input"
        type="password"
        value={v}
        onChange={(e) => setV(e.target.value)}
        aria-label="PIN guru"
        autoFocus
      />
      <button className="btn utama" disabled={v.trim().length < 4}>
        Masuk
      </button>
      {galat ? (
        <div role="alert" style={{ color: "var(--merah)" }}>
          {galat}
        </div>
      ) : null}
    </form>
  );
}

const DEFAULT: SesiSettings = {
  nama: "Transit Rush",
  mode: "rush",
  usiaBawaan: 10,
  ranah: [...RANAH],
  levelMin: 1,
  levelMaks: 10,
  durasiMenit: 10,
  maksPerRanah: 8,
  semTarget: 0.6,
  rondeArena: 12,
  papanSkor: true,
  uji: false,
};
const NAMA_RANAH: Record<Ranah, string> = {
  memori: "Memori",
  spasial: "Spasial",
  numerik: "Numerik",
  logika: "Logika",
};
const KET_RANAH: Record<Ranah, string> = {
  memori: "Hafal rute dan urutan halte",
  spasial: "Arah, kotak peta, jarak",
  numerik: "Hitung halte, koin, jam",
  logika: "Rute terbaik, stasiun misteri",
};

function Saklar({
  nilai,
  ubah,
  judul,
  ket,
}: {
  nilai: boolean;
  ubah: (v: boolean) => void;
  judul: string;
  ket: string;
}): ReactElement {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={nilai}
      className={`saklar${nilai ? " on" : ""}`}
      onClick={() => ubah(!nilai)}
    >
      <span className="rel" aria-hidden>
        <i />
      </span>
      <span className="teks">
        <b>{judul}</b>
        <small>{ket}</small>
      </span>
    </button>
  );
}

const UTAMA: Mode[] = ["rush", "arena"];
const LAIN: Mode[] = ["profil", "latihan", "ekstrim"];
const DESKRIPSI: Record<Mode, string> = {
  rush: "Tiap murid main sendiri sekitar 10 menit. Soal menyesuaikan kemampuan, ada rapor per murid.",
  arena: "Satu kelas main serentak, ronde demi ronde, dengan papan skor langsung.",
  profil: "",
  latihan: "",
  ekstrim: "",
};
const PRESET: Record<Mode, Partial<SesiSettings>> = {
  rush: { durasiMenit: 10, maksPerRanah: 8, semTarget: 0.6, levelMin: 1, levelMaks: 10 },
  profil: { maksPerRanah: 12, semTarget: 0.45, levelMin: 1, levelMaks: 10 },
  latihan: { levelMin: 1, levelMaks: 10 },
  ekstrim: { levelMin: 8, levelMaks: 10 },
  arena: { rondeArena: 12, levelMin: 1, levelMaks: 6 },
};

function Buat({
  konteks,
  jadi,
}: {
  konteks: Konteks | null;
  jadi: (s: { id: string; pin: string }) => void;
}): ReactElement {
  const [s, setS] = useState<SesiSettings>({
    ...DEFAULT,
    nama: konteks?.kelas ? `Transit Rush ${konteks.kelas}` : "Transit Rush",
  });
  const [manual, setManual] = useState("");
  const [galat, setGalat] = useState("");
  const roster = konteks?.roster ?? parseManualNames(manual);
  const set = <K extends keyof SesiSettings>(k: K, v: SesiSettings[K]): void => setS((x) => ({ ...x, [k]: v }));
  async function buat(): Promise<void> {
    setGalat("");
    try {
      const r = await api<{ id: string; pin: string }>("/api/sessions", {
        host: true,
        body: {
          settings: s,
          roster: roster.map((x) => ({ id: x.id, name: x.name, ...(x.absen ? { absen: x.absen } : {}) })),
        },
      });
      jadi({ id: r.id, pin: r.pin });
    } catch (e) {
      setGalat((e as Error).message);
    }
  }
  return (
    <div className="kolom2">
      <div className="kartu" style={{ display: "grid", gap: 12 }}>
        <h2>Buat sesi</h2>
        <label className="f">
          Nama sesi
          <input className="input" value={s.nama} maxLength={60} onChange={(e) => set("nama", e.target.value)} />
        </label>
        <div className="f">
          Cara main
          <div className="mode-kartu-baris" role="radiogroup" aria-label="Cara main">
            {UTAMA.map((m) => (
              <button
                key={m}
                type="button"
                role="radio"
                aria-checked={s.mode === m}
                className={`mode-kartu${s.mode === m ? " on" : ""}`}
                onClick={() => setS((x) => ({ ...x, mode: m, ...PRESET[m] }))}
              >
                <b>{LABEL_MODE[m]}</b>
                <span>{DESKRIPSI[m]}</span>
              </button>
            ))}
          </div>
        </div>
        <details className="lanjutan">
          <summary>Pengaturan lanjutan</summary>
          <div style={{ display: "grid", gap: 12, paddingTop: 12 }}>
            <div className="f">
              Mode lain
              <div className="pilihan dua" role="radiogroup" aria-label="Mode lain">
                {LAIN.map((m) => (
                  <button
                    key={m}
                    type="button"
                    role="radio"
                    aria-checked={s.mode === m}
                    className={`opsi${s.mode === m ? " dipilih" : ""}`}
                    onClick={() => setS((x) => ({ ...x, mode: m, ...PRESET[m] }))}
                  >
                    {LABEL_MODE[m]}
                  </button>
                ))}
              </div>
            </div>{" "}
            <div className="f">
              Ranah yang diuji
              <div className="ranah-pilih" role="group" aria-label="Ranah yang diuji">
                {RANAH.map((d) => {
                  const on = s.ranah.includes(d);
                  const terakhir = on && s.ranah.length === 1;
                  return (
                    <button
                      key={d}
                      type="button"
                      aria-pressed={on}
                      disabled={terakhir}
                      title={terakhir ? "Minimal satu ranah harus aktif" : undefined}
                      className={`ranah-ubin ${d}${on ? " on" : ""}`}
                      onClick={() => set("ranah", on ? s.ranah.filter((x) => x !== d) : [...s.ranah, d])}
                    >
                      <LencanaLin ranah={d} />
                      <span className="nama">{NAMA_RANAH[d]}</span>
                      <span className="ket">{KET_RANAH[d]}</span>
                      <i className="centang" aria-hidden />
                    </button>
                  );
                })}
              </div>
              <div className="baris" style={{ gap: 6 }}>
                <button type="button" className="btn kecil hantu" onClick={() => set("ranah", [...RANAH])}>
                  Pilih semua
                </button>
                <span className="muted">{s.ranah.length} dari 4 ranah aktif</span>
              </div>
            </div>
            <div className="grid2">
              <label className="f">
                Level terendah
                <input
                  className="input"
                  type="number"
                  min={1}
                  max={10}
                  value={s.levelMin}
                  onChange={(e) => set("levelMin", Number(e.target.value))}
                />
              </label>
              <label className="f">
                Level tertinggi
                <input
                  className="input"
                  type="number"
                  min={1}
                  max={10}
                  value={s.levelMaks}
                  onChange={(e) => set("levelMaks", Number(e.target.value))}
                />
              </label>
              <label className="f">
                Usia bawaan
                <input
                  className="input"
                  type="number"
                  min={6}
                  max={80}
                  value={s.usiaBawaan}
                  onChange={(e) => set("usiaBawaan", Number(e.target.value))}
                />
              </label>
              {s.mode === "rush" ? (
                <label className="f">
                  Durasi (menit)
                  <input
                    className="input"
                    type="number"
                    min={1}
                    max={60}
                    value={s.durasiMenit}
                    onChange={(e) => set("durasiMenit", Number(e.target.value))}
                  />
                </label>
              ) : null}
              {s.mode === "rush" || s.mode === "profil" ? (
                <label className="f">
                  Maks soal per ranah
                  <input
                    className="input"
                    type="number"
                    min={1}
                    max={20}
                    value={s.maksPerRanah}
                    onChange={(e) => set("maksPerRanah", Number(e.target.value))}
                  />
                </label>
              ) : null}
              {s.mode === "rush" || s.mode === "profil" ? (
                <label className="f">
                  Target ketidakpastian (SEM)
                  <input
                    className="input"
                    type="number"
                    step={0.05}
                    min={0.2}
                    max={1.2}
                    value={s.semTarget}
                    onChange={(e) => set("semTarget", Number(e.target.value))}
                  />
                </label>
              ) : null}
              {s.mode === "arena" ? (
                <label className="f">
                  Jumlah ronde
                  <input
                    className="input"
                    type="number"
                    min={1}
                    max={30}
                    value={s.rondeArena}
                    onChange={(e) => set("rondeArena", Number(e.target.value))}
                  />
                </label>
              ) : null}
            </div>
            <div className="saklar-baris">
              <Saklar
                nilai={s.papanSkor}
                ubah={(v) => set("papanSkor", v)}
                judul="Papan skor"
                ket="Tampilkan peringkat langsung ke murid"
              />
              <Saklar
                nilai={s.uji}
                ubah={(v) => set("uji", v)}
                judul="Sesi uji"
                ket="Tidak ikut ringkasan hasil resmi"
              />
            </div>
          </div>
        </details>
        <button className="btn utama besar" onClick={() => void buat()} disabled={s.ranah.length === 0}>
          Buat sesi dan tampilkan PIN
        </button>
        {galat ? (
          <div role="alert" style={{ color: "var(--merah)" }}>
            {galat}
          </div>
        ) : null}
      </div>
      <div className="kartu" style={{ display: "grid", gap: 8, alignContent: "start" }}>
        <h2>Daftar murid</h2>
        {konteks ? (
          <>
            <p className="muted" style={{ margin: 0 }}>
              {roster.length} murid dikirim dari SIMPETERI. Murid memilih namanya sendiri; ID siswa SIMPETERI ikut
              tercatat di <code>summary.json</code>.
            </p>
            <div style={{ maxHeight: 260, overflow: "auto" }}>
              {roster.map((r) => (
                <div key={r.id} className="muted">
                  {r.absen}. {r.name}
                </div>
              ))}
            </div>
          </>
        ) : (
          <>
            <p className="muted" style={{ margin: 0 }}>
              Kosongkan bila murid boleh mengetik nama sendiri. Atau tempel satu nama per baris (maks 40).
            </p>
            <textarea
              className="input"
              rows={8}
              value={manual}
              onChange={(e) => setManual(e.target.value)}
              aria-label="Daftar nama"
            />
          </>
        )}
      </div>
    </div>
  );
}

function Jalankan({
  sesi,
  konteks,
  keluarSesi,
}: {
  sesi: { id: string; pin: string };
  konteks: Konteks | null;
  keluarSesi: () => void;
}): ReactElement {
  const sock = useRef<Socket | null>(null);
  const [st, setSt] = useState<StateSesi | null>(null);
  const [ex, setEx] = useState<HostExtra | null>(null);
  const [qr, setQr] = useState("");
  const [ringkas, setRingkas] = useState<RingkasanTR | null>(null);
  const [stat, setStat] = useState<Statistik | null>(null);
  const [rapor, setRapor] = useState<{ nama: string; sesi: string; rapor: Rapor } | null>(null);
  const [pesan, setPesan] = useState("");
  const daring = ex?.pemain.filter((p) => p.online).length ?? 0;
  const soalTotal = ex?.pemain.reduce((a, p) => a + p.soal, 0) ?? 0;
  const benarTotal = ex?.pemain.reduce((a, p) => a + p.benar, 0) ?? 0;
  const selesaiN = ex?.pemain.filter((p) => p.selesai).length ?? 0;
  const urlMurid = `${location.origin}${BASE}/?pin=${sesi.pin}`;

  useEffect(() => {
    const s = sambung({ peran: "host", hostToken: bacaHostToken(), sesiId: sesi.id });
    sock.current = s;
    s.on(EV.state, (p: StateSesi) => setSt(p));
    s.on(EV.host, (p: HostExtra) => setEx(p));
    s.on("connect_error", (e: Error) => setPesan(e.message));
    return () => void s.disconnect();
  }, [sesi.id]);
  useEffect(() => {
    void QRCode.toDataURL(urlMurid, { margin: 1, width: 220 }).then(setQr);
  }, [urlMurid]);
  const aksi = (ev: string): void => {
    sock.current?.emit(ev, {}, (r: { ok?: boolean; alasan?: string }) =>
      setPesan(r?.ok === false ? (r.alasan ?? "Gagal.") : ""),
    );
  };
  const selesai = st?.status === "selesai";
  useEffect(() => {
    if (!selesai) return;
    void api<RingkasanTR>(`/api/sessions/${sesi.id}/summary.json`, { host: true }).then(setRingkas, () => undefined);
    void api<Statistik>(`/api/sessions/${sesi.id}/statistik.json`, { host: true }).then(setStat, () => undefined);
  }, [selesai, sesi.id]);
  async function lihatRapor(pid: string): Promise<void> {
    try {
      setRapor(await api(`/api/sessions/${sesi.id}/rapor/${pid}`, { host: true }));
    } catch (e) {
      setPesan((e as Error).message);
    }
  }
  const kembali = konteks?.kembali && konteks.asal ? buildKembaliUrl(konteks.kembali, konteks.asal, sesi.id) : null;
  const bin = useMemo(() => {
    const b = Array.from({ length: 9 }, () => 0);
    for (const x of ringkas?.siswa ?? [])
      if (x.ikp !== null) b[Math.max(0, Math.min(8, Math.floor((x.ikp - 55) / 10)))]!++;
    return b;
  }, [ringkas]);
  const maksBin = Math.max(1, ...bin);
  const idxPlayer = (nama: string): string => ex?.pemain.find((p) => p.nama === nama)?.id ?? "";

  return (
    <>
      <div className="no-print" style={{ display: "grid", gap: 12 }}>
        <div className="kendali">
          <div className="qr">{qr ? <img src={qr} alt="QR untuk murid" /> : null}</div>
          <div className="isi">
            <div className="judul">
              <h2>{st?.nama ?? "Sesi"}</h2>
              <span className="status-titik" data-testid="status-mode">
                {st ? LABEL_MODE[st.mode] : ""}
              </span>
              <span className={`status-titik ${st?.status ?? ""}`} data-testid="status">
                {st?.status}
              </span>
            </div>
            <div>
              <span className="muted" style={{ color: "#aebdcd" }}>
                PIN murid
              </span>
              <div className="pin" data-testid="pin">
                {sesi.pin}
              </div>
              <div className="url">{urlMurid}</div>
            </div>
            <div className="tombol">
              {st?.status === "lobby" ? (
                <button className="btn utama" onClick={() => aksi("tr:host:mulai")} disabled={!st.pemain}>
                  Mulai ({st.pemain} pemain)
                </button>
              ) : null}
              {st?.mode === "arena" && st.status === "berjalan" ? (
                <button className="btn utama" onClick={() => aksi("tr:host:ronde")}>
                  Ronde berikut ({st.ronde}/{st.rondeTotal})
                </button>
              ) : null}
              {st && st.status !== "selesai" ? (
                <button className="btn hantu" onClick={() => aksi("tr:host:akhiri")}>
                  Akhiri sesi
                </button>
              ) : null}
              {selesai ? (
                <button className="btn utama" onClick={keluarSesi}>
                  Sesi baru
                </button>
              ) : null}
              {selesai && kembali ? (
                <a className="btn hantu" href={kembali}>
                  Kembali ke SIMPETERI dan impor hasil
                </a>
              ) : null}
              <a className="btn hantu" href={`${BASE}/display?pin=${sesi.pin}`} target="_blank" rel="noreferrer">
                Buka proyektor
              </a>
            </div>
            {pesan ? (
              <div role="alert" style={{ color: "#ff9d9d" }}>
                {pesan}
              </div>
            ) : null}
          </div>
        </div>

        <div className="kpi-baris" data-testid="kpi-langsung">
          <div className="kpi">
            <span>Pemain online</span>
            <b className="angka">
              {daring}/{ex?.pemain.length ?? 0}
            </b>
          </div>
          <div className="kpi">
            <span>Soal terjawab</span>
            <b className="angka">{soalTotal}</b>
          </div>
          <div className="kpi">
            <span>Ketepatan kelas</span>
            <b className="angka">{soalTotal ? `${Math.round((100 * benarTotal) / soalTotal)}%` : "—"}</b>
          </div>
          <div className="kpi">
            <span>Selesai</span>
            <b className="angka">
              {selesaiN}/{ex?.pemain.length ?? 0}
            </b>
          </div>
          {st?.mode === "arena" ? (
            <div className="kpi">
              <span>
                Ronde {st.ronde}/{st.rondeTotal}
                {st.rondeInfo ? ` · ${st.rondeInfo.nama}` : ""}
              </span>
              <b className="angka">
                {st.rondeTerjawab}/{st.pemain}
              </b>
              <div className="bar-mini">
                <i style={{ width: `${st.pemain ? (100 * st.rondeTerjawab) / st.pemain : 0}%` }} />
              </div>
            </div>
          ) : null}
        </div>

        <div className="live-grid">
          <div className="kartu">
            <h2 style={{ marginBottom: 10 }}>Peringkat langsung</h2>
            {st?.papan.length ? (
              <Peringkat papan={st.papan} maks={10} />
            ) : (
              <div className="muted">
                {st?.status === "lobby"
                  ? "Peringkat muncul setelah sesi dimulai."
                  : "Papan skor dimatikan atau belum ada poin."}
              </div>
            )}
          </div>
          <div className="kartu">
            <h2 style={{ marginBottom: 10 }}>Pemain ({ex?.pemain.length ?? 0}/40)</h2>
            <div className="pemain-list">
              {ex?.pemain.length ? (
                ex.pemain.map((p) => (
                  <div className="pemain-baris" key={p.id}>
                    <span className={`dot${p.online ? " on" : ""}`} title={p.online ? "online" : "terputus"} />
                    <div style={{ minWidth: 0 }}>
                      <div className="nm">
                        <span>{p.nama}</span>
                        {p.selesai ? <small className="muted">selesai</small> : null}
                        {p.bendera ? <span className="bendera">{p.bendera}</span> : null}
                      </div>
                      <div className="mini">
                        <i style={{ width: `${p.soal ? (100 * p.benar) / p.soal : 0}%` }} />
                      </div>
                    </div>
                    <div className="angka-kecil">
                      {p.poin} poin
                      <div className="muted" style={{ fontWeight: 500 }}>
                        {p.benar}/{p.soal} benar
                      </div>
                    </div>
                  </div>
                ))
              ) : (
                <div className="muted">Belum ada pemain. Bagikan PIN atau QR di atas.</div>
              )}
            </div>
          </div>
        </div>
      </div>
      {selesai && ringkas ? (
        <div className="kartu no-print" style={{ display: "grid", gap: 10 }}>
          <div className="baris" style={{ justifyContent: "space-between" }}>
            <h2>Hasil kelas</h2>
            <div className="baris">
              <button
                className="btn kecil hantu"
                onClick={() => void unduh(`/api/sessions/${sesi.id}/results.csv`, `transit-rush-${sesi.id}.csv`)}
              >
                Ekspor CSV
              </button>
              <button
                className="btn kecil hantu"
                onClick={() => void unduh(`/api/sessions/${sesi.id}/summary.json`, `summary-${sesi.id}.json`)}
              >
                summary.json
              </button>
            </div>
          </div>
          <table className="tabel">
            <thead>
              <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Poin</th>
                <th>Benar</th>
                <th>IKP (rentang 90%)</th>
                <th>Level</th>
                <th>Tipe</th>
                <th>Bendera</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {ringkas.siswa.map((x) => (
                <tr key={x.nama}>
                  <td>{x.peringkat}</td>
                  <td>{x.nama}</td>
                  <td>{x.skor}</td>
                  <td>
                    {x.benar}/{x.soal}
                  </td>
                  <td>{x.ikp === null ? "—" : `${x.ikp} (${x.ikpRentang90![0]}–${x.ikpRentang90![1]})`}</td>
                  <td>{x.levelPenjelajah ?? "—"}</td>
                  <td>{x.tipe ?? "—"}</td>
                  <td>{x.bendera || ""}</td>
                  <td>
                    {x.soal ? (
                      <button className="btn kecil hantu" onClick={() => void lihatRapor(idxPlayer(x.nama))}>
                        Rapor
                      </button>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          <div className="kolom2">
            <div>
              <div className="muted">Sebaran IKP kelas (norma sementara)</div>
              <div className="jejak" style={{ height: 80 }} aria-label="Histogram IKP">
                {bin.map((n, i) => (
                  <i
                    key={i}
                    title={`${55 + i * 10}–${64 + i * 10}: ${n} murid`}
                    style={{ height: `${(n / maksBin) * 100}%`, minHeight: 2, background: "#0f1b2d" }}
                  />
                ))}
              </div>
              <div className="baris muted" style={{ justifyContent: "space-between" }}>
                <span>55</span>
                <span>100</span>
                <span>145</span>
              </div>
            </div>
            {stat ? (
              <div>
                <div className="muted">Ketepatan kelas per ranah</div>
                {RANAH.map((d) => (
                  <div key={d} className="baris" style={{ justifyContent: "space-between" }}>
                    <span style={{ color: WARNA_RANAH[d], fontWeight: 700, textTransform: "capitalize" }}>{d}</span>
                    <span>
                      {stat.ranah[d]?.tepat === null || stat.ranah[d]?.tepat === undefined
                        ? "—"
                        : `${Math.round(stat.ranah[d]!.tepat! * 100)}% dari ${stat.ranah[d]!.soal} soal`}
                    </span>
                  </div>
                ))}
                <div className="muted" style={{ marginTop: 8 }}>
                  Butir terlalu mudah (≥95% benar):{" "}
                  {stat.terlaluMudah.map((b) => `${b.nama} L${b.level}`).join(", ") || "—"}
                </div>
                <div className="muted">
                  Butir terlalu sulit (≤15% benar):{" "}
                  {stat.terlaluSulit.map((b) => `${b.nama} L${b.level}`).join(", ") || "—"}
                </div>
                <div className="muted">
                  Bendera (tidak menghukum):{" "}
                  {stat.bendera.length ? stat.bendera.map((b) => `${b.pemain}: ${b.jenis}`).join("; ") : "tidak ada"}
                </div>
              </div>
            ) : null}
          </div>
          {stat?.perilaku && stat.perilaku.pemain > 0 ? (
            <div data-testid="perilaku-kelas" style={{ display: "grid", gap: 8 }}>
              <div className="muted">Perilaku bermain kelas</div>
              <div className="ubin-baris">
                <div className="ubin">
                  <span className="muted">Waktu median rata-rata</span>
                  <b className="angka">{stat.perilaku.medianDetikRata ?? "—"} dtk</b>
                </div>
                <div className="ubin">
                  <span className="muted">Pakai waktu</span>
                  <b className="angka">{stat.perilaku.pakaiWaktuRata ?? "—"}%</b>
                </div>
                <div className="ubin">
                  <span className="muted">Kehabisan waktu</span>
                  <b className="angka">{stat.perilaku.habisTotal}</b>
                </div>
                <div className="ubin">
                  <span className="muted">Jawaban terburu-buru</span>
                  <b className="angka">{stat.perilaku.gegabahTotal}</b>
                </div>
                <div className="ubin">
                  <span className="muted">Tren naik / turun</span>
                  <b className="angka">
                    {stat.perilaku.trenNaik} / {stat.perilaku.trenTurun}
                  </b>
                </div>
              </div>
              <div className="muted">
                Gaya bermain:{" "}
                {Object.entries(stat.perilaku.gaya)
                  .map(([g, n]) => `${g} (${n})`)
                  .join(" · ") || "—"}
              </div>
            </div>
          ) : null}
        </div>
      ) : null}
      {rapor ? (
        <div style={{ display: "grid", gap: 8 }}>
          <div className="baris no-print">
            <button className="btn utama kecil" onClick={() => window.print()}>
              Cetak / simpan PDF (A4)
            </button>
            <button className="btn hantu kecil" onClick={() => setRapor(null)}>
              Tutup rapor
            </button>
          </div>
          <RaporView rapor={rapor.rapor} nama={rapor.nama} sesi={rapor.sesi} />
        </div>
      ) : null}
    </>
  );
}

function EditorJaringan(): ReactElement {
  const [asli, setAsli] = useState<DataJaringan | null>(null);
  const [gambar, setGambar] = useState<PetaGambar | undefined>(undefined);
  const [draft, setDraft] = useState<DataJaringan | null>(null);
  const [pilih, setPilih] = useState<string | null>(null);
  const [diperiksa, setDiperiksa] = useState<string[]>([]);
  const [pesan, setPesan] = useState("");
  const muat = (): void =>
    void ambilPeta(true).then(
      (r) => (
        setAsli(r.data),
        setGambar(r.gambar),
        setDraft(JSON.parse(JSON.stringify(r.data)) as DataJaringan),
        setDiperiksa([])
      ),
    );
  useEffect(muat, []);
  const model = useMemo(() => (draft ? bangunPeta(draft, gambar) : null), [draft, gambar]);
  if (!draft || !asli || !model) return <div className="kartu muted">Memuat jaringan…</div>;
  const berubah = draft.halte.filter((h, i) => h.x !== asli.halte[i]!.x || h.y !== asli.halte[i]!.y);
  const perkiraan = draft.halte.filter((h) => h.posisi_perkiraan);
  const sel = pilih ? draft.halte.find((h) => h.nama === pilih) : undefined;
  const geser = (nama: string, x: number, y: number): void =>
    setDraft((d) => (d ? { ...d, halte: d.halte.map((h) => (h.nama === nama ? { ...h, x, y } : h)) } : d));
  async function simpan(): Promise<void> {
    try {
      const posisi = Object.fromEntries(berubah.map((h) => [h.nama, { x: h.x, y: h.y }]));
      await api("/api/network", { method: "PUT", host: true, body: { posisi, diperiksa } });
      setPesan(
        `Tersimpan: ${berubah.length} posisi, ${diperiksa.length} halte ditandai dicek. Berlaku untuk soal baru.`,
      );
      muat();
    } catch (e) {
      setPesan((e as Error).message);
    }
  }
  const cek = Object.values(draft.lin).flatMap((l) =>
    ((l as { segmen_perlu_cek?: number[] }).segmen_perlu_cek ?? []).map(
      (i) => `${l.nama}: ${l.halte[i]} → ${l.halte[i + 1]}`,
    ),
  );
  return (
    <div className="kolom2">
      <div style={{ display: "grid", gap: 8 }}>
        <TransitMap
          model={model}
          opsi={{ label: true }}
          tinggi={520}
          editor={{ terpilih: pilih, onPilih: setPilih, onGeser: geser }}
        />
        <div className="muted">
          Ketuk halte untuk memilih; seret untuk memindahkan. Lingkaran putus-putus oranye = posisi masih perkiraan.
          Garis putus-putus = segmen perlu dicek.
        </div>
      </div>
      <div className="kartu" style={{ display: "grid", gap: 8, alignContent: "start" }}>
        <h2>Editor jaringan</h2>
        <div className="muted">
          {perkiraan.length} dari {draft.halte.length} halte masih posisi perkiraan · {cek.length} segmen perlu dicek.
        </div>
        {sel ? (
          <div className="kartu" data-testid="halte-terpilih">
            <b>{sel.nama}</b> <span className="muted">sel {sel.grid}</span>
            <div className="grid2" style={{ marginTop: 6 }}>
              <label className="f">
                x
                <input
                  className="input"
                  type="number"
                  value={sel.x}
                  onChange={(e) => geser(sel.nama, Number(e.target.value), sel.y)}
                />
              </label>
              <label className="f">
                y
                <input
                  className="input"
                  type="number"
                  value={sel.y}
                  onChange={(e) => geser(sel.nama, sel.x, Number(e.target.value))}
                />
              </label>
            </div>
            <button
              className="btn kecil hantu"
              style={{ marginTop: 6 }}
              onClick={() => setDiperiksa([...new Set([...diperiksa, sel.nama])])}
            >
              Tandai sudah dicek{diperiksa.includes(sel.nama) ? " ✓" : ""}
            </button>
          </div>
        ) : (
          <div className="muted">Belum ada halte dipilih.</div>
        )}
        <button
          className="btn utama"
          disabled={berubah.length === 0 && diperiksa.length === 0}
          onClick={() => void simpan()}
        >
          Simpan perbaikan ({berubah.length} posisi, {diperiksa.length} dicek)
        </button>
        {pesan ? <div role="status">{pesan}</div> : null}
        <details>
          <summary>Segmen yang perlu dicek manusia</summary>
          {cek.map((c) => (
            <div key={c} className="muted">
              {c}
            </div>
          ))}
        </details>
        <MapCredit tema="terang" atribusi />
      </div>
    </div>
  );
}

function Kalibrasi({ sesiId }: { sesiId: string | null }): ReactElement {
  return (
    <div className="kartu" style={{ display: "grid", gap: 10, maxWidth: 720 }}>
      <h2>Kalibrasi & norma</h2>
      <p style={{ margin: 0 }}>
        Norma bawaan <b>masih sementara</b> dan ditandai di setiap rapor. Setelah ±100 murid per kelompok usia bermain,
        ekspor jawaban lalu jalankan
        <code> npm run calibrate -- jawaban.csv</code> di komputer server. Hasilnya <code>data/kalibrasi.json</code>{" "}
        (kesulitan butir dan norma per usia) dibaca server saat dinyalakan ulang.
      </p>
      <div className="baris">
        <button
          className="btn hantu"
          disabled={!sesiId}
          onClick={() => sesiId && void unduh(`/api/sessions/${sesiId}/jawaban.csv`, `jawaban-${sesiId}.csv`)}
        >
          Ekspor jawaban sesi ini (CSV kalibrasi)
        </button>
        {!sesiId ? <span className="muted">Buat atau buka sesi dulu.</span> : null}
      </div>
    </div>
  );
}

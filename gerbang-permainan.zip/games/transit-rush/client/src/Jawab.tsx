// Enam tipe jawaban: pilihan, urutan (susun), teks (kotak peta / kode), angka, jam, ketuk peta.
import { useState } from "react";
import type { ReactElement } from "react";
import type { ItemKlien, PetaModel } from "@transit-rush/shared";
import { TransitMap } from "./TransitMap";

interface Props {
  item: ItemKlien;
  model: PetaModel;
  kunci: boolean;
  kirim: (resp: unknown) => void;
}

export function Jawab({ item, model, kunci, kirim }: Props): ReactElement {
  switch (item.tipe) {
    case "pilihan":
      return (
        <div
          className={`pilihan${(item.pilihan?.length ?? 0) <= 2 ? " dua" : ""}`}
          role="group"
          aria-label="Pilihan jawaban"
        >
          {item.pilihan?.map((p, n) => (
            <button key={p} type="button" className="opsi" disabled={kunci} onClick={() => kirim(p)}>
              <span className="i" aria-hidden>
                {String.fromCharCode(65 + n)}
              </span>
              {p}
            </button>
          ))}
        </div>
      );
    case "urutan":
      return <Susun item={item} kunci={kunci} kirim={kirim} />;
    case "angka":
      return <Angka kunci={kunci} kirim={kirim} />;
    case "jam":
      return <Jam kunci={kunci} kirim={kirim} />;
    case "ketuk":
      return <Ketuk item={item} model={model} kunci={kunci} kirim={kirim} />;
    default:
      return item.family === "grid" ? <KotakGrid kunci={kunci} kirim={kirim} /> : <Teks kunci={kunci} kirim={kirim} />;
  }
}

function Susun({ item, kunci, kirim }: Pick<Props, "item" | "kunci" | "kirim">): ReactElement {
  const [urut, setUrut] = useState<string[]>([]);
  return (
    <div className="grid" style={{ display: "grid", gap: 8 }}>
      <div className="susun" aria-label="Urutan jawabanmu" data-testid="susun">
        {urut.length === 0 ? <span className="muted">Ketuk halte sesuai urutan…</span> : null}
        {urut.map((s, i) => (
          <span key={s} className="tag">
            <b>{i + 1}</b> {s}
          </span>
        ))}
      </div>
      <div className="pilihan dua">
        {item.pilihan?.map((p) => (
          <button
            key={p}
            type="button"
            className={`opsi${urut.includes(p) ? " dipilih" : ""}`}
            disabled={kunci || urut.includes(p)}
            onClick={() => setUrut([...urut, p])}
          >
            {p}
          </button>
        ))}
      </div>
      <div className="baris">
        <button
          type="button"
          className="btn hantu kecil"
          disabled={kunci || urut.length === 0}
          onClick={() => setUrut(urut.slice(0, -1))}
        >
          Hapus terakhir
        </button>
        <button
          type="button"
          className="btn hantu kecil"
          disabled={kunci || urut.length === 0}
          onClick={() => setUrut([])}
        >
          Ulang
        </button>
        <span style={{ flex: 1 }} />
        <button type="button" className="btn utama" disabled={kunci || urut.length === 0} onClick={() => kirim(urut)}>
          Kirim urutan
        </button>
      </div>
    </div>
  );
}

function Angka({ kunci, kirim }: Pick<Props, "kunci" | "kirim">): ReactElement {
  const [v, setV] = useState("");
  const tombol = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "⌫", "0", "−"];
  const ketik = (k: string): void => {
    if (k === "⌫") return setV(v.slice(0, -1));
    if (k === "−") return setV(v.startsWith("-") ? v.slice(1) : "-" + v);
    if (v.replace("-", "").length < 6) setV(v + k);
  };
  return (
    <div style={{ display: "grid", gap: 8 }}>
      <div className="layar-angka" aria-live="polite" data-testid="layar-angka">
        {v || "…"}
      </div>
      <div className="numpad">
        {tombol.map((k) => (
          <button
            key={k}
            type="button"
            disabled={kunci}
            onClick={() => ketik(k)}
            aria-label={k === "⌫" ? "Hapus" : k === "−" ? "Tanda minus" : k}
          >
            {k}
          </button>
        ))}
      </div>
      <button type="button" className="btn utama besar" disabled={kunci || !/^-?\d+$/.test(v)} onClick={() => kirim(v)}>
        Kirim jawaban
      </button>
    </div>
  );
}

function Jam({ kunci, kirim }: Pick<Props, "kunci" | "kirim">): ReactElement {
  const [j, setJ] = useState(8);
  const [m, setM] = useState(0);
  const p2 = (n: number): string => String(n).padStart(2, "0");
  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div className="jam" aria-live="polite" data-testid="jam">
        <div className="step">
          <button type="button" disabled={kunci} onClick={() => setJ((j + 1) % 24)} aria-label="Jam naik">
            ▲
          </button>
          <span>{p2(j)}</span>
          <button type="button" disabled={kunci} onClick={() => setJ((j + 23) % 24)} aria-label="Jam turun">
            ▼
          </button>
        </div>
        :
        <div className="step">
          <button type="button" disabled={kunci} onClick={() => setM((m + 1) % 60)} aria-label="Menit naik">
            ▲
          </button>
          <span>{p2(m)}</span>
          <button type="button" disabled={kunci} onClick={() => setM((m + 59) % 60)} aria-label="Menit turun">
            ▼
          </button>
        </div>
      </div>
      <div className="baris" style={{ justifyContent: "center" }}>
        {[5, 10].map((d) => (
          <button key={d} type="button" className="btn hantu kecil" disabled={kunci} onClick={() => setM((m + d) % 60)}>
            +{d} menit
          </button>
        ))}
      </div>
      <button type="button" className="btn utama besar" disabled={kunci} onClick={() => kirim(`${p2(j)}:${p2(m)}`)}>
        Kirim jam
      </button>
    </div>
  );
}

function KotakGrid({ kunci, kirim }: Pick<Props, "kunci" | "kirim">): ReactElement {
  const [baris, setBaris] = useState("");
  const [kolom, setKolom] = useState("");
  return (
    <div style={{ display: "grid", gap: 8 }}>
      <div className="muted">Pilih baris (A–F) lalu kolom (1–8)</div>
      <div className="kisi" style={{ gridTemplateColumns: "repeat(6, 1fr)" }}>
        {[..."ABCDEF"].map((h) => (
          <button
            key={h}
            type="button"
            className={baris === h ? "on" : ""}
            disabled={kunci}
            onClick={() => setBaris(h)}
          >
            {h}
          </button>
        ))}
      </div>
      <div className="kisi">
        {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
          <button
            key={n}
            type="button"
            className={kolom === String(n) ? "on" : ""}
            disabled={kunci}
            onClick={() => setKolom(String(n))}
          >
            {n}
          </button>
        ))}
      </div>
      <button
        type="button"
        className="btn utama besar"
        disabled={kunci || !baris || !kolom}
        onClick={() => kirim(baris + kolom)}
      >
        Kirim {baris && kolom ? baris + kolom : "kotak"}
      </button>
    </div>
  );
}

function Teks({ kunci, kirim }: Pick<Props, "kunci" | "kirim">): ReactElement {
  const [v, setV] = useState("");
  return (
    <form
      style={{ display: "grid", gap: 8 }}
      onSubmit={(e) => {
        e.preventDefault();
        if (v.trim()) kirim(v.trim());
      }}
    >
      <input
        className="input"
        value={v}
        onChange={(e) => setV(e.target.value)}
        disabled={kunci}
        placeholder="Ketik jawaban, mis. 3-9"
        autoComplete="off"
        autoCapitalize="off"
        aria-label="Jawaban"
      />
      <button type="submit" className="btn utama besar" disabled={kunci || !v.trim()}>
        Kirim jawaban
      </button>
    </form>
  );
}

function Ketuk({ item, model, kunci, kirim }: Props): ReactElement {
  const [titik, setTitik] = useState<{ x: number; y: number } | null>(null);
  return (
    <div style={{ display: "grid", gap: 8 }}>
      <TransitMap
        model={model}
        opsi={item.peta}
        tinggi={360}
        onTap={(x, y) => !kunci && setTitik({ x: Math.round(x), y: Math.round(y) })}
        tanda={titik ? [titik] : []}
      />
      <button
        type="button"
        className="btn utama besar"
        disabled={kunci || !titik}
        onClick={() => titik && kirim(titik)}
      >
        {titik ? "Kunci jawaban" : "Ketuk letaknya di peta"}
      </button>
    </div>
  );
}

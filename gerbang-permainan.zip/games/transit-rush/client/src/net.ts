import { useEffect, useState } from "react";
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { bangunPeta } from "@transit-rush/shared";
import type { DataJaringan, PetaGambar, PetaModel } from "@transit-rush/shared";
import { url } from "./url";

export const KUNCI_HOST = "tr.hostToken";
export const bacaHostToken = (): string => {
  try {
    return sessionStorage.getItem(KUNCI_HOST) ?? "";
  } catch {
    return "";
  }
};
export const simpanHostToken = (t: string): void => {
  try {
    sessionStorage.setItem(KUNCI_HOST, t);
  } catch {
    /* penyimpanan diblokir */
  }
};

export async function api<T = unknown>(
  path: string,
  o: { method?: string; body?: unknown; host?: boolean } = {},
): Promise<T> {
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (o.host) headers["x-host-token"] = bacaHostToken();
  const r = await fetch(url(path), {
    method: o.method ?? (o.body !== undefined ? "POST" : "GET"),
    headers,
    body: o.body !== undefined ? JSON.stringify(o.body) : undefined,
  });
  const j = (await r.json().catch(() => ({}))) as T & { error?: string };
  if (!r.ok) throw new Error(j.error ?? `Gagal (${r.status})`);
  return j;
}

export function sambung(auth: Record<string, unknown>): Socket {
  return io(location.origin, {
    path: url("/socket.io"),
    auth,
    transports: ["websocket", "polling"],
    reconnectionDelay: 800,
  });
}

export interface KonfigServer {
  level: string[];
  mode: Record<string, { label: string }>;
  maksArena: number;
  footer: { teks: string; logo: { nama: string; url: string } | null };
  watermark: { teks: string; atribusi: string; opasitas: number; logo: { nama: string; url: string }[] };
  norma: string;
  keluarga: Record<string, { key: string; nama: string }[]>;
}

let cacheKonfig: Promise<KonfigServer> | null = null;
export const ambilKonfig = (): Promise<KonfigServer> => (cacheKonfig ??= api<KonfigServer>("/api/config"));

let cachePeta: Promise<{ versi: number; model: PetaModel; data: DataJaringan; gambar: PetaGambar }> | null = null;
export const ambilPeta = (
  segar = false,
): Promise<{ versi: number; model: PetaModel; data: DataJaringan; gambar: PetaGambar }> => {
  if (segar) cachePeta = null;
  return (cachePeta ??= api<{ versi: number; data: DataJaringan; gambar: PetaGambar }>("/api/network").then((r) => ({
    versi: r.versi,
    data: r.data,
    gambar: r.gambar,
    model: bangunPeta(r.data, r.gambar),
  })));
};

export function useAsync<T>(f: () => Promise<T>, deps: unknown[] = []): { data: T | null; error: string | null } {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  useEffect(() => {
    let batal = false;
    f().then(
      (d) => !batal && setData(d),
      (e: Error) => !batal && setError(e.message),
    );
    return () => {
      batal = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, deps);
  return { data, error };
}

// Papan peringkat langsung: baris berpindah dengan animasi, poin berhitung naik, panah naik/turun sesaat setelah posisi berubah.
import { useEffect, useRef, useState } from "react";
import type { ReactElement } from "react";
import type { SkorPublik } from "@transit-rush/shared";

/** Angka yang berhitung halus menuju nilai baru. */
export function useHitungNaik(target: number, ms = 600): number {
  const [nilai, setNilai] = useState(target);
  const dari = useRef(target);
  useEffect(() => {
    const mulai = performance.now();
    const awal = dari.current;
    if (awal === target) return;
    let id = 0;
    const langkah = (t: number): void => {
      const f = Math.min(1, (t - mulai) / ms);
      const e = 1 - Math.pow(1 - f, 3);
      const v = Math.round(awal + (target - awal) * e);
      setNilai(v);
      dari.current = v;
      if (f < 1) id = requestAnimationFrame(langkah);
    };
    id = requestAnimationFrame(langkah);
    return () => cancelAnimationFrame(id);
  }, [target, ms]);
  return nilai;
}

export function Angka({ n, className }: { n: number; className?: string }): ReactElement {
  const v = useHitungNaik(n);
  return <span className={`angka ${className ?? ""}`}>{v}</span>;
}

interface Props {
  papan: readonly SkorPublik[];
  saya?: string | null;
  maks?: number;
  /** tinggi satu baris (px); harus sama dengan CSS .per-baris */
  tinggi?: number;
  gelap?: boolean;
  /** tampilkan batang proporsional poin */
  batang?: boolean;
  /** tampilkan nama baris "saya" di bawah bila di luar peringkat teratas */
  tambahSaya?: boolean;
}

export function Peringkat({
  papan,
  saya,
  maks = 10,
  tinggi = 52,
  gelap = false,
  batang = true,
  tambahSaya = false,
}: Props): ReactElement {
  const prev = useRef(new Map<string, number>());
  const [gerak, setGerak] = useState<Record<string, "naik" | "turun">>({});
  useEffect(() => {
    const baru: Record<string, "naik" | "turun"> = {};
    papan.forEach((p, i) => {
      const lama = prev.current.get(p.id);
      if (lama !== undefined && lama !== i) baru[p.id] = i < lama ? "naik" : "turun";
    });
    prev.current = new Map(papan.map((p, i) => [p.id, i]));
    if (Object.keys(baru).length === 0) return;
    setGerak((g) => ({ ...g, ...baru }));
    const t = setTimeout(
      () =>
        setGerak((g) => {
          const c = { ...g };
          for (const k of Object.keys(baru)) delete c[k];
          return c;
        }),
      4500,
    );
    return () => clearTimeout(t);
  }, [papan]);

  const teratas = papan.slice(0, maks);
  const puncak = Math.max(1, ...papan.map((p) => p.poin));
  const idxSaya = saya ? papan.findIndex((p) => p.id === saya) : -1;
  const diLuar = tambahSaya && idxSaya >= maks ? papan[idxSaya]! : null;
  const baris = (p: SkorPublik, i: number, atas: number): ReactElement => (
    <div
      key={p.id}
      className={`per-baris${p.id === saya ? " saya" : ""}${i < 3 ? ` m${i + 1}` : ""}${gerak[p.id] ? ` ${gerak[p.id]}` : ""}${p.online === false ? " luring" : ""}`}
      style={{ transform: `translateY(${atas}px)`, height: tinggi - 6 }}
      data-testid={`per-${i + 1}`}
    >
      {batang ? <i className="per-batang" style={{ width: `${Math.max(3, (p.poin / puncak) * 100)}%` }} /> : null}
      <b className="per-no">{i + 1}</b>
      <span className="per-nama">{p.nama}</span>
      {gerak[p.id] ? (
        <em className="per-gerak" aria-label={gerak[p.id] === "naik" ? "naik" : "turun"}>
          {gerak[p.id] === "naik" ? "▲" : "▼"}
        </em>
      ) : null}
      {p.streak >= 3 ? <small className="per-api">{p.streak}×</small> : null}
      <Angka n={p.poin} className="per-poin" />
    </div>
  );
  return (
    <div className={`peringkat${gelap ? " gelap" : ""}`} data-testid="peringkat">
      <div className="per-daftar" style={{ height: Math.max(1, teratas.length) * tinggi }}>
        {teratas.map((p, i) => baris(p, i, i * tinggi))}
      </div>
      {diLuar ? (
        <>
          <div className="per-titik" aria-hidden>
            ⋯
          </div>
          <div className="per-daftar" style={{ height: tinggi }}>
            {baris(diLuar, idxSaya, 0)}
          </div>
        </>
      ) : null}
      {papan.length === 0 ? <div className="muted per-kosong">Belum ada poin.</div> : null}
    </div>
  );
}

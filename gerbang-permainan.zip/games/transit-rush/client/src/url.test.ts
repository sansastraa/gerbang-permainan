import { describe, expect, it } from "vitest";
import { gabungJalur, normalisasiBase } from "./url";

describe("penyusun URL dengan awalan jalur", () => {
  it("normalisasi awalan", () => {
    expect(normalisasiBase("/")).toBe("");
    expect(normalisasiBase("")).toBe("");
    expect(normalisasiBase(undefined)).toBe("");
    expect(normalisasiBase("/games/transit-rush/")).toBe("/games/transit-rush");
    expect(normalisasiBase("games/transit-rush")).toBe("/games/transit-rush");
  });
  it("gabungJalur untuk api, socket.io, dan halaman", () => {
    expect(gabungJalur("/games/transit-rush", "/api/lookup")).toBe("/games/transit-rush/api/lookup");
    expect(gabungJalur("/games/transit-rush/", "socket.io")).toBe("/games/transit-rush/socket.io");
    expect(gabungJalur("", "/watch?pin=123456")).toBe("/watch?pin=123456");
    expect(gabungJalur("/", "/obs")).toBe("/obs");
  });
});

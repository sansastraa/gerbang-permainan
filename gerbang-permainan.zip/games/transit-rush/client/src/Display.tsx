// Proyektor: lobi dengan tiket nama yang bermunculan, papan peringkat hidup, soal ronde berjalan, podium dan konfeti di akhir.
// Interaktif: tombol/pintasan 1 (papan), 2 (statistik), F (layar penuh).
import { useEffect, useMemo, useState } from "react";
import type { ReactElement } from "react";
import QRCode from "qrcode";
import { EV, LABEL_MODE } from "@transit-rush/shared";
import type { StateSesi } from "@transit-rush/shared";
import { MapCredit } from "./MapCredit";
import { Angka, Peringkat } from "./Peringkat";
import { sambung } from "./net";
import { Digits, LatarJalur, LencanaLin } from "./ui";
import { BASE } from "./url";

const WARNA_KONFETI = ["#d7282f", "#f28c28", "#ffc20e", "#2e8b57", "#0084c7", "#7b5ea7", "#e7417a"];

function Konfeti(): ReactElement {
  const potong = useMemo(
    () =>
      Array.from({ length: 56 }, (_, i) => ({
        k: i,
        kiri: (i * 37) % 100,
        tunda: ((i * 53) % 40) / 10,
        dur: 3.6 + ((i * 13) % 30) / 10,
        c: WARNA_KONFETI[i % WARNA_KONFETI.length]!,
        w: 8 + (i % 4) * 3,
      })),
    [],
  );
  return (
    <div className="konfeti" aria-hidden>
      {potong.map((p) => (
        <i
          key={p.k}
          style={{
            left: `${p.kiri}%`,
            animationDelay: `${p.tunda}s`,
            animationDuration: `${p.dur}s`,
            background: p.c,
            width: p.w,
            height: p.w * 1.6,
          }}
        />
      ))}
    </div>
  );
}

function Podium({ papan }: { papan: StateSesi["papan"] }): ReactElement {
  const urut = [papan[1], papan[0], papan[2]];
  const tinggi = [62, 100, 44];
  const peringkat = [2, 1, 3];
  return (
    <div className="podium" data-testid="podium">
      {urut.map((p, i) =>
        p ? (
          <div key={p.id} className={`pod pod${peringkat[i]}`}>
            <div className="pod-nama">{p.nama}</div>
            <div className="pod-poin">
              <Angka n={p.poin} /> poin
            </div>
            <div
              className="pod-tiang"
              style={{ height: `${tinggi[i]}%`, animationDelay: `${(3 - peringkat[i]!) * 0.35}s` }}
            >
              <b>{peringkat[i]}</b>
            </div>
          </div>
        ) : (
          <div key={`kosong${i}`} className="pod" />
        ),
      )}
    </div>
  );
}

export function Display(): ReactElement {
  const pin = new URLSearchParams(location.search).get("pin") ?? "";
  const [st, setSt] = useState<StateSesi | null>(null);
  const [qr, setQr] = useState("");
  const [galat, setGalat] = useState("");
  const [view, setView] = useState<"papan" | "statistik">("papan");
  const [penuh, setPenuh] = useState(false);
  const urlMurid = `${location.origin}${BASE}/?pin=${pin}`;

  useEffect(() => {
    if (!/^\d{6}$/.test(pin)) return setGalat("Tambahkan ?pin=<PIN sesi> pada alamat ini.");
    const s = sambung({ peran: "display", pin });
    s.on(EV.state, (p: StateSesi) => setSt(p));
    s.on("connect_error", (e: Error) => setGalat(e.message));
    return () => void s.disconnect();
  }, [pin]);
  useEffect(() => {
    if (pin) void QRCode.toDataURL(urlMurid, { margin: 1, width: 360 }).then(setQr);
  }, [pin, urlMurid]);
  const layarPenuh = (): void => {
    if (document.fullscreenElement) void document.exitFullscreen();
    else void document.documentElement.requestFullscreen?.();
  };
  useEffect(() => {
    const k = (e: KeyboardEvent): void => {
      if (e.key === "1") setView("papan");
      else if (e.key === "2") setView("statistik");
      else if (e.key.toLowerCase() === "f") layarPenuh();
    };
    const fs = (): void => setPenuh(!!document.fullscreenElement);
    window.addEventListener("keydown", k);
    document.addEventListener("fullscreenchange", fs);
    return () => {
      window.removeEventListener("keydown", k);
      document.removeEventListener("fullscreenchange", fs);
    };
  }, []);

  const lobi = !st || st.status === "lobby";
  const selesai = st?.status === "selesai";
  const akurasi = st && st.soalTotal ? Math.round((100 * st.benarTotal) / st.soalTotal) : 0;
  const terbaik = st ? Math.max(0, ...st.papan.map((p) => p.streak)) : 0;
  const rata = st && st.papan.length ? Math.round(st.papan.reduce((a, p) => a + p.poin, 0) / st.papan.length) : 0;
  const arena = st?.mode === "arena";
  const persenJawab = st && st.pemain ? Math.round((100 * st.rondeTerjawab) / st.pemain) : 0;

  return (
    <div className="proy" data-testid="proyektor">
      <LatarJalur hidup />
      {selesai ? <Konfeti /> : null}
      <header className="proy-atas">
        <div className="proy-merek">
          <i>T</i>
          <div>
            <b>Transit Rush</b>
            <span>{st?.nama ?? "Jakarta Brain Map"}</span>
          </div>
        </div>
        <div className="proy-kendali no-print">
          {st ? <span className="proy-chip">{LABEL_MODE[st.mode]}</span> : null}
          <button
            type="button"
            className={view === "papan" ? "on" : ""}
            onClick={() => setView("papan")}
            title="Tombol 1"
          >
            Papan
          </button>
          <button
            type="button"
            className={view === "statistik" ? "on" : ""}
            onClick={() => setView("statistik")}
            title="Tombol 2"
          >
            Statistik
          </button>
          <button type="button" onClick={layarPenuh} title="Tombol F">
            {penuh ? "Keluar layar penuh" : "Layar penuh"}
          </button>
        </div>
      </header>

      {lobi ? (
        <main className="proy-lobi">
          <section className="proy-pin">
            <span className="label">Naik di sini</span>
            <div className="proy-pin-angka" data-testid="pin-display" aria-label={pin}>
              <Digits nilai={pin || "------"} />
            </div>
            <div className="proy-qr">{qr ? <img src={qr} alt="QR untuk masuk" /> : null}</div>
            <span className="proy-url">
              {location.host}
              {BASE}
            </span>
          </section>
          <section className="proy-penumpang">
            <div className="proy-hitung">
              <b>
                <Angka n={st?.pemain ?? 0} />
              </b>
              <span>penumpang sudah naik</span>
            </div>
            <div className="proy-tiket-baris">
              {(st?.peserta ?? []).slice(0, 40).map((n, i) => (
                <span
                  key={n}
                  className="tiket-nama"
                  style={{
                    animationDelay: `${Math.min(i, 12) * 40}ms`,
                    ["--c" as string]: WARNA_KONFETI[i % WARNA_KONFETI.length],
                  }}
                >
                  {n}
                </span>
              ))}
              {st && st.peserta.length === 0 ? <span className="proy-tunggu">Menunggu penumpang pertama…</span> : null}
            </div>
          </section>
        </main>
      ) : selesai ? (
        <main className="proy-akhir">
          <h1>Perjalanan selesai</h1>
          {st && st.papan.length ? <Podium papan={st.papan} /> : <p className="muted">Terima kasih sudah bermain!</p>}
          {st && st.papan.length > 3 ? (
            <div className="proy-sisa">
              <Peringkat papan={st.papan.slice(3, 8).map((p) => p)} maks={5} gelap tinggi={48} batang={false} />
            </div>
          ) : null}
        </main>
      ) : view === "statistik" ? (
        <main className="proy-statistik">
          {[
            ["Penumpang", String(st?.pemain ?? 0)],
            ["Soal terjawab", String(st?.soalTotal ?? 0)],
            ["Ketepatan kelas", `${akurasi}%`],
            ["Beruntun terbaik", `${terbaik}×`],
            ["Poin rata-rata", String(rata)],
            ["Pemimpin", st?.papan[0]?.nama ?? "—"],
          ].map(([j, v]) => (
            <div key={j} className="proy-kpi-besar">
              <span>{j}</span>
              <b>{v}</b>
            </div>
          ))}
        </main>
      ) : (
        <main className="proy-main">
          <section className="proy-kiri">
            {arena ? (
              <div className="proy-ronde">
                <span className="label">
                  Ronde {st?.ronde} dari {st?.rondeTotal}
                </span>
                <div className="proy-ronde-titik">
                  {Array.from({ length: st?.rondeTotal ?? 0 }, (_, i) => (
                    <i key={i} className={i + 1 < (st?.ronde ?? 0) ? "ok" : i + 1 === st?.ronde ? "kini" : ""} />
                  ))}
                </div>
                {st?.rondeInfo ? (
                  <div className="proy-soal">
                    <LencanaLin ranah={st.rondeInfo.ranah} />
                    <div>
                      <b>{st.rondeInfo.nama}</b>
                      <span>
                        Level {st.rondeInfo.level} · {st.rondeInfo.levelNama}
                      </span>
                    </div>
                  </div>
                ) : null}
                <div className="proy-jawab">
                  <div className="proy-jawab-atas">
                    <span>Jawaban masuk</span>
                    <b>
                      <Angka n={st?.rondeTerjawab ?? 0} /> / {st?.pemain ?? 0}
                    </b>
                  </div>
                  <div className="proy-jawab-bar">
                    <i style={{ width: `${persenJawab}%` }} />
                  </div>
                </div>
              </div>
            ) : (
              <div className="proy-ronde">
                <span className="label">Sedang bermain</span>
                <div className="proy-soal">
                  <div>
                    <b>{st ? LABEL_MODE[st.mode] : ""}</b>
                    <span>Tiap penumpang punya soal sendiri</span>
                  </div>
                </div>
              </div>
            )}
            <div className="proy-kpi">
              <div>
                <span>Soal terjawab</span>
                <b>
                  <Angka n={st?.soalTotal ?? 0} />
                </b>
              </div>
              <div>
                <span>Ketepatan</span>
                <b>{akurasi}%</b>
              </div>
              <div>
                <span>Beruntun terbaik</span>
                <b>{terbaik}×</b>
              </div>
            </div>
          </section>
          <section className="proy-kanan" aria-label="Papan peringkat">
            {st?.papan.length ? (
              <Peringkat papan={st.papan} maks={10} tinggi={64} gelap />
            ) : (
              <p className="proy-tunggu">Papan skor muncul setelah ada poin.</p>
            )}
          </section>
        </main>
      )}
      <footer className="proy-kaki">
        <span className="muted">{galat}</span>
        <MapCredit tema="gelap" atribusi statis />
      </footer>
    </div>
  );
}

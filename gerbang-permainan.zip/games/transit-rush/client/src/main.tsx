import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Display } from "./Display";
import { Footer } from "./Footer";
import { Host } from "./Host";
import { Play } from "./Play";
import { BASE } from "./url";
import "./styles.css";

createRoot(document.getElementById("root") as HTMLElement).render(
  <StrictMode>
    <BrowserRouter basename={BASE || undefined}>
      <Routes>
        <Route path="/" element={<Play />} />
        <Route path="/host" element={<Host />} />
        <Route path="/operator" element={<Host />} />
        <Route path="/display" element={<Display />} />
        <Route path="*" element={<Play />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  </StrictMode>,
);

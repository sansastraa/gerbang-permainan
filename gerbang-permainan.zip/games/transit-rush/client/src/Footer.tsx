﻿// Kaki halaman: logo FDTJ dan kredit sumber peta, tampil di bawah semua layar.
import type { ReactElement } from "react";
import { ambilKonfig, useAsync } from "./net";

export function Footer({ gelap = false }: { gelap?: boolean }): ReactElement | null {
  const { data } = useAsync(ambilKonfig, []);
  const f = data?.footer;
  if (!f) return null;
  return (
    <footer className={`kaki${gelap ? " kaki-gelap" : ""} no-print`} data-testid="footer-fdtj">
      {f.logo ? (
        <span className="kaki-logo">
          <img src={f.logo.url} alt={f.logo.nama} height={22} />
        </span>
      ) : (
        <b>FDTJ</b>
      )}
      <span>{f.teks}</span>
    </footer>
  );
}

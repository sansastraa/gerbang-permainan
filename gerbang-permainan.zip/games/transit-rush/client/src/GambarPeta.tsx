// Lapisan gambar peta: garis lin, air, taman, batas wilayah hasil gambar ulang dari peta FDTJ 2026-08c (geometri vektor sendiri,
// tanpa ilustrasi landmark). Dimemo agar tidak digambar ulang saat zoom/geser.
import { memo } from "react";
import type { ReactElement } from "react";
import type { ItemGambar, PetaGambar } from "@transit-rush/shared";

const CAP = ["butt", "round", "square"] as const;
const URUT: ItemGambar["t"][] = ["a", "w", "p", "b", "r", "l", "x"];

function warna(i: ItemGambar, gelap: boolean): string {
  if (i.t === "w") return gelap ? "#1c3149" : "#cdd8e3";
  if (i.t === "a") return gelap ? "#0c1b2e" : i.c;
  if (i.t === "p") return "#d3ecb0";
  if (i.t === "b") return "#c4c8c6";
  return i.c;
}

function GambarPetaBase({ g, lin, gelap }: { g: PetaGambar; lin: boolean; gelap: boolean }): ReactElement {
  return (
    <g>
      {URUT.map((t) => {
        if (!lin && t !== "a" && t !== "w") return null;
        if (gelap && (t === "p" || t === "b")) return null;
        const arr = g.items.filter((i) => i.t === t);
        return (
          <g key={t} opacity={t === "r" ? 0.42 : 1}>
            {arr.map((i, n) =>
              t === "a" || t === "w" || t === "p" ? (
                <path key={n} d={i.d} fill={warna(i, gelap)} />
              ) : (
                <path
                  key={n}
                  d={i.d}
                  fill="none"
                  stroke={warna(i, gelap)}
                  strokeWidth={i.w}
                  strokeLinecap={CAP[i.cap ?? 1] ?? "round"}
                  strokeLinejoin="round"
                  strokeDasharray={i.dash?.join(" ")}
                />
              ),
            )}
          </g>
        );
      })}
      {lin
        ? g.teks.map((t, n) => (
            <text
              key={n}
              x={t.x}
              y={t.y}
              fontSize={t.h}
              transform={t.r ? `rotate(${-t.r} ${t.x} ${t.y})` : undefined}
              className="peta-wilayah"
            >
              {t.s}
            </text>
          ))
        : null}
      {lin
        ? g.penandaRel.map((p, n) => (
            <g key={`r${n}`}>
              <circle cx={p[0]} cy={p[1]} r={25} fill={p[2]} />
              <circle cx={p[0]} cy={p[1]} r={17} fill="#fff" />
            </g>
          ))
        : null}
      {lin
        ? g.penanda.map((p, n) => (
            <g key={`b${n}`}>
              <circle cx={p[0]} cy={p[1]} r={13.5} fill="#100d0f" />
              <circle cx={p[0]} cy={p[1]} r={11.5} fill="#fff" />
            </g>
          ))
        : null}
    </g>
  );
}
export const GambarPeta = memo(GambarPetaBase);

﻿// Membangun klien dengan BASE_PATH=/games/transit-rush ke dist-base (untuk e2e di belakang gerbang).
import { spawnSync } from "node:child_process";
const r = spawnSync("npx", ["vite", "build"], {
  stdio: "inherit",
  shell: true,
  env: { ...process.env, BASE_PATH: "/games/transit-rush", BUILD_OUT: "dist-base" },
});
process.exit(r.status ?? 1);

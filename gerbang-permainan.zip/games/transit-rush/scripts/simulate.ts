// Simulator: jalankan server nyata dan 40 bot (socket.io) bermain Arena/Rush. Pemakaian: npm run sim -- [mode] [jumlah]
import { buatApp } from "../server/src/app";
import { io as klien } from "socket.io-client";
import type { Socket } from "socket.io-client";

const mode = process.argv[2] ?? "arena";
const n = Number(process.argv[3] ?? 40);
const PIN = "simulasi";
const app = buatApp({ hostPin: PIN });
const port = await app.listen(0, "127.0.0.1");
const base = `http://127.0.0.1:${port}`;
const hs = { "x-host-token": PIN, "content-type": "application/json" };
const r = (await (
  await fetch(`${base}/api/sessions`, {
    method: "POST",
    headers: hs,
    body: JSON.stringify({
      settings: { mode, rondeArena: 3, levelMin: 1, levelMaks: 4, durasiMenit: 2, maksPerRanah: 3, uji: true },
    }),
  })
).json()) as { id: string; pin: string };
const mulai = Date.now();
const host: Socket = klien(base, { auth: { peran: "host", hostToken: PIN, sesiId: r.id }, transports: ["websocket"] });
const emit = (s: Socket, ev: string, p?: unknown) => new Promise<{ ok?: boolean }>((res) => s.emit(ev, p, res));
let selesai = 0;
const bots: Socket[] = [];
for (let i = 1; i <= n; i++) {
  const s = klien(base, { auth: { peran: "pemain", pin: r.pin }, transports: ["websocket"] });
  bots.push(s);
  s.on("tr:item", (it: { no: number; tipe: string; pilihan: string[] | null }) => {
    // bot tidak tahu jawabannya: menebak (dan memeriksa hanya bahwa alur berjalan)
    const resp =
      it.tipe === "pilihan" && it.pilihan
        ? it.pilihan[i % it.pilihan.length]
        : it.tipe === "urutan"
          ? (it.pilihan ?? []).slice(0, 3)
          : it.tipe === "angka"
            ? String(i % 7)
            : it.tipe === "ketuk"
              ? { x: 3000, y: 3000 }
              : it.tipe === "jam"
                ? "08:30"
                : "A1";
    setTimeout(() => s.emit("tr:answer", { no: it.no, resp }, () => undefined), 40 + (i % 5) * 20);
  });
  s.on("tr:result", () => setTimeout(() => s.emit("tr:lanjut", {}, () => undefined), 20));
  s.on("tr:end", () => selesai++);
  await new Promise<void>((ok) => s.once("connect", () => ok()));
  await emit(s, "tr:join", { nama: `Bot ${i}`, usia: 8 + (i % 8) });
}
await emit(host, "tr:host:mulai");
for (const b of bots) b.emit("tr:siap", {}, () => undefined);
const batas = Date.now() + 120_000;
while (selesai < n && Date.now() < batas) {
  await new Promise((ok) => setTimeout(ok, 250));
  if (mode === "arena") host.emit("tr:host:ronde", {}, () => undefined);
  if (mode === "rush" && Date.now() - mulai > 20_000) await emit(host, "tr:host:akhiri");
}
await emit(host, "tr:host:akhiri");
const sum = (await (await fetch(`${base}/api/sessions/${r.id}/summary.json`, { headers: hs })).json()) as {
  siswa: unknown[];
};
console.log(
  `${mode}: ${n} bot, ${selesai} menerima rapor akhir, ${sum.siswa.length} siswa di summary.json, ${((Date.now() - mulai) / 1000).toFixed(1)} dtk`,
);
for (const b of bots) b.disconnect();
host.disconnect();
await app.close();
process.exitCode = selesai >= n || mode === "rush" ? 0 : 1;

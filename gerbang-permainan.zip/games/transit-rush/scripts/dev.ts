// Menyalakan server (tsx watch) dan Vite dev client sekaligus.
import { spawn } from "node:child_process";
const npm = process.platform === "win32" ? "npm.cmd" : "npm";
const run = (args: string[]) =>
  spawn(npm, args, { stdio: "inherit", shell: process.platform === "win32", env: { ...process.env } });
const a = run(["run", "dev", "-w", "server"]);
const b = run(["run", "dev", "-w", "client"]);
const stop = () => {
  a.kill();
  b.kill();
  process.exit(0);
};
process.on("SIGINT", stop);
process.on("SIGTERM", stop);

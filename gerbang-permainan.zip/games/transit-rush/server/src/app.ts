// HTTP + Socket.IO. Server = wasit penuh; klien hanya menerima ItemKlien/MemoKlien (lihat session.ts).
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import express from "express";
import { Server } from "socket.io";
import type { Socket } from "socket.io";
import {
  CONFIG,
  EV,
  FAMILI,
  ITEMS,
  RANAH,
  answerSchema,
  csvRingkasan,
  joinSchema,
  realClock,
  rosterSchema,
  validateSettings,
} from "@transit-rush/shared";
import type { Clock } from "@transit-rush/shared";
import { JaringanStore } from "./jaringan";
import { Registry } from "./registry";
import type { Emit, Sesi, Target } from "./session";
import { PinGuard } from "./util";

export interface AppOpsi {
  hostPin: string;
  allowedOrigins?: string[];
  clock?: Clock;
  staticDir?: string;
  dataDir?: string;
  /** folder logo resmi (assets/branding); berkas yang tidak ada diabaikan dan watermark tampil sebagai teks */
  brandingDir?: string;
  /** Awalan jalur, mis. "/games/transit-rush" (kosong = di akar). */
  basePath?: string;
  trustProxy?: boolean;
  /** Tanpa PIN guru untuk permintaan dari komputer server sendiri (loopback). Klien lain tetap wajib PIN. */
  tanpaPinLokal?: boolean;
  /** Alamat IP milik komputer server sendiri (dibuka lewat IP LAN dari komputer yang sama dianggap lokal juga). */
  alamatServer?: string[];
  store?: JaringanStore;
}

export const normalisasiBasePath = (b?: string | null): string => {
  let s = (b ?? "").trim();
  if (!s || s === "/") return "";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "");
};
type Peran = "host" | "pemain" | "display";
interface Data {
  peran: Peran;
  sesiId: string;
  pid?: string;
}
type Ack = (res: unknown) => void;
const ack = (cb: unknown, res: unknown): void => {
  if (typeof cb === "function") (cb as Ack)(res);
};
const sama = (a: string, b: string): boolean => {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

export function buatApp(o: AppOpsi) {
  const clock = o.clock ?? realClock;
  const staticDir = o.staticDir ? path.resolve(o.staticDir) : undefined;
  const brandingDir = o.brandingDir ? path.resolve(o.brandingDir) : undefined;
  const origins = new Set(o.allowedOrigins ?? []);
  const basePath = normalisasiBasePath(o.basePath);
  const trustProxy = o.trustProxy === true;
  const store = o.store ?? new JaringanStore(o.dataDir);
  const app = express();
  const raut = express.Router();
  const ipDari = (xff: unknown, langsung: string | undefined): string => {
    const v = Array.isArray(xff) ? xff[0] : xff;
    if (trustProxy && typeof v === "string" && v.trim()) return v.split(",")[0]!.trim();
    return langsung ?? "?";
  };
  const server = http.createServer(app);
  const io = new Server(server, {
    path: `${basePath}/socket.io`,
    cors: { origin: o.allowedOrigins?.length ? [...origins] : true },
    maxHttpBufferSize: 64_000,
    pingInterval: 10_000,
    pingTimeout: 10_000,
  });
  const pinGuard = new PinGuard(clock);
  const hostGuard = new PinGuard(clock, 20);

  const emitFor =
    (sesiId: string): Emit =>
    (t: Target, ev: string, payload: unknown) => {
      const room = t.k === "sesi" ? `s:${sesiId}` : t.k === "host" ? `h:${sesiId}` : `p:${sesiId}:${t.pid}`;
      io.to(room).emit(ev, payload);
    };
  const reg = new Registry(clock, store, emitFor, o.dataDir);

  // ------------------------------------------------------------ HTTP
  app.disable("x-powered-by");
  app.use(express.json({ limit: "64kb" }));
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (origins.size === 0 || origins.has(origin))) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Headers", "content-type, x-host-token");
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, OPTIONS");
    }
    if (req.method === "OPTIONS") return void res.sendStatus(204);
    next();
  });
  raut.get("/health", (_req, res) => void res.json({ ok: true, game: "transit-rush", sesi: reg.semua().length }));

  const LOOP = new Set(["127.0.0.1", "::1", "::ffff:127.0.0.1"]);
  const milikSendiri = new Set((o.alamatServer ?? []).flatMap((a) => [a, `::ffff:${a}`]));
  const lokal = (ip: string): boolean => o.tanpaPinLokal === true && (LOOP.has(ip) || milikSendiri.has(ip));
  const adalahHost = (req: express.Request): boolean => {
    if (lokal(ipDari(req.headers["x-forwarded-for"], req.ip))) return true;
    const t = req.header("x-host-token") ?? "";
    return t.length > 0 && sama(t, o.hostPin);
  };
  const jagaHost = (req: express.Request, res: express.Response): boolean => {
    const key = ipDari(req.headers["x-forwarded-for"], req.ip);
    const sisa = hostGuard.terkunci(key);
    if (sisa)
      return (
        void res.status(429).json({ error: "Terlalu banyak percobaan. Coba lagi nanti.", sisaDetik: sisa }),
        false
      );
    if (!adalahHost(req)) return (hostGuard.gagal(key), void res.status(401).json({ error: "PIN guru salah." }), false);
    hostGuard.berhasil(key);
    return true;
  };

  /** Logo resmi yang benar-benar ada di assets/branding (tidak ada = teks saja). */
  const logoAda = (): { nama: string; url: string }[] =>
    CONFIG.watermark.logo
      .filter((l) => brandingDir && fs.existsSync(path.join(brandingDir, path.basename(l.file))))
      .map((l) => ({ nama: l.nama, url: `${basePath}/branding/${path.basename(l.file)}` }));

  const footerLogo = (): { nama: string; url: string } | null =>
    brandingDir && fs.existsSync(path.join(brandingDir, path.basename(CONFIG.footer.logo.file)))
      ? { nama: CONFIG.footer.logo.nama, url: `${basePath}/branding/${path.basename(CONFIG.footer.logo.file)}` }
      : null;
  raut.get("/api/config", (_req, res) => {
    res.json({
      level: CONFIG.level,
      mode: CONFIG.mode,
      maksArena: CONFIG.pemain.maks_arena,
      footer: { teks: CONFIG.footer.teks, logo: footerLogo() },
      watermark: {
        teks: CONFIG.watermark.teks,
        atribusi: CONFIG.watermark.atribusi_data,
        opasitas: CONFIG.watermark.opasitas,
        logo: logoAda(),
      },
      norma: CONFIG.norma,
      keluarga: Object.fromEntries(
        RANAH.map((d) => [d, ITEMS.familiesOf(d).map((f: string) => ({ key: f, nama: FAMILI[f].nama }))]),
      ),
    });
  });
  raut.get("/branding/:file", (req, res) => {
    const aman = path.basename(req.params.file);
    const boleh =
      CONFIG.watermark.logo.some((l) => path.basename(l.file) === aman) ||
      path.basename(CONFIG.footer.logo.file) === aman;
    const f = brandingDir ? path.join(brandingDir, aman) : "";
    if (!boleh || !f || !fs.existsSync(f)) return void res.sendStatus(404);
    res.sendFile(f);
  });
  /** Data jaringan untuk menggambar peta skematik (bukan rahasia; tanpa kunci soal). */
  raut.get(
    "/api/network",
    (_req, res) => void res.json({ versi: store.perbaikan.versi, data: store.data, gambar: store.gambar }),
  );
  raut.put("/api/network", (req, res) => {
    if (!jagaHost(req, res)) return;
    try {
      const v = store.terapkan(
        (req.body?.posisi ?? {}) as Record<string, { x: number; y: number }>,
        Array.isArray(req.body?.diperiksa) ? (req.body.diperiksa as string[]) : [],
      );
      res.json({ ok: true, versi: v });
    } catch (e) {
      res.status(400).json({ error: (e as Error).message });
    }
  });

  raut.post("/api/sessions", (req, res) => {
    if (!jagaHost(req, res)) return;
    const v = validateSettings(req.body?.settings);
    if (!v.ok) return void res.status(400).json({ error: v.errors.join(" "), errors: v.errors });
    const s = reg.buat(v.value);
    if (Array.isArray(req.body?.roster)) {
      const r = rosterSchema.safeParse(req.body.roster);
      if (!r.success) return void res.status(400).json({ error: "Daftar siswa tidak sah." });
      s.setRoster(r.data);
    }
    res.status(201).json({ id: s.id, pin: s.pin, settings: v.value });
  });
  raut.get("/api/sessions", (req, res) => {
    if (!jagaHost(req, res)) return;
    res.json({
      sesi: reg.semua().map((s) => s.statePublik()),
      arsip: reg.semuaArsip().map((r) => ({ id: r.sesiId, nama: r.nama, mode: r.mode, siswa: r.siswa.length })),
    });
  });
  raut.post("/api/lookup", (req, res) => {
    const key = ipDari(req.headers["x-forwarded-for"], req.ip);
    const sisa = pinGuard.terkunci(key);
    if (sisa)
      return void res.status(429).json({ error: `Terlalu banyak percobaan. Tunggu ${sisa} detik.`, sisaDetik: sisa });
    const pin = String(req.body?.pin ?? "");
    const s = /^\d{6}$/.test(pin) ? reg.dariPin(pin) : undefined;
    if (!s || s.status === "selesai")
      return (pinGuard.gagal(key), void res.status(404).json({ error: "PIN tidak ditemukan." }));
    pinGuard.berhasil(key);
    res.json({ id: s.id, nama: s.settings.nama, mode: s.settings.mode, roster: s.rosterPublik() });
  });
  raut.get("/api/sessions/:id/summary.json", (req, res) => {
    const s = reg.get(req.params.id);
    const arsip = reg.ringkasanArsip(req.params.id);
    if (!s && !arsip) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    if (!s) return void res.json(arsip);
    if (s.status !== "selesai" && req.query.includeTest !== "1")
      return void res.status(403).json({ error: "Sesi belum selesai." });
    res.json(s.ringkasan());
  });
  raut.get("/api/sessions/:id/results.csv", (req, res) => {
    const s = reg.get(req.params.id);
    const arsip = reg.ringkasanArsip(req.params.id);
    if (!s && !arsip) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.type("text/csv; charset=utf-8").send(csvRingkasan((s ? s.ringkasan() : arsip)!));
  });
  raut.get("/api/sessions/:id/jawaban.csv", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.type("text/csv; charset=utf-8").send(s.jawabanCsv());
  });
  raut.get("/api/sessions/:id/statistik.json", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.json(s.statistik());
  });
  raut.get("/api/sessions/:id/rapor/:pid", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    const r = s.raporPemain(req.params.pid);
    if (!r) return void res.status(404).json({ error: "Belum ada jawaban." });
    res.json({ nama: s.namaPemain(req.params.pid), sesi: s.settings.nama, rapor: r });
  });
  raut.get("/api/sessions/:id/log.jsonl", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.type("application/x-ndjson").send(s.log.rows.map((r) => JSON.stringify(r)).join("\n"));
  });

  if (staticDir && fs.existsSync(staticDir)) {
    raut.use(express.static(staticDir as string, { maxAge: "1h", index: "index.html" }));
    raut.get(
      /^\/(?!api|socket\.io|health|branding).*/,
      (_req, res) => void res.sendFile(path.join(staticDir as string, "index.html")),
    );
  }
  app.use(basePath || "/", raut);

  // ------------------------------------------------------------ Socket.IO
  const sesiDari = (sock: Socket): { s: Sesi; d: Data } | null => {
    const d = sock.data as Data;
    const s = d.sesiId ? reg.get(d.sesiId) : undefined;
    return s ? { s, d } : null;
  };
  const tolak = (cb: unknown, alasan: string): void => ack(cb, { ok: false, alasan });

  io.use((sock, next) => {
    const a = (sock.handshake.auth ?? {}) as Record<string, unknown>;
    const peran = a.peran as Peran;
    const key = ipDari(sock.handshake.headers["x-forwarded-for"], sock.handshake.address);
    if (!["host", "pemain", "display"].includes(peran)) return next(new Error("peran tidak dikenal"));
    if (peran === "host") {
      const sisa = hostGuard.terkunci(key);
      if (sisa) return next(new Error(`terkunci ${sisa}`));
      if (!lokal(key) && (typeof a.hostToken !== "string" || !sama(a.hostToken, o.hostPin)))
        return (hostGuard.gagal(key), next(new Error("PIN guru salah")));
      const s = typeof a.sesiId === "string" ? reg.get(a.sesiId) : undefined;
      if (!s) return next(new Error("sesi tidak ditemukan"));
      hostGuard.berhasil(key);
      sock.data = { peran, sesiId: s.id } satisfies Data;
      return next();
    }
    let s: Sesi | undefined;
    if (peran === "pemain" && typeof a.sesiId === "string" && typeof a.token === "string") s = reg.get(a.sesiId);
    if (!s) {
      const sisa = pinGuard.terkunci(key);
      if (sisa) return next(new Error(`terkunci ${sisa}`));
      s = typeof a.pin === "string" && /^\d{6}$/.test(a.pin) ? reg.dariPin(a.pin) : undefined;
      if (!s) return (pinGuard.gagal(key), next(new Error("PIN tidak ditemukan")));
      pinGuard.berhasil(key);
    }
    sock.data = { peran, sesiId: s.id } satisfies Data;
    next();
  });

  io.on("connection", (sock) => {
    const d0 = sock.data as Data;
    const s0 = reg.get(d0.sesiId)!;
    void sock.join(`s:${s0.id}`);
    if (d0.peran === "host") void sock.join(`h:${s0.id}`);
    sock.emit(EV.state, s0.statePublik());
    if (d0.peran === "host") sock.emit(EV.host, s0.hostExtra());

    // masuk ulang pemain dengan token
    if (d0.peran === "pemain") {
      const a = (sock.handshake.auth ?? {}) as Record<string, unknown>;
      if (typeof a.token === "string") {
        const m = s0.masukUlang(a.token);
        if (m) {
          d0.pid = m.pid;
          void sock.join(`p:${s0.id}:${m.pid}`);
          sock.emit("tr:masuk-ulang", { pid: m.pid, nama: m.nama });
          s0.pulihkan(m.pid);
        }
      }
    }

    sock.on("tr:join", (p: unknown, cb: unknown) => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "pemain") return tolak(cb, "bukan pemain");
      const parsed = joinSchema.safeParse(p);
      if (!parsed.success) return tolak(cb, "Data masuk tidak sah.");
      const r = c.s.join(parsed.data);
      if (!r.ok) return tolak(cb, r.alasan);
      c.d.pid = r.pid;
      void sock.join(`p:${c.s.id}:${r.pid}`);
      ack(cb, { ok: true, pid: r.pid, token: r.token, pemain: r.pemain, sesiId: c.s.id, mode: c.s.settings.mode });
    });
    const pemainSaja = (cb: unknown): { s: Sesi; pid: string } | null => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "pemain" || !c.d.pid) return (tolak(cb, "Masuk dulu."), null);
      return { s: c.s, pid: c.d.pid };
    };
    sock.on("tr:siap", (_p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      c.s.mulaiPemain(c.pid);
      ack(cb, { ok: true });
    });
    sock.on("tr:answer", (p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      const v = answerSchema.safeParse(p);
      if (!v.success) return tolak(cb, "Jawaban tidak sah.");
      ack(cb, c.s.jawab(c.pid, v.data.no, v.data.resp));
    });
    sock.on("tr:lanjut", (_p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      c.s.lanjut(c.pid);
      ack(cb, { ok: true });
    });
    sock.on("tr:pilih", (p: { family?: unknown; level?: unknown }, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      ack(cb, c.s.pilih(c.pid, String(p?.family ?? ""), Number(p?.level)));
    });
    sock.on("tr:blur", (p: { ms?: unknown }) => {
      const c = sesiDari(sock);
      if (c?.d.pid) c.s.blur(c.d.pid, Number(p?.ms));
    });

    // ---------------- guru
    const hostSaja = (cb: unknown): Sesi | null => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "host") return (tolak(cb, "Bukan guru."), null);
      return c.s;
    };
    sock.on("tr:host:mulai", (_p: unknown, cb: unknown) => {
      const s = hostSaja(cb);
      if (s) ack(cb, s.mulai());
    });
    sock.on("tr:host:ronde", (_p: unknown, cb: unknown) => {
      const s = hostSaja(cb);
      if (s) ack(cb, s.rondeBerikut());
    });
    sock.on("tr:host:akhiri", (_p: unknown, cb: unknown) => {
      const s = hostSaja(cb);
      if (!s) return;
      s.akhiri("host");
      ack(cb, { ok: true });
    });

    sock.on("disconnect", () => {
      const c = sesiDari(sock);
      if (c?.d.pid) c.s.putus(c.d.pid);
    });
  });

  return {
    app,
    server,
    io,
    reg,
    store,
    listen: (port: number, host = "0.0.0.0"): Promise<number> =>
      new Promise((resolve) => {
        server.listen(port, host, () => resolve((server.address() as { port: number }).port));
      }),
    close: (): Promise<void> =>
      new Promise((resolve) => {
        void io.close(() => resolve());
      }),
  };
}

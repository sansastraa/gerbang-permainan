/* eslint-disable @typescript-eslint/no-explicit-any */
import { afterEach, describe, expect, it } from "vitest";
import { io as klien } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { buatApp } from "./app";
import { jaringanBersama } from "./harness";

const PIN = "guru-1234";
const buka: { close: () => Promise<void> }[] = [];
const sock: Socket[] = [];
afterEach(async () => {
  for (const s of sock.splice(0)) s.disconnect();
  for (const a of buka.splice(0)) await a.close();
});

async function nyalakan(basePath = "", origins: string[] = [], tanpaPinLokal = false) {
  const a = buatApp({ hostPin: PIN, basePath, allowedOrigins: origins, tanpaPinLokal, store: jaringanBersama() });
  buka.push(a);
  const port = await a.listen(0, "127.0.0.1");
  return { a, url: `http://127.0.0.1:${port}`, port };
}
const hs = { "x-host-token": PIN, "content-type": "application/json" };
const sambung = (url: string, basePath: string, auth: any): Promise<Socket> =>
  new Promise((res, rej) => {
    const s = klien(url, { path: `${basePath}/socket.io`, auth, transports: ["websocket"], reconnection: false });
    sock.push(s);
    s.on("connect", () => res(s));
    s.on("connect_error", (e) => rej(e));
  });
const tunggu = <T>(s: Socket, ev: string): Promise<T> => new Promise((res) => s.once(ev, res));
const emitAck = (s: Socket, ev: string, p?: unknown): Promise<any> => new Promise((res) => s.emit(ev, p, res));

describe("HTTP + Socket.IO nyata", () => {
  it("PIN guru wajib; sesi dibuat; summary.json hanya untuk guru; bawaan butuh includeTest sebelum selesai", async () => {
    const { url } = await nyalakan();
    expect((await fetch(`${url}/api/sessions`, { method: "POST", body: "{}" })).status).toBe(401);
    const r = await fetch(`${url}/api/sessions`, {
      method: "POST",
      headers: hs,
      body: JSON.stringify({ settings: { mode: "profil" } }),
    });
    expect(r.status).toBe(201);
    const { id, pin } = (await r.json()) as any;
    expect(pin).toMatch(/^\d{6}$/);
    expect((await fetch(`${url}/api/sessions/${id}/summary.json`)).status).toBe(401);
    expect((await fetch(`${url}/api/sessions/${id}/summary.json`, { headers: hs })).status).toBe(403);
    const j = (await (
      await fetch(`${url}/api/sessions/${id}/summary.json?includeTest=1`, { headers: hs })
    ).json()) as any;
    expect(j.game).toBe("transit-rush");
    expect(j.versi).toBe(1);
    expect(
      (await fetch(`${url}/api/lookup`, { method: "POST", headers: hs, body: JSON.stringify({ pin }) })).status,
    ).toBe(200);
    expect(
      (await fetch(`${url}/api/lookup`, { method: "POST", headers: hs, body: JSON.stringify({ pin: "000000" }) }))
        .status,
    ).toBe(404);
  });

  it("alur penuh lewat kabel: join, soal tanpa kunci, jawab, hasil, ringkasan", async () => {
    const { url } = await nyalakan();
    const { id, pin } = (await (
      await fetch(`${url}/api/sessions`, {
        method: "POST",
        headers: hs,
        body: JSON.stringify({ settings: { mode: "latihan" } }),
      })
    ).json()) as any;
    const host = await sambung(url, "", { peran: "host", hostToken: PIN, sesiId: id });
    const p = await sambung(url, "", { peran: "pemain", pin });
    const masuk = await emitAck(p, "tr:join", { nama: "Rani", usia: 9 });
    expect(masuk.ok).toBe(true);
    expect((await emitAck(host, "tr:host:mulai")).ok).toBe(true);
    await emitAck(p, "tr:siap");
    const hasilSoal = tunggu<any>(p, "tr:item");
    expect((await emitAck(p, "tr:pilih", { family: "deret-kode", level: 2 })).ok).toBe(true);
    const item = await hasilSoal;
    expect(JSON.stringify(item)).not.toMatch(/jawaban|penjelasan|fase|"seed"/);
    // jawaban salah lewat kabel
    const hasil = tunggu<any>(p, "tr:result");
    await emitAck(p, "tr:answer", { no: item.no, resp: "salah" });
    const h = await hasil;
    expect(h.benar).toBe(false);
    expect(h.jawabanBenar).toBeTruthy();
    // jawaban ngawur tidak merusak server
    expect((await emitAck(p, "tr:answer", { no: "x" })).ok).toBe(false);
    await emitAck(host, "tr:host:akhiri");
    const sum = (await (await fetch(`${url}/api/sessions/${id}/summary.json`, { headers: hs })).json()) as any;
    expect(sum.selesai).toBe(true);
    expect(sum.siswa[0].nama).toBe("Rani");
    expect((await fetch(`${url}/api/sessions/${id}/results.csv`, { headers: hs })).headers.get("content-type")).toMatch(
      /csv/,
    );
  });

  it("masuk ulang dengan token memulihkan soal aktif", async () => {
    const { url } = await nyalakan();
    const { id, pin } = (await (
      await fetch(`${url}/api/sessions`, {
        method: "POST",
        headers: hs,
        body: JSON.stringify({ settings: { mode: "latihan" } }),
      })
    ).json()) as any;
    const host = await sambung(url, "", { peran: "host", hostToken: PIN, sesiId: id });
    const p = await sambung(url, "", { peran: "pemain", pin });
    const masuk = await emitAck(p, "tr:join", { nama: "Rani" });
    await emitAck(host, "tr:host:mulai");
    await emitAck(p, "tr:siap");
    const it1 = tunggu<any>(p, "tr:item");
    await emitAck(p, "tr:pilih", { family: "arah", level: 2 });
    const awal = await it1;
    p.disconnect();
    const p2 = klien(url, {
      path: "/socket.io",
      auth: { peran: "pemain", sesiId: id, token: masuk.token },
      transports: ["websocket"],
      reconnection: false,
    });
    sock.push(p2);
    const pulih = await tunggu<any>(p2, "tr:item");
    expect(pulih.no).toBe(awal.no);
    expect(pulih.sisaMs).toBeLessThanOrEqual(awal.sisaMs);
  });

  it("TANPA_PIN_GURU: komputer server (loopback) tanpa PIN; PIN salah tetap boleh di sana, mode biasa tetap wajib PIN", async () => {
    const { url } = await nyalakan("", [], true);
    const r = await fetch(`${url}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: "{}",
    });
    expect(r.status).toBe(201);
    const { id } = (await r.json()) as any;
    const host = await sambung(url, "", { peran: "host", sesiId: id });
    expect(host.connected).toBe(true);
    const biasa = await nyalakan();
    expect((await fetch(`${biasa.url}/api/sessions`, { method: "POST", body: "{}" })).status).toBe(401);
  });

  it("host salah ditolak; PIN sesi salah ditolak", async () => {
    const { url } = await nyalakan();
    await expect(sambung(url, "", { peran: "host", hostToken: "salah", sesiId: "x" })).rejects.toBeTruthy();
    await expect(sambung(url, "", { peran: "pemain", pin: "123456" })).rejects.toBeTruthy();
  });

  it("BASE_PATH: API, health, dan socket.io berada di bawah awalan", async () => {
    const { url } = await nyalakan("/games/transit-rush");
    expect((await fetch(`${url}/games/transit-rush/health`)).status).toBe(200);
    expect((await fetch(`${url}/health`)).status).toBe(404);
    const r = await fetch(`${url}/games/transit-rush/api/sessions`, {
      method: "POST",
      headers: hs,
      body: JSON.stringify({ settings: {} }),
    });
    expect(r.status).toBe(201);
    const { pin } = (await r.json()) as any;
    const p = await sambung(url, "/games/transit-rush", { peran: "pemain", pin });
    expect(p.connected).toBe(true);
  });

  it("CORS dibatasi ke ALLOWED_ORIGINS", async () => {
    const { url } = await nyalakan("", ["https://simpeteri.example"]);
    const ok = await fetch(`${url}/health`, { headers: { origin: "https://simpeteri.example" } });
    expect(ok.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example");
    const no = await fetch(`${url}/health`, { headers: { origin: "https://jahat.example" } });
    expect(no.headers.get("access-control-allow-origin")).toBeNull();
  });

  it("jaringan: perbaikan operator butuh PIN, menghitung ulang grid, dan menandai halte diperiksa", async () => {
    const { url } = await nyalakan();
    const net = (await (await fetch(`${url}/api/network`)).json()) as any;
    expect(net.data.halte.length).toBe(335);
    const h = net.data.halte.find((x: any) => x.posisi_perkiraan);
    const tanpa = await fetch(`${url}/api/network`, {
      method: "PUT",
      body: JSON.stringify({ diperiksa: [h.nama] }),
      headers: { "content-type": "application/json" },
    });
    expect(tanpa.status).toBe(401);
    const luar = await fetch(`${url}/api/network`, {
      method: "PUT",
      headers: hs,
      body: JSON.stringify({ posisi: { [h.nama]: { x: 99999, y: 1 } } }),
    });
    expect(luar.status).toBe(400);
  });

  it("logo resmi tidak ada: konfigurasi watermark jatuh ke teks", async () => {
    const { url } = await nyalakan();
    const c = (await (await fetch(`${url}/api/config`)).json()) as any;
    expect(c.watermark.teks).toBe("Map by Transport for Jakarta");
    expect(c.watermark.logo).toEqual([]);
    expect((await fetch(`${url}/branding/jaklingko.svg`)).status).toBe(404);
  });
});

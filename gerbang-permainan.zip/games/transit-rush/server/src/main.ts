// Titik masuk server. Variabel lingkungan:
//   PORT (3110) · HOST (0.0.0.0) · HOST_PIN (PIN guru; kosong = dibuat acak dan disimpan di var/host-token.txt)
//   ALLOWED_ORIGINS (asal SIMPETERI, dipisah koma; kosong = semua asal, hanya untuk LAN/uji)
//   BASE_PATH (mis. /games/transit-rush) · TRUST_PROXY=1 · STATIC_DIR · DATA_DIR · BRANDING_DIR
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { terapkanNorma } from "@transit-rush/shared";
import { buatApp, normalisasiBasePath } from "./app";

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR ?? path.join(here, "..", "var");
fs.mkdirSync(dataDir, { recursive: true });

function hostPin(): string {
  if (process.env.HOST_PIN && process.env.HOST_PIN.length >= 4) return process.env.HOST_PIN;
  const f = path.join(dataDir, "host-token.txt");
  if (fs.existsSync(f)) return fs.readFileSync(f, "utf8").trim();
  const pin = String(crypto.randomInt(100000, 999999));
  fs.writeFileSync(f, pin);
  return pin;
}
// Norma hasil kalibrasi (DATA_DIR/kalibrasi.json atau data/kalibrasi.json) menggantikan norma sementara bila datanya cukup.
for (const f of [path.join(dataDir, "kalibrasi.json"), path.join(here, "..", "..", "data", "kalibrasi.json")]) {
  if (!fs.existsSync(f)) continue;
  const dipakai = terapkanNorma(JSON.parse(fs.readFileSync(f, "utf8")) as Parameters<typeof terapkanNorma>[0]);
  console.log(`Kalibrasi ${f}: norma dipakai untuk ${dipakai.join(", ") || "(tidak ada, data kurang)"}`);
  break;
}
const port = Number(process.env.PORT ?? 3110);
const host = process.env.HOST ?? "0.0.0.0";
const pin = hostPin();
const basePath = normalisasiBasePath(process.env.BASE_PATH);
const app = buatApp({
  hostPin: pin,
  allowedOrigins: (process.env.ALLOWED_ORIGINS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean),
  staticDir: process.env.STATIC_DIR ?? path.join(here, "..", "..", "client", "dist"),
  brandingDir: process.env.BRANDING_DIR ?? path.join(here, "..", "..", "assets", "branding"),
  dataDir,
  basePath,
  trustProxy: process.env.TRUST_PROXY === "1",
  tanpaPinLokal: process.env.TANPA_PIN_GURU === "1",
  alamatServer: Object.values(os.networkInterfaces())
    .flat()
    .filter((i): i is os.NetworkInterfaceInfo => !!i)
    .map((i) => i.address),
});

void app.listen(port, host).then((p) => {
  const lan = Object.values(os.networkInterfaces())
    .flat()
    .filter((i) => i && i.family === "IPv4" && !i.internal)
    .map((i) => (i as os.NetworkInterfaceInfo).address);
  console.log(`\nTRANSIT RUSH berjalan di port ${p}`);
  const tanpaPin = process.env.TANPA_PIN_GURU === "1";
  console.log(
    `  Guru     : http://localhost:${p}${basePath}/host   (${tanpaPin ? "tanpa PIN di komputer ini; perangkat lain tetap perlu PIN " + pin : "PIN guru: " + pin})`,
  );
  for (const ip of lan) console.log(`  Murid    : http://${ip}:${p}${basePath}/`);
  console.log(`  Proyektor: ${basePath}/display?pin=<PIN sesi>`);
});

// Harness tes sesi: jam terkendali + perekam kejadian keluar. Dipakai tes dan simulator bot.
import { FakeClock, validateSettings, EV } from "@transit-rush/shared";
import type { SesiSettings } from "@transit-rush/shared";
import { JaringanStore } from "./jaringan";
import { Sesi } from "./session";
import type { Emit, Target } from "./session";

export interface Rekam {
  t: Target;
  ev: string;
  payload: any; // eslint-disable-line @typescript-eslint/no-explicit-any
}
let store: JaringanStore | null = null;
export const jaringanBersama = (): JaringanStore => (store ??= new JaringanStore());

/** Kunci yang tidak boleh ada di muatan keluar mana pun, kecuali tr:result (setelah dijawab). */
const TERLARANG = /"(jawaban|penjelasan|solution|seed|fase|b)":/;

export function bikinSesi(over: Partial<SesiSettings> = {}, seed = "tes") {
  const clock = new FakeClock();
  const rekam: Rekam[] = [];
  const emit: Emit = (t, ev, payload) => {
    const s = JSON.stringify(payload ?? null);
    if (ev !== EV.result && TERLARANG.test(s))
      throw new Error(`BOCOR: ${ev} memuat kunci terlarang: ${s.slice(0, 160)}`);
    rekam.push({ t, ev, payload: JSON.parse(s) });
  };
  const v = validateSettings({ nama: "Uji", ...over });
  if (!v.ok) throw new Error(v.errors.join(" "));
  const settings = v.value;
  const sesi = new Sesi({ id: "tr-uji", pin: "123456", settings, clock, emit, net: () => jaringanBersama().net, seed });
  return { sesi, clock, rekam };
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export function jawabanDari(item: any, benar: boolean): unknown {
  if (benar) return item.jawaban;
  if (item.tipe === "ketuk") return { x: 0, y: 0 };
  if (item.tipe === "urutan") return [];
  if (item.tipe === "angka") return -999;
  return "__salah__";
}

/** Satu langkah bot untuk satu pemain: lewati fase hafal, jawab, lanjut. Mengembalikan false bila tidak ada soal aktif. */
export function langkahBot(
  sesi: Sesi,
  clock: FakeClock,
  pid: string,
  benar: (item: any, no: number) => boolean,
  detik = 5,
): boolean {
  let a = sesi._itemLengkap(pid);
  if (!a) return false;
  const it = a.item as any;
  if (a.fase === "memo") {
    clock.advance(it.fase.hafal.detik * 1000 + 1);
    a = sesi._itemLengkap(pid);
    if (!a) return false;
  }
  if (a.fase === "tanya") {
    clock.advance(detik * 1000);
    sesi.jawab(pid, a.no, jawabanDari(it, benar(it, a.no)));
  }
  sesi.lanjut(pid);
  return true;
}

/** Mainkan satu pemain sampai selesai (mode mandiri). */
export function mainkanSampaiSelesai(
  sesi: Sesi,
  clock: FakeClock,
  pid: string,
  benar: (item: any, no: number) => boolean,
  maks = 400,
): number {
  let n = 0;
  while (sesi.status === "berjalan" && n < maks && langkahBot(sesi, clock, pid, benar)) n++;
  return n;
}

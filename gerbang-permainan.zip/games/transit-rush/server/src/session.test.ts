/* eslint-disable @typescript-eslint/no-explicit-any */
import { describe, expect, it } from "vitest";
import { EV, ITEMS } from "@transit-rush/shared";
import { bikinSesi, langkahBot, mainkanSampaiSelesai } from "./harness";
import { EventLog } from "./util";

const gabung = (sesi: any, nama = "Ani", extra: any = {}) => {
  const r = sesi.join({ nama, usia: 10, ...extra });
  if (!r.ok) throw new Error(r.alasan);
  return r.pid as string;
};

describe("server berwenang penuh (muatan keluar tanpa kunci)", () => {
  it("semua jenis soal: item/memo klien tanpa jawaban, penjelasan, fase, seed", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "latihan" }, "bocor");
    const pid = gabung(sesi);
    sesi.mulai();
    sesi.mulaiPemain(pid);
    for (const fam of Object.keys(ITEMS.FAMILY)) {
      for (const level of [1, 6, 10]) {
        const r = sesi.pilih(pid, fam, level);
        expect(r.ok).toBe(true);
        expect(langkahBot(sesi, clock, pid, () => true)).toBe(true);
      }
    }
    const itemEv = rekam.filter((r) => r.ev === EV.item);
    expect(itemEv.length).toBe(48);
    for (const e of itemEv) {
      expect(Object.keys(e.payload).sort()).toEqual(
        [
          "batasDetik",
          "family",
          "level",
          "levelNama",
          "nama",
          "no",
          "peta",
          "pilihan",
          "ranah",
          "sisaMs",
          "tanya",
          "tipe",
        ].sort(),
      );
    }
    expect(rekam.some((r) => r.ev === EV.memo)).toBe(true);
    // hasil boleh memuat kunci, tapi hanya setelah dijawab
    expect(rekam.filter((r) => r.ev === EV.result).every((r) => "jawabanBenar" in r.payload)).toBe(true);
  });

  it("jawaban saat fase hafal ditolak dan soal baru terkirim setelah memo ditutup server", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "latihan" }, "memo");
    const pid = gabung(sesi);
    sesi.mulai();
    sesi.mulaiPemain(pid);
    sesi.pilih(pid, "hafal-rute", 3);
    const a = sesi._itemLengkap(pid)!;
    expect(a.fase).toBe("memo");
    expect(sesi.jawab(pid, a.no, "x").ok).toBe(false);
    expect(rekam.filter((r) => r.ev === EV.item).length).toBe(0);
    clock.advance(((a.item as any).fase.hafal.detik as number) * 1000 + 1);
    expect(rekam.filter((r) => r.ev === EV.item).length).toBe(1);
  });

  it("nomor soal salah / jawaban ganda ditolak; waktu habis dihitung server", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "profil" }, "ganda");
    const pid = gabung(sesi);
    sesi.mulai();
    let a = sesi._itemLengkap(pid)!;
    if (a.fase === "memo") {
      clock.advance(((a.item as any).fase.hafal.detik as number) * 1000 + 1);
      a = sesi._itemLengkap(pid)!;
    }
    expect(sesi.jawab(pid, a.no + 5, "x").ok).toBe(false);
    expect(sesi.jawab(pid, a.no, (a.item as any).jawaban).ok).toBe(true);
    expect(sesi.jawab(pid, a.no, (a.item as any).jawaban).ok).toBe(false);
    sesi.lanjut(pid);
    // soal berikut dibiarkan: server menutupnya sendiri
    let b = sesi._itemLengkap(pid)!;
    if (b.fase === "memo") {
      clock.advance(((b.item as any).fase.hafal.detik as number) * 1000 + 1);
      b = sesi._itemLengkap(pid)!;
    }
    const batas = (b.item as any).batasDetik as number;
    clock.advance(batas * 1000 + 2000);
    const hasil = rekam.filter((r) => r.ev === EV.result).at(-1)!.payload;
    expect(hasil.no).toBe(b.no);
    expect(hasil.waktuHabis).toBe(true);
    expect(hasil.benar).toBe(false);
  });
});

describe("mode permainan & tes adaptif", () => {
  it("rush: mulai dari soal mudah (level <= 2) dan berhenti saat durasi habis", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "rush", durasiMenit: 2 }, "rush");
    const pid = gabung(sesi);
    sesi.mulai();
    const lv: number[] = [];
    let n = 0;
    while (sesi.status === "berjalan" && n++ < 200) {
      if (!langkahBot(sesi, clock, pid, () => true, 20)) break;
    }
    for (const r of rekam.filter((x) => x.ev === EV.item)) lv.push(r.payload.level);
    expect(lv[0]).toBeLessThanOrEqual(2);
    expect(sesi.status).toBe("selesai");
    const t = sesi.ringkasan().siswa[0]!.soal;
    expect(t).toBeGreaterThan(2);
    expect(t).toBeLessThan(40);
  });

  it("profil: pemain kuat > pemain lemah, rapor punya rentang & label norma sementara", () => {
    const { sesi, clock } = bikinSesi({ mode: "profil", maksPerRanah: 6 }, "profil");
    const kuat = gabung(sesi, "Kuat");
    const lemah = gabung(sesi, "Lemah");
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, kuat, () => true);
    mainkanSampaiSelesai(sesi, clock, lemah, (_i, no) => no % 5 === 0);
    const r = sesi.ringkasan();
    const a = r.siswa.find((s) => s.nama === "Kuat")!;
    const b = r.siswa.find((s) => s.nama === "Lemah")!;
    expect(a.ikp!).toBeGreaterThan(b.ikp!);
    expect(a.ikpRentang90![0]).toBeLessThanOrEqual(a.ikp!);
    expect(a.ikpRentang90![1]).toBeGreaterThanOrEqual(a.ikp!);
    expect(r.normaSementara).toBe(true);
    const rap = sesi.raporPemain("p1")!;
    expect(rap.normaSementara).toBe(true);
    expect(rap.catatanNorma).toMatch(/sementara/i);
    for (const d of ["memori", "spasial", "numerik", "logika"] as const)
      expect(rap.ranah[d].rentangSkor90[0]).toBeLessThan(rap.ranah[d].rentangSkor90[1]);
  });

  it("ranah dibatasi guru: hanya jenis soal dari ranah terpilih", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "profil", ranah: ["numerik"], maksPerRanah: 4 }, "ranah");
    const pid = gabung(sesi);
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, pid, () => true);
    const it = rekam.filter((r) => r.ev === EV.item);
    expect(it.length).toBeGreaterThan(2);
    expect(it.every((r) => r.payload.ranah === "numerik")).toBe(true);
  });

  it("ekstrim: level 8–10 saja, 12 soal", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "ekstrim" }, "ekstrim");
    const pid = gabung(sesi);
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, pid, () => false);
    const it = rekam.filter((r) => r.ev === EV.item);
    expect(it.length).toBe(12);
    expect(it.every((r) => r.payload.level >= 8)).toBe(true);
  });

  it("latihan: level di luar batas ditolak", () => {
    const { sesi } = bikinSesi({ mode: "latihan", levelMaks: 5 }, "lat");
    const pid = gabung(sesi);
    sesi.mulai();
    expect(sesi.pilih(pid, "arah", 7).ok).toBe(false);
    expect(sesi.pilih(pid, "tidak-ada", 3).ok).toBe(false);
    expect(sesi.pilih(pid, "arah", 3).ok).toBe(true);
  });
});

describe("arena kelas (PIN, maks 40, seed per pemain)", () => {
  it("40 pemain; ke-41 ditolak; tiap pemain soal berbeda; ronde berjalan sampai selesai", () => {
    const { sesi, clock, rekam } = bikinSesi({ mode: "arena", rondeArena: 3, levelMin: 1, levelMaks: 3 }, "arena");
    const pids: string[] = [];
    for (let i = 1; i <= 40; i++) pids.push(gabung(sesi, `Siswa ${i}`));
    expect(sesi.join({ nama: "Ke-41" }).ok).toBe(false);
    sesi.mulai();
    expect(sesi.ronde).toBe(1);
    const awal = rekam.filter((r) => r.ev === EV.item || r.ev === EV.memo);
    // jenis dan level sama, tetapi soalnya berbeda per pemain
    const fam = new Set(awal.map((r) => r.payload.family));
    expect(fam.size).toBe(1);
    for (let r = 1; r <= 3; r++) {
      for (const pid of pids) langkahBot(sesi, clock, pid, (_i, no) => no % 2 === 0, 6);
      clock.advance(7000);
    }
    expect(sesi.status).toBe("selesai");
    expect(sesi.ringkasan().siswa.length).toBe(40);
    expect(rekam.filter((r) => r.ev === EV.race).length).toBe(3);
  }, 120000);

  it("arena: soal tiap pemain berbeda (seed per pemain) pada jenis berisi acak", () => {
    const { sesi, rekam } = bikinSesi({ mode: "arena", rondeArena: 1, levelMin: 4, levelMaks: 4 }, "arena2");
    for (let i = 1; i <= 8; i++) gabung(sesi, `S${i}`);
    sesi.mulai();
    const fam = rekam.find((r) => r.ev === EV.item || r.ev === EV.memo)!.payload.family as string;
    const isi = rekam.filter((r) => r.ev === EV.item).map((r) => JSON.stringify([r.payload.tanya, r.payload.pilihan]));
    if (isi.length) expect(new Set(isi).size).toBeGreaterThan(1);
    expect(fam).toBeTruthy();
  });

  it("arena tidak menerima pemain baru setelah mulai", () => {
    const { sesi } = bikinSesi({ mode: "arena" }, "a3");
    gabung(sesi);
    sesi.mulai();
    expect(sesi.join({ nama: "Telat" }).ok).toBe(false);
  });
});

describe("roster, bendera, log", () => {
  it("roster: wajib pilih nama kelas; siswaId tercatat; ID tidak bisa dipakai dua kali", () => {
    const { sesi, clock } = bikinSesi({ mode: "profil", maksPerRanah: 3 }, "roster");
    sesi.setRoster([
      { id: "s-1", name: "Budi Santoso", absen: 1 },
      { id: "s-2", name: "Citra Lestari", absen: 2 },
    ]);
    expect(sesi.join({ nama: "Palsu" }).ok).toBe(false);
    const a = sesi.join({ nama: "x", siswaId: "s-1" });
    expect(a.ok).toBe(true);
    expect(sesi.join({ nama: "y", siswaId: "s-1" }).ok).toBe(false);
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, "p1", () => true);
    const s = sesi.ringkasan().siswa[0]!;
    expect(s.siswaId).toBe("s-1");
    expect(s.nama).toBe("Budi Santoso");
    expect(s.absen).toBe(1);
  });

  it("bendera: fokus hilang & terlalu cepat tercatat tanpa menghukum", () => {
    const { sesi, clock } = bikinSesi({ mode: "latihan", levelMin: 1, levelMaks: 10 }, "flag");
    const pid = gabung(sesi);
    sesi.mulai();
    sesi.mulaiPemain(pid);
    sesi.pilih(pid, "arah", 9);
    sesi.blur(pid, 3000);
    clock.advance(1000);
    const a = sesi._itemLengkap(pid)!;
    sesi.jawab(pid, a.no, (a.item as any).jawaban);
    const st: any = sesi.statistik();
    const jenis = st.bendera.map((b: any) => b.jenis);
    expect(jenis).toContain("fokus-hilang");
    expect(jenis).toContain("terlalu-cepat");
    expect(sesi.ringkasan().siswa[0]!.skor).toBeGreaterThan(0);
  });

  it("log kejadian berantai hash dan tidak memuat kunci jawaban", () => {
    const { sesi, clock } = bikinSesi({ mode: "profil", maksPerRanah: 3 }, "log");
    const pid = gabung(sesi);
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, pid, () => true);
    expect(sesi.log.rows.length).toBeGreaterThan(10);
    expect(EventLog.verify(sesi.log.rows)).toBe(true);
    expect(JSON.stringify(sesi.log.rows)).not.toMatch(/"jawaban"|"penjelasan"/);
    const rusak = JSON.parse(JSON.stringify(sesi.log.rows));
    rusak[3].data = { palsu: 1 };
    expect(EventLog.verify(rusak)).toBe(false);
  });

  it("ringkasan summary.json: kontrak Multi Permainan (game, versi, siswaId, skor)", () => {
    const { sesi, clock } = bikinSesi({ mode: "rush", durasiMenit: 1 }, "sum");
    gabung(sesi, "Dewi", { siswaId: "abc" });
    sesi.mulai();
    mainkanSampaiSelesai(sesi, clock, "p1", () => true);
    const r = sesi.ringkasan();
    expect(r.game).toBe("transit-rush");
    expect(r.versi).toBe(1);
    expect(r.selesai).toBe(true);
    expect(r.siswa[0]).toMatchObject({ siswaId: "abc", nama: "Dewi", peringkat: 1 });
    expect(typeof r.siswa[0]!.skor).toBe("number");
  });

  it("rapor memuat statistik perilaku bermain; summary.json dan statistik kelas ikut membawanya", () => {
    const { sesi, clock } = bikinSesi({ mode: "profil", maksPerRanah: 3 }, "perilaku");
    const a = gabung(sesi, "Cepat");
    const b = gabung(sesi, "Lambat");
    sesi.mulai();
    // Cepat: jawab 1 detik, salah semua; Lambat: jawab 25 detik, benar semua
    const langkahDetik = (pid: string, detik: number, benar: boolean) => {
      let n = 0;
      while (sesi.status === "berjalan" && n++ < 60) if (!langkahBot(sesi, clock, pid, () => benar, detik)) break;
    };
    langkahDetik(a, 1, false);
    langkahDetik(b, 12, true);
    const ra = sesi.raporPemain(a)!;
    const rb = sesi.raporPemain(b)!;
    expect(ra.perilaku).not.toBeNull();
    expect(ra.perilaku!.gegabah).toBeGreaterThan(0);
    expect(ra.perilaku!.medianDetik).toBeLessThanOrEqual(1.5);
    expect(rb.perilaku!.akurasi).toBe(1);
    expect(rb.perilaku!.medianDetik).toBeGreaterThan(ra.perilaku!.medianDetik);
    const r = sesi.ringkasan();
    expect(r.siswa.find((x) => x.nama === "Cepat")!.perilaku!.gegabah).toBeGreaterThan(0);
    const st: any = sesi.statistik();
    expect(st.perilaku.pemain).toBe(2);
    expect(st.perilaku.gegabahTotal).toBeGreaterThan(0);
    expect(Object.keys(st.perilaku.gaya).length).toBeGreaterThan(0);
  });
});

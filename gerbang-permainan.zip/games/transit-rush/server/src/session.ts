// Sesi Transit Rush. SERVER = WASIT: soal dibangkitkan, dinilai, dan dipilih di sini; klien hanya menerima ItemKlien/MemoKlien.
import {
  CONFIG,
  EV,
  FAMILI,
  IRT,
  ITEMS,
  MAKS_ARENA,
  RANAH,
  buatRapor,
  hitungPerilaku,
  poinSoal,
} from "@transit-rush/shared";
import type {
  Clock,
  JawabLog,
  HasilKlien,
  ItemKlien,
  JoinReq,
  MemoKlien,
  Rapor,
  Ranah,
  RingkasanSiswa,
  RingkasanTR,
  SesiSettings,
  SkorPublik,
  StateSesi,
} from "@transit-rush/shared";
import { EventLog, randomToken } from "./util";

export type Target = { k: "sesi" } | { k: "host" } | { k: "pemain"; pid: string };
export type Emit = (t: Target, ev: string, payload: unknown) => void;

/* eslint-disable @typescript-eslint/no-explicit-any */
type Item = any; // soal lengkap dari engine (punya jawaban/penjelasan): TIDAK pernah keluar dari server
type SesiIRT = any;

interface Aktif {
  no: number;
  item: Item;
  fase: "memo" | "tanya" | "hasil";
  mulai: number; // ms saat pertanyaan terkirim
  timer: unknown;
  memoTimer: unknown;
  lanjutTimer: unknown;
}
interface Flag {
  jenis: "fokus-hilang" | "terlalu-cepat" | "pola-sempurna";
  no: number;
  detail: string;
}
interface Pemain {
  id: string;
  token: string;
  nama: string;
  siswaId: string | null;
  absen: number | null;
  usia: number;
  S: SesiIRT;
  aktif: Aktif | null;
  no: number;
  poin: number;
  streak: number;
  maksStreak: number;
  benar: number;
  soal: number;
  waktuMs: number;
  mulaiAt: number | null;
  habisAt: number | null;
  waktuHabis: boolean;
  selesai: boolean;
  online: boolean;
  flags: Flag[];
  log: JawabLog[];
  rondeDijawab: number; // arena: ronde terakhir yang sudah selesai dijawab
  latihan: { family?: string; level?: number };
  raporCache: Rapor | null;
}

const LANJUT_OTOMATIS_MS = 15_000;
const GRACE_MS = 1500;
const JEDA_RONDE_MS = 6000;

/** Hanya kolom yang diizinkan (daftar putih) yang masuk ke klien. */
export function itemKlien(no: number, it: Item, sisaMs: number): ItemKlien {
  return {
    no,
    ranah: it.ranah,
    family: it.family,
    nama: it.nama,
    level: it.level,
    levelNama: it.levelNama,
    batasDetik: it.batasDetik,
    tipe: it.tipe,
    tanya: it.tanya,
    pilihan: Array.isArray(it.pilihan) ? [...it.pilihan] : null,
    peta: it.peta ? { ...it.peta } : null,
    sisaMs,
  };
}
export function memoKlien(no: number, it: Item): MemoKlien | null {
  const h = it.fase?.hafal;
  if (!h) return null;
  const { detik, labelPeta, ...isi } = h;
  return {
    no,
    family: it.family,
    nama: it.nama,
    detik,
    hafal: isi,
    peta: { label: labelPeta !== false, lin: true, sorot: [], rute: Array.isArray(h.rute) ? [...h.rute] : [] },
  };
}

export interface SesiOpsi {
  id: string;
  pin: string;
  settings: SesiSettings;
  clock: Clock;
  emit: Emit;
  /** pengambil jaringan terkini (berubah bila operator memperbaiki data) */
  net: () => unknown;
  seed?: string;
  logFile?: string;
  onSelesai?: (s: Sesi) => void;
}

export class Sesi {
  readonly id: string;
  readonly pin: string;
  readonly settings: SesiSettings;
  readonly log: EventLog;
  status: "lobby" | "berjalan" | "selesai" = "lobby";
  ronde = 0;
  readonly dibuat: number;
  private pemain = new Map<string, Pemain>();
  private roster = new Map<string, { id: string; name: string; absen?: number }>();
  private clock: Clock;
  private emit: Emit;
  private net: () => any;
  private seed: string;
  private rondeSpec: { family: string; level: number } | null = null;
  private jedaTimer: unknown = null;
  private onSelesai?: (s: Sesi) => void;

  constructor(o: SesiOpsi) {
    this.id = o.id;
    this.pin = o.pin;
    this.settings = o.settings;
    this.clock = o.clock;
    this.emit = o.emit;
    this.net = o.net as () => any;
    this.seed = o.seed ?? randomToken();
    this.log = new EventLog(o.clock, o.logFile);
    this.dibuat = o.clock.now();
    this.onSelesai = o.onSelesai;
    this.log.add("sesi-dibuat", "host", { mode: o.settings.mode, nama: o.settings.nama });
  }

  // ------------------------------------------------------------ roster & masuk
  setRoster(r: { id: string; name: string; absen?: number }[]): void {
    this.roster = new Map(r.map((x) => [x.id, x]));
  }
  rosterPublik(): { id: string; name: string; absen: number | null; terpakai: boolean }[] {
    const dipakai = new Set([...this.pemain.values()].map((p) => p.siswaId));
    return [...this.roster.values()].map((r) => ({
      id: r.id,
      name: r.name,
      absen: r.absen ?? null,
      terpakai: dipakai.has(r.id),
    }));
  }

  join(
    req: JoinReq,
  ): { ok: true; pid: string; token: string; pemain: { id: string; nama: string } } | { ok: false; alasan: string } {
    if (this.status === "selesai") return { ok: false, alasan: "Sesi sudah selesai." };
    if (this.settings.mode === "arena" && this.status !== "lobby") return { ok: false, alasan: "Arena sudah dimulai." };
    if (this.pemain.size >= MAKS_ARENA) return { ok: false, alasan: `Sesi penuh (maksimum ${MAKS_ARENA} pemain).` };
    let nama = req.nama.trim();
    let siswaId: string | null = null;
    let absen: number | null = req.absen ?? null;
    if (this.roster.size > 0) {
      const r = req.siswaId ? this.roster.get(req.siswaId) : undefined;
      if (!r) return { ok: false, alasan: "Pilih namamu dari daftar kelas." };
      if ([...this.pemain.values()].some((p) => p.siswaId === r.id))
        return { ok: false, alasan: "Nama ini sudah masuk. Pakai perangkat yang sama untuk masuk ulang." };
      nama = r.name;
      siswaId = r.id;
      absen = r.absen ?? null;
    } else if (req.siswaId) siswaId = req.siswaId;
    const dipakai = new Set([...this.pemain.values()].map((p) => p.nama));
    if (dipakai.has(nama)) {
      let i = 2;
      while (dipakai.has(`${nama} ${i}`)) i++;
      nama = `${nama} ${i}`;
    }
    const usia = req.usia ?? this.settings.usiaBawaan;
    const id = `p${this.pemain.size + 1}`;
    const s = this.settings;
    const modeIRT = s.mode === "rush" ? "rush" : s.mode === "latihan" ? "latihan" : "profil";
    const S = IRT.newSession({
      mode: modeIRT,
      usia,
      semTarget: s.mode === "rush" ? s.semTarget : s.mode === "ekstrim" ? 0.01 : s.semTarget,
      maxPerDomain: s.mode === "ekstrim" ? 3 : s.mode === "latihan" ? 999 : s.mode === "arena" ? 99 : s.maksPerRanah,
      minPerDomain:
        s.mode === "ekstrim" ? 3 : s.mode === "latihan" || s.mode === "arena" ? 0 : Math.min(3, s.maksPerRanah),
      levelMin: s.mode === "rush" || s.mode === "profil" || s.mode === "ekstrim" ? s.levelMin : undefined,
      levelMax: s.mode === "rush" || s.mode === "profil" || s.mode === "ekstrim" ? s.levelMaks : undefined,
      ranah: s.ranah,
      keluarga: ITEMS.DOMAINS.filter((d: string) => s.ranah.includes(d as Ranah)).flatMap((d: string) =>
        ITEMS.familiesOf(d),
      ),
    });
    const p: Pemain = {
      id,
      token: randomToken(),
      nama,
      siswaId,
      absen,
      usia,
      S,
      aktif: null,
      no: 0,
      poin: 0,
      streak: 0,
      maksStreak: 0,
      benar: 0,
      soal: 0,
      waktuMs: 0,
      mulaiAt: null,
      habisAt: null,
      waktuHabis: false,
      selesai: false,
      online: true,
      flags: [],
      log: [],
      rondeDijawab: 0,
      latihan: {},
      raporCache: null,
    };
    this.pemain.set(id, p);
    this.log.add("join", id, { nama, siswaId, usia });
    this.sebarState();
    return { ok: true, pid: id, token: p.token, pemain: { id, nama } };
  }
  /** Masuk ulang dengan token (setelah refresh/putus). */
  masukUlang(token: string): { pid: string; nama: string } | null {
    for (const p of this.pemain.values())
      if (p.token === token) {
        p.online = true;
        return { pid: p.id, nama: p.nama };
      }
    return null;
  }
  /** Kirim ulang keadaan pemain setelah masuk ulang (refresh/putus). */
  pulihkan(pid: string): void {
    const p = this.pemain.get(pid);
    if (!p) return;
    const t: Target = { k: "pemain", pid };
    this.emit(t, EV.progress, this.progres(p));
    if (p.selesai) return void this.emit(t, EV.end, this.raporPemain(pid));
    const a = p.aktif;
    if (a?.fase === "tanya") {
      const sisa = Math.max(0, a.item.batasDetik * 1000 - (this.clock.now() - a.mulai));
      this.emit(t, EV.item, itemKlien(a.no, a.item, sisa));
    } else if (a?.fase === "memo") {
      const m = memoKlien(a.no, a.item);
      if (m) this.emit(t, EV.memo, m);
    }
  }
  putus(pid: string): void {
    const p = this.pemain.get(pid);
    if (p) p.online = false;
  }

  // ------------------------------------------------------------ alur
  /** Host memulai sesi. Mode mandiri: pemain lalu menekan "Mulai" sendiri (atau otomatis). Arena: ronde 1 dimulai. */
  mulai(): { ok: boolean; alasan?: string } {
    if (this.status !== "lobby") return { ok: false, alasan: "Sesi sudah dimulai." };
    if (this.pemain.size === 0) return { ok: false, alasan: "Belum ada pemain." };
    this.status = "berjalan";
    this.log.add("mulai", "host");
    this.sebarState();
    if (this.settings.mode === "arena") this.mulaiRonde();
    else for (const p of this.pemain.values()) this.mulaiPemain(p.id);
    return { ok: true };
  }
  /** Pemain yang masuk saat sesi sudah berjalan (mode mandiri) langsung bisa mulai. */
  mulaiPemain(pid: string): void {
    const p = this.pemain.get(pid);
    if (!p || this.status !== "berjalan" || p.mulaiAt !== null || this.settings.mode === "arena") return;
    p.mulaiAt = this.clock.now();
    if (this.settings.mode === "rush") {
      p.habisAt = p.mulaiAt + this.settings.durasiMenit * 60_000;
      this.clock.setTimeout(() => {
        p.waktuHabis = true;
      }, this.settings.durasiMenit * 60_000);
    }
    this.log.add("mulai-pemain", pid);
    if (this.settings.mode !== "latihan") this.soalBerikut(p);
    else this.emit({ k: "pemain", pid }, EV.state, { menunggu: "pilih" });
  }

  /** Latihan bebas: pilih jenis dan level. */
  pilih(pid: string, family: string, level: number): { ok: boolean; alasan?: string } {
    const p = this.pemain.get(pid);
    if (!p || this.settings.mode !== "latihan" || this.status !== "berjalan")
      return { ok: false, alasan: "Bukan mode latihan." };
    if (!FAMILI[family] || !this.settings.ranah.includes(FAMILI[family].ranah))
      return { ok: false, alasan: "Jenis soal tidak tersedia." };
    if (!Number.isInteger(level) || level < this.settings.levelMin || level > this.settings.levelMaks)
      return { ok: false, alasan: "Level di luar batas." };
    if (p.aktif && p.aktif.fase !== "hasil") return { ok: false, alasan: "Selesaikan soal ini dulu." };
    p.latihan = { family, level };
    this.sajikan(p, ITEMS.generate(this.net(), family, level, `${this.seed}:${p.id}:${p.no + 1}`), p.no + 1);
    return { ok: true };
  }

  private spekBerikut(p: Pemain): { family: string; level: number; ranah: Ranah } | null {
    const rng = ITEMS.rngFrom(`${this.seed}:${p.id}:spek:${p.no}`);
    const m = this.settings.mode;
    if (m === "arena" && this.rondeSpec) {
      return { family: this.rondeSpec.family, level: this.rondeSpec.level, ranah: FAMILI[this.rondeSpec.family].ranah };
    }
    if (m === "rush" || m === "profil" || m === "ekstrim")
      return IRT.nextSpec(p.S, rng) as { family: string; level: number; ranah: Ranah } | null;
    return null;
  }

  private soalBerikut(p: Pemain): void {
    if (p.selesai) return;
    if (this.settings.mode === "rush" && (p.waktuHabis || (p.habisAt !== null && this.clock.now() >= p.habisAt)))
      return this.selesaiPemain(p);
    const spek = this.spekBerikut(p);
    if (!spek) return this.selesaiPemain(p);
    const no = p.no + 1;
    this.sajikan(p, ITEMS.generate(this.net(), spek.family, spek.level, `${this.seed}:${p.id}:${no}`), no);
  }

  private sajikan(p: Pemain, item: Item, no: number): void {
    this.hentikan(p);
    p.no = no;
    const a: Aktif = { no, item, fase: "tanya", mulai: 0, timer: null, memoTimer: null, lanjutTimer: null };
    p.aktif = a;
    this.log.add("soal", p.id, { no, family: item.family, level: item.level });
    const memo = memoKlien(no, item);
    const tanya = (): void => {
      a.fase = "tanya";
      a.mulai = this.clock.now();
      this.emit({ k: "pemain", pid: p.id }, EV.item, itemKlien(no, item, item.batasDetik * 1000));
      a.timer = this.clock.setTimeout(() => this.waktuHabis(p, no), item.batasDetik * 1000 + GRACE_MS);
    };
    if (memo) {
      a.fase = "memo";
      this.emit({ k: "pemain", pid: p.id }, EV.memo, memo);
      a.memoTimer = this.clock.setTimeout(tanya, memo.detik * 1000);
    } else tanya();
  }

  private hentikan(p: Pemain): void {
    const a = p.aktif;
    if (!a) return;
    this.clock.clearTimeout(a.timer);
    this.clock.clearTimeout(a.memoTimer);
    this.clock.clearTimeout(a.lanjutTimer);
  }

  private waktuHabis(p: Pemain, no: number): void {
    if (!p.aktif || p.aktif.no !== no || p.aktif.fase !== "tanya") return;
    this.nilai(p, null, true);
  }

  /** Jawaban pemain. `no` harus sama dengan soal aktif (mencegah jawaban ganda/usang). */
  jawab(pid: string, no: number, resp: unknown): { ok: boolean; alasan?: string } {
    const p = this.pemain.get(pid);
    if (!p || this.status !== "berjalan") return { ok: false, alasan: "Sesi tidak berjalan." };
    const a = p.aktif;
    if (!a || a.no !== no) return { ok: false, alasan: "Soal tidak cocok." };
    if (a.fase !== "tanya")
      return { ok: false, alasan: a.fase === "memo" ? "Masih fase hafal." : "Soal sudah dijawab." };
    const lewat = this.clock.now() - a.mulai;
    if (lewat > a.item.batasDetik * 1000 + GRACE_MS) return (this.nilai(p, null, true), { ok: true });
    const dipakai = typeof resp === "string" ? resp.slice(0, 200) : resp;
    this.nilai(p, dipakai, false);
    return { ok: true };
  }

  private nilai(p: Pemain, resp: unknown, habis: boolean): void {
    const a = p.aktif!;
    this.hentikan(p);
    const it = a.item;
    const detikPakai = Math.min(it.batasDetik, (this.clock.now() - a.mulai) / 1000);
    let hasil: { benar: boolean; sebagian?: number } = { benar: false, sebagian: 0 };
    if (!habis) {
      try {
        hasil = ITEMS.check(it, resp);
      } catch {
        hasil = { benar: false, sebagian: 0 };
      }
    }
    const benar = !!hasil.benar;
    const sebagian = hasil.sebagian ?? 0;
    p.streak = benar ? p.streak + 1 : 0;
    p.maksStreak = Math.max(p.maksStreak, p.streak);
    const sisa = 1 - detikPakai / it.batasDetik;
    const poin = poinSoal(it.level, benar, sebagian, sisa, p.streak - 1);
    p.poin += poin;
    p.soal++;
    if (benar) p.benar++;
    p.waktuMs += Math.round(detikPakai * 1000);
    p.raporCache = null;
    p.log.push({
      no: a.no,
      family: it.family,
      nama: it.nama,
      level: it.level,
      ranah: it.ranah,
      benar,
      sebagian,
      detik: +detikPakai.toFixed(1),
      batas: it.batasDetik,
      habis,
    });
    IRT.record(p.S, it, { benar, detik: +detikPakai.toFixed(1), sebagian });
    if (benar && it.level >= 8 && detikPakai < 3)
      p.flags.push({ jenis: "terlalu-cepat", no: a.no, detail: `${detikPakai.toFixed(1)} dtk di level ${it.level}` });
    if (p.streak === 15) p.flags.push({ jenis: "pola-sempurna", no: a.no, detail: "15 benar beruntun" });
    this.log.add("jawab", p.id, {
      no: a.no,
      family: it.family,
      level: it.level,
      benar,
      habis,
      detik: +detikPakai.toFixed(1),
      poin,
    });
    a.fase = "hasil";
    const out: HasilKlien = {
      no: a.no,
      benar,
      sebagian,
      poin,
      streak: p.streak,
      total: p.poin,
      penjelasan: String(it.penjelasan ?? ""),
      jawabanBenar: it.jawaban,
      waktuHabis: habis,
    };
    this.emit({ k: "pemain", pid: p.id }, EV.result, out);
    this.emit({ k: "pemain", pid: p.id }, EV.progress, this.progres(p));
    this.sebarState();
    if (this.settings.mode === "arena") {
      p.rondeDijawab = this.ronde;
      this.periksaRonde();
    } else if (this.settings.mode !== "latihan") {
      a.lanjutTimer = this.clock.setTimeout(() => this.lanjut(p.id), LANJUT_OTOMATIS_MS);
    }
  }

  /** Pemain siap soal berikut (setelah melihat hasil). */
  lanjut(pid: string): void {
    const p = this.pemain.get(pid);
    if (!p || this.status !== "berjalan" || !p.aktif || p.aktif.fase !== "hasil" || p.selesai) return;
    if (this.settings.mode === "arena") return;
    if (this.settings.mode === "latihan") {
      p.aktif = null;
      this.emit({ k: "pemain", pid }, EV.state, { menunggu: "pilih" });
      return;
    }
    this.soalBerikut(p);
  }

  /** Pemain keluar dari aplikasi (blur) lebih dari ambang: tercatat sebagai bendera, tidak menghukum. */
  blur(pid: string, ms: number): void {
    const p = this.pemain.get(pid);
    if (!p || !p.aktif || p.aktif.fase !== "tanya" || !(ms > 1500)) return;
    p.flags.push({ jenis: "fokus-hilang", no: p.aktif.no, detail: `${Math.round(ms)} ms` });
    this.log.add("fokus-hilang", pid, { no: p.aktif.no, ms: Math.round(ms) });
  }

  // ------------------------------------------------------------ arena
  private spekRonde(r: number): { family: string; level: number } {
    const s = this.settings;
    const fams = ITEMS.DOMAINS.filter((d: string) => s.ranah.includes(d as Ranah)).flatMap((d: string) =>
      ITEMS.familiesOf(d),
    );
    const rng = ITEMS.rngFrom(`${this.seed}:ronde:${r}`);
    const family = fams[Math.floor(rng() * fams.length)] as string;
    const total = s.rondeArena;
    const level = Math.min(s.levelMaks, s.levelMin + Math.floor(((r - 1) * (s.levelMaks - s.levelMin + 1)) / total));
    return { family, level };
  }
  private mulaiRonde(): void {
    this.clock.clearTimeout(this.jedaTimer);
    this.ronde++;
    this.rondeSpec = this.spekRonde(this.ronde);
    this.log.add("ronde", "host", { ronde: this.ronde, ...this.rondeSpec });
    for (const p of this.pemain.values()) if (!p.selesai) this.soalBerikut(p);
    // batas ronde: memo (maks 15 dtk) + batas soal + grace; setelah itu yang belum menjawab dianggap habis (timer per soal sudah menangani)
    this.sebarState();
  }
  private periksaRonde(): void {
    if (this.status !== "berjalan" || this.settings.mode !== "arena") return;
    const belum = [...this.pemain.values()].some((p) => !p.selesai && p.rondeDijawab < this.ronde);
    if (belum) return;
    this.log.add("ronde-selesai", "server", { ronde: this.ronde });
    this.emit({ k: "sesi" }, EV.race, { ronde: this.ronde, papan: this.papan() });
    if (this.ronde >= this.settings.rondeArena) return void this.akhiri("ronde-habis");
    this.jedaTimer = this.clock.setTimeout(() => this.mulaiRonde(), JEDA_RONDE_MS);
  }
  /** Host melompati jeda dan langsung mulai ronde berikut. */
  rondeBerikut(): { ok: boolean; alasan?: string } {
    if (this.settings.mode !== "arena" || this.status !== "berjalan")
      return { ok: false, alasan: "Bukan arena yang berjalan." };
    const belum = [...this.pemain.values()].some((p) => !p.selesai && p.rondeDijawab < this.ronde);
    if (belum) return { ok: false, alasan: "Ronde ini belum selesai." };
    if (this.ronde >= this.settings.rondeArena) return { ok: false, alasan: "Ronde terakhir sudah selesai." };
    this.mulaiRonde();
    return { ok: true };
  }

  // ------------------------------------------------------------ selesai
  private selesaiPemain(p: Pemain): void {
    if (p.selesai) return;
    this.hentikan(p);
    p.selesai = true;
    p.aktif = null;
    p.raporCache = null;
    this.log.add("selesai-pemain", p.id, { poin: p.poin, soal: p.soal });
    this.emit({ k: "pemain", pid: p.id }, EV.end, this.raporPemain(p.id));
    this.sebarState();
    if (this.settings.mode !== "arena" && [...this.pemain.values()].every((x) => x.selesai))
      this.akhiri("semua-selesai");
  }
  akhiri(alasan = "host"): void {
    if (this.status === "selesai") return;
    this.clock.clearTimeout(this.jedaTimer);
    for (const p of this.pemain.values()) {
      if (!p.selesai) {
        if (p.aktif && p.aktif.fase === "tanya") this.hentikan(p);
        p.selesai = true;
        p.aktif = null;
        this.emit({ k: "pemain", pid: p.id }, EV.end, this.raporPemain(p.id));
      }
    }
    this.status = "selesai";
    this.log.add("sesi-selesai", "server", { alasan });
    this.sebarState();
    this.onSelesai?.(this);
  }

  // ------------------------------------------------------------ keluaran
  private progres(p: Pemain): unknown {
    const doms: Record<string, { soal: number; sem: number }> = {};
    for (const d of RANAH) doms[d] = { soal: p.S.dom[d].resp.length, sem: +p.S.dom[d].sem.toFixed(2) };
    return { poin: p.poin, soal: p.soal, benar: p.benar, streak: p.streak, ranah: doms, mode: this.settings.mode };
  }
  raporPemain(pid: string): Rapor | null {
    return this.raporDari(this.pemain.get(pid));
  }
  private raporDari(p?: Pemain): Rapor | null {
    if (!p || p.soal === 0) return null;
    p.raporCache ??= buatRapor(p.S, hitungPerilaku(p.log, p.flags, p.maksStreak));
    return p.raporCache;
  }
  private papan(): SkorPublik[] {
    return [...this.pemain.values()]
      .map((p) => ({
        id: p.id,
        nama: p.nama,
        poin: p.poin,
        benar: p.benar,
        soal: p.soal,
        streak: p.streak,
        selesai: p.selesai,
        online: p.online,
      }))
      .sort((a, b) => b.poin - a.poin || b.benar - a.benar || a.nama.localeCompare(b.nama, "id"));
  }
  statePublik(): StateSesi {
    return {
      id: this.id,
      pin: this.pin,
      nama: this.settings.nama,
      mode: this.settings.mode,
      status: this.status,
      ronde: this.ronde,
      rondeTotal: this.settings.mode === "arena" ? this.settings.rondeArena : 0,
      pemain: this.pemain.size,
      peserta: this.status === "lobby" ? [...this.pemain.values()].map((p) => p.nama) : [],
      rondeInfo:
        this.settings.mode === "arena" && this.ronde > 0 && this.rondeSpec
          ? {
              nama: FAMILI[this.rondeSpec.family]!.nama,
              ranah: FAMILI[this.rondeSpec.family]!.ranah,
              level: this.rondeSpec.level,
              levelNama: CONFIG.level[this.rondeSpec.level - 1] ?? "",
            }
          : null,
      rondeTerjawab:
        this.settings.mode === "arena"
          ? [...this.pemain.values()].filter((p) => p.rondeDijawab >= this.ronde && this.ronde > 0).length
          : 0,
      soalTotal: [...this.pemain.values()].reduce((a, p) => a + p.soal, 0),
      benarTotal: [...this.pemain.values()].reduce((a, p) => a + p.benar, 0),
      papan: this.settings.papanSkor ? this.papan() : [],
    };
  }
  private sebarState(): void {
    this.emit({ k: "sesi" }, EV.state, this.statePublik());
    this.emit({ k: "host" }, EV.host, this.hostExtra());
  }
  hostExtra(): unknown {
    return {
      pemain: [...this.pemain.values()].map((p) => ({
        id: p.id,
        nama: p.nama,
        siswaId: p.siswaId,
        absen: p.absen,
        online: p.online,
        poin: p.poin,
        soal: p.soal,
        benar: p.benar,
        streak: p.streak,
        selesai: p.selesai,
        bendera: p.flags.length,
      })),
      pemainMaks: MAKS_ARENA,
    };
  }
  /** HANYA untuk tes/bot lokal: soal lengkap (dengan kunci) yang sedang aktif. */
  _itemLengkap(pid: string): { no: number; fase: string; item: unknown } | null {
    const a = this.pemain.get(pid)?.aktif;
    return a ? { no: a.no, fase: a.fase, item: a.item } : null;
  }
  pemainIds(): string[] {
    return [...this.pemain.keys()];
  }
  namaPemain(pid: string): string | undefined {
    return this.pemain.get(pid)?.nama;
  }

  ringkasan(): RingkasanTR {
    const daftar = [...this.pemain.values()].sort((a, b) => b.poin - a.poin || b.benar - a.benar);
    const siswa: RingkasanSiswa[] = daftar.map((p, i) => {
      const r = this.raporDari(p);
      return {
        peringkat: i + 1,
        absen: p.absen,
        nama: p.nama,
        siswaId: p.siswaId,
        skor: p.poin,
        soal: p.soal,
        benar: p.benar,
        akurasi: p.soal ? +(p.benar / p.soal).toFixed(3) : null,
        waktuMs: p.waktuMs,
        ikp: r?.IKP.skorStandar ?? null,
        ikpRentang90: r?.IKP.rentangSkor90 ?? null,
        levelPenjelajah: r?.IKP.level ?? null,
        tipe: r?.tipe ?? null,
        il: null,
        im: null,
        is: null,
        ranah: r
          ? Object.fromEntries(
              RANAH.map((d) => [
                d,
                {
                  skorStandar: r.ranah[d].skorStandar,
                  rentang90: r.ranah[d].rentangSkor90,
                  persentil: r.ranah[d].persentil,
                },
              ]),
            )
          : null,
        maksStreak: p.maksStreak,
        bendera: p.flags.length,
        perilaku: r?.perilaku
          ? {
              medianDetik: r.perilaku.medianDetik,
              pakaiWaktuPersen: r.perilaku.pakaiWaktuPersen,
              habis: r.perilaku.habis,
              gegabah: r.perilaku.gegabah,
              tren: r.perilaku.tren,
              gaya: r.perilaku.gaya,
            }
          : null,
        selesai: p.selesai,
        uji: this.settings.uji,
      };
    });
    return {
      game: "transit-rush",
      versi: 1,
      sesiId: this.id,
      nama: this.settings.nama,
      mode: this.settings.mode,
      selesai: this.status === "selesai",
      normaSementara: true,
      dibuat: this.dibuat,
      siswa,
    };
  }
  /** Data kalibrasi: satu baris per jawaban (pemain,usia,jenis,level,benar). */
  jawabanCsv(): string {
    const b = ["pemain,usia,jenis,level,benar"];
    for (const p of this.pemain.values())
      for (const h of p.S.history as { family: string; level: number; benar: boolean }[])
        b.push(`${this.id}-${p.id},${p.usia},${h.family},${h.level},${h.benar ? 1 : 0}`);
    return b.join("\n") + "\n";
  }
  /** Statistik guru: ketepatan per jenis soal & ranah, butir terlalu mudah/sulit, kekuatan kelas, bendera. */
  statistik(): unknown {
    const per = new Map<string, { family: string; nama: string; level: number; n: number; benar: number }>();
    const rn: Record<string, { n: number; benar: number; thetaJumlah: number; thetaN: number }> = {};
    for (const d of RANAH) rn[d] = { n: 0, benar: 0, thetaJumlah: 0, thetaN: 0 };
    for (const p of this.pemain.values()) {
      for (const h of p.S.history as { ranah: Ranah; family: string; level: number; benar: boolean }[]) {
        const k = `${h.family}:${h.level}`;
        const e = per.get(k) ?? { family: h.family, nama: FAMILI[h.family].nama, level: h.level, n: 0, benar: 0 };
        e.n++;
        if (h.benar) e.benar++;
        per.set(k, e);
        rn[h.ranah]!.n++;
        if (h.benar) rn[h.ranah]!.benar++;
      }
      for (const d of RANAH)
        if (p.S.dom[d].resp.length) {
          rn[d]!.thetaJumlah += p.S.dom[d].theta;
          rn[d]!.thetaN++;
        }
    }
    const butir = [...per.values()].filter((e) => e.n >= 3).map((e) => ({ ...e, tepat: +(e.benar / e.n).toFixed(2) }));
    const pp = [...this.pemain.values()]
      .map((p) => hitungPerilaku(p.log, p.flags, p.maksStreak))
      .filter((x) => x !== null);
    const gayaHitung: Record<string, number> = {};
    for (const x of pp) gayaHitung[x.gaya] = (gayaHitung[x.gaya] ?? 0) + 1;
    const perilaku = {
      pemain: pp.length,
      medianDetikRata: pp.length ? +(pp.reduce((a, x) => a + x.medianDetik, 0) / pp.length).toFixed(1) : null,
      pakaiWaktuRata: pp.length ? Math.round(pp.reduce((a, x) => a + x.pakaiWaktuPersen, 0) / pp.length) : null,
      habisTotal: pp.reduce((a, x) => a + x.habis, 0),
      gegabahTotal: pp.reduce((a, x) => a + x.gegabah, 0),
      trenNaik: pp.filter((x) => x.tren === "naik").length,
      trenTurun: pp.filter((x) => x.tren === "turun").length,
      gaya: gayaHitung,
    };
    return {
      perilaku,
      ranah: Object.fromEntries(
        RANAH.map((d) => [
          d,
          {
            soal: rn[d]!.n,
            tepat: rn[d]!.n ? +(rn[d]!.benar / rn[d]!.n).toFixed(2) : null,
            thetaRata: rn[d]!.thetaN ? +(rn[d]!.thetaJumlah / rn[d]!.thetaN).toFixed(2) : null,
          },
        ]),
      ),
      terlaluMudah: butir.filter((e) => e.tepat >= 0.95),
      terlaluSulit: butir.filter((e) => e.tepat <= 0.15),
      bendera: [...this.pemain.values()].flatMap((p) => p.flags.map((f) => ({ pemain: p.nama, ...f }))),
    };
  }
}

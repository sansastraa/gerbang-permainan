// Penyimpan jaringan: data bawaan + perbaikan operator (posisi halte) dari DATA_DIR. Membangun ulang engine bila berubah.
import fs from "node:fs";
import path from "node:path";
import { NW, bangunPeta, selDari } from "@transit-rush/shared";
import type { DataJaringan, PetaGambar } from "@transit-rush/shared";
import dasar from "../../data/jaringan_jakarta.json";
import gambarPeta from "../../data/peta_gambar.json";

export interface Perbaikan {
  versi: number;
  posisi: Record<string, { x: number; y: number }>;
  /** halte yang sudah dicek manusia (tanda posisi_perkiraan dicabut) */
  diperiksa: string[];
}
export class JaringanStore {
  /** gambar ulang peta (garis lin, air, taman) dari peta FDTJ 2026-08c */
  readonly gambar = gambarPeta as unknown as PetaGambar;
  data: DataJaringan;
  net: any; // eslint-disable-line @typescript-eslint/no-explicit-any
  perbaikan: Perbaikan = { versi: 0, posisi: {}, diperiksa: [] };
  private file?: string;
  constructor(dataDir?: string) {
    if (dataDir) {
      this.file = path.join(dataDir, "jaringan-perbaikan.json");
      try {
        this.perbaikan = JSON.parse(fs.readFileSync(this.file, "utf8")) as Perbaikan;
      } catch {
        /* belum ada perbaikan */
      }
    }
    this.data = this.bangun();
    this.net = NW.buildNetwork(this.data);
  }
  private bangun(): DataJaringan {
    const d = JSON.parse(JSON.stringify(dasar)) as DataJaringan;
    const model = bangunPeta(d);
    for (const h of d.halte) {
      const p = this.perbaikan.posisi[h.nama];
      if (p) {
        h.x = p.x;
        h.y = p.y;
        h.grid = selDari(model, p.x, p.y) ?? h.grid;
      }
      if (this.perbaikan.diperiksa.includes(h.nama) || p) h.posisi_perkiraan = false;
    }
    return d;
  }
  /** Terapkan perbaikan posisi/pemeriksaan. Mengembalikan versi baru. */
  terapkan(posisi: Perbaikan["posisi"], diperiksa: string[]): number {
    const nama = new Set(this.data.halte.map((h) => h.nama));
    for (const k of Object.keys(posisi)) if (!nama.has(k)) throw new Error(`Halte tidak dikenal: ${k}`);
    for (const k of diperiksa) if (!nama.has(k)) throw new Error(`Halte tidak dikenal: ${k}`);
    for (const p of Object.values(posisi))
      if (!Number.isFinite(p.x) || !Number.isFinite(p.y) || p.x < 0 || p.y < 0 || p.x > 9600 || p.y > 6800)
        throw new Error("Koordinat di luar peta.");
    Object.assign(this.perbaikan.posisi, posisi);
    this.perbaikan.diperiksa = [...new Set([...this.perbaikan.diperiksa, ...diperiksa])];
    this.perbaikan.versi++;
    this.data = this.bangun();
    this.net = NW.buildNetwork(this.data);
    if (this.file) {
      fs.mkdirSync(path.dirname(this.file), { recursive: true });
      fs.writeFileSync(this.file, JSON.stringify(this.perbaikan, null, 1));
    }
    return this.perbaikan.versi;
  }
}

// Alat kecil server: log kejadian berantai hash dan penjaga percobaan PIN.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import type { Clock } from "@transit-rush/shared";

export interface LogRow {
  seq: number;
  ts: number;
  tipe: string;
  aktor: string;
  data: unknown;
  prev: string;
  hash: string;
}
export class EventLog {
  rows: LogRow[] = [];
  constructor(
    private clock: Clock,
    private file?: string,
  ) {
    if (file) fs.mkdirSync(path.dirname(file), { recursive: true });
  }
  add(tipe: string, aktor: string, data: unknown = {}): LogRow {
    const prev = this.rows.at(-1)?.hash ?? "0".repeat(64);
    const base = { seq: this.rows.length + 1, ts: this.clock.now(), tipe, aktor, data, prev };
    const hash = crypto.createHash("sha256").update(JSON.stringify(base)).digest("hex");
    const row: LogRow = { ...base, hash };
    this.rows.push(row);
    if (this.file) {
      try {
        fs.appendFileSync(this.file, JSON.stringify(row) + "\n");
      } catch {
        /* log gagal tidak boleh menghentikan permainan */
      }
    }
    return row;
  }
  static verify(rows: LogRow[]): boolean {
    let prev = "0".repeat(64);
    for (const r of rows) {
      const { hash, ...base } = r;
      if (base.prev !== prev) return false;
      if (crypto.createHash("sha256").update(JSON.stringify(base)).digest("hex") !== hash) return false;
      prev = hash;
    }
    return true;
  }
}

export class PinGuard {
  private fails = new Map<string, number[]>();
  private locked = new Map<string, number>();
  constructor(
    private clock: Clock,
    private maks = 10,
    private kunciMs = 60_000,
  ) {}
  /** Sisa detik terkunci, atau 0 bila boleh mencoba. */
  terkunci(key: string): number {
    const until = this.locked.get(key) ?? 0;
    return until > this.clock.now() ? Math.ceil((until - this.clock.now()) / 1000) : 0;
  }
  gagal(key: string): void {
    const now = this.clock.now();
    const arr = (this.fails.get(key) ?? []).filter((t) => now - t < 60_000);
    arr.push(now);
    this.fails.set(key, arr);
    if (arr.length >= this.maks) {
      this.locked.set(key, now + this.kunciMs);
      this.fails.delete(key);
    }
  }
  berhasil(key: string): void {
    this.fails.delete(key);
  }
}

export const randomToken = (): string => crypto.randomBytes(16).toString("hex");

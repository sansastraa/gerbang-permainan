import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";
import type { Clock, RingkasanTR, SesiSettings } from "@transit-rush/shared";
import { Sesi } from "./session";
import type { Emit } from "./session";
import type { JaringanStore } from "./jaringan";

export class Registry {
  private byId = new Map<string, Sesi>();
  private byPin = new Map<string, Sesi>();
  /** sesi lama dari disk: hanya untuk summary.json */
  private arsip = new Map<string, RingkasanTR>();
  constructor(
    private clock: Clock,
    private store: JaringanStore,
    private emitFor: (sesiId: string) => Emit,
    private dataDir?: string,
  ) {
    if (dataDir) {
      const d = path.join(dataDir, "sessions");
      try {
        for (const f of fs.readdirSync(d))
          if (f.endsWith(".summary.json")) {
            const r = JSON.parse(fs.readFileSync(path.join(d, f), "utf8")) as RingkasanTR;
            if (r.game === "transit-rush") this.arsip.set(r.sesiId, r);
          }
      } catch {
        /* belum ada arsip */
      }
    }
  }
  buat(settings: SesiSettings): Sesi {
    let pin: string;
    do pin = String(crypto.randomInt(100000, 1000000));
    while (this.byPin.has(pin));
    const id = `tr-${crypto.randomBytes(5).toString("hex")}`;
    const s = new Sesi({
      id,
      pin,
      settings,
      clock: this.clock,
      emit: this.emitFor(id),
      net: () => this.store.net,
      logFile: this.dataDir ? path.join(this.dataDir, "sessions", `${id}.jsonl`) : undefined,
      onSelesai: (x) => this.simpan(x),
    });
    this.byId.set(id, s);
    this.byPin.set(pin, s);
    return s;
  }
  private simpan(s: Sesi): void {
    if (!this.dataDir) return;
    try {
      const d = path.join(this.dataDir, "sessions");
      fs.mkdirSync(d, { recursive: true });
      fs.writeFileSync(path.join(d, `${s.id}.summary.json`), JSON.stringify(s.ringkasan()));
    } catch {
      /* gagal simpan arsip tidak boleh menghentikan sesi */
    }
  }
  get(id: string): Sesi | undefined {
    return this.byId.get(id);
  }
  ringkasanArsip(id: string): RingkasanTR | undefined {
    return this.arsip.get(id);
  }
  dariPin(pin: string): Sesi | undefined {
    return this.byPin.get(pin);
  }
  semua(): Sesi[] {
    return [...this.byId.values()];
  }
  semuaArsip(): RingkasanTR[] {
    return [...this.arsip.values()];
  }
}

// @ts-nocheck
// Port dari engine/tr.test.js (11.447 pemeriksaan) ke vitest.
import { describe, it, expect } from 'vitest';
import data from '../../../data/jaringan_jakarta.json';
import * as NW from './tr-network';
import * as I from './tr-items';
import * as IRT from './tr-irt';
describe('engine Transit Rush', () => {
 it('seluruh pemeriksaan engine asli lulus', async () => {
const N = NW.buildNetwork(data);
let pass = 0; const t0 = Date.now(), info = [];
const ok = (c: unknown, m: string) => { if (!c) throw new Error('GAGAL: ' + m); pass++; };

await new Promise((r) => setImmediate(r)); // beri napas ke worker vitest agar RPC tidak timeout
// ===== A. Jaringan =====
ok(N.names.length >= 300 && Object.keys(N.lines).length >= 20, 'ukuran jaringan');
await new Promise((r) => setImmediate(r));
for (const l of Object.values(N.lines)) {
  ok(l.halte.every(h => N.st.has(h)), 'halte lin ada: ' + l.id);
  if (l.moda === 'BRT' && !l.id.endsWith('R')) {   // kode koridor naik berurutan sesuai peta
    const nums = l.halte.map(h => (N.st.get(h).kode || []).find(c => c.startsWith(l.id + '-'))).filter(Boolean).map(c => +c.split('-')[1]);
    ok(nums.every((v, i) => i === 0 || v > nums[i - 1]), 'kode koridor berurutan ' + l.id);
  }
}
ok(N.data.halte.every(h => /^[A-F][1-8]$/.test(h.grid) && Number.isFinite(h.x)), 'setiap halte punya posisi & sel grid');
const r1 = NW.shortestRoute(N, 'Blok M', 'Kota', 'transit'); ok(r1.transfers === 0 && r1.legs[0].line === '1' && r1.stops === 19, 'Blok M â†’ Kota: Koridor 1, 0 pindah, 19 halte');
ok(NW.shortestRoute(N, 'Pluit', 'Pinang Ranti', 'transit').transfers === 0, 'Koridor 9 ujung ke ujung');
const rng = I.rngFrom('jar');
await new Promise((r) => setImmediate(r));
for (let t = 0; t < 400; t++) {
  const a = N.names[Math.floor(rng() * N.names.length)], b = N.names[Math.floor(rng() * N.names.length)]; if (a === b) continue;
  const R = NW.shortestRoute(N, a, b, 'transit'), H = NW.shortestRoute(N, a, b, 'halte');
  ok(R && H, `terhubung ${a} â†’ ${b}`);
  ok(H.stops <= R.stops, 'mode halte tidak lebih panjang dari mode transit');
  ok(R.transfers <= H.transfers, 'mode transit tidak lebih banyak pindah');
  for (const leg of R.legs) if (leg.line !== 'walk') { const h = N.lines[leg.line].halte, adjOn = (x, y) => h.some((v, i) => (v === x && (h[i + 1] === y || h[i - 1] === y))); for (let k = 1; k < leg.halte.length; k++) ok(adjOn(leg.halte[k - 1], leg.halte[k]), 'leg mengikuti urutan lin'); }
}
ok(NW.dir8(NW.bearing(N, 'Blok M', 'Kota')) === 'utara' && NW.dir4(NW.bearing(N, 'Pulo Gadung', 'Kalideres')) === 'barat', 'arah mata angin');
ok(N.label('Duri KRL') === 'Duri' && N.label('Juanda KRL') === 'Juanda (KRL)', 'nama tampilan');

await new Promise((r) => setImmediate(r)); // beri napas ke worker vitest agar RPC tidak timeout
// ===== B. Soal =====
const FAMS = Object.keys(I.FAMILY);
await new Promise((r) => setImmediate(r));
for (const f of FAMS) { for (let L = 2; L <= 10; L++) ok(I.bOf(f, L) > I.bOf(f, L - 1), 'b naik dengan level ' + f); ok(I.bOf(f, 1) < -2.5 && I.bOf(f, 10) > 2.5, 'rentang b super gampang â†’ ekstrim ' + f); }
const INTERNAL = N.names.filter(n => / (KRL|LRT|MRT)$/.test(n));
const seen = new Set(); let total = 0;
await new Promise((r) => setImmediate(r));
for (const f of FAMS) for (let L = 1; L <= 10; L++) for (let s = 0; s < 6; s++) {
  const it = I.generate(N, f, L, 'uji' + s); total++;
  ok(it.ranah === I.FAMILY[f].ranah && it.level === L && Number.isFinite(it.b), 'metadata ' + it.id);
  ok(I.check(it, it.jawaban).benar, 'jawaban kunci lolos pemeriksa ' + it.id);
  ok(!('jawaban' in I.publicItem(it)) && !('penjelasan' in I.publicItem(it)), 'publicItem tanpa kunci');
  if (it.tipe === 'pilihan') ok(it.pilihan.includes(it.jawaban) && new Set(it.pilihan).size === it.pilihan.length, 'pilihan memuat kunci & unik ' + it.id);
  if (it.tipe === 'urutan') ok(it.jawaban.every(x => it.pilihan.includes(x)), 'urutan: semua kunci ada di pilihan');
  ok(!INTERNAL.some(n => it.tanya.includes(n) || JSON.stringify(it.pilihan || '').includes(n)), 'tidak ada nama internal di teks ' + it.id);
  seen.add(it.tanya + JSON.stringify(it.jawaban));
}
info.push(`soal unik ${seen.size}/${total}`);
ok(seen.size / total > 0.9, 'variasi soal antar-seed');
await new Promise((r) => setImmediate(r));
{ // verifikasi silang dengan mesin jaringan
  for (let s = 0; s < 20; s++) {
    const a = I.generate(N, 'arah', 1 + (s % 10), 'v' + s); ok(NW.COMPASS8.includes(a.jawaban), 'arah sah');
    const t = I.generate(N, 'terdekat', 1 + (s % 10), 'v' + s), lab2name = n => N.names.find(x => N.label(x) === n) || n, x = lab2name(t.tanya.match(/ke (.+)\?$/)[1]);
    ok(t.pilihan.every(o => NW.distance(N, x, lab2name(t.jawaban)) <= NW.distance(N, x, lab2name(o)) + 1e-9), 'terdekat benar-benar paling dekat');
  }
}
const wrong = I.generate(N, 'hitung-halte', 5, 'w'); ok(!I.check(wrong, wrong.jawaban + 1).benar && I.check(wrong, String(wrong.jawaban)).benar, 'pemeriksa angka');
const tap = I.generate(N, 'peta-buta', 5, 'w'); ok(I.check(tap, { x: tap.jawaban.x + tap.jawaban.radius * 0.5, y: tap.jawaban.y }).benar && !I.check(tap, { x: tap.jawaban.x + tap.jawaban.radius * 2, y: tap.jawaban.y }).benar, 'pemeriksa ketuk');
const jam = I.generate(N, 'waktu', 3, 'w'); ok(I.check(jam, jam.jawaban.replace(':', '.')).benar, 'jam 08.49 = 08:49');

await new Promise((r) => setImmediate(r)); // beri napas ke worker vitest agar RPC tidak timeout
// ===== C. Psikometri (peserta simulasi) =====
const sim = I.rngFrom('psiko');
const gauss = () => { let u = 0, v = 0; while (!u) u = sim(); while (!v) v = sim(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const trueB = {}; for (const f of FAMS) for (let L = 1; L <= 10; L++) trueB[f + L] = I.bOf(f, L) + 0.3 * gauss();   // kalibrasi awal sengaja sedikit meleset
function runCAT(theta, opts) {
  const S = IRT.newSession(opts);
  for (let k = 0; k < 200 && !S.done; k++) {
    const spec = IRT.nextSpec(S, sim); if (!spec) break;
    const item = { ranah: spec.ranah, family: spec.family, level: spec.level, b: I.bOf(spec.family, spec.level) };
    IRT.record(S, item, { benar: sim() < IRT.P(theta[spec.ranah], trueB[spec.family + spec.level]), detik: 5 + 20 * sim() });
  }
  return S;
}
const people = Array.from({ length: 160 }, () => { const g = 1.2 * gauss(); return Object.fromEntries(I.DOMAINS.map(d => [d, g + 0.7 * gauss()])); });
const est = people.map(th => runCAT(th, { mode: 'profil', usia: 11 }));
const pearson = (x, y) => { const n = x.length, mx = x.reduce((a, b) => a + b) / n, my = y.reduce((a, b) => a + b) / n; let a = 0, b = 0, c = 0; for (let i = 0; i < n; i++) { a += (x[i] - mx) * (y[i] - my); b += (x[i] - mx) ** 2; c += (y[i] - my) ** 2; } return a / Math.sqrt(b * c); };
await new Promise((r) => setImmediate(r));
for (const d of I.DOMAINS) {
  const r = pearson(people.map(p => p[d]), est.map(S => S.dom[d].theta)), sem = est.reduce((a, S) => a + S.dom[d].sem, 0) / est.length, n = est.reduce((a, S) => a + S.dom[d].resp.length, 0) / est.length;
  info.push(`${d}: r(Î¸ sejati, Î¸ tes) = ${r.toFixed(3)}, rata-rata SEM ${sem.toFixed(2)}, rata-rata ${n.toFixed(1)} soal`);
  ok(r > 0.85, `tes adaptif memulihkan kemampuan ${d} (r > 0,85)`); ok(sem < 0.6, `SEM ${d} < 0,6`);
}
const rel = (() => { const th = est.map(S => IRT.report(S).IKP.theta), m = th.reduce((a, b) => a + b) / th.length, v = th.reduce((a, b) => a + (b - m) ** 2, 0) / (th.length - 1), se2 = est.reduce((a, S) => a + IRT.report(S).IKP.sem ** 2, 0) / est.length; return v / (v + se2); })();
info.push(`reliabilitas empiris IKP = ${rel.toFixed(3)}`); ok(rel > 0.85, 'reliabilitas IKP > 0,85');
await new Promise((r) => setImmediate(r));
{ // rush selalu mulai super gampang, peserta sangat kuat sampai ekstrim, sangat lemah tetap di level rendah
  const Sr = IRT.newSession({ mode: 'rush', usia: 8 }); const first = IRT.nextSpec(Sr, () => 0.9); ok(first.level <= 2, 'rush mulai level â‰¤ 2: ' + first.level);
  const hi = runCAT(Object.fromEntries(I.DOMAINS.map(d => [d, 4.5])), { mode: 'profil', usia: 16, maxPerDomain: 15 });
  ok(Math.max(...hi.history.map(h => h.level)) === 10 && IRT.report(hi).IKP.level >= 9, 'peserta sangat kuat mencapai level ekstrim');
  const lo = runCAT(Object.fromEntries(I.DOMAINS.map(d => [d, -4])), { mode: 'profil', usia: 7 });
  ok(IRT.report(lo).IKP.level <= 2 && lo.history.slice(-8).every(h => h.level <= 3), 'peserta sangat lemah tetap di level rendah');
}
await new Promise((r) => setImmediate(r));
{ // kekuatan nyata terdeteksi, profil seimbang tidak dicap
  let hit = 0, fa = 0;
  for (let i = 0; i < 40; i++) { const R = IRT.report(runCAT({ memori: 2, spasial: -0.5, numerik: -0.5, logika: -0.5 }, { mode: 'profil', usia: 11 })); if (R.kekuatan.ranah === 'memori') hit++; }
  for (let i = 0; i < 40; i++) { const R = IRT.report(runCAT({ memori: 0, spasial: 0, numerik: 0, logika: 0 }, { mode: 'profil', usia: 11 })); if (R.kekuatan.ranah) fa++; }
  info.push(`kekuatan memori terdeteksi ${hit}/40, salah cap pada profil seimbang ${fa}/40`);
  ok(hit >= 30 && fa <= 4, 'deteksi kekuatan antar-ranah');
}
await new Promise((r) => setImmediate(r));
{ // laporan
  const R = IRT.report(est[0]);
  ok(R.IKP.persentil >= 0 && R.IKP.persentil <= 100 && R.IKP.stanine >= 1 && R.IKP.stanine <= 9 && R.IKP.rentangPersentil90[0] <= R.IKP.persentil && R.IKP.rentangPersentil90[1] >= R.IKP.persentil, 'skala skor & selang');
  ok(I.DOMAINS.every(d => R.ranah[d].level >= 1 && R.ranah[d].level <= 10), 'level per ranah');
}
await new Promise((r) => setImmediate(r));
{ // kalibrasi JML memulihkan kesulitan soal dari data
  const data = [], items = []; for (const f of FAMS.slice(0, 4)) for (let L = 1; L <= 10; L++) items.push(f + L);
  const persons = Array.from({ length: 400 }, () => 1.5 * gauss());
  persons.forEach((th, p) => items.forEach(it => { if (sim() < 0.6) data.push({ person: p, item: it, x: sim() < IRT.P(th, trueB[it]) ? 1 : 0 }); }));
  const C = IRT.calibrate(data), tb = items.map(i => trueB[i]), mb = tb.reduce((a, b) => a + b) / tb.length;
  const r = pearson(tb.map(b => b - mb), items.map(i => C.b[i]));
  info.push(`kalibrasi: r(b sejati, b hasil) = ${r.toFixed(3)}`); ok(r > 0.97, 'kalibrasi memulihkan b');
}


expect(pass).toBeGreaterThan(11000);
}, 600000);
});


// @ts-nocheck
/* Port mekanis dari engine/tr-network.js (CommonJS -> ESM). Perilaku identik; dijaga tes paritas terhadap shared/reference. */
// ============================================================
// TRANSIT RUSH — tr-network (fungsi murni)
// Graf jaringan Jakarta dari data/jaringan_jakarta.json:
// rute (Dijkstra pada keadaan halte+lin), hitung halte, arah mata angin, sel grid.
// ============================================================
function buildNetwork(data) {
  const st = new Map(data.halte.map(h => [h.nama, h]));
  const lines = data.lin;
  const adj = new Map();                 // nama → [{ to, line }]
  const add = (a, b, line) => { if (!adj.has(a)) adj.set(a, []); adj.get(a).push({ to: b, line }); };
  for (const ln of Object.values(lines)) for (let i = 1; i < ln.halte.length; i++) { add(ln.halte[i - 1], ln.halte[i], ln.id); add(ln.halte[i], ln.halte[i - 1], ln.id); }
  const walk = new Map();                // transit jalan kaki antar simpul
  for (const t of data.transit) { for (const [a, b] of [[t.a, t.b], [t.b, t.a]]) { if (!walk.has(a)) walk.set(a, []); walk.get(a).push(b); } }
  const linesAtMap = new Map(); for (const l of Object.values(lines)) for (const h of l.halte) { if (!linesAtMap.has(h)) linesAtMap.set(h, []); if (!linesAtMap.get(h).includes(l.id)) linesAtMap.get(h).push(l.id); }
  const linesAt = name => linesAtMap.get(name) || [];
  // Nama tampilan: tanpa sufiks internal; jika kembar, beri keterangan moda — "Duri (KRL)"
  const base = n => n.replace(/ (KRL|LRT|MRT)$/, '');
  const count = {}; for (const n of st.keys()) count[base(n)] = (count[base(n)] || 0) + 1;
  const MODA = { KRL: 'KRL', LRT: 'LRT', MRT: 'MRT' };
  const label = n => { const b = base(n), m = / (KRL|LRT|MRT)$/.exec(n); return count[b] > 1 && m ? `${b} (${MODA[m[1]]})` : b; };
  return { data, st, lines, adj, walk, linesAt, label, names: [...st.keys()], _cache: new Map() };
}

// ---------- rute ----------
// mode 'halte': paling sedikit halte (transit = 0,5 halte) · mode 'transit': paling sedikit pindah lin, lalu halte
// Antrean prioritas biner kecil
function heap() { const a = []; return { push(x) { a.push(x); let i = a.length - 1; while (i > 0) { const p = (i - 1) >> 1; if (a[p][0] <= a[i][0]) break; [a[p], a[i]] = [a[i], a[p]]; i = p; } }, pop() { const top = a[0], last = a.pop(); if (a.length) { a[0] = last; let i = 0; for (;;) { const l = 2 * i + 1, r = l + 1; let m = i; if (l < a.length && a[l][0] < a[m][0]) m = l; if (r < a.length && a[r][0] < a[m][0]) m = r; if (m === i) break; [a[m], a[i]] = [a[i], a[m]]; i = m; } } return top; }, get size() { return a.length; } }; }
function shortestRoute(N, from, to, mode = 'transit') {
  const ck = from + '>' + to + '>' + mode;
  if (N._cache && N._cache.has(ck)) return N._cache.get(ck);
  const W = mode === 'transit' ? { stop: 1, transfer: 1000, walk: 0.5 } : { stop: 1, transfer: 0.5, walk: 0.25 };
  const key = (s, l) => s + '|' + l, dist = new Map(), prev = new Map(), pq = heap();
  const push = (d, s, l, p) => { const k = key(s, l); if (dist.has(k) && dist.get(k) <= d) return; dist.set(k, d); prev.set(k, p); pq.push([d, s, l]); };
  for (const l of N.linesAt(from)) push(0, from, l, null);
  push(0, from, '*', null);
  let result = null;
  while (pq.size) {
    const [d, s, l] = pq.pop();
    if (d > dist.get(key(s, l))) continue;
    if (s === to) {
      const path = []; let k = key(s, l);
      while (k) { const [ss, ll] = k.split('|'); path.push({ s: ss, l: ll }); k = prev.get(k); }
      result = summarize(N, path.reverse()); break;
    }
    // keadaan l: '*' = belum naik, 'walk*' = jalan kaki sebelum naik, 'walk' = jalan kaki setelah pernah naik, lainnya = sedang di lin l
    const rode = l !== '*' && l !== 'walk*';
    for (const e of (N.adj.get(s) || [])) push(d + W.stop + (rode && l !== e.line ? W.transfer : 0), e.to, e.line, key(s, l));
    for (const b of (N.walk.get(s) || [])) push(d + W.walk, b, rode ? 'walk' : 'walk*', key(s, l));
  }
  if (N._cache) N._cache.set(ck, result);
  return result;
}
function summarize(N, path) {
  const legs = [];
  for (let i = 1; i < path.length; i++) {
    const a = path[i - 1], b = path[i];
    if (a.s === b.s) continue;                                   // ganti lin di halte yang sama
    const line = b.l.startsWith('walk') ? 'walk' : b.l;
    const last = legs[legs.length - 1];
    if (last && last.line === line && line !== 'walk') { last.to = b.s; last.stops++; last.halte.push(b.s); }
    else legs.push({ line, from: a.s, to: b.s, stops: line === 'walk' ? 0 : 1, halte: [a.s, b.s] });
  }
  const rides = legs.filter(l => l.line !== 'walk');
  return { legs, stops: rides.reduce((x, l) => x + l.stops, 0), transfers: Math.max(0, rides.length - 1), walks: legs.filter(l => l.line === 'walk').length, stations: [legs[0] ? legs[0].from : null, ...legs.map(l => l.to)] };
}
// Halte di antara a dan b pada satu lin (null jika tidak satu lin)
function stopsBetween(N, line, a, b) { const h = N.lines[line].halte, i = h.indexOf(a), j = h.indexOf(b); return i < 0 || j < 0 ? null : Math.abs(i - j); }
function segment(N, line, a, b) { const h = N.lines[line].halte, i = h.indexOf(a), j = h.indexOf(b); return i <= j ? h.slice(i, j + 1) : h.slice(j, i + 1).reverse(); }

// ---------- ruang ----------
const COMPASS8 = ['utara', 'timur laut', 'timur', 'tenggara', 'selatan', 'barat daya', 'barat', 'barat laut'];
const COMPASS4 = ['utara', 'timur', 'selatan', 'barat'];
function bearing(N, a, b) { const A = N.st.get(a), B = N.st.get(b); const dx = B.x - A.x, dy = A.y - B.y; return (Math.atan2(dx, dy) * 180 / Math.PI + 360) % 360; }   // 0° = utara (y peta ke bawah)
const dir8 = deg => COMPASS8[Math.round(deg / 45) % 8];
const dir4 = deg => COMPASS4[Math.round(deg / 90) % 4];
function distance(N, a, b) { const A = N.st.get(a), B = N.st.get(b); return Math.hypot(A.x - B.x, A.y - B.y); }
const gridOf = (N, a) => N.st.get(a).grid;
function angularGap(deg) { const k = ((deg % 45) + 45) % 45; return Math.min(k, 45 - k); }   // jarak sudut ke batas sektor terdekat (soal arah yang ambigu dihindari)

const API = { buildNetwork, shortestRoute, stopsBetween, segment, bearing, dir8, dir4, distance, gridOf, angularGap, COMPASS8, COMPASS4 };
export { API as default, buildNetwork, shortestRoute, summarize, stopsBetween, segment, bearing, dir8, dir4, distance, gridOf, angularGap, COMPASS8, COMPASS4 };

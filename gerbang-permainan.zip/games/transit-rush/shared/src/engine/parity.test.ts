// Paritas: port TS harus memberi keluaran identik dengan engine asli (shared/reference/*.cjs).
import { createRequire } from "node:module";
import { describe, expect, it } from "vitest";
import data from "../../../data/jaringan_jakarta.json";
import * as NW from "./tr-network";
import * as I from "./tr-items";
import * as IRT from "./tr-irt";

const req = createRequire(import.meta.url);
const rNW = req("../../reference/tr-network.cjs");
const rI = req("../../reference/tr-items.cjs");
const rIRT = req("../../reference/tr-irt.cjs");

describe("paritas port TS vs engine asli", () => {
  const N = NW.buildNetwork(data);
  const rN = rNW.buildNetwork(data);
  it("soal identik untuk semua jenis x level x seed", () => {
    for (const fam of Object.keys(I.FAMILY)) {
      for (let L = 1; L <= 10; L += 3) {
        for (const seed of ["a", "b"]) {
          expect(JSON.stringify(I.generate(N, fam, L, `${fam}${L}${seed}`))).toBe(
            JSON.stringify(rI.generate(rN, fam, L, `${fam}${L}${seed}`)),
          );
        }
      }
    }
  }, 120000);
  it("publicItem tidak memuat jawaban/penjelasan", () => {
    for (const fam of Object.keys(I.FAMILY)) {
      const pub = JSON.stringify(I.publicItem(I.generate(N, fam, 5, "x")));
      expect(pub).not.toContain('"jawaban"');
      expect(pub).not.toContain('"penjelasan"');
    }
  });
  it("EAP & norma identik", () => {
    const resp = [
      { b: -1, x: 1 },
      { b: 0.5, x: 0 },
      { b: 1, x: 1 },
    ];
    expect(IRT.eap(resp)).toEqual(rIRT.eap(resp));
    expect(IRT.NORMS).toEqual(rIRT.NORMS);
  });
});

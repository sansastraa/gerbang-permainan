// @ts-nocheck
/* Port mekanis dari engine/tr-items.js (CommonJS -> ESM). Perilaku identik; dijaga tes paritas terhadap shared/reference. */
// ============================================================
// TRANSIT RUSH — tr-items: pembangkit soal (fungsi murni, deterministik dari seed)
// 4 ranah × 4 jenis soal × level 1–10. Setiap jawaban dihitung oleh mesin jaringan.
// ============================================================
import * as NW from './tr-network';

function hashStr(s) { let h = 1779033703 ^ s.length; for (let i = 0; i < s.length; i++) { h = Math.imul(h ^ s.charCodeAt(i), 3432918353); h = (h << 13) | (h >>> 19); } return h >>> 0; }
function rngFrom(seed) { let a = hashStr(String(seed)); return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
const pick = (a, r) => a[Math.floor(r() * a.length)];
function shuffle(a, r) { a = a.slice(); for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; }
const T = (arr, L) => arr[Math.min(arr.length, Math.max(1, L)) - 1];

const LEVELS = ['Super Gampang', 'Gampang', 'Mudah', 'Agak Mudah', 'Sedang', 'Menantang', 'Sulit', 'Sangat Sulit', 'Ahli', 'EKSTRIM'];
const MODE_LABEL = { BRT: 'Transjakarta', MRT: 'MRT', LRT: 'LRT', KRL: 'KRL/Kereta' };
const lineName = (N, id) => { const l = N.lines[id]; return l.moda === 'BRT' ? `Koridor ${id.replace('R', '')}` : l.nama; };
const D = (N, n) => N.label ? N.label(n) : n;
const mainLines = N => Object.values(N.lines).filter(l => !l.id.endsWith('R'));

// Kesulitan awal (logit Rasch) per jenis soal: b = dasar + kemiringan × (level − 5,5). Dikalibrasi ulang dari data (tools/tr-calibrate.js).
const FAMILY = {
  'hafal-rute':     { ranah: 'memori',  dasar: 0.3,  miring: 0.72, nama: 'Hafal Rute' },
  'halte-hilang':   { ranah: 'memori',  dasar: 0.0,  miring: 0.70, nama: 'Halte Hilang' },
  'kode-lin':       { ranah: 'memori',  dasar: -0.1, miring: 0.68, nama: 'Ingat Koridor' },
  'urutan-balik':   { ranah: 'memori',  dasar: 0.4,  miring: 0.70, nama: 'Urutan Terbalik' },
  'arah':           { ranah: 'spasial', dasar: -0.2, miring: 0.66, nama: 'Arah Mata Angin' },
  'grid':           { ranah: 'spasial', dasar: -0.1, miring: 0.66, nama: 'Cari Kotak Peta' },
  'terdekat':       { ranah: 'spasial', dasar: 0.1,  miring: 0.70, nama: 'Mana Paling Dekat' },
  'peta-buta':      { ranah: 'spasial', dasar: 0.4,  miring: 0.72, nama: 'Peta Gelap' },
  'hitung-halte':   { ranah: 'numerik', dasar: -0.2, miring: 0.70, nama: 'Hitung Halte' },
  'ongkos':         { ranah: 'numerik', dasar: 0.2,  miring: 0.74, nama: 'Hitung Koin' },
  'waktu':          { ranah: 'numerik', dasar: 0.3,  miring: 0.72, nama: 'Jam Tiba' },
  'deret-kode':     { ranah: 'numerik', dasar: -0.1, miring: 0.70, nama: 'Deret Kode' },
  'rute-terbaik':   { ranah: 'logika',  dasar: 0.1,  miring: 0.72, nama: 'Rute Terbaik' },
  'stasiun-misteri':{ ranah: 'logika',  dasar: 0.2,  miring: 0.72, nama: 'Stasiun Misteri' },
  'gangguan':       { ranah: 'logika',  dasar: 0.4,  miring: 0.72, nama: 'Ada Gangguan!' },
  'benar-salah':    { ranah: 'logika',  dasar: -0.1, miring: 0.70, nama: 'Benar atau Salah' },
};
const DOMAINS = ['memori', 'spasial', 'numerik', 'logika'];
const familiesOf = d => Object.keys(FAMILY).filter(f => FAMILY[f].ranah === d);
const bOf = (fam, L) => +(FAMILY[fam].dasar + FAMILY[fam].miring * (L - 5.5)).toFixed(3);
const TIME = L => T([25, 25, 30, 30, 35, 40, 45, 50, 55, 60], L);

// ---------- pembantu ----------
function optionsFrom(correct, pool, n, r) { const o = new Set([correct]); for (const x of shuffle(pool, r)) { if (o.size >= n) break; if (x !== correct) o.add(x); } return shuffle([...o], r); }
function randomRoute(N, r, wantStops, wantTransfers, tries = 250) {
  let best = null;
  for (let t = 0; t < tries; t++) {
    const a = pick(N.names, r), b = pick(N.names, r); if (a === b) continue;
    const R = NW.shortestRoute(N, a, b, 'transit'); if (!R || R.walks > 1) continue;
    const score = Math.abs(R.stations.length - wantStops) + 2 * Math.abs(R.transfers - wantTransfers);
    if (!best || score < best.score) best = { R, a, b, score };
    if (score === 0) break;
  }
  return best;
}
const routeStations = R => { const out = []; for (const l of R.legs) for (const s of l.halte) if (out[out.length - 1] !== s) out.push(s); return out; };
// urutan nama tampilan; transit jalan kaki antar simpul bernama sama digabung
const routeLabels = (N, R) => { const out = []; for (const s of routeStations(R)) { const d = D(N, s).replace(/ \((KRL|LRT|MRT)\)$/, ''); if (out[out.length - 1] !== d) out.push(d); } return out; };
function lineSlice(N, r, k) { for (let t = 0; t < 200; t++) { const l = pick(mainLines(N), r); if (l.halte.length < k) continue; const i = Math.floor(r() * (l.halte.length - k + 1)); return { line: l.id, halte: l.halte.slice(i, i + k) }; } return null; }

// ---------- generator per jenis ----------
const GEN = {
  // ===== MEMORI =====
  'hafal-rute'(N, L, r) {
    const k = T([3, 4, 5, 6, 7, 9, 11, 13, 16, 20], L), tr = T([0, 0, 0, 0, 1, 1, 2, 2, 3, 3], L);
    const g = randomRoute(N, r, k, tr), seq = routeLabels(N, g.R).slice(0, Math.max(k, 3));
    const distract = T([0, 0, 1, 1, 2, 2, 3, 3, 4, 5], L), pool = shuffle([...new Set(N.names.map(n => D(N, n).replace(/ \((KRL|LRT|MRT)\)$/, '')))].filter(n => !seq.includes(n)), r).slice(0, distract);
    return { tipe: 'urutan', fase: { hafal: { rute: seq, simpul: routeStations(g.R), lin: g.R.legs.map(l => l.line), detik: T([10, 10, 9, 9, 8, 8, 7, 7, 6, 5], L), labelPeta: L < 9 } },
      tanya: `Susun ${seq.length} halte rute tadi sesuai urutan, dari awal sampai akhir.`, pilihan: shuffle([...seq, ...pool], r), jawaban: seq,
      penjelasan: `Urutannya: ${seq.join(' → ')}.` };
  },
  'halte-hilang'(N, L, r) {
    const k = T([3, 4, 5, 6, 7, 8, 9, 10, 11, 12], L), s = lineSlice(N, r, k), hole = 1 + Math.floor(r() * (k - 2));
    const pool = N.lines[s.line].halte.filter(h => !s.halte.includes(h)).concat(N.names.filter(n => !s.halte.includes(n)).slice(0, 10));
    const opts = optionsFrom(s.halte[hole], L >= 7 ? N.lines[s.line].halte.filter(h => !s.halte.includes(h) || h === s.halte[hole]) : pool, T([3, 3, 4, 4, 4, 4, 5, 5, 6, 6], L), r);
    return { tipe: 'pilihan', fase: { hafal: { urutan: s.halte, lin: [s.line], detik: T([8, 8, 8, 7, 7, 7, 6, 6, 5, 5], L) } },
      tanya: `${lineName(N, s.line)}: halte mana yang hilang?\n${s.halte.map((h, i) => i === hole ? '❓' : h).join(' → ')}`, pilihan: opts, jawaban: s.halte[hole], penjelasan: `Yang hilang: ${s.halte[hole]}.` };
  },
  'kode-lin'(N, L, r) {
    const m = T([2, 2, 3, 3, 4, 5, 6, 7, 8, 10], L), ls = shuffle(Object.values(N.lines).filter(l => l.moda === 'BRT' && !l.id.endsWith('R')), r).slice(0, m);
    const q = pick(ls, r), ask = r() < 0.5 ? 'awal' : 'akhir', ans = ask === 'awal' ? q.halte[0] : q.halte[q.halte.length - 1];
    const pool = ls.flatMap(l => [l.halte[0], l.halte[l.halte.length - 1]]);
    return { tipe: 'pilihan', fase: { hafal: { pasangan: ls.map(l => ({ kode: l.id, warna: l.warna, rute: `${l.halte[0]} – ${l.halte[l.halte.length - 1]}` })), detik: T([8, 8, 9, 9, 10, 10, 11, 12, 13, 14], L) } },
      tanya: `Koridor ${q.id} berangkat dari halte apa (ujung ${ask})?`.replace('berangkat dari halte apa (ujung akhir)', 'berakhir di halte apa'), pilihan: optionsFrom(ans, pool, Math.min(4 + (L > 6), new Set(pool).size), r), jawaban: ans, penjelasan: `Koridor ${q.id}: ${q.halte[0]} – ${q.halte[q.halte.length - 1]}.` };
  },
  'urutan-balik'(N, L, r) {
    const k = T([3, 3, 4, 4, 5, 6, 7, 8, 9, 10], L), s = lineSlice(N, r, k), rev = s.halte.slice().reverse();
    return { tipe: 'urutan', fase: { hafal: { urutan: s.halte, lin: [s.line], detik: T([8, 8, 8, 8, 8, 8, 7, 7, 7, 6], L) } },
      tanya: `Susun halte tadi dari BELAKANG ke depan.`, pilihan: shuffle(s.halte, r), jawaban: rev, penjelasan: `Urutan terbalik: ${rev.join(' → ')}.` };
  },
  // ===== SPASIAL =====
  arah(N, L, r) {
    const eight = L >= 4, minGap = T([20, 20, 18, 12, 10, 8, 6, 5, 4, 3], L), minDist = T([3000, 2600, 2200, 1800, 1500, 1200, 1000, 800, 600, 500], L);
    for (let t = 0; t < 2000; t++) {
      const a = pick(N.names, r), b = pick(N.names, r); if (a === b || NW.distance(N, a, b) < minDist) continue;
      const deg = NW.bearing(N, a, b), gap = eight ? NW.angularGap(deg) : Math.min(((deg % 90) + 90) % 90, 90 - ((deg % 90) + 90) % 90);
      if (gap < minGap) continue;
      const ans = eight ? NW.dir8(deg) : NW.dir4(deg);
      return { tipe: 'pilihan', peta: { label: L < 8, putar: L >= 9 ? 180 : 0, sorot: [a, b] }, tanya: `${b} ada di sebelah mana dari ${a}?` + (L >= 9 ? ' (Peta diputar terbalik — jawab arah yang sebenarnya!)' : ''),
        pilihan: eight ? NW.COMPASS8.slice() : NW.COMPASS4.slice(), jawaban: ans, penjelasan: `Arah sebenarnya ${Math.round(deg)}° dari utara = ${ans}.` };
    }
  },
  grid(N, L, r) {
    const a = pick(N.names, r), ans = NW.gridOf(N, a);
    const all = []; for (const R of 'ABCDEF') for (let c = 1; c <= 8; c++) all.push(R + c);
    const near = all.filter(g => g !== ans && Math.abs('ABCDEF'.indexOf(g[0]) - 'ABCDEF'.indexOf(ans[0])) <= 1 && Math.abs(+g[1] - +ans[1]) <= 1);
    const n = T([2, 3, 4, 4, 4, 5, 5, 6, 6, 0], L), pool = L >= 5 ? near : all;
    return { tipe: n ? 'pilihan' : 'teks', peta: { label: L < 7, grid: true, tampil: L < 9, sorot: L < 7 ? [a] : [] }, tanya: L >= 9 ? `Tanpa melihat peta: ${a} ada di kotak mana (A1–F8)?` : `${a} ada di kotak peta mana?`,
      pilihan: n ? optionsFrom(ans, pool.length >= n - 1 ? pool : all, n, r) : null, jawaban: ans, penjelasan: `${a} ada di kotak ${ans}.` };
  },
  terdekat(N, L, r) {
    const n = T([2, 3, 3, 3, 4, 4, 4, 5, 5, 5], L), ratio = T([2.5, 2.2, 1.9, 1.6, 1.45, 1.3, 1.2, 1.12, 1.08, 1.04], L);
    for (let t = 0; t < 3000; t++) {
      const x = pick(N.names, r), near = N.names.filter(c => c !== x && D(N, c) !== D(N, x)).sort((a, b) => NW.distance(N, x, a) - NW.distance(N, x, b));
      const cs = shuffle(L >= 5 ? near.slice(3, 3 + T([0, 0, 0, 0, 40, 30, 25, 20, 16, 12], L)) : near.slice(5), r).slice(0, n), d = cs.map(c => NW.distance(N, x, c)).sort((a, b) => a - b);
      if (cs.length < n || new Set(cs.map(c => D(N, c))).size < n) continue;
      if (d[1] / d[0] < ratio || (L >= 6 && d[1] / d[0] > ratio * 1.6)) continue;
      const ans = cs.reduce((a, c) => NW.distance(N, x, c) < NW.distance(N, x, a) ? c : a);
      return { tipe: 'pilihan', peta: { label: L < 8, sorot: [x, ...cs] }, tanya: `Halte mana yang paling dekat (garis lurus) ke ${x}?`, pilihan: cs, jawaban: ans, penjelasan: `${ans} paling dekat.` };
    }
  },
  'peta-buta'(N, L, r) {
    const a = pick(N.names.filter(n => !N.st.get(n).posisi_perkiraan), r), R = T([1400, 1200, 1000, 850, 700, 600, 500, 420, 350, 280], L), S = N.st.get(a);
    return { tipe: 'ketuk', peta: { label: false, lin: L < 7, grid: L < 5, sorot: [] }, tanya: `Ketuk letak ${a} di peta gelap ini.`, jawaban: { x: S.x, y: S.y, radius: R }, penjelasan: `${a} ada di kotak ${S.grid}.` };
  },
  // ===== NUMERIK =====
  'hitung-halte'(N, L, r) {
    const span = T([[1, 2], [2, 3], [3, 4], [4, 6], [5, 8], [6, 10], [8, 12], [10, 15], [12, 18], [14, 24]], L);
    for (let t = 0; t < 500; t++) {
      const l = pick(mainLines(N), r), k = span[0] + Math.floor(r() * (span[1] - span[0] + 1)); if (l.halte.length <= k) continue;
      const i = Math.floor(r() * (l.halte.length - k)), a = l.halte[i], b = l.halte[i + k];
      const useCode = L >= 7 && l.moda === 'BRT', ca = (N.st.get(a).kode || []).find(c => c.startsWith(l.id + '-')), cb = (N.st.get(b).kode || []).find(c => c.startsWith(l.id + '-'));
      if (useCode && (!ca || !cb)) continue;
      return { tipe: 'angka', peta: { label: true, sorot: L < 7 ? [a, b] : [], lin: L < 5 ? [l.id] : null, tampil: L < 9 }, tanya: useCode ? `Naik ${lineName(N, l.id)} dari halte ${ca} ke halte ${cb}. Berapa kali bus berhenti setelah kamu naik (termasuk halte tujuan)?` : `Naik ${lineName(N, l.id)} dari ${a} ke ${b}. Berapa halte yang dilewati sampai tujuan (halte awal tidak dihitung)?`,
        jawaban: k, penjelasan: `${NW.segment(N, l.id, a, b).join(' → ')} = ${k} halte.` };
    }
  },
  ongkos(N, L, r) {
    const g = randomRoute(N, r, T([4, 5, 6, 8, 9, 10, 12, 14, 16, 18], L), T([0, 1, 1, 1, 2, 2, 2, 3, 3, 3], L)), R = g.R, rides = R.legs.filter(l => l.line !== 'walk');
    const moda = l => N.lines[l.line].moda, rules = [], minutes = R.stops * 2 + R.transfers * 5;
    let total;
    if (L <= 2) { rules.push('Setiap kali naik = 2 koin.'); total = rides.length * 2; }
    else if (L <= 4) { rules.push('Setiap kali naik = 2 koin.', 'Tambah 1 koin untuk setiap 5 halte penuh dalam satu kali naik.'); total = rides.reduce((a, l) => a + 2 + Math.floor(l.stops / 5), 0); }
    else if (L <= 6) { rules.push('Transjakarta = 2 koin sekali naik.', 'KRL = 1 koin + 1 koin setiap 4 halte penuh.', 'MRT dan LRT = 3 koin sekali naik.', 'Pindah antar-lin tidak bayar lagi kecuali naik moda yang berbeda.');
      total = 0; let prev = null; for (const l of rides) { const m = moda(l); if (m !== prev) total += m === 'BRT' ? 2 : m === 'KRL' ? 1 + Math.floor(l.stops / 4) : 3; else if (m === 'KRL') total += Math.floor(l.stops / 4); prev = m; } }
    else { rules.push('Transjakarta = 2 koin sekali naik.', 'KRL = 1 koin + 1 koin setiap 4 halte penuh.', 'MRT dan LRT = 3 koin sekali naik.', 'Pindah moda membayar tarif moda baru.', 'Total maksimal 8 koin per perjalanan.', 'Jika memakai 3 moda atau lebih, potong 1 koin (setelah batas maksimal).');
      if (L >= 9) rules.push(`Setiap halte 2 menit, setiap pindah 5 menit. Jika perjalanan lebih dari 45 menit, tambah 2 koin (setelah semua aturan lain). Perjalanan ini: ${R.stops} halte, ${R.transfers} kali pindah.`);
      total = 0; for (const l of rides) total += moda(l) === 'BRT' ? 2 : moda(l) === 'KRL' ? 1 + Math.floor(l.stops / 4) : 3;
      total = Math.min(8, total); if (new Set(rides.map(moda)).size >= 3) total -= 1; if (L >= 9 && minutes > 45) total += 2; }
    return { tipe: 'angka', peta: { label: true, rute: routeStations(R) }, tanya: `Rute: ${rides.map(l => `${lineName(N, l.line)} ${l.from} → ${l.to} (${l.stops} halte)`).join(', lalu ')}.\nAturan Koin Lingko:\n• ${rules.join('\n• ')}\nBerapa koin yang dibayar?`, jawaban: total, penjelasan: `Total ${total} koin.` };
  },
  waktu(N, L, r) {
    const g = randomRoute(N, r, T([3, 4, 5, 6, 8, 9, 10, 12, 14, 16], L), T([0, 0, 0, 1, 1, 1, 2, 2, 3, 3], L)), R = g.R, rides = R.legs.filter(l => l.line !== 'walk');
    const per = { BRT: 2, MRT: 2, LRT: 2, KRL: 3 }, h = 6 + Math.floor(r() * 3), m0 = [0, 5, 10, 15, 20, 30, 40, 45, 50][Math.floor(r() * 9)];
    const headway = L >= 7 ? T([0, 0, 0, 0, 0, 0, 6, 8, 10, 12], L) : 0, transfer = 5;
    let t = h * 60 + m0, rules = [`Berangkat pukul ${String(h).padStart(2, '0')}:${String(m0).padStart(2, '0')}.`, 'Setiap halte: Transjakarta/MRT/LRT 2 menit, KRL 3 menit.'];
    if (R.transfers) rules.push('Setiap pindah lin butuh 5 menit berjalan.');
    if (headway) rules.push(`Setelah pindah, kendaraan berikutnya datang tepat pada menit kelipatan ${headway} (mis. :00, :${String(headway).padStart(2, '0')}, …).`);
    rides.forEach((l, i) => { if (i > 0) { t += transfer; if (headway) t = Math.ceil(t / headway) * headway; } t += l.stops * per[N.lines[l.line].moda]; });
    const ans = `${String(Math.floor(t / 60) % 24).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}`;
    return { tipe: 'jam', peta: { label: true, rute: routeStations(R) }, tanya: `Rute: ${rides.map(l => `${lineName(N, l.line)} ${l.from} → ${l.to} (${l.stops} halte)`).join(', lalu ')}.\n• ${rules.join('\n• ')}\nPukul berapa kamu tiba?`, jawaban: ans, penjelasan: `Tiba pukul ${ans}.` };
  },
  'deret-kode'(N, L, r) {
    const l = pick(Object.values(N.lines).filter(x => x.moda === 'BRT' && !x.id.endsWith('R') && x.halte.length >= 12), r), id = l.id;
    const step = T([1, 1, 1, 2, 2, 3, 3, -2, -3, 4], L), len = T([3, 4, 4, 4, 5, 5, 5, 5, 6, 6], L);
    const start = step > 0 ? 1 + Math.floor(r() * Math.max(1, l.halte.length - step * len)) : l.halte.length - Math.floor(r() * 3);
    const seq = Array.from({ length: len }, (_, i) => start + step * i).filter(v => v >= 1);
    if (seq.length < 3) return GEN['deret-kode'](N, Math.max(1, L - 1), r);
    const hole = L <= 3 ? seq.length - 1 : 1 + Math.floor(r() * (seq.length - 2)), ans = `${id}-${seq[hole]}`;
    return { tipe: 'teks', tanya: `Lanjutkan pola kode halte Koridor ${id}: ${seq.map((v, i) => i === hole ? '❓' : `${id}-${v}`).join(', ')}`, jawaban: ans, penjelasan: `Polanya ${step > 0 ? '+' : ''}${step} → ${ans}.` };
  },
  // ===== LOGIKA =====
  'rute-terbaik'(N, L, r) {
    const tr = T([0, 1, 1, 1, 2, 2, 2, 3, 3, 3], L), g = randomRoute(N, r, T([4, 5, 6, 8, 9, 10, 12, 14, 16, 18], L), tr);
    return { tipe: 'angka', peta: { label: true, sorot: [g.a, g.b], tampil: L < 8 }, tanya: `Dari ${g.a} ke ${g.b}: paling sedikit berapa kali kamu harus PINDAH lin?`, jawaban: g.R.transfers,
      penjelasan: `Rute terbaik: ${g.R.legs.filter(l => l.line !== 'walk').map(l => `${lineName(N, l.line)} (${l.from} → ${l.to})`).join(', ')} = ${g.R.transfers} kali pindah.` };
  },
  'stasiun-misteri'(N, L, r) {
    const nOpt = T([3, 3, 4, 4, 4, 5, 5, 6, 6, 6], L), maxClues = T([1, 2, 2, 2, 3, 3, 4, 4, 5, 6], L);
    for (let t = 0; t < 400; t++) {
      const target = pick(N.names, r), S = N.st.get(target), opts = optionsFrom(target, N.names, nOpt, r);
      const clueFns = shuffle([
        () => { const l = pick(N.linesAt(target), r); return { teks: `Dilewati ${lineName(N, l)}.`, f: n => N.linesAt(n).includes(l) }; },
        () => ({ teks: `Ada di kotak peta ${S.grid[0]} (baris ${S.grid[0]}).`, f: n => N.st.get(n).grid[0] === S.grid[0] }),
        () => ({ teks: `Ada di kolom peta ${S.grid[1]}.`, f: n => N.st.get(n).grid[1] === S.grid[1] }),
        () => { const k = N.linesAt(target).length; return { teks: k > 1 ? `Dilewati lebih dari satu lin.` : `Hanya dilewati satu lin.`, f: n => (N.linesAt(n).length > 1) === (k > 1) }; },
        () => { const ref = pick(['Monumen Nasional', 'Blok M', 'Manggarai KRL', 'Kampung Melayu', 'Grogol Reformasi'], r); const d = NW.dir4(NW.bearing(N, ref, target)); return { teks: `Letaknya di sebelah ${d} ${ref.replace(' KRL', '')}.`, f: n => n !== ref && NW.dir4(NW.bearing(N, ref, n)) === d }; },
        () => { const m = N.st.get(target).moda[0]; return { teks: `Bisa dinaiki dengan ${MODE_LABEL[m]}.`, f: n => N.st.get(n).moda.includes(m) }; },
        () => { const w = target.split(' ').length; return { teks: `Namanya terdiri dari ${w} kata.`, f: n => n.split(' ').length === w }; },
      ], r);
      const clues = []; let cand = opts.slice();
      for (const mk of clueFns) { if (cand.length === 1) break; const c = mk(); const nc = cand.filter(c.f); if (!nc.includes(target) || nc.length === cand.length) continue; clues.push(c.teks); cand = nc; }
      if (cand.length !== 1 || clues.length > maxClues || clues.length < Math.min(maxClues, T([1, 1, 1, 2, 2, 2, 3, 3, 3, 4], L))) continue;
      return { tipe: 'pilihan', peta: { label: true, grid: true, tampil: L < 9 }, tanya: `Aku sebuah halte/stasiun.\n• ${clues.join('\n• ')}\nSiapakah aku?`, pilihan: opts, jawaban: target, penjelasan: `Hanya ${target} yang cocok dengan semua petunjuk.` };
    }
    return GEN['stasiun-misteri'](N, Math.max(1, L - 1), r);
  },
  gangguan(N, L, r) {
    for (let t = 0; t < 40; t++) {
      const g = randomRoute(N, r, T([5, 6, 7, 8, 9, 10, 12, 14, 16, 18], L), T([0, 0, 1, 1, 1, 2, 2, 2, 3, 3], L), 80);
      const mid = shuffle(routeStations(g.R).slice(1, -1).filter(m => m !== g.a && m !== g.b), r);
      for (const closed of mid.slice(0, 6)) {
        const R2 = NW.shortestRoute(withoutStation(N, closed), g.a, g.b, 'transit'); if (!R2) continue;
        const delta = R2.transfers - g.R.transfers;
        if (L >= 6 && delta < 1) continue; if (L <= 3 && R2.transfers > 1) continue; if (L <= 5 && R2.transfers > 2) continue;
        return { tipe: 'angka', peta: { label: true, sorot: [g.a, g.b, closed], tampil: L < 8 }, tanya: `Halte ${closed} DITUTUP (kendaraan tidak bisa lewat). Dari ${g.a} ke ${g.b}, sekarang paling sedikit berapa kali pindah lin?`, jawaban: R2.transfers,
          penjelasan: `Sebelum ditutup: ${g.R.transfers} kali pindah. Rute pengganti: ${R2.legs.filter(l => l.line !== 'walk').map(l => lineName(N, l.line)).join(' → ')} = ${R2.transfers} kali pindah.` };
      }
    }
  },
  'benar-salah'(N, L, r) {
    const facts = [];
    const fact = () => { const a = pick(N.names, r), b = pick(N.names, r); if (a === b) return fact(); const kind = Math.floor(r() * 3);
      if (kind === 0) { const d = NW.dir4(NW.bearing(N, a, b)), claim = r() < 0.5 ? d : pick(NW.COMPASS4, r); return { teks: `${b} ada di sebelah ${claim} ${a}`, v: claim === d }; }
      if (kind === 1) { const l = pick(mainLines(N), r); return { teks: `${a} dilewati ${lineName(N, l.id)}`, v: N.linesAt(a).includes(l.id) }; }
      const g = N.st.get(a).grid, claim = r() < 0.5 ? g : pick(['A', 'B', 'C', 'D', 'E', 'F'], r) + g[1]; return { teks: `${a} ada di kotak ${claim}`, v: claim === g }; };
    const p = fact(), q = fact(), s = fact();
    let teks, v;
    if (L <= 3) { teks = p.teks + '.'; v = p.v; }
    else if (L <= 5) { teks = `${p.teks} DAN ${q.teks}.`; v = p.v && q.v; }
    else if (L <= 7) { teks = `${p.teks} ATAU ${q.teks}.`; v = p.v || q.v; if (L === 7) { teks = `TIDAK benar bahwa ${p.teks}, ATAU ${q.teks}.`; v = !p.v || q.v; } }
    else if (L <= 9) { teks = `JIKA ${p.teks}, MAKA ${q.teks}.`; v = !p.v || q.v; }
    else { teks = `JIKA (${p.teks} DAN ${q.teks}), MAKA TIDAK ${s.teks}.`; v = !(p.v && q.v) || !s.v; }
    return { tipe: 'pilihan', peta: { label: true, tampil: L < 8 }, tanya: `Benar atau salah?\n${teks}`, pilihan: ['Benar', 'Salah'], jawaban: v ? 'Benar' : 'Salah', penjelasan: `Fakta: "${p.teks}" ${p.v ? 'benar' : 'salah'}; "${q.teks}" ${q.v ? 'benar' : 'salah'}${L >= 10 ? `; "${s.teks}" ${s.v ? 'benar' : 'salah'}` : ''}.` };
  },
};
function withoutStation(N, x) {
  const adj = new Map(); for (const [k, v] of N.adj) if (k !== x) adj.set(k, v.filter(e => e.to !== x));
  const walk = new Map(); for (const [k, v] of N.walk) if (k !== x) walk.set(k, v.filter(b => b !== x));
  return { ...N, adj, walk, linesAt: n => n === x ? [] : N.linesAt(n), _cache: new Map() };   // cache rute baru: jaringan berubah
}

// ---------- API ----------
// Ganti nama simpul internal ("Duri KRL") dengan nama tampilan ("Duri (KRL)") di teks, pilihan, dan jawaban
function relabel(N, item) {
  const internal = N.names.filter(n => / (KRL|LRT|MRT)$/.test(n)).sort((a, b) => b.length - a.length);
  const fix = v => typeof v === 'string' ? internal.reduce((s, n) => s.split(n).join(D(N, n)), v) : Array.isArray(v) ? v.map(fix) : v;
  for (const k of ['tanya', 'penjelasan']) if (item[k]) item[k] = fix(item[k]);
  if (item.pilihan && item.tipe !== 'urutan') item.pilihan = fix(item.pilihan);
  if (typeof item.jawaban === 'string') item.jawaban = fix(item.jawaban);
  if (item.fase && item.fase.hafal && item.fase.hafal.urutan) { item.fase.hafal.urutan = fix(item.fase.hafal.urutan); if (item.tipe === 'urutan') { item.jawaban = fix(item.jawaban); item.pilihan = fix(item.pilihan); } }
  return item;
}
function generate(N, family, level, seed) {
  const L = Math.max(1, Math.min(10, Math.round(level)));
  let raw = null;
  for (let k = 0; k < 12 && !raw; k++) raw = GEN[family](N, L, rngFrom(`${family}|${L}|${seed}|${k}`));   // coba seed lain jika syarat tidak terpenuhi
  if (!raw) throw new Error(`gagal membuat soal ${family} level ${L}`);
  const item = relabel(N, raw);
  return { id: `${family}:${L}:${seed}`, family, ranah: FAMILY[family].ranah, nama: FAMILY[family].nama, level: L, levelNama: LEVELS[L - 1], b: bOf(family, L), batasDetik: TIME(L) + (item.fase && item.fase.hafal ? item.fase.hafal.detik : 0), ...item };
}
const normText = s => String(s).trim().toLowerCase().replace(/\s+/g, '').replace('.', ':');
function check(item, resp) {
  const a = item.jawaban;
  if (item.tipe === 'urutan') { const ok = Array.isArray(resp) && resp.length === a.length && resp.every((x, i) => x === a[i]); const part = Array.isArray(resp) ? a.filter((x, i) => resp[i] === x).length / a.length : 0; return { benar: ok, sebagian: part }; }
  if (item.tipe === 'ketuk') { const d = resp ? Math.hypot(resp.x - a.x, resp.y - a.y) : Infinity; return { benar: d <= a.radius, sebagian: Math.max(0, 1 - d / (3 * a.radius)), jarak: d }; }
  if (item.tipe === 'angka') { const ok = Number(String(resp).replace(',', '.')) === a; return { benar: ok, sebagian: ok ? 1 : 0, selisih: Number(resp) - a }; }
  if (item.tipe === 'jam') { const ok = normText(resp) === normText(a); return { benar: ok, sebagian: ok ? 1 : 0 }; }
  const ok = normText(resp) === normText(a); return { benar: ok, sebagian: ok ? 1 : 0 };
}
// Tampilan aman untuk klien: tanpa jawaban & penjelasan
function publicItem(it) { const { jawaban, penjelasan, ...rest } = it; return rest; }

export { FAMILY, DOMAINS, LEVELS, familiesOf, bOf, generate, check, publicItem, rngFrom, withoutStation };

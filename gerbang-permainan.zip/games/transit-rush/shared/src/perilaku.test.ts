﻿import { describe, expect, it } from "vitest";
import { hitungPerilaku } from "./perilaku";
import type { JawabLog } from "./perilaku";

const L = (i: number, benar: boolean, detik: number, o: Partial<JawabLog> = {}): JawabLog => ({
  no: i,
  family: "arah",
  nama: "Arah Mata Angin",
  level: 3,
  ranah: "spasial",
  benar,
  sebagian: benar ? 1 : 0,
  detik,
  batas: 30,
  habis: false,
  ...o,
});

describe("statistik perilaku bermain", () => {
  it("tanpa jawaban: null", () => expect(hitungPerilaku([], [], 0)).toBeNull());

  it("pemain cepat dan tepat", () => {
    const log = Array.from({ length: 10 }, (_, i) => L(i + 1, true, 6));
    const p = hitungPerilaku(log, [], 10)!;
    expect(p.akurasi).toBe(1);
    expect(p.medianDetik).toBe(6);
    expect(p.pakaiWaktuPersen).toBe(20);
    expect(p.gaya).toBe("Cepat dan tepat");
    expect(p.tren).toBe("stabil");
    expect(p.maksStreak).toBe(10);
  });

  it("pemain terburu-buru: salah dalam < 20% waktu", () => {
    const log = Array.from({ length: 8 }, (_, i) => L(i + 1, i % 4 === 0, 2));
    const p = hitungPerilaku(log, [], 1)!;
    expect(p.gegabah).toBe(6);
    expect(p.gaya).toBe("Cepat, tapi sering terburu-buru");
    expect(p.catatan.join(" ")).toMatch(/sangat cepat/);
  });

  it("pemain teliti memakai banyak waktu dan tepat", () => {
    const log = Array.from({ length: 8 }, (_, i) => L(i + 1, true, 22));
    const p = hitungPerilaku(log, [], 8)!;
    expect(p.pakaiWaktuPersen).toBe(73);
    expect(p.cermat).toBe(8);
    expect(p.gaya).toBe("Teliti dan hati-hati");
  });

  it("kehabisan waktu berulang dihitung, tren naik/turun dari dua paruh, jenis kuat dan lemah", () => {
    const naik = [
      ...Array.from({ length: 6 }, (_, i) => L(i + 1, i < 1, 10)),
      ...Array.from({ length: 6 }, (_, i) => L(i + 7, true, 10, { family: "grid", nama: "Cari Kotak Peta" })),
    ];
    const p = hitungPerilaku(naik, [{ jenis: "fokus-hilang" }, { jenis: "terlalu-cepat" }], 6)!;
    expect(p.tren).toBe("naik");
    expect(p.akurasiAwal).toBeLessThan(p.akurasiAkhir!);
    expect(p.jenisKuat[0]!.nama).toBe("Cari Kotak Peta");
    expect(p.jenisLemah?.nama).toBe("Arah Mata Angin");
    expect(p.fokusHilang).toBe(1);
    expect(p.bendera).toBe(2);
    const habis = Array.from({ length: 5 }, (_, i) => L(i + 1, false, 30, { habis: true }));
    const q = hitungPerilaku(habis, [], 0)!;
    expect(q.habis).toBe(5);
    expect(q.gaya).toBe("Sering kehabisan waktu");
    const turun = [
      ...Array.from({ length: 6 }, (_, i) => L(i + 1, true, 10)),
      ...Array.from({ length: 6 }, (_, i) => L(i + 7, i === 0, 10)),
    ];
    expect(hitungPerilaku(turun, [], 6)!.tren).toBe("turun");
  });

  it("kurang dari 6 jawaban: tren tidak ditebak", () => {
    expect(hitungPerilaku([L(1, true, 5), L(2, false, 5)], [], 1)!.tren).toBeNull();
  });
});

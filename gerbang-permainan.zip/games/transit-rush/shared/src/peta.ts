// Model geometri peta skematik: dibangun sendiri dari data jaringan (bukan gambar peta asli). Murni, tanpa DOM.
import type { DataJaringan, PetaGambar } from "./types";

export interface PetaOpsi {
  /** true = semua nama halte tampil (kecil, terbaca saat diperbesar); false = hanya halte yang disorot/rute */
  label?: boolean;
  /** false = lin disembunyikan */
  lin?: boolean | null;
  grid?: boolean;
  /** false = peta tidak ditampilkan sama sekali */
  tampil?: boolean;
  /** derajat putar (180 = terbalik) */
  putar?: number;
  sorot?: string[];
  rute?: string[];
}

export interface GarisLin {
  id: string;
  warna: string;
  moda: string;
  nama: string;
  /** path SVG, satu per segmen antar-halte berurutan */
  segmen: { d: string; cek: boolean }[];
}
export interface TitikHalte {
  nama: string;
  x: number;
  y: number;
  hub: boolean;
  perkiraan: boolean;
  grid: string;
  /** "penanda-peta" = tepat di penanda stasiun peta FDTJ; "label" = perkiraan dari letak label */
  sumber?: string;
}
export interface SelGrid {
  kode: string;
  x: number;
  y: number;
  w: number;
  h: number;
}
export interface PetaModel {
  view: { x: number; y: number; w: number; h: number };
  lin: GarisLin[];
  halte: TitikHalte[];
  grid: SelGrid[];
  byNama: Map<string, TitikHalte>;
  /** gambar ulang peta (garis lin asli, air, taman); kosong = jatuh ke garis antar-halte */
  gambar?: PetaGambar;
}

const HURUF = "ABCDEF";

/** Rute oktilinear (0/45/90 derajat) dari a ke b dengan satu tekukan. */
export function jalurOktilinear(a: [number, number], b: [number, number]): [number, number][] {
  const dx = b[0] - a[0];
  const dy = b[1] - a[1];
  const adx = Math.abs(dx);
  const ady = Math.abs(dy);
  if (adx < 1 || ady < 1 || Math.abs(adx - ady) < 1) return [a, b];
  const d = Math.min(adx, ady);
  const mid: [number, number] =
    adx > ady ? [a[0] + Math.sign(dx) * (adx - d), a[1]] : [a[0], a[1] + Math.sign(dy) * (ady - d)];
  return [a, mid, b];
}

export function bangunPeta(data: DataJaringan, gambar?: PetaGambar): PetaModel {
  const meta = data.meta as {
    kolom_x?: number[];
    baris_y?: number[];
    grid_batas?: { xs: number[]; ys: number[] };
    bingkai?: { x0: number; y0: number; x1: number; y1: number };
  };
  const gb = gambar?.grid ?? meta.grid_batas;
  let xs: number[];
  let ys: number[];
  if (gb) {
    xs = gb.xs;
    ys = gb.ys;
  } else {
    const kx = meta.kolom_x ?? [628, 1679, 2737, 3793, 4851, 5908, 6966, 8022];
    const by = meta.baris_y ?? [1194, 2184, 3174, 4164, 5154, 6144];
    const w0 = (kx[kx.length - 1]! - kx[0]!) / (kx.length - 1);
    const h0 = (by[by.length - 1]! - by[0]!) / (by.length - 1);
    xs = Array.from({ length: kx.length + 1 }, (_, i) => kx[0]! - w0 / 2 + i * w0);
    ys = Array.from({ length: by.length + 1 }, (_, i) => by[0]! - h0 / 2 + i * h0);
  }
  const grid: SelGrid[] = [];
  for (let r = 0; r < ys.length - 1; r++)
    for (let c = 0; c < xs.length - 1; c++)
      grid.push({ kode: `${HURUF[r]}${c + 1}`, x: xs[c]!, y: ys[r]!, w: xs[c + 1]! - xs[c]!, h: ys[r + 1]! - ys[r]! });
  const fr = gambar?.frame ??
    meta.bingkai ?? { x0: xs[0]!, y0: ys[0]!, x1: xs[xs.length - 1]!, y1: ys[ys.length - 1]! };

  const byNama = new Map<string, TitikHalte>();
  const halte: TitikHalte[] = data.halte.map((s) => {
    const t: TitikHalte = {
      nama: s.nama,
      x: s.x,
      y: s.y,
      hub: s.lin.length > 1 || s.moda.length > 1,
      perkiraan: !!s.posisi_perkiraan,
      grid: s.grid,
      sumber: s.posisi_sumber,
    };
    byNama.set(s.nama, t);
    return t;
  });
  const lin: GarisLin[] = Object.values(data.lin).map((l) => {
    const cek = new Set((l as { segmen_perlu_cek?: number[] }).segmen_perlu_cek ?? []);
    const segmen: GarisLin["segmen"] = [];
    for (let i = 0; i + 1 < l.halte.length; i++) {
      const a = byNama.get(l.halte[i]!);
      const b = byNama.get(l.halte[i + 1]!);
      if (!a || !b) continue;
      const p = jalurOktilinear([a.x, a.y], [b.x, b.y]);
      segmen.push({
        d: p.map((q, j) => `${j ? "L" : "M"}${Math.round(q[0])} ${Math.round(q[1])}`).join(" "),
        cek: cek.has(i),
      });
    }
    return { id: l.id, warna: l.warna, moda: l.moda, nama: l.nama, segmen };
  });
  return {
    view: { x: fr.x0, y: fr.y0, w: fr.x1 - fr.x0, h: fr.y1 - fr.y0 },
    lin,
    halte,
    grid,
    byNama,
    gambar,
  };
}

/** Sel grid (A1–F8) dari koordinat peta; null bila di luar grid. */
export function selDari(m: PetaModel, x: number, y: number): string | null {
  for (const g of m.grid) if (x >= g.x && x < g.x + g.w && y >= g.y && y < g.y + g.h) return g.kode;
  return null;
}

/** Ubah koordinat layar-di-viewBox menjadi koordinat peta bila peta diputar `putar` derajat (0/180). */
export function kePeta(m: PetaModel, x: number, y: number, putar = 0): [number, number] {
  if (((putar % 360) + 360) % 360 !== 180) return [x, y];
  const cx = m.view.x + m.view.w / 2;
  const cy = m.view.y + m.view.h / 2;
  return [2 * cx - x, 2 * cy - y];
}

/** Halte terdekat dari titik (untuk editor jaringan dan penanda ketuk). */
export function halteTerdekat(m: PetaModel, x: number, y: number): TitikHalte | null {
  let best: TitikHalte | null = null;
  let bd = Infinity;
  for (const h of m.halte) {
    const d = Math.hypot(h.x - x, h.y - y);
    if (d < bd) {
      bd = d;
      best = h;
    }
  }
  return best;
}

/** Pilih warna teks hitam/putih untuk latar warna lin. */
export function warnaTeks(hex: string): string {
  const v = hex.replace("#", "");
  const n = parseInt(v.length === 3 ? v.replace(/./g, "$&$&") : v, 16);
  const l = 0.299 * ((n >> 16) & 255) + 0.587 * ((n >> 8) & 255) + 0.114 * (n & 255);
  return l > 150 ? "#111" : "#fff";
}

import { describe, expect, it } from "vitest";
import data from "../../data/jaringan_jakarta.json";
import { bangunPeta, jalurOktilinear, kePeta, selDari } from "./peta";
import gambar from "../../data/peta_gambar.json";
import type { DataJaringan, PetaGambar } from "./types";

const g = gambar as unknown as PetaGambar;
const m = bangunPeta(data as unknown as DataJaringan, g);

describe("model peta (M1)", () => {
  it("setiap halte jatuh di sel grid yang tercatat", () => {
    let salah = 0;
    for (const h of m.halte) if (selDari(m, h.x, h.y) !== h.grid) salah++;
    expect(salah).toBe(0);
  });
  it("335 halte, 25 lin, 48 sel grid, semua halte lin ada", () => {
    expect(m.halte.length).toBe(335);
    expect(m.lin.length).toBe(25);
    expect(m.grid.length).toBe(48);
    for (const l of m.lin) expect(l.segmen.length).toBeGreaterThan(0);
  });
  it("jalur oktilinear hanya 0/45/90 derajat", () => {
    for (const l of Object.values((data as unknown as DataJaringan).lin)) {
      for (let i = 0; i + 1 < l.halte.length; i++) {
        const a = m.byNama.get(l.halte[i]!)!;
        const b = m.byNama.get(l.halte[i + 1]!)!;
        const p = jalurOktilinear([a.x, a.y], [b.x, b.y]);
        for (let j = 0; j + 1 < p.length; j++) {
          const dx = Math.abs(p[j + 1]![0] - p[j]![0]);
          const dy = Math.abs(p[j + 1]![1] - p[j]![1]);
          expect(dx < 1 || dy < 1 || Math.abs(dx - dy) < 1.5).toBe(true);
        }
      }
    }
  });
  it("putar 180 dapat dibalik", () => {
    const [x, y] = kePeta(m, 1000, 2000, 180);
    const [a, b] = kePeta(m, x, y, 180);
    expect([Math.round(a), Math.round(b)]).toEqual([1000, 2000]);
  });
  it("tanda perkiraan dan segmen perlu dicek dipertahankan", () => {
    expect(m.halte.filter((h) => h.perkiraan).length).toBeGreaterThan(0);
    expect(m.lin.some((l) => l.segmen.some((s) => s.cek))).toBe(true);
  });

  it("gambar ulang dari peta FDTJ: lapisan lengkap, bingkai dan grid sesuai peta", () => {
    for (const t of ["a", "w", "p", "b", "l", "r", "x"] as const) expect(g.items.some((i) => i.t === t)).toBe(true);
    expect(g.items.filter((i) => i.t === "l").length).toBeGreaterThanOrEqual(90);
    expect(g.penanda.length).toBeGreaterThan(300);
    expect(g.grid.xs.length).toBe(9);
    expect(g.grid.ys.length).toBe(7);
    expect(m.view).toEqual({ x: g.frame.x0, y: g.frame.y0, w: g.frame.x1 - g.frame.x0, h: g.frame.y1 - g.frame.y0 });
    expect(g.teks.map((x) => x.s)).toContain("Teluk Jakarta");
  });
  it("halte yang diselaraskan ke peta tepat berada di penanda stasiun peta asli", () => {
    const sel = (data as unknown as DataJaringan).halte.filter((h) => h.posisi_sumber === "penanda-peta");
    expect(sel.length).toBeGreaterThan(300);
    const semua = [...g.penanda, ...g.penandaRel];
    for (const h of sel) expect(semua.some((p) => Math.hypot(p[0] - h.x, p[1] - h.y) < 1.5)).toBe(true);
  });

  it("13 stasiun MRT Jakarta (Lebak Bulus sampai Bundaran HI) tepat di tengah penanda stasiun, berurutan dari selatan ke utara", () => {
    const d = data as unknown as DataJaringan;
    const hs = d.lin["M"]!.halte.map((n) => d.halte.find((h) => h.nama === n)!);
    expect(hs.length).toBe(13);
    for (const h of hs) expect(g.penandaRel.some((p) => Math.hypot(p[0] - h.x, p[1] - h.y) < 1.5)).toBe(true);
    expect(hs[0]!.nama).toMatch(/Lebak Bulus/);
    expect(hs[0]!.x).toBeLessThan(hs[1]!.x);
    for (let i = 2; i < hs.length; i++) expect(hs[i]!.y).toBeLessThan(hs[i - 1]!.y);
    expect(new Set(hs.map((h) => `${h.x},${h.y}`)).size).toBe(13);
  });
});

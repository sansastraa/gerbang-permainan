/** Tipe fasad untuk engine (port mekanis, jadi bentuk datanya dipetakan di sini). */
export type Ranah = "memori" | "spasial" | "numerik" | "logika";
export const RANAH: readonly Ranah[] = ["memori", "spasial", "numerik", "logika"];

/** Soal lengkap (hanya di server). */
export interface ItemPenuh {
  family: string;
  level: number;
  jawaban: unknown;
  penjelasan?: string;
  [k: string]: unknown;
}
/** Soal yang boleh dikirim ke klien: tanpa `jawaban` dan `penjelasan`. */
export type ItemPublik = Omit<ItemPenuh, "jawaban" | "penjelasan">;

export interface Halte {
  id: string;
  nama: string;
  moda: string[];
  lin: string[];
  kode: string[];
  x: number;
  y: number;
  grid: string;
  posisi_perkiraan?: boolean;
  posisi_sumber?: "penanda-peta" | "label";
}
export interface LinData {
  id: string;
  moda: string;
  nama: string;
  warna: string;
  halte: string[];
}
export interface DataJaringan {
  meta: unknown;
  lin: Record<string, LinData>;
  halte: Halte[];
  transit: unknown;
}

/** Satu elemen gambar peta hasil gambar ulang dari peta FDTJ 2026-08c (a=daratan, w=air, p=taman, b=batas wilayah, r=lin rencana, l=lin, x=penghubung antarmoda). */
export interface ItemGambar {
  t: "a" | "w" | "p" | "b" | "r" | "l" | "x";
  c: string;
  d: string;
  w?: number;
  dash?: number[];
  cap?: number;
  join?: number;
}
export interface PetaGambar {
  frame: { x0: number; y0: number; x1: number; y1: number };
  grid: { xs: number[]; ys: number[] };
  items: ItemGambar[];
  penanda: [number, number][];
  /** penanda stasiun rel (cakram berwarna lin): x, y, warna */
  penandaRel: [number, number, string][];
  teks: { s: string; x: number; y: number; h: number; r: number }[];
}

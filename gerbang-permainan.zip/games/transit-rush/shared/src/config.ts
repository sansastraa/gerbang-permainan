import config from "../../config/transit-rush.config.json";

export const CONFIG = config;
export const LEVEL_NAMA: readonly string[] = config.level;
export const MAKS_ARENA = config.pemain.maks_arena;
export const PIN_PANJANG = config.pemain.pin_panjang;

import { FAMILY } from "./engine/tr-items";
import type { Ranah } from "./types";
/** Katalog 16 jenis soal dengan tipe yang jelas. */
export const FAMILI = FAMILY as Record<string, { ranah: Ranah; nama: string; dasar: number; miring: number }>;

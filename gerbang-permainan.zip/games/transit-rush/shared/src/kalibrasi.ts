// Kalibrasi dari data jawaban nyata (CSV: pemain,usia,jenis,level,benar) dan penerapan norma hasilnya.
import * as IRT from "./engine/tr-irt";

export interface Kalibrasi {
  dibuat: string;
  b: Record<string, number>;
  norma: Record<string, { mu: number; sd: number; n: number }>;
}

export function kalibrasiDariCsv(csv: string, iters = 60): Kalibrasi {
  const baris = csv.trim().split(/\r?\n/).slice(1);
  const rows = baris
    .map((l) => l.split(","))
    .filter((c) => c.length >= 5)
    .map((c) => ({ pemain: c[0]!, usia: Number(c[1]), item: `${c[2]}:${c[3]}`, x: Number(c[4]) }));
  if (rows.length === 0) throw new Error("CSV kosong.");
  const C = IRT.calibrate(
    rows.map((r) => ({ person: r.pemain, item: r.item, x: r.x })),
    iters,
  ) as { b: Record<string, number>; theta: Record<string, number> };
  const grup: Record<string, Map<string, number>> = {};
  for (const r of rows) (grup[IRT.ageBand(r.usia) as string] ??= new Map()).set(r.pemain, C.theta[r.pemain]!);
  const norma: Kalibrasi["norma"] = {};
  for (const [g, m] of Object.entries(grup)) {
    const v = [...m.values()];
    const mu = v.reduce((a, b) => a + b, 0) / v.length;
    const sd = Math.sqrt(v.reduce((a, b) => a + (b - mu) ** 2, 0) / Math.max(1, v.length - 1));
    norma[g] = { mu: +mu.toFixed(3), sd: +sd.toFixed(3), n: v.length };
  }
  return { dibuat: new Date().toISOString(), b: C.b, norma };
}

export const NORMA_MIN_N = 30;
const status = { sementara: true };
export const normaSementara = (): boolean => status.sementara;

/** Ganti norma bawaan dengan norma kalibrasi untuk kelompok usia yang datanya cukup (n >= NORMA_MIN_N). */
export function terapkanNorma(k: Pick<Kalibrasi, "norma">): string[] {
  const dipakai: string[] = [];
  const N = IRT.NORMS as Record<string, { mu: number; sd: number }>;
  for (const [g, v] of Object.entries(k.norma)) {
    if (N[g] && v.n >= NORMA_MIN_N && v.sd > 0.2) {
      N[g]!.mu = v.mu;
      N[g]!.sd = v.sd;
      dipakai.push(g);
    }
  }
  status.sementara = dipakai.length < Object.keys(N).length;
  return dipakai;
}

// Poin, rapor yang diperkaya rentang ketidakpastian, dan ringkasan summary.json (kontrak Multi Permainan).
import * as IRT from "./engine/tr-irt";
import { normaSementara } from "./kalibrasi";
import type { Perilaku } from "./perilaku";
import { RANAH } from "./types";
import type { Ranah } from "./types";

export function poinSoal(level: number, benar: boolean, sebagian: number, sisaFrac: number, streak: number): number {
  if (benar) {
    const f = Math.max(0, Math.min(1, sisaFrac));
    return Math.round(10 * level * (0.6 + 0.4 * f) * (1 + Math.min(streak, 5) * 0.1));
  }
  return Math.round(level * 2 * Math.max(0, Math.min(1, sebagian)));
}

export interface RaporRanah {
  label: string;
  theta: number;
  sem: number;
  soal: number;
  benar: number;
  level: number;
  skorStandar: number;
  persentil: number;
  rentangPersentil90: [number, number];
  /** skor standar 100±15 dengan selang 90% (ketidakpastian pengukuran) */
  rentangSkor90: [number, number];
  stanine: number;
  medianDetik: number | null;
}
export interface Rapor {
  kelompokUsia: string;
  normaSementara: boolean;
  catatanNorma: string;
  IKP: RaporRanah & { nama: string };
  ranah: Record<Ranah, RaporRanah>;
  kekuatan: { ranah: Ranah | null; teks: string };
  tipe: string;
  rush: { soal: number; benar: number; benarPerMenit: number | null };
  reliabilitasPerkiraan: number;
  saran: string;
  perilaku: Perilaku | null;
  jejak: { ranah: Ranah; family: string; level: number; benar: boolean; theta: number; sem: number }[];
}

/* eslint-disable @typescript-eslint/no-explicit-any */
type Sesi = any;

const SARAN: Record<Ranah, string> = {
  memori: "Latih Hafal Rute dan Halte Hilang: ucapkan nama halte sambil menunjuk di peta.",
  spasial: "Latih Arah Mata Angin dan Cari Kotak Peta: tebak dulu arah, baru periksa peta.",
  numerik: "Latih Hitung Halte dan Deret Kode: hitung selisih nomor halte dengan jari.",
  logika: "Latih Rute Terbaik dan Stasiun Misteri: cari rute dengan paling sedikit pindah lin.",
};

/** Rapor dari sesi adaptif. Selalu memuat rentang ketidakpastian dan label norma sementara. */
export function buatRapor(S: Sesi, perilaku: Perilaku | null = null): Rapor {
  const r: any = IRT.report(S);
  const n: { mu: number; sd: number } = (IRT.NORMS as any)[S.band];
  const rentang = (theta: number, sem: number): [number, number] => {
    const lo = 100 + (15 * (theta - 1.645 * sem - n.mu)) / n.sd;
    const hi = 100 + (15 * (theta + 1.645 * sem - n.mu)) / n.sd;
    return [Math.round(lo), Math.round(hi)];
  };
  const ranah = {} as Record<Ranah, RaporRanah>;
  for (const d of RANAH) ranah[d] = { ...r.ranah[d], rentangSkor90: rentang(r.ranah[d].theta, r.ranah[d].sem) };
  const lemah = [...RANAH].sort((a, b) => ranah[a].theta - ranah[b].theta)[0]!;
  return {
    kelompokUsia: r.kelompokUsia,
    normaSementara: normaSementara(),
    catatanNorma: normaSementara()
      ? "Norma sementara: perbandingan dengan teman seusia memakai angka bawaan, belum dari uji lapangan. Ini profil permainan, bukan tes IQ atau alat seleksi."
      : "Norma dari data kalibrasi sebagian kelompok usia; kelompok lain masih memakai norma sementara. Ini profil permainan, bukan tes IQ atau alat seleksi.",
    IKP: { ...r.IKP, rentangSkor90: rentang(r.IKP.theta, r.IKP.sem) },
    ranah,
    kekuatan: r.kekuatan,
    tipe:
      RANAH.filter((d) => ranah[d].soal > 0).length < 2 ? "Profil belum lengkap (kurang dari 2 ranah diuji)" : r.tipe,
    rush: r.rush,
    reliabilitasPerkiraan: r.reliabilitasPerkiraan,
    saran: SARAN[lemah],
    perilaku,
    jejak: S.history.map((h: any) => ({
      ranah: h.ranah,
      family: h.family,
      level: h.level,
      benar: h.benar,
      theta: +h.theta.toFixed(2),
      sem: +h.sem.toFixed(2),
    })),
  };
}

export interface RingkasanSiswa {
  peringkat: number;
  absen: number | null;
  nama: string;
  siswaId: string | null;
  skor: number;
  soal: number;
  benar: number;
  akurasi: number | null;
  waktuMs: number;
  ikp: number | null;
  ikpRentang90: [number, number] | null;
  levelPenjelajah: number | null;
  tipe: string | null;
  il: number | null;
  im: number | null;
  is: number | null;
  ranah: Record<string, { skorStandar: number; rentang90: [number, number]; persentil: number }> | null;
  maksStreak: number;
  bendera: number;
  perilaku: {
    medianDetik: number;
    pakaiWaktuPersen: number;
    habis: number;
    gegabah: number;
    tren: string | null;
    gaya: string;
  } | null;
  selesai: boolean;
  uji: boolean;
}
export interface RingkasanTR {
  game: "transit-rush";
  versi: 1;
  sesiId: string;
  nama: string;
  mode: string;
  selesai: boolean;
  normaSementara: true;
  dibuat: number;
  siswa: RingkasanSiswa[];
}

const sel = (v: unknown): string => {
  const s = v === null || v === undefined ? "" : String(v);
  const aman = /^[=+\-@]/.test(s) ? "'" + s : s;
  return /[",\n]/.test(aman) ? `"${aman.replace(/"/g, '""')}"` : aman;
};
export function csvRingkasan(r: RingkasanTR): string {
  const kepala = [
    "peringkat",
    "absen",
    "nama",
    "siswa_id",
    "poin",
    "soal",
    "benar",
    "ikp",
    "ikp_bawah90",
    "ikp_atas90",
    "level_penjelajah",
    "tipe",
    "memori",
    "spasial",
    "numerik",
    "logika",
    "bendera",
    "norma_sementara",
  ];
  const baris = r.siswa.map((s) => [
    s.peringkat,
    s.absen,
    s.nama,
    s.siswaId,
    s.skor,
    s.soal,
    s.benar,
    s.ikp,
    s.ikpRentang90?.[0] ?? "",
    s.ikpRentang90?.[1] ?? "",
    s.levelPenjelajah,
    s.tipe,
    s.ranah?.["memori"]?.skorStandar ?? "",
    s.ranah?.["spasial"]?.skorStandar ?? "",
    s.ranah?.["numerik"]?.skorStandar ?? "",
    s.ranah?.["logika"]?.skorStandar ?? "",
    s.bendera,
    "ya",
  ]);
  return "﻿" + [kepala, ...baris].map((b) => b.map(sel).join(",")).join("\n") + "\n";
}

import { describe, expect, it } from "vitest";
import { IRT, NW, ITEMS, kalibrasiDariCsv, terapkanNorma, normaSementara } from "./index";

function rng(seed: number) {
  let a = seed;
  return () => (a = (a * 1664525 + 1013904223) % 4294967296) / 4294967296;
}
describe("kalibrasi & norma (M7)", () => {
  it("kalibrasiDariCsv memulihkan kesulitan butir dan norma per usia dari data simulasi", () => {
    const r = rng(7);
    const items = Array.from({ length: 12 }, (_, i) => ({ k: `arah:${i + 1}`, b: -2.5 + i * 0.45 }));
    const gauss = () => Math.sqrt(-2 * Math.log(r() || 1e-9)) * Math.cos(2 * Math.PI * r());
    const baris = ["pemain,usia,jenis,level,benar"];
    for (let p = 0; p < 120; p++) {
      const usia = p % 2 ? 9 : 14;
      const th = (usia === 9 ? -0.8 : 0.5) + 0.9 * gauss();
      for (const it of items) {
        const [jenis, level] = it.k.split(":");
        baris.push(`P${p},${usia},${jenis},${level},${r() < IRT.P(th, it.b) ? 1 : 0}`);
      }
    }
    const k = kalibrasiDariCsv(baris.join("\n"));
    const est = items.map((i) => k.b[i.k]!);
    const m1 = items.reduce((a, i) => a + i.b, 0) / items.length;
    const m2 = est.reduce((a, b) => a + b, 0) / est.length;
    let sxy = 0,
      sxx = 0,
      syy = 0;
    items.forEach((i, j) => {
      sxy += (i.b - m1) * (est[j]! - m2);
      sxx += (i.b - m1) ** 2;
      syy += (est[j]! - m2) ** 2;
    });
    expect(sxy / Math.sqrt(sxx * syy)).toBeGreaterThan(0.97);
    expect(k.norma["9-10"]!.mu).toBeLessThan(k.norma["13-15"]!.mu);
    expect(k.norma["9-10"]!.n).toBe(60);
  });
  it("terapkanNorma hanya untuk kelompok dengan n cukup; label sementara tetap bila ada kelompok belum terkalibrasi", () => {
    const awal = JSON.parse(JSON.stringify(IRT.NORMS));
    const dipakai = terapkanNorma({ norma: { "9-10": { mu: -0.5, sd: 1, n: 60 }, "13-15": { mu: 0.9, sd: 1, n: 5 } } });
    expect(dipakai).toEqual(["9-10"]);
    expect(IRT.NORMS["9-10"].mu).toBe(-0.5);
    expect(IRT.NORMS["13-15"].mu).toBe(awal["13-15"].mu);
    expect(normaSementara()).toBe(true);
    Object.assign(IRT.NORMS, awal);
    void NW;
    void ITEMS;
  });
});

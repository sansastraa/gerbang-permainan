// Kontrak klien <-> server. Klien hanya menerima ItemKlien (tanpa jawaban/penjelasan/seed/b).
import { z } from "zod";
import type { PetaOpsi } from "./peta";
import type { Ranah } from "./types";

export const MODE = ["rush", "profil", "latihan", "ekstrim", "arena"] as const;
export type Mode = (typeof MODE)[number];
export const LABEL_MODE: Record<Mode, string> = {
  rush: "Rush Kognitif",
  profil: "Tes Profil",
  latihan: "Latihan Bebas",
  ekstrim: "Tantangan EKSTRIM",
  arena: "Arena Kelas",
};

export const EV = {
  state: "tr:state",
  memo: "tr:memo",
  item: "tr:item",
  result: "tr:result",
  progress: "tr:progress",
  end: "tr:end",
  race: "tr:race",
  host: "tr:host",
} as const;

export const settingsSchema = z.object({
  nama: z.string().trim().min(1).max(60).default("Sesi Transit Rush"),
  mode: z.enum(MODE).default("rush"),
  usiaBawaan: z.number().int().min(6).max(80).default(10),
  ranah: z
    .array(z.enum(["memori", "spasial", "numerik", "logika"]))
    .min(1)
    .default(["memori", "spasial", "numerik", "logika"]),
  levelMin: z.number().int().min(1).max(10).default(1),
  levelMaks: z.number().int().min(1).max(10).default(10),
  durasiMenit: z.number().min(1).max(60).default(10),
  maksPerRanah: z.number().int().min(1).max(20).default(8),
  semTarget: z.number().min(0.2).max(1.2).default(0.6),
  rondeArena: z.number().int().min(1).max(30).default(12),
  papanSkor: z.boolean().default(true),
  /** sesi uji: tidak ikut summary.json kecuali includeTest=1 */
  uji: z.boolean().default(false),
});
export type SesiSettings = z.infer<typeof settingsSchema>;

export function validateSettings(raw: unknown): { ok: true; value: SesiSettings } | { ok: false; errors: string[] } {
  const r = settingsSchema.safeParse(raw ?? {});
  if (!r.success) return { ok: false, errors: r.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`) };
  const v = r.data;
  if (v.levelMin > v.levelMaks) return { ok: false, errors: ["levelMin tidak boleh lebih besar dari levelMaks."] };
  if (v.mode === "ekstrim" && v.levelMin < 8) v.levelMin = 8;
  return { ok: true, value: v };
}

export const joinSchema = z.object({
  nama: z.string().trim().min(1).max(40),
  usia: z.number().int().min(6).max(80).optional(),
  siswaId: z.string().max(80).optional(),
  absen: z.number().int().min(0).max(999).optional(),
});
export type JoinReq = z.infer<typeof joinSchema>;

export const rosterSchema = z
  .array(
    z.object({ id: z.string().max(80), name: z.string().trim().min(1).max(60), absen: z.number().int().optional() }),
  )
  .max(200);

export const answerSchema = z.object({ no: z.number().int(), resp: z.unknown() });

export type Tipe = "pilihan" | "urutan" | "teks" | "angka" | "jam" | "ketuk";

/** Soal sebagaimana dikirim ke klien. */
export interface ItemKlien {
  no: number;
  ranah: Ranah;
  family: string;
  nama: string;
  level: number;
  levelNama: string;
  batasDetik: number;
  tipe: Tipe;
  tanya: string;
  pilihan: string[] | null;
  peta: PetaOpsi | null;
  /** sisa waktu (ms) saat soal ini dikirim; server memegang waktu sebenarnya */
  sisaMs: number;
}
/** Fase hafal: dikirim sendiri sebelum soal; tidak pernah ikut di ItemKlien. */
export interface MemoKlien {
  no: number;
  family: string;
  nama: string;
  detik: number;
  hafal: Record<string, unknown>;
  peta: PetaOpsi | null;
}
export interface HasilKlien {
  no: number;
  benar: boolean;
  sebagian: number;
  poin: number;
  streak: number;
  total: number;
  penjelasan: string;
  jawabanBenar: unknown;
  waktuHabis: boolean;
}
export interface SkorPublik {
  id: string;
  nama: string;
  poin: number;
  benar: number;
  soal: number;
  streak: number;
  selesai: boolean;
  online: boolean;
}
export interface StateSesi {
  id: string;
  pin: string;
  nama: string;
  mode: Mode;
  status: "lobby" | "berjalan" | "selesai";
  ronde: number;
  rondeTotal: number;
  pemain: number;
  /** nama pemain yang sudah masuk (hanya saat lobi, untuk layar proyektor) */
  peserta: string[];
  /** soal ronde arena yang sedang berjalan (jenis dan level, tanpa isi soal) */
  rondeInfo: { nama: string; ranah: Ranah; levelNama: string; level: number } | null;
  /** arena: berapa pemain yang sudah menjawab ronde ini */
  rondeTerjawab: number;
  soalTotal: number;
  benarTotal: number;
  /** peringkat lengkap (maks 40); klien memotong sesuai kebutuhan */
  papan: SkorPublik[];
}

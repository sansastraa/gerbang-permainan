﻿// Statistik perilaku bermain per murid: kecepatan, pemakaian waktu, ketergesaan, tren, jenis soal kuat/lemah.
// Deskriptif dan positif; bukan penilaian watak atau diagnosis.
import type { Ranah } from "./types";

export interface JawabLog {
  no: number;
  family: string;
  nama: string;
  level: number;
  ranah: Ranah;
  benar: boolean;
  sebagian: number;
  detik: number;
  batas: number;
  habis: boolean;
}
export interface JenisStat {
  nama: string;
  tepat: number;
  n: number;
}
export interface Perilaku {
  soal: number;
  benar: number;
  akurasi: number;
  medianDetik: number;
  rataDetik: number;
  tercepat: number;
  terlama: number;
  /** rata-rata persen batas waktu yang dipakai per soal */
  pakaiWaktuPersen: number;
  habis: number;
  /** jawaban salah yang diberikan dalam kurang dari 20% waktu */
  gegabah: number;
  /** jawaban benar setelah memakai minimal 50% waktu */
  cermat: number;
  maksStreak: number;
  akurasiAwal: number | null;
  akurasiAkhir: number | null;
  tren: "naik" | "turun" | "stabil" | null;
  levelAwal: number | null;
  levelAkhir: number | null;
  fokusHilang: number;
  bendera: number;
  jenisKuat: JenisStat[];
  jenisLemah: JenisStat | null;
  gaya: string;
  catatan: string[];
}

const median = (a: number[]): number => {
  if (!a.length) return 0;
  const s = [...a].sort((x, y) => x - y);
  return s.length % 2 ? s[(s.length - 1) / 2]! : (s[s.length / 2 - 1]! + s[s.length / 2]!) / 2;
};
const rata = (a: number[]): number => (a.length ? a.reduce((x, y) => x + y, 0) / a.length : 0);
const r1 = (n: number): number => Math.round(n * 10) / 10;
const akur = (l: JawabLog[]): number | null => (l.length ? l.filter((x) => x.benar).length / l.length : null);

export function hitungPerilaku(
  log: readonly JawabLog[],
  flags: readonly { jenis: string }[],
  maksStreak: number,
): Perilaku | null {
  const n = log.length;
  if (n === 0) return null;
  const benar = log.filter((x) => x.benar).length;
  const pakai = log.map((x) => Math.min(1, x.detik / Math.max(1, x.batas)));
  const pakaiWaktuPersen = Math.round(100 * rata(pakai));
  const habis = log.filter((x) => x.habis).length;
  const gegabah = log.filter((x) => !x.benar && !x.habis && x.detik / Math.max(1, x.batas) < 0.2).length;
  const cermat = log.filter((x) => x.benar && x.detik / Math.max(1, x.batas) >= 0.5).length;
  const detik = log.map((x) => x.detik);
  const separuh = Math.ceil(n / 2);
  const awal = n >= 6 ? akur(log.slice(0, separuh)) : null;
  const akhir = n >= 6 ? akur(log.slice(separuh)) : null;
  const tren =
    awal === null || akhir === null ? null : akhir - awal >= 0.15 ? "naik" : akhir - awal <= -0.15 ? "turun" : "stabil";
  const lvl = (l: JawabLog[]): number | null => (l.length ? Math.round(rata(l.map((x) => x.level))) : null);
  const per = new Map<string, JenisStat & { b: number }>();
  for (const x of log) {
    const e = per.get(x.family) ?? { nama: x.nama, tepat: 0, n: 0, b: 0 };
    e.n++;
    if (x.benar) e.b++;
    per.set(x.family, e);
  }
  const jenis: JenisStat[] = [...per.values()]
    .filter((e) => e.n >= 2)
    .map((e) => ({ nama: e.nama, n: e.n, tepat: Math.round((100 * e.b) / e.n) / 100 }));
  const jenisKuat = [...jenis]
    .filter((e) => e.tepat >= 0.5)
    .sort((a, b) => b.tepat - a.tepat || b.n - a.n)
    .slice(0, 2);
  const lemahCal = [...jenis].filter((e) => e.tepat <= 0.5).sort((a, b) => a.tepat - b.tepat || b.n - a.n)[0] ?? null;
  const akurasi = benar / n;
  const gaya =
    gegabah >= 3 && akurasi < 0.6
      ? "Cepat, tapi sering terburu-buru"
      : habis >= 3
        ? "Sering kehabisan waktu"
        : pakaiWaktuPersen >= 60 && akurasi >= 0.7
          ? "Teliti dan hati-hati"
          : pakaiWaktuPersen < 40 && akurasi >= 0.75
            ? "Cepat dan tepat"
            : "Seimbang";
  const catatan: string[] = [
    `Rata-rata memakai ${pakaiWaktuPersen}% waktu per soal (median ${r1(median(detik))} detik).`,
  ];
  if (habis > 0) catatan.push(`${habis} soal kehabisan waktu: bila sudah yakin, jawab lebih cepat.`);
  if (gegabah >= 2)
    catatan.push(
      `${gegabah} jawaban salah diberikan sangat cepat (kurang dari 20% waktu): baca soal sekali lagi sebelum menjawab.`,
    );
  if (tren === "naik") catatan.push("Makin lama makin tepat: pemanasan singkat sudah cukup membantu.");
  if (tren === "turun")
    catatan.push("Ketepatan menurun di paruh akhir: mungkin mulai lelah, istirahat sebentar bisa membantu.");
  if (jenisKuat.length) catatan.push(`Paling tepat di: ${jenisKuat.map((e) => e.nama).join(", ")}.`);
  if (lemahCal)
    catatan.push(`Perlu latihan di: ${lemahCal.nama} (${Math.round(lemahCal.tepat * 100)}% dari ${lemahCal.n} soal).`);
  return {
    soal: n,
    benar,
    akurasi: Math.round(akurasi * 1000) / 1000,
    medianDetik: r1(median(detik)),
    rataDetik: r1(rata(detik)),
    tercepat: r1(Math.min(...detik)),
    terlama: r1(Math.max(...detik)),
    pakaiWaktuPersen,
    habis,
    gegabah,
    cermat,
    maksStreak,
    akurasiAwal: awal === null ? null : Math.round(awal * 100) / 100,
    akurasiAkhir: akhir === null ? null : Math.round(akhir * 100) / 100,
    tren,
    levelAwal: lvl(log.slice(0, 3)),
    levelAkhir: lvl(log.slice(-3)),
    fokusHilang: flags.filter((f) => f.jenis === "fokus-hilang").length,
    bendera: flags.length,
    jenisKuat,
    jenisLemah: lemahCal,
    gaya,
    catatan,
  };
}

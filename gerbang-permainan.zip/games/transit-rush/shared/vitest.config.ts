import { defineConfig } from "vitest/config";
export default defineConfig({
  test: { pool: "forks", fileParallelism: false, environment: "node", include: ["src/**/*.test.ts"] },
});

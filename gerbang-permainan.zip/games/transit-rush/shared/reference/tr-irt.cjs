// ============================================================
// TRANSIT RUSH — tr-irt: psikometri (model Rasch, EAP, tes adaptif, norma, kalibrasi)
// Semua fungsi murni.
// ============================================================
const I = require('./tr-items.cjs');
const Q = []; for (let t = -6; t <= 6.0001; t += 0.1) Q.push(+t.toFixed(1));
const P = (theta, b) => 1 / (1 + Math.exp(-(theta - b)));
const normPdf = (x, m, s) => Math.exp(-0.5 * ((x - m) / s) ** 2);
function erf(x) { const s = Math.sign(x); x = Math.abs(x); const t = 1 / (1 + 0.3275911 * x); const y = 1 - (((((1.061405429 * t - 1.453152027) * t) + 1.421413741) * t - 0.284496736) * t + 0.254829592) * t * Math.exp(-x * x); return s * y; }
const Phi = z => 0.5 * (1 + erf(z / Math.SQRT2));

// ---------- estimasi kemampuan (EAP) ----------
// resp: [{ b, x (0/1) }], prior: { mu, sd }
function eap(resp, prior = { mu: 0, sd: 1 }) {
  let w = Q.map(t => normPdf(t, prior.mu, prior.sd));
  for (const r of resp) w = w.map((v, i) => v * (r.x ? P(Q[i], r.b) : 1 - P(Q[i], r.b)));
  const s = w.reduce((a, v) => a + v, 0) || 1e-300, m = Q.reduce((a, t, i) => a + t * w[i], 0) / s;
  const v = Q.reduce((a, t, i) => a + (t - m) ** 2 * w[i], 0) / s;
  return { theta: m, sem: Math.sqrt(v) };
}
const info = (theta, b) => { const p = P(theta, b); return p * (1 - p); };

// ---------- norma (SEMENTARA — wajib diganti dari data nyata, lihat tools/tr-calibrate.js) ----------
const NORMS = {
  '7-8':   { label: 'Usia 7–8 (SD kelas 1–2)', mu: -1.6, sd: 1.1 },
  '9-10':  { label: 'Usia 9–10 (SD kelas 3–4)', mu: -0.8, sd: 1.1 },
  '11-12': { label: 'Usia 11–12 (SD kelas 5–6)', mu: -0.1, sd: 1.1 },
  '13-15': { label: 'Usia 13–15 (SMP)', mu: 0.5, sd: 1.15 },
  '16+':   { label: 'Usia 16+ (umum)', mu: 1.0, sd: 1.25 },
};
const ageBand = age => age <= 8 ? '7-8' : age <= 10 ? '9-10' : age <= 12 ? '11-12' : age <= 15 ? '13-15' : '16+';

// ---------- sesi tes adaptif ----------
// opsi: { mode: 'rush'|'profil'|'latihan', usia, semTarget, maxPerDomain, minPerDomain, mulaiLevel }
function newSession(opts = {}) {
  const band = ageBand(opts.usia ?? 10), n = NORMS[band];
  const prior = opts.mode === 'rush' ? { mu: Math.min(n.mu, -2.2), sd: 1.4 } : { mu: n.mu, sd: 1.2 };   // rush selalu mulai super gampang
  const dom = Object.fromEntries(I.DOMAINS.map(d => [d, { resp: [], theta: prior.mu, sem: prior.sd, famUse: {} }]));
  return { opts: { semTarget: 0.55, maxPerDomain: 15, minPerDomain: 3, ...opts }, band, prior, dom, history: [], done: false };
}
const levelForTheta = (fam, theta) => { let best = 1, bd = Infinity; for (let L = 1; L <= 10; L++) { const d = Math.abs(I.bOf(fam, L) - theta); if (d < bd) { bd = d; best = L; } } return best; };
// Pilih soal berikutnya: ranah dengan ketidakpastian terbesar → jenis yang paling jarang dipakai → level paling informatif (acak di antara 2 terbaik)
function nextSpec(S, rng) {
  const o = S.opts, ds = I.DOMAINS.filter(d => S.dom[d].resp.length < o.maxPerDomain && (S.dom[d].resp.length < o.minPerDomain || S.dom[d].sem > o.semTarget));
  if (!ds.length) { S.done = true; return null; }
  const d = ds.slice().sort((a, b) => (S.dom[a].resp.length - S.dom[b].resp.length) || (S.dom[b].sem - S.dom[a].sem))[0], D = S.dom[d];
  const fams = I.familiesOf(d).filter(f => !(o.keluarga && !o.keluarga.includes(f))).sort((a, b) => (D.famUse[a] || 0) - (D.famUse[b] || 0) || (rng() - 0.5));
  const fam = fams[0];
  let L = levelForTheta(fam, D.theta);
  if (o.mode === 'latihan' && o.level) L = o.level;
  if (o.mode !== 'latihan' && rng() < 0.35) L = Math.max(1, Math.min(10, L + (rng() < 0.5 ? -1 : 1)));   // randomesque: variasi & kontrol paparan
  if (o.levelMin) L = Math.max(L, o.levelMin); if (o.levelMax) L = Math.min(L, o.levelMax);
  return { family: fam, level: L, ranah: d };
}
// Catat jawaban: item = soal yang dibangkitkan (punya b), hasil = { benar, detik }
function record(S, item, hasil) {
  const D = S.dom[item.ranah];
  D.resp.push({ b: item.b, x: hasil.benar ? 1 : 0, family: item.family, level: item.level, detik: hasil.detik, sebagian: hasil.sebagian });
  D.famUse[item.family] = (D.famUse[item.family] || 0) + 1;
  Object.assign(D, eap(D.resp, S.prior));
  S.history.push({ ranah: item.ranah, family: item.family, level: item.level, b: item.b, benar: !!hasil.benar, detik: hasil.detik, theta: D.theta, sem: D.sem });
}

// ---------- laporan ala psikometri ----------
const DOMAIN_LABEL = { memori: 'Memori', spasial: 'Spasial', numerik: 'Numerik', logika: 'Logika' };
const ARCHETYPE = { memori: 'Si Perekam Rute 🧠', spasial: 'Si Kompas Hidup 🧭', numerik: 'Si Kalkulator Halte 🔢', logika: 'Si Detektif Rute 🔍', seimbang: 'Penjelajah Serba Bisa 🌟' };
function scaled(theta, sem, band) {
  const n = NORMS[band], z = (theta - n.mu) / n.sd, zl = (theta - 1.645 * sem - n.mu) / n.sd, zh = (theta + 1.645 * sem - n.mu) / n.sd;
  return { skorStandar: Math.round(100 + 15 * z), persentil: Math.round(100 * Phi(z)), rentangPersentil90: [Math.round(100 * Phi(zl)), Math.round(100 * Phi(zh))], stanine: Math.max(1, Math.min(9, Math.round(2 * z + 5))) };
}
const levelPenjelajah = theta => Math.max(1, Math.min(10, Math.round(theta / 0.7 + 5.5)));
function report(S) {
  const band = S.band, doms = {};
  for (const d of I.DOMAINS) {
    const D = S.dom[d], rt = D.resp.map(r => r.detik).filter(x => x != null).sort((a, b) => a - b);
    doms[d] = { label: DOMAIN_LABEL[d], theta: +D.theta.toFixed(2), sem: +D.sem.toFixed(2), soal: D.resp.length, benar: D.resp.filter(r => r.x).length, level: levelPenjelajah(D.theta), ...scaled(D.theta, D.sem, band), medianDetik: rt.length ? rt[Math.floor(rt.length / 2)] : null };
  }
  const all = I.DOMAINS.flatMap(d => S.dom[d].resp), g = eap(all, S.prior);
  const sorted = I.DOMAINS.slice().sort((a, b) => doms[b].theta - doms[a].theta), top = sorted[0], low = sorted[sorted.length - 1];
  const zDiff = (doms[top].theta - doms[low].theta) / Math.sqrt(doms[top].sem ** 2 + doms[low].sem ** 2);
  const menit = all.reduce((a, r) => a + (r.detik || 0), 0) / 60;
  return {
    kelompokUsia: NORMS[band].label, normaSementara: true,
    IKP: { nama: 'Indeks Kognitif Peta', theta: +g.theta.toFixed(2), sem: +g.sem.toFixed(2), level: levelPenjelajah(g.theta), ...scaled(g.theta, g.sem, band) },
    ranah: doms,
    kekuatan: zDiff > 1.96 ? { ranah: top, teks: `${DOMAIN_LABEL[top]} lebih kuat secara nyata dibanding ${DOMAIN_LABEL[low]}` } : { ranah: null, teks: 'Kemampuan antar-ranah seimbang (perbedaannya masih dalam batas ketidakpastian)' },
    tipe: zDiff > 1.96 ? ARCHETYPE[top] : ARCHETYPE.seimbang,
    rush: { soal: all.length, benar: all.filter(r => r.x).length, benarPerMenit: menit ? +(all.filter(r => r.x).length / menit).toFixed(2) : null },
    reliabilitasPerkiraan: +(1 - g.sem ** 2 / (S.prior.sd ** 2)).toFixed(2),
  };
}

// ---------- kalibrasi soal dari data (JML Rasch) ----------
// data: [{ person, item, x }] → { b: {item: nilai}, theta: {person: nilai} }
function calibrate(data, iters = 60) {
  const persons = [...new Set(data.map(d => d.person))], items = [...new Set(data.map(d => d.item))];
  const th = Object.fromEntries(persons.map(p => [p, 0])), b = Object.fromEntries(items.map(i => [i, 0]));
  const byP = new Map(), byI = new Map(); for (const d of data) { (byP.get(d.person) || byP.set(d.person, []).get(d.person)).push(d); (byI.get(d.item) || byI.set(d.item, []).get(d.item)).push(d); }
  for (let it = 0; it < iters; it++) {
    for (const [i, ds] of byI) { let g = 0, h = 0; for (const d of ds) { const p = P(th[d.person], b[i]); g += p - d.x; h += p * (1 - p); } b[i] = Math.max(-6, Math.min(6, b[i] + g / Math.max(h, 1e-6))); }
    const mb = items.reduce((a, i) => a + b[i], 0) / items.length; for (const i of items) b[i] -= mb;     // pusatkan
    for (const [p0, ds] of byP) { let g = 0, h = 0; for (const d of ds) { const p = P(th[p0], b[d.item]); g += d.x - p; h += p * (1 - p); } th[p0] = Math.max(-6, Math.min(6, th[p0] + g / Math.max(h, 1e-6))); }
  }
  return { b, theta: th };
}

module.exports = { P, eap, info, NORMS, ageBand, newSession, nextSpec, record, report, scaled, levelPenjelajah, calibrate, Phi, ARCHETYPE };

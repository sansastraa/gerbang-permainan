# PROGRESS Tower Peek

Lokasi: `D:\gerbang-permainan\games\tower-peek` (game mandiri di Gerbang Permainan). Sumber spesifikasi: `docs/SPEC.md`.

## Penyimpangan dari SPEC (disengaja, alasan)
- **npm workspaces**, bukan pnpm: Gerbang memasang semua game dengan `npm ci` dan menjalankan `npm run start -w server`.
- **Express + Socket.IO**, bukan Fastify: sama dengan game Gerbang lain (gateway/BASE_PATH/proxy sudah terbukti); API REST/event identik dengan SPEC §4.6–4.7.
- **Penyimpanan = audit log JSONL berantai hash** (event sourcing), bukan SQLite: state dibangun ulang dengan memutar log (SPEC §4.8 "server restart"). Tanpa modul native (better-sqlite3 bermasalah di Windows/jalur panjang). Tabel SPEC §4.5 dipetakan ke state di memori + log.
- Soal paket yang simetris (Champion R1 hanya punya 2 jawaban berbeda dari 8 transformasi) tidak bisa membedakan meja bersebelahan; server menggantikannya dengan soal bangkitan-seed berukuran & jumlah dipaku sama (`ronde.pengganti` tampil di snapshot operator).
- `puzzle:deliver` dikirim saat LIVE (bukan saat hitung mundur) supaya petunjuk tidak bocor 5 detik lebih awal.
- Seed Simetri memakai pewarnaan pola (x mod 2, y mod 2) pada tata meja grid 2 baris: tak ada meja bersebelahan (termasuk diagonal) dengan varian sama.

## M0 — Monorepo + port engine — SELESAI
`shared/src/engine.ts` (port TS), tes `engine.test.ts`: keluaran identik dengan `shared/reference/puzzle.cjs` untuk seed sama, jawaban tunggal semua ukuran & varian, semua 10 soal paket (jawaban tunggal, petunjuk cocok). Tes asli `node engine/puzzle.test.js` dijalankan: lulus.

## M1 — Event/peserta/pemasangan meja — SELESAI (server)
`server/src/service.ts` (Session Manager), REST `/api/sessions`, `/participants`, `/desks/assign`, `/desks/pair` (token + jalur QR `/meja/N?t=…`, hanya hash yang disimpan), `desk:hello` (satu token = satu perangkat; `desk:swap` memutar token). UI QR/operator di M6.

## M2 — Round Controller + Clock — SELESAI (server)
State machine DRAFT→LOADED→BRIEFING→COUNTDOWN→LIVE⇄PAUSED→CLOSED; jeda global menggeser tenggat; perpanjang; jeda per meja dengan kompensasi; tenggat per meja; tutup otomatis; `clock:ping/pong` + `estimasiOffset` (RTT terkecil). Tes dengan jam terkendali (`harness.ts`) + integrasi Socket.IO. Pemulihan restart dari audit log; berkas yang diubah ditolak.
Belum: uji "3 perangkat nyata" (hanya soket tiruan di satu proses).

## Berikutnya
M3 Meja Jawab (klien Vite/React/three bundel lokal), lalu M4–M10. Entri katalog Gerbang (`hub/lib/katalog.mjs`, `proses.mjs`), `summary.json`, dan serah-terima `towerpeek:host-ready/roster` ditambahkan ketika konsol operator (M6) ada.

## Tambahan permintaan: dua format (seperti Logic Rush)
- **KOMPETISI** (SPEC asli): ≤16 meja, token QR per meja, bel, reveal oleh operator.
- **ARENA / game biasa**: 1–40 pemain, perangkat sendiri, masuk dengan **PIN sesi 6 digit** (`POST /api/join`, `GET /api/join/info`, batas 10 PIN salah/menit/IP). Satu nama satu perangkat (perangkat sama boleh masuk ulang, token diganti); sesi dengan daftar peserta (dari Gerbang) mengunci pilihan nama; pemain telat tetap dapat papan. Papan **unik per pemain** (seed per pemain, ukuran & jumlah dipaku sama) menggantikan Seed Simetri. Batas di `config.arena`.
- Server selesai + 4 tes baru (40 pemain, ke-41 ditolak, papan unik & tunggal, deliver tanpa solusi, restart, HTTP). Antarmuka main/gabung, papan peringkat langsung (hanya % terisi, tanpa tinggi), skor massal 10/8/6/5/4/3/2/1 ikut M3–M7.

## M3–M10 (ringkas, sesi 2)
- **M3–M4 Meja Jawab**: `client/src/play` (kuas tinggi, ketuk bertumpuk, keyboard, tampak atas 2D, papan 3D three.js dibundel, Mata Pengintip 4 sisi, bel tahan 1 dtk + tombol fisik F24, bantuan, tombol Periksa di ARENA). Server: `setPapan/mintaBantuan/tekanBel/periksa/bukaPeek` (`service.ts`).
- **M5 Judge**: `judge.ts` murni, contoh SPEC diuji (SD 155/★★★, sebagian 50×tepat÷terbuka, Champion 10/8/6.., seri → validasi lalu waktu bel).
- **M6 Arena Operator** `/host` (serah-terima Gerbang `towerpeek:host-ready/roster`, PIN manual cadangan, QR meja, PIN Arena, kontrol ronde, kartu meja, bendera, adegan, koreksi beralasan + Ctrl+Z, statistik, ekspor, replay).
- **M7 Layar Siswa** `director.ts`: adegan lobi/aturan/mundur/live/reveal/skor/podium, sensor dijaga tes (payload identik untuk papan beda-tinggi). **Permintaan pengguna**: papan peringkat langsung (skor sementara, % terisi, jumlah validasi, bel) + **Sorotan 3D bergilir** satu pemain tiap 10 dtk (bawaan aktif di ARENA karena papan unik per pemain; di Kompetisi mati dan butuh konfirmasi guru). Ini pelonggaran sadar atas aturan "tanpa tinggi menara selama LIVE", terbatas pada satu papan.
- **M8 Anti-curang**: Jebakan Seed, fokus hilang (1× kuning, 2× merah), papan instan, laju aksi, perangkat ganda; audit log berantai hash, replay.
- **M9 Statistik**: efisiensi, tepat percobaan pertama, ketergantungan pengintip, strategi patokan, kembar dibuat, waktu bel, heatmap dalam kerangka soal dasar; CSV/JSON; `summary.json` untuk Gerbang.
- **M10**: `npm run sim -- --bots 16` dan `--arena 40` lulus (putus-sambung, penyalin, tanpa kebocoran, latensi p95 < 150 ms, QR pindah perangkat < 10 dtk). E2E Playwright (`npx tsx scripts/e2e.ts`) lewat Gerbang: berjalan hingga reveal di mesin ini, tetapi lambat/flaky karena WebGL perangkat lunak + RAM terbatas.
- **Tampilan**: arah "kertas milimeter + blok bertumpuk" (garis tinta 2px, bayangan keras, palet dari warna tinggi menara, tanpa gradien/emoji). Bug nyata yang ditemukan lewat peramban: `webglTersedia()` membuat konteks WebGL tiap render sehingga batas konteks habis dan papan 3D kosong; kini di-cache dan konteks dilepas saat dispose.
- **Belum teruji**: meja fisik/sensor/bel nyata, tablet nyata, FPS ≥ 30 di perangkat sekolah, 40 klien /tonton, Product Sans (tidak dibundel, lisensi belum jelas; dipakai hanya bila terpasang).

- **Nilai sebagian lebih murah hati** (permintaan pengguna): SD = 80 x tepat/terbuka dibulatkan ke atas (satu petak benar minimal 1 poin; SPEC lama 50x). Champion: papan belum sempurna dapat 0,45 x tepat/terbuka (selalu di bawah papan benar mana pun). Angka di config/tower_peek.config.json (sebagian_maks).

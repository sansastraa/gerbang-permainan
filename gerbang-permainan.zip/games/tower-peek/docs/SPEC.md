# Tower Peek — Rancang Bangun Modul Game Clash of Git SIMPETERI

> Versi Markdown untuk Claude Code. Sumber yang sama dengan dokumen Word.


## 1. Ringkasan

Dokumen ini adalah rancang bangun **modul game Tower Peek** di platform **Clash of Git SIMPETERI**. Tower Peek adalah adaptasi game *Vertical Limit* (Clash of Champions) untuk murid SD dengan fokus kemampuan spasial: membaca sudut pandang, membayangkan tinggi-rendah benda, dan menalar posisi dalam grid.

Sistem terdiri atas satu back-end dan tiga aplikasi front-end:

| Komponen | Pengguna | Fungsi utama |
|---|---|---|
| Arena Operator | Guru/operator | Mengatur sesi dan ronde, memantau semua meja, menjalankan waktu, menilai, dan mengatur tayangan |
| Meja Jawab | Satu peserta (Champion) per meja | Papan 3D interaktif untuk menyusun menara, mata pengintip, dan bel |
| Layar Siswa | Penonton satu kelas (proyektor) dan opsional HP murid | Tayangan acara: hitung mundur, progres tersensor, bel, reveal 3D, papan skor |
| Back-end | — | Sumber kebenaran: soal & kunci, waktu, penilaian, sinkronisasi, log audit, statistik |

> **Asumsi yang dipakai**
>
> “Clash of Git SIMPETERI” diperlakukan sebagai nama platform/acara kompetisi milik sekolah. Tower Peek dirancang sebagai **modul** yang bisa dipasang di platform itu atau dijalankan mandiri.
> Acara berjalan di **jaringan lokal (LAN) tanpa internet**, dengan 8 meja jawab (maksimal 16), 1 arena operator, dan 1–2 layar proyektor.


## 2. Aturan Permainan


### 2.1 Aturan inti (bahasa untuk murid)

1. Isi setiap petak dengan satu menara setinggi **1 sampai N lantai** (N = ukuran papan).
2. Di setiap baris dan setiap kolom, **tinggi menara tidak boleh kembar**.
3. **Angka di pinggir papan** menunjukkan berapa menara yang terlihat oleh pengintip dari arah itu.
4. **Menara yang lebih tinggi menutupi** menara yang lebih pendek di belakangnya.
5. Kalau sudah selesai, **tekan bel**. Setelah bel ditekan, jawaban terkunci dan tidak bisa diubah.


### 2.2 Struktur ronde

Tersedia dua mode. **Mode Champion** mengikuti format asli acara; **Mode SD** disederhanakan untuk kelas 3–6.

| Ronde | Mode SD: papan | Mode SD: menara dipaku | Mode SD: waktu | Mode Champion: papan | Mode Champion: waktu |
|---|---|---|---|---|---|
| 1 | 3 × 3 (pemanasan) | 1 | 3 menit | 4 × 4 | 3 menit |
| 2 | 4 × 4 | 5 | 5 menit | 5 × 5 | 6 menit |
| 3 | 5 × 5 | 8 | 8 menit | 5 × 5 | 6 menit |
| 4 | 6 × 6 | 12 | 10 menit | 6 × 6 | 10 menit |
| 5 | 6 × 6 | 10 | 12 menit | 6 × 6 | 10 menit |

Kedua mode sama-sama berakhir di papan **6 × 6**. Bedanya, Mode SD naik satu ukuran setiap ronde mulai dari 3 × 3, memberi menara dipaku sebagai patokan, dan memberi waktu lebih panjang di ronde terakhir. Di Mode Champion tidak ada menara dipaku, kecuali sedikit yang dibutuhkan agar jawabannya **tepat satu** (dicek otomatis oleh solver).

Untuk kelas 3–4, operator boleh menghentikan turnamen setelah ronde 3 (papan 5 × 5) dan langsung ke papan skor.


### 2.3 Penyederhanaan untuk anak SD

| Penyederhanaan | Penjelasan |
|---|---|
| Papan bertahap | Mulai dari 3 × 3 (tinggi 1–3) supaya aturan dipahami dulu, lalu naik satu ukuran tiap ronde: 4 × 4, 5 × 5, sampai 6 × 6 |
| Patokan di 6 × 6 | Ronde 4 memberi 12 menara dipaku (sepertiga papan) dan ronde 5 memberi 10, supaya papan terbesar tetap terjangkau anak SD |
| Menara dipaku 📌 | Beberapa menara sudah terpasang sebagai patokan awal; jumlahnya berkurang tiap ronde |
| Warna per tinggi | Tinggi 1 kuning, 2 oranye, 3 merah, 4 ungu, 5 hijau, 6 merah muda; menara kembar dalam satu baris langsung terlihat |
| Tandai kembar | Menara dengan tinggi sama di satu baris/kolom menyala merah (hanya Mode SD) |
| Mata Pengintip 👀 | Ketuk angka di pinggir → kamera 3D turun ke posisi mata pengintip; menara yang terlihat menyala, yang tertutup memudar |
| Kosakata arah | Sisi papan diberi nama utara, selatan, barat, timur; ada penanda U di papan |
| Satu bantuan per ronde | Membetulkan atau memasang satu menara, dengan biaya poin |
| Nilai sebagian | Papan yang belum sempurna tetap mendapat poin sesuai jumlah menara yang tepat |


### 2.4 Strategi yang diajarkan (muncul di tutorial)

- Angka **1**: menara tertinggi pasti tepat di depan pengintip.
- Angka **N**: menaranya urut 1, 2, 3, … dari depan.
- Menara tertinggi selalu terlihat dari arah mana pun.
- Mulailah dari petak yang sudah pasti, lalu jadikan patokan untuk petak lain.


### 2.5 Skor dan peringkat


#### Mode SD

```
Poin ronde = Ketepatan + Bonus Waktu + Bonus Bel − Bantuan
Ketepatan   = 100 jika sempurna; jika belum: 50 × (menara tepat ÷ petak terbuka)
Bonus Waktu = 50 × (sisa waktu ÷ waktu total)          (hanya jika sempurna)
Bonus Bel   = +30 / +20 / +10 untuk 3 bel sempurna pertama
Bantuan     = −25 per bantuan
Bintang     = ★★★ sempurna tanpa bantuan, ★★ sempurna dengan bantuan, ★ ≥ 70% tepat
```


#### Mode Champion

```
Hanya papan yang 100% benar mendapat poin.
Urutan bel di antara papan benar: 10, 8, 6, 5, 4, 3, 2, 1
Benar tetapi tidak menekan bel sampai waktu habis: poin peringkat terendah × 0,5
Salah: 0. Seri dipecah dengan waktu bel menurut jam server (milidetik).
```


## 3. Arsitektur Sistem


### 3.1 Gambaran besar

```
                 +--------------------------------+
                 |   SERVER (laptop operator)     |
                 |   Node 20, Fastify, Socket.IO  |
                 |   Engine Tower Peek, SQLite    |
                 +---------------+----------------+
                                 |  Wi-Fi/LAN tertutup
         +-----------------------+-----------------------+
         |                       |                       |
+--------+---------+   +---------+--------+   +----------+---------+
| ARENA OPERATOR   |   | MEJA JAWAB 1..16 |   | LAYAR SISWA        |
| /operator        |   | /meja/:nomor     |   | /layar (proyektor) |
| laptop guru      |   | tablet peserta   |   | /tonton (HP, ops.) |
+------------------+   +------------------+   +--------------------+
```


### 3.2 Prinsip desain

- **Server berwenang penuh.** Kunci jawaban, waktu, penilaian, dan urutan bel hanya ditentukan server.
- **Satu engine bersama.** Logika teka-teki (`engine/puzzle.js`) dipakai server untuk membuat dan menilai soal, serta oleh meja untuk menghitung jumlah menara yang terlihat di mode pengintip (tanpa kunci).
- **Offline-first.** Semua aset (font, three.js, suara) dibundel; tidak ada panggilan internet saat acara.
- **Bisa pulih.** Setiap aksi tersimpan sebagai event; meja yang mati bisa diganti perangkat lain dan papannya kembali persis.
- **Aman untuk ditonton.** Layar Siswa tidak pernah menampilkan tinggi menara peserta selama ronde berjalan.


### 3.3 Teknologi

| Lapisan | Pilihan | Alasan |
|---|---|---|
| Monorepo | pnpm workspaces, TypeScript strict | Tipe event dibagi antar-aplikasi |
| Back-end | Node 20, Fastify, Socket.IO, better-sqlite3, zod, pino | Realtime ringan, satu file database, mudah dipindah |
| Engine | `packages/engine` (port TS dari puzzle.js) | Sudah diuji: soal selalu berjawaban tunggal |
| Front-end | Vite + React + TypeScript, Zustand | Tiga aplikasi dalam satu build dengan routing berbeda |
| 3D | three.js via React Three Fiber + drei, instancing | Ringan di tablet; ≤ 36 menara |
| Audio | Web Audio API (efek), file bel lokal | Tanpa internet |
| Uji | Vitest, Playwright, skrip simulasi 16 meja bot | Menjamin kestabilan saat acara |


### 3.4 Struktur repo

```
clash-of-git-simpeteri/
  apps/server/          # Fastify + Socket.IO + SQLite
    src/modules/towerpeek/{round.ts, judge.ts, broadcast.ts, anticheat.ts, stats.ts}
  apps/web/             # satu build React, tiga rute
    src/operator/  src/meja/  src/layar/  src/tonton/
    src/three/{Board.tsx, Tower.tsx, PeekCamera.tsx, CluePlate.tsx}
  packages/engine/      # generator, solver, varian simetri, hitung pengintip
  packages/protocol/    # skema zod semua event & payload
  data/paket_soal.json  # soal resmi (rahasia server)
  config/tower_peek.config.json
```


## 4. Back-end


### 4.1 Modul server

| Modul | Tanggung jawab |
|---|---|
| Session Manager | Membuat acara, mendaftarkan peserta, memasangkan peserta ↔ meja, token meja |
| Puzzle Service | Memuat soal dari paket atau seed, membangkitkan varian simetri per meja, memverifikasi jawaban tunggal |
| Round Controller | State machine ronde, jadwal hitung mundur, tenggat, jeda, perpanjangan waktu |
| Clock Service | Sinkronisasi jam meja ↔ server (ping NTP-ringan), sumber waktu resmi |
| Desk Gateway | Menerima aksi papan dan bel, validasi format, rate limit, menyimpan papan terbaru per meja |
| Judge | Menilai papan saat terkunci, menghitung poin dan peringkat sesuai mode |
| Broadcast Director | Menyusun “adegan” Layar Siswa dan menyensor data sesuai fase |
| Anti-Cheat | Deteksi fokus hilang, perangkat ganda, anomali; bendera untuk operator |
| Audit Log | Event log append-only berantai hash; replay ronde |
| Stats | Indikator spasial per peserta dan analisis per soal |


### 4.2 State machine ronde

```
DRAFT ─muat soal─▶ LOADED ─tayang aturan─▶ BRIEFING ─mulai─▶ COUNTDOWN(5 dtk)
COUNTDOWN ─▶ LIVE ⇄ PAUSED
LIVE ─semua meja bel / waktu habis / operator tutup─▶ CLOSED
CLOSED ─▶ JUDGED (otomatis) ─▶ REVEAL (operator memandu) ─▶ SCORED ─▶ ARCHIVED
```

Status per meja: OFFLINE → READY → COUNTDOWN → PLAYING → (BELL | TIMEOUT_LOCKED) → REVEALED. Operator juga dapat memberi status PAUSED_DESK untuk gangguan teknis di satu meja, dengan **kompensasi waktu** otomatis.


### 4.3 Puzzle engine & Seed Simetri

Generator membuat persegi Latin acak dari seed, menghitung angka pengintip di keempat sisi, lalu menambah menara dipaku seperlunya sampai solver menemukan **tepat satu** jawaban. Seed yang sama selalu menghasilkan soal yang sama (dapat diulang untuk sengketa).

**Seed Simetri**: dari satu soal, server membuat hingga 8 varian dengan memutar (0°, 90°, 180°, 270°) dan mencerminkan papan. Tingkat kesulitannya identik, tetapi jawabannya berbeda. Meja yang bersebelahan wajib mendapat varian berbeda, sehingga melirik meja tetangga tidak berguna. Catatan: papan 3 × 3 hanya memiliki 4 varian yang berbeda.

| Fungsi engine | Kegunaan |
|---|---|
| makePuzzle(n, dipaku, kode) | Membuat soal deterministik berjawaban tunggal |
| solve(n, petunjuk, dipaku, batas) | Mencari hingga `batas` solusi; dipakai untuk uji ketunggalan |
| variant(soal, k) | Varian simetri k = 0..7 |
| countVisible(nilai[]) | Jumlah menara terlihat dalam satu garis (dipakai meja untuk mode pengintip) |
| lineCells(n, sisi, i) | Urutan petak dari sudut pandang pengintip |

Hasil uji: semua ukuran 3 × 3 sampai 6 × 6 selalu berjawaban tunggal; pembuatan soal 6 × 6 tanpa menara dipaku butuh kurang dari 30 ms.


### 4.4 Sinkronisasi waktu & bel

- Saat terhubung dan setiap 30 detik, meja melakukan 7 kali ping; offset jam diambil dari sampel dengan RTT terkecil.
- Server menyiarkan `startAt` dan `deadline` dalam waktu server; timer di layar hanya tampilan.
- Waktu bel resmi = waktu server saat event diterima. Waktu lokal meja dan RTT ikut disimpan untuk audit sengketa.
- Jawaban yang tiba setelah `deadline` ditolak. Saat tenggat, server mengunci semua meja dan memakai papan terakhir yang tersimpan.


### 4.5 Model data (SQLite)

| Tabel | Kolom utama |
|---|---|
| events | id, nama, mode (SD/CHAMPION), status, dibuat |
| participants | id, event_id, nama, kelas, avatar, nama_panggilan |
| desks | id, event_id, nomor, token_hash, device_id, participant_id, status, kursi_x, kursi_y |
| rounds | id, event_id, urutan, n, waktu_detik, kode_soal, status, start_at, deadline, ditutup |
| desk_puzzles | round_id, desk_id, varian_k, petunjuk_json, dipaku_json, solusi_json (hanya server) |
| board_state | round_id, desk_id, grid_json, versi, diperbarui |
| moves | id, round_id, desk_id, seq, sel, tinggi_lama, tinggi_baru, t_server, t_klien, sumber (tap/kuas/keyboard/bantuan) |
| peeks | id, round_id, desk_id, sisi, indeks, masuk, keluar |
| bells | round_id, desk_id, t_server, t_klien, rtt, urutan, sumber (layar/tombol fisik) |
| results | round_id, desk_id, tepat, terbuka, sempurna, poin, bintang, peringkat, rincian_json |
| flags | id, round_id, desk_id, tipe, tingkat, detail_json, status |
| audit_log | seq, ts, aktor, tipe, payload_json, prev_hash, hash |


### 4.6 REST API (operator, terautentikasi)

| Endpoint | Fungsi |
|---|---|
| POST /api/events | Membuat acara (nama, mode, jumlah meja) |
| POST /api/events/:id/participants | Impor peserta (CSV/JSON) |
| POST /api/events/:id/desks/pair | Membuat token & QR pemasangan meja |
| POST /api/rounds/:id/load | Memuat soal dari paket atau seed; membuat varian per meja |
| GET  /api/rounds/:id/replay | Mengunduh event ronde untuk diputar ulang |
| GET  /api/events/:id/export | Ekspor hasil & statistik (CSV/JSON) |


### 4.7 Event realtime (Socket.IO)

Tiga namespace dengan hak akses berbeda. Semua payload divalidasi zod di `packages/protocol`.

| Namespace | Klien → server | Server → klien |
|---|---|---|
| /operator | round:load, round:brief, round:start, round:pause, round:resume, round:extend, round:close, desk:pause, desk:lock, desk:swap, judge:reveal(desk), score:adjust(alasan), scene:set, flag:resolve | arena:snapshot, desk:status, desk:progress, desk:bell, flag:new, judge:result, clock:tick |
| /meja | desk:hello(token, deviceId), clock:ping, board:set(sel, tinggi, versi), peek:open/close, hint:request, bell:ring, focus:lost | desk:assign, round:brief, round:countdown, puzzle:deliver(petunjuk, dipaku), clock:pong, board:ack, round:paused, round:locked, result:show |
| /layar | scene:ready, reveal:done | scene:show(adegan, data tersensor), bell:fx, timer:sync, reveal:play(papan, urutan cek), leaderboard:update |

> **Aturan keamanan payload**
>
> `puzzle:deliver` hanya berisi petunjuk dan menara dipaku; **solusi tidak pernah dikirim** ke meja atau layar sebelum JUDGED.
> Namespace /layar hanya menerima data yang sudah disensor Broadcast Director sesuai fase.


### 4.8 Ketahanan

- **Reconnect**: meja mengirim `desk:hello` dengan token; server membalas snapshot (soal, papan, sisa waktu).
- **Tukar perangkat**: operator menekan “Pindahkan meja” → perangkat cadangan memindai QR → papan pulih dari `board_state`.
- **Server restart**: state ronde dibangun ulang dari `rounds`, `board_state`, dan `audit_log`.
- **Kompensasi**: jeda per meja menambah tenggat meja itu sebesar durasi jeda, tercatat di audit.


## 5. Front-end: Arena Operator

Konsol untuk guru/operator di laptop (minimal 1366 × 768). Tujuannya: semua meja terlihat sekaligus, keputusan cepat, dan setiap tindakan tercatat.

```
+-----------------------------------------------------------------------+
| Ronde 3/5  5x5  LIVE   04:12   [Jeda] [+30 dtk] [Tutup ronde]         |
+-----------------------------------------------------------------------+
| M1 Rina [ok] |M2 Budi [ok] |M3 Sari BEL#1|M4 Dimas [!] |BENDERA       |
| ######.. 18  |###..... 9   |kunci 02:41  |fokus hilang |M4 fokus 2x   |
| kembar: 1    |kembar: 0    |varian k=3   |####.... 15  |...           |
| [lihat papan]|             |             |[tinjau]     |              |
+-----------------------------------------------------------------------+
| ADEGAN LAYAR: [Lobi][Aturan][Mundur][LIVE][Reveal >][Skor][Podium]    |
+-----------------------------------------------------------------------+
```


### 5.1 Fitur

| Area | Isi |
|---|---|
| Persiapan | Buat acara, impor peserta, pasang meja via QR, uji bel tiap meja, pilih mode dan paket soal |
| Kartu meja | Nama, status, progres petak terisi, jumlah kembar, urutan bel, waktu bel, sinyal koneksi, varian simetri |
| Lihat papan | Operator dapat membuka papan 3D meja mana pun (hanya di laptop operator) untuk membantu kendala teknis |
| Kontrol waktu | Mulai, jeda global, jeda per meja (dengan kompensasi), perpanjang waktu, tutup ronde |
| Penjurian | Hasil otomatis; tombol koreksi poin wajib diisi alasan; semua koreksi masuk audit |
| Sutradara layar | Memilih adegan Layar Siswa dan urutan reveal meja |
| Bendera | Antrean bendera anti-curang dengan tombol Abaikan / Peringatkan / Kunci meja |
| Ekspor | Hasil, statistik, dan replay ronde |


### 5.2 Pintasan keyboard

| Tombol | Aksi |
|---|---|
| Spasi | Mulai / jeda |
| 1–9 | Fokus ke kartu meja |
| R | Reveal meja berikutnya |
| S | Tayangkan papan skor |
| Ctrl + Z | Batalkan koreksi poin terakhir (dengan konfirmasi) |


## 6. Front-end: Meja Jawab

Aplikasi peserta di tablet 10 inci (Chrome Android/iPad) atau Chromebook, layar penuh dan mode kios. Inti meja jawab adalah **input 3D yang ramah anak**.

```
+-------------------------------------------------------+
| Meja 3  Sari             Ronde 3/5              04:12 |
|                                                       |
|             3  1  2  4  2      <- angka pengintip     |
|         2 [ ][ ][ ][ ][ ] 3                           |
|         3 [ ][ ][#][ ][ ] 1       PAPAN 3D            |
|         ...                       (putar, zoom, atas) |
|             2  3  1  2  4                             |
|                                                       |
| [<][>][atas][awal]   [1][2][3][4][5][hapus]   (TENG!) |
+-------------------------------------------------------+
```


### 6.1 Cara memasukkan jawaban (3D-friendly)

| Cara | Gerakan | Untuk siapa |
|---|---|---|
| Kuas tinggi | Pilih tinggi di palet bawah, lalu ketuk petak. Kuas tetap aktif sehingga bisa mengetuk banyak petak | Cara utama, paling cepat |
| Ketuk bertumpuk | Tanpa kuas: setiap ketukan menambah satu lantai (0 → 1 → … → N → 0) | Anak kecil, terasa seperti menumpuk balok |
| Geser naik/turun | Tekan menara lalu geser ke atas/bawah untuk menambah/mengurangi lantai | Tablet layar sentuh |
| Keyboard | Panah memindah petak, angka 1–N mengisi, 0/Backspace menghapus | Chromebook/laptop dan aksesibilitas |
| Tampak atas 2D | Kamera tegak lurus dari atas dengan angka di setiap menara | Perangkat lemah atau anak yang pusing dengan 3D |

Palet menampilkan **sisa** setiap tinggi (setiap tinggi harus muncul tepat N kali). Ini latihan numerik kecil sekaligus petunjuk.


### 6.2 Mata Pengintip 👀

Mengetuk angka di pinggir papan membuat kamera terbang ke posisi mata pengintip, rendah di luar papan dan menghadap garis itu. Menara yang terlihat menyala biru, menara yang tertutup memudar, dan garis lain hampir transparan. Banner menampilkan “Terlihat 2 menara. Target: 3.” Peserta tetap dapat mengubah tinggi petak yang sedang dipilih lewat palet dan langsung melihat efeknya. Inilah inti latihan spasial: **membayangkan sudut pandang orang lain**.

Hitungan “terlihat” dihitung di meja dengan `engine.countVisible` dari papan peserta sendiri, tanpa kunci jawaban. Di Mode Champion, banner hanya menampilkan jumlah yang terlihat, tanpa warna benar/salah.


### 6.3 Bel

- **Bel layar**: tahan tombol TENG! selama 1 detik (cincin progres) agar tidak tertekan tidak sengaja.
- **Bel fisik (opsional)**: tombol arcade USB yang bekerja sebagai keyboard (tombol F24). Satu tekan = bel.
- Setelah bel: papan membeku, layar berganti “Jawaban terkunci, tunggu reveal”, dan suara bel diputar di Layar Siswa.


### 6.4 Status layar meja

| Status | Tampilan |
|---|---|
| Menunggu | Nama peserta, nomor meja, indikator koneksi; papan disembunyikan |
| Aturan | Tutorial animasi singkat (khusus ronde 1) |
| Hitung mundur | 5–4–3–2–1 besar; papan masih tertutup kabut |
| Bermain | Papan 3D aktif, timer, palet, bel |
| Terkunci | Papan beku dan diredupkan; pesan menunggu |
| Hasil | Bintang, poin, dan menara yang salah menyala merah; tombol “Lihat jawaban benar” |
| Dijeda | Layar biru “Ronde dijeda oleh operator”; timer berhenti |


### 6.5 Anggaran performa 3D

- Instancing untuk lantai menara; maksimal 36 menara × 6 lantai.
- Device pixel ratio dibatasi 1,5; bayangan otomatis mati jika FPS < 30.
- Tekstur jendela dibuat sekali di canvas dan dipakai ulang.
- Fallback otomatis ke tampak atas 2D jika WebGL tidak tersedia.


## 7. Front-end: Layar Siswa

Layar Siswa adalah “panggung TV” untuk penonton di kelas (proyektor 1920 × 1080). Ada juga rute opsional `/tonton` untuk HP murid dengan isi yang sama dalam versi ringkas.


### 7.1 Adegan

| Adegan | Isi | Data peserta yang tampil |
|---|---|---|
| Lobi | Judul acara, daftar meja dan peserta | Nama, avatar |
| Aturan | Animasi 3D aturan dan contoh pengintip | — |
| Hitung mundur | 5–4–3–2–1 dengan efek suara | — |
| LIVE | Grid kartu meja: progres, status, siluet papan tersensor, timer besar | Hanya persentase petak terisi dan urutan bel |
| BEL! | Overlay singkat “Meja 3 menekan bel! 02:41” | Nama dan waktu bel |
| Waktu habis | Animasi gembok untuk semua meja | — |
| Reveal | Papan 3D satu meja; kamera menyusuri setiap angka pengintip, angka berubah hijau/merah, lalu skor muncul | Papan lengkap meja yang sedang di-reveal |
| Papan skor | Peringkat ronde dan total | Poin dan bintang |
| Podium | Juara 1–3 dan penghargaan khusus | Nama dan avatar |


### 7.2 Aturan sensor

> **Penting: layar tidak boleh membocorkan jawaban**
>
> Selama LIVE, siluet papan di Layar Siswa hanya menunjukkan **petak mana yang sudah terisi** (balok abu-abu seragam), bukan tingginya.
> Tinggi menara baru tampil di adegan Reveal, setelah ronde ditutup.
> Opsi “tampilkan tinggi live” hanya untuk ruangan penonton yang terpisah dari peserta, dan operator wajib mengonfirmasi peringatan sebelum mengaktifkannya.


### 7.3 Koreografi reveal

1. Operator memilih meja (default: bel terakhir lebih dulu, juara di akhir untuk ketegangan).
2. Kamera terbang ke papan meja itu; menara tumbuh lantai demi lantai.
3. Kamera berpindah ke setiap pengintip: menara yang terlihat menyala dan angka berubah hijau (cocok) atau merah (tidak cocok).
4. Hasil: “Sempurna!” atau jumlah menara yang tepat; poin dan bintang muncul.
5. Operator menekan R untuk meja berikutnya.


## 8. Anti-Curang

| Lapis | Mekanisme |
|---|---|
| Fisik | Meja menghadap dinding atau membelakangi Layar Siswa; jarak antarmeja ≥ 1,5 m; tablet dalam mode kios (Guided Access/App Pinning) |
| Soal | Seed Simetri: meja bersebelahan mendapat varian berbeda; papan disembunyikan sampai hitung mundur selesai |
| Protokol | Solusi tidak pernah dikirim ke klien; waktu dan urutan bel dari server; token meja + device ID; rate limit aksi |
| Tayangan | Layar Siswa disensor selama LIVE |
| Deteksi | Fokus hilang > 1,5 detik (dua kali = bendera merah); satu perangkat untuk dua meja; papan tiba-tiba lengkap dalam satu detik; meja menyalin varian meja lain (Jebakan Seed: papan cocok dengan solusi varian lain) |
| Audit | Event log berantai hash; replay langkah demi langkah untuk sengketa; koreksi operator wajib beralasan |

Bendera tidak menghukum otomatis. Operator meninjau dan memilih tindakan: abaikan, peringatkan, atau kunci meja.


## 9. Statistik & Analitik Spasial

Setiap aksi di meja tercatat (`moves`, `peeks`, `bells`), sehingga guru dapat melihat **cara** anak berpikir, bukan hanya hasil akhirnya.

| Indikator | Cara menghitung | Makna |
|---|---|---|
| Ketepatan | menara tepat ÷ petak terbuka | Hasil akhir |
| Efisiensi | petak terbuka ÷ jumlah aksi pengisian | Mendekati 1 = jarang coba-coba |
| Tepat pada percobaan pertama | % petak yang langsung diisi tinggi yang benar | Kematangan penalaran |
| Ketergantungan pengintip | jumlah dan lama mode pengintip per ronde | Seberapa butuh bantuan sudut pandang |
| Strategi patokan | apakah 5 petak pertama yang diisi adalah petak “pasti” (dari angka 1 atau N) | Memakai strategi yang diajarkan |
| Kembar dibuat | jumlah kali membuat tinggi kembar | Pemahaman aturan baris/kolom |
| Waktu bel | detik sejak mulai sampai bel | Kecepatan |

Laporan: kartu hasil per peserta, heatmap kesalahan per petak untuk setiap soal, perbandingan antar-ronde, dan ekspor CSV. Statistik ini adalah alat bantu guru, bukan label kemampuan anak.


## 10. Kebutuhan Non-Fungsional & Pengujian

| Kebutuhan | Target |
|---|---|
| Kapasitas | 16 meja + 1 operator + 2 layar + 40 klien /tonton |
| Latensi aksi → operator | < 150 ms di LAN |
| Akurasi waktu bel | selisih antar-meja < 50 ms |
| Pemulihan meja | < 10 detik setelah perangkat cadangan memindai QR |
| FPS meja | ≥ 30 di tablet kelas menengah |
| Aksesibilitas | Warna + angka (tidak hanya warna), kontras AA, mode kurangi animasi, kontrol keyboard |

Pengujian wajib: uji unit engine (ketunggalan semua paket soal dan varian), uji integrasi state machine ronde, simulasi 16 meja bot (`pnpm sim`), uji putus-sambung jaringan, dan gladi bersih dengan perangkat asli.


## 11. Eksekusi dengan Claude Code

Paket `clash-of-git-towerpeek.zip` berisi `CLAUDE.md`, versi Markdown dokumen ini, engine yang sudah diuji, paket soal, dan konfigurasi. Langkahnya: ekstrak, jalankan `claude` di folder itu, lalu minta Claude Code membaca `CLAUDE.md` dan mengerjakan milestone satu per satu.

| Milestone | Isi | Selesai jika |
|---|---|---|
| M0 | Monorepo, lint, test, port engine ke TypeScript | Uji engine lulus di CI lokal |
| M1 | Server: event, peserta, pemasangan meja, SQLite | Meja terpasang via QR dan muncul di operator |
| M2 | Round Controller + Clock Service | Hitung mundur dan tenggat sinkron di 3 perangkat |
| M3 | Meja Jawab: papan 3D, kuas, ketuk bertumpuk, keyboard, tampak atas | Papan 6 × 6 lancar ≥ 30 FPS di tablet |
| M4 | Mata Pengintip + bel (layar & fisik) | Kamera pengintip benar untuk keempat sisi |
| M5 | Judge + skor dua mode | Skor cocok dengan contoh di dokumen |
| M6 | Arena Operator | Semua kontrol bab 5 berfungsi |
| M7 | Layar Siswa + sensor + reveal | Selama LIVE tidak ada tinggi menara di payload /layar |
| M8 | Anti-curang + audit log + replay | Jebakan Seed terdeteksi di simulasi |
| M9 | Statistik & ekspor | Laporan peserta dan heatmap tersedia |
| M10 | Simulasi 16 bot, uji putus-sambung, polish | Semua target bab 10 tercapai |


## Lampiran A. Paket Soal Resmi

Soal dibangkitkan dari kode tetap di bawah ini dan sudah diverifikasi berjawaban tunggal. Angka di pinggir adalah petunjuk pengintip; angka pada petak kuning adalah menara dipaku (di kunci ditandai *). **Kunci jawaban bersifat rahasia** — jangan diproyeksikan.


### A.1 Mode SD

**Mode SD, Ronde 1: 3 × 3, 3 menit, 1 dipaku (kode COG-SD-R1)**

```
    2  1  3
2 | ·  ·  · | 2
1 | ·  ·  · | 2
3 | ·  2  · | 1
    2  2  1
```

**Mode SD, Ronde 2: 4 × 4, 5 menit, 5 dipaku (kode COG-SD-R2)**

```
    3  2  2  1
4 | ·  2  ·  · | 1
2 | ·  ·  ·  2 | 2
1 | 4  ·  ·  · | 2
3 | ·  3  4  · | 2
    2  2  1  3
```

**Mode SD, Ronde 3: 5 × 5, 8 menit, 8 dipaku (kode COG-SD-R3)**

```
    2  2  2  1  3
3 | ·  ·  ·  ·  · | 2
2 | ·  1  ·  ·  4 | 2
1 | 5  2  4  ·  3 | 3
4 | ·  ·  ·  ·  5 | 1
2 | 4  ·  ·  ·  · | 4
    2  1  3  3  2
```

**Mode SD, Ronde 4: 6 × 6, 10 menit, 12 dipaku (kode COG-SD-R4)**

```
    3  2  2  3  2  1
3 | ·  ·  3  4  ·  · | 1
2 | 5  ·  1  ·  ·  · | 2
2 | ·  2  ·  ·  ·  · | 4
3 | 3  ·  ·  ·  ·  · | 3
1 | 6  4  2  ·  5  · | 3
2 | ·  ·  ·  ·  1  5 | 2
    2  1  3  2  3  2
```

**Mode SD, Ronde 5: 6 × 6, 12 menit, 10 dipaku (kode COG-SD-R5)**

```
    3  2  1  5  3  2
3 | ·  5  ·  ·  2  · | 2
4 | ·  4  ·  ·  ·  6 | 1
2 | ·  ·  ·  ·  ·  · | 2
1 | 6  ·  ·  ·  4  1 | 4
2 | ·  ·  4  ·  ·  · | 2
2 | ·  2  ·  ·  ·  3 | 3
    2  2  4  1  2  3
```


### A.2 Mode Champion

**Mode Champion, Ronde 1: 4 × 4, 3 menit, 2 dipaku (kode COG-CHAMPION-R1)**

```
    1  2  2  3
1 | ·  ·  ·  · | 3
2 | ·  ·  4  · | 2
2 | ·  ·  ·  · | 2
3 | ·  ·  3  · | 1
    3  2  2  1
```

**Mode Champion, Ronde 2: 5 × 5, 6 menit, 0 dipaku (kode COG-CHAMPION-R2)**

```
    3  4  1  2  2
2 | ·  ·  ·  ·  · | 3
2 | ·  ·  ·  ·  · | 1
1 | ·  ·  ·  ·  · | 5
2 | ·  ·  ·  ·  · | 2
2 | ·  ·  ·  ·  · | 4
    3  1  2  2  3
```

**Mode Champion, Ronde 3: 5 × 5, 6 menit, 0 dipaku (kode COG-CHAMPION-R3)**

```
    2  3  1  2  4
2 | ·  ·  ·  ·  · | 3
3 | ·  ·  ·  ·  · | 2
1 | ·  ·  ·  ·  · | 2
2 | ·  ·  ·  ·  · | 3
4 | ·  ·  ·  ·  · | 1
    2  2  3  2  1
```

**Mode Champion, Ronde 4: 6 × 6, 10 menit, 4 dipaku (kode COG-CHAMPION-R4)**

```
    2  3  2  4  1  3
3 | ·  ·  ·  ·  ·  · | 2
1 | ·  4  ·  ·  ·  · | 2
2 | ·  ·  3  ·  ·  · | 4
2 | ·  ·  ·  ·  ·  · | 2
3 | ·  ·  ·  4  ·  · | 1
3 | ·  1  ·  ·  ·  · | 3
    3  3  2  1  2  2
```

**Mode Champion, Ronde 5: 6 × 6, 10 menit, 4 dipaku (kode COG-CHAMPION-R5)**

```
    1  2  2  4  2  4
1 | ·  ·  ·  ·  ·  · | 4
2 | ·  ·  ·  ·  ·  · | 2
2 | 1  ·  3  ·  ·  · | 2
4 | 2  ·  ·  ·  ·  · | 1
2 | ·  ·  ·  1  ·  · | 3
3 | ·  ·  ·  ·  ·  · | 2
    4  2  2  1  3  2
```


## Lampiran B. Konfigurasi Default

```
{
  "$comment": "Konfigurasi modul Tower Peek di Clash of Git SIMPETERI. Semua angka dibaca server saat sesi dibuat.",
  "jumlah_meja_default": 8,
  "jumlah_meja_maks": 16,
  "mode": {
    "SD": {
      "warna_per_tinggi": true,
      "tandai_kembar": true,
      "cek_angka_pengintip": false,
      "bantuan_per_ronde": 1,
      "poin": {
        "ketepatan_maks": 100,
        "nilai_sebagian": true,
        "bonus_waktu_maks": 50,
        "bonus_bel": [
          30,
          20,
          10
        ],
        "biaya_bantuan": 25
      }
    },
    "CHAMPION": {
      "warna_per_tinggi": false,
      "tandai_kembar": false,
      "cek_angka_pengintip": false,
      "bantuan_per_ronde": 0,
      "poin": {
        "peringkat_benar": [
          10,
          8,
          6,
          5,
          4,
          3,
          2,
          1
        ],
        "benar_tanpa_bel_pengali": 0.5,
        "salah": 0
      }
    }
  },
  "bel": {
    "layar_tahan_ms": 1000,
    "tombol_fisik": {
      "aktif": true,
      "tombol_keyboard": "F24",
      "tekan_ganda_ms": 0
    }
  },
  "hitung_mundur_detik": 5,
  "peringatan_waktu_detik": [
    60,
    30,
    10
  ],
  "sinkron_waktu": {
    "sampel_ping": 7,
    "interval_ulang_detik": 30
  },
  "seed_simetri": {
    "aktif": true,
    "catatan": "Meja bersebelahan wajib mendapat varian berbeda. Papan 3x3 hanya punya 4 varian berbeda."
  },
  "layar_siswa": {
    "sensor_live": true,
    "tampilkan_tinggi_live": false,
    "urutan_reveal": "bel_terakhir_dulu"
  },
  "anti_curang": {
    "fokus_hilang_toleransi_ms": 1500,
    "fokus_hilang_maks": 2,
    "papan_disembunyikan_sebelum_mulai": true
  },
  "grafis_meja": {
    "dpr_maks": 1.5,
    "bayangan": "otomatis",
    "fps_minimum": 30,
    "fallback_2d": true
  }
}
```

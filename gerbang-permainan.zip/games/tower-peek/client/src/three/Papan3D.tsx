import { forwardRef, useEffect, useImperativeHandle, useRef } from "react";
import type { Clues } from "@tower-peek/shared";
import { TowerScene } from "./TowerScene";

export interface Papan3DApi {
  scene: () => TowerScene | null;
}
interface Props {
  n: number;
  dipaku: readonly number[];
  clues: Clues | null;
  papan: readonly number[];
  dprMaks?: number;
  interaktif?: boolean;
  onPick?: (sel: number) => void;
  onSiap?: (s: TowerScene) => void;
}
/** Pembungkus React untuk TowerScene: mengurus ukuran kanvas dan siklus hidup. */
export const Papan3D = forwardRef<Papan3DApi, Props>(function Papan3D(p, ref) {
  const cv = useRef<HTMLCanvasElement>(null);
  const wrap = useRef<HTMLDivElement>(null);
  const sc = useRef<TowerScene | null>(null);
  const pick = useRef(p.onPick);
  pick.current = p.onPick;
  useImperativeHandle(ref, () => ({ scene: () => sc.current }));
  useEffect(() => {
    const s = new TowerScene(cv.current!, { dprMaks: p.dprMaks ?? 1.5, interaktif: p.interaktif !== false });
    sc.current = s;
    s.onPick = (x) => pick.current?.(x);
    const ro = new ResizeObserver(() => {
      const r = wrap.current!.getBoundingClientRect();
      s.ukuran(Math.max(2, r.width), Math.max(2, r.height));
    });
    ro.observe(wrap.current!);
    p.onSiap?.(s);
    return () => {
      ro.disconnect();
      s.dispose();
      sc.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  useEffect(() => {
    sc.current?.siapkan(p.n, p.dipaku, p.clues);
    sc.current?.setPapan(p.papan, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [p.n, p.clues, p.dipaku]);
  useEffect(() => {
    sc.current?.setPapan(p.papan);
  }, [p.papan]);
  return (
    <div className="kanvas3d" ref={wrap}>
      <canvas ref={cv} data-testid="canvas3d" />
    </div>
  );
});
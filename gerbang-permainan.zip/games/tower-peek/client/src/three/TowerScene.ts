// Papan 3D Tower Peek (three.js dibundel lokal). Lantai menara = InstancedMesh (≤ 36 × 6 = 216 instans).
import * as THREE from "three";
import { OrbitControls } from "three/examples/jsm/controls/OrbitControls.js";
import { lineCells } from "@tower-peek/shared";
import type { Clues, Side } from "@tower-peek/shared";
import { WARNA_TINGGI } from "../lib/tema";

const LANTAI = 6;
const BG = new THREE.Color("#ebe4d3");
let webglCache: boolean | null = null;
/** Diperiksa SEKALI: membuat konteks WebGL tiap render menghabiskan batas konteks peramban (±16) dan mematikan papan yang sedang tampil. */
export const webglTersedia = (): boolean => {
  if (webglCache !== null) return webglCache;
  try {
    const c = document.createElement("canvas");
    const gl = (c.getContext("webgl2") || c.getContext("webgl")) as WebGLRenderingContext | null;
    webglCache = !!gl;
    gl?.getExtension("WEBGL_lose_context")?.loseContext();
  } catch {
    webglCache = false;
  }
  return webglCache;
};
function pelat(teks: string, warna = "#1b2233", latar = "#fffdf8") {
  const c = document.createElement("canvas");
  c.width = c.height = 128;
  const g = c.getContext("2d")!;
  g.fillStyle = latar;
  g.beginPath();
  g.roundRect(8, 8, 112, 112, 26);
  g.fill();
  g.strokeStyle = "#1b2233";
  g.lineWidth = 7;
  g.stroke();
  g.fillStyle = warna;
  g.font = "700 76px 'Plus Jakarta Sans Variable','Plus Jakarta Sans',system-ui,sans-serif";
  g.textAlign = "center";
  g.textBaseline = "middle";
  g.fillText(teks, 64, 70);
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export class TowerScene {
  readonly renderer: THREE.WebGLRenderer;
  readonly scene = new THREE.Scene();
  readonly camera = new THREE.PerspectiveCamera(42, 1, 0.1, 100);
  private controls: OrbitControls;
  private n = 0;
  private lantai!: THREE.InstancedMesh;
  private alas!: THREE.InstancedMesh;
  private plates: THREE.Sprite[] = [];
  private platKey: { sisi: Side; i: number }[] = [];
  private papan: number[] = [];
  private tumbuh: number[] = []; // tinggi tampil (animasi tumbuh)
  private target: number[] = [];
  private sorot: Set<number> | null = null;
  private raf = 0;
  private fly: { dari: THREE.Vector3; ke: THREE.Vector3; t0: number; dur: number; tDari: THREE.Vector3; tKe: THREE.Vector3 } | null = null;
  private raycaster = new THREE.Raycaster();
  onPick: ((sel: number) => void) | null = null;
  private mati = false;
  private tmp = new THREE.Object3D();
  private downAt = { x: 0, y: 0, t: 0 };
  reduceMotion = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;

  constructor(
    readonly canvas: HTMLCanvasElement,
    opsi: { dprMaks?: number; interaktif?: boolean } = {},
  ) {
    (canvas as unknown as { __tp: TowerScene }).__tp = this; // pengait uji/diagnosis
    this.renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: false, powerPreference: "high-performance" });
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, opsi.dprMaks ?? 1.5));
    this.renderer.setClearColor(BG);
    this.scene.fog = new THREE.Fog(BG, 16, 40);
    this.scene.add(new THREE.HemisphereLight("#fffdf8", "#c9bfa6", 1.9));
    const sun = new THREE.DirectionalLight("#fff6e5", 1.7);
    sun.position.set(5, 9, 4);
    this.scene.add(sun);
    this.controls = new OrbitControls(this.camera, canvas);
    this.controls.enableDamping = true;
    this.controls.enablePan = false;
    this.controls.minDistance = 4;
    this.controls.maxDistance = 22;
    this.controls.maxPolarAngle = Math.PI / 2.05;
    this.controls.enabled = opsi.interaktif !== false;
    if (opsi.interaktif !== false) {
      canvas.addEventListener("pointerdown", (e) => (this.downAt = { x: e.clientX, y: e.clientY, t: performance.now() }));
      canvas.addEventListener("pointerup", (e) => {
        if (Math.hypot(e.clientX - this.downAt.x, e.clientY - this.downAt.y) < 8 && performance.now() - this.downAt.t < 500) this.pilih(e);
      });
    }
    const loop = () => {
      if (this.mati) return;
      this.raf = requestAnimationFrame(loop);
      this.tick();
    };
    loop();
  }

  private pos(sel: number) {
    const o = (this.n - 1) / 2;
    return { x: (sel % this.n) - o, z: Math.floor(sel / this.n) - o };
  }
  siapkan(n: number, dipaku: readonly number[], clues: Clues | null) {
    this.n = n;
    for (const o of [this.lantai, this.alas, ...this.plates]) if (o) this.scene.remove(o);
    const geo = new THREE.BoxGeometry(0.84, 0.46, 0.84);
    this.lantai = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ roughness: 0.55, metalness: 0.05 }), n * n * LANTAI);
    this.lantai.instanceColor = new THREE.InstancedBufferAttribute(new Float32Array(n * n * LANTAI * 3), 3);
    this.scene.add(this.lantai);
    this.alas = new THREE.InstancedMesh(new THREE.BoxGeometry(0.94, 0.12, 0.94), new THREE.MeshStandardMaterial({ roughness: 0.9 }), n * n);
    for (let s = 0; s < n * n; s++) {
      const p = this.pos(s);
      this.tmp.position.set(p.x, -0.06, p.z);
      this.tmp.updateMatrix();
      this.alas.setMatrixAt(s, this.tmp.matrix);
      this.alas.setColorAt(s, new THREE.Color(dipaku[s] ? "#ffc83d" : (Math.floor(s / n) + (s % n)) % 2 ? "#d9cfb8" : "#e2d9c4"));
    }
    this.scene.add(this.alas);
    this.platKey = [];
    this.plates = [];
    if (clues) {
      for (const sisi of ["top", "bottom", "left", "right"] as const)
        for (let i = 0; i < n; i++) {
          const sp = new THREE.Sprite(new THREE.SpriteMaterial({ map: pelat(String(clues[sisi][i]!)), transparent: true, depthWrite: false }));
          const o = (n - 1) / 2;
          const m = n / 2 + 0.75;
          sp.scale.set(0.7, 0.7, 1);
          sp.userData.teks = String(clues[sisi][i]!);
          if (sisi === "top") sp.position.set(i - o, 0.42, -m);
          else if (sisi === "bottom") sp.position.set(i - o, 0.42, m);
          else if (sisi === "left") sp.position.set(-m, 0.42, i - o);
          else sp.position.set(m, 0.42, i - o);
          this.scene.add(sp);
          this.plates.push(sp);
          this.platKey.push({ sisi, i });
        }
    }
    this.papan = new Array<number>(n * n).fill(0);
    this.tumbuh = new Array<number>(n * n).fill(0);
    this.target = new Array<number>(n * n).fill(0);
    this.sorot = null;
    this.rumah(true);
    this.kotor = true;
    this.kameraAtas(false, true);
  }
  setPapan(papan: readonly number[], instan = false) {
    this.papan = papan.slice();
    this.target = papan.map((v) => v || 0);
    if (instan || this.reduceMotion) this.tumbuh = this.target.slice();
  }
  /** menara yang disorot (terlihat) — lainnya dipudarkan; null = normal */
  setSorot(sel: number[] | null, garis: number[] | null = null) {
    this.sorot = sel ? new Set(sel) : null;
    this.garis = garis ? new Set(garis) : null;
  }
  private garis: Set<number> | null = null;
  setPelat(sisi: Side, i: number, status: "benar" | "salah" | "normal") {
    const k = this.platKey.findIndex((x) => x.sisi === sisi && x.i === i);
    if (k < 0) return;
    const mat = this.plates[k]!.material as THREE.SpriteMaterial;
    const teks = this.plates[k]!.userData.teks as string | undefined;
    mat.map?.dispose();
    mat.map = pelat(teks ?? "", status === "normal" ? "#1b2233" : "#ffffff", status === "benar" ? "#2fb36a" : status === "salah" ? "#ec4a3f" : "#fffdf8");
  }
  setTeksPelat(clues: Clues) {
    this.plates.forEach((p, k) => {
      p.userData.teks = String(clues[this.platKey[k]!.sisi][this.platKey[k]!.i]!);
    });
  }
  private rumah(instan = false) {
    const c = new THREE.Color();
    for (let s = 0; s < this.n * this.n; s++) {
      const tinggiTampil = this.tumbuh[s]!;
      const tinggiPenuh = Math.ceil(tinggiTampil - 1e-6);
      const p = this.pos(s);
      const nilai = this.papan[s] || 0;
      for (let l = 0; l < LANTAI; l++) {
        const idx = s * LANTAI + l;
        const frac = Math.max(0, Math.min(1, tinggiTampil - l));
        this.tmp.position.set(p.x, 0.23 + l * 0.48, p.z);
        this.tmp.scale.set(frac > 0 ? 1 : 0.0001, frac > 0 ? frac : 0.0001, frac > 0 ? 1 : 0.0001);
        this.tmp.updateMatrix();
        this.lantai.setMatrixAt(idx, this.tmp.matrix);
        c.set(WARNA_TINGGI[(nilai || 1) - 1] ?? "#cccccc");
        if (this.sorot) {
          if (this.sorot.has(s)) c.lerp(new THREE.Color("#2563eb"), 0.3);
          else c.lerp(BG, this.garis?.has(s) ? 0.82 : 0.93);
        }
        this.lantai.setColorAt(idx, c);
      }
      void tinggiPenuh;
    }
    this.lantai.instanceMatrix.needsUpdate = true;
    if (this.lantai.instanceColor) this.lantai.instanceColor.needsUpdate = true;
    if (this.alas.instanceColor) this.alas.instanceColor.needsUpdate = true;
    this.alas.instanceMatrix.needsUpdate = true;
    void instan;
  }
  private pilih(e: PointerEvent) {
    const r = this.canvas.getBoundingClientRect();
    this.raycaster.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), this.camera);
    const hit = this.raycaster.intersectObjects([this.lantai, this.alas], false)[0];
    if (!hit || hit.instanceId === undefined) return;
    const sel = hit.object === this.lantai ? Math.floor(hit.instanceId / LANTAI) : hit.instanceId;
    this.onPick?.(sel);
  }
  // ---- kamera
  private modeKamera: "awal" | "atas" | "intip" = "awal";
  /** Jarak kamera menyesuaikan lebar kanvas: kanvas sempit (tablet tegak, panel samping) mundur agar angka di tepi tidak terpotong. */
  private jarakAtas() {
    return (this.n * 1.55 + 3) * Math.min(1.6, Math.max(1, 1.05 / Math.max(0.3, this.camera.aspect)));
  }
  kameraAtas(tegakLurus: boolean, instan = false) {
    this.modeKamera = tegakLurus ? "atas" : "awal";
    const d = this.jarakAtas();
    const ke = tegakLurus ? new THREE.Vector3(0, d + 2, 0.01) : new THREE.Vector3(0, d * 0.78, d * 0.82);
    this.terbang(ke, new THREE.Vector3(0, 0.3, 0), instan);
  }
  kameraPengintip(sisi: Side, i: number) {
    const n = this.n;
    const o = (n - 1) / 2;
    const m = n / 2 + 4.6;
    const y = 1.5;
    let dari: THREE.Vector3;
    let lihat: THREE.Vector3;
    if (sisi === "top") {
      dari = new THREE.Vector3(i - o, y, -m);
      lihat = new THREE.Vector3(i - o, 1.1, 2);
    } else if (sisi === "bottom") {
      dari = new THREE.Vector3(i - o, y, m);
      lihat = new THREE.Vector3(i - o, 1.1, -2);
    } else if (sisi === "left") {
      dari = new THREE.Vector3(-m, y, i - o);
      lihat = new THREE.Vector3(2, 1.1, i - o);
    } else {
      dari = new THREE.Vector3(m, y, i - o);
      lihat = new THREE.Vector3(-2, 1.1, i - o);
    }
    this.modeKamera = "intip";
    this.terbang(dari, lihat);
  }
  private terbang(ke: THREE.Vector3, tKe: THREE.Vector3, instan = false) {
    if (instan || this.reduceMotion) {
      this.camera.position.copy(ke);
      this.controls.target.copy(tKe);
      this.controls.update();
      this.fly = null;
      return;
    }
    this.fly = { dari: this.camera.position.clone(), ke, t0: performance.now(), dur: 750, tDari: this.controls.target.clone(), tKe };
    this.controls.enabled = false;
  }
  private kotor = true;
  /** Render hanya bila ada perubahan (hemat baterai tablet & CPU proyektor); OrbitControls melaporkan gerak lewat update(). */
  private tick() {
    let gambar = this.kotor;
    this.kotor = false;
    if (this.fly) {
      const k = Math.min(1, (performance.now() - this.fly.t0) / this.fly.dur);
      const e = 1 - Math.pow(1 - k, 3);
      this.camera.position.lerpVectors(this.fly.dari, this.fly.ke, e);
      this.controls.target.lerpVectors(this.fly.tDari, this.fly.tKe, e);
      this.camera.lookAt(this.controls.target);
      gambar = true;
      if (k >= 1) {
        this.fly = null;
        this.controls.enabled = true;
      }
    } else if (this.controls.update()) gambar = true;
    let ubah = false;
    for (let s = 0; s < this.tumbuh.length; s++) {
      const d = this.target[s]! - this.tumbuh[s]!;
      if (Math.abs(d) > 0.001) {
        this.tumbuh[s] = this.tumbuh[s]! + Math.sign(d) * Math.min(Math.abs(d), 0.16);
        ubah = true;
      }
    }
    if (ubah || this.dirty) {
      this.rumah();
      this.dirty = false;
      gambar = true;
    }
    if (gambar) this.renderer.render(this.scene, this.camera);
  }  private dirty = false;
  segarkan() {
    this.dirty = true;
    this.kotor = true;
  }
  ukuran(w: number, h: number) {
    this.renderer.setSize(w, h, false);
    this.kotor = true;
    this.camera.aspect = w / Math.max(1, h);
    this.camera.updateProjectionMatrix();
    if (this.n && this.modeKamera !== "intip" && !this.fly) this.kameraAtas(this.modeKamera === "atas", true);
  }
  /** Reveal: menara tumbuh lantai demi lantai (kelas animasi dikendalikan pemanggil). */
  tumbuhBertahap(papan: readonly number[], msPerSel = 45): Promise<void> {
    this.papan = papan.slice();
    this.target = new Array<number>(this.n * this.n).fill(0);
    this.tumbuh = new Array<number>(this.n * this.n).fill(0);
    if (this.reduceMotion) {
      this.target = papan.map((v) => v || 0);
      this.tumbuh = this.target.slice();
      return Promise.resolve();
    }
    return new Promise((res) => {
      papan.forEach((v, s) => setTimeout(() => (this.target[s] = v || 0), s * msPerSel));
      setTimeout(res, papan.length * msPerSel + 700);
    });
  }
  garisSel(sisi: Side, i: number) {
    return lineCells(this.n, sisi, i);
  }
  dispose() {
    this.mati = true;
    cancelAnimationFrame(this.raf);
    this.controls.dispose();
    this.renderer.dispose();
    this.renderer.forceContextLoss(); // lepaskan konteks WebGL agar tidak menumpuk saat adegan berganti
  }
}
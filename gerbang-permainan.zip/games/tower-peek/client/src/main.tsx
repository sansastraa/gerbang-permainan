import "@fontsource-variable/plus-jakarta-sans";
import { StrictMode, useState } from "react";
import { createRoot } from "react-dom/client";
import { Host } from "./host/Host";
import { Layar } from "./layar/Layar";
import { Gabung } from "./play/Gabung";
import { Play } from "./play/Play";
import { BASE } from "./lib/net";
import "./styles.css";

function Rute() {
  const jalur = "/" + location.pathname.slice(BASE.length).replace(/\/+$/, "");
  const q = new URLSearchParams(location.search);
  const [tokenMeja] = useState(() => {
    const t = q.get("t");
    if (t) {
      localStorage.setItem("tp-token", t);
      history.replaceState(null, "", location.pathname); // token tidak dibiarkan di URL
    }
    return t ?? localStorage.getItem("tp-token") ?? "";
  });
  if (jalur === "/host" || jalur === "/operator") return <Host />;
  if (jalur === "/layar") return <Layar />;
  if (jalur === "/tonton") return <Layar ringkas />;
  const m = /^\/meja\/(\d+)$/.exec(jalur);
  if (m) return tokenMeja ? <Play token={tokenMeja} nomorUrl={+m[1]!} /> : <div className="layar-tengah"><div className="kartu-pesan"><h2>Pindai QR meja</h2><p>Minta guru menampilkan QR pemasangan meja {m[1]}.</p></div></div>;
  if (jalur === "/main") return tokenMeja ? <Play token={tokenMeja} /> : <Gabung />;
  return <Gabung />;
}
createRoot(document.getElementById("root")!).render(<StrictMode><Rute /></StrictMode>);
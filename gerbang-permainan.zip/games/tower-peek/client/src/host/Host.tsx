import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Socket } from "socket.io-client";
import QRCode from "qrcode";
import { Board2D } from "../play/Board2D";
import { BASE, api, emitAck, sambung } from "../lib/net";
import { fmtWaktu } from "../lib/tema";

interface Roster { kelas: string; roster: { id: string; name: string; absen: number }[]; pin: string; kembali: string; multiSesi?: string }
// eslint-disable-next-line @typescript-eslint/no-explicit-any
type Snap = any;

function Qr({ teks, ukuran = 150 }: { teks: string; ukuran?: number }) {
  const [src, setSrc] = useState("");
  useEffect(() => {
    void QRCode.toDataURL(teks, { margin: 1, width: ukuran * 2, color: { dark: "#0e1a2b", light: "#f6efe3" } }).then(setSrc);
  }, [teks, ukuran]);
  return src ? <img className="qr" src={src} width={ukuran} height={ukuran} alt={`Kode QR ${teks}`} /> : null;
}

/** Konsol guru: serah-terima Gerbang (towerpeek:host-ready → towerpeek:roster) atau PIN manual. */
function useToken(): { token: string | null; roster: Roster | null; setManual: (t: string) => void; menunggu: boolean } {
  const [token, setToken] = useState<string | null>(null);
  const [roster, setRoster] = useState<Roster | null>(null);
  const [menunggu, setMenunggu] = useState(!!window.opener);
  useEffect(() => {
    if (!window.opener) return;
    const h = (e: MessageEvent) => {
      if (e.origin !== location.origin || e.source !== window.opener || e.data?.type !== "towerpeek:roster") return;
      const d = e.data as Roster;
      setRoster(d);
      setToken(d.pin);
      setMenunggu(false);
    };
    window.addEventListener("message", h);
    const kirim = () => (window.opener as Window).postMessage({ type: "towerpeek:host-ready" }, location.origin);
    kirim();
    const t = setInterval(kirim, 1000);
    const stop = setTimeout(() => (clearInterval(t), setMenunggu(false)), 20000);
    return () => {
      window.removeEventListener("message", h);
      clearInterval(t);
      clearTimeout(stop);
    };
  }, []);
  return { token, roster, setManual: setToken, menunggu };
}

const STATUS_LABEL: Record<string, string> = { DRAFT: "Belum dimuat", LOADED: "Soal dimuat", BRIEFING: "Aturan tayang", COUNTDOWN: "Hitung mundur", LIVE: "Berlangsung", PAUSED: "Dijeda", CLOSED: "Ditutup", JUDGED: "Dinilai", REVEAL: "Reveal", SCORED: "Skor tayang", ARCHIVED: "Selesai" };

export function Host() {
  const { token, roster, setManual, menunggu } = useToken();
  const [pinIn, setPinIn] = useState("");
  const [snap, setSnap] = useState<Snap>(null);
  const [off, setOff] = useState(0);
  const [pesan, setPesan] = useState("");
  const [qrMeja, setQrMeja] = useState<{ nomor: number; token: string; jalur: string }[] | null>(null);
  const [lihat, setLihat] = useState<Snap>(null);
  const [stat, setStat] = useState<Snap>(null);
  const sock = useRef<Socket | null>(null);
  const [now, setNow] = useState(Date.now());
  const [galatPin, setGalatPin] = useState("");
  const [form, setForm] = useState({ nama: "", format: "KOMPETISI", mode: "SD", jumlahMeja: 8 });

  useEffect(() => {
    if (!token) return;
    const s = sambung("/operator", { token });
    sock.current = s;
    s.on("arena:snapshot", (d: Snap) => {
      setSnap(d);
      setOff(d.serverNow - Date.now());
    });
    s.on("connect_error", () => {
      setGalatPin("PIN guru ditolak server.");
      setManual("");
    });
    return () => void s.close();
  }, [token, setManual]);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now() + off), 250);
    return () => clearInterval(t);
  }, [off]);

  const aksi = useCallback(async (ev: string, p?: unknown) => {
    const r = await emitAck(sock.current!, ev, p);
    if (!r.ok) setPesan(r.pesan ?? r.kode ?? "Gagal");
    else setPesan("");
    return r;
  }, []);
  const rest = useCallback(
    async (path: string, body?: unknown, method = body ? "POST" : "GET") => {
      const r = await fetch(api(path), { method, headers: { "x-host-token": token ?? "", "content-type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
      return { ok: r.ok, status: r.status, json: (await r.json().catch(() => ({}))) as Snap };
    },
    [token],
  );
  const aktif = useMemo(() => (typeof snap?.sesi?.aktif === "number" ? snap.ronde[snap.sesi.aktif] : null), [snap]);
  const berikut = useMemo(() => snap?.ronde?.find((r: Snap) => r.status === "DRAFT" || r.status === "LOADED"), [snap]);

  const buat = async () => {
    const peserta = roster?.roster.map((r) => ({ id: r.id, nama: r.name })) ?? [];
    const r = await rest("sessions", { nama: form.nama || `Tower Peek ${roster?.kelas ?? ""}`.trim(), format: form.format, mode: form.mode, ...(form.format === "KOMPETISI" ? { jumlahMeja: form.jumlahMeja } : {}), ...(peserta.length ? { peserta: peserta.slice(0, form.format === "ARENA" ? 40 : 64) } : {}) });
    if (!r.ok) setPesan(r.json.pesan ?? r.json.error ?? "Gagal membuat sesi");
  };
  const pasang = async () => {
    const r = await rest(`sessions/${snap.sesi.id}/desks/pair`, {});
    if (r.ok) setQrMeja(r.json.meja);
  };
  const kunciHalaman = (url: string) => `${location.origin}${BASE}${url.replace(/^\//, "")}`;

  const kendali = (): JSX.Element => {
    const st = aktif?.status as string | undefined;
    const u = aktif?.urutan ?? berikut?.urutan;
    const b = (ev: string, label: string, p?: unknown, cls = "") => <button className={cls} onClick={() => void aksi(ev, p)}>{label}</button>;
    if (!st || st === "ARCHIVED" || st === "DRAFT") return berikut ? b("round:load", `Muat ronde ${berikut.urutan}`, { urutan: berikut.urutan }, "utama") : <span>Semua ronde selesai</span>;
    if (st === "LOADED") return <>{b("round:brief", "Tayangkan aturan", { urutan: u })}{b("round:start", "Mulai ▶", { urutan: u }, "utama")}</>;
    if (st === "BRIEFING") return b("round:start", "Mulai ▶", { urutan: u }, "utama");
    if (st === "LIVE") return <>{b("round:pause", "Jeda")}{b("round:extend", "+30 dtk", { detik: 30 })}{b("round:close", "Tutup ronde", undefined, "bahaya")}</>;
    if (st === "PAUSED") return <>{b("round:resume", "Lanjut ▶", undefined, "utama")}{b("round:close", "Tutup ronde", undefined, "bahaya")}</>;
    if (st === "JUDGED" || st === "REVEAL") return <>{b("judge:reveal", "Reveal berikutnya (R)", {}, "utama")}{b("round:score", "Tayangkan skor (S)")}</>;
    if (st === "SCORED") return b("round:archive", "Selesai ronde ✓", undefined, "utama");
    return <span>{STATUS_LABEL[st]}</span>;
  };

  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (["INPUT", "TEXTAREA", "SELECT"].includes((e.target as HTMLElement).tagName) || !snap?.sesi) return;
      const st = aktif?.status;
      if (e.code === "Space") {
        e.preventDefault();
        if (st === "LIVE") void aksi("round:pause");
        else if (st === "PAUSED") void aksi("round:resume");
        else if (st === "LOADED" || st === "BRIEFING") void aksi("round:start", { urutan: aktif.urutan });
      } else if (e.key.toLowerCase() === "r" && (st === "JUDGED" || st === "REVEAL")) void aksi("judge:reveal", {});
      else if (e.key.toLowerCase() === "s" && (st === "JUDGED" || st === "REVEAL")) void aksi("round:score");
      else if (e.ctrlKey && e.key.toLowerCase() === "z" && aktif?.hasil) {
        if (confirm("Batalkan koreksi poin terakhir?")) void aksi("score:undo");
      } else if (/^[1-9]$/.test(e.key)) document.getElementById(`meja-${e.key}`)?.scrollIntoView({ behavior: "smooth", block: "center" });
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  }, [snap, aktif, aksi]);

  const unduh = async (path: string, nama: string) => {
    const r = await fetch(api(path), { headers: { "x-host-token": token ?? "" } });
    const url = URL.createObjectURL(await r.blob());
    Object.assign(document.createElement("a"), { href: url, download: nama }).click();
    URL.revokeObjectURL(url);
  };

  if (!token)
    return (
      <div className="layar-tengah">
        <div className="kartu-pesan">
          <div className="logo"><span>Tower</span><b>Peek</b></div>
          {menunggu ? (
            <p>Menunggu daftar siswa dan PIN dari Gerbang Permainan…</p>
          ) : (
            <form onSubmit={(e) => { e.preventDefault(); setGalatPin(""); setManual(pinIn); }}>
              <label>PIN guru<input type="password" value={pinIn} onChange={(e) => setPinIn(e.target.value)} autoFocus data-testid="pin-guru" /></label>
              <button type="submit" disabled={pinIn.length < 4}>Masuk</button>
              {galatPin && <p className="galat">{galatPin}</p>}
              <p className="kecil">Dibuka dari Gerbang Permainan, PIN terisi otomatis.</p>
            </form>
          )}
        </div>
      </div>
    );

  if (!snap) return <div className="layar-tengah"><p>Menyambung…</p></div>;

  if (!snap.sesi)
    return (
      <div className="host siapkan">
        <div className="kartu-besar">
          <div className="logo"><span>Tower</span><b>Peek</b></div>
          <h1>Siapkan permainan</h1>
          {roster && <p className="kecil">Kelas <b>{roster.kelas}</b>: {roster.roster.length} siswa dari Gerbang.</p>}
          <label>Nama sesi<input value={form.nama} onChange={(e) => setForm({ ...form, nama: e.target.value })} placeholder={`Tower Peek ${roster?.kelas ?? ""}`} data-testid="nama-sesi" /></label>
          <fieldset>
            <legend>Format</legend>
            <label className="pil"><input type="radio" checked={form.format === "KOMPETISI"} onChange={() => setForm({ ...form, format: "KOMPETISI" })} /><b>Kompetisi</b><small>Meja jawab, sampai 16 meja, bel &amp; reveal</small></label>
            <label className="pil"><input type="radio" checked={form.format === "ARENA"} onChange={() => setForm({ ...form, format: "ARENA" })} data-testid="fmt-arena" /><b>Arena</b><small>Game biasa, sampai 40 pemain, masuk dengan PIN</small></label>
          </fieldset>
          <fieldset>
            <legend>Mode soal</legend>
            <label className="pil"><input type="radio" checked={form.mode === "SD"} onChange={() => setForm({ ...form, mode: "SD" })} /><b>Mode SD</b><small>Papan 3×3 → 6×6, menara dipaku, 1 bantuan</small></label>
            <label className="pil"><input type="radio" checked={form.mode === "CHAMPION"} onChange={() => setForm({ ...form, mode: "CHAMPION" })} /><b>Mode Champion</b><small>4×4 → 6×6, tanpa bantuan, hanya yang benar dapat poin</small></label>
          </fieldset>
          {form.format === "KOMPETISI" && <label>Jumlah meja<input type="number" min={1} max={16} value={form.jumlahMeja} onChange={(e) => setForm({ ...form, jumlahMeja: +e.target.value })} /></label>}
          <button className="utama" onClick={() => void buat()} data-testid="buat-sesi">Buat sesi</button>
          {pesan && <p className="galat">{pesan}</p>}
        </div>
      </div>
    );

  const arena = snap.sesi.format === "ARENA";
  const sisa = aktif?.deadline ? (aktif.status === "PAUSED" ? aktif.deadline - (aktif.pausedAt ?? now) - (aktif.pausedAt ? 0 : 0) : aktif.deadline - now) : 0;
  const joinUrl = `${location.origin}${BASE}?pin=${snap.sesi.pin}`;
  return (
    <div className="host">
      <header className="host-bar">
        <div className="judul"><div className="logo kecil"><span>Tower</span><b>Peek</b></div><div><b>{snap.sesi.nama}</b><small>{arena ? "Arena" : "Kompetisi"} · Mode {snap.sesi.mode === "SD" ? "SD" : "Champion"}</small></div></div>
        <nav className="ronde-chips">
          {snap.ronde.map((r: Snap) => <span key={r.urutan} className={`chip st-${r.status} ${aktif?.urutan === r.urutan ? "aktif" : ""}`} title={STATUS_LABEL[r.status]}>R{r.urutan} <small>{r.n}×{r.n}</small></span>)}
        </nav>
        <div className="timer-besar" data-testid="timer-host">{aktif && ["LIVE", "PAUSED", "COUNTDOWN"].includes(aktif.status) ? (aktif.status === "COUNTDOWN" ? `Mulai ${Math.max(0, Math.ceil((aktif.startAt - now) / 1000))}` : fmtWaktu(sisa)) : "--:--"}</div>
        <div className="kendali" data-testid="kendali">{kendali()}</div>
      </header>
      {pesan && <div className="galat bar-galat" role="alert">{pesan}</div>}
      {aktif?.pengganti && <div className="info-bar">Soal paket ronde ini simetris, jadi diganti soal setara bangkitan seed ({aktif.pengganti}) agar meja bersebelahan tak bisa saling melihat.</div>}

      <div className="host-isi">
        <section className="kolom-meja">
          {(!aktif || ["DRAFT", "LOADED", "BRIEFING"].includes(aktif.status)) && (
            <div className="lobi-panel">
              {arena ? (
                <div className="pin-arena">
                  <div><small>PIN gabung</small><b className="pin-besar" data-testid="pin-arena">{snap.sesi.pin}</b><span>{snap.meja.length}/{snap.sesi.jumlahMeja} pemain · {snap.meja.filter((m: Snap) => m.online).length} online</span></div>
                  <Qr teks={joinUrl} ukuran={140} />
                  <code>{joinUrl}</code>
                </div>
              ) : (
                <div>
                  <button onClick={() => void pasang()} data-testid="pasang-meja">Pasang meja (buat QR)</button>
                  {qrMeja && (
                    <div className="qr-grid">
                      {qrMeja.map((m) => <figure key={m.nomor}><Qr teks={kunciHalaman(m.jalur)} ukuran={110} /><figcaption>Meja {m.nomor}</figcaption></figure>)}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
          <div className="kartu-grid">
            {snap.meja.map((m: Snap) => (
              <article key={m.nomor} id={`meja-${m.nomor}`} className={`kartu-meja st-${m.status} ${m.bendera ? "bendera" : ""} ${m.online ? "" : "off"}`}>
                <div className="atas"><b>{arena ? m.nomor : `M${m.nomor}`}</b><span className="nm">{m.nama ?? "—"}</span><i className={`dot ${m.online ? "on" : ""}`} /></div>
                <div className="prog" role="progressbar" aria-valuenow={Math.round(m.persen * 100)}><span style={{ width: `${m.persen * 100}%` }} /></div>
                <div className="meta">
                  <span>{m.status === "BELL" ? `BEL #${m.belUrutan}` : m.jeda ? "dijeda" : m.status.toLowerCase().replace("_", " ")}</span>
                  <span>kembar {m.kembar}</span>
                  {m.validasi > 0 && <span>cek {m.validasi}×</span>}
                  {m.varianK !== null && !arena && <span>k={m.varianK}</span>}
                  {m.fokus > 0 && <span className="peringatan">fokus {m.fokus}×</span>}
                </div>
                <div className="tombol">
                  <button onClick={async () => { const r = await aksi("desk:view", { nomor: m.nomor }); if (r.ok) setLihat(r.data); }} disabled={!aktif || aktif.status === "DRAFT"}>lihat papan</button>
                  {aktif?.status === "LIVE" && m.status === "PLAYING" && <button onClick={() => void aksi(m.jeda ? "desk:resume" : "desk:pause", { nomor: m.nomor })}>{m.jeda ? "lanjut" : "jeda"}</button>}
                  {aktif?.status === "LIVE" && m.status === "PLAYING" && <button onClick={() => void aksi("desk:lock", { nomor: m.nomor })}>kunci</button>}
                  {!arena && <button onClick={async () => { const r = await aksi("desk:swap", { nomor: m.nomor }); if (r.ok) setQrMeja((r.data as { meja: { nomor: number; token: string; jalur: string }[] }).meja); }}>pindahkan</button>}
                </div>
              </article>
            ))}
          </div>
        </section>

        <aside className="kolom-samping">
          <section className="panel">
            <h3>Bendera anti-curang <small>{snap.flags.filter((f: Snap) => f.status === "baru").length} baru</small></h3>
            {snap.flags.length === 0 && <p className="kecil">Tidak ada bendera.</p>}
            <ul className="bendera-daftar">
              {snap.flags.slice().reverse().map((f: Snap) => (
                <li key={f.id} className={`${f.tingkat} ${f.status}`}>
                  <b>{f.tipe.replace("_", " ")}</b> meja {f.nomor} · R{f.urutan}
                  <small>{JSON.stringify(f.detail)}</small>
                  {f.status === "baru" ? (
                    <span className="tombol">
                      <button onClick={() => void aksi("flag:resolve", { id: f.id, tindakan: "diabaikan" })}>Abaikan</button>
                      <button onClick={() => void aksi("flag:resolve", { id: f.id, tindakan: "diperingatkan" })}>Peringatkan</button>
                      <button className="bahaya" onClick={() => void aksi("flag:resolve", { id: f.id, tindakan: "dikunci" })}>Kunci meja</button>
                    </span>
                  ) : <em>{f.status}</em>}
                </li>
              ))}
            </ul>
          </section>

          <section className="panel">
            <h3>Adegan layar</h3>
            <div className="adegan">
              {["lobi", "aturan", "mundur", "live", "reveal", "skor", "podium"].map((a) => <button key={a} className={snap.adeganManual === a ? "on" : ""} onClick={() => void aksi("scene:set", { adegan: a })}>{a}</button>)}
              <button className={!snap.adeganManual ? "on" : ""} onClick={() => void aksi("scene:set", { adegan: null })}>otomatis</button>
            </div>
            <label className="cek"><input type="checkbox" checked={snap.sorotan} data-testid="toggle-sorotan" onChange={(e) => { if (!e.target.checked) void aksi("scene:spotlight", { aktif: false }); else if (arena || confirm("Sorotan menayangkan papan 3D satu peserta (termasuk tinggi menara) secara bergilir. Di Kompetisi pakai HANYA bila peserta tidak melihat layar. Lanjutkan?")) void aksi("scene:spotlight", { aktif: true, konfirmasi: true }); }} />Sorotan 3D bergilir (satu pemain tiap 10 detik)</label>
            <label className="cek"><input type="checkbox" checked={snap.tinggiLive} onChange={(e) => { if (!e.target.checked) void aksi("scene:height", { aktif: false }); else if (confirm("Tinggi menara peserta akan tampil di layar selama ronde. Pakai HANYA bila penonton terpisah dari peserta. Lanjutkan?")) void aksi("scene:height", { aktif: true, konfirmasi: true }); }} />Tampilkan tinggi live (ruang penonton terpisah)</label>
            <small>Layar: <a href={`${BASE}layar`} target="_blank" rel="noreferrer">{location.origin}{BASE}layar</a></small>
          </section>

          {snap.klasemen.length > 0 && (
            <section className="panel">
              <h3>Klasemen</h3>
              <table className="tabel">
                <thead><tr><th>#</th><th>Nama</th>{snap.ronde.map((r: Snap) => <th key={r.urutan}>R{r.urutan}</th>)}<th>Total</th></tr></thead>
                <tbody>{snap.klasemen.map((k: Snap, i: number) => <tr key={k.nomor}><td>{i + 1}</td><td>{k.nama}</td>{k.perRonde.map((p: number | null, j: number) => <td key={j}>{p ?? "·"}</td>)}<td><b>{k.total}</b></td></tr>)}</tbody>
              </table>
            </section>
          )}

          {aktif?.hasil && (
            <section className="panel">
              <h3>Hasil ronde {aktif.urutan}</h3>
              <table className="tabel">
                <thead><tr><th>Meja</th><th>Tepat</th><th>Poin</th><th>★</th><th>Koreksi</th></tr></thead>
                <tbody>{aktif.hasil.map((h: Snap) => <tr key={h.nomor}><td>{h.nomor}</td><td>{h.tepat}/{h.terbuka}</td><td>{h.poin}</td><td>{"★".repeat(h.bintang)}</td><td><button onClick={() => { const d = Number(prompt("Perubahan poin (mis. -5 atau 10):")); if (!d) return; const alasan = prompt("Alasan (wajib):") ?? ""; void aksi("score:adjust", { nomor: h.nomor, delta: d, alasan }); }}>±</button></td></tr>)}</tbody>
              </table>
            </section>
          )}

          <section className="panel">
            <h3>Laporan &amp; ekspor</h3>
            <div className="tombol">
              {snap.ronde.filter((r: Snap) => r.hasil).map((r: Snap) => <button key={r.urutan} onClick={async () => { const x = await rest(`rounds/${r.urutan}/stats`); setStat({ ...x.json, urutan: r.urutan }); }}>Statistik R{r.urutan}</button>)}
              <button onClick={() => void unduh(`sessions/${snap.sesi.id}/export?format=csv`, "tower-peek.csv")}>CSV</button>
              <button onClick={() => void unduh(`sessions/${snap.sesi.id}/export`, "tower-peek.json")}>JSON</button>
              {snap.ronde.filter((r: Snap) => r.hasil).map((r: Snap) => <button key={"p" + r.urutan} onClick={() => void unduh(`rounds/${r.urutan}/replay`, `replay-R${r.urutan}.json`)}>Replay R{r.urutan}</button>)}
            </div>
          </section>
          <section className="panel">
            <button className="utama lebar" onClick={() => { if (roster?.kembali) window.open(`${roster.kembali}${roster.kembali.includes("?") ? "&" : "?"}selesai=1&gameSesi=${snap.sesi.id}`, "_self"); else setPesan(`Kode sesi: ${snap.sesi.id}`); }} data-testid="selesai">Selesai · kembali ke Gerbang</button>
            <small>Kode sesi: {snap.sesi.id}</small>
          </section>
        </aside>
      </div>

      {lihat && (
        <div className="modal" onClick={() => setLihat(null)}>
          <div className="kartu-besar" onClick={(e) => e.stopPropagation()}>
            <h3>Papan meja {lihat.nomor} <small>(hanya terlihat di laptop operator)</small></h3>
            <Board2D n={lihat.n} papan={lihat.papan} dipaku={lihat.dipaku} clues={lihat.petunjuk} sel={null} warna kembar={new Set()} sorot={null} garis={null} peek={null} mati />
            <button onClick={() => setLihat(null)}>Tutup</button>
          </div>
        </div>
      )}
      {qrMeja && !(!aktif || ["DRAFT", "LOADED", "BRIEFING"].includes(aktif?.status)) && (
        <div className="modal" onClick={() => setQrMeja(null)}><div className="kartu-besar" onClick={(e) => e.stopPropagation()}><h3>QR pemasangan</h3><div className="qr-grid">{qrMeja.map((m) => <figure key={m.nomor}><Qr teks={kunciHalaman(m.jalur)} ukuran={150} /><figcaption>Meja {m.nomor}</figcaption></figure>)}</div><button onClick={() => setQrMeja(null)}>Tutup</button></div></div>
      )}
      {stat && (
        <div className="modal" onClick={() => setStat(null)}>
          <div className="kartu-besar lebar" onClick={(e) => e.stopPropagation()}>
            <h3>Statistik ronde {stat.urutan}</h3>
            <table className="tabel">
              <thead><tr><th>Nama</th><th>Ketepatan</th><th>Efisiensi</th><th>Tepat 1×</th><th>Intip</th><th>Strategi</th><th>Kembar</th><th>Bel (dtk)</th></tr></thead>
              <tbody>{stat.indikator.map((i: Snap) => <tr key={i.nomor}><td>{i.nama}</td><td>{Math.round(i.ketepatan * 100)}%</td><td>{i.efisiensi?.toFixed(2) ?? "–"}</td><td>{typeof i.tepatPercobaanPertama === "number" ? Math.round(i.tepatPercobaanPertama * 100) + "%" : "–"}</td><td>{i.pengintip.jumlah}× / {Math.round(i.pengintip.durasiMs / 1000)}s</td><td>{i.strategiPatokan}/5</td><td>{i.kembarDibuat}</td><td>{i.waktuBelDetik ?? "–"}</td></tr>)}</tbody>
            </table>
            <h4>Peta kesalahan per petak {stat.bermakna ? "" : "(Arena: papan tiap pemain berbeda)"}</h4>
            <div className="heat" style={{ gridTemplateColumns: `repeat(${stat.n}, 1fr)` }}>
              {stat.petaPanas.map((v: number, i: number) => <span key={i} style={{ background: `rgba(224,69,58,${Math.min(1, v / Math.max(1, ...stat.petaPanas))})` }}>{v}</span>)}
            </div>
            <small>Alat bantu guru, bukan label kemampuan anak.</small>
            <button onClick={() => setStat(null)}>Tutup</button>
          </div>
        </div>
      )}
    </div>
  );
}
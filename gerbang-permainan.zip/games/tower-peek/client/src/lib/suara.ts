// Efek suara sintetis (Web Audio), tanpa berkas dan tanpa internet. Bawaan mati di meja; layar menyalakannya lewat tombol.
let ctx: AudioContext | null = null;
export const suaraAktif = () => localStorage.getItem("tp-suara") === "1";
export const setSuara = (v: boolean) => {
  localStorage.setItem("tp-suara", v ? "1" : "0");
  if (v) ctx = ctx ?? new AudioContext();
};
function nada(f: number, dur: number, tipe: OscillatorType = "sine", vol = 0.15, delay = 0) {
  if (!suaraAktif()) return;
  ctx = ctx ?? new AudioContext();
  const t = ctx.currentTime + delay;
  const o = ctx.createOscillator();
  const g = ctx.createGain();
  o.type = tipe;
  o.frequency.setValueAtTime(f, t);
  g.gain.setValueAtTime(vol, t);
  g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
  o.connect(g).connect(ctx.destination);
  o.start(t);
  o.stop(t + dur);
}
export const bunyiBel = () => {
  nada(1320, 1.4, "sine", 0.2);
  nada(1760, 1.0, "triangle", 0.08, 0.02);
  nada(880, 1.6, "sine", 0.1, 0.04);
};
export const bunyiTik = (tinggi = false) => nada(tinggi ? 1046 : 740, 0.12, "square", 0.05);
export const bunyiBenar = () => [523, 659, 784, 1046].forEach((f, i) => nada(f, 0.25, "triangle", 0.1, i * 0.09));
export const bunyiSalah = () => nada(180, 0.35, "sawtooth", 0.08);
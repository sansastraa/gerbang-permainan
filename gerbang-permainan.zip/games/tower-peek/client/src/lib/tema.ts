export const WARNA_TINGGI = ["#ffc83d", "#ff8a2a", "#ec4a3f", "#8b5cf6", "#2fb36a", "#f26ba8"] as const;
export const NAMA_WARNA = ["kuning", "oranye", "merah", "ungu", "hijau", "merah muda"] as const;
export const SISI_NAMA: Record<string, string> = { top: "Utara", bottom: "Selatan", left: "Barat", right: "Timur" };
export const fmtWaktu = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
};
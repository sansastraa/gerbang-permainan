import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { estimasiOffset } from "@tower-peek/shared";
import type { SampelPing } from "@tower-peek/shared";

export const BASE: string = import.meta.env.BASE_URL;
export const api = (p: string) => `${BASE}api/${p}`;
export const sambung = (ns: string, auth: Record<string, unknown> = {}): Socket => io(ns, { path: `${BASE}socket.io`, auth, transports: ["websocket", "polling"] });
export const emitAck = <T = unknown>(s: Socket, ev: string, p?: unknown) =>
  new Promise<{ ok: boolean; kode?: string; pesan?: string; data: T }>((res) => {
    const t = setTimeout(() => res({ ok: false, kode: "timeout", pesan: "Tidak ada jawaban dari server", data: null as T }), 8000);
    s.emit(ev, p ?? {}, (r: never) => (clearTimeout(t), res(r)));
  });

/** Sinkron jam (SPEC §4.4): 7 ping, ambil sampel RTT terkecil; ulang tiap 30 dtk. */
export class JamSinkron {
  offset = 0;
  rtt = 0;
  private sampel: SampelPing[] = [];
  private timer: ReturnType<typeof setInterval> | null = null;
  constructor(
    private s: Socket,
    private n = 7,
    private intervalDtk = 30,
  ) {
    s.on("clock:pong", (m: { t0: number; ts: number }) => {
      this.sampel.push({ t0: m.t0, ts: m.ts, t1: Date.now() });
      if (this.sampel.length >= this.n) {
        const h = estimasiOffset(this.sampel);
        if (h) {
          this.offset = h.offset;
          this.rtt = h.rtt;
        }
        this.sampel = [];
      }
    });
  }
  mulai() {
    const ping = () => {
      for (let i = 0; i < this.n; i++) setTimeout(() => this.s.emit("clock:ping", { t0: Date.now() }), i * 60);
    };
    ping();
    this.timer = setInterval(ping, this.intervalDtk * 1000);
  }
  henti() {
    if (this.timer) clearInterval(this.timer);
  }
  now() {
    return Date.now() + this.offset;
  }
  setelUlang(serverNow: number) {
    if (!this.rtt) this.offset = serverNow - Date.now();
  }
}
export const deviceId = (): string => {
  let d = localStorage.getItem("tp-device");
  if (!d) localStorage.setItem("tp-device", (d = "d" + Math.random().toString(36).slice(2, 10) + Date.now().toString(36)));
  return d;
};
import { useEffect, useState } from "react";
import { BASE, api, deviceId } from "../lib/net";

interface Info {
  nama: string;
  mode: string;
  bebas: { id: string; nama: string }[];
  bebasKetik: boolean;
  terisi: number;
  maks: number;
}
export function Gabung() {
  const [pin, setPin] = useState(new URLSearchParams(location.search).get("pin") ?? "");
  const [info, setInfo] = useState<Info | null>(null);
  const [nama, setNama] = useState("");
  const [galat, setGalat] = useState("");
  const cek = async (p: string) => {
    setGalat("");
    const r = await fetch(api(`join/info?pin=${encodeURIComponent(p)}`));
    if (r.ok) setInfo((await r.json()) as Info);
    else setGalat(r.status === 429 ? "Terlalu banyak percobaan. Tunggu semenit." : "PIN tidak cocok. Cek layar guru.");
  };
  useEffect(() => {
    if (/^\d{6}$/.test(pin)) void cek(pin);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);
  const masuk = async (body: { pesertaId?: string; nama?: string }) => {
    const r = await fetch(api("join"), { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ pin, deviceId: deviceId(), ...body }) });
    const j = (await r.json()) as { token?: string; pesan?: string };
    if (r.ok && j.token) {
      localStorage.setItem("tp-token", j.token);
      location.href = `${BASE}main`;
    } else setGalat(j.pesan ?? "Gagal masuk");
  };
  return (
    <div className="layar-tengah gabung">
      <div className="kartu-pesan">
        <div className="logo"><span>Tower</span><b>Peek</b></div>
        {!info ? (
          <form onSubmit={(e) => { e.preventDefault(); void cek(pin); }}>
            <label>PIN dari guru<input inputMode="numeric" autoComplete="off" maxLength={6} value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))} placeholder="6 angka" autoFocus data-testid="pin" /></label>
            <button type="submit" disabled={pin.length !== 6}>Lanjut</button>
          </form>
        ) : (
          <>
            <h2>{info.nama}</h2>
            <p className="kecil">{info.terisi}/{info.maks} pemain sudah masuk</p>
            {info.bebas.length > 0 && (
              <div className="pilih-nama">
                {info.bebas.map((b) => (
                  <button key={b.id} onClick={() => void masuk({ pesertaId: b.id })}>{b.nama}</button>
                ))}
              </div>
            )}
            {info.bebasKetik && (
              <form onSubmit={(e) => { e.preventDefault(); void masuk({ nama }); }}>
                <label>Namamu<input value={nama} maxLength={30} onChange={(e) => setNama(e.target.value)} data-testid="nama" /></label>
                <button type="submit" disabled={!nama.trim()}>Masuk arena</button>
              </form>
            )}
            {!info.bebas.length && !info.bebasKetik && <p>Semua nama sudah dipakai.</p>}
          </>
        )}
        {galat && <p className="galat" role="alert">{galat}</p>}
      </div>
    </div>
  );
}
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Socket } from "socket.io-client";
import { countVisible, lineCells } from "@tower-peek/shared";
import type { Clues, PuzzleDeliver, Side } from "@tower-peek/shared";
import { Board2D } from "./Board2D";
import { Papan3D } from "../three/Papan3D";
import type { Papan3DApi } from "../three/Papan3D";
import { webglTersedia } from "../three/TowerScene";
import { JamSinkron, deviceId, emitAck, sambung } from "../lib/net";
import { bunyiBel, bunyiTik, setSuara, suaraAktif } from "../lib/suara";
import { NAMA_WARNA, SISI_NAMA, WARNA_TINGGI, fmtWaktu } from "../lib/tema";

interface DeskState {
  nomor: number;
  namaPeserta: string | null;
  format: "KOMPETISI" | "ARENA";
  mode: "SD" | "CHAMPION";
  statusMeja: string;
  jeda: boolean;
  ronde: { urutan: number; total: number; n: number; status: string; waktuDetik: number } | null;
  jadwal: { startAt: number; deadline: number } | null;
  tenggatMeja: number | null;
  serverNow: number;
  papan?: number[];
  versi?: number;
  bantuanSisa?: number;
  validasi?: number;
  bisaPeriksa?: boolean;
  bel?: { urutan: number } | null;
  hasil?: Hasil | null;
  total?: number;
  peringatan?: number;
  config: { bel: { layar_tahan_ms: number; tombol_fisik: { aktif: boolean; tombol_keyboard: string } }; peringatanWaktu: number[] };
}
interface Hasil {
  tepat: number;
  terbuka: number;
  sempurna: boolean;
  poin: number;
  bintang: number;
  peringkat: number;
  salah: number[];
  rincian: Record<string, number>;
}

export function Play({ token, nomorUrl }: { token: string; nomorUrl?: number }) {
  const [conn, setConn] = useState<"menyambung" | "ok" | "putus" | "ditolak">("menyambung");
  const [tolak, setTolak] = useState("");
  const [st, setSt] = useState<DeskState | null>(null);
  const [pz, setPz] = useState<PuzzleDeliver | null>(null);
  const [papan, setPapan] = useState<number[]>([]);
  const [kuas, setKuas] = useState(0);
  const [tampil, setTampil] = useState<"3d" | "atas">(() => (localStorage.getItem("tp-tampil") === "atas" || !webglTersedia() ? "atas" : "3d"));
  const pilihTampil = (t: "3d" | "atas") => {
    localStorage.setItem("tp-tampil", t); // pilihan diingat per perangkat (tablet lemah / anak pusing 3D)
    setTampil(t);
  };
  const [peek, setPeek] = useState<{ sisi: Side; i: number } | null>(null);
  const [sel, setSel] = useState<number | null>(null);
  const [now, setNow] = useState(Date.now());
  const [jawab, setJawab] = useState<number[] | null>(null);
  const [catatan, setCatatan] = useState("");
  const [peringatan, setPeringatan] = useState(false);
  const sock = useRef<Socket | null>(null);
  const jam = useRef<JamSinkron | null>(null);
  const versi = useRef(0);
  const api3d = useRef<Papan3DApi>(null);
  const rondeRef = useRef(-1);
  const hiddenAt = useRef<number | null>(null);

  useEffect(() => {
    const s = sambung("/meja");
    sock.current = s;
    const j = new JamSinkron(s);
    jam.current = j;
    const halo = async () => {
      const r = await emitAck<{ serverNow: number }>(s, "desk:hello", { token, deviceId: deviceId() });
      if (!r.ok) {
        setConn("ditolak");
        setTolak(r.kode === "perangkat_lain" ? "Meja ini sedang dipakai perangkat lain. Minta guru memindahkan meja." : r.kode === "token_tidak_sah" ? "Kode meja tidak sah atau sudah diganti. Pindai QR yang baru." : (r.pesan ?? "Ditolak"));
        return;
      }
      j.setelUlang(r.data.serverNow);
      j.mulai();
      setConn("ok");
    };
    s.on("connect", () => void halo());
    s.on("disconnect", () => setConn("putus"));
    s.on("desk:state", (d: DeskState) => {
      setSt(d);
      if (d.ronde && d.ronde.urutan !== rondeRef.current) {
        rondeRef.current = d.ronde.urutan;
        setPz(null);
        setJawab(null);
        setSel(null);
        setPeek(null);
      }
      if (d.papan) {
        setPapan(d.papan);
        versi.current = d.versi ?? 0;
      }
    });
    s.on("puzzle:deliver", (p: PuzzleDeliver) => setPz(p));
    s.on("result:show", () => setPeek(null));
    return () => {
      j.henti();
      s.close();
    };
  }, [token]);

  useEffect(() => {
    const t = setInterval(() => setNow(jam.current?.now() ?? Date.now()), 200);
    return () => clearInterval(t);
  }, []);
  // fokus hilang → bendera (server menyaring dengan toleransi)
  useEffect(() => {
    const h = () => {
      if (document.hidden) hiddenAt.current = performance.now();
      else if (hiddenAt.current !== null) {
        const dur = performance.now() - hiddenAt.current;
        hiddenAt.current = null;
        void emitAck(sock.current!, "focus:lost", { durasiMs: Math.round(dur) });
      }
    };
    document.addEventListener("visibilitychange", h);
    return () => document.removeEventListener("visibilitychange", h);
  }, []);

  const n = pz?.n ?? st?.ronde?.n ?? 0;
  const status = st?.ronde?.status ?? "NONE";
  const main = status === "LIVE" && st?.statusMeja === "PLAYING" && !st.jeda && !!pz;
  const terkunci = st?.statusMeja === "BELL" || st?.statusMeja === "TIMEOUT_LOCKED" || st?.statusMeja === "REVEALED";
  const aturan = pz?.aturan;
  const clues: Clues | null = pz?.petunjuk ?? null;
  const dipaku = useMemo(() => pz?.dipaku ?? [], [pz]);

  const kembar = useMemo(() => {
    const k = new Set<number>();
    if (!aturan?.tandaiKembar || !n) return k;
    for (let i = 0; i < n * n; i++) {
      const v = papan[i];
      if (!v) continue;
      for (let q = 0; q < n; q++) {
        const r = Math.floor(i / n);
        const c = i % n;
        if ((q !== c && papan[r * n + q] === v) || (q !== r && papan[q * n + c] === v)) k.add(i);
      }
    }
    return k;
  }, [papan, n, aturan]);

  const isi = useCallback(
    (s: number, tinggi: number, sumber: "tap" | "kuas" | "keyboard" = "tap") => {
      if (!main || dipaku[s]) return;
      setPapan((p) => {
        const q = p.slice();
        q[s] = tinggi;
        return q;
      });
      void emitAck<unknown>(sock.current!, "board:set", { sel: s, tinggi, versi: versi.current, sumber, tKlien: Date.now() }).then((r) => {
        const d = r.data as { ok?: boolean; versi?: number; papan?: number[] | null } | null;
        if (r.ok && d) {
          if (d.versi !== undefined) versi.current = d.versi;
          if (d.ok === false && d.papan) setPapan(d.papan);
        } else if (!r.ok) setCatatan(r.pesan ?? "Aksi ditolak");
      });
    },
    [main, dipaku],
  );
  const ketukPetak = useCallback(
    (s: number) => {
      setSel(s);
      if (!main || dipaku[s]) return;
      const cur = papan[s] || 0;
      if (kuas) isi(s, cur === kuas ? 0 : kuas, "kuas");
      else isi(s, (cur + 1) % (n + 1), "tap");
    },
    [main, dipaku, papan, kuas, n, isi],
  );

  // keyboard: panah, angka, 0/Backspace, F24 = bel fisik, Esc = tutup pengintip
  const bel = useCallback(
    async (sumber: "layar" | "tombol") => {
      if (!main) return;
      const r = await emitAck(sock.current!, "bell:ring", { tKlien: Date.now(), rtt: jam.current?.rtt ?? 0, sumber });
      if (r.ok) bunyiBel();
      else setCatatan(r.pesan ?? "Bel gagal");
    },
    [main],
  );
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key === st?.config.bel.tombol_fisik.tombol_keyboard && st.config.bel.tombol_fisik.aktif) return void bel("tombol");
      if (e.key === "Escape") return void tutupPeek();
      if (!n) return;
      const pos = sel ?? 0;
      const r = Math.floor(pos / n);
      const c = pos % n;
      if (e.key === "ArrowRight") setSel(r * n + Math.min(n - 1, c + 1));
      else if (e.key === "ArrowLeft") setSel(r * n + Math.max(0, c - 1));
      else if (e.key === "ArrowDown") setSel(Math.min(n - 1, r + 1) * n + c);
      else if (e.key === "ArrowUp") setSel(Math.max(0, r - 1) * n + c);
      else if (/^[1-9]$/.test(e.key) && +e.key <= n) isi(pos, +e.key, "keyboard");
      else if (e.key === "0" || e.key === "Backspace" || e.key === "Delete") isi(pos, 0, "keyboard");
      else return;
      e.preventDefault();
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
     
  }, [st, n, sel, isi, bel]);

  // ---- mata pengintip
  const bukaPeek = (sisi: Side, i: number) => {
    if (!clues) return;
    setPeek({ sisi, i });
    void emitAck(sock.current!, "peek:open", { sisi, indeks: i });
    api3d.current?.scene()?.kameraPengintip(sisi, i);
  };
  const tutupPeek = () => {
    setPeek((p) => {
      if (p) void emitAck(sock.current!, "peek:close");
      return null;
    });
    api3d.current?.scene()?.kameraAtas(false);
  };
  const peekInfo = useMemo(() => {
    if (!peek || !n) return null;
    const sel = lineCells(n, peek.sisi, peek.i);
    let m = 0;
    const terlihat: number[] = [];
    for (const x of sel) {
      const v = papan[x] || 0;
      if (v > m) {
        m = v;
        terlihat.push(x);
      }
    }
    return { sel, terlihat, jumlah: countVisible(sel.map((x) => papan[x] || 0)), target: clues?.[peek.sisi][peek.i] ?? 0 };
  }, [peek, papan, n, clues]);
  useEffect(() => {
    const s = api3d.current?.scene();
    if (!s) return;
    if (peekInfo) s.setSorot(peekInfo.terlihat, peekInfo.sel);
    else s.setSorot(null);
    s.segarkan();
  }, [peekInfo, tampil]);

  // ---- bel tahan 1 detik
  const [tahan, setTahan] = useState(0);
  const tahanRef = useRef<number | null>(null);
  const mulaiTahan = () => {
    if (!main) return;
    const ms = st?.config.bel.layar_tahan_ms ?? 1000;
    const t0 = performance.now();
    const f = () => {
      const k = Math.min(1, (performance.now() - t0) / ms);
      setTahan(k);
      if (k >= 1) {
        tahanRef.current = null;
        setTahan(0);
        void bel("layar");
      } else tahanRef.current = requestAnimationFrame(f);
    };
    tahanRef.current = requestAnimationFrame(f);
  };
  const lepasTahan = () => {
    if (tahanRef.current) cancelAnimationFrame(tahanRef.current);
    tahanRef.current = null;
    setTahan(0);
  };

  // ---- peringatan waktu & hitung mundur
  const sisaMs = st?.tenggatMeja ? st.tenggatMeja - now : 0;
  const sisaDtk = Math.ceil(sisaMs / 1000);
  useEffect(() => {
    if (main && st?.config.peringatanWaktu.includes(sisaDtk)) {
      setPeringatan(true);
      bunyiTik(true);
      const t = setTimeout(() => setPeringatan(false), 1200);
      return () => clearTimeout(t);
    }
  }, [sisaDtk, main, st]);
  const mundur = status === "COUNTDOWN" && st?.jadwal ? Math.max(0, Math.ceil((st.jadwal.startAt - now) / 1000)) : null;

  const sisaTinggi = useMemo(() => Array.from({ length: n }, (_, k) => n - papan.filter((v) => v === k + 1).length), [papan, n]);
  const lihatJawaban = async () => {
    const r = await emitAck<{ solusi: number[] }>(sock.current!, "jawaban:request");
    if (r.ok) setJawab(r.data.solusi);
  };
  const warna = !!aturan?.warnaPerTinggi;
  const hasil = st?.hasil ?? null;
  const salah = useMemo(() => new Set(hasil?.salah ?? []), [hasil]);
  const tampilPapan = jawab ?? papan;

  if (conn === "ditolak")
    return (
      <div className="layar-tengah">
        <div className="kartu-pesan">
          <h2>Tidak bisa masuk</h2>
          <p>{tolak}</p>
        </div>
      </div>
    );

  return (
    <div className={`meja ${terkunci ? "terkunci" : ""} ${peringatan ? "peringatan" : ""}`} data-status={status} data-meja={st?.statusMeja}>
      <header className="bar">
        <div className="nama">
          <b>{st?.format === "ARENA" ? "Arena" : `Meja ${st?.nomor ?? nomorUrl ?? ""}`}</b>
          <span>{st?.namaPeserta ?? "…"}</span>
        </div>
        <div className="ronde-info">{st?.ronde ? `Ronde ${st.ronde.urutan}/${st.ronde.total} · ${st.ronde.n}×${st.ronde.n}` : "Menunggu"}</div>
        <div className={`waktu ${sisaDtk <= 10 && main ? "genting" : ""}`} data-testid="timer">{main || status === "PAUSED" ? fmtWaktu(sisaMs) : "--:--"}</div>
        <button className="ikon" onClick={() => { setSuara(!suaraAktif()); setCatatan(suaraAktif() ? "Suara menyala" : "Suara mati"); }} aria-label="Suara">Suara</button>
        <i className={`sinyal ${conn}`} title={conn} />
      </header>

      {!pz && !hasil && (
        <div className="layar-tengah">
          <div className="kartu-pesan menunggu">
            <div className="menara-hias" aria-hidden><u /><u /><u /><u /></div>
            <h2>{mundur !== null ? "Bersiap…" : status === "BRIEFING" ? "Aturan main" : "Menunggu guru"}</h2>
            {status === "BRIEFING" ? (
              <ol className="aturan">
                <li>Isi tiap petak dengan menara setinggi <b>1 sampai N</b> lantai.</li>
                <li>Di tiap baris dan kolom, <b>tinggi tidak boleh kembar</b>.</li>
                <li>Angka di pinggir = <b>berapa menara yang terlihat</b> dari arah itu.</li>
                <li>Menara tinggi <b>menutupi</b> yang lebih pendek di belakangnya.</li>
                <li>Selesai? <b>Tahan tombol TENG!</b> Jawaban langsung terkunci.</li>
              </ol>
            ) : (
              <p>{conn === "ok" ? "Papan akan muncul saat hitung mundur selesai." : conn === "menyambung" ? "Menyambung ke server…" : "Koneksi terputus, mencoba lagi…"}</p>
            )}
            {mundur !== null && <div className="mundur-besar" data-testid="mundur">{mundur}</div>}
          </div>
        </div>
      )}

      {pz && (
        <main className="area">
          <section className="papan-wrap">
            {tampil === "3d" && webglTersedia() ? (
              <Papan3D ref={api3d} n={pz.n} dipaku={dipaku} clues={clues} papan={tampilPapan} onPick={ketukPetak} />
            ) : (
              <Board2D n={pz.n} papan={tampilPapan} dipaku={dipaku} clues={clues} sel={sel} warna={warna} kembar={kembar} sorot={peekInfo ? new Set(peekInfo.terlihat) : null} garis={peekInfo ? new Set(peekInfo.sel) : null} salah={hasil && !jawab ? salah : null} peek={peek} onCell={ketukPetak} onClue={bukaPeek} mati={!main && !hasil} />
            )}
            {peekInfo && (
              <div className="banner-intip" role="status">
                <span>Mengintip dari {SISI_NAMA[peek!.sisi]}, jalur {peek!.i + 1}: terlihat <b>{peekInfo.jumlah}</b> menara{aturan?.mode === "SD" ? <> · target <b>{peekInfo.target}</b></> : null}</span>
                <button onClick={tutupPeek}>Selesai</button>
              </div>
            )}
            {terkunci && !hasil && <div className="tabir"><b>Jawaban terkunci</b><span>Tunggu reveal ya…</span></div>}
            {status === "PAUSED" && <div className="tabir biru"><b>Ronde dijeda guru</b><span>Waktu berhenti</span></div>}
            {st?.jeda && <div className="tabir biru"><b>Mejamu dijeda</b><span>Ada gangguan teknis, tunggu ya</span></div>}
            {mundur !== null && <div className="tabir kabut"><b className="mundur-besar">{mundur}</b></div>}
          </section>

          <aside className="kontrol">
            <div className="tampilan">
              <button className={tampil === "3d" ? "on" : ""} onClick={() => pilihTampil("3d")} disabled={!webglTersedia()}>3D</button>
              <button className={tampil === "atas" ? "on" : ""} onClick={() => pilihTampil("atas")}>Tampak atas</button>
              {tampil === "3d" && (
                <>
                  <button onClick={() => api3d.current?.scene()?.kameraAtas(false)}>Awal</button>
                  <button onClick={() => api3d.current?.scene()?.kameraAtas(true)}>Atas</button>
                </>
              )}
            </div>
            {clues && tampil === "3d" && (
              <div className="intip-daftar">
                <small>Ketuk angka untuk mengintip</small>
                {(["top", "right", "bottom", "left"] as const).map((sisi) => (
                  <div key={sisi} className="baris-intip">
                    <em>{SISI_NAMA[sisi]}</em>
                    {clues[sisi].map((v, i) => (
                      <button key={i} className={peek?.sisi === sisi && peek.i === i ? "aktif" : ""} onClick={() => bukaPeek(sisi, i)}>{v}</button>
                    ))}
                  </div>
                ))}
              </div>
            )}
            <div className="palet" role="group" aria-label="Palet tinggi menara">
              {Array.from({ length: n }, (_, k) => (
                <button key={k} className={`tinggi ${kuas === k + 1 ? "on" : ""}`} style={warna ? { ["--wt" as string]: WARNA_TINGGI[k] } : undefined} onClick={() => setKuas(kuas === k + 1 ? 0 : k + 1)} disabled={!main} aria-label={`Kuas tinggi ${k + 1}${warna ? ` (${NAMA_WARNA[k]})` : ""}, sisa ${sisaTinggi[k]}`} aria-pressed={kuas === k + 1}>
                  <b>{k + 1}</b>
                  <small>{sisaTinggi[k]}</small>
                </button>
              ))}
              <button className={`tinggi hapus ${kuas === 0 ? "on" : ""}`} onClick={() => setKuas(0)} disabled={!main} title="Mode ketuk bertumpuk: tiap ketukan menambah satu lantai">Ketuk<br />tumpuk</button>
              <button className="tinggi hapus" onClick={() => sel !== null && isi(sel, 0)} disabled={!main || sel === null}>Hapus</button>
            </div>
            <div className="aksi">
              {(st?.bantuanSisa ?? 0) > 0 && (
                <button className="bantu" disabled={!main} onClick={async () => { const r = await emitAck<{ papan: number[] }>(sock.current!, "hint:request"); if (r.ok) setPapan(r.data.papan); else setCatatan(r.pesan ?? ""); }}>Bantuan ({st?.bantuanSisa}) <small>−25 poin</small></button>
              )}
              {st?.bisaPeriksa && (
                <button className="periksa" disabled={!main} onClick={async () => { const r = await emitAck<{ tepat: number; terbuka: number; sempurna: boolean }>(sock.current!, "board:check"); if (r.ok) setCatatan(r.data.sempurna ? "Semua tepat. Tekan TENG!" : `${r.data.tepat} dari ${r.data.terbuka} petak sudah tepat`); else setCatatan(r.pesan ?? "Belum bisa memeriksa"); }}>Periksa jawaban <small>{st.validasi ?? 0}× diperiksa · tampil di papan peringkat</small></button>
              )}
              <button className="bel" disabled={!main} onPointerDown={mulaiTahan} onPointerUp={lepasTahan} onPointerLeave={lepasTahan} onKeyDown={(e) => { if (e.key === " " || e.key === "Enter") mulaiTahan(); }} onKeyUp={lepasTahan} style={{ ["--p" as string]: `${tahan * 100}%` }} aria-label="Tahan satu detik untuk menekan bel" data-testid="bel">
                <span>TENG!</span>
                <small>tahan 1 detik</small>
              </button>
            </div>
          </aside>
        </main>
      )}

      {hasil && (
        <div className="hasil-overlay" data-testid="hasil">
          <div className="kartu-hasil">
            <div className="bintang" aria-label={`${hasil.bintang} bintang`}>{[1, 2, 3].map((k) => <i key={k} className={k <= hasil.bintang ? "nyala" : ""}>★</i>)}</div>
            <h2>{hasil.sempurna ? "Sempurna!" : `${hasil.tepat} dari ${hasil.terbuka} menara tepat`}</h2>
            <p className="poin">+{hasil.poin} poin</p>
            <p className="kecil">Peringkat ronde: {hasil.peringkat} · Total: {st?.total ?? 0}</p>
            <button onClick={() => void lihatJawaban()}>Lihat jawaban benar</button>
            <p className="kecil">Menara yang salah menyala merah di papan.</p>
          </div>
        </div>
      )}
      {catatan && <div className="toast" onAnimationEnd={() => setCatatan("")}>{catatan}</div>}
    </div>
  );
}
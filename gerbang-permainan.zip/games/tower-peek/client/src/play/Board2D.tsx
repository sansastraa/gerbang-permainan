import type { Clues, Side } from "@tower-peek/shared";
import { WARNA_TINGGI } from "../lib/tema";

interface Props {
  n: number;
  papan: readonly number[];
  dipaku: readonly number[];
  clues: Clues | null;
  sel: number | null;
  warna: boolean;
  kembar: ReadonlySet<number>;
  sorot: ReadonlySet<number> | null;
  garis: ReadonlySet<number> | null;
  salah?: ReadonlySet<number> | null;
  benar?: ReadonlySet<number> | null;
  peek: { sisi: Side; i: number } | null;
  onCell?: (sel: number) => void;
  onClue?: (sisi: Side, i: number) => void;
  mati?: boolean;
}
/** Tampak atas 2D: papan yang sama, dengan angka di setiap menara (cadangan tanpa WebGL & mode "tampak atas"). */
export function Board2D(p: Props) {
  const { n } = p;
  const klue = (sisi: Side, i: number, r: number, c: number) => (
    <button key={`${sisi}${i}`} className={`klue ${p.peek?.sisi === sisi && p.peek.i === i ? "aktif" : ""}`} style={{ gridRow: r + 1, gridColumn: c + 1 }} onClick={() => p.onClue?.(sisi, i)} aria-label={`Angka pengintip ${sisi} ${i + 1}: ${p.clues?.[sisi][i]}`} disabled={!p.clues || !p.onClue}>
      {p.clues?.[sisi][i] ?? ""}
    </button>
  );
  return (
    <div className="papan2d" style={{ ["--n" as string]: n + 2 }} role="grid" aria-label="Papan menara">
      {p.clues && Array.from({ length: n }, (_, i) => klue("top", i, 0, i + 1))}
      {p.clues && Array.from({ length: n }, (_, i) => klue("bottom", i, n + 1, i + 1))}
      {p.clues && Array.from({ length: n }, (_, i) => klue("left", i, i + 1, 0))}
      {p.clues && Array.from({ length: n }, (_, i) => klue("right", i, i + 1, n + 1))}
      <span className="u" style={{ gridRow: 1, gridColumn: 1 }} title="Utara">U</span>
      {Array.from({ length: n * n }, (_, s) => {
        const v = p.papan[s] || 0;
        const cls = ["sel", p.dipaku[s] ? "paku" : "", p.sel === s ? "dipilih" : "", p.kembar.has(s) ? "kembar" : "", p.sorot ? (p.sorot.has(s) ? "terlihat" : p.garis?.has(s) ? "tertutup" : "redup") : "", p.salah?.has(s) ? "salah" : "", p.benar?.has(s) ? "benar" : ""].join(" ");
        return (
          <button key={s} role="gridcell" className={cls} data-sel={s} data-v={v} style={{ gridRow: Math.floor(s / n) + 2, gridColumn: (s % n) + 2, ...(p.warna && v ? { ["--wt" as string]: WARNA_TINGGI[v - 1] } : {}) }} onClick={() => p.onCell?.(s)} disabled={p.mati} aria-label={`Petak baris ${Math.floor(s / n) + 1} kolom ${(s % n) + 1}, tinggi ${v || "kosong"}${p.dipaku[s] ? ", dipaku" : ""}`}>
            
            <b>{v || ""}</b>
            {v ? <span className="lantai" aria-hidden>{Array.from({ length: v }, (_, k) => <u key={k} />)}</span> : null}
          </button>
        );
      })}
    </div>
  );
}
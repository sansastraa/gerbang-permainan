import { useEffect, useMemo, useRef, useState } from "react";
import QRCode from "qrcode";
import type { Clues, Side } from "@tower-peek/shared";
import { Board2D } from "../play/Board2D";
import { Papan3D } from "../three/Papan3D";
import type { Papan3DApi } from "../three/Papan3D";
import { webglTersedia } from "../three/TowerScene";
import { BASE, sambung } from "../lib/net";
import { bunyiBel, bunyiBenar, bunyiSalah, bunyiTik, setSuara, suaraAktif } from "../lib/suara";
import { SISI_NAMA, fmtWaktu } from "../lib/tema";

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type D = any;
const tidur = (ms: number) => new Promise((r) => setTimeout(r, ms));

function Menara({ persen, status }: { persen: number; status: string }) {
  const lantai = 6;
  const nyala = Math.round(persen * lantai);
  return <div className={`menara-progres s-${status}`} aria-hidden>{Array.from({ length: lantai }, (_, k) => <u key={k} className={lantai - k <= nyala ? "on" : ""} />)}</div>;
}

function Lobi({ d }: { d: D }) {
  const [qr, setQr] = useState("");
  useEffect(() => {
    if (d.pin) void QRCode.toDataURL(`${location.origin}${BASE}?pin=${d.pin}`, { margin: 1, width: 360, color: { dark: "#0e1a2b", light: "#f6efe3" } }).then(setQr);
  }, [d.pin]);
  return (
    <div className="adegan lobi">
      <div className="logo besar"><span>Tower</span><b>Peek</b></div>
      <h1>{d.namaSesi ?? "Menunggu sesi"}</h1>
      {d.pin && (
        <div className="gabung-kartu">
          {qr && <img src={qr} alt="QR gabung" width={200} height={200} />}
          <div><small>Masuk dari HP / tablet</small><b className="pin-besar">{d.pin}</b><span>{location.host}{BASE}</span></div>
        </div>
      )}
      <div className="lobi-grid">
        {d.meja?.map((m: D) => <div key={m.nomor} className={`chip-meja ${m.online ? "on" : ""}`}><i>{m.nomor}</i><span>{m.nama}</span></div>)}
      </div>
    </div>
  );
}

function Aturan({ d }: { d: D }) {
  const baris = ["Isi petak dengan menara setinggi 1 sampai N lantai.", "Di tiap baris dan kolom, tinggi tidak boleh kembar.", "Angka di pinggir = berapa menara yang terlihat dari sana.", "Menara tinggi menutupi yang lebih pendek di belakangnya.", "Selesai? Tahan TENG! Jawaban langsung terkunci."];
  return (
    <div className="adegan aturan-layar">
      <h1>Ronde {d.ronde?.urutan} · papan {d.ronde?.n}×{d.ronde?.n}</h1>
      <ol>{baris.map((b, i) => <li key={i} style={{ animationDelay: `${i * 0.35}s` }}><b>{i + 1}</b>{b}</li>)}</ol>
      <div className="contoh-intip" aria-hidden><div className="deret">{[1, 3, 2].map((h) => <u key={h} style={{ height: 30 + h * 38 }}><i>{h}</i></u>)}</div><p>Dari kiri terlihat <b>2</b> menara: 1 dan 3. Menara 2 tersembunyi di belakang 3.</p></div>
    </div>
  );
}

function Mundur({ d, now }: { d: D; now: number }) {
  const s = Math.max(0, Math.ceil((d.ronde.startAt - now) / 1000));
  const prev = useRef(-1);
  useEffect(() => {
    if (s !== prev.current && s > 0) bunyiTik(s <= 1);
    prev.current = s;
  }, [s]);
  return <div className="adegan mundur"><small>Ronde {d.ronde.urutan} dimulai dalam</small><div className="angka-raksasa" key={s}>{s || "Mulai!"}</div></div>;
}

function Sorotan({ s, selesai }: { s: D | null; selesai: boolean }) {
  const stab = useRef<{ nomor: number; clues: Clues; dipaku: number[]; n: number } | null>(null);
  if (s && stab.current?.nomor !== s.nomor) stab.current = { nomor: s.nomor, clues: s.petunjuk, dipaku: s.dipaku, n: s.n };
  const ada3d = webglTersedia();
  const k = stab.current;
  const keliling = 2 * Math.PI * 15;
  return (
    <div className="sorotan" data-testid="sorotan">
      {s && k ? (
        <>
          {ada3d ? <Papan3D n={k.n} dipaku={k.dipaku} clues={k.clues} papan={s.papan} interaktif={false} /> : <div className="kosong"><Board2D n={k.n} papan={s.papan} dipaku={k.dipaku} clues={k.clues} sel={null} warna kembar={new Set()} sorot={null} garis={null} peek={null} mati /></div>}
          <div className="kepala-sorotan">
            <div className="label"><small>Sorotan {s.ke}/{s.dari}</small><b>{s.nama}</b></div>
            {!selesai && (
              <div className="cincin" aria-label={`${s.sisaDetik} detik lagi`}>
                <svg viewBox="0 0 36 36" width="100%" height="100%"><circle className="trek" cx="18" cy="18" r="15" fill="none" /><circle className="isi" cx="18" cy="18" r="15" fill="none" strokeDasharray={keliling} strokeDashoffset={keliling * (1 - s.sisaDetik / s.durasi)} /></svg>
                <b>{s.sisaDetik}</b>
              </div>
            )}
          </div>
          <div className="kaki-sorotan"><span>{Math.round(s.persen * 100)}% terisi</span>{s.validasi > 0 && <span>diperiksa {s.validasi}×</span>}<span>3D langsung · geser sendiri di perangkatnya</span></div>
        </>
      ) : (
        <div className="kosong">Menunggu pemain mulai mengisi…</div>
      )}
    </div>
  );
}

function Peringkat({ d }: { d: D }) {
  const lis = d.peringkat as D[];
  const padat = lis.length > 12;
  return (
    <section className={`lb ${padat ? "lb-padat" : ""}`} data-testid="peringkat">
      <h2>Papan peringkat <small>skor ronde ini sementara</small></h2>
      <div className="lb-list" style={lis.length > 20 ? { gridTemplateColumns: "1fr 1fr" } : undefined}>
        {lis.map((m, i) => (
          <div key={m.nomor} className={`lb-baris r${i + 1} ${d.sorotan?.nomor === m.nomor ? "disorot" : ""}`} style={{ ["--p" as string]: m.persen }} data-testid="lb-baris">
            <span className="no">{i + 1}</span>
            <span className="nm">{m.nama}<small>{m.status === "bel" ? "sudah menekan bel" : m.status === "kunci" ? "terkunci" : `${Math.round(m.persen * 100)}% terisi`}</small></span>
            <span className="lencana">{m.validasi > 0 && <span title="Jumlah kali memeriksa jawaban">cek {m.validasi}×</span>}{m.belUrutan && <span className="bel">BEL {m.belUrutan}</span>}</span>
            <b className="skor">{m.total}</b>
          </div>
        ))}
      </div>
    </section>
  );
}

function Live({ d, now }: { d: D; now: number }) {
  const arena = d.format === "ARENA";
  const sisa = d.ronde.deadline ? (d.ronde.status === "PAUSED" ? d.ronde.deadline - (d.ronde.pausedAt ?? now) : d.ronde.deadline - now) : 0;
  const split = !!d.sorotan || !!d.peringkat;
  const kartu = (
    <div className={`kartu-live ${d.meja.length > 16 || (split && d.meja.length > 6) ? "padat" : ""}`}>
      {d.meja.map((m: D) => (
        <div key={m.nomor} className={`kartu st-${m.status}`} data-testid="kartu-live">
          <div className="kepala"><i>{m.nomor}</i><span>{m.nama}</span>{m.belUrutan && <em>BEL {m.belUrutan}</em>}</div>
          <Menara persen={m.persen} status={m.status} />
          <div className="pr"><span style={{ width: `${m.persen * 100}%` }} /></div>
          <small>{m.status === "bel" ? `Bel. Sisa ${m.belSisaDetik ?? 0} dtk` : m.status === "kunci" ? "terkunci" : m.status === "jeda" ? "dijeda" : m.status === "offline" ? "offline" : `${Math.round(m.persen * 100)}% terisi`}</small>
          {m.papan && <code className="papan-live">{m.papan.join("")}</code>}
        </div>
      ))}
    </div>
  );
  return (
    <div className={`adegan live ${arena ? "arena" : ""}`}>
      <header><div><small>Ronde {d.ronde.urutan}/{d.ronde.total}</small><b>{d.ronde.n}×{d.ronde.n}</b></div><div className={`timer-raksasa ${sisa < 10000 && d.ronde.status === "LIVE" ? "genting" : ""}`} data-testid="timer-layar">{d.ronde.status === "LIVE" || d.ronde.status === "PAUSED" ? fmtWaktu(sisa) : "00:00"}</div><div className="status-ronde">{d.ronde.status === "PAUSED" ? "Dijeda" : d.terkunciSemua ? "Waktu habis" : "Berlangsung"}</div></header>
      <div className={`live-isi ${split ? "split" : ""}`}>
        {d.peringkat ? <Peringkat d={d} /> : kartu}
        {d.sorotan !== undefined && (split && (d.sorotan || d.peringkat)) ? <Sorotan s={d.sorotan} selesai={d.terkunciSemua} /> : null}
      </div>
      {d.terkunciSemua && <div className="gembok" aria-hidden><span>Waktu habis</span></div>}
    </div>
  );
}
function Reveal({ d }: { d: D }) {
  const api = useRef<Papan3DApi>(null);
  const [cek, setCek] = useState<Record<string, "benar" | "salah">>({});
  const [selesai, setSelesai] = useState(false);
  const [sorot, setSorot] = useState<{ sel: number[] } | null>(null);
  const tok = useRef(0);
  const ada3d = webglTersedia();
  const clues = d.petunjuk as Clues;
  const nol = useMemo(() => d.papan.map(() => 0) as number[], [d.nomor, d.n]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    const id = ++tok.current;
    const batal = () => tok.current !== id;
    setCek({});
    setSelesai(false);
    setSorot(null);
    void (async () => {
      await tidur(ada3d ? 350 : 100);
      const sc = api.current?.scene();
      if (sc) {
        sc.setSorot(null);
        await sc.tumbuhBertahap(d.papan, 40);
      }
      if (batal()) return;
      for (const c of d.cek) {
        if (batal()) return;
        sc?.kameraPengintip(c.sisi as Side, c.indeks);
        sc?.setSorot(null);
        const lihat: number[] = [];
        let mx = 0;
        for (const x of c.sel as number[])
          if ((d.papan[x] || 0) > mx) {
            mx = d.papan[x];
            lihat.push(x);
          }
        sc?.setSorot(lihat, c.sel);
        sc?.segarkan();
        setSorot({ sel: lihat });
        await tidur(ada3d ? 900 : 350);
        if (batal()) return;
        sc?.setPelat(c.sisi as Side, c.indeks, c.cocok ? "benar" : "salah");
        setCek((x) => ({ ...x, [`${c.sisi}${c.indeks}`]: c.cocok ? "benar" : "salah" }));
        if (c.cocok) bunyiBenar();
        else bunyiSalah();
        await tidur(ada3d ? 450 : 150);
      }
      if (batal()) return;
      sc?.setSorot(null);
      sc?.kameraAtas(false);
      setSorot(null);
      setSelesai(true);
      if (d.hasil.sempurna) bunyiBenar();
    })();
    return () => {
      tok.current++; // eslint-disable-line react-hooks/exhaustive-deps
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [d.nomor, d.ronde?.urutan]);
  const h = d.hasil;
  return (
    <div className="adegan reveal">
      <div className="reveal-papan">
        {ada3d ? <Papan3D ref={api} n={d.n} dipaku={d.dipaku} clues={clues} papan={nol} interaktif={false} dprMaks={1.5} /> : <Board2D n={d.n} papan={d.papan} dipaku={d.dipaku} clues={clues} sel={null} warna kembar={new Set()} sorot={sorot ? new Set(sorot.sel) : null} garis={null} peek={null} mati salah={selesai ? new Set<number>(d.salah) : null} />}
      </div>
      <aside className="reveal-info">
        <small>Reveal {d.urutan}/{d.dari}</small>
        <h1>{d.nama}</h1>
        <div className="cek-daftar">
          {(["top", "right", "bottom", "left"] as const).map((s) => (
            <div key={s}><em>{SISI_NAMA[s]}</em>{d.cek.filter((c: D) => c.sisi === s).map((c: D) => <b key={c.indeks} className={cek[`${s}${c.indeks}`] ?? ""}>{c.petunjuk}</b>)}</div>
          ))}
        </div>
        {selesai && (
          <div className="skor-muncul">
            <div className="bintang">{[1, 2, 3].map((k) => <i key={k} className={k <= h.bintang ? "nyala" : ""} style={{ animationDelay: `${k * 0.25}s` }}>★</i>)}</div>
            <h2>{h.sempurna ? "Sempurna!" : `${h.tepat} dari ${h.terbuka} menara tepat`}</h2>
            <p className="poin">+{h.poin} poin</p>
          </div>
        )}
      </aside>
    </div>
  );
}

function Skor({ d }: { d: D }) {
  const maks = Math.max(1, ...d.klasemen.map((k: D) => k.total));
  return (
    <div className="adegan skor">
      <h1>Papan skor{d.ronde ? ` · setelah ronde ${d.ronde.urutan}` : ""}</h1>
      <div className="skor-daftar">
        {d.klasemen.slice(0, 12).map((k: D, i: number) => (
          <div key={k.nomor} className={`baris peringkat-${i + 1}`} style={{ animationDelay: `${i * 0.07}s` }}>
            <i>{i + 1}</i><span>{k.nama}</span><div className="batang"><u style={{ width: `${(k.total / maks) * 100}%` }} /></div><b>{k.total}</b>
          </div>
        ))}
      </div>
      {d.hasil?.length > 0 && <p className="ronde-ini">Ronde ini: {d.hasil.filter((h: D) => h.sempurna).length} papan sempurna dari {d.hasil.length}</p>}
    </div>
  );
}

function Podium({ d }: { d: D }) {
  const [a, b, c] = d.juara as D[];
  const tiang = (k: D | undefined, tinggi: number, pos: number) => k && <div className={`tiang p${pos}`} style={{ ["--t" as string]: `${tinggi}%` }}><div className="juara"><b>{k.nama}</b><small>{k.total} poin</small></div><div className="blok"><span>{pos}</span></div></div>;
  return (
    <div className="adegan podium">
      <h1>Juara Tower Peek</h1>
      <div className="podium-row">{tiang(b, 62, 2)}{tiang(a, 90, 1)}{tiang(c, 46, 3)}</div>
      <div className="konfeti" aria-hidden>{Array.from({ length: 36 }, (_, i) => <u key={i} style={{ left: `${(i * 37) % 100}%`, animationDelay: `${(i % 9) * 0.3}s`, background: ["#f6c945", "#4cc9f0", "#f06fa8", "#35b36b"][i % 4] }} />)}</div>
    </div>
  );
}

export function Layar({ ringkas = false }: { ringkas?: boolean }) {
  const [sc, setSc] = useState<{ adegan: string; data: D } | null>(null);
  const [bel, setBel] = useState<D | null>(null);
  const [off, setOff] = useState(0);
  const [now, setNow] = useState(Date.now());
  const [suara, setS] = useState(suaraAktif());
  const [konek, setKonek] = useState(false);
  useEffect(() => {
    const s = sambung("/layar");
    s.on("connect", () => setKonek(true));
    s.on("disconnect", () => setKonek(false));
    s.on("scene:show", (m: { adegan: string; data: D }) => {
      setSc(m);
      if (m.data.serverNow) setOff(m.data.serverNow - Date.now());
    });
    s.on("timer:sync", (m: { serverNow: number }) => setOff(m.serverNow - Date.now()));
    s.on("bell:fx", (m: D) => {
      setBel(m);
      bunyiBel();
      setTimeout(() => setBel(null), 3800);
    });
    return () => void s.close();
  }, []);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now() + off), 100);
    return () => clearInterval(t);
  }, [off]);
  return (
    <div className={`layar ${ringkas ? "ringkas" : ""}`} data-adegan={sc?.adegan} data-testid="layar">
      {!sc ? <div className="adegan lobi"><div className="logo besar"><span>Tower</span><b>Peek</b></div><p>Menyambung…</p></div> : sc.adegan === "lobi" ? <Lobi d={sc.data} /> : sc.adegan === "aturan" ? <Aturan d={sc.data} /> : sc.adegan === "mundur" ? <Mundur d={sc.data} now={now} /> : sc.adegan === "live" ? <Live d={sc.data} now={now} /> : sc.adegan === "reveal" ? <Reveal d={sc.data} /> : sc.adegan === "skor" ? <Skor d={sc.data} /> : <Podium d={sc.data} />}
      {bel && <div className="bel-overlay" role="alert" data-testid="bel-fx"><div><span className="lonceng">TENG!</span><h1>{bel.nama} menekan bel</h1><p>Bel ke-{bel.urutan}{bel.sisaDetik !== null ? ` · sisa ${fmtWaktu(bel.sisaDetik * 1000)}` : ""}</p></div></div>}
      <button className="suara-tombol" onClick={() => { setSuara(!suara); setS(!suara); }} aria-pressed={suara}>{suara ? "Suara menyala" : "Nyalakan suara"}</button>
      {!konek && <div className="putus">Terputus dari server…</div>}
    </div>
  );
}
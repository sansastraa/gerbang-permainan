import react from "@vitejs/plugin-react";
import { defineConfig } from "vite";

const basePath = (() => {
  let s = (process.env.BASE_PATH ?? "").trim();
  if (!s || s === "/") return "/";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "") + "/";
})();

export default defineConfig({
  base: basePath,
  plugins: [react()],
  server: { port: 5120, proxy: { "/socket.io": { target: "http://localhost:3120", ws: true }, "/api": "http://localhost:3120" } },
  build: { outDir: "dist", sourcemap: false, chunkSizeWarningLimit: 900 },
});
// Sinkron jam meja ↔ server: dari N sampel ping, ambil offset dari sampel ber-RTT terkecil (NTP-ringan).
export interface SampelPing {
  t0: number; // waktu lokal kirim
  ts: number; // waktu server saat menjawab
  t1: number; // waktu lokal terima
}
export interface HasilSinkron {
  offset: number; // waktuServer ≈ waktuLokal + offset
  rtt: number;
}
export function estimasiOffset(sampel: readonly SampelPing[]): HasilSinkron | null {
  let best: HasilSinkron | null = null;
  for (const s of sampel) {
    const rtt = s.t1 - s.t0;
    if (rtt < 0) continue;
    const offset = s.ts - (s.t0 + rtt / 2);
    if (!best || rtt < best.rtt) best = { offset, rtt };
  }
  return best;
}

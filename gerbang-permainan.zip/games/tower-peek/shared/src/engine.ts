// Tower Peek — engine teka-teki (port TypeScript dari reference/puzzle.js; perilaku identik, seed sama = soal sama).
export type Side = "top" | "bottom" | "left" | "right";
export const SIDES: readonly Side[] = ["top", "bottom", "left", "right"];
export type Clues = Record<Side, number[]>;
export interface Puzzle {
  n: number;
  sol: number[];
  clues: Clues;
  givens: number[];
  code: string;
  varian?: number;
}

function hashStr(s: string): number {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}
function mulberry(a: number): () => number {
  return function () {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function rngFrom(code: string): () => number {
  return mulberry(hashStr(String(code)));
}
function shuffle<T>(a: T[], rng: () => number): T[] {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j]!, a[i]!];
  }
  return a;
}

const PERMS: Record<number, number[][]> = {};
function perms(n: number): number[][] {
  if (PERMS[n]) return PERMS[n];
  const res: number[][] = [];
  const a: number[] = [];
  for (let i = 1; i <= n; i++) a.push(i);
  (function rec(k: number) {
    if (k === n) {
      res.push(a.slice());
      return;
    }
    for (let i = k; i < n; i++) {
      [a[k], a[i]] = [a[i]!, a[k]!];
      rec(k + 1);
      [a[k], a[i]] = [a[i]!, a[k]!];
    }
  })(0);
  return (PERMS[n] = res);
}

/** Jumlah menara yang terlihat dalam satu garis (urutan dari pengintip). */
export function countVisible(vals: readonly number[]): number {
  let m = 0;
  let c = 0;
  for (const v of vals) {
    if (v > m) {
      m = v;
      c++;
    }
  }
  return c;
}
/** Urutan indeks petak yang dilihat pengintip, dari yang paling dekat. */
export function lineCells(n: number, side: Side, i: number): number[] {
  const a: number[] = [];
  for (let k = 0; k < n; k++) {
    if (side === "top") a.push(k * n + i);
    else if (side === "bottom") a.push((n - 1 - k) * n + i);
    else if (side === "left") a.push(i * n + k);
    else a.push(i * n + (n - 1 - k));
  }
  return a;
}
export function computeClues(n: number, g: readonly number[]): Clues {
  const cl = {} as Clues;
  for (const s of SIDES) {
    cl[s] = [];
    for (let i = 0; i < n; i++) cl[s].push(countVisible(lineCells(n, s, i).map((x) => g[x]!)));
  }
  return cl;
}

function latin(n: number, rng: () => number): number[] {
  const idx = () => Array.from({ length: n }, (_, i) => i);
  const rows = shuffle(idx(), rng);
  const cols = shuffle(idx(), rng);
  const sym = shuffle(
    idx().map((x) => x + 1),
    rng,
  );
  const g: number[] = [];
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) g.push(sym[(rows[r]! + cols[c]!) % n]!);
  for (let t = 0; t < n * 3; t++) {
    const a = Math.floor(rng() * n);
    const b = Math.floor(rng() * n);
    for (let r = 0; r < n; r++) {
      const x = g[r * n + a]!;
      g[r * n + a] = g[r * n + b]!;
      g[r * n + b] = x;
    }
  }
  return g;
}

/** Mencari hingga `limit` solusi (array datar). Petunjuk 0/kosong = tidak dibatasi. */
export function solve(n: number, clues: Clues, givens: readonly number[], limit = 2): number[][] {
  const cand: number[][][] = [];
  for (let r = 0; r < n; r++) {
    cand[r] = perms(n).filter((p) => {
      if (clues.left[r] && countVisible(p) !== clues.left[r]) return false;
      if (clues.right[r]) {
        let m = 0;
        let k = 0;
        for (let c = n - 1; c >= 0; c--)
          if (p[c]! > m) {
            m = p[c]!;
            k++;
          }
        if (k !== clues.right[r]) return false;
      }
      for (let c = 0; c < n; c++) {
        const gv = givens[r * n + c];
        if (gv && p[c] !== gv) return false;
      }
      return true;
    });
    if (!cand[r]!.length) return [];
  }
  const sols: number[][] = [];
  const colUsed: number[] = new Array<number>(n).fill(0);
  const colMax: number[] = new Array<number>(n).fill(0);
  const colVis: number[] = new Array<number>(n).fill(0);
  const rows: number[][] = [];
  function rec(r: number): void {
    if (sols.length >= limit) return;
    if (r === n) {
      for (let c = 0; c < n; c++) {
        if (clues.top[c] && colVis[c] !== clues.top[c]) return;
        if (clues.bottom[c]) {
          let m = 0;
          let k = 0;
          for (let rr = n - 1; rr >= 0; rr--) {
            const v = rows[rr]![c]!;
            if (v > m) {
              m = v;
              k++;
            }
          }
          if (k !== clues.bottom[c]) return;
        }
      }
      sols.push(([] as number[]).concat(...rows));
      return;
    }
    for (const p of cand[r]!) {
      let ok = true;
      for (let c = 0; c < n; c++)
        if (colUsed[c]! & (1 << p[c]!)) {
          ok = false;
          break;
        }
      if (!ok) continue;
      const sm = colMax.slice();
      const sv = colVis.slice();
      for (let c = 0; c < n && ok; c++) {
        if (p[c]! > colMax[c]!) {
          colMax[c] = p[c]!;
          colVis[c]!++;
        }
        const t = clues.top[c];
        if (t) {
          if (colVis[c]! > t) ok = false;
          else if (colMax[c] === n && colVis[c] !== t) ok = false;
          else if (colVis[c]! + (n - 1 - r) < t) ok = false;
        }
      }
      if (ok) {
        for (let c = 0; c < n; c++) colUsed[c]! |= 1 << p[c]!;
        rows.push(p);
        rec(r + 1);
        rows.pop();
        for (let c = 0; c < n; c++) colUsed[c]! &= ~(1 << p[c]!);
      }
      for (let c = 0; c < n; c++) {
        colMax[c] = sm[c]!;
        colVis[c] = sv[c]!;
      }
      if (sols.length >= limit) return;
    }
  }
  rec(0);
  return sols;
}

export function makePuzzle(n: number, givenCount: number, code: string): Puzzle {
  const rng = rngFrom(code);
  const sol = latin(n, rng);
  const clues = computeClues(n, sol);
  const givens: number[] = new Array<number>(n * n).fill(0);
  const order = shuffle(
    Array.from({ length: n * n }, (_, i) => i),
    rng,
  );
  for (let i = 0; i < Math.min(givenCount, n * n); i++) givens[order[i]!] = sol[order[i]!]!;
  let sols = solve(n, clues, givens, 2);
  let guard = 0;
  while (sols.length > 1 && guard++ < 60) {
    const diff: number[] = [];
    for (let i = 0; i < n * n; i++) if (sols[0]![i] !== sols[1]![i]) diff.push(i);
    const pick = diff[Math.floor(rng() * diff.length)]!;
    givens[pick] = sol[pick]!;
    sols = solve(n, clues, givens, 2);
  }
  return { n, sol, clues, givens, code };
}

/** Seed Simetri: k = 0..7 (4 rotasi × cermin). */
export function transformGrid(n: number, g: readonly number[], k: number): number[] {
  let cur = g.slice();
  const rot = k % 4;
  if (k >= 4) {
    const t: number[] = [];
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) t[r * n + c] = cur[r * n + (n - 1 - c)]!;
    cur = t;
  }
  for (let q = 0; q < rot; q++) {
    const t: number[] = [];
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) t[r * n + c] = cur[(n - 1 - c) * n + r]!;
    cur = t;
  }
  return cur;
}
export function variant(p: Puzzle, k: number): Puzzle {
  const n = p.n;
  const sol = transformGrid(n, p.sol, k);
  const givens = transformGrid(n, p.givens, k);
  return { n, sol, clues: computeClues(n, sol), givens, code: p.code, varian: k };
}
/** Banyaknya varian yang benar-benar berbeda untuk ukuran n (3×3 hanya 4). */
export const jumlahVarian = (n: number): number => (n <= 3 ? 4 : 8);

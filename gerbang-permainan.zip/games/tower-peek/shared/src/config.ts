// Bentuk config/tower_peek.config.json (semua angka dibaca server; tidak ada angka di-hardcode di logika).
export type ModeGame = "SD" | "CHAMPION";
export interface PoinSD {
  ketepatan_maks: number;
  nilai_sebagian: boolean;
  /** Poin maksimum untuk papan yang belum sempurna: sebagian_maks × tepat ÷ terbuka, dibulatkan ke atas (1 petak tepat = minimal 1 poin). */
  sebagian_maks: number;
  bonus_waktu_maks: number;
  bonus_bel: number[];
  biaya_bantuan: number;
}
export interface PoinChampion {
  peringkat_benar: number[];
  benar_tanpa_bel_pengali: number;
  /** Papan belum sempurna tetap dapat sebagian_maks × tepat ÷ terbuka (< poin terendah papan benar agar urutan tetap adil). */
  sebagian_maks: number;
  salah: number;
}
export interface ModeCfg<P> {
  warna_per_tinggi: boolean;
  /** Tombol "Periksa" (hanya format ARENA): server menyebut berapa petak sudah tepat; jumlahnya tampil di papan peringkat. */
  validasi: boolean;
  tandai_kembar: boolean;
  cek_angka_pengintip: boolean;
  bantuan_per_ronde: number;
  poin: P;
}
export interface TowerConfig {
  jumlah_meja_default: number;
  jumlah_meja_maks: number;
  /** Format ARENA (game biasa): 1–pemain_maks pemain, masuk dengan PIN sesi, perangkat sendiri. */
  arena: { pemain_maks: number; pin_digit: number; percobaan_pin_per_menit: number };
  mode: { SD: ModeCfg<PoinSD>; CHAMPION: ModeCfg<PoinChampion> };
  bel: { layar_tahan_ms: number; tombol_fisik: { aktif: boolean; tombol_keyboard: string; tekan_ganda_ms: number } };
  hitung_mundur_detik: number;
  peringatan_waktu_detik: number[];
  sinkron_waktu: { sampel_ping: number; interval_ulang_detik: number };
  seed_simetri: { aktif: boolean; catatan?: string };
  layar_siswa: { sorotan_detik: number; sensor_live: boolean; tampilkan_tinggi_live: boolean; urutan_reveal: string };
  anti_curang: { fokus_hilang_toleransi_ms: number; fokus_hilang_maks: number; papan_disembunyikan_sebelum_mulai: boolean };
  grafis_meja: { dpr_maks: number; bayangan: string; fps_minimum: number; fallback_2d: boolean };
}


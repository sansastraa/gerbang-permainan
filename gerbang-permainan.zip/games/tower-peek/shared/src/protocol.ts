// Skema payload (zod) dan tipe event. Semua masukan klien divalidasi di sini; tipe keluaran tidak pernah memuat solusi.
import { z } from "zod";
import type { Clues, Side } from "./engine";
import type { ModeGame } from "./config";

export const ModeSchema = z.enum(["SD", "CHAMPION"]);
/** KOMPETISI = meja jawab (≤16, bel, reveal oleh operator). ARENA = game biasa (≤40 pemain, PIN sesi, papan unik per pemain). */
export const FormatSchema = z.enum(["KOMPETISI", "ARENA"]);
export type FormatSesi = z.infer<typeof FormatSchema>;
export const JoinSchema = z.object({
  pin: z.string().regex(/^\d{4,8}$/),
  deviceId: z.string().min(4).max(80),
  pesertaId: z.string().max(64).optional(),
  nama: z.string().trim().min(1).max(30).optional(),
});

export const CreateSessionSchema = z.object({
  nama: z.string().trim().min(1).max(80),
  mode: ModeSchema.default("SD"),
  format: FormatSchema.default("KOMPETISI"),
  jumlahMeja: z.number().int().min(1).max(40).optional(),
  peserta: z
    .array(z.object({ id: z.string().min(1).max(64).optional(), nama: z.string().trim().min(1).max(60), kelas: z.string().max(20).optional(), avatar: z.string().max(8).optional() }))
    .max(64)
    .optional(),
});
export type CreateSession = z.infer<typeof CreateSessionSchema>;

export const ParticipantsSchema = z.object({
  peserta: z
    .array(z.object({ id: z.string().min(1).max(64).optional(), nama: z.string().trim().min(1).max(60), kelas: z.string().max(20).optional(), avatar: z.string().max(8).optional() }))
    .min(1)
    .max(64),
});
export const AssignSchema = z.object({ nomor: z.number().int().min(1).max(16), pesertaId: z.string().nullable() });
export const LoadRoundSchema = z.object({ sumber: z.enum(["paket", "seed"]).default("paket"), seed: z.string().max(40).optional() });

// --- klien → server (/meja)
export const DeskHelloSchema = z.object({ token: z.string().min(8).max(200), deviceId: z.string().min(4).max(80) });
export const ClockPingSchema = z.object({ t0: z.number() });
export const BoardSetSchema = z.object({ sel: z.number().int().min(0).max(35), tinggi: z.number().int().min(0).max(6), versi: z.number().int().min(0), sumber: z.enum(["tap", "kuas", "keyboard", "bantuan"]).default("tap"), tKlien: z.number().optional() });
export const PeekSchema = z.object({ sisi: z.enum(["top", "bottom", "left", "right"]), indeks: z.number().int().min(0).max(5) });
export const BellSchema = z.object({ tKlien: z.number().optional(), rtt: z.number().optional(), sumber: z.enum(["layar", "tombol"]).default("layar") });
export const FocusLostSchema = z.object({ durasiMs: z.number().min(0).max(3_600_000) });

// --- klien → server (/operator)
export const ExtendSchema = z.object({ detik: z.number().int().min(1).max(600) });
export const DeskRefSchema = z.object({ nomor: z.number().int().min(1).max(16) });
export const ScoreAdjustSchema = z.object({ nomor: z.number().int().min(1).max(16), delta: z.number().min(-1000).max(1000), alasan: z.string().trim().min(3).max(200) });

// --- server → klien
export type StatusRonde = "DRAFT" | "LOADED" | "BRIEFING" | "COUNTDOWN" | "LIVE" | "PAUSED" | "CLOSED" | "JUDGED" | "REVEAL" | "SCORED" | "ARCHIVED";
export type StatusMeja = "OFFLINE" | "READY" | "COUNTDOWN" | "PLAYING" | "BELL" | "TIMEOUT_LOCKED" | "REVEALED";

/** Isi `puzzle:deliver`: petunjuk + menara dipaku saja. TIDAK ADA solusi (dijaga tes otomatis). */
export interface PuzzleDeliver {
  rondeUrutan: number;
  n: number;
  petunjuk: Clues;
  dipaku: number[];
  waktuDetik: number;
  aturan: AturanMeja;
}
export interface AturanMeja {
  mode: ModeGame;
  warnaPerTinggi: boolean;
  tandaiKembar: boolean;
  cekAngkaPengintip: boolean;
  bantuanPerRonde: number;
}
export interface JadwalRonde {
  rondeUrutan: number;
  startAt: number;
  deadline: number;
  serverNow: number;
}
export const SIDES_ARR: readonly Side[] = ["top", "bottom", "left", "right"];
export type { ModeGame };



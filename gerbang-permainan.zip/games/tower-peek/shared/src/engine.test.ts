import { createRequire } from "node:module";
import { describe, expect, it } from "vitest";
import { fileURLToPath } from "node:url";
import fs from "node:fs";
import { computeClues, countVisible, jumlahVarian, lineCells, makePuzzle, solve, variant } from "./engine";

const require = createRequire(import.meta.url);
 
const REF = require("../reference/puzzle.cjs");
const paket = JSON.parse(
  fs.readFileSync(fileURLToPath(new URL("../../data/paket_soal.json", import.meta.url)), "utf8"),
) as { mode: Record<string, { ronde: { kode: string; n: number; jumlah_dipaku: number; petunjuk: Record<string, number[]>; dipaku: number[]; solusi: number[] }[] }> };

describe("engine TS identik dengan puzzle.cjs acuan", () => {
  for (const [n, k] of [[3, 1], [4, 3], [5, 4], [6, 6], [6, 0]] as const) {
    it(`makePuzzle ${n}x${n} dipaku=${k}: seed sama → soal sama`, () => {
      for (let i = 0; i < 8; i++) {
        const a = makePuzzle(n, k, `G${n}${k}-${i}`);
        const b = REF.makePuzzle(n, k, `G${n}${k}-${i}`);
        expect(a.sol).toEqual(b.sol);
        expect(a.givens).toEqual(b.givens);
        expect(a.clues).toEqual(b.clues);
        const s = solve(n, a.clues, a.givens, 2);
        expect(s).toHaveLength(1);
        expect(s[0]).toEqual(a.sol);
      }
    });
  }
  it("varian k=0..7 identik dengan acuan dan tetap berjawaban tunggal", () => {
    for (const n of [3, 4, 5, 6]) {
      const p = makePuzzle(n, n === 6 ? 0 : 3, "SYM" + n);
      const seen = new Set<string>();
      for (let k = 0; k < 8; k++) {
        const v = variant(p, k);
        expect(v.sol).toEqual(REF.variant(REF.makePuzzle(n, n === 6 ? 0 : 3, "SYM" + n), k).sol);
        const s = solve(n, v.clues, v.givens, 2);
        expect(s).toHaveLength(1);
        expect(s[0]).toEqual(v.sol);
        seen.add(v.sol.join());
      }
      expect(seen.size).toBe(jumlahVarian(n));
    }
  });
  it("countVisible & lineCells", () => {
    expect(countVisible([1, 2, 3])).toBe(3);
    expect(countVisible([3, 1, 2])).toBe(1);
    expect(lineCells(3, "bottom", 0)).toEqual([6, 3, 0]);
    expect(lineCells(3, "right", 1)).toEqual([5, 4, 3]);
  });
});

describe("paket soal resmi", () => {
  for (const [mode, m] of Object.entries(paket.mode))
    for (const r of m.ronde)
      it(`${r.kode}: solusi sah, petunjuk cocok, jawaban tunggal, menara dipaku sesuai`, () => {
        const clues = r.petunjuk as never;
        expect(computeClues(r.n, r.solusi)).toEqual(clues);
        const s = solve(r.n, clues, r.dipaku, 2);
        expect(s).toHaveLength(1);
        expect(s[0]).toEqual(r.solusi);
        expect(r.dipaku.filter(Boolean)).toHaveLength(r.jumlah_dipaku);
        expect(mode).toBeTruthy();
      });
});


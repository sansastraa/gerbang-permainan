# Referensi prototipe Meja Jawab

`meja_jawab_prototype.js` adalah draf single-file (three.js r128, tanpa framework) untuk interaksi papan 3D:
palet kuas tinggi, ketuk bertumpuk, kamera orbit, tombol putar/tampak atas, **Mata Pengintip** (kamera terbang ke
posisi pengintip, menara terlihat menyala), bel dengan konfirmasi, skor Mode SD, dan kode soal.

Status: sintaksis valid, **belum diuji di browser**. Gunakan sebagai referensi ide saat membangun
`apps/web/src/meja` dengan React Three Fiber. Fungsi teka-teki yang dipanggilnya ada di `engine/puzzle.js`.

(function () {
'use strict';
const $ = s => document.querySelector(s);
const HC = [null, '#F6C945', '#F28C38', '#E4505B', '#8E5BD1', '#3FA66B', '#FF7FB0'];
const WOOD = '#D9B27C';
const FH = 0.44, TW = 0.8;
const SIDE_NAME = { top: 'utara', bottom: 'selatan', left: 'barat', right: 'timur' };
const LINE_NAME = { top: 'kolom', bottom: 'kolom', left: 'baris', right: 'baris' };

// ---------- penyimpanan per-perangkat ----------
function store(k, v) { try { if (v === undefined) return JSON.parse(localStorage.getItem('towerpeek.' + k)); localStorage.setItem('towerpeek.' + k, JSON.stringify(v)); } catch (e) { return null; } }
const reduceMQ = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
const settings = Object.assign({ color: true, dupes: true, clueCheck: true, labels: false, sound: true, reduce: reduceMQ.matches }, store('settings') || {});

// ---------- konfigurasi ----------
const TOUR = [
  { n: 3, givens: 1, time: 180 },
  { n: 4, givens: 5, time: 300 },
  { n: 5, givens: 8, time: 480 },
  { n: 6, givens: 12, time: 600 },
  { n: 6, givens: 10, time: 720 },
];
function freeCfg(n, lvl) {
  const givens = lvl === 'A' ? Math.round(n * n * 0.35) : lvl === 'B' ? Math.round(n * n * 0.15) : 0;
  const time = { 3: [180, 180, 120], 4: [300, 300, 180], 5: [480, 480, 360], 6: [720, 720, 600] }[n]['ABC'.indexOf(lvl)];
  return { n, givens, time };
}
const BASE_PTS = { 3: 100, 4: 200, 5: 300, 6: 500 };

// ---------- state ----------
const S = {
  mode: 'menu', cfg: null, p: null, n: 4, grid: [], locked: false, sel: -1, brush: 0,
  hints: 0, hintCells: new Set(), timeLeft: 0, timeTotal: 0, running: false,
  tourCode: '', round: 0, results: [], peek: null, solved: false,
};

// ---------- audio kecil ----------
let AC = null;
function tone(f, d = 0.09, type = 'triangle', vol = 0.12, when = 0) {
  if (!settings.sound) return;
  try {
    AC = AC || new (window.AudioContext || window.webkitAudioContext)();
    const t = AC.currentTime + when, o = AC.createOscillator(), g = AC.createGain();
    o.type = type; o.frequency.value = f; g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0001, t + d);
    o.connect(g); g.connect(AC.destination); o.start(t); o.stop(t + d + 0.02);
  } catch (e) { }
}
const sfx = {
  place: h => tone(300 + h * 70, 0.08),
  erase: () => tone(220, 0.07, 'sine'),
  bad: () => tone(160, 0.18, 'square', 0.06),
  bell: () => { tone(1320, 0.9, 'sine', 0.18); tone(1980, 0.6, 'sine', 0.06); },
  win: () => [523, 659, 784, 1046].forEach((f, i) => tone(f, 0.18, 'triangle', 0.12, i * 0.11)),
  peek: () => tone(880, 0.1, 'sine', 0.08),
};

// ---------- toast ----------
let toastT = 0;
function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('show'); clearTimeout(toastT); toastT = setTimeout(() => t.classList.remove('show'), 2200); }

// ---------- THREE ----------
if (typeof THREE === 'undefined') {
  $('#stage').innerHTML = '<div class="nogl"><div><h2>Mesin 3D belum termuat</h2><p>Periksa koneksi lalu muat ulang halaman.</p></div></div>';
}
const stageEl = $('#stage');
const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
renderer.outputEncoding = THREE.sRGBEncoding;
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFSoftShadowMap;
renderer.domElement.tabIndex = 0;
renderer.domElement.setAttribute('aria-label', 'Papan 3D. Gunakan tombol panah dan angka untuk mengisi menara.');
stageEl.appendChild(renderer.domElement);
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(40, 1, 0.1, 200);
scene.add(new THREE.HemisphereLight(0xffffff, 0x5a6fa8, 0.8));
const sun = new THREE.DirectionalLight(0xffffff, 0.75);
sun.position.set(-5, 12, 7); sun.castShadow = true; sun.shadow.mapSize.set(1024, 1024); sun.shadow.bias = -0.0005;
scene.add(sun); scene.add(sun.target);
const world = new THREE.Group(); scene.add(world);

const lin = hex => new THREE.Color(hex).convertSRGBToLinear();
function shade(hex, amt) { const c = new THREE.Color(hex), h = {}; c.getHSL(h); c.setHSL(h.h, h.s, Math.max(0, Math.min(1, h.l + amt))); return '#' + c.getHexString(); }

const texCache = {};
function arch(x, l, t, w, h) { x.beginPath(); x.moveTo(l, t + h); x.lineTo(l, t + w / 2); x.arc(l + w / 2, t + w / 2, w / 2, Math.PI, 0); x.lineTo(l + w, t + h); x.closePath(); x.fill(); }
function floorTex(color) {
  if (texCache[color]) return texCache[color];
  const cv = document.createElement('canvas'); cv.width = cv.height = 128; const x = cv.getContext('2d');
  x.fillStyle = color; x.fillRect(0, 0, 128, 128);
  x.fillStyle = shade(color, 0.1); x.fillRect(0, 0, 128, 8);
  x.fillStyle = shade(color, -0.14); x.fillRect(0, 114, 128, 14);
  x.fillStyle = shade(color, -0.42);
  arch(x, 16, 34, 22, 60); arch(x, 53, 26, 22, 68); arch(x, 90, 34, 22, 60);
  x.fillStyle = 'rgba(255,255,255,.35)';
  x.fillRect(19, 48, 3, 30); x.fillRect(56, 40, 3, 36); x.fillRect(93, 48, 3, 30);
  const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding; t.anisotropy = 4;
  return (texCache[color] = t);
}
const spriteCache = {};
function numSprite(text, kind) {
  const key = text + '|' + kind;
  if (!spriteCache[key]) {
    const cv = document.createElement('canvas'); cv.width = cv.height = 128; const x = cv.getContext('2d');
    const pal = { clue: ['#FFFFFF', '#14254A', '#14254A'], good: ['#2FB36A', '#FFFFFF', '#14532F'], bad: ['#E4505B', '#FFFFFF', '#7A1620'], peek: ['#5FD3FF', '#0B2A45', '#0B2A45'], tag: ['#14254A', '#FFFFFF', '#FFFFFF'], north: ['#F28C38', '#2A1300', '#2A1300'] }[kind];
    x.beginPath(); x.arc(64, 64, 56, 0, Math.PI * 2); x.fillStyle = pal[0]; x.fill();
    x.lineWidth = 8; x.strokeStyle = pal[2]; x.stroke();
    x.fillStyle = pal[1]; x.font = '800 74px "Baloo 2", "Trebuchet MS", sans-serif'; x.textAlign = 'center'; x.textBaseline = 'middle';
    x.fillText(text, 64, 70);
    const t = new THREE.CanvasTexture(cv); t.encoding = THREE.sRGBEncoding;
    spriteCache[key] = new THREE.SpriteMaterial({ map: t, depthTest: true, transparent: true });
  }
  return spriteCache[key];
}

const floorGeo = new THREE.BoxGeometry(TW, FH * 0.94, TW);
const roofGeo = new THREE.ConeGeometry(0.585, 0.34, 4); roofGeo.rotateY(Math.PI / 4);
const tileGeo = new THREE.PlaneGeometry(0.94, 0.94); tileGeo.rotateX(-Math.PI / 2);
const plateGeo = new THREE.CylinderGeometry(0.3, 0.3, 0.06, 3);
const pinGeo = new THREE.BoxGeometry(0.94, 0.05, 0.94);
const goldMat = new THREE.MeshStandardMaterial({ color: lin('#F5C542'), metalness: 0.5, roughness: 0.35 });
const hintMat = new THREE.MeshStandardMaterial({ color: lin('#5FD3FF'), metalness: 0.3, roughness: 0.4 });

let board = null, tiles = [], towers = [], clueObjs = [], pickables = [];
const tileCol = { base: lin('#3A6DBA'), sel: lin('#F28C38'), hover: lin('#5585D0'), line: lin('#4F9BE0') };

function cellPos(idx) { const n = S.n, e = (n - 1) / 2; return new THREE.Vector3((idx % n) - e, 0, Math.floor(idx / n) - e); }

function clearBoard() {
  if (board) world.remove(board);
  towers.forEach(t => t && world.remove(t));
  board = null; tiles = []; towers = []; clueObjs = []; pickables = [];
}
function buildBoard() {
  clearBoard();
  const n = S.n, e = (n - 1) / 2;
  board = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(n + 2.7, 0.36, n + 2.7), new THREE.MeshStandardMaterial({ color: lin('#2C5AA0'), roughness: 0.9 }));
  base.position.y = -0.18; base.receiveShadow = true; board.add(base);
  const inner = new THREE.Mesh(new THREE.BoxGeometry(n + 0.16, 0.02, n + 0.16), new THREE.MeshStandardMaterial({ color: lin('#1D437F'), roughness: 0.9 }));
  inner.position.y = 0.0; inner.receiveShadow = true; board.add(inner);
  for (let i = 0; i < n * n; i++) {
    const m = new THREE.Mesh(tileGeo, new THREE.MeshStandardMaterial({ color: tileCol.base.clone(), roughness: 0.85 }));
    const p = cellPos(i); m.position.set(p.x, 0.014, p.z); m.receiveShadow = true; m.userData.cell = i;
    board.add(m); tiles.push(m); pickables.push(m);
  }
  // pelat & angka pengintip
  const rotY = { top: 0, bottom: Math.PI, left: Math.PI / 2, right: -Math.PI / 2 };
  for (const side of SIDES) for (let i = 0; i < n; i++) {
    const v = S.p.clues[side][i];
    const off = e + 1.0, pos = new THREE.Vector3();
    if (side === 'top') pos.set(i - e, 0, -off); else if (side === 'bottom') pos.set(i - e, 0, off);
    else if (side === 'left') pos.set(-off, 0, i - e); else pos.set(off, 0, i - e);
    const plate = new THREE.Mesh(plateGeo, new THREE.MeshStandardMaterial({ color: lin('#F28C38'), roughness: 0.5, emissive: lin('#3a1a00'), emissiveIntensity: 0.3 }));
    plate.position.set(pos.x, 0.04, pos.z); plate.rotation.y = rotY[side]; plate.castShadow = true;
    const sp = new THREE.Sprite(numSprite(String(v), 'clue'));
    sp.position.set(pos.x, 0.62, pos.z); sp.scale.set(0.62, 0.62, 0.62);
    plate.userData.clue = sp.userData.clue = { side, i };
    board.add(plate); board.add(sp);
    clueObjs.push({ side, i, v, plate, sp, status: 'clue' });
    pickables.push(plate, sp);
  }
  const north = new THREE.Sprite(numSprite('U', 'north')); north.position.set(0, 0.45, -(e + 1.95)); north.scale.set(0.5, 0.5, 0.5); board.add(north);
  world.add(board);
  const r = n + 2;
  Object.assign(sun.shadow.camera, { left: -r, right: r, top: r, bottom: -r, near: 1, far: 40 }); sun.shadow.camera.updateProjectionMatrix();
  towers = new Array(n * n).fill(null);
  for (let i = 0; i < n * n; i++) if (S.grid[i]) buildTower(i, false);
  updateAll();
}

function buildTower(idx, animate) {
  if (towers[idx]) { world.remove(towers[idx]); towers[idx] = null; }
  pickables = pickables.filter(o => !(o.userData.tower && o.userData.cell === idx));
  const h = S.grid[idx]; if (!h) return;
  const color = settings.color ? HC[h] : WOOD;
  const side = new THREE.MeshStandardMaterial({ map: floorTex(color), roughness: 0.8, emissive: new THREE.Color(0), emissiveIntensity: 0 });
  const top = new THREE.MeshStandardMaterial({ color: lin(shade(color, 0.06)), roughness: 0.85, emissive: new THREE.Color(0), emissiveIntensity: 0 });
  const roof = new THREE.MeshStandardMaterial({ color: lin(shade(color, -0.2)), roughness: 0.6, emissive: new THREE.Color(0), emissiveIntensity: 0 });
  const mats = [side, top, roof];
  const g = new THREE.Group();
  for (let f = 0; f < h; f++) {
    const m = new THREE.Mesh(floorGeo, [side, side, top, top, side, side]);
    m.position.y = FH * f + FH / 2; m.castShadow = m.receiveShadow = true; m.userData = { cell: idx, tower: true };
    g.add(m); pickables.push(m);
  }
  const rf = new THREE.Mesh(roofGeo, roof); rf.position.y = FH * h + 0.17; rf.castShadow = true; rf.userData = { cell: idx, tower: true }; g.add(rf); pickables.push(rf);
  const fixed = S.p.givens[idx] || S.hintCells.has(idx);
  if (fixed) { const pin = new THREE.Mesh(pinGeo, S.hintCells.has(idx) ? hintMat : goldMat); pin.position.y = 0.035; g.add(pin); }
  if (settings.labels || S.topView) { const sp = new THREE.Sprite(numSprite(String(h), 'tag')); sp.position.y = FH * h + 0.62; sp.scale.set(0.42, 0.42, 0.42); g.add(sp); }
  const p = cellPos(idx); g.position.set(p.x, 0.02, p.z);
  g.userData = { idx, mats };
  world.add(g); towers[idx] = g;
  if (animate && !settings.reduce) { g.scale.set(1, 0.001, 1); tween(360, k => g.scale.set(1, Math.max(0.001, easeOutBack(k)), 1)); }
}
function rebuildTowers() { for (let i = 0; i < S.n * S.n; i++) buildTower(i, false); updateAll(); }

// ---------- animasi ----------
const anims = [];
function tween(dur, fn, done, delay = 0) { anims.push({ t0: performance.now() + delay, dur, fn, done }); }
const easeOut = k => 1 - Math.pow(1 - k, 3);
const easeIO = k => k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
function easeOutBack(k) { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); }
function shake(idx) {
  const g = towers[idx]; if (!g || settings.reduce) return; const x0 = g.position.x;
  tween(420, k => { g.position.x = x0 + Math.sin(k * Math.PI * 6) * 0.06 * (1 - k); }, () => { g.position.x = x0; });
}

// ---------- kamera ----------
const cam = { yaw: 0, pitch: 0.92, dist: 10, target: new THREE.Vector3(0, 0.5, 0) };
const look = new THREE.Vector3(0, 0.5, 0);
let camMode = 'orbit', camTw = null;
function orbitPos(o = cam) { return new THREE.Vector3(o.target.x + o.dist * Math.cos(o.pitch) * Math.sin(o.yaw), o.target.y + o.dist * Math.sin(o.pitch), o.target.z + o.dist * Math.cos(o.pitch) * Math.cos(o.yaw)); }
function defaultDist() { const a = camera.aspect; return (S.n * 1.55 + 5.2) * (a < 0.8 ? 1.45 : a < 1.1 ? 1.15 : 1); }
function applyOrbit() { if (camMode !== 'orbit' || camTw) return; camera.position.copy(orbitPos()); look.copy(cam.target); camera.lookAt(look); }
function flyTo(pos, lk, dur, after) {
  const p0 = camera.position.clone(), l0 = look.clone();
  if (settings.reduce) dur = 1;
  camTw = true;
  tween(dur, k => { const e = easeIO(k); camera.position.lerpVectors(p0, pos, e); look.lerpVectors(l0, lk, e); camera.lookAt(look); }, () => { camTw = null; after && after(); });
}
function tweenOrbit(to, dur = 500) {
  const from = { yaw: cam.yaw, pitch: cam.pitch, dist: cam.dist };
  if (settings.reduce) dur = 1;
  tween(dur, k => { const e = easeIO(k); cam.yaw = from.yaw + (to.yaw - from.yaw) * e; cam.pitch = from.pitch + (to.pitch - from.pitch) * e; cam.dist = from.dist + (to.dist - from.dist) * e; applyOrbit(); });
}
function resetCam(instant) {
  const to = { yaw: 0, pitch: 0.92, dist: defaultDist() };
  S.topView = false;
  if (instant) { Object.assign(cam, to); applyOrbit(); } else tweenOrbit(to);
}
function resize() {
  const w = stageEl.clientWidth || window.innerWidth, h = stageEl.clientHeight || window.innerHeight;
  renderer.setSize(w, h, false); camera.aspect = w / h; camera.updateProjectionMatrix();
  if (camMode === 'orbit') { cam.dist = Math.max(cam.dist, defaultDist() * 0.6); applyOrbit(); }
}
window.addEventListener('resize', resize);

// ---------- mata pengintip ----------
function enterPeek(side, i) {
  if (S.mode === 'menu') return;
  sfx.peek();
  const n = S.n, cells = lineCells(n, side, i);
  const p0 = cellPos(cells[0]), pL = cellPos(cells[n - 1]);
  const dir = pL.clone().sub(p0).normalize();
  const eye = p0.clone().addScaledVector(dir, -2.05); eye.y = 0.55;
  const lk = pL.clone().addScaledVector(dir, 0.6); lk.y = 0.95;
  camMode = 'peek'; S.peek = { side, i };
  flyTo(eye, lk, 750);
  updateAll();
}
function exitPeek() {
  if (!S.peek) return;
  S.peek = null; camMode = 'orbit';
  flyTo(orbitPos(), cam.target.clone(), 650);
  updateAll();
}

// ---------- validasi & tampilan ----------
function lineVals(side, i) { return lineCells(S.n, side, i).map(x => S.grid[x]); }
function dupes() {
  const n = S.n, bad = new Set();
  for (let r = 0; r < n; r++) for (let a = 0; a < n; a++) for (let b = a + 1; b < n; b++) {
    const ia = r * n + a, ib = r * n + b; if (S.grid[ia] && S.grid[ia] === S.grid[ib]) { bad.add(ia); bad.add(ib); }
    const ja = a * n + r, jb = b * n + r; if (S.grid[ja] && S.grid[ja] === S.grid[jb]) { bad.add(ja); bad.add(jb); }
  }
  return bad;
}
function clueStatus(side, i) {
  const vals = lineVals(side, i), v = S.p.clues[side][i];
  if (vals.some(x => !x)) return 'clue';
  return countVisible(vals) === v ? 'good' : 'bad';
}
function updateAll() {
  if (!S.p) return;
  const n = S.n, bad = (settings.dupes && !S.locked) ? dupes() : new Set();
  // petak
  const peekCells = S.peek ? new Set(lineCells(n, S.peek.side, S.peek.i)) : null;
  tiles.forEach((t, i) => {
    let c = tileCol.base;
    if (peekCells && peekCells.has(i)) c = tileCol.line;
    else if (i === S.sel && !S.locked) c = tileCol.sel;
    else if (i === S.hover && !S.locked) c = tileCol.hover;
    t.material.color.copy(c);
  });
  // menara: konflik / pengintip
  let visibleSet = null;
  if (S.peek) {
    visibleSet = new Set(); let m = 0;
    for (const idx of lineCells(n, S.peek.side, S.peek.i)) { const h = S.grid[idx]; if (h > m) { m = h; visibleSet.add(idx); } }
  }
  towers.forEach((g, i) => {
    if (!g) return;
    const [side, top, roof] = g.userData.mats;
    let em = 0x000000, ei = 0, op = 1;
    if (S.peek) {
      if (visibleSet.has(i)) { em = 0x2bb6e8; ei = 0.55; }
      else if (peekCells.has(i)) { op = 0.45; }
      else op = 0.14;
    } else if (S.resultMap) {
      if (S.resultMap[i] === false) { em = 0xe4505b; ei = 0.6; }
    } else if (bad.has(i)) { em = 0xe4505b; ei = 0.55; }
    else if (i === S.sel && !S.locked) { em = 0xf28c38; ei = 0.18; }
    for (const m of [side, top, roof]) { m.emissive.setHex(em); m.emissiveIntensity = ei; m.transparent = op < 1; m.opacity = op; m.depthWrite = op >= 1; }
    g.children.forEach(ch => { if (ch.isMesh) ch.castShadow = op >= 1; if (ch.isSprite) ch.visible = op >= 1; });
  });
  // angka pengintip
  const showCheck = settings.clueCheck && S.mode !== 'tour' || S.locked;
  clueObjs.forEach(o => {
    let st = 'clue';
    if (S.peek && S.peek.side === o.side && S.peek.i === o.i) st = 'peek';
    else if (showCheck) st = clueStatus(o.side, o.i);
    if (st !== o.status) { o.sp.material = numSprite(String(o.v), st); o.status = st; }
    o.sp.visible = !S.peek || (S.peek.side === o.side && S.peek.i === o.i);
  });
  // banner pengintip
  const pk = $('#peek');
  if (S.peek) {
    const { side, i } = S.peek, vals = lineVals(side, i), seen = countVisible(vals), target = S.p.clues[side][i], full = vals.every(Boolean);
    $('#peekT1').textContent = `Pengintip ${SIDE_NAME[side]}, ${LINE_NAME[side]} ${i + 1}`;
    let msg = `Terlihat <b>${seen}</b> menara. Target: <b>${target}</b>.`;
    if (!full) msg += ' Barisnya belum penuh.'; else msg += seen === target ? ' Pas! ✅' : ' Belum pas.';
    $('#peekT2').innerHTML = msg;
    pk.classList.toggle('ok', full && seen === target);
    pk.classList.toggle('no', full && seen !== target && (settings.clueCheck || S.mode !== 'tour'));
    pk.hidden = false;
  } else pk.hidden = true;
  renderPalette();
}

// ---------- palet ----------
function renderPalette() {
  const el = $('#palette'), n = S.n;
  const cnt = new Array(n + 1).fill(0); S.grid.forEach(v => cnt[v]++);
  let html = '';
  for (let h = 1; h <= n; h++) {
    const left = n - cnt[h];
    const col = settings.color ? HC[h] : WOOD;
    let stack = ''; for (let k = 0; k < h; k++) stack += `<i style="background:${col}"></i>`;
    html += `<button class="pk${S.brush === h ? ' on' : ''}${left <= 0 ? ' done' : ''}" data-h="${h}" aria-pressed="${S.brush === h}" aria-label="Tinggi ${h}, sisa ${left}"><div class="stack">${stack}</div><div class="n">${h}</div><div class="left">sisa ${left}</div></button>`;
  }
  html += `<button class="pk erase${S.brush === -1 ? ' on' : ''}" data-h="-1" aria-pressed="${S.brush === -1}" aria-label="Hapus menara"><div class="stack">🧽</div><div class="n">0</div><div class="left">hapus</div></button>`;
  if (el.innerHTML !== html) el.innerHTML = html;
  const dis = S.locked || S.mode === 'menu';
  el.querySelectorAll('button').forEach(b => b.disabled = dis);
  $('#btnBell').disabled = dis;
  $('#btnHint').disabled = dis || (S.mode === 'tour' && S.hints >= 1);
  $('#btnHint').textContent = S.mode === 'tour' ? `💡 Bantuan (${Math.max(0, 1 - S.hints)})` : '💡 Bantuan';
}
$('#palette').addEventListener('click', e => {
  const b = e.target.closest('.pk'); if (!b || S.locked) return;
  const h = +b.dataset.h;
  S.brush = S.brush === h ? 0 : h;
  if (S.sel >= 0 && S.brush !== 0) setCell(S.sel, S.brush === -1 ? 0 : S.brush);
  renderPalette();
});

// ---------- aksi petak ----------
function isFixed(i) { return !!S.p.givens[i] || S.hintCells.has(i); }
function setCell(i, h) {
  if (S.locked) return;
  if (isFixed(i)) { toast('Menara ini sudah dipaku 📌'); sfx.bad(); return; }
  if (h > S.n) h = 0;
  if (S.grid[i] === h) return;
  S.grid[i] = h; buildTower(i, true);
  if (h) sfx.place(h); else sfx.erase();
  const bad = dupes();
  if (h && settings.dupes && bad.has(i)) { shake(i); sfx.bad(); toast(`Ada menara ${h} lantai kembar di baris atau kolom ini`); }
  updateAll();
  if (S.mode === 'free' && !S.solved && S.grid.every((v, k) => v === S.p.sol[k])) { S.solved = true; finishRound(true); }
}
function tapCell(i) {
  if (S.locked || S.mode === 'menu') return;
  S.sel = i;
  if (S.brush === -1) setCell(i, 0);
  else if (S.brush > 0) setCell(i, S.brush);
  else if (!isFixed(i)) setCell(i, (S.grid[i] + 1) % (S.n + 1));
  else toast('Menara ini sudah dipaku 📌');
  updateAll();
}

// ---------- input pointer ----------
const canvas = renderer.domElement;
const ray = new THREE.Raycaster(); ray.camera = camera;
const ndc = new THREE.Vector2();
function pick(cx, cy) {
  const r = canvas.getBoundingClientRect();
  ndc.set(((cx - r.left) / r.width) * 2 - 1, -((cy - r.top) / r.height) * 2 + 1);
  ray.setFromCamera(ndc, camera); ray.camera = camera;
  const hits = ray.intersectObjects(pickables, false);
  for (const h of hits) { if (!h.object.visible) continue; if (h.object.userData.clue || h.object.userData.cell !== undefined) return h.object.userData; }
  return null;
}
const ptrs = new Map(); let downAt = null, dragging = false, pinch0 = 0, dist0 = 0;
const pdist = () => { const a = [...ptrs.values()]; return Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y); };
canvas.addEventListener('pointerdown', e => {
  canvas.setPointerCapture && canvas.setPointerCapture(e.pointerId);
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (ptrs.size === 1) { downAt = { x: e.clientX, y: e.clientY }; dragging = false; }
  else if (ptrs.size === 2) { pinch0 = pdist(); dist0 = cam.dist; dragging = true; }
});
canvas.addEventListener('pointermove', e => {
  if (!ptrs.has(e.pointerId)) {
    if (e.pointerType === 'mouse' && camMode === 'orbit' && S.mode !== 'menu') { const u = pick(e.clientX, e.clientY); const hv = u && u.cell !== undefined ? u.cell : -1; if (hv !== S.hover) { S.hover = hv; updateAll(); } canvas.style.cursor = u ? 'pointer' : 'grab'; }
    return;
  }
  const prev = ptrs.get(e.pointerId); const dx = e.clientX - prev.x, dy = e.clientY - prev.y;
  ptrs.set(e.pointerId, { x: e.clientX, y: e.clientY });
  if (camMode !== 'orbit') return;
  if (ptrs.size === 1) {
    if (!dragging && Math.hypot(e.clientX - downAt.x, e.clientY - downAt.y) > 7) dragging = true;
    if (dragging) { cam.yaw -= dx * 0.008; cam.pitch = Math.min(1.5, Math.max(0.28, cam.pitch + dy * 0.006)); S.topView = false; applyOrbit(); }
  } else if (ptrs.size === 2) {
    const d = pdist(); if (pinch0 > 0) { cam.dist = Math.min(defaultDist() * 1.8, Math.max(defaultDist() * 0.5, dist0 * pinch0 / d)); applyOrbit(); }
  }
});
function endPtr(e) {
  if (!ptrs.has(e.pointerId)) return;
  const single = ptrs.size === 1;
  ptrs.delete(e.pointerId);
  if (single && !dragging && e.type === 'pointerup') {
    const u = pick(e.clientX, e.clientY);
    if (u && u.clue) { if (S.peek && S.peek.side === u.clue.side && S.peek.i === u.clue.i) exitPeek(); else enterPeek(u.clue.side, u.clue.i); }
    else if (u && u.cell !== undefined && camMode === 'orbit') tapCell(u.cell);
  }
  if (ptrs.size === 0) dragging = false;
}
canvas.addEventListener('pointerup', endPtr);
canvas.addEventListener('pointercancel', endPtr);
canvas.addEventListener('wheel', e => { e.preventDefault(); if (camMode !== 'orbit') return; cam.dist = Math.min(defaultDist() * 1.8, Math.max(defaultDist() * 0.5, cam.dist * (1 + Math.sign(e.deltaY) * 0.08))); applyOrbit(); }, { passive: false });

// ---------- keyboard ----------
window.addEventListener('keydown', e => {
  if (S.mode === 'menu' || document.querySelector('.ov:not([hidden])')) { if (e.key === 'Escape') closeTopOverlay(); return; }
  if (e.key === 'Escape') { if (S.peek) exitPeek(); return; }
  if (S.locked) return;
  const n = S.n; let s = S.sel < 0 ? 0 : S.sel;
  const mv = { ArrowLeft: [-1, 0], ArrowRight: [1, 0], ArrowUp: [0, -1], ArrowDown: [0, 1] }[e.key];
  if (mv) { e.preventDefault(); const c = Math.min(n - 1, Math.max(0, (s % n) + mv[0])), r = Math.min(n - 1, Math.max(0, Math.floor(s / n) + mv[1])); S.sel = r * n + c; updateAll(); return; }
  if (/^[0-9]$/.test(e.key) && S.sel >= 0) { const v = +e.key; if (v <= n) setCell(S.sel, v); }
  if (e.key === 'Backspace' || e.key === 'Delete') { if (S.sel >= 0) setCell(S.sel, 0); }
});

// ---------- tombol kamera ----------
$('#camL').onclick = () => { if (S.peek) exitPeek(); S.topView = false; tweenOrbit({ yaw: cam.yaw + Math.PI / 2, pitch: cam.pitch, dist: cam.dist }); };
$('#camR').onclick = () => { if (S.peek) exitPeek(); S.topView = false; tweenOrbit({ yaw: cam.yaw - Math.PI / 2, pitch: cam.pitch, dist: cam.dist }); };
$('#camTop').onclick = () => {
  if (S.peek) exitPeek();
  S.topView = !S.topView;
  const snap = Math.round(cam.yaw / (Math.PI / 2)) * (Math.PI / 2);
  tweenOrbit(S.topView ? { yaw: snap, pitch: 1.5, dist: defaultDist() * 0.95 } : { yaw: snap, pitch: 0.92, dist: defaultDist() });
  rebuildTowers();
};
$('#camReset').onclick = () => { if (S.peek) exitPeek(); resetCam(); rebuildTowers(); };
$('#peekBack').onclick = exitPeek;

// ---------- timer & loop ----------
let lastSec = -1, lastT = performance.now();
function fmt(s) { s = Math.max(0, Math.ceil(s)); return String(Math.floor(s / 60)).padStart(2, '0') + ':' + String(s % 60).padStart(2, '0'); }
function loop(now) {
  const dt = (now - lastT) / 1000; lastT = now;
  for (let i = anims.length - 1; i >= 0; i--) {
    const a = anims[i]; if (now < a.t0) continue;
    const k = Math.min(1, (now - a.t0) / a.dur); a.fn(k);
    if (k >= 1) { anims.splice(i, 1); a.done && a.done(); }
  }
  if (S.mode === 'menu' && camMode === 'orbit' && !camTw && !settings.reduce) { cam.yaw += dt * 0.15; applyOrbit(); }
  if (S.running) {
    S.timeLeft -= dt;
    const sec = Math.ceil(S.timeLeft);
    if (sec !== lastSec) {
      lastSec = sec; const t = $('#timer'); t.textContent = fmt(S.timeLeft);
      t.classList.toggle('warn', S.timeLeft <= 30); t.classList.toggle('pulse', S.timeLeft <= 10);
      if (S.timeLeft <= 5 && S.timeLeft > 0) tone(660, 0.05, 'sine', 0.06);
    }
    if (S.timeLeft <= 0) { S.running = false; toast('Waktu habis! Jawaban dikunci.'); lockAndScore(true); }
  }
  renderer.render(scene, camera);
  requestAnimationFrame(loop);
}

// ---------- alur permainan ----------
function startPuzzle(cfg, code, label) {
  S.cfg = cfg; S.n = cfg.n;
  S.p = makePuzzle(cfg.n, cfg.givens, code);
  S.grid = S.p.givens.slice(); S.locked = false; S.sel = -1; S.brush = 0; S.hints = 0; S.hintCells = new Set();
  S.timeLeft = S.timeTotal = cfg.time; S.running = true; S.peek = null; S.resultMap = null; S.solved = false; S.hover = -1;
  camMode = 'orbit'; camTw = null; lastSec = -1;
  $('#roundLabel').textContent = label;
  $('#codeLabel').textContent = 'Kode ' + (S.mode === 'tour' ? S.tourCode : code);
  $('#timer').textContent = fmt(cfg.time);
  buildBoard(); resetCam(true);
  if (!settings.reduce) { cam.dist = defaultDist() * 1.6; cam.yaw = -0.6; applyOrbit(); tweenOrbit({ yaw: 0, pitch: 0.92, dist: defaultDist() }, 900); }
  hideAll();
}
function startTour(code) {
  S.mode = 'tour'; S.tourCode = code || ('T-' + randCode()); S.round = 0; S.results = [];
  startRound();
}
function startRound() {
  const cfg = TOUR[S.round];
  startPuzzle(cfg, S.tourCode + '#' + S.round, `Ronde ${S.round + 1} dari 5, kota ${cfg.n} × ${cfg.n}`);
  toast(S.round === 0 ? 'Ronde 1: pemanasan di kota 3 × 3!' : `Ronde ${S.round + 1} dimulai!`);
}
function startFree(n, lvl, seed) {
  S.mode = 'free';
  const code = `${n}${lvl}-${seed || randCode()}`;
  const names = { A: 'banyak bantuan', B: 'sedikit bantuan', C: 'Mode Champion' };
  startPuzzle(freeCfg(n, lvl), code, `Latihan ${n} × ${n}, ${names[lvl]}`);
}

function lockAndScore(timeout) {
  if (S.locked) return;
  if (S.peek) exitPeek();
  S.locked = true; S.running = false; S.sel = -1; S.brush = 0;
  sfx.bell();
  const n = S.n, total = n * n;
  const map = {}; let correct = 0, open = 0;
  for (let i = 0; i < total; i++) { if (isFixed(i)) continue; open++; const ok = S.grid[i] === S.p.sol[i]; map[i] = ok; if (ok) correct++; }
  S.resultMap = map;
  updateAll();
  Object.keys(map).forEach(i => { if (!map[i] && S.grid[i]) shake(+i); });
  const perfect = correct === open;
  const base = BASE_PTS[n];
  const timeBonus = perfect ? Math.floor(base * 0.5 * Math.max(0, S.timeLeft) / S.timeTotal) : 0;
  const hintCost = Math.floor(base * 0.25 * S.hints);
  const partial = perfect ? base : Math.floor(base * 0.5 * (open ? correct / open : 0));
  const pts = Math.max(0, partial + timeBonus - hintCost);
  const stars = perfect ? (S.hints ? 2 : 3) : (open && correct / open >= 0.7 ? 1 : 0);
  if (perfect) sfx.win();
  setTimeout(() => showResult({ perfect, correct, open, pts, stars, timeBonus, hintCost, timeout }), settings.reduce ? 50 : 900);
}
function finishRound() { lockAndScore(false); }

function showResult(r) {
  if (S.mode === 'tour') S.results[S.round] = { n: S.n, stars: r.stars, pts: r.pts };
  $('#resTitle').textContent = r.perfect ? 'Kota sempurna! 🎉' : r.timeout ? 'Waktu habis!' : 'Hampir!';
  $('#resStars').textContent = '★'.repeat(r.stars) + '☆'.repeat(3 - r.stars);
  $('#resStars').setAttribute('aria-label', `${r.stars} dari 3 bintang`);
  $('#resPoints').textContent = `${r.pts} poin`;
  let d = `Menara tepat: ${r.correct} dari ${r.open}.`;
  if (r.timeBonus) d += ` Bonus waktu +${r.timeBonus}.`;
  if (r.hintCost) d += ` Bantuan −${r.hintCost}.`;
  if (!r.perfect) d += ' Menara yang salah menyala merah.';
  $('#resDetail').textContent = d;
  const btns = $('#resBtns'); btns.innerHTML = '';
  const add = (txt, cls, fn) => { const b = document.createElement('button'); b.className = 'key ' + cls; b.textContent = txt; b.onclick = fn; btns.appendChild(b); };
  if (!r.perfect) add('Lihat jawaban', '', () => { hideAll(); showSolution(); });
  if (S.mode === 'tour') {
    if (S.round < TOUR.length - 1) add(`Lanjut ke ronde ${S.round + 2}`, 'primary', () => { S.round++; startRound(); });
    else add('Lihat hasil turnamen', 'primary', showFinal);
  } else {
    add('Kota baru', 'primary', () => startFree(S.n, S.cfg.givens === 0 ? 'C' : S.cfg.givens <= Math.round(S.n * S.n * 0.15) ? 'B' : 'A'));
  }
  show('#ovResult');
}
function showSolution() {
  S.resultMap = null;
  for (let i = 0; i < S.n * S.n; i++) if (S.grid[i] !== S.p.sol[i]) { S.grid[i] = S.p.sol[i]; buildTower(i, true); }
  updateAll();
  const nextLabel = S.mode === 'tour' ? (S.round < TOUR.length - 1 ? `Lanjut ke ronde ${S.round + 2}` : 'Lihat hasil turnamen') : 'Kota baru';
  toast('Ini kota yang benar. Ketuk angka di pinggir untuk mengecek.');
  const bell = $('#btnBell'); bell.disabled = false; bell.innerHTML = '<span>▶</span>Lanjut'; bell.dataset.next = '1';
  bell.setAttribute('aria-label', nextLabel);
}

function showFinal() {
  const total = S.results.reduce((a, r) => a + (r ? r.pts : 0), 0);
  const stars = S.results.reduce((a, r) => a + (r ? r.stars : 0), 0);
  let html = '<tr><th>Ronde</th><th>Kota</th><th>Bintang</th><th>Poin</th></tr>';
  S.results.forEach((r, i) => { html += `<tr><td>${i + 1}</td><td>${r.n} × ${r.n}</td><td>${'★'.repeat(r.stars)}${'☆'.repeat(3 - r.stars)}</td><td>${r.pts}</td></tr>`; });
  $('#finTable').innerHTML = html;
  $('#finTotal').textContent = `${total} poin`;
  const best = store('best') || 0;
  if (total > best) store('best', total);
  $('#finTitle').textContent = stars >= 13 ? 'Arsitek Legendaris! 🏆' : stars >= 9 ? 'Arsitek Hebat! 🏗️' : 'Turnamen selesai!';
  $('#finBest').textContent = total > best ? `Rekor baru di perangkat ini! Kode turnamen: ${S.tourCode}` : `Rekor perangkat ini: ${best} poin. Kode turnamen: ${S.tourCode}`;
  hideAll(); show('#ovFinal');
}

// ---------- tombol utama ----------
$('#btnBell').onclick = () => {
  const b = $('#btnBell');
  if (b.dataset.next) {
    delete b.dataset.next; b.innerHTML = '<span>🔔</span>TENG!'; b.setAttribute('aria-label', 'Tekan bel: kunci jawaban');
    if (S.mode === 'tour') { if (S.round < TOUR.length - 1) { S.round++; startRound(); } else showFinal(); }
    else startFree(S.n, S.cfg.givens === 0 ? 'C' : S.cfg.givens <= Math.round(S.n * S.n * 0.15) ? 'B' : 'A');
    return;
  }
  if (S.locked) return;
  const empty = S.grid.filter(v => !v).length;
  $('#confirmNote').textContent = empty ? `Masih ada ${empty} petak kosong. Setelah bel berbunyi, menara tidak bisa diubah lagi.` : 'Setelah bel berbunyi, menara tidak bisa diubah lagi.';
  show('#ovConfirm');
};
$('#confirmGo').onclick = () => { hideAll(); lockAndScore(false); };
$('#btnHint').onclick = () => {
  if (S.locked) return;
  if (S.mode === 'tour' && S.hints >= 1) return;
  const n = S.n, cand = [];
  for (let i = 0; i < n * n; i++) if (!isFixed(i) && S.grid[i] !== S.p.sol[i]) cand.push(i);
  if (!cand.length) { toast('Semua menara sudah benar. Tekan TENG!'); return; }
  const wrong = cand.filter(i => S.grid[i]);
  const i = (wrong.length ? wrong : cand)[Math.floor(Math.random() * (wrong.length ? wrong : cand).length)];
  S.hints++; S.hintCells.add(i); S.grid[i] = S.p.sol[i]; buildTower(i, true); S.sel = i;
  toast(wrong.length ? 'Satu menara salah sudah dibetulkan 💡' : 'Satu menara dipasang untukmu 💡');
  updateAll();
  if (S.mode === 'free' && !S.solved && S.grid.every((v, k) => v === S.p.sol[k])) { S.solved = true; finishRound(); }
};

// ---------- overlay ----------
function show(sel) { $(sel).hidden = false; const f = $(sel).querySelector('button.primary, button, input'); f && setTimeout(() => f.focus(), 30); }
function hideAll() { document.querySelectorAll('.ov').forEach(o => o.hidden = true); }
function closeTopOverlay() { const open = [...document.querySelectorAll('.ov:not([hidden])')]; const top = open[open.length - 1]; if (top && top.id !== 'ovMenu') { top.hidden = true; if (S.mode === 'menu') show('#ovMenu'); } }
document.querySelectorAll('[data-close]').forEach(b => b.onclick = () => { b.closest('.ov').hidden = true; if (S.mode === 'menu') show('#ovMenu'); });

function goMenu() {
  S.mode = 'menu'; S.running = false; S.locked = false;
  if (S.peek) { S.peek = null; camMode = 'orbit'; }
  const demo = makePuzzle(4, 0, 'DEMO-TOWER');
  S.n = 4; S.p = demo; S.grid = demo.sol.slice(); S.hintCells = new Set(); S.resultMap = null; S.sel = -1;
  buildBoard(); Object.assign(cam, { yaw: 0.5, pitch: 0.75, dist: defaultDist() * 1.05 }); applyOrbit();
  $('#roundLabel').textContent = 'Arsitek Cilik Kota Kubus'; $('#timer').textContent = '--:--'; $('#codeLabel').textContent = '';
  const best = store('best'); $('#bestLine').textContent = best ? `Rekor turnamen di perangkat ini: ${best} poin` : '';
  const b = $('#btnBell'); delete b.dataset.next; b.innerHTML = '<span>🔔</span>TENG!';
  hideAll(); show('#ovMenu');
}
$('#btnHome').onclick = () => { if (S.mode !== 'menu' && !S.locked && !confirm('Kembali ke menu? Kota ini akan ditinggalkan.')) return; goMenu(); };
$('#btnHelp').onclick = () => show('#ovHelp');
$('#mHelp').onclick = () => { $('#ovMenu').hidden = true; show('#ovHelp'); };
$('#mTour').onclick = () => startTour();
$('#mFree').onclick = () => { $('#ovMenu').hidden = true; updateFreeNote(); show('#ovFree'); };
$('#mCode').onclick = () => { $('#ovMenu').hidden = true; $('#codeErr').textContent = ''; $('#codeIn').value = ''; show('#ovCode'); };

let freeN = 4, freeL = 'A';
function seg(id, cb) { $(id).addEventListener('click', e => { const b = e.target.closest('button'); if (!b) return; $(id).querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); cb(b.dataset.v); updateFreeNote(); }); }
seg('#segSize', v => freeN = +v); seg('#segLvl', v => freeL = v);
function updateFreeNote() {
  const c = freeCfg(freeN, freeL);
  $('#freeNote').textContent = freeL === 'C'
    ? `Seperti aslinya: tanpa menara bantuan (kecuali bila perlu agar jawabannya hanya satu). Waktu ${fmt(c.time)}.`
    : `${c.givens} menara bantuan sudah dipaku. Waktu ${fmt(c.time)}.`;
}
$('#freeGo').onclick = () => startFree(freeN, freeL);
$('#codeGo').onclick = () => {
  const raw = $('#codeIn').value.trim().toUpperCase().replace(/\s+/g, '');
  let m;
  if ((m = raw.match(/^T-?([A-Z0-9]{3,8})$/))) { startTour('T-' + m[1]); return; }
  if ((m = raw.match(/^([3-6])([ABC])-?([A-Z0-9]{3,8})$/))) { startFree(+m[1], m[2], m[3]); return; }
  $('#codeErr').textContent = 'Kode tidak dikenali. Contoh yang benar: T-K7Q2X atau 4A-M3PZR.';
};
$('#codeIn').addEventListener('keydown', e => { if (e.key === 'Enter') $('#codeGo').click(); });
$('#finMenu').onclick = goMenu;
$('#finAgain').onclick = () => startTour();

// ---------- pengaturan ----------
const TOG = [
  ['color', 'Warna menara sesuai tinggi', 'Mati = semua menara berwarna kayu, lebih menantang'],
  ['dupes', 'Tandai menara kembar', 'Menara dengan tinggi sama di satu baris/kolom menyala merah'],
  ['clueCheck', 'Cek angka pengintip (latihan)', 'Angka berubah hijau/merah saat barisnya penuh. Di turnamen selalu tersembunyi'],
  ['labels', 'Angka di atas menara', 'Membantu murid yang sulit membedakan warna'],
  ['sound', 'Suara', ''],
  ['reduce', 'Kurangi animasi', ''],
];
function renderToggles() {
  $('#toggles').innerHTML = TOG.map(([k, t, d]) => `<div class="toggle"><div><b>${t}</b>${d ? `<div class="muted" style="font-size:14px">${d}</div>` : ''}</div><button class="sw" role="switch" aria-checked="${!!settings[k]}" aria-label="${t}" data-k="${k}"></button></div>`).join('');
}
$('#toggles').addEventListener('click', e => {
  const b = e.target.closest('.sw'); if (!b) return; const k = b.dataset.k;
  settings[k] = !settings[k]; store('settings', settings); renderToggles();
  if (k === 'color' || k === 'labels') rebuildTowers(); else updateAll();
  $('#btnSound').textContent = settings.sound ? '🔊' : '🔇';
});
$('#btnSettings').onclick = () => { renderToggles(); show('#ovSettings'); };
$('#btnSound').onclick = () => { settings.sound = !settings.sound; store('settings', settings); $('#btnSound').textContent = settings.sound ? '🔊' : '🔇'; };
$('#btnSound').textContent = settings.sound ? '🔊' : '🔇';

// ---------- mulai ----------
function boot() { resize(); goMenu(); requestAnimationFrame(t => { lastT = t; loop(t); }); }
if (document.fonts && document.fonts.load) Promise.race([document.fonts.load('800 74px "Baloo 2"'), new Promise(r => setTimeout(r, 1500))]).then(boot, boot); else boot();
})();

const P = require('./puzzle.cjs');
function checkLatin(n,g){for(let r=0;r<n;r++){const s=new Set();for(let c=0;c<n;c++)s.add(g[r*n+c]);if(s.size!==n)return false}for(let c=0;c<n;c++){const s=new Set();for(let r=0;r<n;r++)s.add(g[r*n+c]);if(s.size!==n)return false}return true}
const cfgs=[[3,1],[3,0],[4,6],[4,3],[4,0],[5,8],[5,4],[5,0],[6,6],[6,0]];
for(const [n,k] of cfgs){
  let t0=Date.now(), maxT=0, gsum=0;
  for(let i=0;i<15;i++){
    const t=Date.now();
    const p=P.makePuzzle(n,k,'T'+n+k+'-'+i);
    const dt=Date.now()-t; maxT=Math.max(maxT,dt);
    if(!checkLatin(n,p.sol)) throw 'not latin';
    const s=P.solve(n,p.clues,p.givens,2);
    if(s.length!==1) throw 'not unique '+n+' '+k+' '+s.length;
    if(s[0].join()!==p.sol.join()) throw 'sol mismatch';
    gsum+=p.givens.filter(Boolean).length;
  }
  console.log(`n=${n} k=${k} avgGivens=${(gsum/15).toFixed(1)} maxGenMs=${maxT} total=${Date.now()-t0}ms`);
}
// determinism
const a=P.makePuzzle(5,4,'XYZ'), b=P.makePuzzle(5,4,'XYZ'); console.log('deterministic', a.sol.join()===b.sol.join() && a.givens.join()===b.givens.join());
// symmetry variants: unique, same givens count, all 8 distinct for n>=4 typically
for (const n of [3,4,5,6]) {
  const p = P.makePuzzle(n, n===6?0:3, 'SYM'+n);
  const seen = new Set();
  for (let k=0;k<8;k++){ const v=P.variant(p,k); const s=P.solve(n,v.clues,v.givens,2);
    if(s.length!==1||s[0].join()!==v.sol.join()) throw 'variant broken';
    if(v.givens.filter(Boolean).length!==p.givens.filter(Boolean).length) throw 'given count';
    seen.add(v.sol.join()); }
  console.log('n',n,'variants unique & valid, distinct solutions:',seen.size);
}

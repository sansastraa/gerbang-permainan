import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { io as ioc } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { buatApp, normalisasiBasePath } from "./app";
import type { App } from "./app";
import { AuditLog } from "./audit";
import { realClock } from "./clock";
import { muatConfig, muatPaket } from "./paket";
import { TowerPeek } from "./service";

const PIN = "guru-rahasia";
const BASE = "/games/tower-peek";
let app: App;
let url = "";
const soket: Socket[] = [];
const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tp-app-"));

beforeAll(async () => {
  const svc = new TowerPeek({ ...muatConfig(), hitung_mundur_detik: 0.2 }, muatPaket(), realClock, new AuditLog(path.join(dir, "a.jsonl")));
  app = buatApp({ svc, hostPin: PIN, basePath: BASE + "/", trustProxy: true });
  url = `http://127.0.0.1:${await app.listen(0, "127.0.0.1")}`;
});
afterAll(async () => {
  soket.forEach((s) => s.close());
  await app.tutup();
});
const post = (p: string, body: unknown, h: Record<string, string> = { "x-host-token": PIN }) =>
  fetch(url + BASE + p, { method: "POST", headers: { "content-type": "application/json", ...h }, body: JSON.stringify(body) });
const sambung = (ns: string, auth: object = {}) =>
  new Promise<Socket>((res, rej) => {
    const s = ioc(url + ns, { path: `${BASE}/socket.io`, auth, transports: ["websocket"], reconnection: false });
    soket.push(s);
    s.on("connect", () => res(s));
    s.on("connect_error", rej);
  });
const tunggu = <T>(s: Socket, ev: string) => new Promise<T>((res) => s.once(ev, res));
const emitAck = <T>(s: Socket, ev: string, p: unknown) => new Promise<{ ok: boolean; kode?: string; data: T }>((res) => s.emit(ev, p, res));

describe("gateway", () => {
  it("BASE_PATH dinormalisasi; health di bawah awalan; REST butuh token guru", async () => {
    expect(normalisasiBasePath("games/tower-peek/")).toBe("/games/tower-peek");
    expect(((await (await fetch(url + BASE + "/health")).json()) as { game: string }).game).toBe("tower-peek");
    expect((await fetch(url + "/health")).status).toBe(404);
    expect((await post("/api/sessions", { nama: "x" }, {})).status).toBe(401);
    expect((await post("/api/sessions", { nama: "x" }, { "x-host-token": "salah" })).status).toBe(401);
    expect((await post("/api/sessions", { nama: "" })).status).toBe(400);
  });
  it("socket operator ditolak tanpa PIN", async () => {
    await expect(sambung("/operator", { token: "salah" })).rejects.toBeTruthy();
  });
  it("alur: sesi → pasang meja → 3 meja terhubung → mulai → puzzle:deliver tanpa solusi, tepat setelah hitung mundur", async () => {
    const b = (await (await post("/api/sessions", { nama: "Kelas 5A", mode: "SD", jumlahMeja: 4, peserta: [{ id: "s1", nama: "Rina" }, { id: "s2", nama: "Budi" }] })).json()) as { id: string };
    const pr = (await (await post(`/api/sessions/${b.id}/desks/pair`, {})).json()) as { meja: { nomor: number; token: string; jalur: string }[] };
    expect(pr.meja).toHaveLength(4);
    expect(pr.meja[0]!.jalur).toMatch(/^\/meja\/1\?t=/);
    const op = await sambung("/operator", { token: PIN });
    const meja: Socket[] = [];
    for (const m of pr.meja.slice(0, 3)) {
      const s = await sambung("/meja");
      const a = await emitAck<{ nomor: number }>(s, "desk:hello", { token: m.token, deviceId: `perangkat-${m.nomor}` });
      expect(a.ok).toBe(true);
      meja.push(s);
    }
    // perangkat lain memakai token meja 1 → ditolak
    const maling = await sambung("/meja");
    expect((await emitAck(maling, "desk:hello", { token: pr.meja[0]!.token, deviceId: "perangkat-lain" })).kode).toBe("perangkat_lain");
    // sinkron jam
    const pong = tunggu<{ t0: number; ts: number }>(meja[0]!, "clock:pong");
    meja[0]!.emit("clock:ping", { t0: 123 });
    expect((await pong).t0).toBe(123);

    expect((await emitAck(op, "round:load", { urutan: 1, sumber: "paket" })).ok).toBe(true);
    const diterima: string[] = [];
    const cd = tunggu(meja[0]!, "round:countdown");
    const dl = tunggu<Record<string, unknown>>(meja[0]!, "puzzle:deliver");
    meja[0]!.onAny((ev: string, ...a: unknown[]) => void (ev !== "clock:pong" && diterima.push(ev + JSON.stringify(a))));
    expect((await emitAck(op, "round:start", { urutan: 1 })).ok).toBe(true);
    await cd;
    expect(diterima.some((x) => x.startsWith("puzzle:deliver"))).toBe(false); // belum, masih hitung mundur
    const isi = await dl;
    expect(Object.keys(isi)).toContain("petunjuk");
    // tak satu pun pesan ke meja memuat solusi
    const semua = diterima.join("\n");
    expect(semua).not.toMatch(/solusi|"sol"/);
    const snap = await emitAck(op, "round:close", {});
    expect(snap.ok).toBe(true);
  });
});

describe("gabung ARENA lewat HTTP", () => {
  it("info & join publik dengan PIN sesi; PIN salah 404 lalu dibatasi 429; token dipakai di /meja", async () => {
    const b = (await (await post("/api/sessions", { nama: "Arena", format: "ARENA" })).json()) as { pin: string };
    const g = (p: string, body?: unknown) => fetch(url + BASE + p, body ? { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body) } : {});
    expect((await g(`/api/join/info?pin=${b.pin}`)).status).toBe(200);
    const j = (await (await g("/api/join", { pin: b.pin, deviceId: "perangkat-1", nama: "Sari" })).json()) as { token: string; nomor: number };
    const s = await sambung("/meja");
    expect((await emitAck(s, "desk:hello", { token: j.token, deviceId: "perangkat-1" })).ok).toBe(true);
    let st = 0;
    for (let i = 0; i < 11; i++) st = (await g("/api/join", { pin: "999999", deviceId: "perangkat-x", nama: "X" })).status;
    expect(st).toBe(429);
  });
});

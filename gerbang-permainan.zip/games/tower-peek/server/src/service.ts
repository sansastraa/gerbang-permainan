// Tower Peek — layanan inti (Session Manager, Puzzle Service, Round Controller, Clock). Server berwenang penuh.
// Setiap perubahan = satu entri audit (commit) yang diputar ulang oleh reduce() saat server hidup kembali.
import crypto from "node:crypto";
import { makePuzzle, variant } from "@tower-peek/shared";
import type { FormatSesi, AturanMeja, Clues, JadwalRonde, ModeGame, Puzzle, PuzzleDeliver, StatusMeja, StatusRonde, TowerConfig } from "@tower-peek/shared";
import type { AuditLog } from "./audit";
import { cocokDenganSolusiLain } from "./anticheat";
import { nilaiRonde, urutkan } from "./judge";
import type { Hasil } from "./judge";
import type { Clock } from "./clock";
import type { Paket } from "./paket";
import { bersebelahan, tataMeja, tugaskanVarian } from "./varian";

export interface Peserta {
  id: string;
  nama: string;
  kelas?: string;
  avatar?: string;
}
export interface Flag {
  id: number;
  urutan: number;
  nomor: number;
  tipe: string;
  tingkat: "kuning" | "merah";
  detail: Record<string, unknown>;
  status: "baru" | "diabaikan" | "diperingatkan" | "dikunci";
  t: number;
}
export interface BelState {
  t: number;
  tKlien: number | null;
  rtt: number | null;
  urutan: number;
  sumber: string;
}
const baruMeja = () => ({ papan: [] as number[], versi: 0, bantuan: 0, validasi: 0, validasiT: 0, bel: null as BelState | null, fokus: 0, recent: [] as number[], peringatan: 0 });
export interface Meja extends ReturnType<typeof baruMeja> {
  nomor: number;
  tokenHash: string | null;
  deviceId: string | null;
  pesertaId: string | null;
  online: boolean;
  status: StatusMeja;
  jeda: boolean;
  jedaSejak: number | null;
  kompensasiMs: number;
  x: number;
  y: number;
}
export interface RondeState {
  urutan: number;
  n: number;
  waktuDetik: number;
  kode: string;
  dipaku: number;
  status: StatusRonde;
  sumber: "paket" | "seed" | null;
  /** Kode soal bangkitan yang menggantikan soal paket simetris (null = soal paket dipakai apa adanya). */
  pengganti: string | null;
  startAt: number | null;
  deadline: number | null;
  pausedAt: number | null;
  ditutup: { t: number; alasan: string } | null;
  hasil: Hasil[] | null;
  papanAkhir: Record<number, number[]> | null;
  reveal: { current: number | null; sudah: number[] };
  bel: number[];
  /** SERVER SAJA. Kunci soal per meja (nomor → varian + puzzle berisi solusi). */
  soal: Record<number, { k: number; puzzle: Puzzle }>;
}
export interface Sesi {
  id: string;
  nama: string;
  mode: ModeGame;
  format: FormatSesi;
  /** PIN gabung (ARENA saja). */
  pin: string | null;
  /** Bila true (sesi dibuat dengan daftar peserta), pemain wajib memilih nama dari daftar. */
  kunciRoster: boolean;
  dibuat: number;
  jumlahMeja: number;
  peserta: Peserta[];
  meja: Meja[];
  ronde: RondeState[];
  flags: Flag[];
  adeganManual: string | null;
  tinggiLive: boolean;
  /** Sorotan 3D bergilir: Layar menayangkan papan SATU pemain bergantian (bawaan aktif di ARENA yang papannya unik per pemain). */
  sorotan: boolean;
  aktif: number | null; // indeks ronde berjalan (urutan-1)
}
export class GalatTP extends Error {
  constructor(
    readonly kode: string,
    pesan?: string,
  ) {
    super(pesan ?? kode);
  }
}
export type Pancar = { tipe: "sesi" | "ronde" | "meja" | "papan"; nomor?: number; ronde?: number };

type Payload = Record<string, unknown>;
const sha = (s: string) => crypto.createHash("sha256").update(s).digest("hex");

export class TowerPeek {
  sesi: Sesi | null = null;
  private readonly pendengar = new Set<(e: Pancar) => void>();
  private batalTimer: (() => void) | null = null;
  private replaying = false;

  constructor(
    readonly cfg: TowerConfig,
    readonly paket: Paket,
    readonly clock: Clock,
    readonly audit: AuditLog,
  ) {
    this.replaying = true;
    for (const e of audit.entri) this.reduce(e.tipe, e.payload as Payload);
    this.replaying = false;
    if (this.sesi) {
      for (const m of this.sesi.meja) m.online = false;
      this.tick();
    }
  }

  onPancar(fn: (e: Pancar) => void): () => void {
    this.pendengar.add(fn);
    return () => this.pendengar.delete(fn);
  }
  private pancar(e: Pancar) {
    if (!this.replaying) for (const f of this.pendengar) f(e);
  }
  private commit(aktor: string, tipe: string, payload: Payload) {
    if (!this.replaying) this.audit.tambah(this.clock.now(), aktor, tipe, payload);
    this.reduce(tipe, payload);
  }

  // ---------- akses ----------
  need(): Sesi {
    if (!this.sesi) throw new GalatTP("belum_ada_sesi", "Belum ada sesi. Buat sesi dulu.");
    return this.sesi;
  }
  ronde(urutan: number): RondeState {
    const r = this.need().ronde[urutan - 1];
    if (!r) throw new GalatTP("ronde_tidak_ada");
    return r;
  }
  rondeAktif(): RondeState | null {
    const s = this.sesi;
    return s && s.aktif !== null ? (s.ronde[s.aktif] ?? null) : null;
  }
  meja(nomor: number): Meja {
    const m = this.need().meja[nomor - 1];
    if (!m) throw new GalatTP("meja_tidak_ada");
    return m;
  }
  /** Tenggat efektif sebuah meja = tenggat ronde + kompensasi jeda meja itu. */
  tenggatMeja(r: RondeState, m: Meja): number {
    return (r.deadline ?? 0) + m.kompensasiMs + (m.jeda && m.jedaSejak !== null ? this.clock.now() - m.jedaSejak : 0);
  }

  // ---------- Session Manager ----------
  buatSesi(a: { nama: string; mode: ModeGame; format?: FormatSesi; jumlahMeja?: number; peserta?: Partial<Peserta>[] }): Sesi {
    const format = a.format ?? "KOMPETISI";
    const maks = format === "ARENA" ? this.cfg.arena.pemain_maks : this.cfg.jumlah_meja_maks;
    const jml = Math.min(maks, Math.max(1, a.jumlahMeja ?? (format === "ARENA" ? maks : this.cfg.jumlah_meja_default)));
    const id = "tp" + crypto.randomBytes(5).toString("hex");
    const peserta = this.normalisasiPeserta(a.peserta ?? [], []);
    if (peserta.length > maks) throw new GalatTP("terlalu_banyak_peserta", `Maksimal ${maks} peserta`);
    const pin = format === "ARENA" ? String(crypto.randomInt(10 ** (this.cfg.arena.pin_digit - 1), 10 ** this.cfg.arena.pin_digit)) : null;
    this.commit("operator", "sesi.buat", { id, nama: a.nama, mode: a.mode, format, pin, kunciRoster: peserta.length > 0, jumlahMeja: jml, peserta, sorotan: format === "ARENA", t: this.clock.now() });
    return this.need();
  }
  private normalisasiPeserta(baru: Partial<Peserta>[], ada: Peserta[]): Peserta[] {
    const ids = new Set(ada.map((p) => p.id));
    const out: Peserta[] = [];
    for (const p of baru) {
      let id = p.id ?? "p" + crypto.randomBytes(4).toString("hex");
      if (ids.has(id)) id = "p" + crypto.randomBytes(4).toString("hex");
      ids.add(id);
      out.push({ id, nama: String(p.nama), ...(p.kelas ? { kelas: p.kelas } : {}), ...(p.avatar ? { avatar: p.avatar } : {}) });
    }
    return out;
  }
  tambahPeserta(baru: Partial<Peserta>[]): Peserta[] {
    const s = this.need();
    const peserta = this.normalisasiPeserta(baru, s.peserta);
    this.commit("operator", "peserta.tambah", { peserta });
    return peserta;
  }
  tugaskanPeserta(nomor: number, pesertaId: string | null) {
    const s = this.need();
    this.meja(nomor);
    if (pesertaId && !s.peserta.some((p) => p.id === pesertaId)) throw new GalatTP("peserta_tidak_ada");
    this.commit("operator", "meja.peserta", { nomor, pesertaId });
  }
  /** Membuat token baru untuk satu/semua meja (QR). Token hanya dikembalikan di sini; yang tersimpan hanya hash-nya. */
  pasangMeja(nomor?: number): { nomor: number; token: string; jalur: string }[] {
    const s = this.need();
    if (s.format === "ARENA") throw new GalatTP("format_arena", "Sesi arena memakai PIN gabung, bukan QR meja");
    const daftar = nomor ? [this.meja(nomor)] : s.meja;
    const keluar = daftar.map((m) => {
      const token = crypto.randomBytes(12).toString("base64url");
      return { nomor: m.nomor, token, jalur: `/meja/${m.nomor}?t=${token}` };
    });
    this.commit("operator", "meja.pasang", { meja: keluar.map((k) => ({ nomor: k.nomor, tokenHash: sha(k.token) })), otomatis: !nomor });
    return keluar;
  }
  /** Info publik untuk layar gabung (setelah PIN benar): nama sesi dan nama yang masih bebas. */
  infoGabung(pin: string): { nama: string; mode: ModeGame; bebas: { id: string; nama: string }[]; bebasKetik: boolean; terisi: number; maks: number } {
    const s = this.sesiArena(pin);
    const dipakai = new Set(s.meja.map((m) => m.pesertaId));
    return { nama: s.nama, mode: s.mode, bebas: s.peserta.filter((p) => !dipakai.has(p.id)).map((p) => ({ id: p.id, nama: p.nama })), bebasKetik: !s.kunciRoster, terisi: s.meja.length, maks: this.cfg.arena.pemain_maks };
  }
  private sesiArena(pin: string): Sesi {
    const s = this.sesi;
    const a = Buffer.from(String(pin));
    const b = Buffer.from(s?.pin ?? "");
    if (!s || s.format !== "ARENA" || a.length !== b.length || !crypto.timingSafeEqual(a, b)) throw new GalatTP("pin_salah", "PIN tidak cocok");
    return s;
  }
  /** Pemain ARENA masuk dengan PIN. Satu nama satu perangkat; perangkat yang sama boleh masuk lagi (token diganti). */
  gabung(pin: string, a: { deviceId: string; pesertaId?: string; nama?: string }): { nomor: number; token: string; jalur: string; nama: string } {
    const s = this.sesiArena(pin);
    const bersih = Array.from(a.nama ?? "").filter((ch) => ch.charCodeAt(0) >= 32 && ch !== "<" && ch !== ">").join("").replace(/\s+/g, " ").trim().slice(0, 30);
    let peserta = a.pesertaId ? s.peserta.find((p) => p.id === a.pesertaId) : bersih ? s.peserta.find((p) => p.nama.toLowerCase() === bersih.toLowerCase()) : undefined;
    if (!peserta && (s.kunciRoster || !bersih)) throw new GalatTP("nama_tidak_ada", "Pilih namamu dari daftar");
    let baru: Peserta | null = null;
    if (!peserta) {
      baru = { id: "p" + crypto.randomBytes(4).toString("hex"), nama: bersih };
      peserta = baru;
    }
    const ada = s.meja.find((m) => m.pesertaId === peserta.id);
    const token = crypto.randomBytes(12).toString("base64url");
    if (ada) {
      if (ada.deviceId !== a.deviceId) throw new GalatTP("nama_dipakai", "Nama ini sudah dipakai perangkat lain");
      this.commit("pemain", "meja.pasang", { meja: [{ nomor: ada.nomor, tokenHash: sha(token) }], otomatis: false });
      return { nomor: ada.nomor, token, jalur: `/main?t=${token}`, nama: peserta.nama };
    }
    if (s.meja.length >= this.cfg.arena.pemain_maks) throw new GalatTP("penuh", `Arena penuh (${this.cfg.arena.pemain_maks} pemain)`);
    const nomor = s.meja.length + 1;
    const r = this.rondeAktif();
    const soal = r && Object.keys(r.soal).length && ["LOADED", "BRIEFING", "COUNTDOWN", "LIVE", "PAUSED"].includes(r.status) ? this.soalArena(r, nomor) : null;
    this.commit("pemain", "pemain.gabung", { nomor, peserta: baru, pesertaId: peserta.id, tokenHash: sha(token), deviceId: a.deviceId, soal, t: this.clock.now() });
    return { nomor, token, jalur: `/main?t=${token}`, nama: peserta.nama };
  }
  /** Meja menyapa. Satu token = satu perangkat; perangkat lain ditolak sampai operator "memindahkan meja" (token baru). */
  halo(token: string, deviceId: string): Meja {
    const s = this.need();
    const h = sha(token);
    const m = s.meja.find((x) => x.tokenHash === h);
    if (!m) throw new GalatTP("token_tidak_sah", "Token meja tidak sah");
    if (m.deviceId && m.deviceId !== deviceId) throw new GalatTP("perangkat_lain", "Meja ini sudah dipakai perangkat lain");
    this.commit("meja", "meja.halo", { nomor: m.nomor, deviceId, t: this.clock.now() });
    for (const o of s.meja) if (o.nomor !== m.nomor && o.deviceId === deviceId) for (const q of [m.nomor, o.nomor]) this.tandai(this.rondeAktif()?.urutan ?? 0, q, "PERANGKAT_GANDA", "merah", { meja: [m.nomor, o.nomor] });
    return m;
  }
  setOnline(nomor: number, online: boolean) {
    const m = this.meja(nomor);
    if (m.online === online) return;
    this.commit("meja", "meja.online", { nomor, online });
  }

  // ---------- Puzzle Service ----------
  private bangunSoal(r: RondeState, sumber: "paket" | "seed", seed?: string): { soal: RondeState["soal"]; pengganti: string | null } {
    const s = this.need();
    if (s.format === "ARENA") {
      const out: RondeState["soal"] = {};
      for (const m of s.meja) out[m.nomor] = this.soalArena(r, m.nomor);
      return { soal: out, pengganti: null };
    }
    let dasar: Puzzle;
    if (sumber === "paket") {
      const p = this.paket.mode[s.mode].ronde.find((x) => x.ronde === r.urutan);
      if (!p) throw new GalatTP("paket_tidak_ada");
      dasar = { n: p.n, sol: p.solusi, clues: p.petunjuk, givens: p.dipaku, code: p.kode };
    } else {
      dasar = makePuzzle(r.n, r.dipaku, seed ?? `${s.id}-R${r.urutan}`);
    }
    const tata = tataMeja(s.jumlahMeja);
    const ks = tugaskanVarian(s.jumlahMeja, r.n, this.cfg.seed_simetri.aktif);
    const rakit = (base: Puzzle) => {
      const v = ks.map((k) => variant(base, k));
      for (let a = 0; a < v.length; a++) for (let b = a + 1; b < v.length; b++) if (bersebelahan(tata[a]!, tata[b]!) && v[a]!.sol.join() === v[b]!.sol.join()) return null;
      return v;
    };
    let v = rakit(dasar);
    let pengganti: string | null = null;
    // Soal simetris (mis. Champion R1 hanya punya 2 jawaban berbeda) tak bisa membedakan meja bersebelahan:
    // ganti dengan soal bangkitan seed yang setara ukuran & jumlah dipaku. Operator diberi tahu lewat snapshot.
    for (let i = 1; !v && i <= 200; i++) {
      const alt = makePuzzle(r.n, r.dipaku, `${dasar.code}#${i}`);
      v = rakit(alt);
      if (v) pengganti = alt.code;
    }
    if (!v) throw new GalatTP("varian_tidak_cukup");
    const out: RondeState["soal"] = {};
    s.meja.forEach((m, i) => {
      out[m.nomor] = { k: ks[i]!, puzzle: v![i]! };
    });
    return { soal: out, pengganti };
  }
  /** ARENA: papan unik per pemain (seed berbeda, ukuran & jumlah dipaku sama) = anti-contek tanpa meja bersebelahan. */
  private soalArena(r: RondeState, nomor: number): { k: number; puzzle: Puzzle } {
    return { k: 0, puzzle: variant(makePuzzle(r.n, r.dipaku, `${this.need().id}-R${r.urutan}-P${nomor}`), 0) };
  }
  muatRonde(urutan: number, sumber: "paket" | "seed" = "paket", seed?: string): RondeState {
    const s = this.need();
    const r = this.ronde(urutan);
    if (r.status !== "DRAFT" && r.status !== "LOADED") throw new GalatTP("status_salah", "Ronde ini sudah berjalan");
    const sibuk = s.ronde.find((x) => x !== r && !["DRAFT", "LOADED", "ARCHIVED", "SCORED"].includes(x.status));
    if (sibuk) throw new GalatTP("ronde_lain_berjalan", `Ronde ${sibuk.urutan} belum selesai`);
    const { soal, pengganti } = this.bangunSoal(r, sumber, seed);
    this.commit("operator", "ronde.muat", { urutan, sumber, seed: seed ?? null, soal, pengganti });
    return r;
  }

  // ---------- Round Controller ----------
  tayangAturan(urutan: number) {
    const r = this.ronde(urutan);
    if (r.status !== "LOADED") throw new GalatTP("status_salah", "Muat soal dulu");
    this.commit("operator", "ronde.brief", { urutan });
  }
  mulai(urutan: number): JadwalRonde {
    const s = this.need();
    const r = this.ronde(urutan);
    if (r.status !== "BRIEFING" && r.status !== "LOADED") throw new GalatTP("status_salah", "Tayangkan aturan atau muat soal dulu");
    if (s.meja.every((m) => !m.online)) throw new GalatTP("tidak_ada_meja", "Belum ada meja yang terhubung");
    const startAt = this.clock.now() + this.cfg.hitung_mundur_detik * 1000;
    const deadline = startAt + r.waktuDetik * 1000;
    this.commit("operator", "ronde.mulai", { urutan, startAt, deadline });
    this.tick();
    return this.jadwal(r)!;
  }
  jeda() {
    const r = this.butuhAktif("LIVE");
    this.commit("operator", "ronde.jeda", { urutan: r.urutan, t: this.clock.now() });
    this.tick();
  }
  lanjut() {
    const r = this.butuhAktif("PAUSED");
    const t = this.clock.now();
    this.commit("operator", "ronde.lanjut", { urutan: r.urutan, t, durasi: t - (r.pausedAt ?? t) });
    this.tick();
  }
  perpanjang(detik: number) {
    const r = this.rondeAktif();
    if (!r || (r.status !== "LIVE" && r.status !== "PAUSED")) throw new GalatTP("status_salah", "Hanya saat ronde berjalan");
    this.commit("operator", "ronde.perpanjang", { urutan: r.urutan, ms: detik * 1000 });
    this.tick();
  }
  tutup(alasan = "OPERATOR") {
    const r = this.rondeAktif();
    if (!r || (r.status !== "LIVE" && r.status !== "PAUSED")) throw new GalatTP("status_salah", "Ronde tidak sedang berjalan");
    this.commit("operator", "ronde.tutup", { urutan: r.urutan, t: this.clock.now(), alasan });
    this.rearm();
    this.nilaiOtomatis(r);
  }
  jedaMeja(nomor: number) {
    const r = this.butuhAktif("LIVE");
    const m = this.meja(nomor);
    if (m.jeda) throw new GalatTP("sudah_dijeda");
    if (m.status !== "PLAYING") throw new GalatTP("status_salah", "Meja tidak sedang bermain");
    this.commit("operator", "meja.jeda", { urutan: r.urutan, nomor, t: this.clock.now() });
    this.rearm();
  }
  lanjutMeja(nomor: number) {
    const m = this.meja(nomor);
    if (!m.jeda || m.jedaSejak === null) throw new GalatTP("tidak_dijeda");
    const t = this.clock.now();
    this.commit("operator", "meja.lanjut", { nomor, t, durasi: t - m.jedaSejak });
    this.tick();
  }
  private butuhAktif(status: StatusRonde): RondeState {
    const r = this.rondeAktif();
    if (!r || r.status !== status) throw new GalatTP("status_salah", `Ronde harus ${status}`);
    return r;
  }

  /** Idempotent: majukan state berdasarkan jam server (COUNTDOWN→LIVE, tenggat meja, tutup otomatis). */
  tick() {
    const r = this.rondeAktif();
    const s = this.sesi;
    if (!r || !s) return;
    const now = this.clock.now();
    if (r.status === "COUNTDOWN" && r.startAt !== null && now >= r.startAt) this.commit("sistem", "ronde.live", { urutan: r.urutan, t: now });
    if (r.status === "LIVE") {
      for (const m of s.meja)
        if (m.status === "PLAYING" && !m.jeda && now >= this.tenggatMeja(r, m)) this.commit("sistem", "meja.kunci", { urutan: r.urutan, nomor: m.nomor, t: now, alasan: "TIMEOUT" });
      if (s.meja.some((m) => m.status === "BELL" || m.status === "TIMEOUT_LOCKED") && s.meja.every((m) => !["PLAYING", "COUNTDOWN"].includes(m.status)))
        this.commit("sistem", "ronde.tutup", { urutan: r.urutan, t: now, alasan: "SEMUA_SELESAI" });
    }
    this.rearm();
    if (r.status === "CLOSED") this.nilaiOtomatis(r);
  }
  private rearm() {
    this.batalTimer?.();
    this.batalTimer = null;
    const r = this.rondeAktif();
    const s = this.sesi;
    if (!r || !s || this.replaying) return;
    let at: number | null = null;
    if (r.status === "COUNTDOWN") at = r.startAt;
    else if (r.status === "LIVE")
      for (const m of s.meja)
        if (m.status === "PLAYING" && !m.jeda) {
          const t = this.tenggatMeja(r, m);
          at = at === null ? t : Math.min(at, t);
        }
    if (at === null) return;
    this.batalTimer = this.clock.setTimeout(() => this.tick(), Math.max(0, at - this.clock.now()));
  }
  jadwal(r: RondeState): JadwalRonde | null {
    return r.startAt === null || r.deadline === null ? null : { rondeUrutan: r.urutan, startAt: r.startAt, deadline: r.deadline, serverNow: this.clock.now() };
  }
  aturanMeja(): AturanMeja {
    const s = this.need();
    const c = this.cfg.mode[s.mode];
    return { mode: s.mode, warnaPerTinggi: c.warna_per_tinggi, tandaiKembar: c.tandai_kembar, cekAngkaPengintip: c.cek_angka_pengintip, bantuanPerRonde: c.bantuan_per_ronde };
  }
  /** Satu-satunya jalan data soal keluar ke meja: petunjuk + menara dipaku. TIDAK PERNAH memuat solusi. */
  deliver(nomor: number): PuzzleDeliver | null {
    const r = this.rondeAktif();
    if (!r || !["LIVE", "PAUSED", "CLOSED", "JUDGED", "REVEAL", "SCORED"].includes(r.status)) return null;
    const so = r.soal[nomor];
    if (!so) return null;
    const petunjuk: Clues = { top: [...so.puzzle.clues.top], bottom: [...so.puzzle.clues.bottom], left: [...so.puzzle.clues.left], right: [...so.puzzle.clues.right] };
    return { rondeUrutan: r.urutan, n: r.n, petunjuk, dipaku: [...so.puzzle.givens], waktuDetik: r.waktuDetik, aturan: this.aturanMeja() };
  }

  // ---------- Desk Gateway: papan, bantuan, bel, pengintip, fokus ----------
  private peekBuka = new Map<number, { sisi: string; indeks: number; masuk: number }>();
  private mainAktif(nomor: number) {
    const r = this.butuhAktif("LIVE");
    const m = this.meja(nomor);
    if (m.status !== "PLAYING" || m.jeda) throw new GalatTP("terkunci", "Meja tidak sedang bermain");
    if (this.clock.now() >= this.tenggatMeja(r, m)) throw new GalatTP("lewat_tenggat", "Waktu habis");
    return { r, m };
  }
  private terbuka(r: RondeState, nomor: number): number[] {
    const g = r.soal[nomor]?.puzzle.givens ?? [];
    return g.map((_, i) => i).filter((i) => !g[i]);
  }
  persen(r: RondeState, m: Meja): number {
    const t = this.terbuka(r, m.nomor);
    return t.length ? t.filter((i) => m.papan[i]).length / t.length : 0;
  }
  kembar(r: RondeState, m: Meja): number {
    const n = r.n;
    let k = 0;
    for (let i = 0; i < n * n; i++) {
      const v = m.papan[i];
      if (!v) continue;
      const rr = Math.floor(i / n);
      const cc = i % n;
      let dup = false;
      for (let q = 0; q < n; q++) if ((q !== cc && m.papan[rr * n + q] === v) || (q !== rr && m.papan[q * n + cc] === v)) dup = true;
      if (dup) k++;
    }
    return k;
  }
  setPapan(nomor: number, sel: number, tinggi: number, versi: number, sumber = "tap", tKlien?: number) {
    const { r, m } = this.mainAktif(nomor);
    const so = r.soal[nomor]!.puzzle;
    const balas = (ok: boolean, alasan?: string) => ({ ok, alasan: alasan ?? null, versi: m.versi, papan: ok ? null : m.papan.slice() });
    if (versi > m.versi) return balas(false, "versi");
    if (sel >= r.n * r.n || tinggi > r.n) throw new GalatTP("di_luar_papan");
    if (so.givens[sel]) return balas(false, "dipaku");
    const now = this.clock.now();
    if (m.recent.filter((q) => now - q < 1000).length >= 25) {
      this.tandai(r.urutan, nomor, "LAJU", "kuning", { aksiPerDetik: 25 });
      return balas(false, "terlalu_cepat");
    }
    this.commit("meja", "papan.set", { urutan: r.urutan, nomor, sel, tinggi, sumber, t: now, tKlien: tKlien ?? null });
    const t = this.terbuka(r, nomor);
    if (m.recent.length >= Math.max(8, Math.ceil(t.length * 0.8))) this.tandai(r.urutan, nomor, "PAPAN_INSTAN", "merah", { aksi1Detik: m.recent.length, terbuka: t.length });
    if (t.every((i) => m.papan[i])) this.periksaJebakan(r, m);
    return { ok: true, alasan: null, versi: m.versi, papan: null };
  }
  /** Tombol "Periksa" (ARENA, Mode SD): menyebut berapa petak terbuka yang sudah tepat; jumlah pemeriksaan tampil di papan peringkat. */
  periksa(nomor: number) {
    const { r, m } = this.mainAktif(nomor);
    const s = this.need();
    if (s.format !== "ARENA" || !this.cfg.mode[s.mode].validasi) throw new GalatTP("validasi_tidak_tersedia", "Periksa tidak tersedia di mode ini");
    const t = this.clock.now();
    if (t - m.validasiT < 1500) throw new GalatTP("terlalu_cepat", "Tunggu sebentar sebelum memeriksa lagi");
    const so = r.soal[nomor]!.puzzle;
    const idx = this.terbuka(r, nomor);
    const tepat = idx.filter((i) => m.papan[i] === so.sol[i]).length;
    this.commit("meja", "papan.validasi", { urutan: r.urutan, nomor, t, tepat, terbuka: idx.length });
    return { tepat, terbuka: idx.length, sempurna: tepat === idx.length, validasi: m.validasi };
  }
  /** Poin ronde "kalau ditutup sekarang" untuk papan peringkat langsung (ARENA). */
  skorSementara(r: RondeState): Map<number, number> {
    const s = this.need();
    const items = s.meja.filter((m) => r.soal[m.nomor]).map((m) => ({ nomor: m.nomor, papan: m.papan, sol: r.soal[m.nomor]!.puzzle.sol, givens: r.soal[m.nomor]!.puzzle.givens, bel: m.bel ? { t: m.bel.t } : null, bantuan: m.bantuan, validasi: m.validasi, tenggat: this.tenggatMeja(r, m) }));
    return new Map(nilaiRonde(this.cfg, s.mode, r.waktuDetik, items).map((h) => [h.nomor, h.poin]));
  }
  setSorotan(aktif: boolean, konfirmasi: boolean) {
    const s = this.need();
    if (aktif && s.format === "KOMPETISI" && !konfirmasi) throw new GalatTP("konfirmasi_wajib", "Di Kompetisi, sorotan menayangkan tinggi menara satu peserta. Konfirmasi dulu.");
    this.commit("operator", "layar.sorotan", { aktif });
  }
  mintaBantuan(nomor: number) {
    const { r, m } = this.mainAktif(nomor);
    if (m.bantuan >= this.cfg.mode[this.need().mode].bantuan_per_ronde) throw new GalatTP("tidak_ada_bantuan", "Bantuan habis");
    const so = r.soal[nomor]!.puzzle;
    const idx = this.terbuka(r, nomor);
    const sel = idx.find((i) => m.papan[i] && m.papan[i] !== so.sol[i]) ?? idx.find((i) => !m.papan[i]) ?? -1;
    if (sel < 0) throw new GalatTP("papan_sudah_benar", "Semua sudah benar");
    this.commit("meja", "papan.bantuan", { urutan: r.urutan, nomor, sel, tinggi: so.sol[sel]!, t: this.clock.now() });
    return { ok: true, sel, versi: m.versi, papan: m.papan.slice() };
  }
  tekanBel(nomor: number, a: { tKlien?: number; rtt?: number; sumber?: string } = {}) {
    const { r, m } = this.mainAktif(nomor);
    const t = this.clock.now();
    this.commit("meja", "bel.tekan", { urutan: r.urutan, nomor, t, tKlien: a.tKlien ?? null, rtt: a.rtt ?? null, sumber: a.sumber ?? "layar" });
    this.peekBuka.delete(nomor);
    if (this.terbuka(r, nomor).every((i) => m.papan[i])) this.periksaJebakan(r, m);
    const urutan = m.bel!.urutan;
    this.tick();
    return { urutan, t };
  }
  bukaPeek(nomor: number, sisi: string, indeks: number) {
    this.tutupPeek(nomor);
    if (this.rondeAktif()?.status === "LIVE") this.peekBuka.set(nomor, { sisi, indeks, masuk: this.clock.now() });
  }
  tutupPeek(nomor: number) {
    const o = this.peekBuka.get(nomor);
    const r = this.rondeAktif();
    if (!o || !r) return;
    this.peekBuka.delete(nomor);
    const t = this.clock.now();
    this.commit("meja", "peek", { urutan: r.urutan, nomor, sisi: o.sisi, indeks: o.indeks, masuk: o.masuk, keluar: t, t });
  }
  fokusHilang(nomor: number, durasiMs: number) {
    const r = this.rondeAktif();
    const m = this.meja(nomor);
    const a = this.cfg.anti_curang;
    if (!r || r.status !== "LIVE" || m.status !== "PLAYING" || durasiMs <= a.fokus_hilang_toleransi_ms) return;
    this.commit("meja", "fokus.hilang", { urutan: r.urutan, nomor, durasiMs, t: this.clock.now() });
    this.tandai(r.urutan, nomor, "FOKUS", m.fokus >= a.fokus_hilang_maks ? "merah" : "kuning", { kali: m.fokus, durasiMs });
  }
  private tandai(urutan: number, nomor: number, tipe: string, tingkat: Flag["tingkat"], detail: Record<string, unknown>) {
    const s = this.need();
    if (s.flags.some((f) => f.urutan === urutan && f.nomor === nomor && f.tipe === tipe && (tipe !== "FOKUS" || f.tingkat === tingkat))) return;
    this.commit("sistem", "flag.baru", { flag: { id: s.flags.length + 1, urutan, nomor, tipe, tingkat, detail, status: "baru", t: this.clock.now() } });
  }
  /** Jebakan Seed: papan lengkap yang cocok dengan solusi varian MEJA LAIN (bukan miliknya) = jejak menyalin. */
  private periksaJebakan(r: RondeState, m: Meja) {
    const so = r.soal[m.nomor];
    if (!so) return;
    const lain = new Map<number, readonly number[]>();
    for (const [no, v] of Object.entries(r.soal)) if (Number(no) !== m.nomor) lain.set(Number(no), v.puzzle.sol);
    const dari = cocokDenganSolusiLain(m.papan, so.puzzle.givens, so.puzzle.sol, lain);
    if (dari !== null) this.tandai(r.urutan, m.nomor, "JEBAKAN_SEED", "merah", { cocokDenganSolusiMeja: dari });
  }
  kunciMeja(nomor: number) {
    const r = this.butuhAktif("LIVE");
    const m = this.meja(nomor);
    if (m.status !== "PLAYING") throw new GalatTP("status_salah", "Meja tidak sedang bermain");
    this.commit("operator", "meja.kunci", { urutan: r.urutan, nomor, t: this.clock.now(), alasan: "OPERATOR" });
    this.tick();
  }
  selesaikanFlag(id: number, tindakan: "diabaikan" | "diperingatkan" | "dikunci") {
    const f = this.need().flags.find((x) => x.id === id);
    if (!f) throw new GalatTP("flag_tidak_ada");
    this.commit("operator", "flag.selesai", { id, nomor: f.nomor, tindakan, t: this.clock.now() });
    if (tindakan === "dikunci") this.tick();
  }

  // ---------- Judge, reveal, skor ----------
  private nilaiOtomatis(r: RondeState) {
    if (r.status !== "CLOSED" || this.replaying) return;
    const s = this.need();
    for (const m of s.meja) this.tutupPeek(m.nomor);
    const items = s.meja
      .filter((m) => r.soal[m.nomor])
      .map((m) => ({ nomor: m.nomor, papan: m.papan, sol: r.soal[m.nomor]!.puzzle.sol, givens: r.soal[m.nomor]!.puzzle.givens, bel: m.bel ? { t: m.bel.t } : null, bantuan: m.bantuan, validasi: m.validasi, tenggat: this.tenggatMeja(r, m) }));
    for (const m of s.meja) if (r.soal[m.nomor] && this.terbuka(r, m.nomor).every((i) => m.papan[i])) this.periksaJebakan(r, m);
    const hasil = nilaiRonde(this.cfg, s.mode, r.waktuDetik, items);
    this.commit("sistem", "ronde.nilai", { urutan: r.urutan, hasil, papanAkhir: Object.fromEntries(s.meja.map((m) => [m.nomor, m.papan.slice()])) });
  }
  private butuhHasil(): RondeState {
    const r = this.rondeAktif();
    if (!r || !r.hasil) throw new GalatTP("status_salah", "Ronde belum dinilai");
    return r;
  }
  /** Urutan reveal bawaan: peringkat terburuk dulu, juara di akhir (ketegangan). */
  urutanReveal(): number[] {
    const r = this.butuhHasil();
    return [...r.hasil!].sort((a, b) => b.peringkat - a.peringkat).map((h) => h.nomor);
  }
  pilihReveal(nomor: number) {
    const r = this.butuhHasil();
    if (r.status !== "JUDGED" && r.status !== "REVEAL") throw new GalatTP("status_salah", "Reveal hanya setelah penilaian");
    this.meja(nomor);
    this.commit("operator", "reveal.pilih", { urutan: r.urutan, nomor });
  }
  revealBerikut(): number | null {
    const r = this.butuhHasil();
    const nx = this.urutanReveal().find((n) => !r.reveal.sudah.includes(n));
    if (nx === undefined) return null;
    this.pilihReveal(nx);
    return nx;
  }
  tayangSkor() {
    const r = this.butuhHasil();
    if (r.status !== "JUDGED" && r.status !== "REVEAL") throw new GalatTP("status_salah");
    this.commit("operator", "ronde.skor", { urutan: r.urutan });
  }
  arsipkan() {
    const r = this.rondeAktif();
    if (!r || r.status !== "SCORED") throw new GalatTP("status_salah", "Tayangkan papan skor dulu");
    this.commit("operator", "ronde.arsip", { urutan: r.urutan });
  }
  koreksiSkor(nomor: number, delta: number, alasan: string) {
    const r = this.butuhHasil();
    if (!alasan.trim()) throw new GalatTP("alasan_wajib", "Alasan wajib diisi");
    this.meja(nomor);
    this.commit("operator", "skor.koreksi", { urutan: r.urutan, nomor, delta, alasan: alasan.trim(), t: this.clock.now() });
  }
  batalKoreksi() {
    const r = this.butuhHasil();
    const semua = r.hasil!.flatMap((h) => h.koreksi.map((k) => ({ nomor: h.nomor, t: k.t })));
    const akhir = semua.sort((a, b) => b.t - a.t)[0];
    if (!akhir) throw new GalatTP("tidak_ada_koreksi");
    this.commit("operator", "skor.batal", { urutan: r.urutan, nomor: akhir.nomor });
  }
  setAdegan(adegan: string | null) {
    this.need();
    this.commit("operator", "layar.adegan", { adegan });
  }
  /** Opsi "tampilkan tinggi live" hanya untuk ruang penonton terpisah; wajib konfirmasi. */
  setTinggiLive(aktif: boolean, konfirmasi: boolean) {
    this.need();
    if (aktif && !konfirmasi) throw new GalatTP("konfirmasi_wajib", "Konfirmasi peringatan dulu");
    this.commit("operator", "layar.tinggi", { aktif });
  }
  /** Meja melihat papan dirinya, sisa bantuan, dan hasil sendiri (setelah JUDGED). Tanpa solusi. */
  mejaView(nomor: number) {
    const s = this.need();
    const m = this.meja(nomor);
    const r = this.rondeAktif();
    const h = r?.hasil?.find((x) => x.nomor === nomor) ?? null;
    return {
      papan: m.papan.slice(), versi: m.versi, peringatan: m.peringatan,
      validasi: m.validasi, bisaPeriksa: s.format === "ARENA" && this.cfg.mode[s.mode].validasi,
      bantuanSisa: Math.max(0, this.cfg.mode[s.mode].bantuan_per_ronde - m.bantuan),
      bel: m.bel ? { urutan: m.bel.urutan, t: m.bel.t } : null,
      hasil: h ? { tepat: h.tepat, terbuka: h.terbuka, sempurna: h.sempurna, poin: h.poin, bintang: h.bintang, peringkat: h.peringkat, salah: h.salah, rincian: h.rincian } : null,
      total: this.klasemen().find((k) => k.nomor === nomor)?.total ?? 0,
    };
  }
  /** Kunci jawaban baru boleh keluar setelah ronde dinilai (SPEC: tombol "Lihat jawaban benar"). */
  jawaban(nomor: number): number[] {
    const r = this.rondeAktif();
    if (!r || !["JUDGED", "REVEAL", "SCORED"].includes(r.status)) throw new GalatTP("belum_boleh", "Jawaban baru terbuka setelah ronde dinilai");
    return r.soal[nomor]!.puzzle.sol.slice();
  }
  klasemen() {
    const s = this.need();
    return s.meja
      .map((m) => {
        const p = s.peserta.find((q) => q.id === m.pesertaId);
        let waktuMs = 0;
        let validasi = 0;
        const per = s.ronde.map((r) => {
          const h = r.hasil?.find((x) => x.nomor === m.nomor);
          if (!h) return null;
          validasi += h.validasi;
          waktuMs += h.belT !== null && r.startAt !== null ? h.belT - r.startAt : r.waktuDetik * 1000;
          return h.poin;
        });
        return { nomor: m.nomor, pesertaId: m.pesertaId, nama: p?.nama ?? `Meja ${m.nomor}`, avatar: p?.avatar ?? null, perRonde: per, total: per.reduce<number>((a, b) => a + (b ?? 0), 0), validasi, waktuMs };
      })
      .sort((a, b) => b.total - a.total || a.validasi - b.validasi || a.waktuMs - b.waktuMs || a.nomor - b.nomor);
  }
  /** Ringkasan untuk Gerbang Permainan (Multi Permainan / Hall of Fame). */
  ringkasan() {
    const s = this.need();
    const selesai = s.ronde.some((r) => r.hasil);
    return {
      game: "tower-peek", versi: 1, sesiId: s.id, nama: s.nama, format: s.format, mode: s.mode, selesai,
      siswa: this.klasemen().filter((k) => k.pesertaId).map((k) => ({ siswaId: k.pesertaId, nama: k.nama, skor: k.total, waktuMs: k.waktuMs })),
    };
  }

  // ---------- Snapshot operator (tanpa solusi) ----------
  snapshotOperator() {
    const s = this.sesi;
    if (!s) return { sesi: null };
    const ra = this.rondeAktif();
    return {
      sesi: { id: s.id, nama: s.nama, mode: s.mode, format: s.format, pin: s.pin, jumlahMeja: s.jumlahMeja, aktif: s.aktif },
      peserta: s.peserta,
      meja: s.meja.map((m) => ({
        nomor: m.nomor, pesertaId: m.pesertaId, nama: s.peserta.find((p) => p.id === m.pesertaId)?.nama ?? null, online: m.online, status: m.status, jeda: m.jeda, terpasang: m.tokenHash !== null, x: m.x, y: m.y,
        varianK: ra?.soal[m.nomor]?.k ?? null, persen: ra && ra.soal[m.nomor] ? this.persen(ra, m) : 0, kembar: ra && ra.soal[m.nomor] ? this.kembar(ra, m) : 0,
        belUrutan: m.bel?.urutan ?? null, belT: m.bel?.t ?? null, validasi: m.validasi, fokus: m.fokus, bantuan: m.bantuan, bendera: s.flags.filter((f) => f.nomor === m.nomor && f.status === "baru").length,
      })),
      ronde: s.ronde.map((r) => ({ urutan: r.urutan, n: r.n, waktuDetik: r.waktuDetik, kode: r.kode, dipaku: r.dipaku, status: r.status, sumber: r.sumber, pengganti: r.pengganti, startAt: r.startAt, deadline: r.deadline, ditutup: r.ditutup, hasil: r.hasil, reveal: r.reveal })),
      flags: s.flags,
      klasemen: s.ronde.some((r) => r.hasil) ? this.klasemen() : [],
      adeganManual: s.adeganManual,
      tinggiLive: s.tinggiLive,
      sorotan: s.sorotan,
      urutanReveal: ra?.hasil ? this.urutanReveal() : [],
      serverNow: this.clock.now(),
    };
  }
  lihatPapan(nomor: number) {
    const r = this.rondeAktif();
    const m = this.meja(nomor);
    if (!r || !r.soal[nomor]) throw new GalatTP("belum_ada_soal");
    return { nomor, n: r.n, papan: m.papan.slice(), dipaku: r.soal[nomor]!.puzzle.givens.slice(), petunjuk: r.soal[nomor]!.puzzle.clues };
  }
  // ---------- reducer (murni terhadap payload; dipakai juga saat replay) ----------
  private reduce(tipe: string, p: Payload) {
    const n = (k: string) => p[k] as number;
    if (tipe === "sesi.buat") {
      const modeDef = this.paket.mode[p.mode as ModeGame].ronde;
      const pos = tataMeja(n("jumlahMeja"));
      this.sesi = {
        id: p.id as string, nama: p.nama as string, mode: p.mode as ModeGame, format: p.format as FormatSesi, pin: (p.pin as string | null) ?? null, kunciRoster: p.kunciRoster as boolean, dibuat: n("t"), jumlahMeja: n("jumlahMeja"),
        peserta: p.peserta as Peserta[],
        meja: (p.format === "ARENA" ? [] : pos).map((q, i) => ({ nomor: i + 1, tokenHash: null, deviceId: null, pesertaId: (p.peserta as Peserta[])[i]?.id ?? null, online: false, status: "OFFLINE", jeda: false, jedaSejak: null, kompensasiMs: 0, ...baruMeja(), x: q.x, y: q.y })),
        ronde: modeDef.map((d) => ({ urutan: d.ronde, n: d.n, waktuDetik: d.waktu_detik, kode: d.kode, dipaku: d.jumlah_dipaku, status: "DRAFT", hasil: null, papanAkhir: null, reveal: { current: null, sudah: [] }, bel: [], sumber: null, pengganti: null, startAt: null, deadline: null, pausedAt: null, ditutup: null, soal: {} })),
        flags: [], adeganManual: null, tinggiLive: false, sorotan: p.sorotan as boolean, aktif: null,
      };
      this.pancar({ tipe: "sesi" });
      return;
    }
    const s = this.sesi;
    if (!s) return;
    const r = typeof p.urutan === "number" ? s.ronde[(p.urutan as number) - 1] : undefined;
    const m = typeof p.nomor === "number" ? s.meja[(p.nomor as number) - 1] : undefined;
    switch (tipe) {
      case "peserta.tambah": {
        const baru = p.peserta as Peserta[];
        s.peserta.push(...baru);
        const bebas = s.meja.filter((x) => !x.pesertaId);
        baru.forEach((q, i) => {
          if (bebas[i]) bebas[i]!.pesertaId = q.id;
        });
        this.pancar({ tipe: "sesi" });
        break;
      }
      case "pemain.gabung": {
        const pb = p.peserta as Peserta | null;
        if (pb) s.peserta.push(pb);
        const rr = this.rondeAktif();
        const st: StatusMeja = rr?.status === "LIVE" ? "PLAYING" : rr?.status === "COUNTDOWN" ? "COUNTDOWN" : "OFFLINE";
        s.meja.push({ nomor: n("nomor"), tokenHash: p.tokenHash as string, deviceId: null, pesertaId: p.pesertaId as string, online: false, status: st, jeda: false, jedaSejak: null, kompensasiMs: 0, ...baruMeja(), x: 0, y: 0 });
        if (rr && p.soal) {
          rr.soal[n("nomor")] = p.soal as RondeState["soal"][number];
          s.meja[s.meja.length - 1]!.papan = rr.soal[n("nomor")]!.puzzle.givens.slice();
        }
        this.pancar({ tipe: "sesi" });
        break;
      }
      case "meja.peserta":
        if (m) m.pesertaId = p.pesertaId as string | null;
        this.pancar({ tipe: "sesi" });
        break;
      case "meja.pasang":
        for (const x of p.meja as { nomor: number; tokenHash: string }[]) {
          const mm = s.meja[x.nomor - 1]!;
          mm.tokenHash = x.tokenHash;
          mm.deviceId = null;
          mm.online = false;
          if (mm.status !== "OFFLINE" && !["COUNTDOWN", "PLAYING"].includes(mm.status)) mm.status = "OFFLINE";
        }
        this.pancar({ tipe: "sesi" });
        break;
      case "meja.halo":
        if (m) {
          m.deviceId = p.deviceId as string;
          this.sinkronStatusMeja(m);
        }
        break;
      case "meja.online":
        if (m) {
          m.online = p.online as boolean;
          this.sinkronStatusMeja(m);
          this.pancar({ tipe: "meja", nomor: m.nomor });
        }
        break;
      case "ronde.muat":
        if (r) {
          r.soal = p.soal as RondeState["soal"];
          r.sumber = p.sumber as "paket" | "seed";
          r.pengganti = (p.pengganti as string | null) ?? null;
          for (const x of s.meja) Object.assign(x, baruMeja(), { papan: r.soal[x.nomor]?.puzzle.givens.slice() ?? [] });
          r.status = "LOADED";
          s.aktif = r.urutan - 1;
          for (const x of s.meja) x.status = x.online ? "READY" : "OFFLINE";
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.brief":
        if (r) {
          r.status = "BRIEFING";
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.mulai":
        if (r) {
          r.status = "COUNTDOWN";
          r.startAt = n("startAt");
          r.deadline = n("deadline");
          for (const x of s.meja) {
            x.kompensasiMs = 0;
            x.jeda = false;
            x.jedaSejak = null;
            x.status = x.online ? "COUNTDOWN" : "OFFLINE";
          }
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.live":
        if (r) {
          r.status = "LIVE";
          for (const x of s.meja) if (x.status === "COUNTDOWN") x.status = "PLAYING";
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.jeda":
        if (r) {
          r.status = "PAUSED";
          r.pausedAt = n("t");
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.lanjut":
        if (r) {
          r.status = "LIVE";
          r.deadline = (r.deadline ?? 0) + n("durasi");
          r.pausedAt = null;
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.perpanjang":
        if (r) {
          r.deadline = (r.deadline ?? 0) + n("ms");
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "meja.jeda":
        if (m) {
          m.jeda = true;
          m.jedaSejak = n("t");
          this.pancar({ tipe: "meja", nomor: m.nomor });
        }
        break;
      case "meja.lanjut":
        if (m) {
          m.jeda = false;
          m.jedaSejak = null;
          m.kompensasiMs += n("durasi");
          this.pancar({ tipe: "meja", nomor: m.nomor });
        }
        break;
      case "meja.kunci":
        if (m) {
          m.status = "TIMEOUT_LOCKED";
          this.pancar({ tipe: "meja", nomor: m.nomor });
        }
        break;
      case "papan.set":
      case "papan.bantuan":
        if (m) {
          m.papan[n("sel")] = n("tinggi");
          m.versi++;
          if (tipe === "papan.bantuan") m.bantuan++;
          else m.recent = [...m.recent.filter((q) => n("t") - q < 1000), n("t")];
          this.pancar({ tipe: "papan", nomor: m.nomor });
        }
        break;
      case "bel.tekan":
        if (m && r) {
          m.bel = { t: n("t"), tKlien: (p.tKlien as number | null) ?? null, rtt: (p.rtt as number | null) ?? null, urutan: r.bel.length + 1, sumber: p.sumber as string };
          m.status = "BELL";
          r.bel.push(m.nomor);
          this.pancar({ tipe: "meja", nomor: m.nomor });
        }
        break;
      case "fokus.hilang":
        if (m) m.fokus++;
        break;
      case "peek":
        break;
      case "flag.baru":
        s.flags.push(p.flag as Flag);
        this.pancar({ tipe: "sesi" });
        break;
      case "flag.selesai": {
        const fl = s.flags.find((q) => q.id === n("id"));
        if (fl) fl.status = p.tindakan as Flag["status"];
        if (p.tindakan === "diperingatkan" && m) m.peringatan++;
        if (p.tindakan === "dikunci" && m && m.status === "PLAYING") m.status = "TIMEOUT_LOCKED";
        this.pancar({ tipe: "meja", nomor: m?.nomor });
        break;
      }
      case "ronde.nilai":
        if (r) {
          r.hasil = p.hasil as Hasil[];
          r.papanAkhir = p.papanAkhir as Record<number, number[]>;
          r.status = "JUDGED";
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "reveal.pilih":
        if (r && m) {
          r.status = "REVEAL";
          r.reveal.current = m.nomor;
          if (!r.reveal.sudah.includes(m.nomor)) r.reveal.sudah.push(m.nomor);
          m.status = "REVEALED";
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.skor":
        if (r) {
          r.status = "SCORED";
          r.reveal.current = null;
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "ronde.arsip":
        if (r) {
          r.status = "ARCHIVED";
          s.aktif = null;
          s.adeganManual = null;
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "skor.koreksi":
        if (r?.hasil) {
          const h = r.hasil.find((q) => q.nomor === n("nomor"));
          if (h) {
            h.poin += n("delta");
            h.koreksi.push({ delta: n("delta"), alasan: p.alasan as string, t: n("t") });
            urutkan(r.hasil);
          }
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "skor.batal":
        if (r?.hasil) {
          const h = r.hasil.find((q) => q.nomor === n("nomor"));
          const k = h?.koreksi.pop();
          if (h && k) h.poin -= k.delta;
          urutkan(r.hasil);
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
      case "layar.adegan":
        s.adeganManual = (p.adegan as string | null) ?? null;
        this.pancar({ tipe: "sesi" });
        break;
      case "papan.validasi":
        if (m) {
          m.validasi++;
          m.validasiT = n("t");
          this.pancar({ tipe: "papan", nomor: m.nomor });
        }
        break;
      case "layar.sorotan":
        s.sorotan = p.aktif as boolean;
        this.pancar({ tipe: "sesi" });
        break;
      case "layar.tinggi":
        s.tinggiLive = p.aktif as boolean;
        this.pancar({ tipe: "sesi" });
        break;
      case "ronde.tutup":
        if (r) {
          r.status = "CLOSED";
          r.ditutup = { t: n("t"), alasan: p.alasan as string };
          for (const x of s.meja) {
            if (x.status === "PLAYING" || x.status === "COUNTDOWN") x.status = "TIMEOUT_LOCKED";
            x.jeda = false;
            x.jedaSejak = null;
          }
          this.pancar({ tipe: "ronde", ronde: r.urutan });
        }
        break;
    }
  }
  private sinkronStatusMeja(m: Meja) {
    const r = this.rondeAktif();
    if (m.status === "OFFLINE" && m.online) m.status = r && ["COUNTDOWN"].includes(r.status) ? "COUNTDOWN" : r?.status === "LIVE" ? "PLAYING" : "READY";
    else if (!m.online && m.status === "READY") m.status = "OFFLINE";
  }
}





// Seed Simetri: meja bersebelahan (termasuk diagonal) wajib mendapat varian simetri berbeda.
import { jumlahVarian } from "@tower-peek/shared";

export function tataMeja(jumlah: number): { x: number; y: number }[] {
  const kolom = jumlah <= 4 ? jumlah : Math.ceil(jumlah / 2);
  return Array.from({ length: jumlah }, (_, i) => ({ x: i % kolom, y: Math.floor(i / kolom) }));
}
export const bersebelahan = (a: { x: number; y: number }, b: { x: number; y: number }): boolean =>
  a !== b && Math.abs(a.x - b.x) <= 1 && Math.abs(a.y - b.y) <= 1;

/**
 * Mengembalikan k per meja (indeks 0 = meja 1). Pewarnaan pola (x mod 2, y mod 2) = 4 warna: terbukti benar untuk graf
 * "raja" (8 tetangga), sehingga tak ada dua meja bersebelahan, juga diagonal, yang bervarian sama. Papan >3×3 memakai
 * 4 varian lain untuk blok kolom berikutnya agar lebih beragam.
 */
export function tugaskanVarian(jumlah: number, n: number, simetri = true): number[] {
  if (!simetri) return new Array<number>(jumlah).fill(0);
  const K = jumlahVarian(n);
  return tataMeja(jumlah).map((q) => (q.x % 2) + 2 * (q.y % 2) + (K === 8 ? 4 * (Math.floor(q.x / 2) % 2) : 0));
}

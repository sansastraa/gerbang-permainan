import { describe, expect, it } from "vitest";
import { solve } from "@tower-peek/shared";
import { AuditLog, verifikasiRantai } from "./audit";
import { buatHarness, siapkanMeja } from "./harness";
import { GalatTP, TowerPeek } from "./service";
import { bersebelahan, tataMeja, tugaskanVarian } from "./varian";

describe("Seed Simetri: meja bersebelahan beda varian", () => {
  it("untuk 1..16 meja dan n=3..6 tak ada pasangan bersebelahan (termasuk diagonal) dengan k sama", () => {
    for (let j = 1; j <= 16; j++)
      for (const n of [3, 4, 5, 6]) {
        const k = tugaskanVarian(j, n);
        const pos = tataMeja(j);
        for (let a = 0; a < j; a++) for (let b = a + 1; b < j; b++) if (bersebelahan(pos[a]!, pos[b]!)) expect(k[a]).not.toBe(k[b]);
        expect(Math.max(...k)).toBeLessThan(n === 3 ? 4 : 8);
      }
  });
  it("papan nyata: tiap ronde paket, jawaban meja bersebelahan berbeda & tiap varian berjawaban tunggal", () => {
    for (const mode of ["SD", "CHAMPION"] as const) {
      const h = buatHarness();
      siapkanMeja(h, 16, 16, mode);
      for (const r of h.svc.need().ronde) {
        h.svc.muatRonde(r.urutan, "paket");
        const pos = tataMeja(16);
        for (let a = 0; a < 16; a++) {
          const sa = r.soal[a + 1]!.puzzle;
          expect(solve(sa.n, sa.clues, sa.givens, 2)).toEqual([sa.sol]);
          for (let b = a + 1; b < 16; b++) if (bersebelahan(pos[a]!, pos[b]!)) expect(sa.sol).not.toEqual(r.soal[b + 1]!.puzzle.sol);
        }
        // ronde berikutnya boleh dimuat setelah yang ini diarsipkan; di sini cukup reset status
        r.status = "ARCHIVED";
      }
    }
  });
});

describe("puzzle:deliver tidak memuat solusi", () => {
  it("null sebelum LIVE; sesudahnya hanya petunjuk + dipaku, tanpa kunci apa pun", () => {
    const h = buatHarness();
    siapkanMeja(h, 4);
    h.svc.muatRonde(2);
    expect(h.svc.deliver(1)).toBeNull();
    h.svc.tayangAturan(2);
    h.svc.mulai(2);
    expect(h.svc.deliver(1)).toBeNull(); // hitung mundur: papan masih tertutup
    h.clock.advance(5000);
    const dl = h.svc.deliver(1)!;
    expect(Object.keys(dl).sort()).toEqual(["aturan", "dipaku", "n", "petunjuk", "rondeUrutan", "waktuDetik"]);
    const sol = h.svc.ronde(2).soal[1]!.puzzle.sol;
    const json = JSON.stringify(dl);
    expect(json).not.toMatch(/sol/i);
    expect(json).not.toContain(JSON.stringify(sol));
    // menara dipaku adalah bagian dari solusi, tetapi bukan seluruhnya
    expect(dl.dipaku.filter(Boolean).length).toBe(5);
    // snapshot operator juga tak membawa solusi
    expect(JSON.stringify(h.svc.snapshotOperator())).not.toMatch(/"sol"|solusi/);
  });
});

describe("Round Controller + Clock", () => {
  it("alur lengkap: hitung mundur 5 dtk → LIVE → jeda/lanjut → perpanjang → tenggat mengunci semua", () => {
    const h = buatHarness();
    siapkanMeja(h, 3);
    const r = h.svc.muatRonde(1);
    expect(r.status).toBe("LOADED");
    h.svc.tayangAturan(1);
    const t0 = h.clock.now();
    const j = h.svc.mulai(1);
    expect(j.startAt).toBe(t0 + 5000);
    expect(j.deadline).toBe(t0 + 5000 + 180_000);
    expect(r.status).toBe("COUNTDOWN");
    h.clock.advance(4999);
    expect(r.status).toBe("COUNTDOWN");
    h.clock.advance(2);
    expect(r.status).toBe("LIVE");
    expect(h.svc.need().meja.every((m) => m.status === "PLAYING")).toBe(true);
    // jeda 20 detik menggeser tenggat
    h.clock.advance(10_000);
    h.svc.jeda();
    h.clock.advance(20_000);
    expect(r.status).toBe("PAUSED");
    h.svc.lanjut();
    expect(r.deadline).toBe(t0 + 5000 + 180_000 + 20_000);
    h.svc.perpanjang(30);
    expect(r.deadline).toBe(t0 + 5000 + 180_000 + 50_000);
    // jeda meja 2 selama 15 detik = kompensasi 15 detik hanya untuk meja 2
    h.svc.jedaMeja(2);
    h.clock.advance(15_000);
    h.svc.lanjutMeja(2);
    expect(h.svc.meja(2).kompensasiMs).toBe(15_000);
    // maju sampai tenggat umum: meja 1 & 3 terkunci, meja 2 masih punya 15 dtk
    h.clock.advance(r.deadline! - h.clock.now() + 2);
    expect(h.svc.meja(1).status).toBe("TIMEOUT_LOCKED");
    expect(h.svc.meja(3).status).toBe("TIMEOUT_LOCKED");
    expect(h.svc.meja(2).status).toBe("PLAYING");
    expect(r.status).toBe("LIVE");
    h.clock.advance(15_000);
    expect(h.svc.meja(2).status).toBe("TIMEOUT_LOCKED");
    expect(r.status).toBe("JUDGED"); // ditutup lalu dinilai otomatis
    expect(r.ditutup?.alasan).toBe("SEMUA_SELESAI");
  });
  it("operator menutup ronde: meja yang masih bermain terkunci; aksi di status salah ditolak", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    expect(() => h.svc.mulai(1)).toThrow(GalatTP);
    h.svc.muatRonde(1);
    h.svc.mulai(1);
    h.clock.advance(6000);
    h.svc.tutup();
    expect(h.svc.ronde(1).status).toBe("JUDGED");
    expect(h.svc.need().meja.every((m) => m.status === "TIMEOUT_LOCKED")).toBe(true);
    expect(() => h.svc.jeda()).toThrow(GalatTP);
    expect(() => h.svc.muatRonde(2)).toThrow(/belum selesai/); // ronde 1 harus ditayangkan skornya & diarsipkan dulu
  });
  it("tidak bisa mulai tanpa meja online; ronde lain tak bisa dimuat saat ronde berjalan", () => {
    const h = buatHarness();
    siapkanMeja(h, 2, 0);
    h.svc.muatRonde(1);
    expect(() => h.svc.mulai(1)).toThrow(/meja/i);
    h.svc.setOnline(1, true);
    expect(() => h.svc.mulai(1)).not.toThrow();
    expect(() => h.svc.muatRonde(2)).toThrow(GalatTP);
  });
});

describe("Session Manager", () => {
  it("token meja: perangkat kedua ditolak; token baru ('pindahkan meja') memindahkan perangkat", () => {
    const h = buatHarness();
    const tok = siapkanMeja(h, 2);
    expect(() => h.svc.halo(tok[0]!.token, "perangkat-lain-1")).toThrow(/perangkat lain/);
    expect(() => h.svc.halo("salah-salah-salah", "dev-1-xxxx")).toThrow(GalatTP);
    const baru = h.svc.pasangMeja(1)[0]!;
    expect(h.svc.halo(baru.token, "perangkat-lain-1").nomor).toBe(1);
    expect(() => h.svc.halo(tok[0]!.token, "dev-1-xxxx")).toThrow(GalatTP); // token lama mati
  });
  it("token tidak disimpan polos: state & audit hanya memuat hash", () => {
    const h = buatHarness();
    const tok = siapkanMeja(h, 2);
    const semua = JSON.stringify(h.svc.audit.entri) + JSON.stringify(h.svc.sesi);
    for (const t of tok) expect(semua).not.toContain(t.token);
  });
});

describe("Audit log & pemulihan server", () => {
  it("rantai hash sah; state pulih persis setelah restart (ronde LIVE tetap berjalan dan terkunci tepat waktu)", () => {
    const h = buatHarness();
    siapkanMeja(h, 3);
    h.svc.muatRonde(1);
    h.svc.mulai(1);
    h.clock.advance(60_000);
    expect(verifikasiRantai(h.svc.audit.entri).sah).toBe(true);
    const before = JSON.stringify(h.svc.sesi);
    h.svc.audit.tutup();
    const svc2 = new TowerPeek(h.cfg, h.svc.paket, h.clock, new AuditLog(h.berkas));
    const s2 = JSON.parse(JSON.stringify(svc2.sesi)) as { meja: { online: boolean }[] };
    const s1 = JSON.parse(before) as { meja: { online: boolean }[] };
    s1.meja.forEach((m) => (m.online = false));
    expect(s2).toEqual(s1);
    h.clock.advance(110_000);
    expect(svc2.ronde(1).status).toBe("LIVE"); // meja offline setelah restart tetap bermain sampai tenggat
    h.clock.advance(20_000);
    expect(svc2.ronde(1).status).toBe("JUDGED");
    svc2.audit.tutup();
  });
  it("berkas yang diubah terdeteksi", async () => {
    const fs = await import("node:fs");
    const h = buatHarness();
    siapkanMeja(h, 2);
    h.svc.audit.tutup();
    const teks = fs.readFileSync(h.berkas, "utf8").replace("Uji", "Curang");
    fs.writeFileSync(h.berkas, teks);
    expect(() => new AuditLog(h.berkas)).toThrow(/rusak/);
  });
});



describe("Format ARENA (game biasa, sampai 40 pemain)", () => {
  const buatArena = (peserta?: { id: string; nama: string }[]) => {
    const h = buatHarness();
    h.svc.buatSesi({ nama: "Arena 5B", mode: "SD", format: "ARENA", ...(peserta ? { peserta } : {}) });
    return { h, pin: h.svc.need().pin! };
  };
  it("40 pemain masuk dengan PIN; ke-41 ditolak; nama kembar & PIN salah ditolak", () => {
    const { h, pin } = buatArena();
    expect(pin).toMatch(/^\d{6}$/);
    expect(() => h.svc.gabung("000000", { deviceId: "dev-xxxx", nama: "A" })).toThrow(/PIN/);
    for (let i = 1; i <= 40; i++) h.svc.gabung(pin, { deviceId: `dev-${i}-aaaa`, nama: `Anak ${i}` });
    expect(h.svc.need().meja).toHaveLength(40);
    expect(() => h.svc.gabung(pin, { deviceId: "dev-41-aaaa", nama: "Anak 41" })).toThrow(/penuh/);
    expect(() => h.svc.gabung(pin, { deviceId: "perangkat-lain", nama: "anak 7" })).toThrow(/dipakai/);
    expect(() => h.svc.pasangMeja()).toThrow(/arena/i);
  });
  it("papan unik per pemain, berjawaban tunggal; deliver tanpa solusi; pemain yang telat masuk tetap dapat papan", () => {
    const { h, pin } = buatArena();
    const toks = Array.from({ length: 12 }, (_, i) => h.svc.gabung(pin, { deviceId: `dev-${i + 1}-aaaa`, nama: `Anak ${i + 1}` }));
    toks.forEach((t, i) => {
      h.svc.halo(t.token, `dev-${i + 1}-aaaa`);
      h.svc.setOnline(t.nomor, true);
    });
    const r = h.svc.muatRonde(3);
    const sols = new Set(Object.values(r.soal).map((x) => x.puzzle.sol.join()));
    expect(sols.size).toBe(12);
    for (const x of Object.values(r.soal)) expect(solve(x.puzzle.n, x.puzzle.clues, x.puzzle.givens, 2)).toEqual([x.puzzle.sol]);
    h.svc.mulai(3);
    h.clock.advance(5000);
    const telat = h.svc.gabung(pin, { deviceId: "dev-telat-aaaa", nama: "Telat" });
    h.svc.halo(telat.token, "dev-telat-aaaa");
    h.svc.setOnline(telat.nomor, true);
    expect(h.svc.meja(telat.nomor).status).toBe("PLAYING");
    const dl = h.svc.deliver(telat.nomor)!;
    expect(JSON.stringify(dl)).not.toMatch(/sol/i);
    expect(dl.dipaku.filter(Boolean)).toHaveLength(8);
  });
  it("sesi dengan daftar peserta mengunci pilihan nama; perangkat sama boleh masuk ulang; pulih setelah restart", () => {
    const { h, pin } = buatArena([{ id: "s1", nama: "Rina" }, { id: "s2", nama: "Budi" }]);
    expect(h.svc.infoGabung(pin).bebas.map((p) => p.id)).toEqual(["s1", "s2"]);
    expect(() => h.svc.gabung(pin, { deviceId: "dev-1-aaaa", nama: "Orang Asing" })).toThrow(/daftar/);
    const a = h.svc.gabung(pin, { deviceId: "dev-1-aaaa", pesertaId: "s1" });
    h.svc.halo(a.token, "dev-1-aaaa");
    const a2 = h.svc.gabung(pin, { deviceId: "dev-1-aaaa", pesertaId: "s1" });
    expect(a2.nomor).toBe(a.nomor);
    expect(() => h.svc.halo(a.token, "dev-1-aaaa")).toThrow(GalatTP); // token lama mati
    expect(h.svc.infoGabung(pin).bebas.map((p) => p.id)).toEqual(["s2"]);
    h.svc.audit.tutup();
    const svc2 = new TowerPeek(h.cfg, h.svc.paket, h.clock, new AuditLog(h.berkas));
    expect(svc2.need().meja).toHaveLength(1);
    expect(svc2.need().pin).toBe(pin);
    svc2.audit.tutup();
  });
});

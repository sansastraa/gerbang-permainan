// Statistik & analitik spasial (SPEC §9), dihitung dari audit log (moves/peeks/bells) + hasil.
import { SIDES, lineCells, transformGrid } from "@tower-peek/shared";
import type { AuditEntry } from "./audit";

export interface Indikator {
  nomor: number;
  ketepatan: number;
  efisiensi: number | null;
  tepatPercobaanPertama: number | null;
  pengintip: { jumlah: number; durasiMs: number };
  strategiPatokan: number; // dari 5 isian pertama, berapa yang petak "pasti"
  kembarDibuat: number;
  waktuBelDetik: number | null;
  aksiIsi: number;
}
interface P { urutan: number; nomor: number; sel?: number; tinggi?: number; sumber?: string; t?: number; masuk?: number; keluar?: number }

/** Petak "pasti" (angka 1 → menara tertinggi; angka N → urut 1..N): peta sel → nilai. */
export function petakPasti(n: number, clues: Record<string, number[]>): Map<number, number> {
  const m = new Map<number, number>();
  for (const sisi of SIDES) {
    for (let i = 0; i < n; i++) {
      const c = clues[sisi]![i]!;
      const sel = lineCells(n, sisi, i);
      if (c === 1) m.set(sel[0]!, n);
      if (c === n) sel.forEach((s, k) => m.set(s, k + 1));
    }
  }
  return m;
}

export function indikatorMeja(a: { n: number; nomor: number; urutan: number; sol: readonly number[]; givens: readonly number[]; clues: Record<string, number[]>; entri: readonly AuditEntry[]; mulai: number; belT: number | null; tepat: number; terbuka: number }): Indikator {
  const mine = a.entri.filter((e) => (e.payload as P).urutan === a.urutan && (e.payload as P).nomor === a.nomor);
  const sets = mine.filter((e) => e.tipe === "papan.set" || e.tipe === "papan.bantuan").map((e) => ({ ...(e.payload as P), tipe: e.tipe }));
  const isi = sets.filter((s) => s.tipe === "papan.set" && (s.tinggi ?? 0) > 0);
  const pernah = new Set<number>();
  let pertamaBenar = 0;
  let pertama = 0;
  for (const s of isi) {
    if (pernah.has(s.sel!)) continue;
    pernah.add(s.sel!);
    pertama++;
    if (a.sol[s.sel!] === s.tinggi) pertamaBenar++;
  }
  const pasti = petakPasti(a.n, a.clues);
  const lima = isi.filter((s, i) => isi.findIndex((x) => x.sel === s.sel) === i).slice(0, 5);
  const strategi = lima.filter((s) => pasti.get(s.sel!) === s.tinggi).length;
  // kembar dibuat: ulang papan dari awal, hitung isian yang menciptakan tinggi kembar di baris/kolom
  const papan = a.givens.slice();
  let kembar = 0;
  const n = a.n;
  for (const s of sets) {
    if (s.tipe !== "papan.set" || !s.tinggi) {
      if (s.sel !== undefined) papan[s.sel] = s.tinggi ?? 0;
      continue;
    }
    const r = Math.floor(s.sel! / n);
    const c = s.sel! % n;
    let dup = false;
    for (let k = 0; k < n; k++) {
      if (k !== c && papan[r * n + k] === s.tinggi) dup = true;
      if (k !== r && papan[k * n + c] === s.tinggi) dup = true;
    }
    if (dup) kembar++;
    papan[s.sel!] = s.tinggi;
  }
  const peeks = mine.filter((e) => e.tipe === "peek").map((e) => e.payload as P);
  return {
    nomor: a.nomor,
    ketepatan: a.terbuka ? a.tepat / a.terbuka : 1,
    efisiensi: isi.length ? Math.min(1, a.terbuka / isi.length) : null,
    tepatPercobaanPertama: pertama ? pertamaBenar / pertama : null,
    pengintip: { jumlah: peeks.length, durasiMs: peeks.reduce((x, p) => x + Math.max(0, (p.keluar ?? p.masuk ?? 0) - (p.masuk ?? 0)), 0) },
    strategiPatokan: strategi,
    kembarDibuat: kembar,
    waktuBelDetik: a.belT === null ? null : Math.round((a.belT - a.mulai) / 100) / 10,
    aksiIsi: isi.length,
  };
}

/** Heatmap kesalahan per petak dalam kerangka soal dasar (varian dipetakan balik). */
export function petaPanas(n: number, items: { k: number; salah: readonly number[] }[]): number[] {
  const idx = Array.from({ length: n * n }, (_, i) => i);
  const heat = new Array<number>(n * n).fill(0);
  for (const it of items) {
    const peta = transformGrid(n, idx, it.k); // posisi p pada varian ← sel dasar peta[p]
    for (const p of it.salah) heat[peta[p]!]!++;
  }
  return heat;
}
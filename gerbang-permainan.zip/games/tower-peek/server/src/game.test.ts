import { describe, expect, it } from "vitest";
import { solve } from "@tower-peek/shared";
import { susunAdegan } from "./director";
import { ekspor, replay, statistik } from "./laporan";
import { buatHarness, siapkanMeja } from "./harness";
import type { Harness } from "./harness";
import { nilaiRonde } from "./judge";
import { GalatTP } from "./service";

/** Murid ber-bot: memecahkan papan HANYA dari data puzzle:deliver (petunjuk + dipaku) memakai engine. */
function pecahkan(h: Harness, nomor: number, benar = true): number[] {
  const dl = h.svc.deliver(nomor)!;
  const s = solve(dl.n, dl.petunjuk, dl.dipaku, 2);
  expect(s).toHaveLength(1);
  const sol = s[0]!;
  const dipaku = dl.dipaku;
  sol.forEach((v, i) => {
    if (dipaku[i]) return;
    h.svc.setPapan(nomor, i, benar ? v : (v % dl.n) + 1, h.svc.meja(nomor).versi, "kuas");
  });
  return sol;
}
const mulaiLive = (h: Harness, urutan = 1) => {
  h.svc.muatRonde(urutan);
  h.svc.mulai(urutan);
  h.clock.advance(5000);
};

describe("Judge: contoh dokumen SPEC §2.5", () => {
  const cfg = buatHarness().cfg;
  const mk = (nomor: number, tepatSemua: boolean, belT: number | null, bantuan = 0, salahN = 0) => {
    const sol = [1, 2, 3, 2, 3, 1, 3, 1, 2];
    const givens = [0, 0, 0, 0, 0, 0, 0, 0, 0];
    const papan = sol.slice();
    for (let i = 0; i < salahN; i++) papan[i] = (sol[i]! % 3) + 1;
    return { nomor, papan: tepatSemua ? sol : papan, sol, givens, bel: belT === null ? null : { t: belT }, bantuan, tenggat: 1000_000 };
  };
  it("SD: sempurna, sisa 50%, bel pertama = 100 + 25 + 30 = 155, ★★★; bel ke-2/3 +20/+10; bantuan −25 ★★", () => {
    const h = nilaiRonde(cfg, "SD", 200, [mk(1, true, 900_000), mk(2, true, 880_000, 1), mk(3, true, 950_000)]);
    const by = (n: number) => h.find((x) => x.nomor === n)!;
    expect(by(2).poin).toBe(Math.round(100 + 50 * (120_000 / 200_000) + 30 - 25)); // bel pertama, dengan 1 bantuan
    expect(by(2).bintang).toBe(2);
    expect(by(1).poin).toBe(Math.round(100 + 50 * (100_000 / 200_000) + 20)); // bel kedua
    expect(by(1).bintang).toBe(3);
    expect(by(3).poin).toBe(Math.round(100 + 50 * (50_000 / 200_000) + 10)); // bel ketiga
  });
  it("SD: nilai sebagian 80 × tepat ÷ terbuka dibulatkan ke atas (1 petak tepat tetap dapat poin); ★ bila ≥70%; tanpa bel tidak ada bonus", () => {
    const h = nilaiRonde(cfg, "SD", 200, [mk(1, false, null, 0, 2), mk(2, false, 1, 0, 6)]);
    expect(h[0]!.poin).toBe(Math.ceil(80 * (7 / 9)));
    expect(h[0]!.bintang).toBe(1); // 7/9 = 77%
    expect(h[1]!.poin).toBe(Math.ceil(80 * (3 / 9)));
    const satu = nilaiRonde(cfg, "SD", 200, [mk(1, false, null, 0, 8)]);
    expect(satu[0]!.tepat).toBe(1);
    expect(satu[0]!.poin).toBeGreaterThanOrEqual(1); // satu petak benar tidak boleh bernilai nol
    expect(h[1]!.bintang).toBe(0);
  });
  it("Champion: papan benar 10,8,6… menurut urutan bel; benar tanpa bel = terendah × 0,5; belum sempurna = poin sebagian kecil; seri → waktu bel", () => {
    const h = nilaiRonde(cfg, "CHAMPION", 200, [mk(1, true, 100), mk(2, true, 90), mk(3, false, 80, 0, 1), mk(4, true, null), mk(5, true, 100)]);
    const by = (n: number) => h.find((x) => x.nomor === n)!;
    expect(by(2).poin).toBe(10);
    expect(by(1).poin).toBe(8); // t=100, nomor lebih kecil menang seri milidetik yang sama
    expect(by(5).poin).toBe(6);
    expect(by(3).poin).toBeCloseTo(0.45 * (8 / 9), 2); // salah satu petak: tetap dapat poin sebagian, di bawah papan benar mana pun
    expect(by(3).poin).toBeLessThan(0.5);
    expect(by(4).poin).toBe(0.5);
    expect(by(2).peringkat).toBe(1);
  });
});

describe("Meja Jawab di server: papan, bantuan, bel", () => {
  it("murid memecahkan dari puzzle:deliver; bel mengunci; papan beku; ronde tutup & dinilai otomatis ketika semua bel", () => {
    const h = buatHarness();
    siapkanMeja(h, 3);
    mulaiLive(h, 2);
    pecahkan(h, 1);
    h.clock.advance(1000);
    const bel = h.svc.tekanBel(1, { sumber: "tombol" });
    expect(bel.urutan).toBe(1);
    expect(h.svc.meja(1).status).toBe("BELL");
    expect(() => h.svc.setPapan(1, 0, 1, 0)).toThrow(GalatTP); // beku
    expect(() => h.svc.tekanBel(1)).toThrow(GalatTP); // bel hanya sekali
    h.clock.advance(500);
    pecahkan(h, 2, false);
    h.svc.tekanBel(2);
    expect(h.svc.ronde(2).status).toBe("LIVE"); // meja 3 masih bermain
    h.svc.tutup();
    const r = h.svc.ronde(2);
    expect(r.status).toBe("JUDGED");
    const by = (n: number) => r.hasil!.find((x) => x.nomor === n)!;
    expect(by(1).sempurna).toBe(true);
    expect(by(1).bintang).toBe(3);
    expect(by(1).peringkat).toBe(1);
    expect(by(2).sempurna).toBe(false);
    expect(by(3).poin).toBe(0);
  });
  it("bantuan: satu per ronde (SD), memperbaiki petak salah dulu, biaya 25; Champion tak punya bantuan", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    mulaiLive(h, 1);
    const sol = pecahkan(h, 1, false);
    const res = h.svc.mintaBantuan(1);
    expect(res.papan[res.sel]).toBe(sol[res.sel]);
    expect(() => h.svc.mintaBantuan(1)).toThrow(/habis/);
    const h2 = buatHarness();
    siapkanMeja(h2, 2, 2, "CHAMPION");
    mulaiLive(h2, 1);
    expect(() => h2.svc.mintaBantuan(1)).toThrow(/habis/);
  });
  it("papan yang dipaku tidak bisa diubah; aksi setelah tenggat/jeda ditolak; kompensasi jeda meja berlaku", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    mulaiLive(h, 1);
    const dl = h.svc.deliver(1)!;
    const pakuIdx = dl.dipaku.findIndex(Boolean);
    expect(h.svc.setPapan(1, pakuIdx, 1, 0).ok).toBe(false);
    h.svc.jedaMeja(1);
    expect(() => h.svc.setPapan(1, 0, 1, 0)).toThrow(GalatTP);
    h.svc.lanjutMeja(1);
    h.clock.advance(181_000);
    expect(() => h.svc.setPapan(1, 0, 1, 0)).toThrow(GalatTP);
  });
  it("hasil sendiri dan jawaban benar baru terbuka setelah ronde dinilai", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    mulaiLive(h, 1);
    expect(() => h.svc.jawaban(1)).toThrow(/dinilai/);
    expect(h.svc.mejaView(1).hasil).toBeNull();
    h.svc.tutup();
    expect(h.svc.jawaban(1)).toHaveLength(9);
    expect(h.svc.mejaView(1).hasil).not.toBeNull();
  });
});

describe("Layar Siswa: sensor (tidak ada tinggi menara peserta selama LIVE)", () => {
  const kunci = (o: unknown, hit: string[] = []): string[] => {
    if (Array.isArray(o)) o.forEach((x) => kunci(x, hit));
    else if (o && typeof o === "object") for (const [k, v] of Object.entries(o)) {
        hit.push(k);
        kunci(v, hit);
      }
    return hit;
  };
  it("payload /layar identik untuk papan berbeda-tinggi tetapi pola terisi sama; tanpa kunci papan/sol", () => {
    const hasil: string[] = [];
    for (const salah of [false, true]) {
      const h = buatHarness();
      siapkanMeja(h, 4);
      mulaiLive(h, 3);
      for (const no of [1, 2, 3, 4]) pecahkan(h, no, !salah);
      const a = susunAdegan(h.svc);
      expect(a.adegan).toBe("live");
      const k = kunci(a);
      expect(k).not.toContain("papan");
      expect(k).not.toContain("sol");
      expect(k).not.toContain("solusi");
      expect(k).not.toContain("tinggi");
      const j = JSON.parse(JSON.stringify(a.data)) as { serverNow?: number; meja: { persen: number }[] };
      delete j.serverNow;
      hasil.push(JSON.stringify(j));
      // setelah bel & tutup, sebelum reveal tetap tidak ada papan
      h.svc.tekanBel(1);
      h.svc.tutup();
      expect(kunci(susunAdegan(h.svc))).not.toContain("papan");
    }
    expect(hasil[0]).toBe(hasil[1]);
  });
  it("reveal membuka papan satu meja saja, dan hanya setelah JUDGED; urutan bawaan: peringkat terburuk dulu", () => {
    const h = buatHarness();
    siapkanMeja(h, 3);
    mulaiLive(h, 2);
    pecahkan(h, 1);
    h.clock.advance(100);
    h.svc.tekanBel(1);
    h.svc.tutup();
    expect(susunAdegan(h.svc).adegan).toBe("live");
    h.svc.setAdegan("reveal");
    expect(kunci(susunAdegan(h.svc))).not.toContain("papan"); // belum ada meja yang dibuka
    expect(h.svc.urutanReveal().at(-1)).toBe(1); // juara di akhir
    const pertama = h.svc.revealBerikut()!;
    expect(pertama).not.toBe(1);
    const a = susunAdegan(h.svc);
    expect(a.adegan).toBe("reveal");
    expect((a.data as { nomor: number }).nomor).toBe(pertama);
    h.svc.setAdegan(null);
    h.svc.tayangSkor();
    expect(susunAdegan(h.svc).adegan).toBe("skor");
    h.svc.arsipkan();
    expect(() => h.svc.muatRonde(3)).not.toThrow();
  });
  it("tinggi live butuh konfirmasi", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    expect(() => h.svc.setTinggiLive(true, false)).toThrow(/Konfirmasi/);
    expect(() => h.svc.setTinggiLive(true, true)).not.toThrow();
  });
});

describe("Anti-curang & audit", () => {
  it("Jebakan Seed: papan yang menyalin solusi meja tetangga terdeteksi (bendera merah)", () => {
    const h = buatHarness();
    siapkanMeja(h, 4);
    mulaiLive(h, 2);
    const solTetangga = h.svc.ronde(2).soal[2]!.puzzle.sol; // pelaku (meja 1) mengintip papan meja 2
    const dl = h.svc.deliver(1)!;
    solTetangga.forEach((v, i) => {
      if (!dl.dipaku[i]) h.svc.setPapan(1, i, v, h.svc.meja(1).versi);
    });
    const f = h.svc.need().flags.filter((x) => x.tipe === "JEBAKAN_SEED");
    expect(f).toHaveLength(1);
    expect(f[0]!.nomor).toBe(1);
    expect(f[0]!.tingkat).toBe("merah");
    // meja jujur tidak diberi bendera
    pecahkan(h, 3);
    expect(h.svc.need().flags.some((x) => x.nomor === 3 && x.tipe === "JEBAKAN_SEED")).toBe(false);
  });
  it("fokus hilang: 1× kuning, 2× merah; di bawah toleransi diabaikan; papan instan; tindakan operator", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    mulaiLive(h, 3);
    h.svc.fokusHilang(1, 1000);
    expect(h.svc.need().flags).toHaveLength(0);
    h.svc.fokusHilang(1, 2000);
    h.svc.fokusHilang(1, 2500);
    const fo = h.svc.need().flags.filter((x) => x.tipe === "FOKUS");
    expect(fo.map((x) => x.tingkat)).toEqual(["kuning", "merah"]);
    pecahkan(h, 2); // semua petak terbuka dalam hitungan milidetik jam terkendali
    expect(h.svc.need().flags.some((x) => x.tipe === "PAPAN_INSTAN" && x.nomor === 2)).toBe(true);
    h.svc.selesaikanFlag(fo[1]!.id, "dikunci");
    expect(h.svc.meja(1).status).toBe("TIMEOUT_LOCKED");
  });
  it("satu perangkat dua meja ditandai", () => {
    const h = buatHarness();
    h.svc.buatSesi({ nama: "x", mode: "SD", jumlahMeja: 2 });
    const t = h.svc.pasangMeja();
    h.svc.halo(t[0]!.token, "perangkat-sama");
    h.svc.halo(t[1]!.token, "perangkat-sama");
    expect(h.svc.need().flags.filter((f) => f.tipe === "PERANGKAT_GANDA")).toHaveLength(2);
  });
  it("koreksi poin wajib beralasan, masuk audit, bisa dibatalkan; replay memuat langkah", () => {
    const h = buatHarness();
    siapkanMeja(h, 2);
    mulaiLive(h, 1);
    pecahkan(h, 1);
    h.svc.tekanBel(1);
    h.svc.tutup();
    const awal = h.svc.ronde(1).hasil!.find((x) => x.nomor === 1)!.poin;
    expect(() => h.svc.koreksiSkor(1, 5, "  ")).toThrow(/Alasan/);
    h.svc.koreksiSkor(1, 7, "Salah klik layar");
    expect(h.svc.ronde(1).hasil!.find((x) => x.nomor === 1)!.poin).toBe(awal + 7);
    expect(h.svc.audit.entri.some((e) => e.tipe === "skor.koreksi" && JSON.stringify(e.payload).includes("Salah klik"))).toBe(true);
    h.svc.batalKoreksi();
    expect(h.svc.ronde(1).hasil!.find((x) => x.nomor === 1)!.poin).toBe(awal);
    const rp = replay(h.svc, 1);
    expect(rp.entri.filter((e) => e.tipe === "papan.set").length).toBeGreaterThan(5);
  });
});

describe("Statistik & ekspor", () => {
  it("indikator, heatmap kerangka dasar, CSV, ringkasan Gerbang", () => {
    const h = buatHarness();
    siapkanMeja(h, 4);
    mulaiLive(h, 2);
    pecahkan(h, 1);
    pecahkan(h, 2, false);
    h.svc.bukaPeek(1, "top", 0);
    h.clock.advance(2000);
    h.svc.tutupPeek(1);
    h.svc.tekanBel(1);
    h.svc.tutup();
    const st = statistik(h.svc, 2);
    const i1 = st.indikator.find((x) => x.nomor === 1)!;
    expect(i1.ketepatan).toBe(1);
    expect(i1.tepatPercobaanPertama).toBe(1);
    expect(i1.pengintip.jumlah).toBe(1);
    expect(i1.pengintip.durasiMs).toBe(2000);
    expect(st.indikator.find((x) => x.nomor === 2)!.ketepatan).toBeLessThan(1);
    expect(st.petaPanas.reduce((a, b) => a + b, 0)).toBeGreaterThan(0);
    const e = ekspor(h.svc);
    expect(e.csv.split("\n")[0]).toContain("pengintip_kali");
    expect(e.csv.trim().split("\n")).toHaveLength(5);
    const rg = h.svc.ringkasan();
    expect(rg.game).toBe("tower-peek");
    expect(rg.siswa).toHaveLength(4);
    expect(rg.siswa[0]!.skor).toBeGreaterThan(0);
  });
});
describe("ARENA: sorotan 3D bergilir, papan peringkat langsung, tombol Periksa", () => {
  const arena = (n = 5) => {
    const h = buatHarness();
    h.svc.buatSesi({ nama: "Arena", mode: "SD", format: "ARENA" });
    const pin = h.svc.need().pin!;
    const toks = Array.from({ length: n }, (_, i) => h.svc.gabung(pin, { deviceId: `dev-${i + 1}-aaaa`, nama: `Anak ${i + 1}` }));
    toks.forEach((t, i) => {
      h.svc.halo(t.token, `dev-${i + 1}-aaaa`);
      h.svc.setOnline(t.nomor, true);
    });
    return h;
  };
  const hitungPapan = (o: unknown): number => JSON.stringify(o).split('"papan"').length - 1;
  it("sorotan: tepat SATU papan di payload /layar, berganti tiap 10 detik, ikut mengisi secara langsung", () => {
    const h = arena(4);
    mulaiLive(h, 3);
    const a1 = susunAdegan(h.svc).data as { sorotan: { nomor: number; papan: number[]; sisaDetik: number; dari: number } };
    expect(hitungPapan(susunAdegan(h.svc))).toBe(1);
    expect(a1.sorotan.dari).toBe(4);
    const pertama = a1.sorotan.nomor;
    pecahkan(h, pertama);
    expect((susunAdegan(h.svc).data as { sorotan: { papan: number[] } }).sorotan.papan.every(Boolean)).toBe(true);
    h.clock.advance(10_000);
    const a2 = (susunAdegan(h.svc).data as { sorotan: { nomor: number } }).sorotan.nomor;
    expect(a2).not.toBe(pertama);
    expect(hitungPapan(susunAdegan(h.svc))).toBe(1);
  });
  it("Kompetisi: sorotan mati bawaan; menyalakannya butuh konfirmasi", () => {
    const h = buatHarness();
    siapkanMeja(h, 3);
    mulaiLive(h, 3);
    expect(hitungPapan(susunAdegan(h.svc))).toBe(0);
    expect(() => h.svc.setSorotan(true, false)).toThrow(/Konfirmasi/);
    h.svc.setSorotan(true, true);
    expect(hitungPapan(susunAdegan(h.svc))).toBe(1);
  });
  it("papan peringkat langsung memuat skor sementara; Periksa menghitung validasi dan memecah seri", () => {
    const h = arena(3);
    mulaiLive(h, 2);
    pecahkan(h, 1);
    const live = susunAdegan(h.svc).data as { peringkat: { nomor: number; skorRonde: number; validasi: number }[] };
    expect(live.peringkat[0]!.nomor).toBe(1);
    expect(live.peringkat[0]!.skorRonde).toBeGreaterThan(live.peringkat[1]!.skorRonde);
    h.clock.advance(2000);
    const p = h.svc.periksa(2);
    expect(p.validasi).toBe(1);
    expect(p.sempurna).toBe(false);
    expect(() => h.svc.periksa(2)).toThrow(/Tunggu/); // jeda antar-pemeriksaan
    h.clock.advance(2000);
    h.svc.periksa(2);
    pecahkan(h, 3);
    h.clock.advance(1500);
    h.svc.periksa(3);
    h.svc.tekanBel(1);
    h.svc.tekanBel(3);
    h.svc.tutup();
    const hs = h.svc.ronde(2).hasil!;
    expect(hs.find((x) => x.nomor === 2)!.validasi).toBe(2);
    expect(hs.find((x) => x.nomor === 3)!.validasi).toBe(1);
    expect(hs.find((x) => x.nomor === 1)!.peringkat).toBeLessThan(hs.find((x) => x.nomor === 3)!.peringkat); // validasi lebih sedikit menang seri
    expect(h.svc.klasemen().find((k) => k.nomor === 2)!.validasi).toBe(2);
    const hk = buatHarness();
    siapkanMeja(hk, 2);
    mulaiLive(hk, 1);
    expect(() => hk.svc.periksa(1)).toThrow(/tidak tersedia/); // Kompetisi tanpa Periksa
  });
});
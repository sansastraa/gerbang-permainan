// Jam server yang bisa disuntik: tes memakai ManualClock sehingga hitung mundur/tenggat deterministik.
export interface Clock {
  now(): number;
  setTimeout(fn: () => void, ms: number): () => void;
}
export const realClock: Clock = {
  now: () => Date.now(),
  setTimeout(fn, ms) {
    const h = setTimeout(fn, Math.max(0, Math.min(ms, 2 ** 31 - 1)));
    return () => clearTimeout(h);
  },
};
export class ManualClock implements Clock {
  private t: number;
  private q: { at: number; fn: () => void; id: number; off: boolean }[] = [];
  private seq = 0;
  constructor(start = 1_700_000_000_000) {
    this.t = start;
  }
  now(): number {
    return this.t;
  }
  setTimeout(fn: () => void, ms: number): () => void {
    const it = { at: this.t + Math.max(0, ms), fn, id: this.seq++, off: false };
    this.q.push(it);
    return () => {
      it.off = true;
    };
  }
  /** Majukan jam; timer yang jatuh tempo dijalankan berurutan pada waktunya masing-masing. */
  advance(ms: number): void {
    const target = this.t + ms;
    for (;;) {
      this.q = this.q.filter((x) => !x.off);
      const next = this.q.filter((x) => x.at <= target).sort((a, b) => a.at - b.at || a.id - b.id)[0];
      if (!next) break;
      this.q = this.q.filter((x) => x !== next);
      this.t = Math.max(this.t, next.at);
      next.fn();
    }
    this.t = target;
  }
}

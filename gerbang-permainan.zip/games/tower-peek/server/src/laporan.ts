// Laporan: statistik per peserta, heatmap per soal, CSV, replay (SPEC §9, §4.6). Hanya untuk operator.
import { indikatorMeja, petaPanas } from "./stats";
import type { TowerPeek } from "./service";

export function statistik(svc: TowerPeek, urutan: number) {
  const s = svc.need();
  const r = svc.ronde(urutan);
  if (!r.hasil) return { urutan, indikator: [], petaPanas: [], bermakna: false };
  const indikator = r.hasil.map((h) => {
    const so = r.soal[h.nomor]!.puzzle;
    return {
      ...indikatorMeja({ n: r.n, nomor: h.nomor, urutan, sol: so.sol, givens: so.givens, clues: so.clues as unknown as Record<string, number[]>, entri: svc.audit.entri, mulai: r.startAt ?? 0, belT: h.belT, tepat: h.tepat, terbuka: h.terbuka }),
      nama: s.peserta.find((p) => p.id === s.meja[h.nomor - 1]?.pesertaId)?.nama ?? `Meja ${h.nomor}`,
    };
  });
  const heat = petaPanas(r.n, r.hasil.map((h) => ({ k: r.soal[h.nomor]!.k, salah: h.salah })));
  // Pada ARENA tiap pemain punya papan unik: heatmap per posisi tetap ada tetapi tidak membandingkan soal yang sama.
  return { urutan, n: r.n, indikator, petaPanas: heat, bermakna: s.format === "KOMPETISI" };
}

const csv = (v: unknown) => {
  const t = v === null || v === undefined ? "" : String(v);
  return /[",\n]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t;
};
export function ekspor(svc: TowerPeek): { csv: string; json: unknown } {
  const s = svc.need();
  const baris: unknown[][] = [["ronde", "nomor", "nama", "kelas", "poin", "tepat", "terbuka", "sempurna", "bintang", "peringkat", "bel_detik", "bantuan", "efisiensi", "tepat_pertama", "pengintip_kali", "pengintip_ms", "strategi_patokan", "kembar_dibuat"]];
  const semua = [];
  for (const r of s.ronde) {
    if (!r.hasil) continue;
    const st = statistik(svc, r.urutan);
    semua.push(st);
    for (const h of r.hasil) {
      const i = st.indikator.find((x) => x.nomor === h.nomor)!;
      const p = s.peserta.find((q) => q.id === s.meja[h.nomor - 1]?.pesertaId);
      baris.push([r.urutan, h.nomor, p?.nama ?? "", p?.kelas ?? "", h.poin, h.tepat, h.terbuka, h.sempurna ? 1 : 0, h.bintang, h.peringkat, i.waktuBelDetik, h.bantuan, i.efisiensi?.toFixed(2), i.tepatPercobaanPertama?.toFixed(2), i.pengintip.jumlah, i.pengintip.durasiMs, i.strategiPatokan, i.kembarDibuat]);
    }
  }
  return { csv: baris.map((b) => b.map(csv).join(",")).join("\n") + "\n", json: { ringkasan: svc.ringkasan(), klasemen: svc.klasemen(), statistik: semua, bendera: s.flags } };
}
export function replay(svc: TowerPeek, urutan: number) {
  const r = svc.ronde(urutan);
  const awal = r.startAt ?? 0;
  const entri = svc.audit.entri
    .filter((e) => (e.payload as { urutan?: number }).urutan === urutan && e.tipe !== "ronde.nilai")
    .map((e) => ({ seq: e.seq, dtMs: e.ts - awal, tipe: e.tipe, aktor: e.aktor, payload: e.payload }));
  return { urutan, n: r.n, startAt: r.startAt, deadline: r.deadline, hashAkhir: svc.audit.entri[svc.audit.entri.length - 1]?.hash ?? null, entri };
}
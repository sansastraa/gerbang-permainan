// Audit log append-only berantai hash (SPEC §4.5/§8). Sumber kebenaran: state dibangun ulang dengan memutar ulang entri.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";

export interface AuditEntry {
  seq: number;
  ts: number;
  aktor: string;
  tipe: string;
  payload: unknown;
  prev: string;
  hash: string;
}
const GENESIS = "0".repeat(64);
export const hitungHash = (e: Omit<AuditEntry, "hash">): string =>
  crypto.createHash("sha256").update(`${e.prev}|${e.seq}|${e.ts}|${e.aktor}|${e.tipe}|${JSON.stringify(e.payload)}`).digest("hex");

export function verifikasiRantai(entri: readonly AuditEntry[]): { sah: boolean; rusakDi?: number } {
  let prev = GENESIS;
  for (let i = 0; i < entri.length; i++) {
    const e = entri[i]!;
    if (e.seq !== i + 1 || e.prev !== prev || hitungHash(e) !== e.hash) return { sah: false, rusakDi: e.seq };
    prev = e.hash;
  }
  return { sah: true };
}

export class AuditLog {
  readonly entri: AuditEntry[] = [];
  private fd: number | null = null;
  constructor(berkas?: string) {
    if (!berkas) return;
    fs.mkdirSync(path.dirname(berkas), { recursive: true });
    if (fs.existsSync(berkas)) {
      for (const baris of fs.readFileSync(berkas, "utf8").split("\n")) if (baris.trim()) this.entri.push(JSON.parse(baris) as AuditEntry);
      const v = verifikasiRantai(this.entri);
      if (!v.sah) throw new Error(`Audit log rusak pada entri #${v.rusakDi}; pulihkan dari cadangan atau pindahkan berkas.`);
    }
    this.fd = fs.openSync(berkas, "a");
  }
  tambah(ts: number, aktor: string, tipe: string, payload: unknown): AuditEntry {
    const prev = this.entri.length ? this.entri[this.entri.length - 1]!.hash : GENESIS;
    const dasar = { seq: this.entri.length + 1, ts, aktor, tipe, payload, prev };
    const e: AuditEntry = { ...dasar, hash: hitungHash(dasar) };
    this.entri.push(e);
    if (this.fd !== null) fs.writeSync(this.fd, JSON.stringify(e) + "\n");
    return e;
  }
  tutup(): void {
    if (this.fd !== null) fs.closeSync(this.fd);
    this.fd = null;
  }
}


// Broadcast Director (SPEC §7): menyusun "adegan" Layar Siswa dan MENYENSOR data sesuai fase.
// Selama ronde berjalan (hingga reveal) payload tidak memuat tinggi menara peserta — hanya persen petak terisi.
import { SIDES, countVisible, lineCells } from "@tower-peek/shared";
import type { RondeState, TowerPeek } from "./service";

export interface Adegan {
  adegan: string;
  data: Record<string, unknown>;
}
const ADEGAN_SAH = ["lobi", "aturan", "mundur", "live", "reveal", "skor", "podium"];
export const adeganSah = (a: string | null) => a === null || ADEGAN_SAH.includes(a);

function ringkasMeja(svc: TowerPeek, r: RondeState | null) {
  const s = svc.need();
  return s.meja.map((m) => {
    const p = s.peserta.find((q) => q.id === m.pesertaId);
    const status = m.status === "PLAYING" ? (m.jeda ? "jeda" : "main") : m.status === "BELL" ? "bel" : m.status === "TIMEOUT_LOCKED" || m.status === "REVEALED" ? "kunci" : m.online ? "siap" : "offline";
    return {
      nomor: m.nomor, nama: p?.nama ?? `Meja ${m.nomor}`, avatar: p?.avatar ?? null, status,
      persen: r && r.soal[m.nomor] ? Math.round(svc.persen(r, m) * 100) / 100 : 0,
      belUrutan: m.bel?.urutan ?? null,
      validasi: m.validasi,
      belSisaDetik: m.bel && r?.deadline ? Math.max(0, Math.round((r.deadline + m.kompensasiMs - m.bel.t) / 1000)) : null,
      ...(s.tinggiLive && r && r.soal[m.nomor] ? { papan: m.papan.slice() } : {}),
    };
  });
}

/**
 * Sorotan bergilir: tiap `sorotan_detik` detik (jam server) Layar menayangkan papan SATU pemain dalam 3D, hidup selagi ia mengisi.
 * Hanya satu papan yang pernah dimuat ke payload; aktif bila operator menyalakannya (bawaan: ARENA, papan tiap pemain unik).
 */
function sorotanData(svc: TowerPeek, r: RondeState) {
  const s = svc.need();
  if (!s.sorotan || r.startAt === null || !["LIVE", "PAUSED", "CLOSED", "JUDGED"].includes(r.status)) return null;
  const aktif = s.meja.filter((m) => r.soal[m.nomor] && (m.status === "PLAYING" || m.status === "BELL"));
  const calon = aktif.length ? aktif : s.meja.filter((m) => r.soal[m.nomor]);
  if (!calon.length) return null;
  const dur = svc.cfg.layar_siswa.sorotan_detik * 1000;
  const acuan = r.status === "LIVE" ? svc.clock.now() : (r.pausedAt ?? r.ditutup?.t ?? svc.clock.now());
  const t = Math.max(0, acuan - r.startAt);
  const idx = Math.floor(t / dur) % calon.length;
  const m = calon[idx]!;
  const so = r.soal[m.nomor]!.puzzle;
  const p = s.peserta.find((q) => q.id === m.pesertaId);
  return {
    nomor: m.nomor, nama: p?.nama ?? `Meja ${m.nomor}`, avatar: p?.avatar ?? null, n: r.n, papan: m.papan.slice(), dipaku: so.givens, petunjuk: so.clues,
    validasi: m.validasi, persen: Math.round(svc.persen(r, m) * 100) / 100, sisaDetik: Math.max(1, Math.ceil((dur - (t % dur)) / 1000)), durasi: dur / 1000, ke: idx + 1, dari: calon.length,
  };
}

export function revealData(svc: TowerPeek, r: RondeState, nomor: number) {
  const s = svc.need();
  const papan = r.papanAkhir![nomor]!;
  const so = r.soal[nomor]!.puzzle;
  const h = r.hasil!.find((x) => x.nomor === nomor)!;
  const p = s.peserta.find((q) => q.id === s.meja[nomor - 1]?.pesertaId);
  const cek = ([...SIDES] as const).flatMap((sisi) =>
    Array.from({ length: r.n }, (_, i) => {
      const sel = lineCells(r.n, sisi, i);
      const hitung = countVisible(sel.map((x) => papan[x] || 0));
      return { sisi, indeks: i, petunjuk: so.clues[sisi][i]!, hitung, cocok: sel.every((x) => papan[x]) && hitung === so.clues[sisi][i], sel };
    }),
  );
  return { nomor, nama: p?.nama ?? `Meja ${nomor}`, avatar: p?.avatar ?? null, n: r.n, papan, dipaku: so.givens, petunjuk: so.clues, cek, salah: h.salah, hasil: { tepat: h.tepat, terbuka: h.terbuka, sempurna: h.sempurna, poin: h.poin, bintang: h.bintang, peringkat: h.peringkat }, urutan: r.reveal.sudah.length, dari: r.hasil!.length };
}

export function susunAdegan(svc: TowerPeek): Adegan {
  const s = svc.sesi;
  if (!s) return { adegan: "lobi", data: { nama: null, meja: [] } };
  const r = svc.rondeAktif();
  let nama = s.adeganManual;
  if (!nama) {
    if (!r) nama = s.ronde.some((x) => x.hasil) ? "skor" : "lobi";
    else if (r.status === "LOADED" || r.status === "BRIEFING") nama = "aturan";
    else if (r.status === "COUNTDOWN") nama = "mundur";
    else if (r.status === "LIVE" || r.status === "PAUSED" || r.status === "CLOSED" || r.status === "JUDGED") nama = "live";
    else if (r.status === "REVEAL") nama = r.reveal.current ? "reveal" : "skor";
    else nama = "skor";
  }
  const dasar = { namaSesi: s.nama, format: s.format, mode: s.mode, serverNow: svc.clock.now() };
  const rd = r ? { urutan: r.urutan, total: s.ronde.length, n: r.n, status: r.status, waktuDetik: r.waktuDetik, startAt: r.startAt, deadline: r.deadline, pausedAt: r.pausedAt } : null;
  switch (nama) {
    case "reveal":
      if (r?.hasil && r.reveal.current && (r.status === "REVEAL" || r.status === "JUDGED" || r.status === "SCORED")) return { adegan: "reveal", data: { ...dasar, ronde: rd, ...revealData(svc, r, r.reveal.current) } };
      nama = "live";
    // eslint-disable-next-line no-fallthrough
    case "live":
    case "mundur": {
      const meja = ringkasMeja(svc, r);
      const sem = r && s.format === "ARENA" && r.status !== "COUNTDOWN" ? svc.skorSementara(r) : null;
      const sebelum = new Map(svc.klasemen().map((k) => [k.nomor, k.total - (r?.hasil?.find((h) => h.nomor === k.nomor)?.poin ?? 0)]));
      const peringkat = sem
        ? meja
            .map((m) => ({ ...m, skorRonde: sem.get(m.nomor) ?? 0, total: (sebelum.get(m.nomor) ?? 0) + (sem.get(m.nomor) ?? 0) }))
            .sort((a, b) => b.total - a.total || a.validasi - b.validasi || (a.belUrutan ?? 99) - (b.belUrutan ?? 99) || a.nomor - b.nomor)
        : null;
      return { adegan: nama === "live" && r?.status === "COUNTDOWN" ? "mundur" : nama, data: { ...dasar, ronde: rd, meja, peringkat, sorotan: r ? sorotanData(svc, r) : null, tinggiLive: s.tinggiLive, terkunciSemua: r ? r.status === "CLOSED" || r.status === "JUDGED" : false } };
    }
    case "aturan":
      return { adegan: "aturan", data: { ...dasar, ronde: rd } };
    case "skor": {
      const kl = svc.klasemen();
      const hasil = (r?.hasil ?? [...s.ronde].reverse().find((x) => x.hasil)?.hasil ?? []).map((h) => ({ nomor: h.nomor, nama: s.peserta.find((q) => q.id === s.meja[h.nomor - 1]?.pesertaId)?.nama ?? `Meja ${h.nomor}`, poin: h.poin, bintang: h.bintang, peringkat: h.peringkat, sempurna: h.sempurna }));
      return { adegan: "skor", data: { ...dasar, ronde: rd, hasil, klasemen: kl.slice(0, 40) } };
    }
    case "podium":
      return { adegan: "podium", data: { ...dasar, juara: svc.klasemen().slice(0, 3) } };
    default:
      return { adegan: "lobi", data: { ...dasar, pin: s.format === "ARENA" ? s.pin : null, meja: s.meja.map((m) => ({ nomor: m.nomor, nama: s.peserta.find((q) => q.id === m.pesertaId)?.nama ?? `Meja ${m.nomor}`, avatar: s.peserta.find((q) => q.id === m.pesertaId)?.avatar ?? null, online: m.online })), kapasitas: s.jumlahMeja } };
  }
}
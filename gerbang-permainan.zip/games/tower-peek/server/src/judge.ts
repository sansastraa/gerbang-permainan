// Judge: penilaian murni (tanpa efek samping) sesuai SPEC §2.5. Dipanggil server saat ronde ditutup.
import type { ModeGame, PoinChampion, PoinSD, TowerConfig } from "@tower-peek/shared";

export interface MasukanNilai {
  nomor: number;
  papan: readonly number[];
  sol: readonly number[];
  givens: readonly number[];
  bel: { t: number } | null;
  bantuan: number;
  validasi?: number;
  /** tenggat efektif meja (ms jam server), dipakai untuk sisa waktu */
  tenggat: number;
}
export interface Hasil {
  nomor: number;
  tepat: number;
  terbuka: number;
  sempurna: boolean;
  poin: number;
  bintang: 0 | 1 | 2 | 3;
  peringkat: number;
  belUrutan: number | null;
  belT: number | null;
  bantuan: number;
  validasi: number;
  salah: number[];
  rincian: Record<string, number>;
  koreksi: { delta: number; alasan: string; t: number }[];
}
const r2 = (x: number) => Math.round(x * 100) / 100;

export function nilaiRonde(cfg: TowerConfig, mode: ModeGame, waktuDetik: number, items: readonly MasukanNilai[]): Hasil[] {
  const dasar = items.map((it) => {
    const terbukaIdx = it.sol.map((_, i) => i).filter((i) => !it.givens[i]);
    const tepat = terbukaIdx.filter((i) => it.papan[i] === it.sol[i]).length;
    const salah = terbukaIdx.filter((i) => it.papan[i] !== it.sol[i]).map((i) => i);
    return { it, terbuka: terbukaIdx.length, tepat, salah, sempurna: tepat === terbukaIdx.length };
  });
  // urutan bel di antara papan sempurna (jam server, milidetik)
  const sempBel = dasar.filter((d) => d.sempurna && d.it.bel).sort((a, b) => a.it.bel!.t - b.it.bel!.t || a.it.nomor - b.it.nomor);
  const rankBenar = new Map(sempBel.map((d, i) => [d.it.nomor, i]));
  const semuaBel = dasar.filter((d) => d.it.bel).sort((a, b) => a.it.bel!.t - b.it.bel!.t || a.it.nomor - b.it.nomor);
  const urutBel = new Map(semuaBel.map((d, i) => [d.it.nomor, i + 1]));

  const hasil: Hasil[] = dasar.map((d) => {
    const rincian: Record<string, number> = {};
    let poin = 0;
    let bintang: 0 | 1 | 2 | 3 = 0;
    if (mode === "SD") {
      const p = cfg.mode.SD.poin as PoinSD;
      const ketepatan = d.sempurna ? p.ketepatan_maks : p.nilai_sebagian && d.tepat > 0 ? Math.ceil(p.sebagian_maks * (d.tepat / Math.max(1, d.terbuka))) : 0;
      let bonusWaktu = 0;
      let bonusBel = 0;
      if (d.sempurna && d.it.bel) {
        const sisa = Math.max(0, d.it.tenggat - d.it.bel.t) / (waktuDetik * 1000);
        bonusWaktu = p.bonus_waktu_maks * Math.min(1, sisa);
        bonusBel = p.bonus_bel[rankBenar.get(d.it.nomor) ?? 99] ?? 0;
      }
      const biaya = p.biaya_bantuan * d.it.bantuan;
      Object.assign(rincian, { ketepatan: r2(ketepatan), bonusWaktu: r2(bonusWaktu), bonusBel, bantuan: -biaya });
      poin = Math.max(0, Math.round(ketepatan + bonusWaktu + bonusBel - biaya));
      bintang = d.sempurna ? (d.it.bantuan === 0 ? 3 : 2) : d.tepat / Math.max(1, d.terbuka) >= 0.7 ? 1 : 0;
    } else {
      const p = cfg.mode.CHAMPION.poin as PoinChampion;
      if (d.sempurna && d.it.bel) {
        const rk = rankBenar.get(d.it.nomor) ?? 0;
        poin = p.peringkat_benar[Math.min(rk, p.peringkat_benar.length - 1)]!;
        rincian.peringkatBenar = rk + 1;
      } else if (d.sempurna) {
        poin = Math.min(...p.peringkat_benar) * p.benar_tanpa_bel_pengali;
        rincian.tanpaBel = 1;
      } else poin = d.tepat > 0 ? r2(p.sebagian_maks * (d.tepat / Math.max(1, d.terbuka))) : p.salah;
      bintang = d.sempurna ? 3 : 0;
    }
    return {
      nomor: d.it.nomor, tepat: d.tepat, terbuka: d.terbuka, sempurna: d.sempurna, poin, bintang, peringkat: 0,
      belUrutan: urutBel.get(d.it.nomor) ?? null, belT: d.it.bel?.t ?? null, bantuan: d.it.bantuan, validasi: d.it.validasi ?? 0, salah: d.salah, rincian, koreksi: [],
    };
  });
  return urutkan(hasil);
}
/** Peringkat ronde: poin menurun, seri dipecah jumlah validasi (lebih sedikit menang), waktu bel (jam server), lalu nomor. */
export function urutkan(hasil: Hasil[]): Hasil[] {
  const o = [...hasil].sort((a, b) => b.poin - a.poin || a.validasi - b.validasi || (a.belT ?? Infinity) - (b.belT ?? Infinity) || a.nomor - b.nomor);
  o.forEach((h, i) => (h.peringkat = i + 1));
  return hasil;
}
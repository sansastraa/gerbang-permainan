// Paket soal resmi + konfigurasi. HANYA server yang boleh memuat berkas ini (berisi solusi).
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { Clues, ModeGame, TowerConfig } from "@tower-peek/shared";

const here = path.dirname(fileURLToPath(import.meta.url));
export const ROOT = path.resolve(here, "..", "..");

export interface RondePaket {
  ronde: number;
  kode: string;
  n: number;
  waktu_detik: number;
  jumlah_dipaku: number;
  petunjuk: Clues;
  dipaku: number[];
  solusi: number[];
}
export interface Paket {
  mode: Record<ModeGame, { ronde: RondePaket[] }>;
}
export const muatPaket = (berkas = path.join(ROOT, "data", "paket_soal.json")): Paket => JSON.parse(fs.readFileSync(berkas, "utf8")) as Paket;
export const muatConfig = (berkas = path.join(ROOT, "config", "tower_peek.config.json")): TowerConfig =>
  JSON.parse(fs.readFileSync(berkas, "utf8")) as TowerConfig;

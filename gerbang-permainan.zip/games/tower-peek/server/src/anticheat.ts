// Deteksi curang murni (SPEC §8). Bendera tidak menghukum otomatis; operator yang memutuskan.
export function cocokDenganSolusiLain(papan: readonly number[], givens: readonly number[], solSendiri: readonly number[], solLain: ReadonlyMap<number, readonly number[]>): number | null {
  const terbuka = solSendiri.map((_, i) => i).filter((i) => !givens[i]);
  if (terbuka.some((i) => !papan[i])) return null;
  if (terbuka.every((i) => papan[i] === solSendiri[i])) return null; // jawaban benar milik sendiri
  for (const [nomor, sol] of solLain) {
    if (sol.join() === solSendiri.join()) continue; // varian identik: bukan jejak salin
    const cocok = terbuka.filter((i) => papan[i] === sol[i]).length;
    if (cocok === terbuka.length) return nomor;
  }
  return null;
}
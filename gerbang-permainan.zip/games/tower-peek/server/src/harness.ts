// Harness tes: layanan dengan jam terkendali. Dipakai juga oleh skrip simulasi.
import os from "node:os";
import path from "node:path";
import fs from "node:fs";
import type { TowerConfig } from "@tower-peek/shared";
import { AuditLog } from "./audit";
import { ManualClock } from "./clock";
import { muatConfig, muatPaket } from "./paket";
import { TowerPeek } from "./service";

export function buatHarness(opsi: { berkas?: string; cfg?: Partial<TowerConfig> } = {}) {
  const clock = new ManualClock();
  const cfg = { ...muatConfig(), ...opsi.cfg };
  const berkas = opsi.berkas ?? path.join(fs.mkdtempSync(path.join(os.tmpdir(), "tp-")), "audit.jsonl");
  const svc = new TowerPeek(cfg, muatPaket(), clock, new AuditLog(berkas));
  return { clock, svc, berkas, cfg };
}
export type Harness = ReturnType<typeof buatHarness>;

/** Membuat sesi, memasang meja, dan menyambungkan `online` meja (token → halo → online). */
export function siapkanMeja(h: Harness, jumlah = 8, online = jumlah, mode: "SD" | "CHAMPION" = "SD") {
  h.svc.buatSesi({ nama: "Uji", mode, jumlahMeja: jumlah, peserta: Array.from({ length: jumlah }, (_, i) => ({ id: `s${i + 1}`, nama: `Murid ${i + 1}` })) });
  const tok = h.svc.pasangMeja();
  for (let i = 0; i < online; i++) {
    h.svc.halo(tok[i]!.token, `dev-${i + 1}-xxxx`);
    h.svc.setOnline(i + 1, true);
  }
  return tok;
}

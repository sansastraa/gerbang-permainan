// Gateway HTTP + Socket.IO (Desk Gateway, REST operator). BASE_PATH = /games/tower-peek di belakang Gerbang.
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import express from "express";
import type { NextFunction, Request, Response } from "express";
import { Server } from "socket.io";
import type { Namespace, Socket } from "socket.io";
import { z } from "zod";
import { BellSchema, BoardSetSchema, FocusLostSchema, PeekSchema, ScoreAdjustSchema, JoinSchema, AssignSchema, ClockPingSchema, CreateSessionSchema, DeskHelloSchema, DeskRefSchema, ExtendSchema, LoadRoundSchema, ParticipantsSchema } from "@tower-peek/shared";
import { adeganSah, susunAdegan } from "./director";
import { ekspor, replay, statistik } from "./laporan";
import { GalatTP } from "./service";
import type { TowerPeek } from "./service";

export function normalisasiBasePath(v?: string): string {
  const s = (v ?? "").trim().replace(/\/+/g, "/").replace(/^\/|\/$/g, "");
  return s ? "/" + s : "";
}
const samaAman = (a: string, b: string) => {
  const x = crypto.createHash("sha256").update(a).digest();
  const y = crypto.createHash("sha256").update(b).digest();
  return crypto.timingSafeEqual(x, y);
};

export interface AppOpsi {
  svc: TowerPeek;
  hostPin: string;
  basePath?: string;
  staticDir?: string;
  trustProxy?: boolean;
}
export interface App {
  listen(port: number, host: string): Promise<number>;
  tutup(): Promise<void>;
  io: Server;
}

const ack = (cb: unknown, f: () => unknown) => {
  const kirim = typeof cb === "function" ? (cb as (x: unknown) => void) : () => undefined;
  try {
    kirim({ ok: true, data: f() ?? null });
  } catch (e) {
    if (e instanceof GalatTP) kirim({ ok: false, kode: e.kode, pesan: e.message });
    else if (e instanceof z.ZodError) kirim({ ok: false, kode: "payload_tidak_sah", pesan: "Data tidak sah" });
    else throw e;
  }
};

export function buatApp(o: AppOpsi): App {
  const { svc } = o;
  const base = normalisasiBasePath(o.basePath);
  const app = express();
  if (o.trustProxy) app.set("trust proxy", true);
  app.disable("x-powered-by");
  const router = express.Router();
  router.use(express.json({ limit: "256kb" }));

  // --- auth host: x-host-token = PIN guru (dibagi dengan Gerbang)
  const gagal = new Map<string, number[]>();
  const host = (req: Request, res: Response, next: NextFunction) => {
    const ip = req.ip ?? "?";
    const now = Date.now();
    const cat = (gagal.get(ip) ?? []).filter((t) => now - t < 60_000);
    if (cat.length >= 10) return void res.status(429).json({ error: "terlalu_banyak_percobaan" });
    const tok = String(req.header("x-host-token") ?? "");
    if (!tok || !samaAman(tok, o.hostPin)) {
      gagal.set(ip, [...cat, now]);
      return void res.status(401).json({ error: "token_guru_salah" });
    }
    next();
  };
  const jalan = (f: (req: Request) => unknown) => (req: Request, res: Response) => {
    try {
      res.json(f(req) ?? { ok: true });
    } catch (e) {
      if (e instanceof GalatTP) res.status(e instanceof GalatTP && e.kode.endsWith("tidak_ada") ? 404 : 409).json({ error: e.kode, pesan: e.message });
      else if (e instanceof z.ZodError) res.status(400).json({ error: "payload_tidak_sah", detail: e.issues });
      else throw e;
    }
  };

  // --- gabung ARENA (publik, dijaga PIN sesi + batas percobaan salah per IP)
  const gagalPin = new Map<string, number[]>();
  const gerbangPin = (req: Request, res: Response, f: () => unknown) => {
    const ip = req.ip ?? "?";
    const now = Date.now();
    const cat = (gagalPin.get(ip) ?? []).filter((t) => now - t < 60_000);
    if (cat.length >= svc.cfg.arena.percobaan_pin_per_menit) return void res.status(429).json({ error: "terlalu_banyak_percobaan" });
    try {
      res.json(f());
    } catch (e) {
      if (e instanceof GalatTP) {
        if (e.kode === "pin_salah") gagalPin.set(ip, [...cat, now]);
        res.status(e.kode === "pin_salah" ? 404 : 409).json({ error: e.kode, pesan: e.message });
      } else if (e instanceof z.ZodError) res.status(400).json({ error: "payload_tidak_sah" });
      else throw e;
    }
  };
  router.get("/api/join/info", (q, r) => gerbangPin(q, r, () => svc.infoGabung(String(q.query.pin ?? ""))));
  router.post("/api/join", (q, r) =>
    gerbangPin(q, r, () => {
      const b = JoinSchema.parse(q.body);
      return svc.gabung(b.pin, { deviceId: b.deviceId, ...(b.pesertaId ? { pesertaId: b.pesertaId } : {}), ...(b.nama ? { nama: b.nama } : {}) });
    }),
  );
  router.get("/health", (_q, r) => void r.json({ ok: true, game: "tower-peek" }));
  router.get("/api/state", host, jalan(() => svc.snapshotOperator()));
  router.post("/api/sessions", host, jalan((q) => {
    const b = CreateSessionSchema.parse(q.body);
    const s = svc.buatSesi({ nama: b.nama, mode: b.mode, format: b.format, ...(b.jumlahMeja ? { jumlahMeja: b.jumlahMeja } : {}), ...(b.peserta ? { peserta: b.peserta } : {}) });
    return { id: s.id, jumlahMeja: s.jumlahMeja, format: s.format, pin: s.pin };
  }));
  router.post("/api/sessions/:id/participants", host, jalan((q) => {
    if (svc.need().id !== q.params.id) throw new GalatTP("sesi_tidak_ada");
    return { peserta: svc.tambahPeserta(ParticipantsSchema.parse(q.body).peserta) };
  }));
  router.post("/api/sessions/:id/desks/assign", host, jalan((q) => {
    if (svc.need().id !== q.params.id) throw new GalatTP("sesi_tidak_ada");
    const b = AssignSchema.parse(q.body);
    svc.tugaskanPeserta(b.nomor, b.pesertaId);
  }));
  router.post("/api/sessions/:id/desks/pair", host, jalan((q) => {
    if (svc.need().id !== q.params.id) throw new GalatTP("sesi_tidak_ada");
    const b = z.object({ nomor: z.number().int().optional() }).parse(q.body ?? {});
    return { meja: svc.pasangMeja(b.nomor) };
  }));
  router.post("/api/rounds/:urutan/load", host, jalan((q) => {
    const b = LoadRoundSchema.parse(q.body ?? {});
    svc.muatRonde(Number(q.params.urutan), b.sumber, b.seed);
  }));



  const server = http.createServer(app);
  const io = new Server(server, { path: `${base}/socket.io`, serveClient: false, transports: ["websocket", "polling"] });

  // --- throttle siaran (40 pemain × banyak aksi/detik tidak boleh membanjiri operator/layar)
  const tunda = (fn: () => void, ms: number) => {
    let h: NodeJS.Timeout | null = null;
    return () => {
      if (h) return;
      h = setTimeout(() => {
        h = null;
        fn();
      }, ms);
    };
  };

  // --- /operator
  const op: Namespace = io.of("/operator");
  op.use((s, next) => {
    const t = String((s.handshake.auth as { token?: string }).token ?? "");
    if (t && samaAman(t, o.hostPin)) next();
    else next(new Error("token_guru_salah"));
  });
  op.on("connection", (s: Socket) => {
    s.emit("arena:snapshot", svc.snapshotOperator());
    const U = z.object({ urutan: z.number().int() });
    const aksi = (nama: string, f: (p: unknown) => unknown) => s.on(nama, (p: unknown, cb: unknown) => ack(cb, () => f(p)));
    aksi("round:load", (p) => {
      const b = U.merge(LoadRoundSchema).parse(p);
      svc.muatRonde(b.urutan, b.sumber, b.seed);
    });
    aksi("round:brief", (p) => svc.tayangAturan(U.parse(p).urutan));
    aksi("round:start", (p) => svc.mulai(U.parse(p).urutan));
    aksi("round:pause", () => svc.jeda());
    aksi("round:resume", () => svc.lanjut());
    aksi("round:extend", (p) => svc.perpanjang(ExtendSchema.parse(p).detik));
    aksi("round:close", () => svc.tutup("OPERATOR"));
    aksi("round:score", () => svc.tayangSkor());
    aksi("round:archive", () => svc.arsipkan());
    aksi("desk:pause", (p) => svc.jedaMeja(DeskRefSchema.parse(p).nomor));
    aksi("desk:resume", (p) => svc.lanjutMeja(DeskRefSchema.parse(p).nomor));
    aksi("desk:lock", (p) => svc.kunciMeja(DeskRefSchema.parse(p).nomor));
    aksi("desk:swap", (p) => ({ meja: svc.pasangMeja(DeskRefSchema.parse(p).nomor) }));
    aksi("desk:view", (p) => svc.lihatPapan(DeskRefSchema.parse(p).nomor));
    aksi("judge:reveal", (p) => {
      const b = z.object({ nomor: z.number().int().optional() }).parse(p ?? {});
      return b.nomor ? svc.pilihReveal(b.nomor) : { nomor: svc.revealBerikut() };
    });
    aksi("score:adjust", (p) => {
      const b = ScoreAdjustSchema.parse(p);
      svc.koreksiSkor(b.nomor, b.delta, b.alasan);
    });
    aksi("score:undo", () => svc.batalKoreksi());
    aksi("scene:set", (p) => {
      const a = z.object({ adegan: z.string().nullable() }).parse(p).adegan;
      if (!adeganSah(a)) throw new GalatTP("adegan_tidak_sah");
      svc.setAdegan(a);
    });
    aksi("scene:height", (p) => {
      const b = z.object({ aktif: z.boolean(), konfirmasi: z.boolean().default(false) }).parse(p);
      svc.setTinggiLive(b.aktif, b.konfirmasi);
    });
    aksi("scene:spotlight", (p) => {
      const b = z.object({ aktif: z.boolean(), konfirmasi: z.boolean().default(false) }).parse(p);
      svc.setSorotan(b.aktif, b.konfirmasi);
    });
    aksi("flag:resolve", (p) => {
      const b = z.object({ id: z.number().int(), tindakan: z.enum(["diabaikan", "diperingatkan", "dikunci"]) }).parse(p);
      svc.selesaikanFlag(b.id, b.tindakan);
    });
  });

  // --- /meja
  const mj: Namespace = io.of("/meja");
  const soketMeja = new Map<number, Socket>();
  const kirimStatus = (s: Socket, nomor: number) => {
    const r = svc.rondeAktif();
    const m = svc.sesi?.meja[nomor - 1];
    if (!m) return;
    s.emit("desk:state", {
      nomor, namaPeserta: svc.sesi?.peserta.find((p) => p.id === m.pesertaId)?.nama ?? null, format: svc.sesi?.format, mode: svc.sesi?.mode,
      statusMeja: m.status, jeda: m.jeda,
      ronde: r ? { urutan: r.urutan, total: svc.sesi!.ronde.length, n: r.n, status: r.status, waktuDetik: r.waktuDetik } : null,
      jadwal: r ? svc.jadwal(r) : null, tenggatMeja: r && r.deadline ? svc.tenggatMeja(r, m) : null, serverNow: svc.clock.now(),
      ...(r && r.soal[nomor] ? svc.mejaView(nomor) : {}),
      config: { bel: svc.cfg.bel, peringatanWaktu: svc.cfg.peringatan_waktu_detik, sinkron: svc.cfg.sinkron_waktu, grafis: svc.cfg.grafis_meja },
    });
    const dl = svc.deliver(nomor);
    if (dl && s.data.terkirim !== dl.rondeUrutan) {
      s.data.terkirim = dl.rondeUrutan;
      s.emit("puzzle:deliver", dl);
    }
    if (r?.status === "COUNTDOWN") s.emit("round:countdown", svc.jadwal(r));
    if (r?.status === "PAUSED") s.emit("round:paused", {});
    if (m.status === "TIMEOUT_LOCKED" || m.status === "BELL") s.emit("round:locked", { alasan: m.status });
    if (r?.hasil && r.soal[nomor]) s.emit("result:show", svc.mejaView(nomor));
  };
  const semuaMeja = () => {
    for (const [n, s] of soketMeja) kirimStatus(s, n);
  };
  mj.on("connection", (s: Socket) => {
    let token = 60;
    const isi = setInterval(() => (token = 60), 1000);
    const g = (nama: string, f: (p: unknown, nomor: number) => unknown) =>
      s.on(nama, (p: unknown, cb: unknown) => {
        ack(cb, () => {
          const nomor = s.data.nomor as number | undefined;
          if (!nomor) throw new GalatTP("belum_halo");
          if (token-- <= 0) throw new GalatTP("terlalu_cepat", "Terlalu banyak aksi");
          return f(p, nomor);
        });
      });
    s.on("desk:hello", (p: unknown, cb: unknown) =>
      ack(cb, () => {
        const b = DeskHelloSchema.parse(p);
        const m = svc.halo(b.token, b.deviceId);
        soketMeja.get(m.nomor)?.disconnect(true);
        soketMeja.set(m.nomor, s);
        s.data.nomor = m.nomor;
        svc.setOnline(m.nomor, true);
        setImmediate(() => kirimStatus(s, m.nomor));
        return { nomor: m.nomor, serverNow: svc.clock.now() };
      }),
    );
    s.on("clock:ping", (p: unknown) => {
      const r = ClockPingSchema.safeParse(p);
      if (r.success) s.emit("clock:pong", { t0: r.data.t0, ts: svc.clock.now() });
    });
    g("board:set", (p, nomor) => {
      const b = BoardSetSchema.parse(p);
      return svc.setPapan(nomor, b.sel, b.tinggi, b.versi, b.sumber, b.tKlien);
    });
    g("hint:request", (_p, nomor) => svc.mintaBantuan(nomor));
    g("board:check", (_p, nomor) => svc.periksa(nomor));
    g("bell:ring", (p, nomor) => {
      const b = BellSchema.parse(p ?? {});
      return svc.tekanBel(nomor, { ...(b.tKlien !== undefined ? { tKlien: b.tKlien } : {}), ...(b.rtt !== undefined ? { rtt: b.rtt } : {}), sumber: b.sumber });
    });
    g("peek:open", (p, nomor) => {
      const b = PeekSchema.parse(p);
      svc.bukaPeek(nomor, b.sisi, b.indeks);
    });
    g("peek:close", (_p, nomor) => svc.tutupPeek(nomor));
    g("focus:lost", (p, nomor) => svc.fokusHilang(nomor, FocusLostSchema.parse(p).durasiMs));
    g("jawaban:request", (_p, nomor) => ({ solusi: svc.jawaban(nomor) }));
    s.on("disconnect", () => {
      clearInterval(isi);
      const n = s.data.nomor as number | undefined;
      if (n && soketMeja.get(n) === s) {
        soketMeja.delete(n);
        try {
          svc.tutupPeek(n);
          svc.setOnline(n, false);
        } catch {
          /* sesi sudah diganti */
        }
      }
    });
  });

  // --- /layar (hanya data yang sudah disensor Broadcast Director)
  const ly: Namespace = io.of("/layar");
  ly.on("connection", (s: Socket) => void s.emit("scene:show", susunAdegan(svc)));
  let belTerakhir = 0;
  let belRonde = -1;
  let revealTerakhir: number | null = null;
  const siarLayar = tunda(() => ly.emit("scene:show", susunAdegan(svc)), 200);
  const siarOp = tunda(() => op.emit("arena:snapshot", svc.snapshotOperator()), 150);

  svc.onPancar((e) => {
    siarOp();
    siarLayar();
    if (e.tipe !== "papan") semuaMeja();
    const r = svc.rondeAktif();
    if (r) {
      if (belRonde !== r.urutan) {
        belRonde = r.urutan;
        belTerakhir = r.bel.length;
      }
      while (belTerakhir < r.bel.length) {
        const nomor = r.bel[belTerakhir++]!;
        const m = svc.meja(nomor);
        ly.emit("bell:fx", { nomor, nama: svc.sesi!.peserta.find((p) => p.id === m.pesertaId)?.nama ?? `Meja ${nomor}`, urutan: m.bel?.urutan ?? 0, sisaDetik: r.deadline && m.bel ? Math.max(0, Math.round((r.deadline + m.kompensasiMs - m.bel.t) / 1000)) : null });
      }
      if (r.reveal.current !== null && r.reveal.current !== revealTerakhir && r.hasil) {
        revealTerakhir = r.reveal.current;
        ly.emit("reveal:play", { nomor: r.reveal.current });
      }
      if (r.reveal.current === null) revealTerakhir = null;
    }
  });
  setInterval(() => ly.emit("timer:sync", { serverNow: svc.clock.now() }), 5000).unref();
  // sorotan bergilir & papan peringkat langsung: dorong adegan tiap detik selama ronde berjalan
  setInterval(() => {
    const st = svc.rondeAktif()?.status;
    if (st === "LIVE" || st === "PAUSED") ly.emit("scene:show", susunAdegan(svc));
  }, 1000).unref();

  // --- REST laporan (operator)
  const ses = (q: Request) => {
    if (svc.need().id !== q.params.id) throw new GalatTP("sesi_tidak_ada");
  };
  router.get("/api/sessions/:id/summary.json", host, jalan((q) => (ses(q), svc.ringkasan())));
  router.get("/api/sessions/:id/export", host, (q, r) => {
    try {
      ses(q);
      const e = ekspor(svc);
      if (q.query.format === "csv") r.type("text/csv; charset=utf-8").set("content-disposition", 'attachment; filename="tower-peek.csv"').send(e.csv);
      else r.json(e.json);
    } catch (err) {
      r.status(err instanceof GalatTP ? 404 : 500).json({ error: err instanceof GalatTP ? err.kode : "galat" });
    }
  });
  router.get("/api/rounds/:urutan/stats", host, jalan((q) => statistik(svc, Number(q.params.urutan))));
  router.get("/api/rounds/:urutan/replay", host, jalan((q) => replay(svc, Number(q.params.urutan))));
  // --- statis + SPA (/host, /operator, /meja/:n, /layar, /tonton)
  const dist = o.staticDir;
  if (dist && fs.existsSync(dist)) {
    router.use(express.static(dist, { index: false, maxAge: "1h" }));
    router.get(/^\/(?!api\/|socket\.io\/|health).*/, (_q, r) => void r.sendFile(path.join(dist, "index.html")));
  }
  router.use("/api", (_q, r) => void r.status(404).json({ error: "tidak_ditemukan" }));
  app.use(base || "/", router);

  return {
    io,
    listen: (port, hostAddr) => new Promise((res) => server.listen(port, hostAddr, () => res((server.address() as { port: number }).port))),
    tutup: () =>
      new Promise((res) => {
        void io.close(() => res());
      }),
  };
}


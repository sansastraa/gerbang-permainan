// Titik masuk. Env: PORT (3120) HOST DATA_DIR HOST_PIN/HOST_TOKEN BASE_PATH TRUST_PROXY STATIC_DIR
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buatApp, normalisasiBasePath } from "./app";
import { AuditLog } from "./audit";
import { realClock } from "./clock";
import { muatConfig, muatPaket } from "./paket";
import { TowerPeek } from "./service";

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR ?? path.join(here, "..", "var");
fs.mkdirSync(dataDir, { recursive: true });
function hostPin(): string {
  const env = process.env.HOST_PIN || process.env.HOST_TOKEN;
  if (env && env.length >= 4) return env;
  const f = path.join(dataDir, "host-token.txt");
  if (fs.existsSync(f)) return fs.readFileSync(f, "utf8").trim();
  const pin = String(crypto.randomInt(100000, 999999));
  fs.writeFileSync(f, pin);
  return pin;
}
const port = Number(process.env.PORT ?? 3120);
const bind = process.env.HOST ?? "0.0.0.0";
const pin = hostPin();
const basePath = normalisasiBasePath(process.env.BASE_PATH);
const svc = new TowerPeek(muatConfig(), muatPaket(), realClock, new AuditLog(path.join(dataDir, "audit.jsonl")));
const app = buatApp({
  svc,
  hostPin: pin,
  basePath,
  trustProxy: process.env.TRUST_PROXY === "1",
  staticDir: process.env.STATIC_DIR ?? path.join(here, "..", "..", "client", "dist"),
});
void app.listen(port, bind).then((p) => {
  console.log(`\nTOWER PEEK berjalan di port ${p}`);
  console.log(`  Operator : http://localhost:${p}${basePath}/host   (PIN guru: ${pin})`);
  for (const i of Object.values(os.networkInterfaces()).flat())
    if (i && i.family === "IPv4" && !i.internal) console.log(`  Layar    : http://${i.address}:${p}${basePath}/layar`);
});

// E2E nyata: Gerbang (PIN) → Tower Peek ARENA → 3 murid di peramban → bel → reveal di /layar. Edge sistem via playwright-core.
// Pakai: npx tsx scripts/e2e.ts   (butuh `npm run build` di folder ini; Gerbang berada di ../..)
import { spawn, spawnSync } from "node:child_process";
import { mkdtempSync, mkdirSync } from "node:fs";
import { tmpdir } from "node:os";
import { createRequire } from "node:module";
import { join } from "node:path";
import type { Page } from "playwright-core";
import { solve } from "@tower-peek/shared";

const gerbang = join(import.meta.dirname, "..", "..", "..");
const { chromium } = createRequire(join(gerbang, "package.json"))("playwright-core") as { chromium: import("playwright-core").BrowserType }; // eslint-disable-line @typescript-eslint/consistent-type-imports
const PIN = "guru-e2e-1";
const PORT = Number(process.env.E2E_PORT ?? 8124);
const base = `http://127.0.0.1:${PORT}`;
const GAME = `${base}/games/tower-peek`;
const docs = join(import.meta.dirname, "..", "docs", "e2e");
mkdirSync(docs, { recursive: true });
const hasil: boolean[] = [];
const t00 = Date.now();
const cek = (nama: string, ok: boolean, info = "") => {
  hasil.push(ok);
  console.log(`${ok ? "✔" : "✘"} [${Math.round((Date.now() - t00) / 1000)}s] ${nama}${info ? ` — ${info}` : ""}`);
};
const foto = async (p: Page, nama: string) => {
  // WebGL perangkat lunak di mesin uji lambat: tangkapan layar tidak boleh menggagalkan uji
  await p.screenshot({ path: join(docs, nama), timeout: 90000 }).catch(() => console.log(`   (tangkapan ${nama} dilewati: lambat)`));
};
const tunggu = async (fn: () => Promise<boolean>, ms = 60000) => {
  const t = Date.now();
  while (Date.now() - t < ms) {
    try {
      if (await fn()) return true;
    } catch {
      /* belum siap */
    }
    await new Promise((r) => setTimeout(r, 300));
  }
  return false;
};
const data = mkdtempSync(join(tmpdir(), "tp-e2e-"));
const srv = spawn(process.execPath, ["scripts/start.mjs", "--game", "tower-peek"], { cwd: gerbang, env: { ...process.env, GERBANG_PIN: PIN, GERBANG_PORT: String(PORT), GERBANG_HOST: "127.0.0.1", GERBANG_DATA: data } });
let log = "";
srv.stdout.on("data", (d) => (log += d));
srv.stderr.on("data", (d) => (log += d));
const j = async (path: string, body?: unknown) => {
  const r = await fetch(base + path, { method: body ? "POST" : "GET", headers: { "x-host-token": PIN, ...(body ? { "content-type": "application/json" } : {}) }, body: body ? JSON.stringify(body) : undefined });
  return { status: r.status, json: (await r.json().catch(() => null)) as any }; // eslint-disable-line @typescript-eslint/no-explicit-any
};

let peramban;
const halamanSemua: Page[] = [];
try {
  const siap = await tunggu(async () => ((await (await fetch(`${base}/api/status`)).json()) as any).games.find((g: any) => g.key === "tower-peek")?.hidup); // eslint-disable-line @typescript-eslint/no-explicit-any
  cek("Gerbang + Tower Peek menyala", siap, siap ? "" : log.slice(-600));
  if (!siap) throw new Error("server tidak siap");
  peramban = await chromium.launch({ channel: "msedge", headless: true, args: ["--mute-audio", "--use-angle=swiftshader", "--enable-unsafe-swiftshader", "--ignore-gpu-blocklist"] });
  const ctx = await peramban.newContext({ viewport: { width: 1366, height: 800 } });
  const hub = await ctx.newPage();
  await hub.goto(base);
  await hub.locator(".dunia").nth(5).waitFor();
  cek("Tower Peek muncul sebagai pilihan di Gerbang", (await hub.locator(".dunia").nth(5).innerText()).includes("Tower Peek"));
  await hub.locator("#pin").fill(PIN);
  await hub.getByRole("button", { name: "Buka" }).click();
  await hub.getByRole("tab", { name: "Kelas" }).waitFor();
  const nama = ["Ani Lestari", "Budi Santoso", "Citra Dewi", "Dodi Pratama"];
  await j("/api/kelas", { nama: "7A", daftar: nama.join("\n") });
  await hub.reload();
  await hub.getByRole("tab", { name: "Dunia" }).waitFor();

  // 1) serah-terima: popup konsol guru menerima daftar kelas, PIN tidak di URL
  const [host] = await Promise.all([ctx.waitForEvent("page"), hub.locator(".dunia").nth(5).getByRole("button", { name: "Masuk" }).click()]);
  halamanSemua.push(host);
  await host.setViewportSize({ width: 1366, height: 800 });
  await host.getByText("Siapkan permainan").waitFor({ timeout: 25000 });
  cek("konsol guru menerima daftar kelas dari Gerbang", (await host.locator("body").innerText()).includes("Kelas 7A: 4 siswa"));
  cek("PIN guru tidak ada di URL", !host.url().includes(PIN));
  await foto(host, "1-siapkan.png");
  await host.getByTestId("fmt-arena").check();
  await host.getByTestId("buat-sesi").click();
  const pinArena = (await host.getByTestId("pin-arena").innerText()).trim();
  cek("sesi Arena dibuat dengan PIN 6 digit", /^\d{6}$/.test(pinArena), pinArena);
  await foto(host, "2-lobi-arena.png");

  const layar = await (await peramban.newContext({ viewport: { width: 1024, height: 600 } })).newPage();
  const teksLayar: string[] = [];
  await layar.goto(`${GAME}/layar`);
  await layar.getByText(pinArena).waitFor({ timeout: 10000 });
  cek("layar proyektor menampilkan PIN gabung", true);

  // 2) tiga murid masuk dengan PIN, memilih nama dari daftar
  const murid: { page: Page; nama: string }[] = [];
  for (let i = 0; i < 3; i++) {
    const c = await peramban.newContext({ viewport: i === 0 ? { width: 768, height: 900 } : { width: 1000, height: 700 }, hasTouch: i === 0 });
    if (i !== 1) await c.addInitScript(() => localStorage.setItem("tp-tampil", "atas")); // hemat CPU: hanya satu murid memakai 3D di E2E
    const p = await c.newPage();
    p.setDefaultTimeout(60000);
    p.on("pageerror", (e) => console.log(`   [murid ${i + 1} galat halaman] ${e.message.slice(0, 200)}`));
    p.on("console", (m) => m.type() === "error" && console.log(`   [murid ${i + 1} console] ${m.text().slice(0, 200)}`));
    await p.goto(`${GAME}/?pin=${pinArena}`);
    await p.getByRole("button", { name: nama[i]! }).click();
    await p.waitForURL(/\/main$/);
    murid.push({ page: p, nama: nama[i]! });
    halamanSemua.push(p);
  }
  await host.waitForFunction(() => document.querySelectorAll(".kartu-meja.st-READY, .kartu-meja:not(.off)").length >= 3, null, { timeout: 10000 });
  cek("3 murid masuk Arena dan terlihat online di konsol guru", (await host.locator(".kartu-meja:not(.off)").count()) === 3);

  // 3) ronde 1: muat → mulai
  await host.getByRole("button", { name: /Muat ronde 1/ }).click();
  await host.getByRole("button", { name: /Mulai/ }).click();
  for (const m of murid) await m.page.getByTestId("mundur").waitFor({ timeout: 8000 }).catch(() => undefined);
  await foto(murid[0]!.page, "3-murid-mundur.png");
  await foto(layar, "3-layar-mundur.png");
  for (const m of murid) await m.page.locator(".papan-wrap").waitFor({ timeout: 15000 });
  cek("papan muncul di semua murid setelah hitung mundur", true);
  const webgl = await murid[1]!.page.evaluate(() => !!document.createElement("canvas").getContext("webgl2"));
  const kanvas = await murid[1]!.page.locator("canvas").count();
  cek("papan 3D (WebGL) tampil di tablet", webgl && kanvas === 1, `webgl=${webgl}`);
  await murid[1]!.page.waitForTimeout(900);
  await foto(murid[1]!.page, "4-murid-3d.png");

  // 4) murid memecahkan lewat UI (tampak atas 2D), hanya dari data yang tampil di layar
  const pecahkan = async (p: Page, salah = false) => {
    await p.getByRole("button", { name: "Tampak atas" }).click();
    await p.locator(".papan2d").waitFor();
    await p.locator("canvas").waitFor({ state: "detached" });
    const n = Math.round(Math.sqrt(await p.locator("button.sel").count()));
    const klue = await p.locator("button.klue").allInnerTexts();
    const [top, bottom, left, right] = [0, 1, 2, 3].map((k) => klue.slice(k * n, k * n + n).map(Number));
    const dipaku = await p.locator("button.sel").evaluateAll((els) => els.map((e) => (e.classList.contains("paku") ? Number(e.getAttribute("data-v")) : 0)));
    const sol = solve(n, { top: top!, bottom: bottom!, left: left!, right: right! }, dipaku, 2)[0]!;
    for (let h = 1; h <= n; h++) {
      await p.locator(`.palet button[aria-label^="Kuas tinggi ${h},"], .palet button[aria-label^="Kuas tinggi ${h} "]`).first().click();
      for (let s = 0; s < n * n; s++) {
        if (dipaku[s] || sol[s] !== h) continue;
        if (salah && s === 0) continue;
        await p.locator(`button.sel[data-sel="${s}"]`).click();
        await p.waitForTimeout(45);
      }
    }
    return { n, sol };
  };
  const teksLive = await layar.locator("body").innerText();
  const { n } = await pecahkan(murid[0]!.page);
  await pecahkan(murid[1]!.page, true);
  cek("papan murid terisi (kuas + ketuk)", (await murid[0]!.page.locator("button.sel:not([data-v='0'])").count()) === n * n);
  await layar.getByTestId("lb-baris").first().waitFor({ timeout: 8000 });
  await layar.getByTestId("sorotan").locator("canvas").waitFor({ timeout: 8000 });
  cek("layar LIVE: papan peringkat + satu sorotan 3D (bukan papan semua pemain)", (await layar.getByTestId("lb-baris").count()) === 3 && (await layar.locator("canvas").count()) === 1 && (await layar.locator("button.sel").count()) === 0 && !/Sempurna/.test(teksLive));
  await foto(layar, "5-layar-live.png");
  // tombol Periksa (validasi) tampil di papan peringkat
  await murid[1]!.page.getByRole("button", { name: /Periksa jawaban/ }).click();
  await murid[1]!.page.getByText(/petak sudah tepat|Semua tepat/).waitFor({ timeout: 4000 });
  await layar.getByText("✓ 1×").first().waitFor({ timeout: 6000 });
  cek("jumlah validasi muncul di papan peringkat layar", true);
  await foto(layar, "5b-layar-peringkat.png");
  // mata pengintip: ketuk angka → banner
  await murid[0]!.page.locator("button.klue").first().click();
  cek("mata pengintip menampilkan jumlah menara terlihat", /terlihat \d+ menara/.test(await murid[0]!.page.locator(".banner-intip").innerText()));
  await foto(murid[0]!.page, "6-murid-intip.png");
  await murid[0]!.page.getByRole("button", { name: "Selesai" }).click();
  // bel: tahan 1 detik
  let belMuncul = false;
  for (const m of murid.slice(0, 2)) {
    const bel = m.page.getByTestId("bel");
    await bel.scrollIntoViewIfNeeded();
    const kotak = (await bel.boundingBox())!;
    await m.page.mouse.move(kotak.x + kotak.width / 2, kotak.y + kotak.height / 2);
    await m.page.mouse.down();
    await m.page.waitForTimeout(1250);
    await m.page.mouse.up();
    belMuncul = (await layar.getByTestId("bel-fx").waitFor({ timeout: 2500 }).then(() => true, () => false)) || belMuncul;
  }
  cek("bel tampil di layar proyektor", belMuncul);
  await foto(layar, "7-layar-bel.png");
  await murid[0]!.page.getByText("Jawaban terkunci").waitFor({ timeout: 4000 });
  cek("setelah bel jawaban terkunci", true);
  // murid ke-3 tidak menekan bel; guru menutup ronde
  await host.getByRole("button", { name: "Tutup ronde" }).click();
  await murid[0]!.page.getByTestId("hasil").waitFor({ timeout: 8000 });
  const h0 = await murid[0]!.page.getByTestId("hasil").innerText();
  const h1 = await murid[1]!.page.getByTestId("hasil").innerText();
  cek("murid sempurna mendapat ★★★ & poin", /Sempurna/.test(h0) && /\+\d+ poin/.test(h0));
  cek("murid dengan 1 salah tidak sempurna", /tepat/.test(h1) && !/Sempurna/.test(h1), h1.split("\n")[1] ?? "");
  await foto(murid[0]!.page, "8-murid-hasil.png");

  // 5) reveal di layar
  await host.getByRole("button", { name: /Reveal berikutnya/ }).click();
  await layar.locator('[data-adegan="reveal"]').waitFor({ timeout: 8000 });
  await layar.locator("canvas").waitFor();
  cek("reveal menampilkan papan 3D di layar", true);
  await layar.waitForTimeout(2500);
  await foto(layar, "9-layar-reveal.png");
  await layar.locator(".skor-muncul").waitFor({ timeout: 40000 });
  cek("reveal selesai dengan skor & bintang", true);
  await host.getByRole("button", { name: /Tayangkan skor/ }).click();
  await layar.locator('[data-adegan="skor"]').waitFor({ timeout: 8000 });
  await layar.waitForTimeout(1200);
  await foto(layar, "10-layar-skor.png");
  await foto(host, "11-host.png");
  await host.getByRole("button", { name: /Selesai ronde/ }).click();
  await host.getByRole("button", { name: /Muat ronde 2/ }).waitFor({ timeout: 6000 });
  cek("alur ronde berlanjut ke ronde 2", true);

  // 6) ringkasan untuk Gerbang
  const id = (await host.getByText(/Kode sesi: /).innerText()).replace("Kode sesi: ", "").trim();
  const sum = await j(`/games/tower-peek/api/sessions/${id}/summary.json`);
  cek("summary.json terbaca lewat Gerbang dengan token PIN", sum.status === 200 && sum.json.game === "tower-peek" && sum.json.siswa.length === 3 && sum.json.siswa.every((s: any) => typeof s.siswaId === "string" && s.siswaId.length > 0), `${sum.json?.siswa?.length} siswa`); // eslint-disable-line @typescript-eslint/no-explicit-any
  void teksLayar;
} catch (e) {
  for (const [i, p] of halamanSemua.entries()) await p.screenshot({ path: join(docs, `gagal-${i}.png`) }).catch(() => undefined);
  console.log("--- log server ---\n" + log.slice(-1500));
  cek("E2E selesai tanpa galat", false, String((e as Error).message ?? e).slice(0, 600));
} finally {
  await peramban?.close();
  if (process.platform === "win32") spawnSync("taskkill", ["/pid", String(srv.pid), "/T", "/F"]);
  else srv.kill();
}
console.log(`\n${hasil.filter(Boolean).length}/${hasil.length} lulus`);
process.exit(hasil.every(Boolean) ? 0 : 1);
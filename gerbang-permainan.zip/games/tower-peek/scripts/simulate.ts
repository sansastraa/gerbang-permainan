// Simulasi bot (SPEC §10): N meja/pemain bot lewat Socket.IO nyata, operator, layar, putus-sambung, penyalin.
// Pakai: npm run sim -- [--bots 16] [--arena 40] [--rounds 5] [--mode SD|CHAMPION]
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { solve } from "@tower-peek/shared";
import type { PuzzleDeliver } from "@tower-peek/shared";
import { buatApp } from "../server/src/app";
import { AuditLog, verifikasiRantai } from "../server/src/audit";
import { realClock } from "../server/src/clock";
import { muatConfig, muatPaket } from "../server/src/paket";
import { TowerPeek } from "../server/src/service";

const arg = (k: string, d: string) => {
  const i = process.argv.indexOf(`--${k}`);
  return i < 0 ? d : (process.argv[i + 1] ?? d);
};
const ADA = (k: string) => process.argv.includes(`--${k}`);
const arena = ADA("arena");
const N = Number(arena ? arg("arena", "40") : arg("bots", "16"));
const RONDE = Number(arg("rounds", "5"));
const MODE = arg("mode", "SD") as "SD" | "CHAMPION";
const PIN = "guru-sim";
const gagal: string[] = [];
const cek = (ok: boolean, pesan: string) => {
  console.log(`${ok ? "  ✔" : "  ✘"} ${pesan}`);
  if (!ok) gagal.push(pesan);
};
const tidur = (ms: number) => new Promise((r) => setTimeout(r, ms));
const ack = <T = unknown>(s: Socket, ev: string, p?: unknown) => new Promise<{ ok: boolean; kode?: string; data: T }>((res) => s.emit(ev, p ?? {}, res));

const dir = fs.mkdtempSync(path.join(os.tmpdir(), "tp-sim-"));
const cfg = { ...muatConfig(), hitung_mundur_detik: 1 };
const svc = new TowerPeek(cfg, muatPaket(), realClock, new AuditLog(path.join(dir, "audit.jsonl")));
const app = buatApp({ svc, hostPin: PIN, basePath: "/games/tower-peek" });
const port = await app.listen(0, "127.0.0.1");
const url = `http://127.0.0.1:${port}`;
const BASE = "/games/tower-peek";
const sambung = (ns: string, auth: object = {}) => io(url + ns, { path: `${BASE}/socket.io`, auth, transports: ["websocket"], reconnection: false });
const post = async (p: string, b: unknown, h: Record<string, string> = { "x-host-token": PIN }) => (await fetch(url + BASE + p, { method: "POST", headers: { "content-type": "application/json", ...h }, body: JSON.stringify(b) })).json() as Promise<Record<string, any>>; // eslint-disable-line @typescript-eslint/no-explicit-any

console.log(`Tower Peek sim: ${arena ? "ARENA" : "KOMPETISI"} ${N} bot, mode ${MODE}, ${RONDE} ronde`);
const roster = Array.from({ length: N }, (_, i) => ({ id: `s${i + 1}`, nama: `Murid ${i + 1}` }));
const sesi = await post("/api/sessions", { nama: "Simulasi", mode: MODE, format: arena ? "ARENA" : "KOMPETISI", jumlahMeja: arena ? undefined : N, peserta: roster });
const tokens: string[] = [];
if (arena) {
  for (let i = 0; i < N; i++) {
    const j = await post("/api/join", { pin: sesi.pin, deviceId: `bot-dev-${i + 1}`, pesertaId: roster[i]!.id }, {});
    tokens.push(j.token);
  }
  const lebih = await post("/api/join", { pin: sesi.pin, deviceId: "bot-dev-lebih", nama: "Ke-41" }, {});
  cek(N < 40 || lebih.error === "penuh" || lebih.error === "nama_tidak_ada", `pemain ke-${N + 1} ditolak (${lebih.error})`);
} else {
  const p = await post(`/api/sessions/${sesi.id}/desks/pair`, {});
  for (const m of p.meja) tokens.push(m.token);
}

// ---- layar & operator
const layar = sambung("/layar");
const layarPayload: { adegan: string; json: string }[] = [];
layar.on("scene:show", (m: { adegan: string; data: unknown }) => layarPayload.push({ adegan: m.adegan, json: JSON.stringify(m) }));
let bellFx = 0;
layar.on("bell:fx", () => bellFx++);
const op = sambung("/operator", { token: PIN });
let snap: any = null; // eslint-disable-line @typescript-eslint/no-explicit-any
const tOp = new Map<number, number>();
op.on("arena:snapshot", (s: unknown) => {
  snap = s;
});
await new Promise((r) => op.on("connect", r));
await tidur(200);

// ---- bot
const terima: { ev: string; json: string }[][] = Array.from({ length: N }, () => []);
const bots = tokens.map((token, i) => {
  const s = sambung("/meja");
  s.onAny((ev: string, ...a: unknown[]) => {
    if (ev !== "clock:pong") terima[i]!.push({ ev, json: JSON.stringify(a) });
  });
  return { i, nomor: i + 1, token, s, papan: [] as number[], versi: 0 };
});
type Bot = (typeof bots)[number];
const pesanLatensi: number[] = [];
let akhirSolve = 0;
const halo = async (b: Bot) => ack(b.s, "desk:hello", { token: b.token, deviceId: arena ? `bot-dev-${b.nomor}` : `bot-dev-${b.nomor}` });
for (const b of bots) await new Promise<void>((r) => b.s.on("connect", () => r()));
for (const b of bots) cek((await halo(b)).ok, `meja ${b.nomor} terhubung`);
await tidur(300);
cek(snap.meja.filter((m: any) => m.online).length === N, `operator melihat ${N} meja online`); // eslint-disable-line @typescript-eslint/no-explicit-any

let ronde = 0;
let seed = 7;
const acak = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
async function main(b: Bot, dl: PuzzleDeliver, r: number) {
  const sol = solve(dl.n, dl.petunjuk, dl.dipaku, 2)[0]!;
  akhirSolve = performance.now(); // solver bot berjalan di proses yang sama dengan server: sampel yang tumpang tindih dibuang
  const salahan = b.i % 5 === 0 && r % 2 === 0 ? 2 : 0; // sebagian bot sengaja salah
  const penyalin = !arena && r === 3 && b.i === 1;
  const flagAwal = svc.need().flags.length;
  void flagAwal;
  const sumber = penyalin ? svc.ronde(r).soal[1]!.puzzle.sol : sol; // bot penyalin "mengintip" papan tetangga
  const urut = sumber.map((_, k) => k).filter((k) => !dl.dipaku[k]);
  let salahDibuat = 0;
  for (let k = 0; k < urut.length; k++) {
    const sel = urut[k]!;
    let tinggi = sumber[sel]!;
    if (salahDibuat < salahan && k % 7 === 3 && !penyalin) {
      tinggi = (tinggi % dl.n) + 1;
      salahDibuat++;
    }
    const t0 = performance.now();
    const res = await ack<{ ok: boolean; versi: number }>(b.s, "board:set", { sel, tinggi, versi: b.versi, sumber: "kuas", tKlien: Date.now() });
    if (akhirSolve < t0) pesanLatensi.push(performance.now() - t0);
    if (res.ok && res.data) b.versi = res.data.versi;
    if (b.i === 3 && r === 2 && k === 5) await putusSambung(b);
    await tidur(85 + acak() * 60); // ketukan manusiawi (batas server 25 aksi/dtk)
  }
  if (b.i === 6 && r % 2 === 1) return; // tidak menekan bel: ditutup operator
  await tidur(acak() * 300);
  const bel = await ack(b.s, "bell:ring", { tKlien: Date.now(), sumber: "layar" });
  if (!bel.ok) console.log("bel gagal", b.nomor, bel.kode);
}
async function putusSambung(b: Bot) {
  const papanSebelum = svc.meja(b.nomor).papan.slice();
  b.s.disconnect();
  await tidur(250);
  const baru = sambung("/meja");
  baru.onAny((ev: string, ...a: unknown[]) => void (ev !== "clock:pong" && terima[b.i]!.push({ ev, json: JSON.stringify(a) })));
  b.s = baru;
  await new Promise<void>((r) => baru.on("connect", () => r()));
  const t0 = performance.now();
  const pulih = new Promise<{ papan: number[] }>((r) => baru.once("desk:state", r));
  await halo(b);
  const st = await pulih;
  cek(JSON.stringify(st.papan) === JSON.stringify(papanSebelum), `meja ${b.nomor} pulih persis setelah putus-sambung (${Math.round(performance.now() - t0)} ms)`);
  baru.on("puzzle:deliver", () => undefined);
}

for (ronde = 1; ronde <= RONDE; ronde++) {
  console.log(`\n== Ronde ${ronde}`);
  const r = ronde;
  const dikerjakan: Promise<void>[] = [];
  for (const b of bots)
    b.s.once("puzzle:deliver", (dl: PuzzleDeliver) => {
      b.versi = 0;
      dikerjakan.push(main(b, dl, r));
    });
  cek((await ack(op, "round:load", { urutan: r, sumber: "paket" })).ok, "ronde dimuat");
  const tStart = Date.now();
  cek((await ack(op, "round:start", { urutan: r })).ok, "ronde dimulai");
  // tunggu LIVE
  while (snap.ronde[r - 1].status !== "LIVE" && Date.now() - tStart < 8000) await tidur(50);
  cek(snap.ronde[r - 1].status === "LIVE", "hitung mundur selesai → LIVE");
  await tidur(300);
  // sensor layar selama LIVE
  const live = layarPayload.filter((x) => x.adegan === "live").at(-1);
  const maksPapan = arena ? 1 : 0; // ARENA: hanya papan SATU pemain yang disorot (papan tiap pemain unik)
  const jmlPapan = (j: string) => j.split('"papan"').length - 1;
  cek(!!live && jmlPapan(live.json) <= maksPapan && !/"sol"|"solusi"/.test(live.json), `payload /layar saat LIVE: ${live ? jmlPapan(live.json) : "?"} papan (maks ${maksPapan}), tanpa solusi`);
  const t1 = Date.now();
  while (!["JUDGED"].includes(snap.ronde[r - 1].status) && Date.now() - t1 < 16000) {
    await tidur(100);
    if (Date.now() - t1 > 9000 && snap.ronde[r - 1].status === "LIVE") await ack(op, "round:close");
  }
  await Promise.all(dikerjakan);
  cek(snap.ronde[r - 1].status === "JUDGED", `ronde dinilai otomatis (${snap.ronde[r - 1].hasil?.filter((h: any) => h.sempurna).length}/${N} sempurna)`); // eslint-disable-line @typescript-eslint/no-explicit-any
  // layar selama LIVE/CLOSED tidak pernah memuat papan
  const bocor = layarPayload.filter((x) => x.adegan !== "reveal" && x.adegan !== "skor" && x.adegan !== "podium" && (jmlPapan(x.json) > maksPapan || /"sol"|"solusi"/.test(x.json)));
  cek(bocor.length === 0, `semua payload /layar (${layarPayload.length}) sebelum reveal tanpa papan/solusi`);
  // reveal semua
  for (let k = 0; k < N; k++) {
    const rv = await ack<{ nomor: number | null }>(op, "judge:reveal", {});
    if (!rv.ok) break;
  }
  await tidur(250);
  const rev = layarPayload.filter((x) => x.adegan === "reveal");
  cek(rev.length > 0 && rev.every((x) => /"papan"/.test(x.json)), `reveal menayangkan papan (${rev.length} adegan)`);
  cek((await ack(op, "round:score")).ok, "papan skor tayang");
  cek((await ack(op, "round:archive")).ok, "ronde diarsipkan");
  layarPayload.length = 0;
}

// ---- pemeriksaan akhir
console.log("\n== Pemeriksaan akhir");
const totalBel = svc.need().ronde.slice(0, RONDE).reduce((a, x) => a + x.bel.length, 0);
cek(bellFx === totalBel && totalBel > 0, `/layar menerima bell:fx untuk setiap bel (${bellFx}/${totalBel})`);
const s = svc.need();
cek(s.ronde.slice(0, RONDE).every((x) => x.status === "ARCHIVED"), `${RONDE} ronde ARCHIVED`);
cek(verifikasiRantai(svc.audit.entri).sah, `rantai hash audit utuh (${svc.audit.entri.length} entri)`);
let bocorKlien = 0;
for (const b of bots) for (const e of terima[b.i]!) if (e.ev !== "result:show" && /"solusi"|"sol"/.test(e.json) && e.ev !== "board:ack") bocorKlien++;
cek(bocorKlien === 0, "tidak ada pesan ke meja yang memuat solusi");
if (!arena) {
  const jebakan = s.flags.filter((f) => f.tipe === "JEBAKAN_SEED");
  cek(RONDE < 3 || (jebakan.length >= 1 && jebakan.every((f) => f.nomor === 2)), `Jebakan Seed terdeteksi pada bot penyalin (${jebakan.length} bendera, meja ${jebakan.map((f) => f.nomor).join(",")})`);
}
const rt = pesanLatensi.sort((a, b) => a - b);
const p95 = rt[Math.floor(rt.length * 0.95)] ?? 0;
cek(rt.length > 100 && p95 < 150, `latensi aksi (ack) p95 = ${p95.toFixed(1)} ms dari ${rt.length} sampel di luar jendela solver (< 150)`);
const sum = (await (await fetch(`${url}${BASE}/api/sessions/${sesi.id}/summary.json`, { headers: { "x-host-token": PIN } })).json()) as { game: string; siswa: { skor: number }[] };
cek(sum.game === "tower-peek" && sum.siswa.length === N && sum.siswa.some((x) => x.skor > 0), `summary.json untuk Gerbang: ${sum.siswa.length} siswa`);
const csv = await (await fetch(`${url}${BASE}/api/sessions/${sesi.id}/export?format=csv`, { headers: { "x-host-token": PIN } })).text();
cek(csv.trim().split("\n").length === 1 + N * RONDE, `ekspor CSV ${csv.trim().split("\n").length - 1} baris`);
// spread waktu bel antar-meja pada ronde terakhir diukur server (jam server tunggal); pemulihan via QR baru
if (!arena) {
  const baru = svc.pasangMeja(2)[0]!;
  const t0 = performance.now();
  const sk = sambung("/meja");
  await new Promise((r) => sk.on("connect", r));
  const st = new Promise((r) => sk.once("desk:state", r));
  const a = await ack(sk, "desk:hello", { token: baru.token, deviceId: "perangkat-cadangan" });
  await st;
  cek(a.ok && performance.now() - t0 < 10000, `pindah perangkat via QR baru pulih dalam ${Math.round(performance.now() - t0)} ms (< 10 dtk)`);
  sk.close();
}
for (const b of bots) b.s.close();
layar.close();
op.close();
await app.tutup();
void tOp;
console.log(gagal.length ? `\nGAGAL (${gagal.length}):\n- ${gagal.join("\n- ")}` : "\nSEMUA LULUS");
process.exit(gagal.length ? 1 : 0);
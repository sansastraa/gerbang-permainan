# CLAUDE.md — Clash of Git SIMPETERI: Modul Tower Peek

Kamu membangun **Tower Peek**, adaptasi game *Vertical Limit* untuk anak SD, sebagai modul platform **Clash of Git SIMPETERI**. Sistem terdiri atas back-end realtime dan tiga front-end: **Arena Operator** (`/operator`), **Meja Jawab** (`/meja/:nomor`), dan **Layar Siswa** (`/layar`, opsional `/tonton`). Semuanya berjalan offline di LAN.

## Sumber kebenaran
- `docs/SPEC.md` — rancang bangun lengkap (sama dengan dokumen Word). **Baca seluruhnya sebelum menulis kode.**
- `engine/puzzle.js` — generator, solver, varian simetri, hitung pengintip. **Sudah diuji** (`node engine/puzzle.test.js`). Port ke TypeScript tanpa mengubah perilaku; seed yang sama harus menghasilkan soal yang sama.
- `data/paket_soal.json` — paket soal resmi Mode SD dan Mode Champion, berisi solusi. **Hanya boleh dibaca server.**
- `config/tower_peek.config.json` — semua angka (waktu, poin, bel, sensor, anti-curang). Jangan hardcode.
- `reference/meja_jawab_prototype.js` — prototipe single-file three.js r128 untuk interaksi meja (kuas, ketuk bertumpuk, mata pengintip, kamera orbit). **Belum diuji end-to-end di browser**; pakai hanya sebagai referensi ide, bukan kode jadi.

## Aturan kerja
- Monorepo pnpm, TypeScript strict. Stack sesuai SPEC §3.3.
- **Server berwenang penuh**: solusi, waktu, urutan bel, dan penilaian hanya di server. `puzzle:deliver` tidak boleh memuat solusi. Tulis tes otomatis yang memeriksa ini.
- Namespace `/layar` hanya menerima data hasil Broadcast Director; selama LIVE **tidak boleh ada tinggi menara peserta** di payload.
- Meja bersebelahan wajib mendapat varian simetri berbeda (`engine.variant(p, k)`).
- Semua aset (three.js, font, suara) dibundel lokal. Tidak ada panggilan internet saat runtime.
- Teks UI Bahasa Indonesia ramah anak; nama game tetap "Tower Peek".
- Setiap milestone selesai = tes hijau + lint bersih + catatan di `docs/PROGRESS.md`. Berhenti dan laporkan setiap selesai satu milestone.

## Milestone
M0 Monorepo + port engine (tes lulus) → M1 Event/peserta/pemasangan meja (QR) → M2 Round Controller + Clock Service → M3 Meja Jawab papan 3D + input → M4 Mata Pengintip + bel layar/fisik → M5 Judge + skor dua mode → M6 Arena Operator → M7 Layar Siswa + sensor + reveal → M8 Anti-curang + audit log + replay → M9 Statistik & ekspor → M10 Simulasi 16 bot + uji putus-sambung + polish.
Kriteria tiap milestone ada di SPEC §11; target performa di SPEC §10.

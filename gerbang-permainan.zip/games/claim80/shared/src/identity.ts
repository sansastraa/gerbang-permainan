export const KOLOM_LABEL: Record<string, { nama: string; ikon: string }> = {
  A: { nama: "Numerik", ikon: "🔢" },
  B: { nama: "Bahasa Indonesia", ikon: "📖" },
  C: { nama: "Bahasa Inggris", ikon: "🔤" },
  D: { nama: "Pengetahuan Umum", ikon: "🌏" },
  E: { nama: "Aritmetika", ikon: "➗" },
  F: { nama: "Spasial", ikon: "🧊" },
  G: { nama: "Musikal", ikon: "🎵" },
  H: { nama: "Mystery", ikon: "❓" },
  I: { nama: "Sandi & Pola", ikon: "🔐" },
  J: { nama: "Logika", ikon: "🧩" },
};

const letters = (s: string) =>
  s
    .normalize("NFKD")
    .replace(/[^\p{L}]/gu, "")
    .toUpperCase();

/**
 * Inisial unik per siswa untuk ditulis di kartu yang diklaim. Dua huruf dari nama (kata pertama + kata terakhir);
 * bila bentrok, dicoba huruf berikutnya lalu angka, sehingga tiap siswa di satu kelas punya inisial berbeda.
 */
export function makeInitials(names: string[]): string[] {
  const used = new Set<string>();
  return names.map((full) => {
    const words = full
      .trim()
      .split(/\s+/)
      .map(letters)
      .filter((w) => w.length > 0);
    const first = words[0] ?? "?";
    const last = words.length > 1 ? words[words.length - 1]! : (first[1] ?? "");
    const candidates: string[] = [`${first[0]}${last[0] ?? ""}`];
    if (words.length > 1) candidates.push(`${first[0]}${words[1]![0]}`);
    for (let i = 1; i < first.length; i++) candidates.push(`${first[0]}${first[i]}`);
    let pick = candidates.find((c) => !used.has(c));
    if (!pick) {
      const base = candidates[0]!;
      for (let n = 2; !pick; n++) if (!used.has(`${base}${n}`)) pick = `${base}${n}`;
    }
    used.add(pick);
    return pick;
  });
}

/** Palet warna pemilik: sudut warna dibagi rata dengan selang terang/gelap agar berbeda untuk ≥ 25 murid. */
export function playerColor(index: number): string {
  const hue = Math.round((index * 137.508) % 360);
  const light = [46, 58, 38][index % 3]!;
  return `hsl(${hue} 68% ${light}%)`;
}

import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { badgesFileSchema, configSchema, validateBank } from "./schemas";

const root = new URL("../../", import.meta.url);
const read = (p: string) => JSON.parse(readFileSync(new URL(p, root), "utf8")) as unknown;

describe("berkas paket", () => {
  it("bank_soal.json lolos validasi dan berisi 160 soal", () => {
    const r = validateBank(read("data/bank_soal.json"));
    if (!r.ok) throw new Error(r.errors.join("\n"));
    expect(r.soal).toHaveLength(160);
  });
  it("menolak sel yang kurang varian", () => {
    const raw = read("data/bank_soal.json") as { soal: unknown[] };
    const r = validateBank({ ...raw, soal: raw.soal.slice(1) });
    expect(r.ok).toBe(false);
  });
  it("menolak opsi pg tanpa jawaban", () => {
    const raw = read("data/bank_soal.json") as { soal: Array<Record<string, unknown>> };
    const soal = raw.soal.map((s) => (s.id === "B1-1" ? { ...s, jawaban: "tidak ada" } : s));
    expect(validateBank({ ...raw, soal }).ok).toBe(false);
  });
  it("config dan badges valid", () => {
    expect(configSchema.safeParse(read("config/game.config.json")).success).toBe(true);
    expect(badgesFileSchema.safeParse(read("config/badges.json")).success).toBe(true);
  });
});

import { z } from "zod";

export const COLS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"] as const;
export const ROWS = [1, 2, 3, 4, 5, 6, 7, 8] as const;
export type Col = (typeof COLS)[number];

const levelSchema = z.number().int().min(1).max(8);
const baseItem = {
  // soal bank: A1-1 / A1-2; soal hasil generator parametrik: A3-g1f2e3d (sufiks "g" + hex)
  id: z.string().regex(/^[A-J][1-8]-([12]|g[0-9a-f]+)$/),
  sel: z.string().regex(/^[A-J][1-8]$/),
  kolom: z.enum(COLS),
  level: levelSchema,
  varian: z.number().int().min(1).max(2),
  kategori_kolom: z.string(),
  subkategori: z.string(),
  soal: z.string().min(1),
  waktu_detik: z.number().int().positive(),
  poin_dasar: z.number().int().positive(),
  satuan: z.string().optional(),
  audio: z
    .object({ notes: z.array(z.string().regex(/^[A-G][#b]?[0-8]$/)).min(1), durasi: z.number().positive() })
    .optional(),
  pembahasan: z.string(),
};

export const questionSchema = z.discriminatedUnion("tipe", [
  z.object({
    ...baseItem,
    tipe: z.literal("pg"),
    opsi: z.array(z.string().min(1)).min(2),
    jawaban: z.string(),
    acak_opsi: z.boolean(),
  }),
  z.object({ ...baseItem, tipe: z.literal("angka"), jawaban: z.number().finite(), toleransi: z.number().min(0) }),
  z.object({ ...baseItem, tipe: z.literal("teks"), jawaban_diterima: z.array(z.string().min(1)).min(1) }),
]);
export type Question = z.infer<typeof questionSchema>;

export const bankFileSchema = z.object({
  meta: z.object({ versi: z.string() }).passthrough(),
  soal: z.array(questionSchema),
});

export const configSchema = z
  .object({
    durasi_menit: z.number().positive(),
    fase: z.array(
      z.object({
        id: z.enum(["OPEN", "BATTLE", "RUSH", "END"]),
        mulai_menit: z.number().min(0),
        rebut_aktif: z.boolean().optional(),
        zona_pemula: z.boolean().optional(),
        pengali_poin: z.number().optional(),
      }),
    ),
    poin_per_level: z.record(z.string(), z.number()),
    pengali_kolom: z.record(z.string(), z.number()),
    streak: z.array(
      z.object({ min: z.number(), pengali: z.number(), label: z.string(), hadiah_power_up: z.boolean().optional() }),
    ),
    jackpot: z.object({ naik_per_gagal_persen: z.number(), maks_persen: z.number() }),
    cooldown: z.object({
      kartu_setelah_gagal_detik: z.number(),
      murid_setelah_gagal_detik: z.number(),
      murid_setelah_gagal_rebut_detik: z.number(),
    }),
    rebut: z.object({
      tiket_per_murid: z.number(),
      waktu_pengali: z.number(),
      perisai_setelah_bertahan_menit: z.number(),
      imun_setelah_direbut_menit: z.number(),
    }),
    kartu_spesial: z.object({ golden: z.number(), golden_pengali: z.number(), hadiah: z.number() }),
    pajak_juara: z.array(z.object({ min_kartu: z.number(), baris_minimal: z.number() })),
    zona_pemula: z.object({
      baris: z.array(z.number()),
      maks_kartu_dimiliki: z.number(),
      berlaku_sampai_menit: z.number(),
    }),
    combo: z.object({
      kolom_3: z.number(),
      pelangi_kategori: z.number(),
      pelangi_bonus: z.number(),
      wilayah_per_kartu_terhubung: z.number(),
    }),
    misi_kelas: z.object({ target_kartu_terklaim: z.number() }).passthrough(),
    anti_curang: z.object({
      fokus_hilang_peringatan_maks: z.number(),
      fokus_hilang_toleransi_ms: z.number(),
      waktu_baca_min_dasar_ms: z.number(),
      waktu_baca_min_per_kata_ms: z.number(),
      level_cek_terlalu_cepat_min: z.number(),
      relay_jendela_detik: z.number(),
      audio_putar_maks: z.number(),
    }),
    jeda_soal: z
      .object({ setiap: z.number().int().min(1), detik: z.number().min(0) })
      .passthrough()
      .default({ setiap: 2, detik: 5 }),
    pin_kelas: z
      .object({ ganti_tiap_menit: z.number().positive(), toleransi_detik: z.number().min(0) })
      .passthrough()
      .default({ ganti_tiap_menit: 5, toleransi_detik: 20 }),
    kecepatan: z
      .object({
        pengali_waktu: z.number().positive(),
        waktu_min_detik: z.number().positive(),
        batas_cepat_rasio: z.number().min(0).max(1),
        bonus_cepat_persen: z.number().min(0),
      })
      .passthrough(),
    papan_skor: z.object({ tampilkan_top: z.number() }).passthrough(),
    terjun_bebas: z.object({ level_minimal: z.number(), bonus: z.number() }).passthrough(),
    penakluk_puncak: z.object({ bonus: z.number() }).passthrough(),
    voice_over: z.object({}).passthrough(),
  })
  .passthrough();
export type GameConfig = z.infer<typeof configSchema>;

export const badgesFileSchema = z.object({
  badges: z.array(
    z.object({ id: z.string(), nama: z.string(), ikon: z.string(), syarat: z.string(), bonus: z.number() }),
  ),
});

/** Validasi tingkat bank (SPEC §7.5): tiap sel ≥ 2 varian, opsi pg memuat jawaban, angka bernilai numerik. */
export function validateBank(raw: unknown): { ok: true; soal: Question[] } | { ok: false; errors: string[] } {
  const parsed = bankFileSchema.safeParse(raw);
  if (!parsed.success) {
    return { ok: false, errors: parsed.error.issues.map((i) => `${i.path.join(".")}: ${i.message}`) };
  }
  const errors: string[] = [];
  const perSel = new Map<string, Set<number>>();
  const ids = new Set<string>();
  for (const q of parsed.data.soal) {
    if (ids.has(q.id)) errors.push(`${q.id}: id ganda`);
    ids.add(q.id);
    if (q.id !== `${q.sel}-${q.varian}`) errors.push(`${q.id}: id tidak cocok dengan sel/varian`);
    if (q.sel !== `${q.kolom}${q.level}`) errors.push(`${q.id}: sel tidak cocok dengan kolom/level`);
    if (!perSel.has(q.sel)) perSel.set(q.sel, new Set());
    perSel.get(q.sel)!.add(q.varian);
    if (q.tipe === "pg") {
      if (!q.opsi.includes(q.jawaban)) errors.push(`${q.id}: opsi tidak memuat jawaban`);
      if (new Set(q.opsi).size !== q.opsi.length) errors.push(`${q.id}: opsi ganda`);
    }
  }
  for (const c of COLS) {
    for (const r of ROWS) {
      if ((perSel.get(`${c}${r}`)?.size ?? 0) < 2) errors.push(`${c}${r}: kurang dari 2 varian`);
    }
  }
  return errors.length ? { ok: false, errors } : { ok: true, soal: parsed.data.soal };
}

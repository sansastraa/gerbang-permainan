import type { GameConfig } from "../schemas";

export type Phase = "LOBBY" | "OPEN" | "BATTLE" | "RUSH" | "END";
export type CardStatus = "OPEN" | "LOCKED" | "CLAIMED" | "COOLDOWN" | "CONTESTED";
export type PowerUp = "50_50" | "plus15" | "perisai" | "streak_saver" | "mata_elang" | "kunci_emas";
export const POWER_UPS: PowerUp[] = ["50_50", "plus15", "perisai", "streak_saver", "mata_elang", "kunci_emas"];
export const MAX_POWER_UPS = 3;

/** Aturan tambahan di luar game.config.json yang dibutuhkan engine (waktu per level berasal dari bank soal). */
export interface BadgeDef {
  id: string;
  nama: string;
  ikon: string;
  bonus: number;
  syarat?: string;
}

export interface Rules {
  config: GameConfig;
  /** definisi badge dari config/badges.json (opsional di tes) */
  badges?: BadgeDef[];
  /** detik per level (dari bank), sebelum pengali kecepatan */
  waktuPerLevel: Record<number, number>;
}

export interface Card {
  cell: string;
  col: string;
  row: number;
  status: CardStatus;
  owner: string | null;
  /** nilai poin yang dikunci saat diklaim */
  value: number;
  attempts: number;
  jackpotPct: number;
  golden: boolean;
  gift: boolean;
  lockedBy: string | null;
  challenger: string | null;
  cooldownUntil: number;
  shieldUntil: number;
  immuneUntil: number;
  prevOwner: string | null;
  /** urutan varian soal untuk kartu ini (diacak per sesi) */
  order: [1 | 2, 1 | 2];
  served: number;
  /** varian yang dipakai pemilik saat ini */
  claimedVariant: 1 | 2 | null;
  claimedAt: number;
}

export interface ActiveDelivery {
  cell: string;
  deliveryId: string;
  mode: "claim" | "steal";
  variant: 1 | 2;
  /** true bila kedua varian sudah terpakai (server memakai generator / acak ulang opsi) */
  reused: boolean;
  startedAt: number;
  deadline: number;
  totalMs: number;
  focusLost: number;
  used5050: boolean;
}

export interface Player {
  id: string;
  name: string;
  initials: string;
  color: string;
  joinedAt: number;
  streak: number;
  bestStreak: number;
  saver: boolean;
  goldenKey: boolean;
  powerUps: PowerUp[];
  tickets: number;
  cooldownUntil: number;
  frozenUntil: number;
  frozen: boolean;
  active: ActiveDelivery | null;
  bonus: number;
  attempts: number;
  correct: number;
  failsInRow: number;
  claims: number;
  stealsWon: number;
  defends: number;
  peakLevel: number;
  levelSum: number;
  colsTried: string[];
  firstClaimDone: boolean;
  lastClaimAt: number;
  /** sel klaim/rebut berhasil terakhir (untuk sanksi "batalkan klaim terakhir") */
  lastClaim: string | null;
  ahliAwarded: string[];
  pelangiAwarded: boolean;
  badges: string[];
  /** jumlah soal selesai sejak jeda terakhir (jeda tiap N soal) */
  sincePause: number;
  /** percobaan dan jawaban benar per kolom (untuk Raja/Ratu kategori dan laporan) */
  colStats: Record<string, { a: number; c: number }>;
}

export interface GameState {
  rules: Rules;
  seed: number;
  rng: number;
  phase: Phase;
  startedAt: number;
  pausedAt: number | null;
  endedAt: number | null;
  cards: Record<string, Card>;
  players: Record<string, Player>;
  /** kolom → id pemain yang pertama menaklukkan baris 8 */
  puncak: Record<string, string>;
  missionDone: boolean;
  wilayahApplied: boolean;
  /** pemain yang meraih klaim pertama sesi (First Blood) */
  firstBlood: string | null;
  /** peringkat tiap pemain 15 menit sebelum selesai (untuk Rising Star) */
  rankMark: Record<string, number> | null;
}

export type Action =
  | { type: "join"; playerId: string; name: string; initials: string; color: string }
  | { type: "start" }
  | { type: "claim"; playerId: string; cell: string; deliveryId: string }
  | { type: "steal"; playerId: string; cell: string; deliveryId: string }
  | { type: "answer"; playerId: string; deliveryId: string; correct: boolean }
  | { type: "focus_lost"; playerId: string; deliveryId: string }
  | { type: "powerup"; playerId: string; powerUp: PowerUp; cell?: string }
  | { type: "tick" }
  | { type: "host_phase"; phase: Exclude<Phase, "LOBBY"> }
  | { type: "host_pause" }
  | { type: "host_resume" }
  | { type: "host_freeze"; playerId: string; frozen: boolean; untilMs?: number }
  | { type: "host_void"; cell: string }
  | { type: "host_restore"; cell: string }
  | { type: "host_adjust"; playerId: string; delta: number; reason: string }
  | { type: "host_ticket"; playerId: string; delta: number; reason: string }
  | { type: "host_badge"; playerId: string; badgeId: string };

export type RejectReason =
  | "not_started"
  | "paused"
  | "ended"
  | "unknown_player"
  | "unknown_cell"
  | "frozen"
  | "has_active"
  | "player_cooldown"
  | "card_not_open"
  | "zona_pemula"
  | "pajak_juara"
  | "rebut_nonaktif"
  | "no_ticket"
  | "own_card"
  | "protected"
  | "not_claimed"
  | "bad_delivery"
  | "no_powerup"
  | "bad_powerup"
  | "reason_required";

export interface GameEvent {
  type:
    | "joined"
    | "started"
    | "phase"
    | "paused"
    | "resumed"
    | "locked"
    | "steal_started"
    | "claimed"
    | "stolen"
    | "claim_failed"
    | "steal_failed"
    | "cooldown_end"
    | "streak"
    | "powerup_granted"
    | "powerup_used"
    | "bonus"
    | "golden"
    | "gift"
    | "jackpot"
    | "focus_warning"
    | "mission"
    | "frozen"
    | "voided"
    | "restored"
    | "adjusted"
    | "tickets_changed"
    | "badge_awarded"
    | "player_paused"
    | "wilayah"
    | "ended"
    | "rejected";
  playerId?: string;
  cell?: string;
  data?: Record<string, string | number | boolean | null>;
}

export interface ReduceResult {
  state: GameState;
  events: GameEvent[];
}

import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { badgesFileSchema } from "../schemas";
import { legacyConfig } from "./testConfig";
import type { GameConfig } from "../schemas";
import { computeAwards, createGame, levelForXp, reduce, scoreOf, xpFromScore } from "./index";
import type { Action, GameEvent, GameState } from "./index";

const root = new URL("../../../", import.meta.url);
const baseConfig = legacyConfig;
const badges = badgesFileSchema.parse(JSON.parse(readFileSync(new URL("config/badges.json", root), "utf8"))).badges;
const waktuPerLevel = { 1: 30, 2: 30, 3: 45, 4: 60, 5: 60, 6: 90, 7: 120, 8: 180 };
const MIN = 60_000;

function harness(opts: { config?: GameConfig; players?: string[]; seed?: number } = {}) {
  let now = 1_000_000;
  let state: GameState = createGame({ config: opts.config ?? baseConfig, waktuPerLevel, badges }, opts.seed ?? 1);
  const log: GameEvent[] = [];
  const act = (a: Action) => {
    const r = reduce(state, a, now);
    state = r.state;
    log.push(...r.events);
    return r.events;
  };
  (opts.players ?? ["a", "b", "c"]).forEach((id, i) =>
    act({ type: "join", playerId: id, name: id.toUpperCase(), initials: id.toUpperCase(), color: `c${i}` }),
  );
  act({ type: "start" });
  let d = 0;
  return {
    get state() {
      return state;
    },
    log,
    act,
    advance(ms: number) {
      now += ms;
      act({ type: "tick" });
    },
    claim: (id: string, cell: string) => act({ type: "claim", playerId: id, cell, deliveryId: `d${++d}` }),
    answer(id: string, correct: boolean) {
      return act({ type: "answer", playerId: id, deliveryId: state.players[id]!.active!.deliveryId, correct });
    },
    win(id: string, cell: string) {
      this.claim(id, cell);
      return this.answer(id, true);
    },
    fail(id: string, cell: string) {
      this.claim(id, cell);
      return this.answer(id, false);
    },
    steal: (id: string, cell: string) => act({ type: "steal", playerId: id, cell, deliveryId: `s${++d}` }),
  };
}
const has = (ev: GameEvent[], id: string) => ev.some((e) => e.type === "badge_awarded" && e.data?.id === id);

describe("badge otomatis", () => {
  it("First Blood hanya untuk klaim pertama sesi (+10)", () => {
    const h = harness();
    expect(has(h.win("a", "E2"), "first_blood")).toBe(true);
    expect(h.state.players.a!.bonus).toBe(10);
    expect(has(h.win("b", "E3"), "first_blood")).toBe(false);
    expect(h.state.players.b!.badges).not.toContain("first_blood");
  });

  it("Sniper (baris 8, +20) dan tidak diberikan dua kali", () => {
    const h = harness();
    expect(has(h.win("a", "A8"), "sniper")).toBe(true);
    expect(has(h.win("a", "B8"), "sniper")).toBe(false);
    expect(h.state.players.a!.badges.filter((b) => b === "sniper")).toHaveLength(1);
  });

  it("Comeback Kid: klaim berhasil setelah 3 gagal beruntun (+15)", () => {
    const h = harness();
    for (const cell of ["A4", "B4", "C4"]) {
      h.fail("a", cell);
      h.advance(21_000);
    }
    expect(h.state.players.a!.badges).not.toContain("comeback_kid");
    expect(has(h.win("a", "D4"), "comeback_kid")).toBe(true);
  });

  it("Penjelajah: mencoba 8 kolom berbeda (+15); Pemberani: rata-rata level ≥ 5 dengan ≥ 4 percobaan (+15)", () => {
    const h = harness();
    h.advance(11 * MIN);
    for (const c of ["A", "B", "C", "D"]) h.win("a", `${c}5`);
    expect(h.state.players.a!.badges).toContain("pemberani");
    expect(h.state.players.a!.badges).not.toContain("penjelajah");
    // 5 kartu → baris ≥ 4; pakai baris 5 lagi
    for (const c of ["E", "F", "G"]) h.win("a", `${c}5`);
    expect(h.state.players.a!.colsTried.length).toBe(7);
    expect(has(h.win("a", "H5"), "penjelajah")).toBe(true);
  });

  it("Pemberani tidak diberikan bila rata-rata level di bawah 5", () => {
    const h = harness();
    for (const c of ["A", "B", "C", "D"]) h.win("a", `${c}3`);
    expect(h.state.players.a!.badges).not.toContain("pemberani");
  });

  it("Pencuri Ulung (2 rebut berhasil) dan Benteng (bertahan 2 kali)", () => {
    const h = harness();
    h.win("b", "A5");
    h.win("b", "B5");
    h.advance(16 * MIN);
    h.steal("a", "A5");
    h.answer("a", true);
    expect(h.state.players.a!.badges).not.toContain("pencuri_ulung");
    h.advance(4 * MIN); // imun kartu pertama selesai; kartu kedua milik b tidak terlindungi
    h.steal("a", "B5");
    expect(has(h.answer("a", true), "pencuri_ulung")).toBe(true);

    const h2 = harness();
    h2.win("b", "A5");
    h2.win("b", "B5");
    h2.advance(16 * MIN);
    h2.steal("a", "A5");
    h2.answer("a", false);
    h2.advance(31_000);
    h2.steal("a", "B5");
    const ev = h2.answer("a", false);
    expect(has(ev, "benteng")).toBe(true);
    expect(h2.state.players.b!.badges).toContain("benteng");
    expect(h2.state.players.b!.bonus).toBe(10 + 10 + 10 + 20); // First Blood + 2× Benteng Kokoh + badge Benteng
  });

  it("Ahli Kolom memberi combo +30 dan badge ahli_X (bonus 0); Polymath lewat Pelangi", () => {
    const h = harness();
    h.advance(11 * MIN);
    h.win("a", "A4");
    h.win("a", "A5");
    const ev = h.win("a", "A6");
    expect(has(ev, "ahli_A")).toBe(true);
    expect(ev.some((e) => e.data?.why === "ahli_A")).toBe(true);
    h.advance(20_000);
    for (const c of ["B", "C", "D"]) h.win("a", `${c}4`);
    h.win("a", "E4");
    expect(has(h.win("a", "F4"), "polymath")).toBe(true);
  });

  it("Kelas Juara untuk semua murid saat misi kelas tercapai", () => {
    const cfg = { ...baseConfig, misi_kelas: { ...baseConfig.misi_kelas, target_kartu_terklaim: 2 } };
    const h = harness({ config: cfg });
    h.win("a", "A3");
    const ev = h.win("b", "B3");
    expect(has(ev, "kelas_juara")).toBe(true);
    for (const id of ["a", "b", "c"]) expect(h.state.players[id]!.badges).toContain("kelas_juara");
  });

  it("badge manual Jujur Itu Keren (+20) hanya sekali; badge lain tidak bisa diberikan manual", () => {
    const h = harness();
    expect(has(h.act({ type: "host_badge", playerId: "a", badgeId: "jujur_itu_keren" }), "jujur_itu_keren")).toBe(true);
    expect(scoreOf(h.state, "a")).toBe(20);
    expect(h.act({ type: "host_badge", playerId: "a", badgeId: "jujur_itu_keren" })[0]!.type).toBe("rejected");
    expect(h.act({ type: "host_badge", playerId: "a", badgeId: "sniper" })[0]!.type).toBe("rejected");
    expect(h.act({ type: "host_badge", playerId: "zzz", badgeId: "jujur_itu_keren" })[0]!.type).toBe("rejected");
  });

  it("tanpa definisi badge (tes lama) engine tetap berjalan", () => {
    let st = createGame({ config: baseConfig, waktuPerLevel }, 1);
    st = reduce(st, { type: "join", playerId: "a", name: "A", initials: "A", color: "x" }, 0).state;
    st = reduce(st, { type: "start" }, 0).state;
    const r = reduce(st, { type: "claim", playerId: "a", cell: "A1", deliveryId: "1" }, 1000);
    expect(r.events[0]!.type).toBe("locked");
  });
});

describe("penghargaan akhir", () => {
  it("Juara Umum, Raja/Ratu kategori (min 2 percobaan), Penjaga Benteng, Paling Berani", () => {
    const h = harness({ players: ["a", "b", "c", "d"] });
    // a: aritmetika 2/2 ; b: aritmetika 2 dari 3 ; c: hanya 1 percobaan
    h.win("a", "E4");
    h.win("a", "E5");
    h.win("b", "E6");
    h.win("b", "E7");
    h.advance(21_000);
    h.fail("b", "E8");
    h.advance(21_000);
    h.win("c", "G4");
    h.win("b", "F6"); // percobaan ke-4 b: rata-rata level (6+7+8+6)/4
    const aw = computeAwards(h.state);
    const byId = Object.fromEntries(aw.map((x) => [x.id, x]));
    expect(byId.juara_1).toBeDefined();
    expect(byId.raja_aritmetika!.playerIds).toEqual(["a"]);
    expect(byId.raja_musikal).toBeUndefined(); // c hanya 1 percobaan
    expect(byId.paling_berani!.playerIds).toEqual(["b"]); // hanya b yang punya ≥ 4 percobaan
  });

  it("Rising Star memakai peringkat 15 menit sebelum selesai; Penjaga Benteng dari jumlah bertahan", () => {
    const h = harness({ players: ["a", "b", "c"] });
    h.win("a", "E4");
    h.win("a", "E5"); // a unggul di awal
    h.win("b", "E3");
    h.advance(26 * MIN); // lewat menit 25 → rankMark tercatat (durasi 40)
    expect(h.state.rankMark).not.toBeNull();
    expect(h.state.rankMark!.a).toBe(1);
    h.win("c", "J8");
    h.win("c", "I8");
    h.win("c", "H8");
    h.act({ type: "host_phase", phase: "END" });
    const aw = computeAwards(h.state);
    const rs = aw.find((x) => x.id === "rising_star");
    expect(rs?.playerIds).toEqual(["c"]);
  });

  it("tanpa pemain atau tanpa skor tidak menghasilkan penghargaan yang aneh", () => {
    expect(computeAwards(createGame({ config: baseConfig, waktuPerLevel }, 1))).toEqual([]);
    const h = harness();
    expect(computeAwards(h.state).filter((x) => x.id.startsWith("juara"))).toEqual([]);
  });

  it("deterministik", () => {
    const run = () => {
      const h = harness({ seed: 5 });
      h.win("a", "E4");
      h.win("b", "A5");
      return JSON.stringify(computeAwards(h.state));
    };
    expect(run()).toBe(run());
  });
});

describe("XP lintas sesi", () => {
  it("XP = skor ÷ 10 dan level naik sesuai ambang", () => {
    expect(xpFromScore(0)).toBe(0);
    expect(xpFromScore(499)).toBe(49);
    expect(levelForXp(0).nama).toBe("Pemula");
    expect(levelForXp(49).nama).toBe("Pemula");
    expect(levelForXp(50).nama).toBe("Penjelajah");
    expect(levelForXp(150).nama).toBe("Ahli");
    expect(levelForXp(400).nama).toBe("Master");
    expect(levelForXp(900)).toEqual({ nama: "Grandmaster", index: 4, next: null });
    expect(levelForXp(60).next).toBe(150);
  });
});

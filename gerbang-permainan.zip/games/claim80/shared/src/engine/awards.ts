import { leaderboard } from "./scoring";
import type { GameState } from "./types";

export interface Award {
  id: string;
  title: string;
  ikon: string;
  playerIds: string[];
  detail: string;
}

/** Kelompok kategori untuk Raja/Ratu (SPEC §6.2: B+C = Linguistik, I+J = Logika; kolom H tidak dihitung). */
export const AWARD_GROUPS: { id: string; nama: string; ikon: string; cols: string[] }[] = [
  { id: "numerik", nama: "Numerik", ikon: "🔢", cols: ["A"] },
  { id: "linguistik", nama: "Linguistik", ikon: "📖", cols: ["B", "C"] },
  { id: "pengetahuan", nama: "Pengetahuan Umum", ikon: "🌏", cols: ["D"] },
  { id: "aritmetika", nama: "Aritmetika", ikon: "➗", cols: ["E"] },
  { id: "spasial", nama: "Spasial", ikon: "🧊", cols: ["F"] },
  { id: "musikal", nama: "Musikal", ikon: "🎵", cols: ["G"] },
  { id: "logika", nama: "Logika", ikon: "🧩", cols: ["I", "J"] },
];

const MIN_ATTEMPTS_KATEGORI = 2;
const MIN_ATTEMPTS_BERANI = 4;

/**
 * Penghargaan akhir (SPEC §4.7): banyak pemenang agar banyak murid mendapat panggung.
 * Murni dan deterministik: seri dipecah dengan jumlah benar, lalu urutan id.
 */
export function computeAwards(s: GameState): Award[] {
  const out: Award[] = [];
  const players = Object.values(s.players);
  if (players.length === 0) return out;
  const lb = leaderboard(s);
  const name = (id: string) => s.players[id]?.name ?? id;

  lb.slice(0, 3).forEach((r, i) => {
    if (r.score <= 0) return;
    out.push({
      id: `juara_${i + 1}`,
      title: `Juara Umum ${i + 1}`,
      ikon: ["🥇", "🥈", "🥉"][i]!,
      playerIds: [r.playerId],
      detail: `${name(r.playerId)} · ${r.score} poin`,
    });
  });

  for (const g of AWARD_GROUPS) {
    let best: { id: string; acc: number; c: number } | null = null;
    for (const p of players) {
      let a = 0;
      let c = 0;
      for (const col of g.cols) {
        a += p.colStats[col]?.a ?? 0;
        c += p.colStats[col]?.c ?? 0;
      }
      if (a < MIN_ATTEMPTS_KATEGORI || c === 0) continue;
      const cand = { id: p.id, acc: c / a, c };
      if (
        !best ||
        cand.acc > best.acc ||
        (cand.acc === best.acc && (cand.c > best.c || (cand.c === best.c && cand.id < best.id)))
      ) {
        best = cand;
      }
    }
    if (best) {
      out.push({
        id: `raja_${g.id}`,
        title: `Raja/Ratu ${g.nama}`,
        ikon: g.ikon,
        playerIds: [best.id],
        detail: `${name(best.id)} · akurasi ${Math.round(best.acc * 100)}%`,
      });
    }
  }

  if (s.rankMark) {
    const mark = s.rankMark;
    let best: { id: string; gain: number; rank: number } | null = null;
    lb.forEach((r, i) => {
      const before = mark[r.playerId];
      if (before === undefined) return;
      const gain = before - (i + 1);
      if (gain > 0 && (!best || gain > best.gain || (gain === best.gain && i + 1 < best.rank))) {
        best = { id: r.playerId, gain, rank: i + 1 };
      }
    });
    const b = best as { id: string; gain: number; rank: number } | null;
    if (b) {
      out.push({
        id: "rising_star",
        title: "Rising Star",
        ikon: "🚀",
        playerIds: [b.id],
        detail: `${name(b.id)} · naik ${b.gain} peringkat di 15 menit terakhir`,
      });
    }
  }

  let brave: { id: string; avg: number } | null = null;
  for (const p of players) {
    if (p.attempts < MIN_ATTEMPTS_BERANI) continue;
    const avg = p.levelSum / p.attempts;
    if (!brave || avg > brave.avg || (avg === brave.avg && p.id < brave.id)) brave = { id: p.id, avg };
  }
  if (brave) {
    out.push({
      id: "paling_berani",
      title: "Paling Berani",
      ikon: "🦁",
      playerIds: [brave.id],
      detail: `${name(brave.id)} · rata-rata level ${brave.avg.toFixed(1)}`,
    });
  }

  let guard: { id: string; n: number } | null = null;
  for (const p of players) {
    if (p.defends < 1) continue;
    if (!guard || p.defends > guard.n || (p.defends === guard.n && p.id < guard.id)) guard = { id: p.id, n: p.defends };
  }
  if (guard) {
    out.push({
      id: "penjaga_benteng",
      title: "Penjaga Benteng",
      ikon: "🏰",
      playerIds: [guard.id],
      detail: `${name(guard.id)} · bertahan ${guard.n} kali`,
    });
  }
  return out;
}

/** Level murid lintas sesi dari XP (XP = total skor ÷ 10; SPEC §4.8). */
export const XP_LEVELS: { min: number; nama: string }[] = [
  { min: 0, nama: "Pemula" },
  { min: 50, nama: "Penjelajah" },
  { min: 150, nama: "Ahli" },
  { min: 400, nama: "Master" },
  { min: 900, nama: "Grandmaster" },
];

export function xpFromScore(score: number): number {
  return Math.max(0, Math.floor(score / 10));
}

export function levelForXp(xp: number): { nama: string; index: number; next: number | null } {
  let idx = 0;
  XP_LEVELS.forEach((l, i) => {
    if (xp >= l.min) idx = i;
  });
  return { nama: XP_LEVELS[idx]!.nama, index: idx, next: XP_LEVELS[idx + 1]?.min ?? null };
}

import type { GameConfig } from "../schemas";
import type { Card, GameState, Player } from "./types";

export function streakTier(config: GameConfig, streak: number) {
  let best: GameConfig["streak"][number] | null = null;
  for (const t of config.streak) if (streak >= t.min && (!best || t.min > best.min)) best = t;
  return best;
}

export function streakMultiplier(config: GameConfig, streak: number): number {
  return streakTier(config, streak)?.pengali ?? 1;
}

export function phaseMultiplier(s: GameState): number {
  return s.rules.config.fase.find((f) => f.id === s.phase)?.pengali_poin ?? 1;
}

/** Waktu efektif satu soal (ms): anti-AI, waktu bank dipersingkat. */
export function effectiveTimeMs(s: GameState, level: number, mode: "claim" | "steal"): number {
  const k = s.rules.config.kecepatan;
  const base = s.rules.waktuPerLevel[level] ?? 60;
  let sec = Math.max(k.waktu_min_detik, Math.round(base * k.pengali_waktu));
  if (mode === "steal") sec = Math.max(k.waktu_min_detik * 0.75, Math.round(sec * s.rules.config.rebut.waktu_pengali));
  return Math.round(sec * 1000);
}

export interface ValueInput {
  card: Card;
  streak: number;
  goldenKey: boolean;
  /** rasio waktu terpakai terhadap total (0..1) */
  usedRatio: number;
}

/** nilai kartu = poin_dasar × kolom × jackpot × golden × fase × streak × kunci emas × cepat (SPEC §3.5). */
export function cardValue(s: GameState, i: ValueInput): number {
  const cfg = s.rules.config;
  const base = cfg.poin_per_level[String(i.card.row)] ?? 0;
  let v = base * (cfg.pengali_kolom[i.card.col] ?? 1);
  v *= 1 + i.card.jackpotPct / 100;
  if (i.card.golden) v *= cfg.kartu_spesial.golden_pengali;
  if (i.goldenKey) v *= 2;
  v *= phaseMultiplier(s);
  v *= streakMultiplier(cfg, i.streak);
  if (i.usedRatio <= cfg.kecepatan.batas_cepat_rasio) v *= 1 + cfg.kecepatan.bonus_cepat_persen / 100;
  return Math.round(v);
}

export function territoryScore(s: GameState, playerId: string): number {
  let n = 0;
  for (const c of Object.values(s.cards))
    if (c.owner === playerId && (c.status === "CLAIMED" || c.status === "CONTESTED")) n += c.value;
  return n;
}

export function scoreOf(s: GameState, playerId: string): number {
  const p = s.players[playerId];
  return p ? territoryScore(s, playerId) + p.bonus : 0;
}

export interface LeaderRow {
  playerId: string;
  score: number;
  cards: number;
}

/** Papan skor penuh. Seri: level puncak → akurasi → waktu klaim terakhir lebih awal (SPEC §3.5). */
export function leaderboard(s: GameState): LeaderRow[] {
  const rows = Object.values(s.players).map((p: Player) => ({
    playerId: p.id,
    score: scoreOf(s, p.id),
    cards: Object.values(s.cards).filter(
      (c) => c.owner === p.id && (c.status === "CLAIMED" || c.status === "CONTESTED"),
    ).length,
  }));
  const pl = s.players;
  return rows.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    const pa = pl[a.playerId]!;
    const pb = pl[b.playerId]!;
    if (pb.peakLevel !== pa.peakLevel) return pb.peakLevel - pa.peakLevel;
    const acc = (p: Player) => (p.attempts ? p.correct / p.attempts : 0);
    if (acc(pb) !== acc(pa)) return acc(pb) - acc(pa);
    return pa.lastClaimAt - pb.lastClaimAt;
  });
}

import type { GameState, Player, RejectReason } from "./types";

export type Check = { ok: true } | { ok: false; reason: RejectReason; message: string };
const no = (reason: RejectReason, message: string): Check => ({ ok: false, reason, message });

export function elapsedMs(s: GameState, now: number): number {
  return Math.max(0, (s.pausedAt ?? now) - s.startedAt);
}

export function ownedCount(s: GameState, playerId: string): number {
  let n = 0;
  for (const c of Object.values(s.cards))
    if (c.owner === playerId && (c.status === "CLAIMED" || c.status === "CONTESTED")) n++;
  return n;
}

function playerGate(s: GameState, p: Player | undefined, now: number): Check {
  if (s.phase === "LOBBY") return no("not_started", "Permainan belum dimulai.");
  if (s.phase === "END") return no("ended", "Permainan sudah selesai.");
  if (s.pausedAt !== null) return no("paused", "Permainan sedang dijeda guru.");
  if (!p) return no("unknown_player", "Kamu belum terdaftar.");
  if (p.frozen || p.frozenUntil > now) return no("frozen", "Kamu sedang dibekukan guru.");
  if (p.active) return no("has_active", "Selesaikan dulu kartu yang sedang kamu kerjakan.");
  if (p.cooldownUntil > now) {
    return no("player_cooldown", `Tarik napas dulu ya, tunggu ${Math.ceil((p.cooldownUntil - now) / 1000)} detik.`);
  }
  return { ok: true };
}

/** Kelayakan membuka kartu OPEN (SPEC §3.3). */
export function canClaim(s: GameState, playerId: string, cell: string, now: number): Check {
  const p = s.players[playerId];
  const gate = playerGate(s, p, now);
  if (!gate.ok) return gate;
  const card = s.cards[cell];
  if (!card) return no("unknown_cell", "Kartu tidak ada.");
  if (card.status !== "OPEN") return no("card_not_open", "Kartu ini sedang dipakai atau sudah diklaim.");
  const cfg = s.rules.config;
  const owned = ownedCount(s, playerId);
  const zp = cfg.zona_pemula;
  if (
    elapsedMs(s, now) < zp.berlaku_sampai_menit * 60_000 &&
    zp.baris.includes(card.row) &&
    owned > zp.maks_kartu_dimiliki
  ) {
    return no("zona_pemula", "Baris 1–2 dulu untuk teman yang belum punya kartu. Coba baris yang lebih tinggi ya!");
  }
  let minRow = 1;
  for (const t of cfg.pajak_juara) if (owned >= t.min_kartu) minRow = Math.max(minRow, t.baris_minimal);
  if (card.row < minRow) {
    return no("pajak_juara", `Kamu sudah jago! Coba kartu baris ${minRow} ke atas 💪`);
  }
  return { ok: true };
}

/** Kelayakan merebut kartu CLAIMED milik orang lain (SPEC §3.4). */
export function canSteal(s: GameState, playerId: string, cell: string, now: number): Check {
  const p = s.players[playerId];
  const gate = playerGate(s, p, now);
  if (!gate.ok) return gate;
  const fase = s.rules.config.fase.find((f) => f.id === s.phase);
  if (!fase?.rebut_aktif) return no("rebut_nonaktif", "Rebut baru dibuka di fase BATTLE.");
  if (!p || p.tickets <= 0) return no("no_ticket", "Tiket rebutmu sudah habis.");
  const card = s.cards[cell];
  if (!card) return no("unknown_cell", "Kartu tidak ada.");
  if (card.status !== "CLAIMED") return no("not_claimed", "Hanya kartu yang sudah diklaim yang bisa direbut.");
  if (card.owner === playerId) return no("own_card", "Ini kartumu sendiri.");
  if (card.shieldUntil > now || card.immuneUntil > now) return no("protected", "Kartu ini sedang dilindungi.");
  return { ok: true };
}

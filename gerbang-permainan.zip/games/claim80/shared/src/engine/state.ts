import { COLS, ROWS } from "../schemas";
import { ahliKolom, kategoriDimiliki, wilayahTerbesar } from "./combos";
import { canClaim, canSteal } from "./eligibility";
import type { Check } from "./eligibility";
import { cardValue, effectiveTimeMs, leaderboard, streakTier } from "./scoring";
import { MAX_POWER_UPS, POWER_UPS } from "./types";
import type { Action, Card, GameEvent, GameState, Phase, Player, PowerUp, ReduceResult, Rules } from "./types";

const MIN = 60_000;

/** RNG deterministik (mulberry32); state.rng ikut maju sehingga reduce tetap murni dan dapat di-replay. */
function rand(s: GameState): number {
  s.rng = (s.rng + 0x6d2b79f5) >>> 0;
  let t = s.rng;
  t = Math.imul(t ^ (t >>> 15), t | 1);
  t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
  return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
}

export function createGame(rules: Rules, seed: number): GameState {
  const s: GameState = {
    rules,
    seed,
    rng: seed >>> 0,
    phase: "LOBBY",
    startedAt: 0,
    pausedAt: null,
    endedAt: null,
    cards: {},
    players: {},
    puncak: {},
    missionDone: false,
    wilayahApplied: false,
    firstBlood: null,
    rankMark: null,
  };
  for (const col of COLS) {
    for (const row of ROWS) {
      const cell = `${col}${row}`;
      // Paket soal diacak per sesi: varian 1/2 mana yang tampil lebih dulu (SPEC §3.2, permintaan guru).
      const order: [1 | 2, 1 | 2] = rand(s) < 0.5 ? [1, 2] : [2, 1];
      s.cards[cell] = {
        cell,
        col,
        row,
        status: "OPEN",
        owner: null,
        value: 0,
        attempts: 0,
        jackpotPct: 0,
        golden: false,
        gift: false,
        lockedBy: null,
        challenger: null,
        cooldownUntil: 0,
        shieldUntil: 0,
        immuneUntil: 0,
        prevOwner: null,
        order,
        served: 0,
        claimedVariant: null,
        claimedAt: 0,
      };
    }
  }
  const cells = Object.keys(s.cards);
  for (let i = cells.length - 1; i > 0; i--) {
    const j = Math.floor(rand(s) * (i + 1));
    [cells[i], cells[j]] = [cells[j]!, cells[i]!];
  }
  const ks = rules.config.kartu_spesial;
  cells.slice(0, ks.golden).forEach((c) => (s.cards[c]!.golden = true));
  cells.slice(ks.golden, ks.golden + ks.hadiah).forEach((c) => (s.cards[c]!.gift = true));
  return s;
}

export function newPlayer(
  s: GameState,
  a: { id: string; name: string; initials: string; color: string },
  now: number,
): Player {
  return {
    id: a.id,
    name: a.name,
    initials: a.initials,
    color: a.color,
    joinedAt: now,
    streak: 0,
    bestStreak: 0,
    saver: false,
    goldenKey: false,
    powerUps: [],
    tickets: s.rules.config.rebut.tiket_per_murid,
    cooldownUntil: 0,
    frozenUntil: 0,
    frozen: false,
    active: null,
    bonus: 0,
    attempts: 0,
    correct: 0,
    failsInRow: 0,
    claims: 0,
    stealsWon: 0,
    defends: 0,
    peakLevel: 0,
    levelSum: 0,
    colsTried: [],
    firstClaimDone: false,
    lastClaimAt: 0,
    lastClaim: null,
    ahliAwarded: [],
    pelangiAwarded: false,
    badges: [],
    sincePause: 0,
    colStats: {},
  };
}

type Ev = GameEvent[];

function addBonus(p: Player, amount: number, why: string, ev: Ev, cell?: string) {
  p.bonus += amount;
  ev.push({ type: "bonus", playerId: p.id, ...(cell ? { cell } : {}), data: { amount, why } });
}

function grantPowerUp(s: GameState, p: Player, ev: Ev, source: string) {
  if (p.powerUps.length >= MAX_POWER_UPS) return;
  const pu = POWER_UPS[Math.floor(rand(s) * POWER_UPS.length)]!;
  p.powerUps.push(pu);
  ev.push({ type: "powerup_granted", playerId: p.id, data: { powerUp: pu, source } });
}

function reject(
  state: GameState,
  a: { playerId?: string; cell?: string },
  c: Extract<Check, { ok: false }>,
): ReduceResult {
  return {
    state,
    events: [
      {
        type: "rejected",
        ...(a.playerId ? { playerId: a.playerId } : {}),
        ...(a.cell ? { cell: a.cell } : {}),
        data: { reason: c.reason, message: c.message },
      },
    ],
  };
}

function rejectSimple(
  state: GameState,
  a: { playerId?: string; cell?: string },
  reason: string,
  message: string,
): ReduceResult {
  return {
    state,
    events: [
      {
        type: "rejected",
        ...(a.playerId ? { playerId: a.playerId } : {}),
        ...(a.cell ? { cell: a.cell } : {}),
        data: { reason, message },
      },
    ],
  };
}

function setPhase(s: GameState, phase: Phase, now: number, ev: Ev) {
  s.phase = phase;
  ev.push({ type: "phase", data: { phase } });
  if (phase === "END") finalize(s, now, ev);
}

function finalize(s: GameState, now: number, ev: Ev) {
  for (const p of Object.values(s.players)) {
    if (!p.active) continue;
    const card = s.cards[p.active.cell]!;
    if (card.status === "LOCKED") {
      card.status = "OPEN";
      card.lockedBy = null;
    } else if (card.status === "CONTESTED") {
      card.status = "CLAIMED";
      card.challenger = null;
    }
    p.active = null;
  }
  for (const c of Object.values(s.cards)) if (c.status === "COOLDOWN") c.status = "OPEN";
  if (!s.wilayahApplied) {
    s.wilayahApplied = true;
    const per = s.rules.config.combo.wilayah_per_kartu_terhubung;
    for (const p of Object.values(s.players)) {
      const size = wilayahTerbesar(s, p.id);
      if (size >= 2) {
        addBonus(p, size * per, "wilayah", ev);
        ev.push({ type: "wilayah", playerId: p.id, data: { size } });
      }
    }
  }
  s.endedAt = now;
  ev.push({ type: "ended" });
}

function claimedCount(s: GameState): number {
  return Object.values(s.cards).filter((c) => c.status === "CLAIMED" || c.status === "CONTESTED").length;
}

/** Memberi badge satu kali (jika didefinisikan di config/badges.json) beserta bonus poinnya. */
function grantBadge(s: GameState, p: Player, id: string, ev: Ev) {
  const def = s.rules.badges?.find((b) => b.id === id);
  if (!def || p.badges.includes(id)) return;
  p.badges.push(id);
  if (def.bonus) p.bonus += def.bonus;
  ev.push({ type: "badge_awarded", playerId: p.id, data: { id, nama: def.nama, ikon: def.ikon, bonus: def.bonus } });
}

/** Badge otomatis (SPEC §4.5) yang dinilai dari kondisi pemain saat ini. */
function checkBadges(s: GameState, p: Player, ev: Ev, flags: { claimRow8?: boolean; comeback?: boolean } = {}) {
  if (flags.claimRow8) grantBadge(s, p, "sniper", ev);
  if (flags.comeback) grantBadge(s, p, "comeback_kid", ev);
  if (p.stealsWon >= 2) grantBadge(s, p, "pencuri_ulung", ev);
  if (p.defends >= 2) grantBadge(s, p, "benteng", ev);
  if (p.colsTried.length >= 8) grantBadge(s, p, "penjelajah", ev);
  // levelSum dan attempts selaras hanya ketika tidak ada soal yang sedang dikerjakan
  if (!p.active && p.attempts >= 4 && p.levelSum / p.attempts >= 5) grantBadge(s, p, "pemberani", ev);
  if (p.pelangiAwarded) grantBadge(s, p, "polymath", ev);
  for (const col of p.ahliAwarded) grantBadge(s, p, `ahli_${col}`, ev);
}

/** Jeda singkat setiap N soal selesai (benar atau salah) agar giliran terbagi ke teman lain. */
function pauseAfterAnswer(s: GameState, p: Player, now: number, ev: Ev) {
  const j = s.rules.config.jeda_soal;
  if (j.detik <= 0) return;
  p.sincePause++;
  if (p.sincePause < j.setiap) return;
  p.sincePause = 0;
  p.cooldownUntil = Math.max(p.cooldownUntil, now + j.detik * 1000);
  ev.push({ type: "player_paused", playerId: p.id, data: { detik: j.detik } });
}

function bumpColStat(p: Player, col: string, correct: boolean) {
  const st = (p.colStats[col] ??= { a: 0, c: 0 });
  st.a++;
  if (correct) st.c++;
}

/** Dipanggil saat jawaban benar (klaim atau rebut berhasil). */
function awardCorrect(s: GameState, p: Player, card: Card, mode: "claim" | "steal", now: number, ev: Ev) {
  const act = p.active!;
  const cfg = s.rules.config;
  const usedRatio = Math.min(1, Math.max(0, (now - act.startedAt) / act.totalMs));
  const streak = p.streak + 1;
  const value = cardValue(s, { card, streak, goldenKey: p.goldenKey, usedRatio });
  const comeback = p.failsInRow >= 3;
  const prevOwner = card.owner;

  card.prevOwner = mode === "steal" ? prevOwner : card.prevOwner;
  card.owner = p.id;
  card.status = "CLAIMED";
  card.value = value;
  card.claimedVariant = act.variant;
  card.claimedAt = now;
  card.lockedBy = null;
  card.challenger = null;
  if (mode === "steal") card.immuneUntil = now + cfg.rebut.imun_setelah_direbut_menit * MIN;

  const hadGoldenKey = p.goldenKey;
  p.goldenKey = false;
  p.active = null;
  p.streak = streak;
  p.bestStreak = Math.max(p.bestStreak, streak);
  p.attempts++;
  p.correct++;
  bumpColStat(p, card.col, true);
  p.claims++;
  p.failsInRow = 0;
  p.peakLevel = Math.max(p.peakLevel, card.row);
  p.lastClaimAt = now;
  p.lastClaim = card.cell;
  const fast = usedRatio <= cfg.kecepatan.batas_cepat_rasio;

  ev.push({
    type: mode === "claim" ? "claimed" : "stolen",
    playerId: p.id,
    cell: card.cell,
    data: {
      value,
      streak,
      variant: act.variant,
      golden: card.golden,
      goldenKey: hadGoldenKey,
      fast,
      comeback,
      from: prevOwner,
    },
  });

  if (mode === "steal") p.stealsWon++;
  if (mode === "claim") {
    if (card.golden) ev.push({ type: "golden", playerId: p.id, cell: card.cell });
    if (card.gift) {
      card.gift = false;
      ev.push({ type: "gift", playerId: p.id, cell: card.cell });
      grantPowerUp(s, p, ev, "gift");
    }
    if (!p.firstClaimDone && card.row >= cfg.terjun_bebas.level_minimal) {
      addBonus(p, cfg.terjun_bebas.bonus, "terjun_bebas", ev, card.cell);
    }
    p.firstClaimDone = true;
    if (!s.firstBlood) {
      s.firstBlood = p.id;
      grantBadge(s, p, "first_blood", ev);
    }
    if (card.row === 8 && !s.puncak[card.col]) {
      s.puncak[card.col] = p.id;
      addBonus(p, cfg.penakluk_puncak.bonus, "penakluk_puncak", ev, card.cell);
    }
  }

  const tier = streakTier(cfg, streak);
  if (tier && tier.min === streak) {
    ev.push({ type: "streak", playerId: p.id, data: { streak, label: tier.label } });
    if (tier.hadiah_power_up) grantPowerUp(s, p, ev, "streak");
  }

  for (const col of ahliKolom(s, p.id)) {
    if (!p.ahliAwarded.includes(col)) {
      p.ahliAwarded.push(col);
      addBonus(p, cfg.combo.kolom_3, `ahli_${col}`, ev);
    }
  }
  if (!p.pelangiAwarded && kategoriDimiliki(s, p.id) >= cfg.combo.pelangi_kategori) {
    p.pelangiAwarded = true;
    addBonus(p, cfg.combo.pelangi_bonus, "pelangi", ev);
  }

  if (!s.missionDone && claimedCount(s) >= cfg.misi_kelas.target_kartu_terklaim) {
    s.missionDone = true;
    ev.push({ type: "mission", data: { claimed: claimedCount(s) } });
    for (const q of Object.values(s.players)) {
      grantPowerUp(s, q, ev, "misi");
      grantBadge(s, q, "kelas_juara", ev);
    }
  }
  checkBadges(s, p, ev, { claimRow8: mode === "claim" && card.row === 8, comeback: mode === "claim" && comeback });
  pauseAfterAnswer(s, p, now, ev);
}

function breakStreak(p: Player, ev: Ev) {
  if (p.saver) {
    p.saver = false;
    ev.push({ type: "powerup_used", playerId: p.id, data: { powerUp: "streak_saver", auto: true } });
  } else {
    p.streak = 0;
  }
}

/** Dipanggil saat jawaban salah / waktu habis / fokus hilang. */
function awardFail(s: GameState, p: Player, reason: string, now: number, ev: Ev) {
  const act = p.active!;
  const cfg = s.rules.config;
  const card = s.cards[act.cell]!;
  p.active = null;
  p.attempts++;
  bumpColStat(p, card.col, false);
  p.failsInRow++;
  breakStreak(p, ev);
  if (act.mode === "claim") {
    p.cooldownUntil =
      cfg.cooldown.murid_setelah_gagal_detik > 0 ? now + cfg.cooldown.murid_setelah_gagal_detik * 1000 : 0;
    card.lockedBy = null;
    // detik 0 = tanpa pembekuan: kartu langsung terbuka lagi dengan varian soal berikutnya
    if (cfg.cooldown.kartu_setelah_gagal_detik > 0) {
      card.status = "COOLDOWN";
      card.cooldownUntil = now + cfg.cooldown.kartu_setelah_gagal_detik * 1000;
    } else {
      card.status = "OPEN";
      card.cooldownUntil = 0;
    }
    card.attempts++;
    const before = card.jackpotPct;
    card.jackpotPct = Math.min(cfg.jackpot.maks_persen, card.jackpotPct + cfg.jackpot.naik_per_gagal_persen);
    ev.push({ type: "claim_failed", playerId: p.id, cell: card.cell, data: { reason } });
    if (card.jackpotPct !== before) ev.push({ type: "jackpot", cell: card.cell, data: { pct: card.jackpotPct } });
  } else {
    p.cooldownUntil =
      cfg.cooldown.murid_setelah_gagal_rebut_detik > 0 ? now + cfg.cooldown.murid_setelah_gagal_rebut_detik * 1000 : 0;
    card.status = "CLAIMED";
    card.challenger = null;
    card.shieldUntil = now + cfg.rebut.perisai_setelah_bertahan_menit * MIN;
    ev.push({ type: "steal_failed", playerId: p.id, cell: card.cell, data: { reason, owner: card.owner } });
    const owner = card.owner ? s.players[card.owner] : undefined;
    if (owner) {
      owner.defends++;
      addBonus(owner, 10, "benteng_kokoh", ev, card.cell);
      checkBadges(s, owner, ev);
    }
  }
  checkBadges(s, p, ev);
  pauseAfterAnswer(s, p, now, ev);
}

function startDelivery(
  s: GameState,
  p: Player,
  card: Card,
  mode: "claim" | "steal",
  deliveryId: string,
  now: number,
  ev: Ev,
) {
  let variant: 1 | 2;
  if (mode === "claim") variant = card.order[card.served % 2]!;
  else variant = card.claimedVariant === 1 ? 2 : 1;
  card.served++;
  const totalMs = effectiveTimeMs(s, card.row, mode);
  p.active = {
    cell: card.cell,
    deliveryId,
    mode,
    variant,
    reused: card.served > 2,
    startedAt: now,
    deadline: now + totalMs,
    totalMs,
    focusLost: 0,
    used5050: false,
  };
  p.levelSum += card.row;
  if (!p.colsTried.includes(card.col)) p.colsTried.push(card.col);
  if (mode === "claim") {
    card.status = "LOCKED";
    card.lockedBy = p.id;
  } else {
    card.status = "CONTESTED";
    card.challenger = p.id;
  }
  ev.push({
    type: mode === "claim" ? "locked" : "steal_started",
    playerId: p.id,
    cell: card.cell,
    data: { deliveryId, variant, totalMs, deadline: p.active.deadline, reused: p.active.reused, owner: card.owner },
  });
}

function shiftTimes(s: GameState, delta: number) {
  s.startedAt += delta;
  for (const p of Object.values(s.players)) {
    if (p.cooldownUntil) p.cooldownUntil += delta;
    if (p.frozenUntil) p.frozenUntil += delta;
    if (p.active) {
      p.active.deadline += delta;
      p.active.startedAt += delta;
    }
  }
  for (const c of Object.values(s.cards)) {
    if (c.cooldownUntil) c.cooldownUntil += delta;
    if (c.shieldUntil) c.shieldUntil += delta;
    if (c.immuneUntil) c.immuneUntil += delta;
  }
}

export function reduce(prev: GameState, a: Action, now: number): ReduceResult {
  const s = structuredClone(prev);
  const ev: Ev = [];

  switch (a.type) {
    case "join": {
      const existing = s.players[a.playerId];
      if (existing) {
        existing.name = a.name;
        existing.initials = a.initials;
        existing.color = a.color;
      } else {
        s.players[a.playerId] = newPlayer(
          s,
          { id: a.playerId, name: a.name, initials: a.initials, color: a.color },
          now,
        );
      }
      ev.push({ type: "joined", playerId: a.playerId });
      return { state: s, events: ev };
    }

    case "start": {
      if (s.phase !== "LOBBY") return rejectSimple(prev, {}, "bad_phase", "Permainan sudah dimulai.");
      s.startedAt = now;
      s.phase = "OPEN";
      ev.push({ type: "started" }, { type: "phase", data: { phase: "OPEN" } });
      return { state: s, events: ev };
    }

    case "claim": {
      const c = canClaim(prev, a.playerId, a.cell, now);
      if (!c.ok) return reject(prev, a, c);
      startDelivery(s, s.players[a.playerId]!, s.cards[a.cell]!, "claim", a.deliveryId, now, ev);
      return { state: s, events: ev };
    }

    case "steal": {
      const c = canSteal(prev, a.playerId, a.cell, now);
      if (!c.ok) return reject(prev, a, c);
      const p = s.players[a.playerId]!;
      p.tickets--;
      startDelivery(s, p, s.cards[a.cell]!, "steal", a.deliveryId, now, ev);
      return { state: s, events: ev };
    }

    case "answer": {
      const p = s.players[a.playerId];
      if (s.pausedAt !== null) return rejectSimple(prev, a, "paused", "Permainan sedang dijeda.");
      if (!p?.active || p.active.deliveryId !== a.deliveryId) {
        return rejectSimple(prev, a, "bad_delivery", "Soal ini sudah tidak aktif.");
      }
      const card = s.cards[p.active.cell]!;
      const mode = p.active.mode;
      if (now > p.active.deadline) {
        awardFail(s, p, "timeout", now, ev);
      } else if (a.correct) {
        awardCorrect(s, p, card, mode, now, ev);
      } else {
        awardFail(s, p, "salah", now, ev);
      }
      return { state: s, events: ev };
    }

    case "focus_lost": {
      const p = s.players[a.playerId];
      if (!p?.active || p.active.deliveryId !== a.deliveryId || s.pausedAt !== null) {
        return rejectSimple(prev, a, "bad_delivery", "Soal ini sudah tidak aktif.");
      }
      p.active.focusLost++;
      if (p.active.focusLost > s.rules.config.anti_curang.fokus_hilang_peringatan_maks) {
        awardFail(s, p, "fokus", now, ev);
      } else {
        ev.push({ type: "focus_warning", playerId: p.id, cell: p.active.cell, data: { count: p.active.focusLost } });
      }
      return { state: s, events: ev };
    }

    case "powerup": {
      const p = s.players[a.playerId];
      if (!p) return rejectSimple(prev, a, "unknown_player", "Kamu belum terdaftar.");
      if (s.phase === "LOBBY" || s.phase === "END" || s.pausedAt !== null) {
        return rejectSimple(prev, a, "bad_powerup", "Power-up tidak bisa dipakai sekarang.");
      }
      const idx = p.powerUps.indexOf(a.powerUp);
      if (idx < 0) return rejectSimple(prev, a, "no_powerup", "Kamu tidak punya power-up itu.");
      const bad = () => rejectSimple(prev, a, "bad_powerup", "Power-up tidak bisa dipakai sekarang.");
      const pu: PowerUp = a.powerUp;
      let cell: string | undefined;
      if (pu === "plus15") {
        if (!p.active) return bad();
        p.active.deadline += 15_000;
        p.active.totalMs += 15_000;
        cell = p.active.cell;
      } else if (pu === "50_50") {
        if (!p.active || p.active.used5050) return bad();
        p.active.used5050 = true;
        cell = p.active.cell;
      } else if (pu === "perisai") {
        const card = a.cell ? s.cards[a.cell] : undefined;
        if (!card || card.owner !== p.id || card.status !== "CLAIMED") return bad();
        card.shieldUntil = Math.max(card.shieldUntil, now + 5 * MIN);
        cell = card.cell;
      } else if (pu === "streak_saver") {
        if (p.saver) return bad();
        p.saver = true;
      } else if (pu === "kunci_emas") {
        if (p.goldenKey) return bad();
        p.goldenKey = true;
      } else {
        const card = a.cell ? s.cards[a.cell] : undefined;
        if (!card || card.col !== "H" || card.status !== "OPEN") return bad();
        cell = card.cell;
      }
      p.powerUps.splice(idx, 1);
      ev.push({ type: "powerup_used", playerId: p.id, ...(cell ? { cell } : {}), data: { powerUp: pu } });
      return { state: s, events: ev };
    }

    case "tick": {
      if (s.pausedAt !== null || s.phase === "LOBBY" || s.phase === "END") return { state: prev, events: [] };
      for (const p of Object.values(s.players)) {
        if (p.active && now > p.active.deadline) awardFail(s, p, "timeout", now, ev);
      }
      for (const c of Object.values(s.cards)) {
        if (c.status === "COOLDOWN" && now >= c.cooldownUntil) {
          c.status = "OPEN";
          ev.push({ type: "cooldown_end", cell: c.cell });
        }
      }
      const minutes = (now - s.startedAt) / MIN;
      let marked = false;
      if (!s.rankMark && minutes >= s.rules.config.durasi_menit - 15) {
        s.rankMark = Object.fromEntries(leaderboard(s).map((r, i) => [r.playerId, i + 1]));
        marked = true;
      }
      const fase = s.rules.config.fase;
      const curIdx = fase.findIndex((f) => f.id === s.phase);
      let target = curIdx;
      fase.forEach((f, i) => {
        if (f.mulai_menit <= minutes && i > target) target = i;
      });
      if (target > curIdx) setPhase(s, fase[target]!.id, now, ev);
      return ev.length || marked ? { state: s, events: ev } : { state: prev, events: [] };
    }

    case "host_phase": {
      if (s.phase === "LOBBY") return rejectSimple(prev, {}, "not_started", "Mulai permainan dulu.");
      if (s.phase === "END") return rejectSimple(prev, {}, "ended", "Permainan sudah selesai.");
      const f = s.rules.config.fase.find((x) => x.id === a.phase);
      if (!f) return rejectSimple(prev, {}, "bad_phase", "Fase tidak dikenal.");
      s.startedAt = (s.pausedAt ?? now) - f.mulai_menit * MIN;
      setPhase(s, a.phase, now, ev);
      return { state: s, events: ev };
    }

    case "host_pause": {
      if (s.phase === "LOBBY" || s.phase === "END" || s.pausedAt !== null)
        return rejectSimple(prev, {}, "bad_phase", "Tidak bisa dijeda.");
      s.pausedAt = now;
      ev.push({ type: "paused" });
      return { state: s, events: ev };
    }

    case "host_resume": {
      if (s.pausedAt === null) return rejectSimple(prev, {}, "bad_phase", "Permainan tidak sedang dijeda.");
      shiftTimes(s, now - s.pausedAt);
      s.pausedAt = null;
      ev.push({ type: "resumed" });
      return { state: s, events: ev };
    }

    case "host_freeze": {
      const p = s.players[a.playerId];
      if (!p) return rejectSimple(prev, a, "unknown_player", "Murid tidak ditemukan.");
      p.frozen = a.frozen && a.untilMs === undefined;
      p.frozenUntil = a.frozen && a.untilMs !== undefined ? now + a.untilMs : 0;
      ev.push({ type: "frozen", playerId: p.id, data: { frozen: a.frozen } });
      return { state: s, events: ev };
    }

    case "host_void": {
      const card = s.cards[a.cell];
      if (!card) return rejectSimple(prev, a, "unknown_cell", "Kartu tidak ada.");
      for (const p of Object.values(s.players)) if (p.active?.cell === card.cell) p.active = null;
      card.prevOwner = card.owner ?? card.prevOwner;
      card.owner = null;
      card.status = "OPEN";
      card.lockedBy = null;
      card.challenger = null;
      card.cooldownUntil = 0;
      card.shieldUntil = 0;
      card.immuneUntil = 0;
      card.claimedVariant = null;
      ev.push({ type: "voided", cell: card.cell });
      return { state: s, events: ev };
    }

    case "host_restore": {
      const card = s.cards[a.cell];
      if (!card || !card.prevOwner || !s.players[card.prevOwner]) {
        return rejectSimple(prev, a, "unknown_cell", "Tidak ada pemilik sebelumnya.");
      }
      if (card.status === "OPEN") {
        card.owner = card.prevOwner;
        card.status = "CLAIMED";
      } else if (card.status === "CLAIMED") {
        const cur = card.owner;
        card.owner = card.prevOwner;
        card.prevOwner = cur;
      } else {
        return rejectSimple(prev, a, "card_not_open", "Kartu sedang dikerjakan.");
      }
      ev.push({ type: "restored", cell: card.cell, ...(card.owner ? { playerId: card.owner } : {}) });
      return { state: s, events: ev };
    }

    case "host_adjust": {
      const p = s.players[a.playerId];
      if (!p) return rejectSimple(prev, a, "unknown_player", "Murid tidak ditemukan.");
      if (!a.reason.trim()) return rejectSimple(prev, a, "reason_required", "Alasan wajib diisi.");
      p.bonus += a.delta;
      ev.push({ type: "adjusted", playerId: p.id, data: { delta: a.delta, reason: a.reason.trim() } });
      return { state: s, events: ev };
    }

    case "host_badge": {
      const p = s.players[a.playerId];
      if (!p) return rejectSimple(prev, a, "unknown_player", "Murid tidak ditemukan.");
      // hanya badge yang memang diberikan guru
      if (a.badgeId !== "jujur_itu_keren" || !s.rules.badges?.some((b) => b.id === a.badgeId)) {
        return rejectSimple(prev, a, "bad_badge", "Badge ini tidak bisa diberikan manual.");
      }
      if (p.badges.includes(a.badgeId)) return rejectSimple(prev, a, "bad_badge", "Murid sudah punya badge ini.");
      grantBadge(s, p, a.badgeId, ev);
      return { state: s, events: ev };
    }

    case "host_ticket": {
      const p = s.players[a.playerId];
      if (!p) return rejectSimple(prev, a, "unknown_player", "Murid tidak ditemukan.");
      if (!a.reason.trim()) return rejectSimple(prev, a, "reason_required", "Alasan wajib diisi.");
      p.tickets = Math.max(0, p.tickets + a.delta);
      ev.push({ type: "tickets_changed", playerId: p.id, data: { delta: a.delta, reason: a.reason.trim() } });
      return { state: s, events: ev };
    }
  }
}

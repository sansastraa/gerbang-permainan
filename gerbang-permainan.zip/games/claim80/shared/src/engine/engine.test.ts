import { describe, expect, it } from "vitest";
import { defaultConfig, legacyConfig, noPauseConfig } from "./testConfig";
import { canClaim, createGame, leaderboard, reduce, scoreOf, wilayahTerbesar } from "./index";
import type { Action, GameEvent, GameState } from "./index";

const config = legacyConfig;
const waktuPerLevel = { 1: 30, 2: 30, 3: 45, 4: 60, 5: 60, 6: 90, 7: 120, 8: 180 };
const MIN = 60_000;

/** Harness kecil: jam terkendali + log peristiwa. */
function harness(seed = 1, players = ["a", "b", "c"]) {
  let now = 1_000_000;
  let state = createGame({ config, waktuPerLevel }, seed);
  const log: GameEvent[] = [];
  const act = (a: Action) => {
    const r = reduce(state, a, now);
    state = r.state;
    log.push(...r.events);
    return r.events;
  };
  players.forEach((id, i) =>
    act({ type: "join", playerId: id, name: id.toUpperCase(), initials: id.toUpperCase(), color: `c${i}` }),
  );
  act({ type: "start" });
  let d = 0;
  return {
    get state(): GameState {
      return state;
    },
    log,
    act,
    advance(ms: number) {
      now += ms;
      act({ type: "tick" });
    },
    get now() {
      return now;
    },
    claim(playerId: string, cell: string) {
      return act({ type: "claim", playerId, cell, deliveryId: `d${++d}` });
    },
    answer(playerId: string, correct: boolean) {
      const id = state.players[playerId]!.active!.deliveryId;
      return act({ type: "answer", playerId, deliveryId: id, correct });
    },
    win(playerId: string, cell: string) {
      this.claim(playerId, cell);
      return this.answer(playerId, true);
    },
  };
}
const types = (ev: GameEvent[]) => ev.map((e) => e.type);

describe("kartu: klaim", () => {
  it("klaim mengunci kartu lalu jawaban benar memilikinya dengan nilai terkunci", () => {
    const h = harness();
    expect(types(h.claim("a", "E2"))).toEqual(["locked"]);
    expect(h.state.cards.E2!.status).toBe("LOCKED");
    h.advance(10_000); // 10 dtk dari batas 18 dtk → tidak cepat
    h.answer("a", true);
    const c = h.state.cards.E2!;
    expect(c.status).toBe("CLAIMED");
    expect(c.owner).toBe("a");
    // 15 poin × streak 1 (×1) = 15
    expect(c.value).toBe(15);
    expect(scoreOf(h.state, "a")).toBe(15);
  });

  it("jawaban cepat mendapat bonus kecepatan 20%", () => {
    const h = harness();
    h.claim("a", "E2");
    h.advance(2000);
    h.answer("a", true);
    expect(h.state.cards.E2!.value).toBe(18);
  });

  it("race: dua klaim bersamaan pada kartu yang sama → tepat satu yang LOCKED", () => {
    const h = harness();
    const e1 = h.claim("a", "J5");
    const e2 = h.claim("b", "J5");
    expect(types(e1)).toEqual(["locked"]);
    expect(types(e2)).toEqual(["rejected"]);
    expect(h.state.cards.J5!.lockedBy).toBe("a");
    expect(h.state.players.b!.active).toBeNull();
  });

  it("J8 bisa diklaim di detik pertama (tanpa kunci baris)", () => {
    const h = harness();
    expect(types(h.claim("a", "J8"))).toEqual(["locked"]);
  });

  it("paket soal diacak: urutan varian per kartu tergantung seed, dan tetap A1-1/A1-2", () => {
    const orders = (seed: number) =>
      Object.values(createGame({ config, waktuPerLevel }, seed).cards).map((c) => c.order.join(""));
    const o1 = orders(1);
    const o2 = orders(2);
    expect(o1).not.toEqual(o2);
    expect(new Set(o1)).toEqual(new Set(["12", "21"]));
    expect(orders(1)).toEqual(o1);
  });

  it("varian yang tampil pada percobaan pertama dan kedua selalu berbeda", () => {
    const h = harness(7);
    h.claim("a", "C3");
    const v1 = h.state.players.a!.active!.variant;
    h.answer("a", false);
    h.advance(20_000); // kartu & murid dingin
    h.claim("b", "C3");
    expect(h.state.players.b!.active!.variant).not.toBe(v1);
  });
});

describe("kartu: gagal, cooldown, jackpot", () => {
  it("salah → kartu COOLDOWN 20 dtk, murid cooldown 15 dtk, jackpot +10%, lalu OPEN lagi", () => {
    const h = harness();
    h.claim("a", "D4");
    const ev = h.answer("a", false);
    expect(types(ev)).toContain("claim_failed");
    const c = h.state.cards.D4!;
    expect(c.status).toBe("COOLDOWN");
    expect(c.jackpotPct).toBe(10);
    expect(types(h.claim("b", "D4"))).toEqual(["rejected"]); // masih retak
    h.advance(20_000);
    expect(h.state.cards.D4!.status).toBe("OPEN");
    // murid a masih cooldown 15 dtk sudah lewat (20 dtk) → boleh lagi
    expect(canClaim(h.state, "a", "D4", h.now).ok).toBe(true);
  });

  it("jackpot maksimal 50% dan nilai kartu ikut naik", () => {
    const h = harness();
    for (let i = 0; i < 6; i++) {
      h.claim("a", "A4");
      h.answer("a", false);
      h.advance(21_000);
    }
    expect(h.state.cards.A4!.jackpotPct).toBe(50);
    h.claim("b", "A4");
    h.advance(20_000); // 20 dtk dari 36 dtk (tidak cepat)
    h.answer("b", true);
    expect(h.state.cards.A4!.value).toBe(Math.round(35 * 1.5));
  });

  it("murid yang baru gagal ada di cooldown pribadi", () => {
    const h = harness();
    h.claim("a", "A1");
    h.answer("a", false);
    const ev = h.claim("a", "A2");
    expect(ev[0]!.data!.reason).toBe("player_cooldown");
  });

  it("timeout di tick menggagalkan klaim; jawaban setelah deadline ditolak walau benar", () => {
    const h = harness();
    h.claim("a", "B2");
    const id = h.state.players.a!.active!.deliveryId;
    h.advance(100_000);
    expect(h.state.cards.B2!.status).toBe("COOLDOWN");
    const ev = h.act({ type: "answer", playerId: "a", deliveryId: id, correct: true });
    expect(types(ev)).toEqual(["rejected"]);
    expect(h.state.cards.B2!.owner).toBeNull();

    // jawaban terlambat tanpa tick di antaranya juga gagal
    h.claim("b", "B3");
    const id2 = h.state.players.b!.active!.deliveryId;
    h.advance(0);
    const h2 = harness();
    h2.claim("a", "B3");
    const id3 = h2.state.players.a!.active!.deliveryId;
    // maju waktu tanpa tick: paksa lewat reduce langsung
    const r = reduce(h2.state, { type: "answer", playerId: "a", deliveryId: id3, correct: true }, h2.now + 200_000);
    expect(types(r.events)).toContain("claim_failed");
    expect(r.state.cards.B3!.owner).toBeNull();
    expect(id2).toBeTruthy();
  });

  it("satu pengiriman, satu jawaban: jawaban ulang ditolak", () => {
    const h = harness();
    h.claim("a", "A1");
    const id = h.state.players.a!.active!.deliveryId;
    h.answer("a", true);
    expect(types(h.act({ type: "answer", playerId: "a", deliveryId: id, correct: true }))).toEqual(["rejected"]);
  });

  it("maksimal 1 kartu aktif", () => {
    const h = harness();
    h.claim("a", "A1");
    expect(h.claim("a", "A2")[0]!.data!.reason).toBe("has_active");
  });
});

describe("kelayakan", () => {
  it("Zona Pemula: baris 1–2 hanya untuk pemilik ≤ 1 kartu sampai menit 10", () => {
    const h = harness();
    h.win("a", "A3");
    h.win("a", "A4"); // punya 2 kartu
    expect(h.claim("a", "A1")[0]!.data!.reason).toBe("zona_pemula");
    expect(types(h.claim("b", "A1"))).toEqual(["locked"]);
    h.answer("b", true);
    // setelah menit 10 zona berakhir
    h.advance(10 * MIN);
    expect(types(h.claim("a", "A2"))).toEqual(["locked"]);
  });

  it("Pajak Juara: ≥5 kartu → baris ≥ 4; ≥8 kartu → baris ≥ 6", () => {
    const h = harness();
    h.advance(11 * MIN);
    const cells = ["A3", "B3", "C3", "D3", "E3"];
    cells.forEach((c) => h.win("a", c));
    expect(h.claim("a", "F3")[0]!.data!.reason).toBe("pajak_juara");
    expect(types(h.claim("a", "F4"))).toEqual(["locked"]);
    h.answer("a", true);
    ["G4", "H4"].forEach((c) => h.win("a", c));
    h.win("a", "A6"); // kartu ke-8
    expect(h.state.cards.A6!.owner).toBe("a");
    expect(h.claim("a", "B5")[0]!.data!.reason).toBe("pajak_juara");
    expect(types(h.claim("a", "B6"))).toEqual(["locked"]);
  });

  it("dibekukan guru tidak bisa membuka kartu", () => {
    const h = harness();
    h.act({ type: "host_freeze", playerId: "a", frozen: true });
    expect(h.claim("a", "A3")[0]!.data!.reason).toBe("frozen");
    h.act({ type: "host_freeze", playerId: "a", frozen: false });
    expect(types(h.claim("a", "A3"))).toEqual(["locked"]);
  });

  it("tidak bisa klaim sebelum mulai / setelah selesai", () => {
    let st = createGame({ config, waktuPerLevel }, 3);
    st = reduce(st, { type: "join", playerId: "a", name: "A", initials: "A", color: "x" }, 0).state;
    expect(reduce(st, { type: "claim", playerId: "a", cell: "A1", deliveryId: "1" }, 0).events[0]!.data!.reason).toBe(
      "not_started",
    );
  });
});

describe("streak & power-up", () => {
  it("streak menaikkan pengali (×1,1 pada 2, ×1,25 pada 3) dan hadiah power-up di 3", () => {
    const h = harness();
    h.advance(11 * MIN);
    h.win("a", "A3"); // streak 1: 25
    h.advance(1000);
    h.advance(20_000);
    h.claim("a", "B3");
    h.advance(15_000);
    h.answer("a", true); // streak 2 → ×1,1
    expect(h.state.cards.B3!.value).toBe(Math.round(25 * 1.1));
    h.claim("a", "C3");
    h.advance(15_000);
    const ev = h.answer("a", true); // streak 3 → ×1,25
    expect(h.state.cards.C3!.value).toBe(Math.round(25 * 1.25));
    expect(types(ev)).toContain("streak");
    expect(h.state.players.a!.powerUps.length).toBeGreaterThanOrEqual(1);
  });

  it("gagal memutus streak, Streak Saver menahannya satu kali", () => {
    const h = harness();
    h.win("a", "A3");
    h.state.players.a!.powerUps.push("streak_saver");
    h.act({ type: "powerup", playerId: "a", powerUp: "streak_saver" });
    h.claim("a", "B3");
    h.answer("a", false);
    expect(h.state.players.a!.streak).toBe(1);
    h.advance(20_000);
    h.claim("a", "B3");
    h.answer("a", false);
    expect(h.state.players.a!.streak).toBe(0);
  });

  it("+15 Detik menambah deadline; power-up yang tidak dimiliki ditolak", () => {
    const h = harness();
    h.claim("a", "A3");
    const before = h.state.players.a!.active!.deadline;
    expect(types(h.act({ type: "powerup", playerId: "a", powerUp: "plus15" }))).toEqual(["rejected"]);
    h.state.players.a!.powerUps.push("plus15");
    h.act({ type: "powerup", playerId: "a", powerUp: "plus15" });
    expect(h.state.players.a!.active!.deadline).toBe(before + 15_000);
    expect(h.state.players.a!.powerUps).toHaveLength(0);
  });

  it("Kunci Emas menggandakan kartu berikutnya", () => {
    const h = harness();
    h.state.players.a!.powerUps.push("kunci_emas");
    h.act({ type: "powerup", playerId: "a", powerUp: "kunci_emas" });
    h.claim("a", "E3");
    h.advance(20_000);
    h.answer("a", true);
    expect(h.state.cards.E3!.value).toBe(50);
    expect(h.state.players.a!.goldenKey).toBe(false);
  });

  it("maksimal 3 power-up tersimpan", () => {
    const h = harness();
    const p = h.state.players.a!;
    p.powerUps.push("50_50", "plus15", "perisai");
    h.state.cards.A3!.gift = true;
    h.win("a", "A3");
    expect(h.state.players.a!.powerUps).toHaveLength(3);
  });
});

describe("kartu spesial & bonus", () => {
  it("Golden ×2 dan Gift memberi power-up", () => {
    const h = harness(5);
    const golden = Object.values(h.state.cards).find((c) => c.golden)!;
    const gift = Object.values(h.state.cards).find((c) => c.gift)!;
    expect(Object.values(h.state.cards).filter((c) => c.golden)).toHaveLength(4);
    expect(Object.values(h.state.cards).filter((c) => c.gift)).toHaveLength(4);
    h.claim("a", golden.cell);
    h.advance(100_000);
    // deadline lewat → gagal; ulangi dengan b agar valid
    h.advance(20_000);
    h.claim("b", golden.cell);
    h.advance(30);
    const ev = h.answer("b", true);
    expect(types(ev)).toContain("golden");
    h.advance(20_000);
    const before = h.state.players.c!.powerUps.length;
    h.claim("c", gift.cell);
    const ev2 = h.answer("c", true);
    expect(types(ev2)).toContain("gift");
    expect(h.state.players.c!.powerUps.length).toBe(before + 1);
  });

  it("Terjun Bebas +25 untuk klaim pertama di level ≥ 6, Penakluk Puncak +30 sekali per kolom", () => {
    const h = harness();
    const ev = h.win("a", "F6");
    expect(ev.some((e) => e.type === "bonus" && e.data!.why === "terjun_bebas")).toBe(true);
    expect(h.state.players.a!.bonus).toBe(25);
    const ev2 = h.win("a", "G8");
    expect(ev2.some((e) => e.data?.why === "penakluk_puncak")).toBe(true);
    expect(h.state.players.a!.bonus).toBe(55);
    // terjun bebas hanya klaim pertama; puncak kolom G sudah diambil
    h.advance(21_000);
    const ev3 = h.win("b", "G7");
    expect(ev3.some((e) => e.data?.why === "terjun_bebas")).toBe(true);
    h.advance(21_000);
    h.state.cards.G8!.status = "OPEN";
    h.state.cards.G8!.owner = null;
    const ev4 = h.win("b", "G8");
    expect(ev4.some((e) => e.data?.why === "penakluk_puncak")).toBe(false);
  });

  it("Ahli Kolom +30 pada kartu ke-3 satu kolom, Pelangi +50 pada 6 kolom", () => {
    const h = harness();
    h.advance(11 * MIN);
    h.win("a", "A4");
    h.win("a", "A5");
    const ev = h.win("a", "A6");
    expect(ev.some((e) => e.data?.why === "ahli_A")).toBe(true);
    h.win("a", "B4");
    h.win("a", "C4");
    const ev2 = h.win("a", "D4");
    expect(ev2.some((e) => e.data?.why === "pelangi")).toBe(false);
    h.advance(20_000);
    h.win("a", "E4"); // E dan seterusnya: karena pajak juara (6 kartu ≥ 5 → baris ≥ 4), tetap baris 4
    const ev3 = h.win("a", "F4");
    expect(ev3.some((e) => e.data?.why === "pelangi")).toBe(true);
  });

  it("wilayah terhubung dihitung dan dibayar sekali di akhir (+5/kartu)", () => {
    const h = harness();
    h.advance(11 * MIN);
    h.win("a", "A4");
    h.win("a", "A5");
    h.win("a", "B5");
    expect(wilayahTerbesar(h.state, "a")).toBe(3);
    const bonusBefore = h.state.players.a!.bonus;
    h.act({ type: "host_phase", phase: "END" });
    expect(h.state.players.a!.bonus).toBe(bonusBefore + 15);
    expect(h.state.phase).toBe("END");
  });
});

describe("rebut", () => {
  function setup() {
    const h = harness(2);
    h.advance(16 * MIN); // BATTLE
    h.win("a", "A5");
    h.advance(1000);
    return h;
  }

  it("ditolak di fase OPEN", () => {
    const h = harness();
    h.win("a", "A5");
    expect(h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s" })[0]!.data!.reason).toBe(
      "rebut_nonaktif",
    );
  });

  it("rebut berhasil memindahkan kartu, memberi imun 3 menit, memakai varian lain dan waktu ×0,75", () => {
    const h = setup();
    const variantA = h.state.cards.A5!.claimedVariant;
    const valueOwner = h.state.cards.A5!.value;
    const ev = h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s1" });
    expect(types(ev)).toEqual(["steal_started"]);
    const act = h.state.players.b!.active!;
    expect(act.variant).not.toBe(variantA);
    expect(act.totalMs).toBe(Math.round(Math.max(15, Math.round(60 * 0.6)) * 1000 * 0.75));
    expect(h.state.cards.A5!.status).toBe("CONTESTED");
    expect(h.state.players.b!.tickets).toBe(1);
    h.answer("b", true);
    const c = h.state.cards.A5!;
    expect(c.owner).toBe("b");
    expect(c.status).toBe("CLAIMED");
    expect(c.immuneUntil).toBeGreaterThan(h.now);
    expect(scoreOf(h.state, "a")).toBe(0);
    expect(valueOwner).toBeGreaterThan(0);
    // kartu imun tidak bisa direbut lagi
    expect(h.act({ type: "steal", playerId: "c", cell: "A5", deliveryId: "s2" })[0]!.data!.reason).toBe("protected");
  });

  it("rebut gagal: kartu tetap, perisai 3 menit, pemilik +10, penantang cooldown 30 dtk, tiket hangus", () => {
    const h = setup();
    h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s1" });
    h.answer("b", false);
    const c = h.state.cards.A5!;
    expect(c.owner).toBe("a");
    expect(c.status).toBe("CLAIMED");
    expect(c.shieldUntil).toBeGreaterThan(h.now);
    expect(h.state.players.a!.bonus).toBe(10);
    expect(h.state.players.b!.cooldownUntil).toBe(h.now + 30_000);
    expect(h.state.players.b!.tickets).toBe(1);
    expect(h.act({ type: "steal", playerId: "c", cell: "A5", deliveryId: "s2" })[0]!.data!.reason).toBe("protected");
  });

  it("tidak bisa merebut kartu sendiri, kartu OPEN, atau tanpa tiket", () => {
    const h = setup();
    expect(h.act({ type: "steal", playerId: "a", cell: "A5", deliveryId: "x" })[0]!.data!.reason).toBe("own_card");
    expect(h.act({ type: "steal", playerId: "b", cell: "B5", deliveryId: "x" })[0]!.data!.reason).toBe("not_claimed");
    h.state.players.b!.tickets = 0;
    expect(h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "x" })[0]!.data!.reason).toBe("no_ticket");
  });

  it("dua rebut bersamaan pada kartu sama: hanya satu", () => {
    const h = setup();
    expect(types(h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s1" }))).toEqual(["steal_started"]);
    expect(types(h.act({ type: "steal", playerId: "c", cell: "A5", deliveryId: "s2" }))).toEqual(["rejected"]);
  });

  it("Perisai power-up melindungi kartu sendiri 5 menit", () => {
    const h = setup();
    h.state.players.a!.powerUps.push("perisai");
    h.act({ type: "powerup", playerId: "a", powerUp: "perisai", cell: "A5" });
    expect(h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s" })[0]!.data!.reason).toBe("protected");
    h.advance(5 * MIN + 1000);
    expect(types(h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s3" }))).toEqual(["steal_started"]);
  });
});

describe("fokus & kendali guru & fase", () => {
  it("fokus hilang 1× = peringatan, 2× = gagal otomatis", () => {
    const h = harness();
    h.claim("a", "A3");
    const id = h.state.players.a!.active!.deliveryId;
    expect(types(h.act({ type: "focus_lost", playerId: "a", deliveryId: id }))).toEqual(["focus_warning"]);
    const ev = h.act({ type: "focus_lost", playerId: "a", deliveryId: id });
    expect(types(ev)).toContain("claim_failed");
    expect(ev[0]!.data!.reason).toBe("fokus");
    expect(h.state.cards.A3!.status).toBe("COOLDOWN");
  });

  it("fase berjalan otomatis OPEN → BATTLE → RUSH (×1,5) → END", () => {
    const h = harness();
    h.advance(14 * MIN);
    expect(h.state.phase).toBe("OPEN");
    h.advance(1 * MIN);
    expect(h.state.phase).toBe("BATTLE");
    h.advance(20 * MIN);
    expect(h.state.phase).toBe("RUSH");
    h.claim("a", "E3");
    h.advance(20_000);
    h.answer("a", true);
    expect(h.state.cards.E3!.value).toBe(Math.round(25 * 1.5));
    h.advance(5 * MIN);
    expect(h.state.phase).toBe("END");
    expect(h.claim("b", "A1")[0]!.data!.reason).toBe("ended");
  });

  it("jeda menghentikan jam & deadline; lanjut menggeser semuanya", () => {
    const h = harness();
    h.claim("a", "A3");
    const remaining = h.state.players.a!.active!.deadline - h.now;
    h.act({ type: "host_pause" });
    h.advance(10 * MIN);
    expect(h.state.phase).toBe("OPEN");
    expect(h.claim("b", "A4")[0]!.data!.reason).toBe("paused");
    h.act({ type: "host_resume" });
    expect(h.state.players.a!.active!.deadline - h.now).toBe(remaining);
  });

  it("void membuka kembali kartu, restore mengembalikannya; adjust butuh alasan", () => {
    const h = harness();
    h.win("a", "A3");
    h.act({ type: "host_void", cell: "A3" });
    expect(h.state.cards.A3!.status).toBe("OPEN");
    expect(scoreOf(h.state, "a")).toBe(0);
    h.act({ type: "host_restore", cell: "A3" });
    expect(h.state.cards.A3!.owner).toBe("a");
    expect(types(h.act({ type: "host_adjust", playerId: "a", delta: -30, reason: " " }))).toEqual(["rejected"]);
    h.act({ type: "host_adjust", playerId: "a", delta: -30, reason: "curang" });
    expect(h.state.players.a!.bonus).toBe(-30);
  });

  it("papan skor mengurutkan skor lalu level puncak", () => {
    const h = harness();
    h.win("a", "A3");
    h.win("b", "A4");
    expect(leaderboard(h.state)[0]!.playerId).toBe("b");
  });
});

describe("invarian", () => {
  it("80 kartu selalu terbagi di status valid & reduce tidak mengubah state lama (murni)", () => {
    const h = harness(11, ["a", "b", "c", "d", "e"]);
    const frozen = JSON.stringify(h.state);
    const cells = Object.keys(h.state.cards);
    let seed = 99;
    const r = () => (seed = (seed * 1664525 + 1013904223) >>> 0) / 4294967296;
    for (let step = 0; step < 600; step++) {
      const id = ["a", "b", "c", "d", "e"][Math.floor(r() * 5)]!;
      const p = h.state.players[id]!;
      if (p.active) h.answer(id, r() < 0.7);
      else if (r() < 0.2 && h.state.phase === "BATTLE")
        h.act({ type: "steal", playerId: id, cell: cells[Math.floor(r() * 80)]!, deliveryId: `s${step}` });
      else h.claim(id, cells[Math.floor(r() * 80)]!);
      if (step % 5 === 0) h.advance(8_000);
      const all = Object.values(h.state.cards);
      expect(all).toHaveLength(80);
      expect(all.every((c) => ["OPEN", "LOCKED", "CLAIMED", "COOLDOWN", "CONTESTED"].includes(c.status))).toBe(true);
      for (const c of all) if (c.status === "CLAIMED") expect(c.owner).not.toBeNull();
    }
    expect(frozen).toBe(JSON.stringify(harness(11, ["a", "b", "c", "d", "e"]).state));
  }, 60_000);

  it("reduce deterministik: aksi yang sama menghasilkan state yang sama", () => {
    const run = () => {
      const h = harness(4);
      h.win("a", "A3");
      h.win("b", "C5");
      return JSON.stringify(h.state);
    };
    expect(run()).toBe(run());
  });
});

describe("sanksi guru", () => {
  it("host_ticket mengurangi tiket (tidak di bawah 0) dan butuh alasan; lastClaim tercatat", () => {
    const h = harness();
    h.win("a", "E3");
    expect(h.state.players.a!.lastClaim).toBe("E3");
    expect(types(h.act({ type: "host_ticket", playerId: "a", delta: -1, reason: " " }))).toEqual(["rejected"]);
    h.act({ type: "host_ticket", playerId: "a", delta: -1, reason: "uji" });
    expect(h.state.players.a!.tickets).toBe(1);
    h.act({ type: "host_ticket", playerId: "a", delta: -5, reason: "uji" });
    expect(h.state.players.a!.tickets).toBe(0);
    expect(types(h.act({ type: "host_ticket", playerId: "zzz", delta: -1, reason: "uji" }))).toEqual(["rejected"]);
  });
});

describe("aturan guru: tanpa pembekuan, tanpa batas kartu", () => {
  function plain() {
    let now = 1_000_000;
    let state = createGame({ config: noPauseConfig, waktuPerLevel }, 3);
    const act = (a: Action) => {
      const r = reduce(state, a, now);
      state = r.state;
      return r.events;
    };
    for (const id of ["a", "b"]) act({ type: "join", playerId: id, name: id, initials: id, color: "x" });
    act({ type: "start" });
    let d = 0;
    return {
      act,
      get state() {
        return state;
      },
      claim: (id: string, cell: string) => act({ type: "claim", playerId: id, cell, deliveryId: `d${++d}` }),
      answer: (id: string, correct: boolean) =>
        act({ type: "answer", playerId: id, deliveryId: state.players[id]!.active!.deliveryId, correct }),
      adv(ms: number) {
        now += ms;
        act({ type: "tick" });
      },
    };
  }

  it("config bawaan: cooldown 0 dan tanpa Zona Pemula/Pajak Juara", () => {
    expect(defaultConfig.cooldown).toMatchObject({
      kartu_setelah_gagal_detik: 0,
      murid_setelah_gagal_detik: 0,
      murid_setelah_gagal_rebut_detik: 0,
    });
    expect(defaultConfig.pajak_juara).toEqual([]);
    expect(defaultConfig.zona_pemula.baris).toEqual([]);
  });

  it("salah jawab: kartu langsung OPEN dan murid langsung bisa mencoba lagi (varian lain)", () => {
    const h = plain();
    h.claim("a", "B4");
    const v1 = h.state.players.a!.active!.variant;
    const ev = h.answer("a", false);
    expect(ev.map((e) => e.type)).toContain("claim_failed");
    expect(h.state.cards.B4!.status).toBe("OPEN");
    expect(h.state.players.a!.cooldownUntil).toBe(0);
    expect(h.claim("a", "B4").map((e) => e.type)).toEqual(["locked"]);
    expect(h.state.players.a!.active!.variant).not.toBe(v1);
    // jackpot tetap naik pada kegagalan
    expect(h.state.cards.B4!.jackpotPct).toBe(10);
  });

  it("rebut gagal: murid tidak dibekukan, kartu tetap berperisai", () => {
    const h = plain();
    h.claim("a", "A5");
    h.answer("a", true);
    h.act({ type: "host_phase", phase: "BATTLE" });
    h.act({ type: "steal", playerId: "b", cell: "A5", deliveryId: "s1" });
    h.answer("b", false);
    expect(h.state.players.b!.cooldownUntil).toBe(0);
    expect(h.state.cards.A5!.shieldUntil).toBeGreaterThan(0);
    expect(h.claim("b", "C5").map((e) => e.type)).toEqual(["locked"]);
  });

  it("murid bebas mengambil kartu sebanyak apa pun di baris mana pun", () => {
    const h = plain();
    const cells = ["A1", "B1", "C1", "D1", "E1", "F1", "G1", "H2", "I2", "J2", "A3", "B3"];
    for (const c of cells) {
      expect(h.claim("a", c).map((e) => e.type)).toEqual(["locked"]);
      h.answer("a", true);
    }
    expect(Object.values(h.state.cards).filter((c) => c.owner === "a")).toHaveLength(12);
  });
});

describe("jeda tiap N soal (permintaan guru)", () => {
  function setup(jeda: { setiap: number; detik: number }) {
    let now = 1_000_000;
    let state = createGame({ config: { ...defaultConfig, jeda_soal: jeda }, waktuPerLevel }, 9);
    const act = (a: Action) => {
      const r = reduce(state, a, now);
      state = r.state;
      return r.events;
    };
    for (const id of ["a", "b"]) act({ type: "join", playerId: id, name: id, initials: id, color: "x" });
    act({ type: "start" });
    let d = 0;
    return {
      act,
      get state() {
        return state;
      },
      get now() {
        return now;
      },
      adv(ms: number) {
        now += ms;
        act({ type: "tick" });
      },
      claim: (id: string, cell: string) => act({ type: "claim", playerId: id, cell, deliveryId: `d${++d}` }),
      answer: (id: string, ok: boolean) =>
        act({ type: "answer", playerId: id, deliveryId: state.players[id]!.active!.deliveryId, correct: ok }),
    };
  }

  it("config bawaan: setiap 2 soal dibekukan 5 detik (benar maupun salah dihitung)", () => {
    expect(defaultConfig.jeda_soal).toMatchObject({ setiap: 2, detik: 5 });
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "A3");
    expect(h.answer("a", false).some((e) => e.type === "player_paused")).toBe(false); // soal ke-1
    expect(h.claim("a", "A3").map((e) => e.type)).toEqual(["locked"]); // belum dibekukan
    const ev = h.answer("a", true); // soal ke-2
    expect(ev.find((e) => e.type === "player_paused")?.data?.detik).toBe(5);
    expect(h.state.players.a!.cooldownUntil).toBe(h.now + 5000);
    expect(h.claim("a", "B3")[0]!.data!.reason).toBe("player_cooldown");
    h.adv(4900);
    expect(h.claim("a", "B3")[0]!.type).toBe("rejected");
    h.adv(200);
    expect(h.claim("a", "B3").map((e) => e.type)).toEqual(["locked"]);
  });

  it("hitungan berulang tiap 2 soal, per murid, dan tidak mengganggu murid lain", () => {
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "C2");
    h.answer("a", true);
    h.claim("a", "D2");
    h.answer("a", true); // jeda #1
    h.adv(5100);
    h.claim("a", "E2");
    h.answer("a", true);
    expect(h.state.players.a!.sincePause).toBe(1);
    expect(h.claim("b", "F2").map((e) => e.type)).toEqual(["locked"]); // b tidak ikut dibekukan
    h.answer("b", true);
    h.claim("a", "G2");
    const ev = h.answer("a", false); // soal ke-4 a → jeda #2
    expect(ev.some((e) => e.type === "player_paused")).toBe(true);
  });

  it("setiap 3 soal / detik 0 = nonaktif", () => {
    const h3 = setup({ setiap: 3, detik: 5 });
    for (const c of ["A2", "B2"]) {
      h3.claim("a", c);
      h3.answer("a", true);
    }
    expect(h3.state.players.a!.cooldownUntil).toBe(0);
    h3.claim("a", "C2");
    h3.answer("a", true);
    expect(h3.state.players.a!.cooldownUntil).toBeGreaterThan(0);

    const off = setup({ setiap: 2, detik: 0 });
    for (const c of ["A2", "B2", "C2", "D2"]) {
      off.claim("a", c);
      off.answer("a", true);
    }
    expect(off.state.players.a!.cooldownUntil).toBe(0);
  });

  it("waktu habis juga dihitung sebagai soal selesai", () => {
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "A1");
    h.adv(60_000); // timeout
    h.claim("a", "B1");
    h.adv(60_000);
    expect(h.state.players.a!.cooldownUntil).toBeGreaterThan(0);
  });
});

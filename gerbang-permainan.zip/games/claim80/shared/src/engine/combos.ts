import { COLS } from "../schemas";
import type { GameState } from "./types";

const owned = (s: GameState, id: string) =>
  Object.values(s.cards).filter((c) => c.owner === id && (c.status === "CLAIMED" || c.status === "CONTESTED"));

/** Kolom yang sudah dimiliki ≥ 3 kartu oleh pemain (Ahli Kolom). */
export function ahliKolom(s: GameState, id: string): string[] {
  const n: Record<string, number> = {};
  for (const c of owned(s, id)) n[c.col] = (n[c.col] ?? 0) + 1;
  return COLS.filter((c) => (n[c] ?? 0) >= 3);
}

/** Kategori berbeda dari kartu yang dimiliki (kolom B dan C dihitung sebagai kategori terpisah di grid; H atas nama kolomnya). */
export function kategoriDimiliki(s: GameState, id: string): number {
  return new Set(owned(s, id).map((c) => c.col)).size;
}

/** Ukuran kelompok kartu terhubung terbesar (atas/bawah/kiri/kanan) milik pemain. */
export function wilayahTerbesar(s: GameState, id: string): number {
  const mine = new Set(owned(s, id).map((c) => c.cell));
  const seen = new Set<string>();
  let best = 0;
  for (const start of mine) {
    if (seen.has(start)) continue;
    let size = 0;
    const stack = [start];
    seen.add(start);
    while (stack.length) {
      const cur = stack.pop()!;
      size++;
      const ci = COLS.indexOf(cur[0] as (typeof COLS)[number]);
      const row = Number(cur.slice(1));
      for (const [dc, dr] of [
        [1, 0],
        [-1, 0],
        [0, 1],
        [0, -1],
      ] as const) {
        const nc = COLS[ci + dc];
        const nr = row + dr;
        if (!nc || nr < 1 || nr > 8) continue;
        const key = `${nc}${nr}`;
        if (mine.has(key) && !seen.has(key)) {
          seen.add(key);
          stack.push(key);
        }
      }
    }
    best = Math.max(best, size);
  }
  return best;
}

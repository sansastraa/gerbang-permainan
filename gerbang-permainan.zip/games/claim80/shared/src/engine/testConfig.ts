import { readFileSync } from "node:fs";
import { configSchema } from "../schemas";
import type { GameConfig } from "../schemas";

const root = new URL("../../../", import.meta.url);

/** Konfigurasi bawaan sekarang (config/game.config.json): tanpa pembekuan dan tanpa batas kartu. */
export const defaultConfig: GameConfig = configSchema.parse(
  JSON.parse(readFileSync(new URL("config/game.config.json", root), "utf8")),
);

/**
 * Aturan SPEC awal (cooldown 20/15/30 dtk, Zona Pemula, Pajak Juara). Dipakai tes untuk memastikan engine tetap
 * mampu menegakkannya bila guru mengaktifkan kembali lewat config.
 */
export const legacyConfig: GameConfig = {
  ...defaultConfig,
  cooldown: { kartu_setelah_gagal_detik: 20, murid_setelah_gagal_detik: 15, murid_setelah_gagal_rebut_detik: 30 },
  pajak_juara: [
    { min_kartu: 5, baris_minimal: 4 },
    { min_kartu: 8, baris_minimal: 6 },
  ],
  zona_pemula: { baris: [1, 2], maks_kartu_dimiliki: 1, berlaku_sampai_menit: 10 },
  jeda_soal: { setiap: 2, detik: 0 },
};

/** Config bawaan tetapi tanpa jeda tiap 2 soal, untuk tes yang memainkan banyak aksi beruntun oleh satu murid. */
export const noPauseConfig: GameConfig = { ...defaultConfig, jeda_soal: { setiap: 2, detik: 0 } };

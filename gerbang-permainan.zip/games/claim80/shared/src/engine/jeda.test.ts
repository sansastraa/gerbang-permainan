import { describe, expect, it } from "vitest";
import { createGame, reduce } from "./index";
import type { Action } from "./index";
import { defaultConfig } from "./testConfig";

const waktuPerLevel = { 1: 30, 2: 30, 3: 45, 4: 60, 5: 60, 6: 90, 7: 120, 8: 180 };

function setup(jeda: { setiap: number; detik: number }) {
  let now = 1_000_000;
  let state = createGame({ config: { ...defaultConfig, jeda_soal: jeda }, waktuPerLevel }, 9);
  const act = (a: Action) => {
    const r = reduce(state, a, now);
    state = r.state;
    return r.events;
  };
  for (const id of ["a", "b"]) act({ type: "join", playerId: id, name: id, initials: id, color: "x" });
  act({ type: "start" });
  let d = 0;
  return {
    act,
    get state() {
      return state;
    },
    get now() {
      return now;
    },
    adv(ms: number) {
      now += ms;
      act({ type: "tick" });
    },
    claim: (id: string, cell: string) => act({ type: "claim", playerId: id, cell, deliveryId: `d${++d}` }),
    answer: (id: string, ok: boolean) =>
      act({ type: "answer", playerId: id, deliveryId: state.players[id]!.active!.deliveryId, correct: ok }),
  };
}

describe("jeda tiap N soal (permintaan guru)", () => {
  it("config bawaan: setiap 2 soal dibekukan 5 detik (benar maupun salah dihitung)", () => {
    expect(defaultConfig.jeda_soal).toMatchObject({ setiap: 2, detik: 5 });
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "A3");
    expect(h.answer("a", false).some((e) => e.type === "player_paused")).toBe(false); // soal ke-1
    expect(h.claim("a", "A3").map((e) => e.type)).toEqual(["locked"]); // belum dibekukan
    const ev = h.answer("a", true); // soal ke-2
    expect(ev.find((e) => e.type === "player_paused")?.data?.detik).toBe(5);
    expect(h.state.players.a!.cooldownUntil).toBe(h.now + 5000);
    expect(h.claim("a", "B3")[0]!.data!.reason).toBe("player_cooldown");
    h.adv(4900);
    expect(h.claim("a", "B3")[0]!.type).toBe("rejected");
    h.adv(200);
    expect(h.claim("a", "B3").map((e) => e.type)).toEqual(["locked"]);
  });

  it("hitungan berulang tiap 2 soal, per murid, dan tidak mengganggu murid lain", () => {
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "C2");
    h.answer("a", true);
    h.claim("a", "D2");
    h.answer("a", true); // jeda pertama
    h.adv(5100);
    h.claim("a", "E2");
    h.answer("a", true);
    expect(h.state.players.a!.sincePause).toBe(1);
    expect(h.claim("b", "F2").map((e) => e.type)).toEqual(["locked"]); // b tidak ikut dibekukan
    h.answer("b", true);
    h.claim("a", "G2");
    const ev = h.answer("a", false); // soal ke-4 milik a → jeda kedua
    expect(ev.some((e) => e.type === "player_paused")).toBe(true);
  });

  it("setiap 3 soal berlaku, dan detik 0 menonaktifkan jeda", () => {
    const h3 = setup({ setiap: 3, detik: 5 });
    for (const c of ["A2", "B2"]) {
      h3.claim("a", c);
      h3.answer("a", true);
    }
    expect(h3.state.players.a!.cooldownUntil).toBe(0);
    h3.claim("a", "C2");
    h3.answer("a", true);
    expect(h3.state.players.a!.cooldownUntil).toBeGreaterThan(0);

    const off = setup({ setiap: 2, detik: 0 });
    for (const c of ["A2", "B2", "C2", "D2"]) {
      off.claim("a", c);
      off.answer("a", true);
    }
    expect(off.state.players.a!.cooldownUntil).toBe(0);
  });

  it("waktu habis juga dihitung sebagai soal selesai", () => {
    const h = setup({ setiap: 2, detik: 5 });
    h.claim("a", "A1");
    h.adv(60_000);
    h.claim("a", "B1");
    h.adv(60_000);
    expect(h.state.players.a!.cooldownUntil).toBeGreaterThan(0);
  });
});

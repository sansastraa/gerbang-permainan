import type { Award } from "./engine/awards";
import type { Phase, PowerUp, CardStatus } from "./engine/types";

/** Satu siswa dari daftar kelas (diimpor dari SIMPETERI). */
export interface RosterEntry {
  /** id siswa di SIMPETERI (siswa.id) */
  id: string;
  name: string;
  absen?: number | null;
}

export interface PublicCard {
  cell: string;
  status: CardStatus;
  ownerId: string | null;
  /** inisial pemilik, ditampilkan pada kartu yang sudah diklaim */
  initials: string | null;
  color: string | null;
  value: number;
  jackpotPct: number;
  shielded: boolean;
  immune: boolean;
  cooldownUntil: number;
  /** murid yang sedang mencoba (LOCKED) atau menantang (CONTESTED) */
  tryingId: string | null;
  tryingInitials: string | null;
  /** hanya terisi setelah kartu emas diklaim */
  golden: boolean;
}

export interface LeaderEntry {
  id: string;
  name: string;
  initials: string;
  color: string;
  score: number;
  cards: number;
  streak: number;
}

export interface MeState {
  id: string;
  name: string;
  initials: string;
  color: string;
  score: number;
  cards: number;
  streak: number;
  bestStreak: number;
  tickets: number;
  powerUps: PowerUp[];
  saver: boolean;
  goldenKey: boolean;
  cooldownUntil: number;
  frozen: boolean;
  rank: number;
  /** id badge yang sudah diraih di sesi ini */
  badges: string[];
  /** terisi setelah permainan selesai: XP lintas sesi */
  xp?: { gain: number; total: number; level: string; next: number | null };
}

/** Soal yang dikirim ke murid: tanpa kunci, opsi memakai token acak per pengiriman. */
export interface QuestionDeliver {
  deliveryId: string;
  nonce: string;
  cell: string;
  mode: "claim" | "steal";
  level: number;
  kategori: string;
  tipe: "pg" | "angka" | "teks";
  soal: string;
  opsi: { optId: string; text: string }[] | null;
  satuan?: string;
  audio?: { notes: string[]; durasi: number };
  /** waktu server (ms) saat dikirim, deadline dalam jam server */
  serverNow: number;
  deadline: number;
  totalMs: number;
}

/** Aturan yang perlu diketahui klien untuk menampilkan petunjuk (bukan untuk menegakkan; penegakan di server). */
export interface ClientRules {
  pajak: { min_kartu: number; baris_minimal: number }[];
  zona: { baris: number[]; maks: number; sampaiMenit: number };
  poin: Record<number, number>;
  /** waktu efektif per level (detik) setelah pengali kecepatan */
  waktuDetik: Record<number, number>;
  pengaliKolom: Record<string, number>;
  audioMaks: number;
  fokusToleransiMs: number;
  /** fase tempat rebut aktif */
  rebutFase: string[];
}

/** Mode Stasiun (SPEC §2, §8.4): beberapa tablet di depan kelas, murid antre dan bergiliran. */
export interface StationState {
  mode: boolean;
  stations: { no: number; studentId: string | null; name: string | null; initials: string | null }[];
  queue: { id: string; name: string; initials: string; color: string }[];
}

export interface HostSettings {
  /** kolom yang soalnya selalu diacak oleh generator (anti-hafal), mis. ["A","E","I"] */
  alwaysRandom: string[];
  stationMode: boolean;
  /** durasi permainan (menit) */
  durasiMenit: number;
  /** pengali waktu menjawab terhadap waktu bank (mis. 0,6) dan batas minimum (detik) */
  pengaliWaktu: number;
  waktuMin: number;
  /** jeda: setiap N soal selesai, murid dibekukan `jedaDetik` detik (0 = nonaktif) */
  jedaSetiap: number;
  jedaDetik: number;
  /** pengaturan waktu dikunci setelah permainan dimulai */
  locked: boolean;
}

export interface BadgeInfo {
  id: string;
  nama: string;
  ikon: string;
  syarat: string;
  bonus: number;
}

export interface Snapshot {
  rules: ClientRules;
  badgeDefs: BadgeInfo[];
  /** antrean dan stasiun (proyektor, guru, stasiun) */
  station?: StationState;
  /** pengaturan sesi (hanya guru) */
  settings?: HostSettings;
  /** PIN kelas yang sedang berlaku (hanya guru) */
  pin?: { value: string; expiresAt: number; intervalMs: number };
  /** pengaturan VO (proyektor dan guru) */
  vo?: VoSettings;
  /** ejaan fonetik nama VO per murid (hanya guru) */
  voNames?: Record<string, string>;
  /** terisi setelah permainan selesai */
  awards?: Award[];
  sessionId: string;
  code: string;
  className: string;
  phase: Phase;
  serverNow: number;
  startedAt: number;
  pausedAt: number | null;
  durationMs: number;
  board: PublicCard[];
  leaderboard: LeaderEntry[];
  mission: { claimed: number; target: number; done: boolean };
  me?: MeState;
  question?: QuestionDeliver;
  /** hanya untuk host */
  roster?: HostPlayer[];
  flags?: FlagItem[];
}

export interface HostPlayer {
  id: string;
  name: string;
  initials: string;
  color: string;
  absen: number | null;
  pin: string;
  status: "none" | "pending" | "approved";
  deviceId: string | null;
  online: boolean;
  score: number;
  cards: number;
  streak: number;
  frozen: boolean;
  badges: number;
}

export type JoinResult =
  | { ok: true; status: "approved" | "pending" }
  | { ok: false; error: "no_session" | "no_student" | "bad_pin" | "locked" };

export interface AnswerResult {
  correct: boolean;
  reason?: string;
  pointsGained: number;
  streak: number;
  cell: string;
  mode: "claim" | "steal";
  powerUpOffer?: PowerUp;
  /** pesan ramah, tanpa kunci jawaban */
  message: string;
}

export type FlagSeverity = "kuning" | "oranye" | "merah";
export type FlagType =
  "fokus_hilang" | "fokus_gagal" | "terlalu_cepat" | "relay" | "pola_sama" | "login_ganda" | "perangkat_bersama";

/** Bendera anti-curang: sinyal untuk dicek guru, bukan vonis (SPEC §5). */
export interface FlagItem {
  id: number;
  ts: number;
  studentId: string | null;
  name: string;
  type: FlagType;
  severity: FlagSeverity;
  text: string;
  status: "open" | "diabaikan" | "ditindak";
}

export type VoMode = "semua" | "penting_dan_klaim" | "penting_saja" | "mati";
export type VoPrioritas = "rendah" | "normal" | "tinggi";

export interface VoSettings {
  mode: VoMode;
  /** 0..1 */
  volume: number;
  /** kecepatan bicara, mis. 1.05 */
  kecepatan: number;
  nada: number;
  /** subtitle selalu aktif (aksesibilitas); disimpan agar guru bisa melihatnya */
  subtitle: true;
}

/** Potongan kalimat VO; dipakai agar rekaman guru dapat disambung per bagian. */
export interface VoSegmen {
  /** jenis: nama murid, sel, atau teks tetap */
  k: "nama" | "sel" | "teks";
  v: string;
  /** id murid untuk k="nama" */
  id?: string;
}

/** Perintah putar VO ke proyektor (siaran `vo:play`, hanya ke room proyektor). */
export interface VoPlay {
  id: string;
  teks: string;
  segmen: VoSegmen[];
  jingle: string;
  prioritas: VoPrioritas;
  sorotSel?: string;
  studentId?: string;
  /** batas tampil minimum (ms) bila tidak ada suara */
  minMs: number;
}

/** Efek publik untuk proyektor (siaran `fx`). */
export interface FxEvent {
  type:
    | "claimed"
    | "stolen"
    | "golden"
    | "streak"
    | "steal_started"
    | "steal_failed"
    | "phase"
    | "mission"
    | "ended"
    | "gift"
    | "jackpot"
    | "badge_awarded";
  cell?: string;
  name?: string;
  initials?: string;
  color?: string;
  fromName?: string;
  fromInitials?: string;
  data: { streak?: number; label?: string; phase?: string; pct?: number; nama?: string; ikon?: string };
}

export interface TickerItem {
  id: number;
  ts: number;
  text: string;
  kind: "claim" | "steal" | "fail" | "special" | "phase" | "info";
}

import { describe, expect, it } from "vitest";
import { judgeValue, normalizeNumber, normalizeText } from "./judge";
import type { Question } from "./schemas";

const base = {
  id: "E6-2",
  sel: "E6",
  kolom: "E",
  level: 6,
  varian: 2,
  kategori_kolom: "aritmetika",
  subkategori: "aritmetika",
  soal: "x",
  waktu_detik: 90,
  poin_dasar: 70,
  pembahasan: "",
} as const;
const angka = (jawaban: number, satuan?: string, toleransi = 0): Question => ({
  ...base,
  tipe: "angka",
  jawaban,
  toleransi,
  ...(satuan ? { satuan } : {}),
});

describe("normalizeNumber", () => {
  it("menganggap 5.000, Rp5000, dan 5000 sama", () => {
    expect(normalizeNumber("5.000")).toBe(5000);
    expect(normalizeNumber("Rp5000")).toBe(5000);
    expect(normalizeNumber("Rp 5.000")).toBe(5000);
    expect(normalizeNumber("5000")).toBe(5000);
  });
  it("koma desimal", () => {
    expect(normalizeNumber("0,5")).toBe(0.5);
    expect(normalizeNumber("2.5")).toBe(2.5);
  });
  it("tanda minus Unicode", () => {
    expect(normalizeNumber("−50")).toBe(-50);
  });
  it("derajat dan satuan", () => {
    expect(normalizeNumber("75°")).toBe(75);
    expect(normalizeNumber("48 km/jam", "km/jam")).toBe(48);
    expect(normalizeNumber("26 cm")).toBe(26);
  });
  it("menolak sampah", () => {
    expect(normalizeNumber("abc")).toBeNull();
    expect(normalizeNumber("")).toBeNull();
    expect(normalizeNumber("1,2,3")).toBeNull();
  });
});

describe("judgeValue", () => {
  it("angka dengan toleransi", () => {
    expect(judgeValue(angka(5000, "rupiah"), "Rp5.000")).toBe(true);
    expect(judgeValue(angka(5000), "5001")).toBe(false);
    expect(judgeValue(angka(10, undefined, 0.5), "10,4")).toBe(true);
  });
  it("teks: huruf besar/kecil dan tanda baca", () => {
    const q: Question = { ...base, tipe: "teks", jawaban_diterima: ["garuda"] };
    expect(judgeValue(q, "  GARUDA! ")).toBe(true);
    expect(judgeValue(q, "garudaa")).toBe(false);
    expect(normalizeText("Vb  kJi.")).toBe("vb kji");
  });
  it("pg tidak dinilai lewat teks", () => {
    const q: Question = { ...base, tipe: "pg", opsi: ["a", "b"], jawaban: "a", acak_opsi: true };
    expect(judgeValue(q, "a")).toBe(false);
  });
});

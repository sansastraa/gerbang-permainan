import { describe, expect, it } from "vitest";
import { makeInitials, playerColor } from "./identity";

describe("makeInitials", () => {
  it("memakai kata pertama dan terakhir", () => {
    expect(makeInitials(["Rina Putri Ayu"])).toEqual(["RA"]);
    expect(makeInitials(["Budi"])).toEqual(["BU"]);
  });
  it("selalu unik dalam satu kelas", () => {
    const names = ["Andi Saputra", "Ani Sulistiyo", "Agus Sari", "Andi Santoso", "Andi Saputra"];
    const r = makeInitials(names);
    expect(new Set(r).size).toBe(names.length);
  });
  it("tahan nama aneh", () => {
    expect(makeInitials(["  ", "O'Neil  Jr."])[1]).toMatch(/^[A-Z]/);
    expect(makeInitials([""])[0]).toBeTruthy();
  });
});

describe("playerColor", () => {
  it("25+ warna berbeda", () => {
    expect(new Set(Array.from({ length: 30 }, (_, i) => playerColor(i))).size).toBe(30);
  });
});

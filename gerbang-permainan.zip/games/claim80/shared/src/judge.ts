import type { Question } from "./schemas";

/** Normalisasi angka sesuai SPEC §7.3. Mengembalikan null bila tidak bisa diparse. */
export function normalizeNumber(input: string, satuan?: string): number | null {
  let s = input.normalize("NFKC").toLowerCase();
  s = s.replace(/[−‒–—]/g, "-");
  s = s.replace(/rp\.?/g, "").replace(/°/g, "");
  if (satuan) {
    const u = satuan.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    s = s.replace(new RegExp(u, "g"), "");
  }
  s = s.replace(/\s+/g, "");
  // buang satuan huruf di ujung (mis. "5cm", "48km/jam")
  s = s.replace(/[a-z/%²³]+$/g, "");
  if (/^-?\d{1,3}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, "");
  s = s.replace(",", ".");
  if (!/^-?\d+(\.\d+)?$/.test(s)) return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

/** Normalisasi teks: huruf kecil, trim, buang tanda baca, rapatkan spasi. */
export function normalizeText(input: string): string {
  return input
    .normalize("NFKC")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, "")
    .replace(/\s+/g, " ")
    .trim();
}

/** Menilai jawaban angka/teks. Jawaban pilihan ganda dinilai lewat optId di server. */
export function judgeValue(q: Question, raw: string): boolean {
  if (q.tipe === "angka") {
    const n = normalizeNumber(raw, q.satuan);
    return n !== null && Math.abs(n - q.jawaban) <= q.toleransi + 1e-9;
  }
  if (q.tipe === "teks") {
    const v = normalizeText(raw);
    return q.jawaban_diterima.some((a) => normalizeText(a) === v);
  }
  return false;
}

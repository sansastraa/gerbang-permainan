# PROGRESS — CLAIM 80

## M0 Scaffold — selesai

- npm workspaces `shared` (zod), `server` (Express + Socket.IO + better-sqlite3 + pino), `client` (Vite + React + Tailwind v4 + Zustand + Framer Motion + react-router).
- ESLint (flat config) + Prettier, Vitest di tiap paket. `npm run typecheck`, `test`, `lint`, `build` hijau.
- Server `server/src/main.ts`: `/health`, melayani `client/dist`, mencetak URL LAN. Port default 3080 (`PORT`).
- Catatan: Python tidak terpasang di mesin ini, jadi `scripts/build_bank.py` belum dijalankan (isi `data/` dan `docs/BANK_SOAL.md` dipakai apa adanya dari paket).

## M1 Bank & validasi — selesai

- `shared/src/schemas.ts`: skema zod item (pg/angka/teks), konfigurasi, badge, dan `validateBank` (SPEC §7.5: ≥ 2 varian per sel, opsi pg memuat jawaban, id konsisten).
- `shared/src/judge.ts`: normalisasi angka (5.000 = Rp5000 = 5000, "0,5", minus Unicode, °/satuan) dan teks; tes lengkap.
- Server memuat dan memvalidasi bank saat start (`server/src/questions/bank.ts`).
- Pemeriksaan isi: 160 soal lolos validasi; belum ditemukan kesalahan jawaban pada tinjauan manual sampel (A7-2, A8-2, F7-1, I7-2, J8-1, dst.).

## Permintaan tambahan dari pengguna (dicatat 2026-11-03)

- Paket soal per sel (mis. A1-1 / A1-2) **diacak per sesi**: varian mana yang tampil lebih dulu ditentukan RNG sesi (`Card.order`) — **sudah di engine (M2)**.
- **Anti-AI / jawaban cepat**: waktu soal dipersingkat (`kecepatan` di `config/game.config.json`: ×0,6, minimum 15 dtk) dan jawaban cepat (≤ 40% waktu) dapat bonus ×1,2 — **sudah di engine**. Pelengkap di M4/M7: pemilihan teks dinonaktifkan, deteksi fokus hilang, pengacakan opsi. Tidak ada cara teknis menjamin 100% tahan AI di perangkat murid; batas waktu ketat + pengawasan guru adalah pertahanan utamanya.
- Game dirancang per kelas dari **daftar siswa SIMPETERI** (impor `postMessage`, M6 + integrasi).
- **Strike** diartikan sebagai fitur streak beruntun (SPEC §4.1) — sudah di engine; mohon dikonfirmasi bila yang dimaksud hal lain.
- Kartu yang sudah diklaim di papan menampilkan **inisial siswa** (M4/M5, engine sudah menyimpan `owner` + `initials`).

## M2 Engine — selesai

- `shared/src/engine/{types,state,eligibility,scoring,combos}.ts`: `createGame(rules, seed)` dan `reduce(state, action, now)` murni (RNG ikut di state, replay identik).
- Mencakup: state machine kartu OPEN/LOCKED/CLAIMED/COOLDOWN/CONTESTED, kelayakan (maks 1 kartu aktif, cooldown, Zona Pemula, Pajak Juara, beku), skor & streak, jackpot, rebut (tiket, varian lain, ×0,75, imun/perisai, Benteng Kokoh), golden/gift, Terjun Bebas, Penakluk Puncak, Ahli Kolom, Pelangi, Wilayah di akhir, Misi Kelas, power-up, fokus hilang, fase otomatis, jeda/lanjut, void/restore/adjust/freeze.
- 38 tes engine (termasuk race dua klaim bersamaan, J8 di detik pertama, invarian 80 kartu pada 600 langkah acak, determinisme). Total 50 tes shared + 1 server hijau, lint bersih.
- Keputusan: hadiah power-up streak diberikan acak otomatis (SPEC menyebut "pilih 1"); `host_restore` pada kartu hasil rebut memakai nilai kartu saat ini.

## M3 Server realtime — selesai

- `server/src/db.ts`: SQLite (better-sqlite3; tabel sessions, events, flags, deliveries, students). Log `events` append-only dengan rantai hash `sha256(prev|ts|type|actor|payload)`; `verifyChain` mendeteksi perubahan manual. Yang dicatat adalah **aksi** yang diterima engine (+ ts), sehingga state bisa di-replay persis (`replayState`, `Registry.restoreAll` setelah restart).
- `server/src/session.ts` (`GameSession`): membungkus engine; membuat pengiriman soal dengan **optId token acak**, nonce sekali pakai, opsi diacak per murid; menilai jawaban di server; 50:50, +15 detik, Mata Elang; siaran `board:diff`, `leaderboard:update` (top 10), `player:update`, `ticker:push`, `host:roster`; inisial unik per siswa (`makeInitials`) ditampilkan pada kartu yang diklaim.
- `server/src/socket.ts`: room `session/projector/host/player`; proyektor tidak pernah menerima `question:deliver`; host butuh token; satu murid = satu socket (perangkat lama diputus); validasi zod; batas 5 aksi/10 dtk; reconnect → `state:snapshot` termasuk soal aktif.
- `server/src/main.ts`: REST `POST /api/sessions` (impor daftar siswa kelas + `autoApprove`), `/api/join/:code`, `/api/sessions/:id/pins`, `/api/host-token` (hanya loopback), CORS hanya untuk `ALLOWED_ORIGINS`. Loop timer tunggal 250 ms.
- Tes: 13 tes sesi (payload bebas kunci, replay nonce, deadline server, race klaim, reconnect, 50:50, join/PIN, rantai hash rusak terdeteksi, replay = state langsung, restart) + 3 tes Socket.IO nyata. Total 54 shared + 18 server hijau, lint & typecheck bersih.
- Catatan: PIN disimpan apa adanya di SQLite agar Kartu PIN bisa dicetak ulang (alat kelas lokal). Pendeteksi anti-curang lanjutan (terlalu cepat, relay, pola jawaban, perangkat ganda → `flags`) ada di M7; yang sudah ada hanya fokus hilang (engine) dan batas laju.

## M4 `/play` — selesai

- `client/src/play/`: `Play.tsx` (alur kode sesi → pilih nama → PIN 4 digit + Kode Kehormatan → menunggu persetujuan → game), `playStore.ts` (Zustand + Socket.IO, auto-rejoin saat sambungan pulih, `deviceId` di localStorage), `logic.ts` (petunjuk kelayakan murni: Pajak Juara, Zona Pemula, cooldown, rebut), `play.css`.
- Papan 10×8: sel OPEN menampilkan poin (kolom H: "?"), LOCKED ⏳, COOLDOWN retak + hitung mundur, CLAIMED berwarna pemilik dengan **inisial siswa**, kartu sendiri bercincin, 🛡 untuk perisai/imun, badge jackpot. Ketuk sel → lembar detail (kategori, level, poin, waktu efektif) → Ambil / Rebut / Mata Elang / Perisai.
- Layar soal: timer cincin (jam server dikoreksi), opsi besar bertoken, keypad angka, kolom teks, tombol putar nada (maks 3×), 50:50 dan +15 detik; salin/tempel/menu konteks/seleksi dinonaktifkan; fokus hilang > 1,5 dtk dilaporkan ke server; hasil benar/salah tanpa kunci jawaban.
- `client/src/audio/synth.ts`: Web Audio (nada, sfx), buka kunci lewat ketukan, tombol bisukan tersimpan.
- `scripts/seed-demo.ts`: membuat sesi demo 25 siswa di server yang berjalan.
- Diverifikasi di browser (viewport 375×812) terhadap server sungguhan: pilih nama → PIN → klaim E2 → jawab → kartu "RA" muncul, skor 15, streak 1, tanpa galat konsol. Tes: 7 tes klien (logika, keypad, frekuensi nada). Total 54 + 18 + 7 hijau, lint bersih.
- Belum: uji di Chrome Android/Safari iOS sungguhan (audio, fullscreen, getar), uji layar 360 px pada perangkat nyata, zoom/pan selain geser mendatar, animasi tambahan.

## M5 `/projector` — selesai

- Permintaan pengguna: **bukan peta kursi**, melainkan **kartu pilih kartu**, modern, interaktif, bersih. Tiap kartu berbentuk kartu remi: strip warna kategori, indeks sudut (kode sel kiri atas, poin kanan bawah), ikon kategori di tengah; saat diklaim **membalik** (Framer Motion) menjadi kartu berwarna pemilik dengan **inisial besar** dan nilai kartu; ⏳ avatar berdenyut saat dicoba, retak + hitung mundur saat gagal, 🛡 perisai, ⚔️ saat direbut, kilau emas untuk kartu emas, badge jackpot. Kolom H tampil "❓" sampai diklaim. Gaya yang sama (strip warna kategori) dipakai di papan murid.
- `client/src/projector/` (`Projector.tsx`, `projStore.ts`, `projector.css`) + `client/src/theme.ts`: header (fase, jam, misi kelas), papan 10×8 yang mengisi layar, Top 10 beranimasi (urutan berpindah halus; peringkat bawah tidak pernah tampil), ticker kabar terbaru, banner layar penuh (streak ≥ 5, kartu emas, rebut, bertahan, fase, misi, selesai), kabut lembut pada fase RUSH, lobi dengan **QR + alamat LAN + kode sesi** (`/api/lan`), klik kartu = sorotan besar (interaktif), tombol **A** mematikan/menyalakan animasi (tersimpan).
- Server: siaran `fx` ke room sesi (identitas publik saja; tes memastikan tanpa soal/jawaban/token), `ticker:backlog` untuk proyektor; jackpot hanya diumumkan di ticker bila ≥ 30%.
- Diverifikasi di browser 1920×1080 terhadap server sungguhan dengan 20 bot: papan penuh kartu berinisial, Top 10, misi 48/70, dan **server dimulai ulang di tengah sesi lalu sesi pulih dari log** (state sama). Tes baru: 4 tes `bannerFor`, 1 tes siaran `fx`. Total 54 + 19 + 11 hijau, lint bersih.
- Alat: `scripts/demo-bots.ts` (bot untuk mengisi papan demo).
- Belum: subtitle/sorot sel VO (M8b), Rising Star dan misi di ticker lanjutan (M8), uji di proyektor fisik 8 m (ukuran huruf sel ≥ 28 px pada 1080p sudah diatur lewat clamp tetapi belum diukur di perangkat), efek suara proyektor.

## Tambahan M5 (permintaan pengguna) — Top 10 interaktif & streak ungu

- `client/src/projector/Leaderboard.tsx` + `rankMarks.ts`: pendatang baru meluncur masuk dengan chip **BARU**; peserta yang tersingkir dari 10 besar memudar keluar; yang **naik peringkat** bergeser ke atas dengan sorot **hijau** dan chip ▲n; yang turun diberi sorot merah lembut dengan ▼n; kenaikan skor memunculkan **+N** hijau; urutan berpindah dengan animasi pegas.
- **Streak ungu**: chip ⚡N ungu pada Top 10, papan guru, dan bar atas murid; makin pekat pada streak 3 / 5 (bercincin) / 8 (👑). Jawaban salah memutus streak (engine; Streak Saver menahannya sekali) dan chip **mengecil lalu hilang** dengan animasi keluar.
- Tes: `rankMarks.test.ts` (naik/turun/baru/lompat, kenaikan skor, tingkat streak). Diverifikasi di browser 1920×1080 dengan bot: sorot hijau + ▲, ▼ merah, +N, chip ungu.
- Belum diperiksa secara visual: tersingkirnya peringkat 11 (uji nyata butuh > 10 siswa; perilakunya diuji pada fungsi `rankMarks` dan memakai `AnimatePresence` exit) — akan terlihat saat `npm run sim` dengan 25 bot dipantau di proyektor.

## M6 `/host` — selesai

- `client/src/host/`: `Host.tsx` (beranda: terima daftar siswa dari SIMPETERI lewat `postMessage` atau tempel manual; daftar sesi; konsol sesi), `hostStore.ts`, `Pins.tsx` (Kartu PIN cetak A4, 8 per halaman), `importRoster.ts` (pola Route Rush: pesan `claim80:roster`, balasan siap `claim80:host-ready`, hanya diterima dari `window.opener`, divalidasi dan dibersihkan), `host.css`.
- Konsol sesi: kode sesi + alamat gabung; tabel murid (status Menunggu/Online/Putus/Beku, PIN dapat ditampilkan, skor, kartu, streak); **Setujui satu / semua**; **Mulai**; kontrol fase OPEN/BATTLE/RUSH, **Jeda/Lanjutkan**, **Akhiri** (konfirmasi); **Bekukan/Cairkan**; **± Poin** dengan alasan wajib; tab **Papan** (klik kartu → batalkan klaim / kembalikan ke pemilik sebelumnya); tab **Kabar** (log ringkas); tautan buka proyektor. Token guru diambil otomatis dari laptop server, atau diketik dari perangkat lain.
- Server: `host:rejected` memberi umpan balik bila aksi ditolak engine.
- Diverifikasi di browser: buat sesi manual → daftar murid → murid menunggu → setujui semua → mulai (fase OPEN, jam berjalan) → proyektor menampilkan hasil bot. Tes: 4 tes parsing impor (pesan asing/rusak ditolak, pemangkasan).
- Belum diuji: `postMessage` dari SIMPETERI sungguhan (sisi SIMPETERI belum dibuat), cetak fisik Kartu PIN, tombol Bendera anti-curang (M7).
- Insiden: satu sunting PowerShell sempat merusak encoding teks Indonesia (mojibake) di `Host.tsx` dan nama tes engine; sudah dipulihkan dan diperiksa tidak ada sisa.

## M7 Anti-curang — selesai

- **Pencegahan (§5.1)** sudah ada sejak M2–M4 dan kini diuji ulang: kunci tak pernah dikirim (tes payload + fx), timer server, satu pengiriman satu jawaban (nonce), opsi diacak per murid, proyektor tanpa soal, identitas PIN + persetujuan, satu murid satu socket, batas laju 5/10 dtk, UI tanpa seleksi/salin/menu konteks + fullscreen.
- **Deteksi (§5.2)** `server/src/anticheat/detectors.ts` (murni, diuji) + pemasangan di `session.ts`: fokus hilang (peringatan 🟡, gagal otomatis 🟠 — DoD 5 tercatat di tabel `flags`), terlalu cepat (level ≥ 5, benar, < 1,5 dtk + 150 ms/kata → 🟡, **tanpa penalti**), pola jawaban salah sama ≥ 3 kali antar dua murid (🟠), relay (🟠; **hanya aktif bila peta kursi diisi** lewat `setNeighbors` — UI peta kursi belum dibuat), login ganda dan perangkat bersama (🔴; Mode Stasiun dikecualikan lewat `stationMode`).
- **Log audit (§5.3)**: rantai hash sejak M3; kini ada `GET /api/sessions/:id/log` (guru) berisi seluruh peristiwa, hasil verifikasi rantai, dan bendera.
- **Kendali guru (§5.4–5.5)**: tab **Bendera** di `/host` (🟡🟠🔴, Abaikan / Tindak) dengan sanksi berjenjang 1 peringatan pribadi, 2 batalkan klaim terakhir, 3 −1 tiket & −30 poin, 4 bekukan 3 menit (engine: aksi baru `host_ticket`, `Player.lastClaim`). Bendera tersimpan di SQLite dan pulih setelah restart.
- Perbaikan: token guru tersimpan di browser yang basi setelah server dimulai ulang kini divalidasi dan diambil ulang otomatis (sebelumnya "Token guru salah").
- Tes: 7 tes detektor, 7 tes sesi anti-curang (fokus 2× → flags, terlalu cepat tanpa penalti, perangkat/login ganda, pola sama, relay, sanksi, resolve + pemulihan), 1 tes engine, 1 tes log. Total 55 + 33 + 20 hijau. Diverifikasi di browser: tab Bendera menampilkan bendera "terlalu cepat" dari 14 bot.
- Belum: "Jujur Itu Keren" (+20, M8), peta kursi, perilaku anti-curang pada perangkat murid sungguhan (mis. peramban yang tidak memicu `visibilitychange`), pengujian relay secara realistis.
- Catatan jujur: tidak ada cara teknis menjamin murid tidak memakai AI di perangkat lain atau di perangkat kedua; pertahanannya adalah batas waktu ketat, deteksi sinyal, dan pengawasan guru.

## Perubahan aturan atas permintaan guru (2026-11-03)

- **PIN seragam**: satu PIN 4 digit untuk seluruh kelas (`Session.create`); halaman cetak menjadi poster PIN kelas. Konsekuensi yang perlu diketahui: murid bisa memilih nama temannya, jadi pengamannya adalah persetujuan guru, satu socket per murid (login ganda → bendera merah), dan bendera perangkat bersama.
- **Tanpa pembekuan**: salah jawab tidak lagi membekukan kartu (20 dtk) maupun murid (15 dtk / 30 dtk saat rebut gagal). Kartu langsung OPEN dengan varian soal berikutnya; jackpot tetap naik; perisai setelah rebut gagal tetap ada. Diatur di `config/game.config.json` → `cooldown` (isi detik > 0 untuk mengaktifkan lagi).
- **Tanpa batas kartu**: Pajak Juara dan Zona Pemula dinonaktifkan (`pajak_juara: []`, `zona_pemula.baris: []`). Engine tetap mampu menegakkannya bila diaktifkan; tes aturan lama memakai `legacyConfig` (`shared/src/engine/testConfig.ts`), tes aturan baru memakai config bawaan.

## M8 Gamifikasi lanjutan — selesai

- **Badge** (`config/badges.json`): First Blood, Sniper, Comeback Kid, Pencuri Ulung, Benteng, Penjelajah, Pemberani, Polymath, Ahli Kolom ×10, Kelas Juara diberikan otomatis oleh engine (dengan bonus poin sesuai config); **Jujur Itu Keren** diberikan guru lewat tombol "Jujur ✓". Diumumkan di ticker, toast pribadi, dan siaran `fx`; daftar badge tampil di lembar Badge murid.
- **Penghargaan akhir** (`shared/src/engine/awards.ts`): Juara Umum 1–3, Raja/Ratu per kategori (akurasi tertinggi, min. 2 percobaan), Rising Star (peringkat 15 menit sebelum selesai vs akhir), Paling Berani, Penjaga Benteng. Proyektor memutar **upacara penghargaan** (podium muncul dari peringkat 3 ke 1, lalu penghargaan lain bergantian + konfeti); murid melihat penghargaan miliknya.
- **XP lintas sesi**: XP = skor ÷ 10, level Pemula → Penjelajah → Ahli → Master → Grandmaster (ambang 0/50/150/400/900). Disimpan sekali per sesi per murid di SQLite (`xp_awards`, `students`, `student_badges`), tidak digandakan setelah restart, dan id manual (tanpa SIMPETERI) tidak disimpan lintas sesi.
- Tes: 15 tes badge/penghargaan/XP di engine, 4 tes sesi (PIN seragam, badge, selesai + XP + restart, id manual). Total 74 + 36 + 20 hijau, lint & typecheck bersih.

## Desain ulang UI ("papercraft arcade") — selesai

- Arah desain: kertas krem berpola titik, garis tinta tebal 2 px, **bayangan keras bergeser** (bukan blur), warna kategori jenuh seperti stiker, font **Bricolage Grotesque** (judul/angka) + **Plus Jakarta Sans** (isi) yang dibundel lewat paket (tanpa internet), gerak berbasis pegas. Tanpa gradien, tanpa kaca buram; ungu hanya untuk streak.
- **Murid**: papan 10×8 mungil diganti **pilih dek lalu pilih kartu besar** (rel dek dengan 8 petak status per dek, kartu bertingkat dengan animasi "dibagikan", kartu terklaim berwarna pemilik dengan inisial besar), kartu soal bergaya stiker, timer cincin, tombol bertekstur "ditekan", konfeti saat benar, lembar badge, layar akhir dengan penghargaan dan bar XP.
- **Proyektor**: kartu bergaya stiker dengan strip kategori, header, Top 10, banner, lobi QR, dan upacara penghargaan dalam bahasa desain yang sama.
- **Guru**: konsol dengan kartu statistik (online / masuk / terklaim / bendera), tombol bertekstur, poster PIN kelas.
- Diverifikasi di browser: murid (pilih nama → PIN → dek → kartu → soal → benar → konfeti +234), proyektor 1920×1080, upacara penghargaan, konsol guru.
- Belum: uji di perangkat sungguhan, pengukuran keterbacaan dari jarak 8 m, mode gelap.

## M8b Voice-Over — selesai

- **Server** (`server/src/vo/`): `director.ts` mengelola antrean VO — tiga prioritas (tinggi menyalip tetapi tidak memotong yang sedang bicara), **penggabungan** ≥ 3 klaim rendah yang menumpuk menjadi satu pengumuman ("N kartu baru terklaim: A satu, Be dua, dan De tiga"), **kedaluwarsa** (rendah 6 dtk, normal 8 dtk, tinggi 15 dtk; yang basi hanya muncul di ticker), satu murid tidak disebut > 2 kali per 20 dtk pada prioritas rendah, varian tidak sama dengan varian terakhir, jeda 400 ms antar VO, pelepasan otomatis bila proyektor tidak membalas `vo:done`. `naskah.ts` memuat `config/vo_naskah.json` (sel diucapkan "E enam", "Je delapan") dan memecah kalimat menjadi segmen nama/sel/teks.
- **Pemetaan peristiwa** (`session.ts`): klaim per level (1–3 rendah, 4–6 normal, 7–8 tinggi, Mystery), kartu emas, jackpot (≥ 2 kali gagal), terjun bebas, penakluk puncak, hadiah, rebut mulai/berhasil/gagal, streak 3/5/8, fase BATTLE/RUSH, misi kelas (dekat dan tercapai), selesai, dan hitung mundur 10 detik terakhir. **Jawaban salah tidak pernah menghasilkan VO**; isi soal dan jawaban tidak pernah dibacakan. `vo:play` dikirim **hanya ke room proyektor**; murid yang disebut mendapat toast "Namamu sedang diumumkan!"; perangkat murid tidak memutar suara.
- **Pengaturan** dari guru: mode Semua / Penting dan klaim (bawaan) / Penting saja / Mati, volume, kecepatan, nada, ejaan fonetik nama (`nama_vo`, tersimpan di SQLite). Subtitle selalu aktif.
- **Klien** (`client/src/audio/vo.ts`): urutan mesin **rekaman guru → suara Indonesia lokal (Web Speech) → suara Indonesia online → teks saja**; rekaman dipakai hanya bila seluruh bagian kalimat sudah direkam; jingle sintetis per kejadian di `synth.ts`. **Proyektor**: subtitle besar, **sel yang disebut berkedip**, avatar murid yang disebut membesar di Top 10, tombol "aktifkan suara" (izin autoplay), melaporkan mesin aktif ke guru. **Guru** `/host/:id/vo`: pengaturan, status mesin, "Tes VO", "Dengar di sini", ejaan nama, dan **perekam suara guru** (frasa tetap, 80 sel, nama murid) dengan MediaRecorder dan penyimpanan IndexedDB.
- Tes: 12 tes `director` (antrean, prioritas, penggabungan, kedaluwarsa, pembatasan, mode, varian, pengaman), 6 tes sesi (klaim benar → `vo:play` hanya ke proyektor; salah → tidak ada VO; 10 klaim → VO gabungan; hitung mundur + fase; nama fonetik + pengaturan; Tes VO tanpa ubah skor), 4 tes helper klien. Total 74 + 54 + 24 hijau, lint bersih.
- Diverifikasi di browser dengan 14 bot: subtitle muncul bergantian, sel yang disebut berkedip, avatar membesar, `vo:done` mengalir. Mesin yang tersedia di peramban pengujian ini hanya **teks** (tidak ada suara Indonesia), jadi **suara sebenarnya belum terdengar/teruji** di sini.
- Belum diuji: kualitas suara Indonesia di Windows/Android guru, perekaman dengan mikrofon sungguhan, penyambungan rekaman per segmen, latensi suara < 1 detik pada perangkat nyata. Belum ada musik latar, jadi "duck musik" tidak berlaku. Rekaman tersimpan per peramban/alamat, bukan di server.

## PIN kelas berganti otomatis (permintaan guru, 2026-11-05)

- PIN 4 digit **berganti tiap 5 menit** (`config/game.config.json` → `pin_kelas`: `ganti_tiap_menit`, `toleransi_detik`). PIN diturunkan dari rahasia sesi + slot waktu (HMAC), jadi tidak perlu disimpan dan **tetap sama setelah server restart**. Konsol guru menampilkan PIN terbaru di sisi kanan dengan hitung mundur; halaman poster PIN ikut memperbarui. PIN sebelumnya masih diterima 20 detik pertama setelah pergantian.
- Murid yang **sudah disetujui** menyambung ulang dari perangkat yang sama tanpa PIN terbaru (agar putus-sambung tidak mengunci murid); perangkat lain, murid baru, dan setelah restart bagi yang belum pernah disetujui tetap wajib PIN terbaru.
- **Token guru** kini stabil antar-restart (disimpan di `server/var/host-token.txt`, atau `HOST_TOKEN`) dan bisa dilihat lewat tombol "Token guru" di beranda konsol.
- Tes: 4 tes rotasi PIN (slot, toleransi, sambung ulang, siaran ke guru).

## M9 Statistik & laporan — selesai

- **Data mentah per percobaan** (SPEC §6.1) dari tabel `deliveries`: kini mencatat jawaban benar, salah (teks opsi yang dipilih), waktu habis, dan fokus hilang (`server/src/stats/stats.ts`).
- **Indikator murid** (§6.2): akurasi per kategori, Skor Kecerdasan 0–100 (Σ level benar ÷ Σ level dicoba, hanya bila ≥ 2 percobaan), level puncak, kecepatan (median + rasio terhadap median kelas pada level yang sama), keberanian, ketangguhan, eksplorasi; 7 kategori radar (B+C = Linguistik, I+J = Logika, kartu H menurut subkategori soalnya).
- **Heatmap kelas 10×8** dengan tanda revisi (p < 0,2 terlalu sulit; p > 0,9 di baris ≥ 5 terlalu mudah; minimal 3 percobaan), **analisis butir** (p, daya beda D 27% atas vs bawah, sebaran pengecoh), dan **rapor murid** dengan grafik radar, tabel kategori, badge, kalimat penyemangat dari kategori terkuat dan saran latihan dari yang terlemah (tanpa label negatif), plus catatan etis.
- **Halaman `/report/:id`** (tombol "Laporan" di konsol): rapor murid dengan **cetak A5 per murid / semua murid**, heatmap, analisis butir, ekspor.
- **Ekspor**: `students.csv`, `attempts.csv`, `items.csv` (BOM + CRLF, aman untuk Excel), `report.json` (guru), dan **`summary.json` untuk SIMPETERI** (Multi Permainan): `students[].studentId/name/points/rank/accuracy/profile{7 kategori}/…`. `summary.json` hanya tersedia setelah permainan selesai (403 sebelum itu kecuali dengan token guru), tanpa token karena dipanggil dari browser SIMPETERI; CORS dibatasi ke `ALLOWED_ORIGINS`, dan id sesi tidak dapat ditebak.
- Tes: 11 tes statistik/ekspor, 2 tes sesi (semua jenis percobaan tercatat), 1 tes endpoint (403 → 200, CSV butuh token), 2 tes radar. Total 74 + 72 + 26 hijau, lint bersih. Diverifikasi di browser dengan 20 bot: rapor, radar, heatmap dengan bingkai tanda.
- Belum: tren lintas sesi (per murid/kelas) dan rapor PDF langsung (cetak lewat dialog cetak peramban ke PDF), uji cetak fisik A5, tampilan murid sendiri untuk rapornya. Kegagalan karena waktu habis setelah server restart di tengah soal tidak tercatat (pengiriman soal hanya di memori).

## Pengaturan waktu dan jeda (permintaan guru, 2026-11-05)

- Tab **Pengaturan** di konsol guru: **durasi permainan** (5–120 menit; jadwal fase ikut diskalakan: BATTLE ≈ 37,5% waktu, RUSH di menit-menit terakhir), **waktu menjawab soal** (pengali 30–200% dari waktu bank + batas minimum detik, dengan pratinjau waktu efektif per level), dan **jeda**: setiap N soal selesai (benar, salah, atau waktu habis) murid itu **dibekukan beberapa detik** (bawaan: tiap 2 soal, 5 detik; 0 = mati). Konfigurasi dasar di `config/game.config.json` (`jeda_soal`, `kecepatan`, `durasi_menit`).
- Pengaturan waktu **dikunci setelah permainan dimulai** (konfigurasi ikut menentukan tenggat dan jadwal fase, jadi mengubahnya di tengah jalan akan membuat replay log tidak konsisten); disimpan di opsi sesi dan pulih setelah restart.
- Engine: `jeda_soal` + `Player.sincePause`, event `player_paused`; murid melihat hitungan mundur di papannya (kartu redup + "tunggu N detik"). Tes: 4 tes jeda engine, 4 tes konfigurasi, 4 tes sesi (durasi/waktu/jeda/penguncian/restart).

## M10 Mode Stasiun & generator — selesai

- **Generator parametrik** (`server/src/questions/generators.ts`, SPEC §7.4) untuk **seluruh 24 sel kolom A, E, I** (mis. E1 `a±b`, E3 penjumlahan dengan simpan, E5 `a + b × c − d`, E8 `(10^k − 1) × n`, A3/I1 barisan aritmetika/geometri, A4 FPB, A8 angka nol faktorial, I7 sandi geser, I8 teka-teki angka). Deterministik per (sesi, murid, sel, percobaan); waktu, poin, dan kategori mengikuti soal bank sel itu. Dipakai bila **kolom diset "Selalu Acak"** oleh guru (tab Pengaturan), atau otomatis setelah **kedua varian bank terpakai** (rebut/percobaan ke-3). Soal acak ikut statistik murid tetapi tidak masuk analisis butir bank.
- **Mode Stasiun** (SPEC §2, §8.4): `/station` untuk tablet di depan kelas — masuk satu kali dengan kode sesi + token guru, lalu layar antrean: **Panggil sekarang** (murid pertama di antrean), antre/panggil per nama, murid disetujui otomatis (stasiun diawasi guru), memakai **pipeline pemain yang sama** (soal, timer server, kunci tidak dikirim), kembali otomatis ke layar antrean **5 detik setelah soal dijawab**, tombol Selesai/batal. Guru: tab **Stasiun** (antrean, tambah/keluarkan, kosongkan, lepas stasiun macet). **Proyektor** menampilkan nomor stasiun, siapa yang sedang menjawab, dan antrean. Satu murid hanya di satu stasiun; nomor stasiun terkecil yang kosong.
- Tes: generator (24 sel × 150 seed lolos skema, jawaban konsisten, dicek perhitungan independen untuk E5/I8/A4/A8, deterministik), 11 tes sesi (settings, soal acak, stasiun), 3 tes Socket.IO nyata (token wajib, alur panggil → klaim → lepas, pengaturan terkunci, lepas oleh guru). Total 82 + 95 + 26 hijau, lint bersih. Diverifikasi di browser: tab Pengaturan menyimpan durasi/jeda/soal acak di server, layar `/station` terhubung sebagai Stasiun 1.
- Catatan jujur: stasiun memakai token guru (bukan PIN kelas yang berganti 5 menit) karena tablet diawasi guru; murid memilih nama sendiri di tablet. Alur penuh satu kelas dengan 2–4 tablet nyata belum dicoba. Tidak ada batas waktu otomatis bila murid di stasiun diam tanpa memilih kartu (guru memakai "Lepas" atau murid menekan Selesai/batal).

## M11 Simulasi & polish — sebagian selesai

- **`npm run sim`** (`scripts/simulate.ts`): server dijalankan di dalam proses dengan jam dipercepat (`--speed`, bawaan 10×) dan DB di memori; 25 bot Socket.IO sungguhan dengan akurasi acak per kolom (30–92%), berpikir 3 detik hingga ±55% waktu soal, ikut Rebut di fase BATTLE/RUSH. Dua bot menekan J8 serentak di detik pertama; satu bot menjawab setelah deadline; satu bot menghilangkan fokus dua kali. Keluarannya daftar LULUS/GAGAL per butir SPEC §10 dan kode keluar 1 bila ada yang gagal.
- **Hasil lari penuh 40 menit permainan (10×, 272 detik nyata)**: LULUS §10.1 (455 sampel invarian, total kartu selalu 80, fase OPEN>BATTLE>RUSH>END, tanpa galat; 1087 soal terkirim), §10.2 (satu pemenang J8 dari dua ketukan serentak), §10.3 (payload soal hanya berisi kunci yang dikenal, opsi hanya `optId`+`text`), §10.4 (jawaban benar setelah deadline ditolak, alasan `timeout`), §10.5 (fokus hilang 2× gagal + bendera), §10.7 (rantai hash utuh, skor hasil replay log sama dengan skor langsung untuk semua murid), §10.10 (report.json, summary.json, 3 CSV terunduh), §10.11 (J8 dikunci 242 ms setelah mulai), §10.12 (VO hanya ke proyektor: 47 ke proyektor, 0 ke murid).
- **Tidak diukur oleh simulasi**: §10.6 (diuji tes unit), §10.8 (audio di Chrome Android/Safari iOS), §10.9 (keterbacaan 8 m), serta pernyataan "jawaban salah tidak pernah menghasilkan VO" dan "10 klaim dalam 3 detik jadi satu VO gabungan" (diuji `director.test.ts`, bukan di simulasi). Bot yang menerima soal acak generator (kolom A/E/I setelah kedua varian terpakai) tidak punya kuncinya sehingga menebak: tingkat benar simulasi bukan ukuran kesulitan soal.
- **Aksesibilitas**: kartu terklaim menampilkan inisial selain warna; tombol suara di layar murid; tombol animasi di proyektor kini mengikuti pengaturan sistem "kurangi gerakan" bila belum ada pilihan tersimpan, dan CSS global mematikan animasi/transisi pada pengaturan itu. Kontras warna belum diukur dengan alat.
- **Belum dikerjakan**: tes e2e Playwright dengan Edge sistem (butuh pemasangan Playwright), uji kelas sungguhan (1 proyektor, 1 host, 3 perangkat murid), uji Wi-Fi/LAN dan perangkat murid asli.
- **Pindah ke SIMPETERI**: folder dipindahkan ke `games/claim80` di repositori SIMPETERI (sejajar `games/route-rush`); skrip akar `c80:*`; halaman `/claim-80` + menu Clash of Git; README (bagian deploy terpisah) di `games/claim80/README.md`.
- **BASE_PATH (permintaan guru, 2026-11-06)**: server dan klien bisa berjalan di bawah awalan jalur (server/src/basePath.ts, client/src/base.ts, ite.config.ts); tes asePath.test.ts (health, api, fallback SPA, socket.io, host-token lewat proxy ditolak) dan ase.test.ts. Terverifikasi di browser pada http://localhost:3080/games/claim80/ (aset, router, API, socket proyektor). Belum diuji lewat gerbang SIMPETERI sungguhan.
- Catatan lingkungan: di folder kerja sementara ini jalur berkas >260 karakter membuat `esbuild.exe` gagal dijalankan di Windows (ENOENT); perintah Node dijalankan lewat drive `subst` pendek. Itu keterbatasan folder kerja sementara, bukan kode.

## Berikutnya

Sesi kelas sungguhan, e2e Playwright, pengukuran kontras Server realtime → M4–M6 klien → M7–M11, lalu integrasi SIMPETERI (menu CLAIM 80, `claim-80.tsx`, `routeTree.gen.ts`, `roadmap.md`, `AGENTS.md`) dan ekspor ringkasan JSON per siswa.

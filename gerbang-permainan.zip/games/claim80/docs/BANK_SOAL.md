# CLAIM 80 — Bank Soal (versi baca guru)

Dibangkitkan otomatis dari `data/bank_soal.json`. Ubah soal di JSON, bukan di sini.

| Kolom | Kategori |
|---|---|
| A | Numerik — bilangan & nilai tempat |
| B | Linguistik — Bahasa Indonesia |
| C | Linguistik — Bahasa Inggris |
| D | Pengetahuan Umum |
| E | Aritmetika — hitung |
| F | Spasial |
| G | Musikal |
| H | Mystery — campuran (tersembunyi di papan) |
| I | Numerik-Logika — sandi & pola |
| J | Logika — deduksi |

| Level | Waktu | Poin dasar |
|---|---|---|
| 1 | 30 detik | 10 |
| 2 | 30 detik | 15 |
| 3 | 45 detik | 25 |
| 4 | 60 detik | 35 |
| 5 | 60 detik | 50 |
| 6 | 90 detik | 70 |
| 7 | 120 detik | 100 |
| 8 | 180 detik | 150 |

## Kolom A — Numerik — bilangan & nilai tempat

**A1-1** · Level 1 · ANGKA

Bilangan apa yang datang tepat setelah 99?

> **Kunci:** 100 — 99 + 1 = 100.

**A1-2** · Level 1 · PG

Mana yang lebih besar?

- A. 47
- B. Tidak bisa ditentukan
- C. 74  ✅
- D. Sama besar

> **Kunci:** 74 — 74 punya 7 puluhan, 47 hanya 4 puluhan.

**A2-1** · Level 2 · PG

Pada bilangan 352, angka 5 menempati nilai tempat...

- A. satuan
- B. ribuan
- C. puluhan  ✅
- D. ratusan

> **Kunci:** puluhan — 3 ratusan, 5 puluhan, 2 satuan.

**A2-2** · Level 2 · ANGKA

Bilangan ganjil terbesar yang kurang dari 50 adalah...

> **Kunci:** 49 — 50 genap, jadi ganjil terbesar di bawahnya 49.

**A3-1** · Level 3 · ANGKA

Lanjutkan pola: 3, 6, 12, 24, ...

> **Kunci:** 48 — Setiap suku dikali 2.

**A3-2** · Level 3 · ANGKA

Bulatkan 3.468 ke ribuan terdekat.

> **Kunci:** 3000 — Angka ratusan 4 < 5, jadi dibulatkan ke bawah: 3.000.

**A4-1** · Level 4 · PG

Pecahan yang senilai dengan 3/4 adalah...

- A. 6/4
- B. 6/8  ✅
- C. 3/8
- D. 4/3

> **Kunci:** 6/8 — 3/4 = (3×2)/(4×2) = 6/8.

**A4-2** · Level 4 · ANGKA

FPB dari 12 dan 18 adalah...

> **Kunci:** 6 — Faktor sekutu 12 dan 18: 1, 2, 3, 6. Terbesar 6.

**A5-1** · Level 5 · ANGKA

KPK dari 4, 6, dan 10 adalah...

> **Kunci:** 60 — KPK(4,6) = 12, lalu KPK(12,10) = 60.

**A5-2** · Level 5 · PG

Pecahan manakah yang paling BESAR?

- A. 7/12
- B. 3/5
- C. 5/8
- D. 2/3  ✅

> **Kunci:** 2/3 — Dalam desimal: 0,6; 0,667; 0,625; 0,583. Terbesar 2/3.

**A6-1** · Level 6 · ANGKA

Berapa banyak faktor dari 36?

> **Kunci:** 9 — 1, 2, 3, 4, 6, 9, 12, 18, 36 → 9 faktor.

**A6-2** · Level 6 · ANGKA

Ada berapa bilangan prima di antara 1 dan 50?

> **Kunci:** 15 — 2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47.

**A7-1** · Level 7 · ANGKA

Berapa jumlah semua bilangan genap dari 2 sampai 100?

> **Kunci:** 2550 — 2 + 4 + ... + 100 = 2 × (1 + 2 + ... + 50) = 2 × 1.275 = 2.550.

**A7-2** · Level 7 · ANGKA

Berapa angka satuan dari 7 pangkat 2026?

> **Kunci:** 9 — Angka satuan pangkat 7 berulang 7, 9, 3, 1 (siklus 4). 2026 : 4 bersisa 2 → angka kedua siklus = 9.

**A8-1** · Level 8 · ANGKA

Ada berapa angka 0 di ujung hasil perkalian 1 × 2 × 3 × ... × 100?

> **Kunci:** 24 — Setiap 0 di ujung butuh pasangan 2 × 5, dan faktor 5 lebih sedikit. ⌊100/5⌋ + ⌊100/25⌋ = 20 + 4 = 24.

**A8-2** · Level 8 · ANGKA

Bilangan asli terkecil yang jika dibagi 2, 3, 4, 5, atau 6 selalu bersisa 1, tetapi habis dibagi 7, adalah...

> **Kunci:** 301 — Bilangannya berbentuk 60k + 1 (KPK 2–6 = 60). Coba k = 1, 2, ...: 61, 121, 181, 241, 301. 301 = 7 × 43.


## Kolom B — Linguistik — Bahasa Indonesia

**B1-1** · Level 1 · PG

Lawan kata "besar" adalah...

- A. tinggi
- B. luas
- C. kecil  ✅
- D. berat

> **Kunci:** kecil — Antonim besar = kecil.

**B1-2** · Level 1 · PG

Nama hewan yang diawali huruf K adalah...

- A. sapi
- B. kucing  ✅
- C. bebek
- D. ayam

> **Kunci:** kucing — K-ucing.

**B2-1** · Level 2 · PG

Sinonim kata "gembira" adalah...

- A. takut
- B. marah
- C. sedih
- D. senang  ✅

> **Kunci:** senang — Gembira = senang.

**B2-2** · Level 2 · PG

Penulisan kata ulang yang benar adalah...

- A. anakanak
- B. anak2
- C. anak anak
- D. anak-anak  ✅

> **Kunci:** anak-anak — Kata ulang ditulis dengan tanda hubung.

**B3-1** · Level 3 · PG

Kata dasar dari "pembelajaran" adalah...

- A. belajar
- B. ajar  ✅
- C. pembelajar
- D. pelajar

> **Kunci:** ajar — pe(m)- + bel- + ajar + -an → kata dasarnya ajar.

**B3-2** · Level 3 · PG

Peribahasa "bagai air di daun talas" artinya...

- A. hidup rukun
- B. cepat marah
- C. tidak tetap pendirian  ✅
- D. sangat rajin

> **Kunci:** tidak tetap pendirian — Air di daun talas mudah bergulir ke mana saja.

**B4-1** · Level 4 · PG

Kata baku yang benar adalah...

- A. apotek  ✅
- B. apoteik
- C. apotiek
- D. apotik

> **Kunci:** apotek — Menurut KBBI, bentuk bakunya apotek.

**B4-2** · Level 4 · TEKS

Susun ulang huruf D-U-R-A-G-A menjadi nama seekor burung.

> **Kunci:** garuda — G-A-R-U-D-A.

**B5-1** · Level 5 · PG

Kalimat yang efektif adalah...

- A. Para siswa-siswa sedang belajar.
- B. Siswa-siswa para sedang belajar.
- C. Para siswa-siswa sedang belajar-belajar.
- D. Para siswa sedang belajar.  ✅

> **Kunci:** Para siswa sedang belajar. — "Para" sudah bermakna jamak, jadi kata siswa tidak perlu diulang.

**B5-2** · Level 5 · PG

"Angin berbisik di telingaku." Kalimat ini memakai majas...

- A. litotes
- B. hiperbola
- C. personifikasi  ✅
- D. metafora

> **Kunci:** personifikasi — Angin diberi sifat manusia (berbisik).

**B6-1** · Level 6 · PG

Kalimat yang penulisan "di"-nya benar SELURUHNYA adalah...

- A. Buku itu di letakkan di atas meja.
- B. Buku itu di letakkan diatas meja.
- C. Buku itu diletakkan diatas meja.
- D. Buku itu diletakkan di atas meja.  ✅

> **Kunci:** Buku itu diletakkan di atas meja. — di- sebagai awalan kata kerja ditulis serangkai (diletakkan); di sebagai kata depan tempat ditulis terpisah (di atas).

**B6-2** · Level 6 · PG

Pada kalimat "Adik tertidur di kursi", awalan ter- bermakna...

- A. paling
- B. sudah selesai
- C. dapat di-
- D. tidak sengaja  ✅

> **Kunci:** tidak sengaja — Adik tidak berniat tidur; ia tidur tanpa sengaja.

**B7-1** · Level 7 · PG

Peribahasa yang maknanya paling dekat dengan "tong kosong nyaring bunyinya" adalah...

- A. air beriak tanda tak dalam  ✅
- B. bagai pinang dibelah dua
- C. sambil menyelam minum air
- D. ada gula ada semut

> **Kunci:** air beriak tanda tak dalam — Keduanya menggambarkan orang yang sedikit ilmunya tetapi banyak bicara.

**B7-2** · Level 7 · PG

Kalimat manakah yang AMBIGU (bermakna ganda)?

- A. Adik membaca buku cerita.
- B. Istri pejabat yang baru itu cantik.  ✅
- C. Ibu memasak nasi di dapur.
- D. Ayah berangkat ke kantor naik bus.

> **Kunci:** Istri pejabat yang baru itu cantik. — "Yang baru" bisa menerangkan istri atau pejabat.

**B8-1** · Level 8 · PG

Kalimat yang penggunaan huruf kapitalnya benar adalah...

- A. Kami berlibur ke danau Toba pada Hari Minggu.
- B. kami berlibur ke danau Toba pada Hari minggu.
- C. Kami berlibur ke Danau Toba pada hari Minggu.  ✅
- D. Kami Berlibur ke Danau toba pada hari minggu.

> **Kunci:** Kami berlibur ke Danau Toba pada hari Minggu. — Nama geografi (Danau Toba) dan nama hari (Minggu) berhuruf kapital, sedangkan kata "hari" tidak.

**B8-2** · Level 8 · PG

Kelompok kata serapan yang penulisannya baku SEMUA adalah...

- A. kualitas, frekuensi, sistem, analisis  ✅
- B. kwalitas, frekuensi, sistim, analisis
- C. kualitas, frekwensi, sistem, analisa
- D. kwalitas, frekwensi, sistim, analisa

> **Kunci:** kualitas, frekuensi, sistem, analisis — Bentuk baku KBBI: kualitas, frekuensi, sistem, analisis.


## Kolom C — Linguistik — Bahasa Inggris

**C1-1** · Level 1 · PG

Bahasa Inggris dari "kucing" adalah...

- A. cat  ✅
- B. cow
- C. dog
- D. bird

> **Kunci:** cat — Kucing = cat.

**C1-2** · Level 1 · PG

What color is the sky on a clear day?

- A. red
- B. blue  ✅
- C. black
- D. green

> **Kunci:** blue — Langit cerah berwarna biru = blue.

**C2-1** · Level 2 · PG

The plural of "child" is...

- A. childrens
- B. childes
- C. children  ✅
- D. childs

> **Kunci:** children — Bentuk jamak tak beraturan: child → children.

**C2-2** · Level 2 · PG

The opposite of "hot" is...

- A. wet
- B. warm
- C. cold  ✅
- D. big

> **Kunci:** cold — Hot (panas) >< cold (dingin).

**C3-1** · Level 3 · PG

She ___ to school every day.

- A. gone
- B. going
- C. goes  ✅
- D. go

> **Kunci:** goes — Subjek she + kebiasaan → goes.

**C3-2** · Level 3 · PG

Which word is a fruit?

- A. chair
- B. mango  ✅
- C. pencil
- D. river

> **Kunci:** mango — Mango = mangga.

**C4-1** · Level 4 · PG

The past tense of "eat" is...

- A. eats
- B. eaten
- C. eated
- D. ate  ✅

> **Kunci:** ate — Kata kerja tak beraturan: eat – ate – eaten.

**C4-2** · Level 4 · PG

Which spelling is correct?

- A. beautiful  ✅
- B. beutiful
- C. beautifull
- D. beatiful

> **Kunci:** beautiful — B-E-A-U-T-I-F-U-L.

**C5-1** · Level 5 · TEKS

Unscramble the letters R-E-H-T-A-W-E into a word about rain, sun, and wind.

> **Kunci:** weather — W-E-A-T-H-E-R (cuaca).

**C5-2** · Level 5 · PG

I have lived here ___ 2020.

- A. since  ✅
- B. at
- C. from
- D. for

> **Kunci:** since — Titik awal waktu memakai since.

**C6-1** · Level 6 · PG

A synonym of "enormous" is...

- A. tiny
- B. quick
- C. huge  ✅
- D. quiet

> **Kunci:** huge — Enormous = sangat besar = huge.

**C6-2** · Level 6 · PG

If it rains tomorrow, we ___ at home.

- A. stayed
- B. will stay  ✅
- C. staying
- D. stays

> **Kunci:** will stay — First conditional: If + present simple, will + verb.

**C7-1** · Level 7 · PG

When I arrived at the station, the train ___. I had to wait for the next one.

- A. was leave
- B. has left
- C. had left  ✅
- D. leaves

> **Kunci:** had left — Kejadian yang lebih dulu terjadi di masa lampau memakai past perfect (had + V3).

**C7-2** · Level 7 · PG

"Let's play a game to break the ice." The idiom "break the ice" means...

- A. to make people feel relaxed at the start  ✅
- B. to win easily
- C. to destroy something cold
- D. to stop a game

> **Kunci:** to make people feel relaxed at the start — Break the ice = mencairkan suasana.

**C8-1** · Level 8 · PG

Neither the students nor the teacher ___ ready for the trip.

- A. is  ✅
- B. be
- C. were
- D. are

> **Kunci:** is — Pada neither...nor, kata kerja mengikuti subjek terdekat (the teacher, tunggal) → is.

**C8-2** · Level 8 · TEKS

Find ONE word that can be put in front of "room", "time", and "side" to make three new English words.

> **Kunci:** bed — bedroom, bedtime, bedside.


## Kolom D — Pengetahuan Umum

**D1-1** · Level 1 · PG

Lambang negara Indonesia adalah...

- A. Garuda Pancasila  ✅
- B. Komodo
- C. Bendera Merah Putih
- D. Monas

> **Kunci:** Garuda Pancasila — Lambang negara: Garuda Pancasila.

**D1-2** · Level 1 · PG

Hewan berikut yang berkembang biak dengan bertelur adalah...

- A. sapi
- B. ayam  ✅
- C. kucing
- D. kambing

> **Kunci:** ayam — Ayam bertelur; yang lain melahirkan.

**D2-1** · Level 2 · PG

Planet tempat kita tinggal adalah...

- A. Venus
- B. Bulan
- C. Bumi  ✅
- D. Mars

> **Kunci:** Bumi — Bulan adalah satelit, bukan planet.

**D2-2** · Level 2 · PG

Sila pertama Pancasila adalah...

- A. Persatuan Indonesia
- B. Keadilan Sosial bagi Seluruh Rakyat Indonesia
- C. Ketuhanan Yang Maha Esa  ✅
- D. Kemanusiaan yang Adil dan Beradab

> **Kunci:** Ketuhanan Yang Maha Esa — Sila ke-1.

**D3-1** · Level 3 · PG

Proses tumbuhan membuat makanannya sendiri disebut...

- A. metamorfosis
- B. respirasi
- C. fotosintesis  ✅
- D. evaporasi

> **Kunci:** fotosintesis — Foto = cahaya, sintesis = menyusun.

**D3-2** · Level 3 · PG

Candi Borobudur terletak di provinsi...

- A. DI Yogyakarta
- B. Jawa Tengah  ✅
- C. Bali
- D. Jawa Timur

> **Kunci:** Jawa Tengah — Borobudur berada di Kabupaten Magelang, Jawa Tengah.

**D4-1** · Level 4 · PG

Planet terbesar di tata surya adalah...

- A. Neptunus
- B. Bumi
- C. Saturnus
- D. Jupiter  ✅

> **Kunci:** Jupiter — Jupiter adalah planet terbesar.

**D4-2** · Level 4 · PG

Proklamasi kemerdekaan Indonesia dibacakan pada tanggal...

- A. 1 Juni 1945
- B. 17 Agustus 1945  ✅
- C. 28 Oktober 1928
- D. 20 Mei 1908

> **Kunci:** 17 Agustus 1945 — Dibacakan Soekarno–Hatta pada 17 Agustus 1945.

**D5-1** · Level 5 · PG

Mata uang negara Jepang adalah...

- A. yuan
- B. yen  ✅
- C. won
- D. ringgit

> **Kunci:** yen — Won (Korea Selatan), yuan (Tiongkok), ringgit (Malaysia).

**D5-2** · Level 5 · ANGKA

Pada tekanan udara normal, air mendidih pada suhu berapa derajat Celsius?

> **Kunci:** 100 °C — Titik didih air = 100 °C.

**D6-1** · Level 6 · PG

Gas yang diambil tumbuhan dari udara untuk fotosintesis adalah...

- A. nitrogen
- B. karbon dioksida  ✅
- C. hidrogen
- D. oksigen

> **Kunci:** karbon dioksida — Tumbuhan menyerap CO₂ dan melepas O₂.

**D6-2** · Level 6 · PG

Pencipta lagu kebangsaan "Indonesia Raya" adalah...

- A. Ismail Marzuki
- B. C. Simanjuntak
- C. Ibu Sud
- D. W.R. Supratman  ✅

> **Kunci:** W.R. Supratman — Wage Rudolf Supratman.

**D7-1** · Level 7 · PG

Lapisan atmosfer paling bawah, tempat terjadinya cuaca, adalah...

- A. termosfer
- B. troposfer  ✅
- C. stratosfer
- D. mesosfer

> **Kunci:** troposfer — Troposfer paling dekat dengan permukaan Bumi.

**D7-2** · Level 7 · PG

Bagian sel tumbuhan yang menjadi tempat berlangsungnya fotosintesis adalah...

- A. kloroplas  ✅
- B. dinding sel
- C. mitokondria
- D. inti sel

> **Kunci:** kloroplas — Kloroplas mengandung klorofil yang menangkap cahaya.

**D8-1** · Level 8 · PG

Jika kamu ditimbang di Bulan, berat badanmu kira-kira menjadi... dibanding di Bumi.

- A. sama saja
- B. 1/6 kalinya  ✅
- C. 2 kalinya
- D. nol

> **Kunci:** 1/6 kalinya — Gravitasi Bulan sekitar seperenam gravitasi Bumi. Massamu tetap, beratmu berkurang.

**D8-2** · Level 8 · PG

Kerajaan Hindu yang dianggap tertua di Indonesia adalah...

- A. Sriwijaya
- B. Kutai  ✅
- C. Tarumanegara
- D. Majapahit

> **Kunci:** Kutai — Kerajaan Kutai di Kalimantan Timur, dibuktikan dengan prasasti Yupa.


## Kolom E — Aritmetika — hitung

**E1-1** · Level 1 · ANGKA

7 + 8 = ...

> **Kunci:** 15 — 7 + 8 = 15.

**E1-2** · Level 1 · ANGKA

20 − 9 = ...

> **Kunci:** 11 — 20 − 9 = 11.

**E2-1** · Level 2 · ANGKA

6 × 7 = ...

> **Kunci:** 42 — 6 × 7 = 42.

**E2-2** · Level 2 · ANGKA

56 : 8 = ...

> **Kunci:** 7 — 8 × 7 = 56.

**E3-1** · Level 3 · ANGKA

125 + 378 = ...

> **Kunci:** 503 — 125 + 378 = 503.

**E3-2** · Level 3 · ANGKA

Ani punya 24 permen yang dibagi rata kepada 4 teman. Setiap teman mendapat berapa permen?

> **Kunci:** 6 — 24 : 4 = 6.

**E4-1** · Level 4 · ANGKA

15 × 12 = ...

> **Kunci:** 180 — 15 × 12 = 150 + 30 = 180.

**E4-2** · Level 4 · ANGKA

1.000 − 357 = ...

> **Kunci:** 643 — 1.000 − 357 = 643.

**E5-1** · Level 5 · ANGKA

8 + 4 × 5 − 6 = ...

> **Kunci:** 22 — Kali dulu: 4 × 5 = 20. Lalu 8 + 20 − 6 = 22.

**E5-2** · Level 5 · ANGKA

3/4 dari 120 adalah...

> **Kunci:** 90 — 120 : 4 × 3 = 90.

**E6-1** · Level 6 · ANGKA

(48 : 6) × (13 − 4) = ...

> **Kunci:** 72 — 8 × 9 = 72.

**E6-2** · Level 6 · ANGKA

Harga 1 pensil Rp2.500. Budi membeli 6 pensil dan membayar Rp20.000. Berapa rupiah kembaliannya?

> **Kunci:** 5000 rupiah — 6 × 2.500 = 15.000; 20.000 − 15.000 = 5.000.

**E7-1** · Level 7 · ANGKA

Rata-rata 5 bilangan adalah 12. Jika bilangan 20 dihapus, berapa rata-rata 4 bilangan sisanya?

> **Kunci:** 10 — Jumlah = 5 × 12 = 60. 60 − 20 = 40. 40 : 4 = 10.

**E7-2** · Level 7 · ANGKA

Andi dapat mengecat pagar sendirian dalam 6 jam, Budi dalam 3 jam. Jika mereka mengecat bersama, berapa jam pagar selesai?

> **Kunci:** 2 jam — Per jam: Andi 1/6, Budi 1/3 = 2/6. Bersama 3/6 = 1/2 pagar per jam → 2 jam.

**E8-1** · Level 8 · ANGKA

Hitung: 1 − 2 + 3 − 4 + 5 − 6 + ... + 99 − 100

> **Kunci:** -50 — Pasangkan (1−2) + (3−4) + ... + (99−100) = 50 pasang × (−1) = −50.

**E8-2** · Level 8 · ANGKA

Sebuah mobil pergi dari kota A ke kota B dengan kecepatan 60 km/jam dan pulang lewat jalan yang sama dengan kecepatan 40 km/jam. Berapa km/jam kecepatan rata-rata untuk seluruh perjalanan?

> **Kunci:** 48 km/jam — BUKAN 50! Misal jarak 120 km: pergi 2 jam, pulang 3 jam. Total 240 km : 5 jam = 48 km/jam.


## Kolom F — Spasial

**F1-1** · Level 1 · PG

Bangun datar yang memiliki 3 sisi adalah...

- A. lingkaran
- B. persegi
- C. segitiga  ✅
- D. persegi panjang

> **Kunci:** segitiga — Tri = tiga.

**F1-2** · Level 1 · PG

Benda yang bentuknya paling mirip bola adalah...

- A. jeruk  ✅
- B. pintu
- C. penggaris
- D. buku

> **Kunci:** jeruk — Jeruk berbentuk bulat seperti bola.

**F2-1** · Level 2 · ANGKA

Persegi memiliki berapa titik sudut?

> **Kunci:** 4 — Persegi punya 4 titik sudut.

**F2-2** · Level 2 · ANGKA

Selembar kertas dilipat dua, lalu dilubangi satu kali menembus kedua lapisan. Saat dibuka, ada berapa lubang?

> **Kunci:** 2 — 2 lapisan → 2 lubang.

**F3-1** · Level 3 · PG

Huruf kecil "b" dicerminkan kiri-kanan akan tampak seperti huruf...

- A. q
- B. d  ✅
- C. p
- D. b

> **Kunci:** d — Pencerminan kiri-kanan membalik arah perut huruf.

**F3-2** · Level 3 · ANGKA

Kubus memiliki berapa sisi (permukaan)?

> **Kunci:** 6 — Atas, bawah, depan, belakang, kiri, kanan.

**F4-1** · Level 4 · ANGKA

Pada dadu, jumlah dua angka yang saling berseberangan selalu 7. Angka berapa yang berseberangan dengan 2?

> **Kunci:** 5 — 7 − 2 = 5.

**F4-2** · Level 4 · PG

Kamu menghadap utara, lalu berbelok ke kanan 90°. Sekarang kamu menghadap...

- A. barat
- B. utara
- C. selatan
- D. timur  ✅

> **Kunci:** timur — Searah jarum jam dari utara adalah timur.

**F5-1** · Level 5 · PG

Kamu menghadap barat, lalu berbalik arah (putar 180°), kemudian berbelok ke kiri 90°. Sekarang kamu menghadap...

- A. barat
- B. selatan
- C. utara  ✅
- D. timur

> **Kunci:** utara — Barat → berbalik → timur → belok kiri → utara.

**F5-2** · Level 5 · ANGKA

Selembar kertas dilipat dua, lalu dilipat dua lagi, kemudian dilubangi satu kali. Saat dibuka, ada berapa lubang?

> **Kunci:** 4 — Dua kali lipat = 4 lapisan → 4 lubang.

**F6-1** · Level 6 · PG

Jam dinding yang menunjukkan pukul 03.00 dilihat lewat cermin. Jam itu tampak seperti pukul...

- A. 06.00
- B. 09.00  ✅
- C. 03.00
- D. 12.00

> **Kunci:** 09.00 — Cermin menukar kiri-kanan: jarum di angka 3 tampak di angka 9.

**F6-2** · Level 6 · ANGKA

Sebuah kubus besar 4 × 4 × 4 dibuat berongga: hanya kulit luarnya yang tersusun dari kubus kecil, bagian dalamnya kosong. Berapa kubus kecil yang dibutuhkan?

> **Kunci:** 56 — Kubus penuh 64. Bagian dalam yang kosong 2 × 2 × 2 = 8. 64 − 8 = 56.

**F7-1** · Level 7 · ANGKA

Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 03.30?

> **Kunci:** 75 ° — Jarum menit di 180°. Jarum jam bergerak 30° per jam: 90° + 15° = 105°. Selisih 75°.

**F7-2** · Level 7 · ANGKA

Kertas persegi dilipat dua, lalu dilipat dua lagi menjadi persegi kecil. Pojok yang merupakan TITIK TENGAH kertas semula digunting sedikit. Saat dibuka, ada berapa lubang?

> **Kunci:** 1 — Keempat lapisan bertemu di satu titik (pusat kertas), sehingga potongan membentuk SATU lubang belah ketupat di tengah.

**F8-1** · Level 8 · ANGKA

Kubus 4 × 4 × 4 dicat seluruh permukaan luarnya, lalu dipotong menjadi 64 kubus kecil. Berapa kubus kecil yang terkena cat TEPAT pada 1 sisi?

> **Kunci:** 24 — Pada setiap sisi, kubus yang bukan di tepi: (4 − 2)² = 4. Ada 6 sisi → 24.

**F8-2** · Level 8 · ANGKA

Ada berapa jaring-jaring kubus yang berbeda (tidak dihitung lagi jika hanya hasil putaran atau cerminan)?

> **Kunci:** 11 — Terdapat tepat 11 jaring-jaring kubus.


## Kolom G — Musikal

**G1-1** · Level 1 · PG

Angklung dimainkan dengan cara...

- A. digoyangkan  ✅
- B. digesek
- C. ditiup
- D. dipetik

> **Kunci:** digoyangkan — Tabung bambu angklung berbunyi saat digoyang.

**G1-2** · Level 1 · PG  🔊 audio: C4 C5

Dengarkan dua nada. Nada mana yang lebih TINGGI?

- A. Nada pertama
- B. Nada kedua  ✅
- C. Sama tinggi

> **Kunci:** Nada kedua — Nada kedua satu oktaf lebih tinggi.

**G2-1** · Level 2 · PG

Alat musik sasando berasal dari provinsi...

- A. Sulawesi Utara
- B. Nusa Tenggara Timur  ✅
- C. Bali
- D. Papua

> **Kunci:** Nusa Tenggara Timur — Sasando berasal dari Pulau Rote, NTT.

**G2-2** · Level 2 · PG

Urutan solmisasi: do, re, mi, fa, sol, ... Setelah sol adalah...

- A. si
- B. la  ✅
- C. fa
- D. do

> **Kunci:** la — do – re – mi – fa – sol – la – si – do.

**G3-1** · Level 3 · ANGKA

Dalam birama 4/4, not penuh bernilai berapa ketuk?

> **Kunci:** 4 ketuk — Not penuh = 4 ketuk.

**G3-2** · Level 3 · PG

Lagu daerah "Ampar-Ampar Pisang" berasal dari...

- A. Maluku
- B. Jawa Barat
- C. Sumatra Utara
- D. Kalimantan Selatan  ✅

> **Kunci:** Kalimantan Selatan — Lagu daerah Banjar, Kalimantan Selatan.

**G4-1** · Level 4 · PG

Tanda dinamika "f" (forte) berarti dimainkan dengan...

- A. cepat
- B. keras  ✅
- C. lembut
- D. lambat

> **Kunci:** keras — Forte = keras, piano = lembut.

**G4-2** · Level 4 · PG  🔊 audio: E4 A4 C4

Dengarkan tiga nada. Nada ke berapa yang paling TINGGI?

- A. Nada ke-1
- B. Nada ke-2  ✅
- C. Nada ke-3

> **Kunci:** Nada ke-2 — Urutan: E4, A4, C4. A4 paling tinggi.

**G5-1** · Level 5 · PG

Lagu daerah "Yamko Rambe Yamko" berasal dari...

- A. Aceh
- B. Bali
- C. Papua  ✅
- D. Riau

> **Kunci:** Papua — Lagu daerah Papua.

**G5-2** · Level 5 · PG  🔊 audio: G4 B4 D5 G4

Dengarkan empat nada. Nada mana yang SAMA dengan nada pertama?

- A. Nada ke-2
- B. Nada ke-3
- C. Nada ke-4  ✅
- D. Tidak ada

> **Kunci:** Nada ke-4 — Urutan: G4, B4, D5, G4.

**G6-1** · Level 6 · PG

Tanda tempo "allegro" berarti...

- A. sangat lambat
- B. berhenti
- C. sedang
- D. cepat  ✅

> **Kunci:** cepat — Allegro = cepat dan riang.

**G6-2** · Level 6 · ANGKA

Dalam birama 4/4, satu birama sudah berisi 1 not setengah dan 1 not seperempat. Butuh berapa ketuk lagi agar birama penuh?

> **Kunci:** 1 ketuk — 2 + 1 = 3 ketuk; 4 − 3 = 1.

**G7-1** · Level 7 · PG

Nada ke-5 dari tangga nada G mayor adalah...

- A. B
- B. E
- C. D  ✅
- D. C

> **Kunci:** D — G – A – B – C – D.

**G7-2** · Level 7 · PG

Akor G mayor terdiri dari nada...

- A. G – C – E
- B. G – B♭ – D
- C. G – A – B
- D. G – B – D  ✅

> **Kunci:** G – B – D — Akor mayor = nada dasar + terts besar + kuint: G, B, D. (G – B♭ – D adalah G minor.)

**G8-1** · Level 8 · ANGKA

Tangga nada D mayor memiliki berapa tanda kres (#)?

> **Kunci:** 2 — D – E – F# – G – A – B – C# – D → F# dan C#.

**G8-2** · Level 8 · ANGKA

Sebuah lagu bertempo 90 ketuk per menit dan terdiri dari 32 birama 3/4. Berapa detik lamanya lagu itu dimainkan?

> **Kunci:** 64 detik — 32 × 3 = 96 ketuk. 1 ketuk = 60/90 detik. 96 × 60/90 = 64 detik.


## Kolom H — Mystery — campuran (tersembunyi di papan)

**H1-1** · Level 1 · ANGKA · sub: logika

Ada 3 ekor ayam. Berapa jumlah semua kakinya?

> **Kunci:** 6 — 3 × 2 = 6.

**H1-2** · Level 1 · PG · sub: linguistik

Huruf vokal pada kata BUKU adalah...

- A. K
- B. BK
- C. B
- D. U  ✅

> **Kunci:** U — Vokal: a, i, u, e, o.

**H2-1** · Level 2 · PG · sub: pengetahuan_umum

Hewan yang hidup di air dan bernapas dengan insang adalah...

- A. paus
- B. lumba-lumba
- C. ikan  ✅
- D. katak dewasa

> **Kunci:** ikan — Paus dan lumba-lumba bernapas dengan paru-paru.

**H2-2** · Level 2 · ANGKA · sub: spasial

Segi enam memiliki berapa sisi?

> **Kunci:** 6 — Heksagon = 6 sisi.

**H3-1** · Level 3 · PG · sub: musikal

Gamelan paling dikenal sebagai alat musik tradisional dari...

- A. Kalimantan
- B. Papua
- C. Jawa dan Bali  ✅
- D. Sumatra Barat

> **Kunci:** Jawa dan Bali — Gamelan berkembang terutama di Jawa dan Bali.

**H3-2** · Level 3 · ANGKA · sub: numerik

Setengah dari setengah dari 40 adalah...

> **Kunci:** 10 — 40 → 20 → 10.

**H4-1** · Level 4 · PG · sub: linguistik

Hari setelah Monday adalah...

- A. Tuesday  ✅
- B. Friday
- C. Wednesday
- D. Sunday

> **Kunci:** Tuesday — Monday (Senin) → Tuesday (Selasa).

**H4-2** · Level 4 · PG · sub: logika

Jika hari ini Rabu, 10 hari lagi hari apa?

- A. Jumat
- B. Minggu
- C. Sabtu  ✅
- D. Kamis

> **Kunci:** Sabtu — 10 = 7 + 3. Rabu + 3 hari = Sabtu.

**H5-1** · Level 5 · PG · sub: pengetahuan_umum

Rumah Gadang adalah rumah adat dari...

- A. Jawa Tengah
- B. Sumatra Barat  ✅
- C. Sulawesi Selatan
- D. Papua

> **Kunci:** Sumatra Barat — Rumah adat Minangkabau, Sumatra Barat.

**H5-2** · Level 5 · ANGKA · sub: aritmetika

Persegi panjang berukuran 8 cm × 5 cm. Berapa cm kelilingnya?

> **Kunci:** 26 cm — 2 × (8 + 5) = 26.

**H6-1** · Level 6 · TEKS · sub: linguistik

Kata KASUR dibaca dari belakang menjadi kata...

> **Kunci:** rusak — R-U-S-A-K.

**H6-2** · Level 6 · ANGKA · sub: spasial

Papan berukuran 3 × 3 kotak. Ada berapa persegi jika SEMUA ukuran dihitung?

> **Kunci:** 14 — 9 (1×1) + 4 (2×2) + 1 (3×3) = 14.

**H7-1** · Level 7 · ANGKA · sub: logika

Umur Ayah 3 kali umur Budi. 10 tahun lagi, umur Ayah 2 kali umur Budi. Berapa umur Budi sekarang?

> **Kunci:** 10 tahun — 3B + 10 = 2(B + 10) → B = 10.

**H7-2** · Level 7 · ANGKA · sub: numerik_logika

Dalam sebuah turnamen, 8 tim saling bertanding tepat satu kali melawan setiap tim lain. Ada berapa pertandingan?

> **Kunci:** 28 — 7 + 6 + 5 + 4 + 3 + 2 + 1 = 28, atau 8 × 7 : 2.

**H8-1** · Level 8 · ANGKA · sub: spasial

Mulai tepat setelah pukul 12.00 siang sampai tepat pukul 12.00 malam (termasuk pukul 12.00 malam), berapa kali jarum jam dan jarum menit BERIMPIT?

> **Kunci:** 11 — Jarum menit menyusul jarum jam 11 kali dalam 12 jam (sekitar setiap 1 jam 5 menit 27 detik). Antara pukul 11 dan 1 hanya terjadi sekali, yaitu tepat pukul 12.

**H8-2** · Level 8 · ANGKA · sub: spasial

Ada berapa persegi (SEMUA ukuran) pada papan catur 8 × 8?

> **Kunci:** 204 — 1² + 2² + 3² + ... + 8² = 1 + 4 + 9 + 16 + 25 + 36 + 49 + 64 = 204.


## Kolom I — Numerik-Logika — sandi & pola

**I1-1** · Level 1 · ANGKA

Lanjutkan pola: 2, 4, 6, 8, ...

> **Kunci:** 10 — Ditambah 2.

**I1-2** · Level 1 · PG

Pola: ○ △ ○ △ ○ ... Bentuk berikutnya adalah...

- A. △  ✅
- B. □
- C. ☆
- D. ○

> **Kunci:** △ — Lingkaran dan segitiga bergantian.

**I2-1** · Level 2 · ANGKA

Lanjutkan pola: 5, 10, 15, 20, ...

> **Kunci:** 25 — Ditambah 5.

**I2-2** · Level 2 · ANGKA

Jika A = 1, B = 2, C = 3, dan seterusnya, maka E = ...

> **Kunci:** 5 — A1 B2 C3 D4 E5.

**I3-1** · Level 3 · ANGKA

Lanjutkan pola: 1, 1, 2, 3, 5, 8, ...

> **Kunci:** 13 — Setiap suku = jumlah dua suku sebelumnya: 5 + 8.

**I3-2** · Level 3 · ANGKA

Jika A = 1, B = 2, C = 3, dan seterusnya, berapa nilai kata CABE?

> **Kunci:** 11 — C3 + A1 + B2 + E5 = 11.

**I4-1** · Level 4 · ANGKA

Lanjutkan pola: 100, 90, 81, 73, ...

> **Kunci:** 66 — Dikurangi 10, 9, 8, lalu 7.

**I4-2** · Level 4 · TEKS

Setiap huruf sebuah kata digeser maju 1 (A jadi B, B jadi C, dst.) sehingga tertulis KBNV. Apa kata aslinya?

> **Kunci:** jamu — Geser mundur 1: K→J, B→A, N→M, V→U.

**I5-1** · Level 5 · ANGKA

Lanjutkan pola: 2, 6, 12, 20, 30, ...

> **Kunci:** 42 — 1×2, 2×3, 3×4, 4×5, 5×6, lalu 6×7 = 42.

**I5-2** · Level 5 · PG

Lanjutkan pola huruf: A, C, F, J, O, ...

- A. U  ✅
- B. V
- C. T
- D. S

> **Kunci:** U — Lompatan 2, 3, 4, 5, lalu 6. O (15) + 6 = U (21).

**I6-1** · Level 6 · ANGKA

Diketahui 3 ★ 4 = 15 dan 2 ★ 5 = 12. Berapa 6 ★ 3?

> **Kunci:** 24 — Aturannya a ★ b = a × b + a. 6 × 3 + 6 = 24.

**I6-2** · Level 6 · ANGKA

Pola: 1, 2, 4, 7, 11, 16, ... Berapa suku ke-10?

> **Kunci:** 46 — Selisihnya 1, 2, 3, 4, ... Suku ke-10 = 1 + (1 + 2 + ... + 9) = 1 + 45 = 46.

**I7-1** · Level 7 · TEKS

Jika A = 1, B = 2, ..., Z = 26, kata apa yang ditulis dengan sandi 16-1-19-1-18?

> **Kunci:** pasar — 16 P, 1 A, 19 S, 1 A, 18 R.

**I7-2** · Level 7 · TEKS

Dalam sebuah sandi, kata MERAH ditulis IBSFN. Dengan aturan yang SAMA, kata HIJAU ditulis...

> **Kunci:** vbkji — Aturannya dua langkah: geser setiap huruf maju 1 (MERAH → NFSBI), lalu balik urutannya (→ IBSFN). HIJAU → IJKBV → dibalik → VBKJI.

**I8-1** · Level 8 · ANGKA

Lanjutkan pola: 2, 12, 36, 80, 150, ...

> **Kunci:** 252 — Rumusnya n² × (n + 1): 1×2, 4×3, 9×4, 16×5, 25×6, lalu 36×7 = 252.

**I8-2** · Level 8 · ANGKA

Sebuah bilangan dua angka memiliki jumlah angka 9. Jika urutan angkanya dibalik, bilangan itu bertambah 27. Bilangan berapakah itu?

> **Kunci:** 36 — a + b = 9 dan selisihnya 9(b − a) = 27 → b − a = 3 → a = 3, b = 6 → 36.


## Kolom J — Logika — deduksi

**J1-1** · Level 1 · PG

Semua kucing punya ekor. Tom adalah kucing. Apakah Tom punya ekor?

- A. Tidak
- B. Ya  ✅
- C. Tidak bisa ditentukan

> **Kunci:** Ya — Tom termasuk kelompok kucing.

**J1-2** · Level 1 · PG

Rina lebih tinggi daripada Sari. Siapa yang lebih pendek?

- A. Rina
- B. Sari  ✅
- C. Sama tinggi

> **Kunci:** Sari — Kebalikan dari lebih tinggi.

**J2-1** · Level 2 · PG

Mana yang TIDAK sekelompok?

- A. mangga
- B. wortel  ✅
- C. apel
- D. jeruk

> **Kunci:** wortel — Wortel adalah sayuran; lainnya buah.

**J2-2** · Level 2 · PG

Jika kemarin hari Minggu, hari ini hari...

- A. Senin  ✅
- B. Sabtu
- C. Minggu
- D. Selasa

> **Kunci:** Senin — Minggu + 1 hari = Senin.

**J3-1** · Level 3 · PG

Andi lebih tua daripada Budi. Budi lebih tua daripada Caca. Siapa yang paling muda?

- A. Budi
- B. Caca  ✅
- C. Andi

> **Kunci:** Caca — Andi > Budi > Caca.

**J3-2** · Level 3 · ANGKA

Sebuah kotak berisi 3 bola merah dan 3 bola biru. Paling sedikit berapa bola yang harus diambil tanpa melihat agar PASTI mendapat 2 bola berwarna sama?

> **Kunci:** 3 — Paling sial: 1 merah + 1 biru. Bola ke-3 pasti sama dengan salah satunya.

**J4-1** · Level 4 · ANGKA

Lima anak antre. Dodi berada di urutan ke-2 dari depan. Dodi di urutan ke berapa dari belakang?

> **Kunci:** 4 — 5 − 2 + 1 = 4.

**J4-2** · Level 4 · PG

Ani, Bela, dan Citra masing-masing menyukai satu warna berbeda: merah, kuning, hijau. Ani tidak suka merah ataupun hijau. Bela tidak suka merah. Citra suka warna...

- A. kuning
- B. merah  ✅
- C. hijau

> **Kunci:** merah — Ani = kuning. Bela bukan merah → hijau. Citra = merah.

**J5-1** · Level 5 · PG

Semua siswa kelas 5 memakai topi. Doni tidak memakai topi. Kesimpulannya...

- A. Doni lupa topi
- B. Doni siswa kelas 5
- C. Doni bukan siswa kelas 5  ✅
- D. Tidak bisa disimpulkan

> **Kunci:** Doni bukan siswa kelas 5 — Jika Doni siswa kelas 5, ia pasti bertopi. Ternyata tidak.

**J5-2** · Level 5 · ANGKA

Seekor siput berada di dasar sumur sedalam 10 m. Setiap siang ia naik 3 m, setiap malam ia merosot 2 m. Pada hari ke berapa siput itu sampai di atas sumur?

> **Kunci:** 8 — Setelah 7 hari penuh ia berada di 7 m. Siang hari ke-8 naik 3 m → 10 m (tidak sempat merosot).

**J6-1** · Level 6 · PG

Ada 3 kotak berlabel "Apel", "Jeruk", dan "Campur". SEMUA labelnya salah. Kamu boleh mengambil 1 buah dari 1 kotak saja. Dari kotak berlabel apa kamu harus mengambil agar semua label bisa dibetulkan?

- A. Jeruk
- B. Campur  ✅
- C. Apel

> **Kunci:** Campur — Kotak "Campur" pasti berisi satu jenis saja. Buah yang keluar menunjukkan isinya, lalu dua label lain dapat ditentukan.

**J6-2** · Level 6 · ANGKA

Di sebuah kelas, 15 anak suka sepak bola, 12 anak suka renang, dan 5 anak suka keduanya. Setiap anak suka minimal salah satu. Ada berapa anak di kelas itu?

> **Kunci:** 22 — 15 + 12 − 5 = 22.

**J7-1** · Level 7 · ANGKA

Di laci gelap ada 10 kaus kaki hitam dan 10 putih. Paling sedikit berapa kaus kaki yang harus diambil agar PASTI mendapat sepasang yang berwarna HITAM?

> **Kunci:** 12 — Paling sial: 10 putih terambil dulu, lalu 2 hitam.

**J7-2** · Level 7 · PG

Di sebuah pulau, orang jujur selalu berkata benar dan pembohong selalu berbohong. A berkata: "B pembohong." B berkata: "C pembohong." C berkata: "A dan B sama-sama pembohong." Siapa saja yang jujur?

- A. Hanya B  ✅
- B. Hanya A
- C. A dan C
- D. Hanya C

> **Kunci:** Hanya B — Jika C jujur, A dan B pembohong; tetapi A pembohong berarti B jujur (bertentangan). Jadi C pembohong → ucapan B benar → B jujur → ucapan A salah → A pembohong.

**J8-1** · Level 8 · ANGKA

Ada 12 koin yang tampak sama; tepat satu koin palsu yang beratnya berbeda (bisa lebih berat ATAU lebih ringan, tidak diketahui). Dengan timbangan dua lengan tanpa anak timbangan, paling sedikit berapa kali menimbang agar PASTI menemukan koin palsu dan tahu apakah ia lebih berat atau lebih ringan?

> **Kunci:** 3 — Ada 24 kemungkinan (12 koin × berat/ringan). Setiap penimbangan punya 3 hasil, sehingga 2 kali hanya membedakan 9 kemungkinan; 3 kali bisa 27 ≥ 24, dan strategi 4-4-4 terbukti berhasil.

**J8-2** · Level 8 · ANGKA

Ada 100 loker tertutup bernomor 1–100 dan 100 murid. Murid ke-1 membuka semua loker. Murid ke-2 membalik (buka↔tutup) setiap loker kelipatan 2. Murid ke-3 membalik setiap loker kelipatan 3, dan seterusnya sampai murid ke-100. Berapa loker yang terbuka di akhir?

> **Kunci:** 10 — Loker dibalik sebanyak banyaknya faktor nomornya. Hanya bilangan kuadrat yang punya faktor ganjil: 1, 4, 9, ..., 100 → 10 loker.


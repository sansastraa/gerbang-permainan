# CLAIM 80 — Conquer the Grid of Minds
### Spesifikasi Rancang Bangun (Game Design + Technical Spec)

> Dokumen ini adalah sumber kebenaran untuk membangun aplikasi. `CLAUDE.md` merangkum urutan kerjanya.
> Semua angka permainan ada di `config/game.config.json`; semua soal ada di `data/bank_soal.json`.

---

## 1. Ringkasan

**CLAIM 80** adalah game rebutan kartu untuk satu kelas (default 25 murid, mengikuti jumlah yang hadir). Papan berisi **80 kartu** dalam grid **kolom A–J × baris 1–8**. Setiap kolom mewakili satu jenis kecerdasan, sedangkan setiap baris mewakili tingkat kesulitan (1 = sangat mudah setara kelas 1 SD, 8 = EXTREME setara olimpiade nasional SD/SMP awal). Murid berlomba **mengklaim** kartu sebanyak mungkin dengan menjawab soalnya dengan benar, lalu mempertahankan kartu dari upaya **rebut** oleh murid lain.

| Kolom | Kategori | Kolom | Kategori |
|---|---|---|---|
| A | Numerik (bilangan, nilai tempat, FPB/KPK) | F | Spasial |
| B | Linguistik — Bahasa Indonesia | G | Musikal (termasuk soal audio) |
| C | Linguistik — Bahasa Inggris | **H** | **Mystery** — kategori campuran, disembunyikan di papan, poin ×1,5 |
| D | Pengetahuan Umum | **I** | **Numerik-Logika** — sandi & pola |
| E | Aritmetika | J | Logika — deduksi |


### Tangga kesulitan (baris)
| Baris | Tingkat | Setara | Waktu | Poin dasar |
|---|---|---|---|---|
| 1 | Sangat Mudah | kelas 1–2 SD | 30 dtk | 10 |
| 2 | Mudah | kelas 2–3 SD | 30 dtk | 15 |
| 3 | Sedang | kelas 3–4 SD | 45 dtk | 25 |
| 4 | Menengah | kelas 4–5 SD | 60 dtk | 35 |
| 5 | Sulit | kelas 5–6 SD | 60 dtk | 50 |
| 6 | Sangat Sulit | kelas 6 / seleksi olimpiade sekolah | 90 dtk | 70 |
| 7 | Expert | olimpiade SD / SMP kelas 7 | 120 dtk | 100 |
| 8 | **EXTREME** | olimpiade nasional SD / SMP awal | 180 dtk | 150 |

> Kolom H dan I tidak disebut di brief awal. Keduanya diisi sebagai **Mystery** dan **Sandi & Pola** supaya grid tetap 80 kartu dan bobot numerik-logika seimbang. Pemetaan kolom dapat diubah di `bank_soal.json → meta.kolom`.

### Target pengalaman
- 40 menit main, ±3 kartu per murid rata-rata, tanpa ada murid yang "menganggur" atau "tidak kebagian".
- Proyektor menjadi panggung drama: kartu berubah warna, notifikasi streak, upaya rebut, kartu emas.
- Guru tidak perlu menilai manual. Semua dinilai server dan menghasilkan profil kecerdasan per murid.

---

## 2. Mode Bermain

| Mode | Kebutuhan | Cara kerja |
|---|---|---|
| **Mode Perangkat** (utama) | 1 laptop guru (server) + proyektor + HP/tablet/Chromebook murid di Wi-Fi/hotspot yang sama | Murid memilih dan menjawab kartu di perangkatnya sendiri |
| **Mode Stasiun** (kelas minim perangkat) | 1 laptop + proyektor + 2–4 tablet "Stasiun Jawab" di depan kelas | Murid antre ke stasiun, login dengan PIN, mengklaim 1 kartu, lalu kembali ke tempat duduk. Antrean tampil di proyektor |

Keduanya memakai server dan aturan yang sama; hanya tampilan klien yang berbeda (`/play` vs `/station`). Aplikasi harus **berjalan offline di LAN** tanpa internet.

---

## 3. Aturan Inti

### 3.1 Alur sesi
1. **Lobby** — Guru membuat sesi dan mengimpor/memilih daftar hadir. Murid membuka URL/QR, memilih namanya, dan memasukkan **PIN 4 digit** dari Kartu PIN (dicetak dari aplikasi). Guru menyetujui setiap join.
2. **Fase OPEN (menit 0–15)** — **semua 80 kartu langsung terbuka**. Zona Pemula aktif sampai menit 10. Rebut belum aktif.
3. **Fase BATTLE (menit 15–35)** — fitur **Rebut** aktif. VO mengumumkan pergantian fase.
4. **Fase RUSH (5 menit terakhir)** — semua poin ×1,5, musik lebih cepat, timer besar, VO hitung mundur 10 detik terakhir.
5. **END** — papan dibekukan, Upacara Penghargaan, lalu laporan.

### 3.1a Aturan Klaim Bebas Urutan
Klaim **tidak harus berurutan** dari baris 1. Kartu mana pun (A1 sampai J8) boleh dipilih kapan saja, termasuk langsung ke baris 8 di detik pertama. Strategi menjadi bagian permainan: kartu mudah lebih aman, kartu sulit bernilai jauh lebih besar (150 poin untuk baris 8 vs 10 poin untuk baris 1).
- **Terjun Bebas**: jika klaim pertama seorang murid di sesi itu langsung berada di level ≥ 6, ia mendapat +25 dan VO khusus.
- **Penakluk Puncak**: orang pertama yang mengklaim kartu baris 8 di suatu kolom mendapat +30 dan VO khusus.
- Satu-satunya pembatas adalah aturan keadilan di §3.3 (Zona Pemula dan Pajak Juara), yang justru mendorong murid kuat ke kartu sulit.

Guru dapat menjeda, melanjutkan, dan memaju/mundurkan fase secara manual.

### 3.2 Siklus satu kartu (claim)
1. Murid mengetuk kartu berstatus **OPEN** pada grid di perangkatnya.
2. Server memeriksa **kelayakan** (lihat 3.3). Jika lolos, kartu berubah menjadi **LOCKED** untuk murid itu dan proyektor menampilkan avatar murid di atas kartu dengan ikon "sedang mencoba ⏳".
3. Server mengirim **soal** (tanpa kunci) hanya ke perangkat murid itu. Opsi diacak per pengiriman.
4. Murid menjawab sebelum batas waktu server (`waktu_detik` dari bank).
   - **Benar** → kartu **CLAIMED**, berwarna sesuai warna murid; poin dihitung (3.5); streak +1.
   - **Salah / waktu habis** → kartu **COOLDOWN** selama 20 detik (tampak "retak"), lalu **OPEN** kembali dengan **varian soal berganti**. Murid mendapat cooldown pribadi 15 detik dan streak kembali ke 0. Nilai kartu naik +10% (**Jackpot**, maksimal +50%) untuk memancing murid lain mencoba.
5. Kunci jawaban yang benar **tidak ditampilkan** saat gagal (hanya "Belum tepat"), supaya tidak dapat dibocorkan ke teman. Pembahasan muncul di laporan akhir.

### 3.3 Aturan kelayakan
Murid boleh membuka kartu jika **semua** syarat berikut terpenuhi:
- Tidak sedang memegang kartu LOCKED lain (**maksimal 1 kartu aktif**).
- Tidak sedang dalam cooldown pribadi.
- **Zona Pemula**: sampai menit 10, baris 1–2 hanya boleh dibuka oleh murid yang memiliki ≤ 1 kartu.
- **Pajak Juara**: pemilik ≥ 5 kartu hanya boleh membuka baris ≥ 4; pemilik ≥ 8 kartu hanya boleh membuka baris ≥ 6. Ini mencegah satu anak memborong kartu mudah.
- Tidak sedang dibekukan guru.

Jika ditolak, klien menampilkan alasan yang ramah (misalnya "Kamu sudah jago! Coba kartu baris 4 ke bawah 💪").

### 3.4 Rebut (Steal) — mulai fase BATTLE
- Setiap murid memiliki **2 Tiket Rebut** per sesi.
- Target: kartu CLAIMED milik murid lain yang tidak berperisai dan tidak sedang imun.
- Penantang mendapat **varian yang belum dijawab pemilik** dengan waktu ×0,75.
- Proyektor menampilkan "⚔️ Rina mencoba merebut E6 dari Budi!", dan pemilik mendapat notifikasi.
- **Berhasil** → kartu berpindah ke penantang, kartu menjadi **imun 3 menit**, penantang +streak.
- **Gagal** → tiket hangus, penantang cooldown 30 detik, kartu mendapat **Perisai 3 menit**, dan pemilik mendapat +10 poin bonus "Benteng Kokoh".
- Jika kedua varian sudah terpakai, server memakai generator parametrik (kolom A, E, I — lihat 7.3) atau mengacak ulang opsi varian lama.

### 3.5 Skor
```
Skor Total = Nilai Wilayah + Poin Bonus
Nilai Wilayah = Σ nilai kartu yang SAAT INI dimiliki
nilai kartu   = poin_dasar(level) × pengali_kolom × jackpot × golden × pengali_fase × pengali_streak (dibekukan saat diklaim)
Poin Bonus    = combo + badge + bertahan dari rebut + misi
```
- Nilai kartu dikunci saat diklaim; jika kartu direbut, nilai kartu dihitung ulang untuk pemilik baru.
- Pengali streak: ≥2 → ×1,1; ≥3 → ×1,25; ≥5 → ×1,5; ≥8 → ×2 (lihat config).
- Seri dipecah dengan: level puncak tertinggi → akurasi → waktu klaim terakhir lebih awal.

---

## 4. Gamifikasi

### 4.1 Streak
| Streak | Label | Efek |
|---|---|---|
| 2 | Warming Up | ×1,1 |
| 3 | On Fire 🔥 | ×1,25 + pilih 1 power-up; avatar di proyektor diberi api |
| 5 | Unstoppable ⚡ | ×1,5 + 1 power-up; pengumuman layar penuh 2 detik |
| 8 | LEGEND 👑 | ×2; mahkota pada avatar hingga streak putus |

**Streak Saver** (power-up) mencegah satu kali reset streak.

### 4.2 Power-up (maksimal 3 disimpan)
| Power-up | Efek |
|---|---|
| 50:50 | Menghapus 2 opsi salah (hanya soal PG ≥ 4 opsi) |
| +15 Detik | Menambah waktu satu soal |
| Perisai | Melindungi satu kartu milik sendiri dari rebut selama 5 menit |
| Streak Saver | Gagal berikutnya tidak memutus streak |
| Mata Elang | Membuka kategori asli satu kartu Mystery (H) sebelum mengklaim |
| Kunci Emas | Kartu berikutnya bernilai ×2 |

### 4.3 Kartu tersembunyi
Saat sesi dibuat, server mengacak secara diam-diam:
- **4 Golden Card** (nilai ×2), terungkap dengan animasi emas saat diklaim.
- **4 Gift Card** — pengklaim mendapat 1 power-up acak.
Proyektor **tidak** menandai keduanya sebelum terklaim.

### 4.4 Combo & wilayah
- **Ahli Kolom**: memiliki 3 kartu dalam satu kolom → +30 dan badge kategori (mis. "Mozart Cilik" untuk G).
- **Pelangi Kecerdasan**: memiliki kartu dari ≥ 6 kategori berbeda → +50, badge "Polymath".
- **Wilayah**: di akhir, kelompok kartu milik sendiri yang saling bersebelahan (atas/bawah/kiri/kanan) mendapat +5 per kartu pada wilayah terbesar.

### 4.5 Badge (contoh, simpan di `config/badges.json`)
First Blood (klaim pertama sesi) · Sniper (klaim baris 8) · Comeback Kid (klaim setelah 3 kali gagal beruntun) · Pencuri Ulung (2 rebut berhasil) · Benteng (bertahan 2 kali) · Penjelajah (mencoba 8 kolom berbeda) · Pemberani (rata-rata level yang dipilih ≥ 5) · Mozart Cilik / Pujangga / Profesor / Kalkulator Manusia / Arsitek / Detektif / Sang Peramal (Ahli Kolom per kategori).

### 4.6 Misi Kelas (kooperatif)
Jika kelas berhasil mengklaim ≥ 70 dari 80 kartu sebelum waktu habis, **semua murid** mendapat badge "Kelas Juara" dan proyektor menampilkan perayaan. Progress bar misi selalu tampil. Ini menyeimbangkan kompetisi dengan rasa kebersamaan.

### 4.7 Penghargaan akhir (banyak pemenang)
Juara Umum 1–3, Raja/Ratu per kategori (akurasi tertinggi dengan minimal 2 percobaan), Rising Star (kenaikan peringkat terbesar dalam 15 menit terakhir), Paling Berani, dan Penjaga Benteng. Papan skor publik hanya menampilkan **top 10**; peringkat bawah tidak pernah ditampilkan di proyektor.

### 4.8 Progres lintas sesi
XP = total skor ÷ 10. Level murid (Pemula → Penjelajah → Ahli → Master → Grandmaster) dan koleksi badge disimpan permanen per murid sehingga murid termotivasi untuk sesi berikutnya.

---

## 5. Anti-Curang

Prinsip: **server berwenang penuh (server-authoritative), cegah lebih dulu, deteksi kemudian, dan beri sanksi dengan mendidik**. Bendera dari sistem bukan vonis, melainkan sinyal untuk dicek guru.

### 5.1 Pencegahan teknis (wajib)
1. **Kunci jawaban tidak pernah dikirim ke klien.** Payload soal hanya berisi teks, opsi, dan ID opsi acak (`optId` berupa token acak per pengiriman, bukan indeks). Penilaian dilakukan di server. Inspect Element tidak berguna.
2. **Timer di server.** Klien hanya menampilkan hitung mundur; jawaban setelah `deadline` server ditolak.
3. **Satu pengiriman, satu jawaban.** Setiap pengiriman memiliki `deliveryId` + nonce sekali pakai; replay ditolak.
4. **Opsi diacak per murid**, dan varian berganti setelah gagal. Murid yang baru gagal tidak dapat membisikkan "jawabannya B" ke temannya.
5. **Soal tidak ditampilkan di proyektor** selama kartu aktif; proyektor hanya menampilkan kategori dan level.
6. **Identitas**: daftar hadir + PIN + persetujuan guru. Satu murid = satu socket aktif; login ganda memutus yang lama dan memberi bendera. `deviceId` (UUID di localStorage) dicatat; satu perangkat dipakai untuk >1 murid → bendera (kecuali Mode Stasiun).
7. **Rate limit** event socket per murid (mis. maksimal 5 permintaan klaim per 10 detik).
8. **Antarmuka**: `user-select: none`, menu konteks dinonaktifkan pada layar soal, meminta fullscreen saat sesi mulai (tidak memblokir jika ditolak).

### 5.2 Deteksi
| Detektor | Aturan | Tindakan |
|---|---|---|
| **Fokus hilang** | `visibilitychange`/`blur` > 1,5 detik saat soal terbuka | Pelanggaran 1 = peringatan; pelanggaran 2 pada soal yang sama = otomatis gagal. Dicatat |
| **Terlalu cepat** | Level ≥ 5, benar, waktu < 1.500 ms + 150 ms × jumlah kata soal | Bendera 🟡 (tanpa penalti otomatis) |
| **Relay** | Murid X gagal di kartu K, lalu dalam 60 detik murid Y (yang tercatat duduk dekat X, jika peta kursi diisi) mengklaim K dengan sangat cepat | Bendera 🟠 |
| **Pola jawaban sama** | Dua murid memilih opsi salah yang sama pada varian yang sama ≥ 3 kali | Bendera 🟠 |
| **Multi-login / berbagi perangkat** | Lihat 5.1 no. 6 | Bendera 🔴 |

### 5.3 Log audit anti-manipulasi
Semua kejadian disimpan sebagai **event log append-only** dengan rantai hash (`hash = sha256(prevHash + JSON(event))`). Guru dapat memutar ulang sesi (replay) dan mengekspor log. Data skor yang diubah manual akan terlihat jelas.

### 5.4 Kendali guru
Bekukan/cairkan murid · batalkan klaim (kartu kembali OPEN) · kembalikan kartu ke pemilik sebelumnya · kurangi/tambah poin dengan alasan wajib · jeda seluruh game · tinjau daftar bendera dengan tombol "Abaikan" atau "Tindak".

### 5.5 Sanksi berjenjang & budaya
1. Peringatan pribadi di perangkat murid (tidak ditampilkan di proyektor).
2. Klaim terakhir dibatalkan.
3. Kehilangan 1 Tiket Rebut + −30 poin.
4. Dibekukan 3 menit (guru berbicara dengan murid).

**Kode Kehormatan** ditampilkan di layar lobby dan harus diketuk "Aku setuju" oleh murid: *"Strategi boleh licik, cara harus jujur."* Murid yang melapor sendiri kesalahan penilaian yang menguntungkannya mendapat badge **Jujur Itu Keren** (+20).

---

## 6. Statistik & Profil Kecerdasan

### 6.1 Data mentah per percobaan
`murid, sesi, sel, varian, kategori_kolom, subkategori, level, mode (claim/steal), benar, waktu_ms, power_up_dipakai, opsi_dipilih, fokus_hilang, bendera`

### 6.2 Indikator per murid
| Indikator | Rumus |
|---|---|
| Akurasi per kategori | benar ÷ percobaan |
| Skor Kecerdasan per kategori (0–100) | Σ(level soal benar) ÷ Σ(level soal dicoba) × 100, ditampilkan hanya jika percobaan ≥ 2 |
| Level Puncak per kategori | level tertinggi yang dijawab benar |
| Kecepatan | median `waktu_ms` untuk jawaban benar, dibandingkan median kelas di level yang sama |
| Indeks Keberanian | rata-rata level yang dipilih |
| Indeks Ketangguhan | peluang benar setelah gagal (bangkit kembali) |
| Eksplorasi | jumlah kategori berbeda yang dicoba |

Kategori untuk radar: Numerik (A), Linguistik (B + C), Pengetahuan Umum (D), Aritmetika (E), Spasial (F), Musikal (G), Logika (I + J). Kartu H diatribusikan ke `subkategori`-nya.

### 6.3 Laporan
- **Rapor Murid**: grafik radar 7 kategori, level puncak, badge, satu kalimat penyemangat berbasis kategori terkuat, dan satu saran latihan berbasis kategori terlemah. Dapat dicetak (A5) atau diekspor ke PDF.
- **Heatmap Kelas 10×8**: tingkat keberhasilan setiap sel. Sel dengan p < 0,2 (terlalu sulit) atau p > 0,9 di baris ≥ 5 (terlalu mudah) ditandai untuk revisi bank soal.
- **Analisis Butir**: p (kesukaran) dan daya beda D (27% atas vs 27% bawah berdasarkan skor total) per soal, beserta distribusi opsi pengecoh.
- **Tren lintas sesi** per murid dan kelas.
- **Ekspor** CSV dan JSON.

### 6.4 Catatan etis
Profil ini adalah **potret performa pada satu permainan**, bukan tes IQ atau diagnosis. Kategori diilhami teori kecerdasan majemuk, yang populer di pendidikan tetapi bukan alat ukur baku. Rapor memakai bahasa penyemangat, tidak memberi label "tidak pintar", dan data individu tidak ditampilkan di layar umum.

---

## 7. Bank Soal

### 7.1 Isi
`data/bank_soal.json` berisi **160 soal = 80 sel × 2 varian** (varian 1 utama, varian 2 cadangan untuk gagal/rebut). Teks untuk ditinjau guru tersedia di `docs/BANK_SOAL.md`.

### 7.2 Skema item
```jsonc
{
  "id": "G4-2", "sel": "G4", "kolom": "G", "level": 4, "varian": 2,
  "kategori_kolom": "musikal", "subkategori": "musikal",
  "tipe": "pg" | "angka" | "teks",
  "soal": "...", "waktu_detik": 45, "poin_dasar": 30,
  "opsi": ["..."], "jawaban": "...", "acak_opsi": true,   // pg
  "jawaban": 42, "toleransi": 0, "satuan": "cm",          // angka
  "jawaban_diterima": ["garuda"],                           // teks
  "audio": { "notes": ["E4","A4","C4"], "durasi": 0.7 },   // opsional
  "pembahasan": "..."
}
```

### 7.3 Aturan penilaian
- **pg**: bandingkan `optId` yang dipilih dengan ID opsi benar di server.
- **angka**: normalisasi input → ubah tanda minus Unicode (−) menjadi "-" → hapus spasi, "rp", "°", dan satuan → jika berpola ribuan Indonesia (`^\d{1,3}(\.\d{3})+$`) hapus titik → ganti koma dengan titik → parse → `|x − jawaban| ≤ toleransi`. Contoh: "5.000", "Rp5000", dan "5000" dianggap sama; "0,5" = 0,5.
- **teks**: huruf kecil, trim, hapus tanda baca, rapatkan spasi, lalu cocokkan dengan `jawaban_diterima`.
- **audio**: dibangkitkan klien dengan Web Audio API (oscillator sinus/segitiga + envelope). Tidak memakai file rekaman sehingga bebas hak cipta. Tombol "Putar" maksimal 3 kali; dapat diputar ulang tanpa memotong waktu.

### 7.4 Generator parametrik (anti-hafal & cadangan rebut)
Untuk kolom A, E, I, buat `server/questions/generators.ts` yang menghasilkan soal setara level dengan angka acak (seed = sesi + murid + sel). Contoh template:
- E1: `a + b`, a, b ∈ [2, 9]; E3: penjumlahan tiga angka dengan simpan; E5: operasi campuran `a + b × c − d`; E8: `(10^k − 1) × n`.
- A3/I1: barisan aritmetika/geometri dengan beda/rasio acak.
Generator dipakai bila varian statis habis atau guru mengaktifkan mode "Selalu Acak" untuk kolom tersebut.

### 7.5 Editor & impor
Halaman `/host/bank` untuk melihat, mengedit, dan menambah soal; impor CSV dengan kolom yang sama; validasi skema (zod) ketika server mulai: setiap sel harus memiliki ≥ 2 varian, opsi pg berisi jawaban, dan tipe angka bernilai numerik.

---

## 7a. Sistem Voice-Over (VO)

### 7a.1 Tujuan
Setiap kali server **memvalidasi** jawaban benar, proyektor mengumumkan dengan suara: *"{Nama} telah mengklaim kartu {X}{Y}!"* — membuat suasana seperti acara TV dan memberi pengakuan publik pada setiap murid yang berhasil.

### 7a.2 Alur
```
answer:submit → judge (server) → benar → engine.reduce → event CLAIMED
   → voDirector.enqueue({template, params, prioritas})  (server)
   → emit "vo:play" ke room projector:{id} SAJA
   → proyektor: duck musik → jingle → ucapkan teks → subtitle + sorot sel → kembalikan musik
```
- VO hanya dipicu oleh event yang sudah tersimpan di event log; tidak pernah dari klien murid.
- Target latensi: suara mulai < 1 detik setelah penilaian.

### 7a.3 Naskah
Semua kalimat ada di `config/vo_naskah.json` (klaim per tingkat level, kartu emas, hadiah, jackpot, terjun bebas, penakluk puncak, rebut berhasil/gagal, streak 3/5/8, fase, misi kelas, hitung mundur, selesai). Sel diucapkan sebagai huruf + angka kata: E6 → "E enam", J8 → "Je delapan". Server memilih varian acak yang tidak sama dengan varian terakhir agar tidak monoton.

### 7a.4 Antrean & prioritas (`server/vo/director.ts`)
- Tiga prioritas: **tinggi** (level 7–8, emas, jackpot, rebut berhasil, streak 5+, fase), **normal** (level 4–6, rebut dimulai/gagal, streak 3), **rendah** (level 1–3).
- Prioritas tinggi menyalip antrean, tetapi tidak memotong VO yang sedang berbicara.
- Jika ≥ 3 VO rendah menumpuk, gabungkan menjadi satu: *"Tiga kartu baru terklaim: A satu, Be dua, dan De tiga!"*
- VO yang menunggu lebih lama dari batas kedaluwarsa (rendah 6 detik, normal 8 detik, tinggi 15 detik) dibuang dan hanya muncul di ticker.
- Satu murid tidak disebut lebih dari 2 kali dalam 20 detik untuk event prioritas rendah (agar murid lain juga mendapat panggung).

### 7a.5 Mesin suara (urutan fallback)
1. **Rekaman Guru** — di `/host/vo`, guru dapat merekam potongan suara (frasa tetap + 80 ucapan sel + nama murid) melalui MediaRecorder. Disimpan lokal, lalu disambung saat diputar. Paling personal dan 100% offline.
2. **Web Speech API lokal** — `speechSynthesis` dengan suara `id-ID` yang `localService === true` (mis. suara Bahasa Indonesia bawaan Windows).
3. **Web Speech API online** — suara `id-ID` jaringan jika laptop terhubung internet.
4. **Teks saja** — jingle + subtitle besar jika tidak ada suara Indonesia.
Konsol guru menyediakan tombol **"Tes VO"** dan menampilkan mesin yang aktif.

### 7a.6 Nama panggilan VO
Setiap murid memiliki kolom `nama_vo` (ejaan fonetik, mis. "Kayla" → "Kei-la") yang dapat dites di konsol guru. Default = nama panggilan dari daftar hadir.

### 7a.7 Aturan etika & anti-curang VO
- **Tidak ada VO untuk jawaban salah** dan tidak pernah membacakan isi soal atau jawaban.
- Perangkat murid tidak memutar VO (mencegah gema 25 HP). Murid yang disebut melihat notifikasi "🔊 Namamu sedang diumumkan!".
- Pengaturan: Semua / Penting dan Klaim (default) / Penting Saja / Mati; volume; kecepatan; subtitle selalu aktif untuk aksesibilitas.

## 8. Tampilan (UI)

### 8.1 `/projector` — Layar Proyektor (1920×1080, tanpa interaksi)
```
┌───────────────────────────────────────────────────────────────┬──────────────────┐
│ CLAIM 80   Fase: BATTLE ⚔️   ⏱ 18:42   Misi Kelas ███████░ 52/70 │  TOP 10          │
├───────────────────────────────────────────────────────────────┤  1 🔥Rina   420   │
│     A    B    C    D    E    F    G    H?   I    J             │  2 Budi     385   │
│ 1  [▣] [▣] [ ] [▣] ...                                         │  ...             │
│ ...         grid 10×8, tiap sel: warna pemilik + avatar         │──────────────────│
│ 8  [ ] [▣] ...  (semua baris terbuka sejak awal)                │  RISING STAR ⬆   │
├───────────────────────────────────────────────────────────────┴──────────────────┤
│ SUBTITLE VO: 🔊 "Mantap! Rina berhasil menaklukkan kartu E enam!"                 │
│ TICKER: ⚔️ Rina mencoba merebut E6 dari Budi! • 🌟 Golden card G7 diklaim Sari! • │
└─────────────────────────────────────────────────────────────────────────────────┘
```
Status sel: OPEN (putih, label kategori + level), LOCKED (avatar + ⏳ berdenyut), COOLDOWN (retak abu-abu + hitung mundur), CLAIMED (warna pemilik + inisial), SHIELDED (ikon 🛡), JACKPOT (badge +%), kolom H tampil "?" sampai diklaim.
Animasi: klaim (kartu membalik), golden (kilau emas + suara), streak 5 (overlay layar penuh 2 detik), rebut (pedang bergetar), END (confetti). Semua animasi dapat dimatikan. Saat VO berbicara, sel yang disebut berkedip dan foto/avatar murid membesar sesaat (sinkron dengan subtitle). **Proyektor adalah satu-satunya perangkat yang mengeluarkan suara VO.**

### 8.2 `/play` — Perangkat Murid (mobile-first, 360px)
- Bar atas: avatar, skor, streak 🔥, tiket rebut, power-up.
- Grid 10×8 dengan ukuran sentuh minimal 32 px dan zoom/pan; sel yang tidak layak tampak redup dengan ikon alasan.
- Layar soal: kategori + level, timer cincin, teks soal besar, tombol opsi besar (atau keypad angka untuk tipe angka), tombol power-up, tombol audio untuk soal musik.
- Umpan balik: benar (getar + suara + poin terbang), salah (lembut, tanpa kunci jawaban).
- Notifikasi: "Kartumu E6 sedang direbut!"

### 8.3 `/host` — Konsol Guru/Operator
Lobby (persetujuan join, cetak Kartu PIN), kontrol fase, papan langsung dengan nama lengkap, panel bendera anti-curang, kendali murid, log kejadian, tombol "Tampilkan Pembahasan Sel X" di proyektor (setelah sesi), serta editor bank soal dan laporan.

### 8.4 `/station` — Stasiun Jawab
Layar penuh: masukkan PIN → grid → soal → kembali otomatis ke layar PIN setelah 5 detik. Antrean dan nomor stasiun tampil di proyektor.

### 8.5 `/report/:sessionId`
Rapor murid, heatmap kelas, analisis butir, ekspor.

Gaya visual: cerah dan ramah anak, setiap kolom memiliki warna dan ikon kategori (A 🔢, B 📖, C 🔤, D 🌏, E ➗, F 🧊, G 🎵, H ❓, I 🔐, J 🧩). Warna pemilik diambil dari palet 25+ warna yang dapat dibedakan, ditambah inisial agar tidak bergantung pada warna saja.

---

## 9. Arsitektur Teknis

### 9.1 Stack
- **Monorepo** npm workspaces, TypeScript di semua bagian.
- `server/`: Node 20, Express, **Socket.IO**, **better-sqlite3**, zod, pino.
- `client/`: Vite + React + TypeScript + Tailwind, Zustand untuk state, socket.io-client, Framer Motion untuk animasi.
- `shared/`: tipe, skema zod, konstanta, dan **engine game murni** (tanpa I/O) yang dipakai server.
- Pengujian: Vitest (engine & server), Playwright (smoke test UI), skrip simulasi bot.
- Server melayani build klien statis; `npm run start` mencetak URL LAN + QR code di terminal.

### 9.2 Struktur folder
```
claim80/
  CLAUDE.md
  config/game.config.json, badges.json
  data/bank_soal.json
  docs/SPEC.md, BANK_SOAL.md
  shared/src/{types.ts, schemas.ts, engine/{state.ts, eligibility.ts, scoring.ts, combos.ts, steal.ts}}
  config/vo_naskah.json
  server/src/{index.ts, socket.ts, vo/director.ts, db.ts, repo/*.ts, anticheat/*.ts, questions/{bank.ts, judge.ts, generators.ts}, stats/*.ts}
  client/src/{routes/{Projector,Play,Host,Station,Report}.tsx, components/*, audio/synth.ts, store/*.ts}
  scripts/{build_bank.py, simulate.ts, seed-demo.ts}
```

### 9.3 State machine kartu
```
OPEN ──claim(ok)──▶ LOCKED(by, deliveryId, deadline)
LOCKED ──benar──▶ CLAIMED(owner, value)
LOCKED ──salah/timeout/fokus──▶ COOLDOWN(until) ──timer──▶ OPEN (varian++ , jackpot+10%)
CLAIMED ──steal(ok)──▶ CONTESTED(challenger, deliveryId, deadline)
CONTESTED ──benar──▶ CLAIMED(owner=challenger, immuneUntil)
CONTESTED ──salah/timeout──▶ CLAIMED(owner tetap, shieldUntil)
* ──host.void──▶ OPEN        * ──host.restore──▶ CLAIMED(prevOwner)
```
Semua transisi melewati satu fungsi murni `reduce(state, action, now) → {state, events}` di `shared/engine`. Server hanya meneruskan aksi, menyimpan event, dan menyiarkan diff. Ini membuat logika mudah diuji dan replay identik.

### 9.4 Model data (SQLite)
```
students(id, name, class, pin_hash, avatar, color, xp, created_at)
sessions(id, code, config_json, bank_version, phase, started_at, ended_at, seed)
session_players(session_id, student_id, joined_at, device_id, steal_tickets, power_ups_json, frozen_until, seat)
cards(session_id, cell, state, owner_id, value, variant_next, attempts, jackpot_pct, golden, gift, shield_until, immune_until, cooldown_until)
deliveries(id, session_id, cell, student_id, question_id, mode, opt_map_json, sent_at, deadline, answered_at, answer_raw, correct, focus_lost_count)
events(seq, session_id, ts, type, actor_id, payload_json, prev_hash, hash)
flags(id, session_id, student_id, type, severity, detail_json, status, created_at)
badges_awarded(session_id, student_id, badge_id, ts)
```

### 9.5 Event Socket.IO
Klien → server: `join {sessionCode, studentId, pin, deviceId}` · `card:open {cell}` · `card:steal {cell}` · `answer:submit {deliveryId, nonce, optId|value}` · `powerup:use {type, target?}` · `focus:lost {deliveryId, ms}` · host: `host:phase`, `host:pause`, `host:freeze`, `host:void`, `host:restore`, `host:adjust`, `host:flag:resolve`.
Server → proyektor saja: `vo:play {id, teks, jingle, prioritas, sorotSel?, studentId?}` · klien proyektor → server: `vo:done {id}`.
Server → klien: `state:snapshot` (saat join/reconnect) · `board:diff` · `question:deliver {deliveryId, nonce, cell, level, kategori, soal, opsi:[{optId,text}], tipe, deadline, audio?}` · `answer:result {correct, pointsGained, streak, powerUpOffer?}` · `player:update` · `ticker:push` · `leaderboard:update` · `toast {level, text}`.
Room: `session:{id}`, `projector:{id}`, `host:{id}`, `player:{studentId}`. Projector **tidak pernah** menerima `question:deliver`.

### 9.6 Ketahanan
- Reconnect otomatis: klien mengirim ulang `join`, server membalas `state:snapshot` termasuk soal aktif (jika belum lewat deadline).
- Timer server memakai satu loop `setInterval(250 ms)` yang memeriksa deadline dan cooldown, bukan timer per kartu.
- Server restart → state dibangun ulang dari tabel `cards` atau replay `events`.
- Target beban: 40 klien + 1 proyektor + 1 host pada laptop biasa, latensi < 150 ms di LAN.

---

## 10. Kriteria Penerimaan (Definition of Done)
1. 25 bot simulasi bermain 40 menit (dipercepat) tanpa error; total kartu CLAIMED + OPEN + COOLDOWN + LOCKED = 80 setiap saat.
2. Dua murid mengetuk kartu yang sama bersamaan → tepat satu yang mendapat LOCKED.
3. Payload `question:deliver` tidak memuat kunci jawaban maupun indeks opsi asli (diuji otomatis).
4. Jawaban setelah deadline server ditolak meskipun timer klien dimanipulasi.
5. Fokus hilang 2 kali pada satu soal → otomatis gagal dan tercatat di `flags`.
6. Pajak Juara, Zona Pemula, cooldown, dan batas 1 kartu aktif lulus uji unit.
7. Skor akhir dapat direkonstruksi persis dari event log; rantai hash tervalidasi.
8. Soal audio dapat diputar di Chrome Android dan Safari iOS setelah interaksi pengguna.
9. Proyektor terbaca dari jarak 8 m (font sel ≥ 28 px pada 1080p).
10. Rapor murid dan heatmap kelas dapat diekspor (CSV + cetak/PDF).
11. Murid dapat mengklaim J8 di detik pertama sesi (tidak ada kunci baris).
12. Setiap klaim benar menghasilkan VO di proyektor < 1 detik; 10 klaim dalam 3 detik menghasilkan VO gabungan, bukan 10 VO berturut-turut; jawaban salah tidak pernah menghasilkan VO.

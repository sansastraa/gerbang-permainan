/**
 * Simulasi Definition of Done (SPEC §10): 25 bot bermain satu sesi penuh dengan jam server dipercepat.
 *   npm run sim                         # 40 menit permainan, 10x (sekitar 4 menit nyata)
 *   npm run sim -- --minutes 10 --speed 20
 * Server dijalankan di dalam proses ini (DB di memori) dengan jam yang dipercepat; bot memakai Socket.IO sungguhan.
 * Bot membaca kunci dari berkas bank karena ini alat uji, bukan klien. Keluar dengan kode 1 bila ada kriteria gagal.
 */
import { readFileSync } from "node:fs";
import type { AddressInfo } from "node:net";
import { io, type Socket } from "socket.io-client";
import { scoreOf, type GameState } from "@claim80/shared";
import type { AnswerResult, QuestionDeliver } from "@claim80/shared";
import { createApp } from "../server/src/main";

const arg = (name: string, def: number) => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? Number(process.argv[i + 1]) : def;
};
const MINUTES = arg("minutes", 40);
const SPEED = arg("speed", 10);
const N = 25;
const TOKEN = "token-simulasi";

const t0 = Date.now();
const clock = () => t0 + (Date.now() - t0) * SPEED;
/** tidur selama `gameMs` milidetik waktu permainan */
const sleep = (gameMs: number) => new Promise((r) => setTimeout(r, Math.max(1, gameMs / SPEED)));
const rnd = (a: number, b: number) => a + Math.random() * (b - a);

type Item = { sel: string; soal: string; tipe: string; jawaban?: string | number; jawaban_diterima?: string[] };
const bank = (JSON.parse(readFileSync(new URL("../data/bank_soal.json", import.meta.url), "utf8")) as { soal: Item[] })
  .soal;
const CELLS = Array.from("ABCDEFGHIJ").flatMap((c) => [1, 2, 3, 4, 5, 6, 7, 8].map((r) => `${c}${r}`));

const app = createApp({ dbPath: ":memory:", clock, tickMs: 100, hostToken: TOKEN });
await new Promise<void>((r) => app.http.listen(0, r));
const base = `http://127.0.0.1:${(app.http.address() as AddressInfo).port}`;

const roster = Array.from({ length: N }, (_, i) => ({ id: `sim-${i + 1}`, name: `Murid ${i + 1}`, absen: i + 1 }));
const created = (await (
  await fetch(`${base}/api/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": TOKEN },
    body: JSON.stringify({ className: "Simulasi", roster, autoApprove: true }),
  })
).json()) as { id: string; code: string };
const session = app.registry.get(created.id)!;

// ---- pencatat kriteria -----------------------------------------------------------------------------------------
const results = new Map<string, { ok: boolean; note: string }>();
const check = (id: string, ok: boolean, note: string) => {
  const prev = results.get(id);
  results.set(id, { ok: (prev?.ok ?? true) && ok, note: prev && !prev.ok ? prev.note : note });
};
const errors: string[] = [];
process.on("unhandledRejection", (e) => errors.push(`unhandledRejection: ${String(e)}`));

const ALLOWED_KEYS = new Set([
  "deliveryId",
  "nonce",
  "cell",
  "mode",
  "level",
  "kategori",
  "tipe",
  "soal",
  "opsi",
  "satuan",
  "audio",
  "serverNow",
  "deadline",
  "totalMs",
]);
/** Payload soal hanya boleh berisi kunci yang dikenal; kunci jawaban/indeks asli akan muncul sebagai kunci asing. */
const bocor = (q: QuestionDeliver) =>
  Object.keys(q).some((k) => !ALLOWED_KEYS.has(k)) ||
  (q.opsi ?? []).some((o) => Object.keys(o).sort().join() !== "optId,text");
let delivered = 0;
let leaked = 0;
let voToPlayers = 0;
let voToProjector = 0;
const answerStats = { correct: 0, wrong: 0 };

// ---- host + proyektor -----------------------------------------------------------------------------------------
const host = io(base, { auth: { role: "host", sessionId: created.id, hostToken: TOKEN }, transports: ["websocket"] });
await new Promise<void>((r) => host.once("state:snapshot", () => r()));
host.emit("host:game-settings", { durasiMenit: MINUTES });
await sleep(500);

const projector = io(base, { auth: { role: "projector", sessionCode: created.code }, transports: ["websocket"] });
projector.on("vo:play", () => voToProjector++);
await new Promise<void>((r) => projector.once("state:snapshot", () => r()));

// ---- bot --------------------------------------------------------------------------------------------------------
type Special = "race" | "late" | "focus" | null;
const sockets: Socket[] = [];
const raceWins: { bot: number; at: number }[] = [];
let startReal = 0;

async function bot(i: number, special: Special) {
  const id = `sim-${i + 1}`;
  const s = io(base, { auth: { role: "player", sessionCode: created.code }, transports: ["websocket"] });
  sockets.push(s);
  await new Promise<void>((r) => s.once("session:info", () => r()));
  const joined = await new Promise<{ ok: boolean }>((r) =>
    s.emit("join", { sessionCode: created.code, studentId: id, pin: session.currentPin(), deviceId: `dev-${i}` }, r),
  );
  if (!joined.ok) throw new Error(`bot ${i} gagal join`);
  s.on("vo:play", () => voToPlayers++);
  const skill = Object.fromEntries(Array.from("ABCDEFGHIJ").map((c) => [c, rnd(0.3, 0.92)]));
  let busy = false;
  let mode = special;
  let lastResult: AnswerResult | null = null;
  s.on("answer:result", (r: AnswerResult) => {
    lastResult = r;
    if (r.correct) answerStats.correct++;
    else answerStats.wrong++;
  });

  s.on("question:deliver", async (q: QuestionDeliver) => {
    delivered++;
    if (bocor(q)) leaked++;
    if (q.opsi?.some((o) => !/^[a-z0-9_-]{6,}$/i.test(o.optId) || /^\d$/.test(o.optId))) leaked++;
    if (q.cell === "J8" && mode === "race") {
      mode = null;
      // hanya pengiriman pada jendela balapan (5 detik nyata pertama) yang dihitung sebagai "pemenang"
      if (Date.now() - startReal < 5000) raceWins.push({ bot: i, at: Date.now() - startReal });
    }
    busy = true;
    const item = bank.find((b) => b.sel === q.cell && b.soal === q.soal);
    const key = item ? String(item.jawaban ?? item.jawaban_diterima?.[0] ?? "0") : null;
    const submit = (ok: boolean) => {
      if (q.tipe === "pg") {
        const pool = q.opsi ?? [];
        const right = key === null ? undefined : pool.find((o) => o.text === key);
        const pick = ok && right ? right : (pool.find((o) => o !== right) ?? pool[0]);
        s.emit("answer:submit", { deliveryId: q.deliveryId, nonce: q.nonce, optId: pick!.optId });
      } else {
        s.emit("answer:submit", { deliveryId: q.deliveryId, nonce: q.nonce, value: ok && key ? key : "0" });
      }
    };
    if (mode === "focus") {
      // SPEC §10.5: fokus hilang 2 kali pada satu soal -> otomatis gagal
      mode = null;
      lastResult = null;
      s.emit("focus:lost", { deliveryId: q.deliveryId });
      await sleep(8000);
      s.emit("focus:lost", { deliveryId: q.deliveryId });
      await sleep(30000);
      const r = lastResult as AnswerResult | null;
      check("5", !!r && !r.correct && r.pointsGained === 0, `fokus hilang 2x -> gagal (${r?.reason ?? "tanpa hasil"})`);
      busy = false;
      return;
    }
    if (mode === "late") {
      // SPEC §10.4: jawaban setelah deadline server ditolak (klien tidak berperan)
      mode = null;
      lastResult = null;
      await sleep(q.deadline - clock() + 1500);
      submit(true);
      await sleep(30000);
      const r = lastResult as AnswerResult | null;
      check(
        "4",
        !!r && !r.correct && r.pointsGained === 0,
        `jawaban benar setelah deadline ditolak (${r?.reason ?? "tanpa hasil"})`,
      );
      busy = false;
      return;
    }
    await sleep(Math.min(q.totalMs * 0.92, rnd(3000, 0.55 * q.totalMs)));
    const lvl = q.level;
    submit(Math.random() < (skill[q.cell[0]!] ?? 0.5) - (lvl - 1) * 0.05);
    await sleep(600);
    busy = false;
  });

  if (special === "race") {
    // semua bot "race" menekan J8 pada detik pertama (SPEC §10.2 dan §10.11)
    await new Promise<void>((r) => (race.push(r), void 0));
    s.emit("card:open", { cell: "J8" });
  }
  if (special === "late" || special === "focus") {
    // coba sel terbuka acak sampai satu soal benar-benar terkirim (kartu bisa direbut bot lain lebih dulu)
    await sleep(2000);
    while (mode === special && session.state.phase !== "END") {
      const open = CELLS.filter((c) => session.state.cards[c]?.status === "OPEN");
      const cell = open[Math.floor(Math.random() * open.length)];
      if (cell) s.emit("card:open", { cell });
      await sleep(4000);
    }
    while (busy) await sleep(500);
  }

  if (!special) await sleep(30000); // beri ruang bagi balapan J8 sebelum seluruh kelas ikut bermain
  while (session.state.phase !== "END") {
    await sleep(rnd(2500, 9000));
    if (busy) continue;
    const st = session.state;
    const me = st.players[id];
    if (!me || me.frozen || me.frozenUntil > clock() || me.cooldownUntil > clock()) continue;
    if ((st.phase === "BATTLE" || st.phase === "RUSH") && Math.random() < 0.4) {
      const targets = Object.values(st.cards).filter((c) => c.status === "CLAIMED" && c.owner !== id);
      const t = targets[Math.floor(Math.random() * targets.length)];
      if (t) {
        s.emit("card:steal", { cell: t.cell });
        continue;
      }
    }
    const open = CELLS.filter((c) => st.cards[c]?.status === "OPEN");
    const cell = open[Math.floor(Math.random() * open.length)];
    if (cell) s.emit("card:open", { cell });
  }
}
const race: (() => void)[] = [];

// ---- jalankan ---------------------------------------------------------------------------------------------------
const racers = [0, 1];
const tasks: Promise<void>[] = [];
tasks.push(...racers.map((i) => bot(i, "race")));
tasks.push(bot(2, "late"), bot(3, "focus"));
for (let i = 4; i < N; i++) tasks.push(bot(i, null));
while (race.length < racers.length) await new Promise((r) => setTimeout(r, 50));

host.emit("host:start");
await sleep(200);
startReal = Date.now();
const gameStart = clock();
race.forEach((r) => r());

// ---- pemantau invarian ------------------------------------------------------------------------------------------
let samples = 0;
const phases = new Set<string>();
const monitor = setInterval(() => {
  try {
    const st: GameState = session.state;
    phases.add(st.phase);
    const cards = Object.values(st.cards);
    const valid = new Set(["OPEN", "LOCKED", "CLAIMED", "COOLDOWN", "CONTESTED"]);
    const byStatus: Record<string, number> = {};
    for (const c of cards) byStatus[c.status] = (byStatus[c.status] ?? 0) + 1;
    const total = Object.values(byStatus).reduce((a, b) => a + b, 0);
    const bad =
      total !== 80 ||
      cards.some((c) => !valid.has(c.status)) ||
      cards.some((c) => c.status === "CLAIMED" && (!c.owner || !st.players[c.owner]));
    samples++;
    if (bad) check("1", false, `invarian kartu rusak pada sampel ${samples}: ${JSON.stringify(byStatus)}`);
  } catch (e) {
    errors.push(String(e));
  }
}, 250);

const t1 = Date.now();
const progress = setInterval(() => {
  const st = session.state;
  const claimed = Object.values(st.cards).filter((c) => c.status === "CLAIMED").length;
  console.log(
    `[${((clock() - gameStart) / 60000).toFixed(1)} mnt] fase ${st.phase}  kartu diklaim ${claimed}/80  benar ${answerStats.correct}  salah ${answerStats.wrong}`,
  );
}, 30_000);

await Promise.race([Promise.all(tasks), new Promise((r) => setTimeout(r, (MINUTES * 60_000) / SPEED + 120_000))]);
await sleep(3000);
clearInterval(monitor);
clearInterval(progress);

// ---- pemeriksaan akhir ------------------------------------------------------------------------------------------
check(
  "1",
  samples > 20 && errors.length === 0 && phases.has("END"),
  `${samples} sampel invarian, fase: ${[...phases].join(">")}, galat: ${errors.length}`,
);
const winners = raceWins.length;
check("2", winners === 1, `${winners} pemenang J8 dari ${racers.length} ketukan bersamaan`);
check("11", winners === 1 && raceWins[0]!.at < 5000, `J8 dikunci ${raceWins[0]?.at ?? "-"} ms setelah mulai`);
check("3", delivered > 50 && leaked === 0, `${delivered} soal dikirim, ${leaked} payload mencurigakan`);

const chain = app.store.verifyChain(created.id);
const replay = session.replayState();
const live = session.state;
const mismatch = Object.keys(live.players).filter((p) => scoreOf(live, p) !== scoreOf(replay, p));
check(
  "7",
  chain === null && mismatch.length === 0,
  `rantai hash ${chain === null ? "utuh" : `putus di ${chain}`}; selisih skor replay: ${mismatch.length}`,
);

const flags = session.flagList();
check(
  "5",
  flags.some((f) => f.type === "fokus_gagal" || f.type === "fokus_hilang"),
  `${flags.length} bendera tercatat`,
);
check("12", voToPlayers === 0 && voToProjector > 0, `VO ke proyektor ${voToProjector}x, ke murid ${voToPlayers}x`);

const exportsOk: string[] = [];
for (const path of ["report.json", "summary.json", "students.csv", "items.csv", "attempts.csv"]) {
  const r = await fetch(`${base}/api/sessions/${created.id}/${path}`, { headers: { "x-host-token": TOKEN } });
  if (r.status !== 200) exportsOk.push(`${path}:${r.status}`);
}
check(
  "10",
  exportsOk.length === 0,
  exportsOk.length ? `gagal: ${exportsOk.join(", ")}` : "report, summary, 3 CSV berhasil diunduh",
);

const lb = Object.keys(live.players)
  .map((p) => ({ n: live.players[p]!.name, s: scoreOf(live, p) }))
  .sort((a, b) => b.s - a.s)
  .slice(0, 5);
console.log("\nTop 5:", lb.map((x) => `${x.n} ${x.s}`).join(" | "));
console.log(`Waktu nyata ${((Date.now() - t1) / 1000).toFixed(0)} dtk untuk ${MINUTES} menit permainan (${SPEED}x).\n`);

const LABEL: Record<string, string> = {
  "1": "25 bot sesi penuh tanpa galat, total kartu = 80 setiap saat",
  "2": "dua ketukan bersamaan -> tepat satu LOCKED",
  "3": "payload soal bebas kunci",
  "4": "jawaban setelah deadline server ditolak",
  "5": "fokus hilang 2x -> gagal + bendera",
  "7": "skor direkonstruksi dari log, rantai hash valid",
  "10": "ekspor CSV/JSON laporan",
  "11": "J8 dapat diklaim di detik pertama",
  "12": "VO hanya ke proyektor",
};
let failed = 0;
for (const k of Object.keys(LABEL)) {
  const r = results.get(k) ?? { ok: false, note: "tidak teruji" };
  if (!r.ok) failed++;
  console.log(`${r.ok ? "LULUS" : "GAGAL"}  §10.${k.padStart(2)}  ${LABEL[k]}  — ${r.note}`);
}
console.log(
  "\nButir 6 (aturan kartu) dan 8–9 (audio perangkat nyata, keterbacaan 8 m) diuji lewat tes unit / manual, bukan simulasi.",
);

sockets.forEach((s) => s.close());
host.close();
projector.close();
app.close();
process.exit(failed ? 1 : 0);

# -*- coding: utf-8 -*-
"""Sumber bank soal CLAIM 80 -> data/bank_soal.json + docs/BANK_SOAL.md
Format item: (sel, varian, subkategori, tipe, soal, jawaban, opsi/None, pembahasan, extra)
- tipe "pg": jawaban = teks opsi benar; opsi = daftar opsi (opsi benar boleh di mana saja)
- tipe "angka": jawaban = nilai numerik; extra boleh berisi {"satuan": "..."}
- tipe "teks": jawaban = daftar jawaban yang diterima
"""
import json, random

KOLOM = {
    "A": ("numerik", "Numerik — bilangan & nilai tempat"),
    "B": ("linguistik", "Linguistik — Bahasa Indonesia"),
    "C": ("linguistik", "Linguistik — Bahasa Inggris"),
    "D": ("pengetahuan_umum", "Pengetahuan Umum"),
    "E": ("aritmetika", "Aritmetika — hitung"),
    "F": ("spasial", "Spasial"),
    "G": ("musikal", "Musikal"),
    "H": ("misteri", "Mystery — campuran (tersembunyi di papan)"),
    "I": ("numerik_logika", "Numerik-Logika — sandi & pola"),
    "J": ("logika", "Logika — deduksi"),
}
WAKTU = {1: 30, 2: 30, 3: 45, 4: 60, 5: 60, 6: 90, 7: 120, 8: 180}
POIN = {1: 10, 2: 15, 3: 25, 4: 35, 5: 50, 6: 70, 7: 100, 8: 150}
TINGKAT = {
    1: ("Sangat Mudah", "kelas 1–2 SD", "Satu langkah, dijawab hampir spontan"),
    2: ("Mudah", "kelas 2–3 SD", "Satu langkah, pengetahuan dasar"),
    3: ("Sedang", "kelas 3–4 SD", "Satu–dua langkah"),
    4: ("Menengah", "kelas 4–5 SD", "Dua langkah atau perlu ketelitian"),
    5: ("Sulit", "kelas 5–6 SD", "Beberapa langkah, ada jebakan kecil"),
    6: ("Sangat Sulit", "kelas 6 SD / seleksi olimpiade sekolah", "Butuh strategi atau konsep lanjutan"),
    7: ("Expert", "olimpiade SD / SMP kelas 7", "Multi-langkah, berpikir di luar kebiasaan"),
    8: ("EXTREME", "olimpiade nasional SD / SMP awal", "Trik, wawasan mendalam, atau pembuktian kasus"),
}

Q = [
# ---------------- A NUMERIK ----------------
("A1",1,"numerik","angka","Bilangan apa yang datang tepat setelah 99?",100,None,"99 + 1 = 100.",{}),
("A1",2,"numerik","pg","Mana yang lebih besar?","74",["47","74","Sama besar","Tidak bisa ditentukan"],"74 punya 7 puluhan, 47 hanya 4 puluhan.",{}),
("A2",1,"numerik","pg","Pada bilangan 352, angka 5 menempati nilai tempat...","puluhan",["satuan","puluhan","ratusan","ribuan"],"3 ratusan, 5 puluhan, 2 satuan.",{}),
("A2",2,"numerik","angka","Bilangan ganjil terbesar yang kurang dari 50 adalah...",49,None,"50 genap, jadi ganjil terbesar di bawahnya 49.",{}),
("A3",1,"numerik","angka","Lanjutkan pola: 3, 6, 12, 24, ...",48,None,"Setiap suku dikali 2.",{}),
("A3",2,"numerik","angka","Bulatkan 3.468 ke ribuan terdekat.",3000,None,"Angka ratusan 4 < 5, jadi dibulatkan ke bawah: 3.000.",{}),
("A4",1,"numerik","pg","Pecahan yang senilai dengan 3/4 adalah...","6/8",["3/8","6/8","4/3","6/4"],"3/4 = (3×2)/(4×2) = 6/8.",{}),
("A4",2,"numerik","angka","FPB dari 12 dan 18 adalah...",6,None,"Faktor sekutu 12 dan 18: 1, 2, 3, 6. Terbesar 6.",{}),
("A5",1,"numerik","angka","KPK dari 4, 6, dan 10 adalah...",60,None,"KPK(4,6) = 12, lalu KPK(12,10) = 60.",{}),
("A5",2,"numerik","pg","Pecahan manakah yang paling BESAR?","2/3",["3/5","2/3","5/8","7/12"],"Dalam desimal: 0,6; 0,667; 0,625; 0,583. Terbesar 2/3.",{}),
("A6",1,"numerik","angka","Berapa banyak faktor dari 36?",9,None,"1, 2, 3, 4, 6, 9, 12, 18, 36 → 9 faktor.",{}),
("A6",2,"numerik","angka","Ada berapa bilangan prima di antara 1 dan 50?",15,None,"2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47.",{}),
("A7",1,"numerik","angka","Berapa jumlah semua bilangan genap dari 2 sampai 100?",2550,None,"2 + 4 + ... + 100 = 2 × (1 + 2 + ... + 50) = 2 × 1.275 = 2.550.",{}),
("A7",2,"numerik","angka","Berapa angka satuan dari 7 pangkat 2026?",9,None,"Angka satuan pangkat 7 berulang 7, 9, 3, 1 (siklus 4). 2026 : 4 bersisa 2 → angka kedua siklus = 9.",{}),
("A8",1,"numerik","angka","Ada berapa angka 0 di ujung hasil perkalian 1 × 2 × 3 × ... × 100?",24,None,"Setiap 0 di ujung butuh pasangan 2 × 5, dan faktor 5 lebih sedikit. ⌊100/5⌋ + ⌊100/25⌋ = 20 + 4 = 24.",{}),
("A8",2,"numerik","angka","Bilangan asli terkecil yang jika dibagi 2, 3, 4, 5, atau 6 selalu bersisa 1, tetapi habis dibagi 7, adalah...",301,None,"Bilangannya berbentuk 60k + 1 (KPK 2–6 = 60). Coba k = 1, 2, ...: 61, 121, 181, 241, 301. 301 = 7 × 43.",{}),

# ---------------- B BAHASA INDONESIA ----------------
("B1",1,"linguistik","pg","Lawan kata \"besar\" adalah...","kecil",["kecil","tinggi","luas","berat"],"Antonim besar = kecil.",{}),
("B1",2,"linguistik","pg","Nama hewan yang diawali huruf K adalah...","kucing",["ayam","kucing","sapi","bebek"],"K-ucing.",{}),
("B2",1,"linguistik","pg","Sinonim kata \"gembira\" adalah...","senang",["sedih","senang","marah","takut"],"Gembira = senang.",{}),
("B2",2,"linguistik","pg","Penulisan kata ulang yang benar adalah...","anak-anak",["anak2","anak anak","anak-anak","anakanak"],"Kata ulang ditulis dengan tanda hubung.",{}),
("B3",1,"linguistik","pg","Kata dasar dari \"pembelajaran\" adalah...","ajar",["belajar","pelajar","ajar","pembelajar"],"pe(m)- + bel- + ajar + -an → kata dasarnya ajar.",{}),
("B3",2,"linguistik","pg","Peribahasa \"bagai air di daun talas\" artinya...","tidak tetap pendirian",["sangat rajin","tidak tetap pendirian","hidup rukun","cepat marah"],"Air di daun talas mudah bergulir ke mana saja.",{}),
("B4",1,"linguistik","pg","Kata baku yang benar adalah...","apotek",["apotik","apotek","apotiek","apoteik"],"Menurut KBBI, bentuk bakunya apotek.",{}),
("B4",2,"linguistik","teks","Susun ulang huruf D-U-R-A-G-A menjadi nama seekor burung.",["garuda"],None,"G-A-R-U-D-A.",{}),
("B5",1,"linguistik","pg","Kalimat yang efektif adalah...","Para siswa sedang belajar.",["Para siswa-siswa sedang belajar.","Para siswa sedang belajar.","Para siswa-siswa sedang belajar-belajar.","Siswa-siswa para sedang belajar."],"\"Para\" sudah bermakna jamak, jadi kata siswa tidak perlu diulang.",{}),
("B5",2,"linguistik","pg","\"Angin berbisik di telingaku.\" Kalimat ini memakai majas...","personifikasi",["hiperbola","personifikasi","metafora","litotes"],"Angin diberi sifat manusia (berbisik).",{}),
("B6",1,"linguistik","pg","Kalimat yang penulisan \"di\"-nya benar SELURUHNYA adalah...","Buku itu diletakkan di atas meja.",["Buku itu di letakkan diatas meja.","Buku itu diletakkan diatas meja.","Buku itu diletakkan di atas meja.","Buku itu di letakkan di atas meja."],"di- sebagai awalan kata kerja ditulis serangkai (diletakkan); di sebagai kata depan tempat ditulis terpisah (di atas).",{}),
("B6",2,"linguistik","pg","Pada kalimat \"Adik tertidur di kursi\", awalan ter- bermakna...","tidak sengaja",["paling","tidak sengaja","dapat di-","sudah selesai"],"Adik tidak berniat tidur; ia tidur tanpa sengaja.",{}),
("B7",1,"linguistik","pg","Peribahasa yang maknanya paling dekat dengan \"tong kosong nyaring bunyinya\" adalah...","air beriak tanda tak dalam",["bagai pinang dibelah dua","air beriak tanda tak dalam","ada gula ada semut","sambil menyelam minum air"],"Keduanya menggambarkan orang yang sedikit ilmunya tetapi banyak bicara.",{}),
("B7",2,"linguistik","pg","Kalimat manakah yang AMBIGU (bermakna ganda)?","Istri pejabat yang baru itu cantik.",["Ibu memasak nasi di dapur.","Istri pejabat yang baru itu cantik.","Adik membaca buku cerita.","Ayah berangkat ke kantor naik bus."],"\"Yang baru\" bisa menerangkan istri atau pejabat.",{}),
("B8",1,"linguistik","pg","Kalimat yang penggunaan huruf kapitalnya benar adalah...","Kami berlibur ke Danau Toba pada hari Minggu.",["Kami berlibur ke danau Toba pada Hari Minggu.","Kami berlibur ke Danau Toba pada hari Minggu.","Kami Berlibur ke Danau toba pada hari minggu.","kami berlibur ke danau Toba pada Hari minggu."],"Nama geografi (Danau Toba) dan nama hari (Minggu) berhuruf kapital, sedangkan kata \"hari\" tidak.",{}),
("B8",2,"linguistik","pg","Kelompok kata serapan yang penulisannya baku SEMUA adalah...","kualitas, frekuensi, sistem, analisis",["kwalitas, frekwensi, sistim, analisa","kualitas, frekuensi, sistem, analisis","kualitas, frekwensi, sistem, analisa","kwalitas, frekuensi, sistim, analisis"],"Bentuk baku KBBI: kualitas, frekuensi, sistem, analisis.",{}),

# ---------------- C BAHASA INGGRIS ----------------
("C1",1,"linguistik","pg","Bahasa Inggris dari \"kucing\" adalah...","cat",["dog","cat","cow","bird"],"Kucing = cat.",{}),
("C1",2,"linguistik","pg","What color is the sky on a clear day?","blue",["green","red","blue","black"],"Langit cerah berwarna biru = blue.",{}),
("C2",1,"linguistik","pg","The plural of \"child\" is...","children",["childs","childes","children","childrens"],"Bentuk jamak tak beraturan: child → children.",{}),
("C2",2,"linguistik","pg","The opposite of \"hot\" is...","cold",["warm","cold","big","wet"],"Hot (panas) >< cold (dingin).",{}),
("C3",1,"linguistik","pg","She ___ to school every day.","goes",["go","goes","going","gone"],"Subjek she + kebiasaan → goes.",{}),
("C3",2,"linguistik","pg","Which word is a fruit?","mango",["chair","river","mango","pencil"],"Mango = mangga.",{}),
("C4",1,"linguistik","pg","The past tense of \"eat\" is...","ate",["eated","ate","eaten","eats"],"Kata kerja tak beraturan: eat – ate – eaten.",{}),
("C4",2,"linguistik","pg","Which spelling is correct?","beautiful",["beutiful","beautifull","beautiful","beatiful"],"B-E-A-U-T-I-F-U-L.",{}),
("C5",1,"linguistik","teks","Unscramble the letters R-E-H-T-A-W-E into a word about rain, sun, and wind.",["weather"],None,"W-E-A-T-H-E-R (cuaca).",{}),
("C5",2,"linguistik","pg","I have lived here ___ 2020.","since",["for","since","at","from"],"Titik awal waktu memakai since.",{}),
("C6",1,"linguistik","pg","A synonym of \"enormous\" is...","huge",["tiny","huge","quick","quiet"],"Enormous = sangat besar = huge.",{}),
("C6",2,"linguistik","pg","If it rains tomorrow, we ___ at home.","will stay",["stayed","will stay","stays","staying"],"First conditional: If + present simple, will + verb.",{}),
("C7",1,"linguistik","pg","When I arrived at the station, the train ___. I had to wait for the next one.","had left",["has left","leaves","had left","was leave"],"Kejadian yang lebih dulu terjadi di masa lampau memakai past perfect (had + V3).",{}),
("C7",2,"linguistik","pg","\"Let's play a game to break the ice.\" The idiom \"break the ice\" means...","to make people feel relaxed at the start",["to make people feel relaxed at the start","to destroy something cold","to stop a game","to win easily"],"Break the ice = mencairkan suasana.",{}),
("C8",1,"linguistik","pg","Neither the students nor the teacher ___ ready for the trip.","is",["are","is","were","be"],"Pada neither...nor, kata kerja mengikuti subjek terdekat (the teacher, tunggal) → is.",{}),
("C8",2,"linguistik","teks","Find ONE word that can be put in front of \"room\", \"time\", and \"side\" to make three new English words.",["bed"],None,"bedroom, bedtime, bedside.",{}),

# ---------------- D PENGETAHUAN UMUM ----------------
("D1",1,"pengetahuan_umum","pg","Lambang negara Indonesia adalah...","Garuda Pancasila",["Garuda Pancasila","Bendera Merah Putih","Monas","Komodo"],"Lambang negara: Garuda Pancasila.",{}),
("D1",2,"pengetahuan_umum","pg","Hewan berikut yang berkembang biak dengan bertelur adalah...","ayam",["kucing","sapi","ayam","kambing"],"Ayam bertelur; yang lain melahirkan.",{}),
("D2",1,"pengetahuan_umum","pg","Planet tempat kita tinggal adalah...","Bumi",["Mars","Bumi","Venus","Bulan"],"Bulan adalah satelit, bukan planet.",{}),
("D2",2,"pengetahuan_umum","pg","Sila pertama Pancasila adalah...","Ketuhanan Yang Maha Esa",["Persatuan Indonesia","Ketuhanan Yang Maha Esa","Kemanusiaan yang Adil dan Beradab","Keadilan Sosial bagi Seluruh Rakyat Indonesia"],"Sila ke-1.",{}),
("D3",1,"pengetahuan_umum","pg","Proses tumbuhan membuat makanannya sendiri disebut...","fotosintesis",["respirasi","fotosintesis","evaporasi","metamorfosis"],"Foto = cahaya, sintesis = menyusun.",{}),
("D3",2,"pengetahuan_umum","pg","Candi Borobudur terletak di provinsi...","Jawa Tengah",["Jawa Timur","DI Yogyakarta","Jawa Tengah","Bali"],"Borobudur berada di Kabupaten Magelang, Jawa Tengah.",{}),
("D4",1,"pengetahuan_umum","pg","Planet terbesar di tata surya adalah...","Jupiter",["Saturnus","Jupiter","Bumi","Neptunus"],"Jupiter adalah planet terbesar.",{}),
("D4",2,"pengetahuan_umum","pg","Proklamasi kemerdekaan Indonesia dibacakan pada tanggal...","17 Agustus 1945",["17 Agustus 1945","28 Oktober 1928","1 Juni 1945","20 Mei 1908"],"Dibacakan Soekarno–Hatta pada 17 Agustus 1945.",{}),
("D5",1,"pengetahuan_umum","pg","Mata uang negara Jepang adalah...","yen",["won","yuan","yen","ringgit"],"Won (Korea Selatan), yuan (Tiongkok), ringgit (Malaysia).",{}),
("D5",2,"pengetahuan_umum","angka","Pada tekanan udara normal, air mendidih pada suhu berapa derajat Celsius?",100,None,"Titik didih air = 100 °C.",{"satuan":"°C"}),
("D6",1,"pengetahuan_umum","pg","Gas yang diambil tumbuhan dari udara untuk fotosintesis adalah...","karbon dioksida",["oksigen","nitrogen","karbon dioksida","hidrogen"],"Tumbuhan menyerap CO₂ dan melepas O₂.",{}),
("D6",2,"pengetahuan_umum","pg","Pencipta lagu kebangsaan \"Indonesia Raya\" adalah...","W.R. Supratman",["Ismail Marzuki","W.R. Supratman","C. Simanjuntak","Ibu Sud"],"Wage Rudolf Supratman.",{}),
("D7",1,"pengetahuan_umum","pg","Lapisan atmosfer paling bawah, tempat terjadinya cuaca, adalah...","troposfer",["stratosfer","troposfer","mesosfer","termosfer"],"Troposfer paling dekat dengan permukaan Bumi.",{}),
("D7",2,"pengetahuan_umum","pg","Bagian sel tumbuhan yang menjadi tempat berlangsungnya fotosintesis adalah...","kloroplas",["mitokondria","inti sel","kloroplas","dinding sel"],"Kloroplas mengandung klorofil yang menangkap cahaya.",{}),
("D8",1,"pengetahuan_umum","pg","Jika kamu ditimbang di Bulan, berat badanmu kira-kira menjadi... dibanding di Bumi.","1/6 kalinya",["sama saja","2 kalinya","1/6 kalinya","nol"],"Gravitasi Bulan sekitar seperenam gravitasi Bumi. Massamu tetap, beratmu berkurang.",{}),
("D8",2,"pengetahuan_umum","pg","Kerajaan Hindu yang dianggap tertua di Indonesia adalah...","Kutai",["Majapahit","Tarumanegara","Kutai","Sriwijaya"],"Kerajaan Kutai di Kalimantan Timur, dibuktikan dengan prasasti Yupa.",{}),

# ---------------- E ARITMETIKA ----------------
("E1",1,"aritmetika","angka","7 + 8 = ...",15,None,"7 + 8 = 15.",{}),
("E1",2,"aritmetika","angka","20 − 9 = ...",11,None,"20 − 9 = 11.",{}),
("E2",1,"aritmetika","angka","6 × 7 = ...",42,None,"6 × 7 = 42.",{}),
("E2",2,"aritmetika","angka","56 : 8 = ...",7,None,"8 × 7 = 56.",{}),
("E3",1,"aritmetika","angka","125 + 378 = ...",503,None,"125 + 378 = 503.",{}),
("E3",2,"aritmetika","angka","Ani punya 24 permen yang dibagi rata kepada 4 teman. Setiap teman mendapat berapa permen?",6,None,"24 : 4 = 6.",{}),
("E4",1,"aritmetika","angka","15 × 12 = ...",180,None,"15 × 12 = 150 + 30 = 180.",{}),
("E4",2,"aritmetika","angka","1.000 − 357 = ...",643,None,"1.000 − 357 = 643.",{}),
("E5",1,"aritmetika","angka","8 + 4 × 5 − 6 = ...",22,None,"Kali dulu: 4 × 5 = 20. Lalu 8 + 20 − 6 = 22.",{}),
("E5",2,"aritmetika","angka","3/4 dari 120 adalah...",90,None,"120 : 4 × 3 = 90.",{}),
("E6",1,"aritmetika","angka","(48 : 6) × (13 − 4) = ...",72,None,"8 × 9 = 72.",{}),
("E6",2,"aritmetika","angka","Harga 1 pensil Rp2.500. Budi membeli 6 pensil dan membayar Rp20.000. Berapa rupiah kembaliannya?",5000,None,"6 × 2.500 = 15.000; 20.000 − 15.000 = 5.000.",{"satuan":"rupiah"}),
("E7",1,"aritmetika","angka","Rata-rata 5 bilangan adalah 12. Jika bilangan 20 dihapus, berapa rata-rata 4 bilangan sisanya?",10,None,"Jumlah = 5 × 12 = 60. 60 − 20 = 40. 40 : 4 = 10.",{}),
("E7",2,"aritmetika","angka","Andi dapat mengecat pagar sendirian dalam 6 jam, Budi dalam 3 jam. Jika mereka mengecat bersama, berapa jam pagar selesai?",2,None,"Per jam: Andi 1/6, Budi 1/3 = 2/6. Bersama 3/6 = 1/2 pagar per jam → 2 jam.",{"satuan":"jam"}),
("E8",1,"aritmetika","angka","Hitung: 1 − 2 + 3 − 4 + 5 − 6 + ... + 99 − 100",-50,None,"Pasangkan (1−2) + (3−4) + ... + (99−100) = 50 pasang × (−1) = −50.",{}),
("E8",2,"aritmetika","angka","Sebuah mobil pergi dari kota A ke kota B dengan kecepatan 60 km/jam dan pulang lewat jalan yang sama dengan kecepatan 40 km/jam. Berapa km/jam kecepatan rata-rata untuk seluruh perjalanan?",48,None,"BUKAN 50! Misal jarak 120 km: pergi 2 jam, pulang 3 jam. Total 240 km : 5 jam = 48 km/jam.",{"satuan":"km/jam"}),

# ---------------- F SPASIAL ----------------
("F1",1,"spasial","pg","Bangun datar yang memiliki 3 sisi adalah...","segitiga",["persegi","lingkaran","segitiga","persegi panjang"],"Tri = tiga.",{}),
("F1",2,"spasial","pg","Benda yang bentuknya paling mirip bola adalah...","jeruk",["buku","pintu","jeruk","penggaris"],"Jeruk berbentuk bulat seperti bola.",{}),
("F2",1,"spasial","angka","Persegi memiliki berapa titik sudut?",4,None,"Persegi punya 4 titik sudut.",{}),
("F2",2,"spasial","angka","Selembar kertas dilipat dua, lalu dilubangi satu kali menembus kedua lapisan. Saat dibuka, ada berapa lubang?",2,None,"2 lapisan → 2 lubang.",{}),
("F3",1,"spasial","pg","Huruf kecil \"b\" dicerminkan kiri-kanan akan tampak seperti huruf...","d",["p","q","d","b"],"Pencerminan kiri-kanan membalik arah perut huruf.",{}),
("F3",2,"spasial","angka","Kubus memiliki berapa sisi (permukaan)?",6,None,"Atas, bawah, depan, belakang, kiri, kanan.",{}),
("F4",1,"spasial","angka","Pada dadu, jumlah dua angka yang saling berseberangan selalu 7. Angka berapa yang berseberangan dengan 2?",5,None,"7 − 2 = 5.",{}),
("F4",2,"spasial","pg","Kamu menghadap utara, lalu berbelok ke kanan 90°. Sekarang kamu menghadap...","timur",["barat","selatan","timur","utara"],"Searah jarum jam dari utara adalah timur.",{}),
("F5",1,"spasial","pg","Kamu menghadap barat, lalu berbalik arah (putar 180°), kemudian berbelok ke kiri 90°. Sekarang kamu menghadap...","utara",["selatan","utara","timur","barat"],"Barat → berbalik → timur → belok kiri → utara.",{}),
("F5",2,"spasial","angka","Selembar kertas dilipat dua, lalu dilipat dua lagi, kemudian dilubangi satu kali. Saat dibuka, ada berapa lubang?",4,None,"Dua kali lipat = 4 lapisan → 4 lubang.",{}),
("F6",1,"spasial","pg","Jam dinding yang menunjukkan pukul 03.00 dilihat lewat cermin. Jam itu tampak seperti pukul...","09.00",["03.00","06.00","09.00","12.00"],"Cermin menukar kiri-kanan: jarum di angka 3 tampak di angka 9.",{}),
("F6",2,"spasial","angka","Sebuah kubus besar 4 × 4 × 4 dibuat berongga: hanya kulit luarnya yang tersusun dari kubus kecil, bagian dalamnya kosong. Berapa kubus kecil yang dibutuhkan?",56,None,"Kubus penuh 64. Bagian dalam yang kosong 2 × 2 × 2 = 8. 64 − 8 = 56.",{}),
("F7",1,"spasial","angka","Berapa derajat sudut terkecil antara jarum jam dan jarum menit pada pukul 03.30?",75,None,"Jarum menit di 180°. Jarum jam bergerak 30° per jam: 90° + 15° = 105°. Selisih 75°.",{"satuan":"°"}),
("F7",2,"spasial","angka","Kertas persegi dilipat dua, lalu dilipat dua lagi menjadi persegi kecil. Pojok yang merupakan TITIK TENGAH kertas semula digunting sedikit. Saat dibuka, ada berapa lubang?",1,None,"Keempat lapisan bertemu di satu titik (pusat kertas), sehingga potongan membentuk SATU lubang belah ketupat di tengah.",{}),
("F8",1,"spasial","angka","Kubus 4 × 4 × 4 dicat seluruh permukaan luarnya, lalu dipotong menjadi 64 kubus kecil. Berapa kubus kecil yang terkena cat TEPAT pada 1 sisi?",24,None,"Pada setiap sisi, kubus yang bukan di tepi: (4 − 2)² = 4. Ada 6 sisi → 24.",{}),
("F8",2,"spasial","angka","Ada berapa jaring-jaring kubus yang berbeda (tidak dihitung lagi jika hanya hasil putaran atau cerminan)?",11,None,"Terdapat tepat 11 jaring-jaring kubus.",{}),

# ---------------- G MUSIKAL ----------------
("G1",1,"musikal","pg","Angklung dimainkan dengan cara...","digoyangkan",["dipetik","ditiup","digoyangkan","digesek"],"Tabung bambu angklung berbunyi saat digoyang.",{}),
("G1",2,"musikal","pg","Dengarkan dua nada. Nada mana yang lebih TINGGI?","Nada kedua",["Nada pertama","Nada kedua","Sama tinggi"],"Nada kedua satu oktaf lebih tinggi.",{"audio":{"notes":["C4","C5"],"durasi":0.7}}),
("G2",1,"musikal","pg","Alat musik sasando berasal dari provinsi...","Nusa Tenggara Timur",["Bali","Nusa Tenggara Timur","Papua","Sulawesi Utara"],"Sasando berasal dari Pulau Rote, NTT.",{}),
("G2",2,"musikal","pg","Urutan solmisasi: do, re, mi, fa, sol, ... Setelah sol adalah...","la",["si","la","fa","do"],"do – re – mi – fa – sol – la – si – do.",{}),
("G3",1,"musikal","angka","Dalam birama 4/4, not penuh bernilai berapa ketuk?",4,None,"Not penuh = 4 ketuk.",{"satuan":"ketuk"}),
("G3",2,"musikal","pg","Lagu daerah \"Ampar-Ampar Pisang\" berasal dari...","Kalimantan Selatan",["Jawa Barat","Kalimantan Selatan","Sumatra Utara","Maluku"],"Lagu daerah Banjar, Kalimantan Selatan.",{}),
("G4",1,"musikal","pg","Tanda dinamika \"f\" (forte) berarti dimainkan dengan...","keras",["lembut","keras","cepat","lambat"],"Forte = keras, piano = lembut.",{}),
("G4",2,"musikal","pg","Dengarkan tiga nada. Nada ke berapa yang paling TINGGI?","Nada ke-2",["Nada ke-1","Nada ke-2","Nada ke-3"],"Urutan: E4, A4, C4. A4 paling tinggi.",{"audio":{"notes":["E4","A4","C4"],"durasi":0.7}}),
("G5",1,"musikal","pg","Lagu daerah \"Yamko Rambe Yamko\" berasal dari...","Papua",["Papua","Aceh","Bali","Riau"],"Lagu daerah Papua.",{}),
("G5",2,"musikal","pg","Dengarkan empat nada. Nada mana yang SAMA dengan nada pertama?","Nada ke-4",["Nada ke-2","Nada ke-3","Nada ke-4","Tidak ada"],"Urutan: G4, B4, D5, G4.",{"audio":{"notes":["G4","B4","D5","G4"],"durasi":0.6}}),
("G6",1,"musikal","pg","Tanda tempo \"allegro\" berarti...","cepat",["sangat lambat","sedang","cepat","berhenti"],"Allegro = cepat dan riang.",{}),
("G6",2,"musikal","angka","Dalam birama 4/4, satu birama sudah berisi 1 not setengah dan 1 not seperempat. Butuh berapa ketuk lagi agar birama penuh?",1,None,"2 + 1 = 3 ketuk; 4 − 3 = 1.",{"satuan":"ketuk"}),
("G7",1,"musikal","pg","Nada ke-5 dari tangga nada G mayor adalah...","D",["C","D","E","B"],"G – A – B – C – D.",{}),
("G7",2,"musikal","pg","Akor G mayor terdiri dari nada...","G – B – D",["G – A – B","G – B – D","G – C – E","G – B♭ – D"],"Akor mayor = nada dasar + terts besar + kuint: G, B, D. (G – B♭ – D adalah G minor.)",{}),
("G8",1,"musikal","angka","Tangga nada D mayor memiliki berapa tanda kres (#)?",2,None,"D – E – F# – G – A – B – C# – D → F# dan C#.",{}),
("G8",2,"musikal","angka","Sebuah lagu bertempo 90 ketuk per menit dan terdiri dari 32 birama 3/4. Berapa detik lamanya lagu itu dimainkan?",64,None,"32 × 3 = 96 ketuk. 1 ketuk = 60/90 detik. 96 × 60/90 = 64 detik.",{"satuan":"detik"}),

# ---------------- H MYSTERY ----------------
("H1",1,"logika","angka","Ada 3 ekor ayam. Berapa jumlah semua kakinya?",6,None,"3 × 2 = 6.",{}),
("H1",2,"linguistik","pg","Huruf vokal pada kata BUKU adalah...","U",["B","K","U","BK"],"Vokal: a, i, u, e, o.",{}),
("H2",1,"pengetahuan_umum","pg","Hewan yang hidup di air dan bernapas dengan insang adalah...","ikan",["katak dewasa","paus","ikan","lumba-lumba"],"Paus dan lumba-lumba bernapas dengan paru-paru.",{}),
("H2",2,"spasial","angka","Segi enam memiliki berapa sisi?",6,None,"Heksagon = 6 sisi.",{}),
("H3",1,"musikal","pg","Gamelan paling dikenal sebagai alat musik tradisional dari...","Jawa dan Bali",["Jawa dan Bali","Papua","Kalimantan","Sumatra Barat"],"Gamelan berkembang terutama di Jawa dan Bali.",{}),
("H3",2,"numerik","angka","Setengah dari setengah dari 40 adalah...",10,None,"40 → 20 → 10.",{}),
("H4",1,"linguistik","pg","Hari setelah Monday adalah...","Tuesday",["Sunday","Tuesday","Wednesday","Friday"],"Monday (Senin) → Tuesday (Selasa).",{}),
("H4",2,"logika","pg","Jika hari ini Rabu, 10 hari lagi hari apa?","Sabtu",["Jumat","Sabtu","Minggu","Kamis"],"10 = 7 + 3. Rabu + 3 hari = Sabtu.",{}),
("H5",1,"pengetahuan_umum","pg","Rumah Gadang adalah rumah adat dari...","Sumatra Barat",["Sumatra Barat","Jawa Tengah","Papua","Sulawesi Selatan"],"Rumah adat Minangkabau, Sumatra Barat.",{}),
("H5",2,"aritmetika","angka","Persegi panjang berukuran 8 cm × 5 cm. Berapa cm kelilingnya?",26,None,"2 × (8 + 5) = 26.",{"satuan":"cm"}),
("H6",1,"linguistik","teks","Kata KASUR dibaca dari belakang menjadi kata...",["rusak"],None,"R-U-S-A-K.",{}),
("H6",2,"spasial","angka","Papan berukuran 3 × 3 kotak. Ada berapa persegi jika SEMUA ukuran dihitung?",14,None,"9 (1×1) + 4 (2×2) + 1 (3×3) = 14.",{}),
("H7",1,"logika","angka","Umur Ayah 3 kali umur Budi. 10 tahun lagi, umur Ayah 2 kali umur Budi. Berapa umur Budi sekarang?",10,None,"3B + 10 = 2(B + 10) → B = 10.",{"satuan":"tahun"}),
("H7",2,"numerik_logika","angka","Dalam sebuah turnamen, 8 tim saling bertanding tepat satu kali melawan setiap tim lain. Ada berapa pertandingan?",28,None,"7 + 6 + 5 + 4 + 3 + 2 + 1 = 28, atau 8 × 7 : 2.",{}),
("H8",1,"spasial","angka","Mulai tepat setelah pukul 12.00 siang sampai tepat pukul 12.00 malam (termasuk pukul 12.00 malam), berapa kali jarum jam dan jarum menit BERIMPIT?",11,None,"Jarum menit menyusul jarum jam 11 kali dalam 12 jam (sekitar setiap 1 jam 5 menit 27 detik). Antara pukul 11 dan 1 hanya terjadi sekali, yaitu tepat pukul 12.",{}),
("H8",2,"spasial","angka","Ada berapa persegi (SEMUA ukuran) pada papan catur 8 × 8?",204,None,"1² + 2² + 3² + ... + 8² = 1 + 4 + 9 + 16 + 25 + 36 + 49 + 64 = 204.",{}),

# ---------------- I SANDI & POLA ----------------
("I1",1,"numerik_logika","angka","Lanjutkan pola: 2, 4, 6, 8, ...",10,None,"Ditambah 2.",{}),
("I1",2,"numerik_logika","pg","Pola: ○ △ ○ △ ○ ... Bentuk berikutnya adalah...","△",["○","△","□","☆"],"Lingkaran dan segitiga bergantian.",{}),
("I2",1,"numerik_logika","angka","Lanjutkan pola: 5, 10, 15, 20, ...",25,None,"Ditambah 5.",{}),
("I2",2,"numerik_logika","angka","Jika A = 1, B = 2, C = 3, dan seterusnya, maka E = ...",5,None,"A1 B2 C3 D4 E5.",{}),
("I3",1,"numerik_logika","angka","Lanjutkan pola: 1, 1, 2, 3, 5, 8, ...",13,None,"Setiap suku = jumlah dua suku sebelumnya: 5 + 8.",{}),
("I3",2,"numerik_logika","angka","Jika A = 1, B = 2, C = 3, dan seterusnya, berapa nilai kata CABE?",11,None,"C3 + A1 + B2 + E5 = 11.",{}),
("I4",1,"numerik_logika","angka","Lanjutkan pola: 100, 90, 81, 73, ...",66,None,"Dikurangi 10, 9, 8, lalu 7.",{}),
("I4",2,"numerik_logika","teks","Setiap huruf sebuah kata digeser maju 1 (A jadi B, B jadi C, dst.) sehingga tertulis KBNV. Apa kata aslinya?",["jamu"],None,"Geser mundur 1: K→J, B→A, N→M, V→U.",{}),
("I5",1,"numerik_logika","angka","Lanjutkan pola: 2, 6, 12, 20, 30, ...",42,None,"1×2, 2×3, 3×4, 4×5, 5×6, lalu 6×7 = 42.",{}),
("I5",2,"numerik_logika","pg","Lanjutkan pola huruf: A, C, F, J, O, ...","U",["S","T","U","V"],"Lompatan 2, 3, 4, 5, lalu 6. O (15) + 6 = U (21).",{}),
("I6",1,"numerik_logika","angka","Diketahui 3 ★ 4 = 15 dan 2 ★ 5 = 12. Berapa 6 ★ 3?",24,None,"Aturannya a ★ b = a × b + a. 6 × 3 + 6 = 24.",{}),
("I6",2,"numerik_logika","angka","Pola: 1, 2, 4, 7, 11, 16, ... Berapa suku ke-10?",46,None,"Selisihnya 1, 2, 3, 4, ... Suku ke-10 = 1 + (1 + 2 + ... + 9) = 1 + 45 = 46.",{}),
("I7",1,"numerik_logika","teks","Jika A = 1, B = 2, ..., Z = 26, kata apa yang ditulis dengan sandi 16-1-19-1-18?",["pasar"],None,"16 P, 1 A, 19 S, 1 A, 18 R.",{}),
("I7",2,"numerik_logika","teks","Dalam sebuah sandi, kata MERAH ditulis IBSFN. Dengan aturan yang SAMA, kata HIJAU ditulis...",["vbkji"],None,"Aturannya dua langkah: geser setiap huruf maju 1 (MERAH → NFSBI), lalu balik urutannya (→ IBSFN). HIJAU → IJKBV → dibalik → VBKJI.",{}),
("I8",1,"numerik_logika","angka","Lanjutkan pola: 2, 12, 36, 80, 150, ...",252,None,"Rumusnya n² × (n + 1): 1×2, 4×3, 9×4, 16×5, 25×6, lalu 36×7 = 252.",{}),
("I8",2,"numerik_logika","angka","Sebuah bilangan dua angka memiliki jumlah angka 9. Jika urutan angkanya dibalik, bilangan itu bertambah 27. Bilangan berapakah itu?",36,None,"a + b = 9 dan selisihnya 9(b − a) = 27 → b − a = 3 → a = 3, b = 6 → 36.",{}),

# ---------------- J LOGIKA ----------------
("J1",1,"logika","pg","Semua kucing punya ekor. Tom adalah kucing. Apakah Tom punya ekor?","Ya",["Ya","Tidak","Tidak bisa ditentukan"],"Tom termasuk kelompok kucing.",{}),
("J1",2,"logika","pg","Rina lebih tinggi daripada Sari. Siapa yang lebih pendek?","Sari",["Rina","Sari","Sama tinggi"],"Kebalikan dari lebih tinggi.",{}),
("J2",1,"logika","pg","Mana yang TIDAK sekelompok?","wortel",["apel","jeruk","wortel","mangga"],"Wortel adalah sayuran; lainnya buah.",{}),
("J2",2,"logika","pg","Jika kemarin hari Minggu, hari ini hari...","Senin",["Sabtu","Senin","Selasa","Minggu"],"Minggu + 1 hari = Senin.",{}),
("J3",1,"logika","pg","Andi lebih tua daripada Budi. Budi lebih tua daripada Caca. Siapa yang paling muda?","Caca",["Andi","Budi","Caca"],"Andi > Budi > Caca.",{}),
("J3",2,"logika","angka","Sebuah kotak berisi 3 bola merah dan 3 bola biru. Paling sedikit berapa bola yang harus diambil tanpa melihat agar PASTI mendapat 2 bola berwarna sama?",3,None,"Paling sial: 1 merah + 1 biru. Bola ke-3 pasti sama dengan salah satunya.",{}),
("J4",1,"logika","angka","Lima anak antre. Dodi berada di urutan ke-2 dari depan. Dodi di urutan ke berapa dari belakang?",4,None,"5 − 2 + 1 = 4.",{}),
("J4",2,"logika","pg","Ani, Bela, dan Citra masing-masing menyukai satu warna berbeda: merah, kuning, hijau. Ani tidak suka merah ataupun hijau. Bela tidak suka merah. Citra suka warna...","merah",["merah","kuning","hijau"],"Ani = kuning. Bela bukan merah → hijau. Citra = merah.",{}),
("J5",1,"logika","pg","Semua siswa kelas 5 memakai topi. Doni tidak memakai topi. Kesimpulannya...","Doni bukan siswa kelas 5",["Doni siswa kelas 5","Doni bukan siswa kelas 5","Doni lupa topi","Tidak bisa disimpulkan"],"Jika Doni siswa kelas 5, ia pasti bertopi. Ternyata tidak.",{}),
("J5",2,"logika","angka","Seekor siput berada di dasar sumur sedalam 10 m. Setiap siang ia naik 3 m, setiap malam ia merosot 2 m. Pada hari ke berapa siput itu sampai di atas sumur?",8,None,"Setelah 7 hari penuh ia berada di 7 m. Siang hari ke-8 naik 3 m → 10 m (tidak sempat merosot).",{}),
("J6",1,"logika","pg","Ada 3 kotak berlabel \"Apel\", \"Jeruk\", dan \"Campur\". SEMUA labelnya salah. Kamu boleh mengambil 1 buah dari 1 kotak saja. Dari kotak berlabel apa kamu harus mengambil agar semua label bisa dibetulkan?","Campur",["Apel","Jeruk","Campur"],"Kotak \"Campur\" pasti berisi satu jenis saja. Buah yang keluar menunjukkan isinya, lalu dua label lain dapat ditentukan.",{}),
("J6",2,"logika","angka","Di sebuah kelas, 15 anak suka sepak bola, 12 anak suka renang, dan 5 anak suka keduanya. Setiap anak suka minimal salah satu. Ada berapa anak di kelas itu?",22,None,"15 + 12 − 5 = 22.",{}),
("J7",1,"logika","angka","Di laci gelap ada 10 kaus kaki hitam dan 10 putih. Paling sedikit berapa kaus kaki yang harus diambil agar PASTI mendapat sepasang yang berwarna HITAM?",12,None,"Paling sial: 10 putih terambil dulu, lalu 2 hitam.",{}),
("J7",2,"logika","pg","Di sebuah pulau, orang jujur selalu berkata benar dan pembohong selalu berbohong. A berkata: \"B pembohong.\" B berkata: \"C pembohong.\" C berkata: \"A dan B sama-sama pembohong.\" Siapa saja yang jujur?","Hanya B",["Hanya A","Hanya B","Hanya C","A dan C"],"Jika C jujur, A dan B pembohong; tetapi A pembohong berarti B jujur (bertentangan). Jadi C pembohong → ucapan B benar → B jujur → ucapan A salah → A pembohong.",{}),
("J8",1,"logika","angka","Ada 12 koin yang tampak sama; tepat satu koin palsu yang beratnya berbeda (bisa lebih berat ATAU lebih ringan, tidak diketahui). Dengan timbangan dua lengan tanpa anak timbangan, paling sedikit berapa kali menimbang agar PASTI menemukan koin palsu dan tahu apakah ia lebih berat atau lebih ringan?",3,None,"Ada 24 kemungkinan (12 koin × berat/ringan). Setiap penimbangan punya 3 hasil, sehingga 2 kali hanya membedakan 9 kemungkinan; 3 kali bisa 27 ≥ 24, dan strategi 4-4-4 terbukti berhasil.",{}),
("J8",2,"logika","angka","Ada 100 loker tertutup bernomor 1–100 dan 100 murid. Murid ke-1 membuka semua loker. Murid ke-2 membalik (buka↔tutup) setiap loker kelipatan 2. Murid ke-3 membalik setiap loker kelipatan 3, dan seterusnya sampai murid ke-100. Berapa loker yang terbuka di akhir?",10,None,"Loker dibalik sebanyak banyaknya faktor nomornya. Hanya bilangan kuadrat yang punya faktor ganjil: 1, 4, 9, ..., 100 → 10 loker.",{}),
]


def build():
    rnd = random.Random(80)
    items = []
    seen = set()
    for (cell, var, sub, tipe, soal, jaw, opsi, pemb, extra) in Q:
        col, lvl = cell[0], int(cell[1:])
        key = (cell, var)
        assert key not in seen, key
        seen.add(key)
        it = {
            "id": f"{cell}-{var}", "sel": cell, "kolom": col, "level": lvl, "varian": var,
            "kategori_kolom": KOLOM[col][0], "subkategori": sub, "tipe": tipe,
            "soal": soal, "waktu_detik": WAKTU[lvl], "poin_dasar": POIN[lvl],
        }
        if tipe == "pg":
            assert jaw in opsi, (cell, var)
            o = opsi[:]
            # opsi bertipe urutan (Nada ke-1, dst.) tetap urut agar tidak membingungkan
            if not any(x.startswith("Nada") for x in o):
                rnd.shuffle(o)
            it["opsi"] = o
            it["jawaban"] = jaw
            it["acak_opsi"] = not any(x.startswith("Nada") for x in o)
        elif tipe == "angka":
            it["jawaban"] = jaw
            it["toleransi"] = 0
        else:
            it["jawaban_diterima"] = jaw
        if extra.get("satuan"): it["satuan"] = extra["satuan"]
        if extra.get("audio"): it["audio"] = extra["audio"]
        it["pembahasan"] = pemb
        items.append(it)
    # validasi kelengkapan 80 sel x 2 varian
    for col in "ABCDEFGHIJ":
        for l in range(1, 9):
            for v in (1, 2):
                assert (f"{col}{l}", v) in seen, f"kurang {col}{l}-{v}"
    bank = {
        "meta": {
            "nama": "CLAIM 80 — Bank Soal Inti",
            "versi": "1.0.0",
            "jumlah_sel": 80, "varian_per_sel": 2, "jumlah_soal": len(items),
            "kolom": {k: {"kategori": v[0], "label": v[1]} for k, v in KOLOM.items()},
            "waktu_per_level": WAKTU, "poin_per_level": POIN,
            "tingkat": {k: {"label": v[0], "setara": v[1], "ciri": v[2]} for k, v in TINGKAT.items()},
            "catatan": "Klaim BEBAS urutan: kartu mana pun boleh diambil kapan saja. Varian 1 = soal utama, varian 2 = soal cadangan (dipakai setelah gagal / untuk rebut). Kunci jawaban TIDAK BOLEH dikirim ke klien."
        },
        "soal": items,
    }
    with open("data/bank_soal.json", "w", encoding="utf-8") as f:
        json.dump(bank, f, ensure_ascii=False, indent=2)

    # markdown untuk guru
    L = ["# CLAIM 80 — Bank Soal (versi baca guru)", "",
         "Dibangkitkan otomatis dari `data/bank_soal.json`. Ubah soal di JSON, bukan di sini.", "",
         "| Kolom | Kategori |", "|---|---|"]
    for k, v in KOLOM.items(): L.append(f"| {k} | {v[1]} |")
    L += ["", "| Level | Waktu | Poin dasar |", "|---|---|---|"]
    for l in range(1, 9): L.append(f"| {l} | {WAKTU[l]} detik | {POIN[l]} |")
    for col in "ABCDEFGHIJ":
        L += ["", f"## Kolom {col} — {KOLOM[col][1]}", ""]
        for it in [i for i in items if i["kolom"] == col]:
            L.append(f"**{it['id']}** · Level {it['level']} · {it['tipe'].upper()}" + (f" · sub: {it['subkategori']}" if col == "H" else "") + ("  🔊 audio: " + " ".join(it['audio']['notes']) if it.get("audio") else ""))
            L.append("")
            L.append(f"{it['soal']}")
            if it["tipe"] == "pg":
                L.append("")
                for i, o in enumerate(it["opsi"]):
                    L.append(f"- {'ABCD'[i]}. {o}{'  ✅' if o == it['jawaban'] else ''}")
                kunci = it["jawaban"]
            elif it["tipe"] == "angka":
                kunci = f"{it['jawaban']}" + (f" {it['satuan']}" if it.get("satuan") else "")
            else:
                kunci = " / ".join(it["jawaban_diterima"])
            L += ["", f"> **Kunci:** {kunci} — {it['pembahasan']}", ""]
    with open("docs/BANK_SOAL.md", "w", encoding="utf-8") as f:
        f.write("\n".join(L) + "\n")
    print("OK", len(items), "soal")

if __name__ == "__main__":
    build()

/**
 * Bot demo untuk mengisi papan (bukan simulasi DoD; itu `scripts/simulate.ts`):
 *   npx tsx scripts/demo-bots.ts KODE [jumlahBot=12] [detik=25]
 * Bot membaca kunci dari berkas bank karena ini alat uji lokal, bukan klien sungguhan.
 */
import { readFileSync } from "node:fs";
import { io } from "socket.io-client";
import type { QuestionDeliver } from "@claim80/shared";

const base = "http://localhost:3080";
const code = process.argv[2];
if (!code) throw new Error("Pakai: demo-bots.ts KODE [jumlah] [detik]");
const n = Number(process.argv[3] ?? 12);
const seconds = Number(process.argv[4] ?? 25);
type Item = { sel: string; soal: string; tipe: string; jawaban?: string | number; jawaban_diterima?: string[] };
const bank = (JSON.parse(readFileSync(new URL("../data/bank_soal.json", import.meta.url), "utf8")) as { soal: Item[] })
  .soal;
const { token } = (await (await fetch(`${base}/api/host-token`)).json()) as { token: string };
const sessions = (await (await fetch(`${base}/api/sessions`, { headers: { "x-host-token": token } })).json()) as {
  id: string;
  code: string;
}[];
const sess = sessions.find((s) => s.code === code);
if (!sess) throw new Error("Sesi tidak ditemukan");
const pins = (await (
  await fetch(`${base}/api/sessions/${sess.id}/pins`, { headers: { "x-host-token": token } })
).json()) as {
  cards: { id: string; pin: string }[];
};
const cells = Array.from("ABCDEFGHIJ").flatMap((c) => [1, 2, 3, 4, 5, 6, 7, 8].map((r) => `${c}${r}`));
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const stopAt = Date.now() + seconds * 1000;

async function bot(i: number) {
  const card = pins.cards[i]!;
  const s = io(base, { auth: { role: "player", sessionCode: code }, transports: ["websocket"] });
  await new Promise<void>((r) => s.once("session:info", () => r()));
  await new Promise<void>((r) =>
    s.emit("join", { sessionCode: code, studentId: card.id, pin: card.pin, deviceId: `bot-${i}` }, () => r()),
  );
  const skill = 0.5 + Math.random() * 0.4;
  s.on("question:deliver", async (q: QuestionDeliver) => {
    const item = bank.find((b) => b.sel === q.cell && b.soal === q.soal)!;
    await sleep(900 + Math.random() * 3500);
    const ok = Math.random() < skill - (q.level - 1) * 0.06;
    if (q.tipe === "pg") {
      const target = ok ? q.opsi!.find((o) => o.text === item.jawaban) : q.opsi!.find((o) => o.text !== item.jawaban);
      s.emit("answer:submit", { deliveryId: q.deliveryId, nonce: q.nonce, optId: target!.optId });
    } else {
      const v = ok ? String(item.jawaban ?? item.jawaban_diterima![0]) : "0";
      s.emit("answer:submit", { deliveryId: q.deliveryId, nonce: q.nonce, value: v });
    }
  });
  while (Date.now() < stopAt) {
    await sleep(1500 + Math.random() * 2500);
    s.emit("card:open", { cell: cells[Math.floor(Math.random() * cells.length)] });
  }
  s.close();
}

await Promise.all(Array.from({ length: n }, (_, i) => bot(i)));
console.log("Selesai.");
process.exit(0);

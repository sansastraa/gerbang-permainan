/**
 * Membuat sesi demo di server yang sedang berjalan (laptop yang sama):
 *   npx tsx scripts/seed-demo.ts [http://localhost:3080] [--start] [--manual]
 * Mencetak kode sesi dan PIN tiap siswa. --start langsung memulai permainan; --manual mematikan persetujuan otomatis.
 */
import { io } from "socket.io-client";

const base = process.argv.find((a) => a.startsWith("http")) ?? "http://localhost:3080";
const NAMES = [
  "Rina Putri Ayu",
  "Budi Santoso",
  "Sari Dewi",
  "Andi Saputra",
  "Kayla Maharani",
  "Dimas Pratama",
  "Nadia Safitri",
  "Fajar Nugroho",
  "Putri Amelia",
  "Rizky Ramadhan",
  "Salsa Aulia",
  "Bagas Wicaksono",
  "Intan Permata",
  "Yoga Prasetyo",
  "Citra Lestari",
  "Hendra Kurniawan",
  "Dewi Anggraini",
  "Eko Setiawan",
  "Lina Marlina",
  "Joko Susilo",
  "Maya Sari",
  "Ilham Hakim",
  "Tika Wulandari",
  "Rafi Alfarizi",
  "Zahra Nabila",
];

const { token } = (await (await fetch(`${base}/api/host-token`)).json()) as { token: string };
const roster = NAMES.map((name, i) => ({ id: `demo-${i + 1}`, name, absen: i + 1 }));
const res = await fetch(`${base}/api/sessions`, {
  method: "POST",
  headers: { "content-type": "application/json", "x-host-token": token },
  body: JSON.stringify({ className: "Demo 5A", roster, autoApprove: !process.argv.includes("--manual") }),
});
if (!res.ok) throw new Error(`Gagal membuat sesi: ${res.status} ${await res.text()}`);
const s = (await res.json()) as { id: string; code: string };
const pins = (await (
  await fetch(`${base}/api/sessions/${s.id}/pins`, { headers: { "x-host-token": token } })
).json()) as {
  cards: { id: string; name: string; pin: string }[];
};
console.log(`Kode sesi: ${s.code}   (id ${s.id})`);
console.log(`Murid: ${base}/play/${s.code}`);
for (const c of pins.cards) console.log(`  ${c.id.padEnd(8)} ${c.name.padEnd(20)} PIN ${c.pin}`);

if (process.argv.includes("--start")) {
  const sock = io(base, { auth: { role: "host", sessionId: s.id, hostToken: token }, transports: ["websocket"] });
  await new Promise<void>((r) => sock.once("state:snapshot", () => r()));
  sock.emit("host:start");
  await new Promise((r) => setTimeout(r, 300));
  sock.close();
  console.log("Permainan dimulai.");
}

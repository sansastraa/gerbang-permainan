import { spawn } from "node:child_process";

const run = (name: string, args: string[]) => {
  const p = spawn("npm", args, { stdio: "inherit", shell: true });
  p.on("exit", (c) => {
    console.log(`[${name}] selesai (${c})`);
    process.exit(c ?? 0);
  });
};
run("server", ["run", "dev", "-w", "server"]);
run("client", ["run", "dev", "-w", "client"]);

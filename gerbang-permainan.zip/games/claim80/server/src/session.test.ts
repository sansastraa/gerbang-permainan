import { describe, expect, it } from "vitest";
import { scoreOf } from "@claim80/shared";
import type { QuestionDeliver } from "@claim80/shared";
import { Store } from "./db";
import { loadBadges, loadBank, loadConfig } from "./questions/bank";
import { Registry } from "./registry";

const bank = loadBank();
// tes memainkan banyak aksi beruntun oleh murid yang sama, jadi jeda tiap 2 soal dimatikan (diuji khusus di bawah)
const config = { ...loadConfig(), jeda_soal: { setiap: 2, detik: 0 } };
const badges = loadBadges();
const roster = ["Rina Putri", "Budi Santoso", "Sari Dewi", "Andi Saputra"].map((name, i) => ({
  id: `s${i + 1}`,
  name,
  absen: i + 1,
}));

interface Sent {
  room: string;
  event: string;
  payload: unknown;
}

function make(seed = 5) {
  let now = 1_700_000_000_000;
  const sent: Sent[] = [];
  const store = new Store(":memory:");
  const reg = new Registry({
    store,
    bank,
    config,
    badges,
    clock: () => now,
    emitter: { emit: (room, event, payload) => void sent.push({ room, event, payload }) },
  });
  const s = reg.create({ className: "5A", roster, autoApprove: true, seed });
  for (const r of roster) s.join(r.id, s.pins[r.id]!, `dev-${r.id}`);
  s.host({ type: "start" });
  const deliver = (id: string) =>
    [...sent].reverse().find((m) => m.event === "question:deliver" && m.room === `player:${id}`)
      ?.payload as QuestionDeliver;
  /** Menjawab benar dengan membaca kunci langsung dari bank (hanya tes yang boleh tahu). */
  const correctFor = (q: QuestionDeliver) => {
    const item = bank.find((b) => b.sel === q.cell && b.soal === q.soal)!;
    if (item.tipe === "pg") return { optId: q.opsi!.find((o) => o.text === item.jawaban)!.optId };
    if (item.tipe === "angka") return { value: String(item.jawaban) };
    return { value: item.jawaban_diterima[0]! };
  };
  return {
    s,
    reg,
    store,
    sent,
    deliver,
    correctFor,
    advance: (ms: number) => {
      now += ms;
      s.tick();
    },
    claimAndWin(id: string, cell: string, waitMs = 0) {
      s.claim(id, cell);
      const q = deliver(id);
      now += waitMs;
      s.answer(id, { deliveryId: q.deliveryId, nonce: q.nonce, ...this.correctFor(q) });
    },
  };
}

describe("GameSession", () => {
  it("payload question:deliver tidak memuat kunci jawaban maupun indeks opsi asli", () => {
    const t = make();
    for (const cell of ["A1", "B3", "C5", "D2", "F7", "G4", "I6", "J8"]) {
      t.s.claim("s1", cell);
      const q = t.deliver("s1");
      const item = bank.find((b) => b.sel === cell && b.soal === q.soal)!;
      const json = JSON.stringify(q);
      expect(json).not.toContain("jawaban");
      expect(json).not.toContain("pembahasan");
      expect(Object.keys(q)).not.toContain("jawaban");
      if (item.tipe === "pg") {
        expect(q.opsi!.every((o) => /^[0-9a-f]{8}$/.test(o.optId))).toBe(true);
        expect(q.opsi!.map((o) => o.text).sort()).toEqual([...item.opsi].sort());
      } else {
        expect(q.opsi).toBeNull();
      }
      // kunci tidak tersiar ke room mana pun
      expect(JSON.stringify(t.sent.map((m) => m.payload))).not.toContain(`"pembahasan"`);
      t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, value: "x", optId: "zzz" });
      t.advance(60_000);
    }
  });

  it("jawaban benar → kartu jadi milik murid dengan inisial pada papan; proyektor tidak menerima soal", () => {
    const t = make();
    t.claimAndWin("s1", "E2", 3000);
    const card = t.s.publicCard("E2");
    expect(card.status).toBe("CLAIMED");
    expect(card.ownerId).toBe("s1");
    expect(card.initials).toBe("RP");
    expect(t.sent.some((m) => m.event === "question:deliver" && !m.room.startsWith("player:"))).toBe(false);
    const res = t.sent.find((m) => m.event === "answer:result" && m.room === "player:s1")!.payload as {
      correct: boolean;
    };
    expect(res.correct).toBe(true);
    expect(t.s.leaderboardTop()[0]!.id).toBe("s1");
  });

  it("siaran fx untuk proyektor memuat identitas publik tetapi tidak soal maupun jawaban", () => {
    const t = make();
    t.claimAndWin("s1", "G3", 4000);
    const fx = t.sent.filter((m) => m.event === "fx");
    expect(fx.length).toBeGreaterThan(0);
    const claimed = fx.find((m) => (m.payload as { type: string }).type === "claimed")!.payload as {
      name: string;
      initials: string;
    };
    expect(claimed.initials).toBe("RP");
    const blob = JSON.stringify(fx.map((m) => m.payload));
    expect(blob).not.toMatch(/soal|jawaban|pembahasan|optId|nonce/);
    expect(fx.every((m) => m.room === `session:${t.s.id}`)).toBe(true);
  });

  it("salah → hasil tanpa kunci; kartu langsung terbuka dengan varian lain", () => {
    const t = make();
    t.s.claim("s1", "E4");
    const q1 = t.deliver("s1");
    t.s.answer("s1", { deliveryId: q1.deliveryId, nonce: q1.nonce, value: "-999" });
    const res = t.sent.filter((m) => m.event === "answer:result").at(-1)!.payload as {
      correct: boolean;
      message: string;
    };
    expect(res.correct).toBe(false);
    expect(res.message).not.toMatch(/\d{2,}/);
    expect(t.s.publicCard("E4").status).toBe("OPEN"); // tanpa pembekuan: langsung bisa dicoba lagi
    t.advance(25_000);
    t.s.claim("s2", "E4");
    expect(t.deliver("s2").soal).not.toBe(q1.soal);
  });

  it("replay nonce/deliveryId: jawaban kedua dengan pengiriman sama ditolak", () => {
    const t = make();
    t.s.claim("s1", "A5");
    const q = t.deliver("s1");
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, ...t.correctFor(q) });
    const before = scoreOf(t.s.state, "s1");
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, ...t.correctFor(q) });
    expect(scoreOf(t.s.state, "s1")).toBe(before);
    expect(t.sent.at(-1)!.event).not.toBe("answer:result");
  });

  it("nonce salah ditolak dan tidak menghanguskan soal", () => {
    const t = make();
    t.s.claim("s1", "A5");
    const q = t.deliver("s1");
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: "palsu", ...t.correctFor(q) });
    expect(t.s.state.players.s1!.active).not.toBeNull();
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, ...t.correctFor(q) });
    expect(t.s.publicCard("A5").ownerId).toBe("s1");
  });

  it("jawaban setelah deadline server ditolak walaupun benar", () => {
    const t = make();
    t.s.claim("s1", "A1");
    const q = t.deliver("s1");
    t.advance(q.totalMs + 1000);
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, ...t.correctFor(q) });
    expect(t.s.publicCard("A1").ownerId).toBeNull();
    expect(scoreOf(t.s.state, "s1")).toBe(0);
  });

  it("timeout lewat tick mengirim hasil ke murid", () => {
    const t = make();
    t.s.claim("s2", "B2");
    t.advance(100_000);
    const r = t.sent.filter((m) => m.event === "answer:result" && m.room === "player:s2").at(-1)!.payload as {
      reason: string;
    };
    expect(r.reason).toBe("timeout");
  });

  it("dua murid mengetuk kartu yang sama: tepat satu yang menerima soal", () => {
    const t = make();
    t.s.claim("s1", "H3");
    t.s.claim("s2", "H3");
    expect(t.deliver("s1")).toBeTruthy();
    expect(t.deliver("s2")).toBeUndefined();
    expect(t.sent.some((m) => m.event === "action:rejected" && m.room === "player:s2")).toBe(true);
  });

  it("snapshot saat reconnect memuat soal aktif dengan token yang sama dan tanpa kunci", () => {
    const t = make();
    t.s.claim("s3", "C4");
    const q = t.deliver("s3");
    const snap = t.s.snapshotFor("player", "s3");
    expect(snap.question?.deliveryId).toBe(q.deliveryId);
    expect(snap.question?.opsi).toEqual(q.opsi);
    expect(JSON.stringify(snap)).not.toContain("pembahasan");
    expect(snap.me?.id).toBe("s3");
    expect(t.s.snapshotFor("projector").question).toBeUndefined();
    expect(t.s.snapshotFor("projector").roster).toBeUndefined();
    expect(t.s.snapshotFor("host").roster).toHaveLength(4);
  });

  it("50:50 menyembunyikan dua opsi salah", () => {
    const t = make();
    t.s.claim("s1", "A4"); // pg 4 opsi di salah satu varian; cari kartu pg
    t.advance(30_000);
    let cell = "";
    for (const c of ["B1", "B3", "C1", "D1", "D3", "F1", "J1"]) {
      t.s.claim("s2", c);
      const q = t.deliver("s2");
      if (q.opsi && q.opsi.length >= 4) {
        cell = c;
        break;
      }
      t.s.answer("s2", { deliveryId: q.deliveryId, nonce: q.nonce, value: "x" });
      t.advance(40_000);
    }
    expect(cell).not.toBe("");
    t.s.state.players.s2!.powerUps.push("50_50");
    t.s.usePowerUp("s2", "50_50");
    const upd = t.sent.filter((m) => m.event === "question:update").at(-1)!.payload as QuestionDeliver;
    expect(upd.opsi).toHaveLength(2);
    const item = bank.find((b) => b.sel === cell && b.soal === upd.soal)!;
    expect(upd.opsi!.map((o) => o.text)).toContain(item.tipe === "pg" ? item.jawaban : "");
  });

  it("join: PIN salah ditolak, perlu persetujuan bila autoApprove mati, login ganda memutus perangkat lama", () => {
    const store = new Store(":memory:");
    const sent: Sent[] = [];
    const reg = new Registry({
      store,
      bank,
      config,
      badges,
      emitter: { emit: (room, event, payload) => void sent.push({ room, event, payload }) },
    });
    const s = reg.create({ className: "5B", roster });
    expect(s.join("s1", "0000" === s.pins.s1 ? "1111" : "0000", "d1")).toEqual({ ok: false, error: "bad_pin" });
    expect(s.join("nope", "1234", "d1")).toEqual({ ok: false, error: "no_student" });
    expect(s.join("s1", s.pins.s1!, "d1")).toEqual({ ok: true, status: "pending" });
    expect(s.state.players.s1).toBeUndefined();
    s.approve("s1");
    expect(s.state.players.s1).toBeDefined();
    expect(s.hostRoster().find((r) => r.id === "s1")!.status).toBe("approved");
  });
});

describe("log berantai hash & replay", () => {
  it("rantai hash valid, rusak terdeteksi, dan state hasil replay identik dengan state langsung (DoD 7)", () => {
    const t = make(9);
    t.claimAndWin("s1", "E1", 2000);
    t.advance(20_000);
    t.claimAndWin("s2", "J6", 5000);
    t.s.host({ type: "host_adjust", playerId: "s3", delta: 7, reason: "hadiah jujur" });
    t.s.claim("s3", "B2");
    t.advance(100_000); // timeout
    expect(t.store.verifyChain(t.s.id)).toBeNull();
    const replayed = t.s.replayState();
    expect(JSON.stringify(replayed)).toBe(JSON.stringify(t.s.state));
    for (const r of roster) expect(scoreOf(replayed, r.id)).toBe(scoreOf(t.s.state, r.id));

    t.store.db
      .prepare(
        "UPDATE events SET payload_json = replace(payload_json, 'hadiah jujur', 'diubah') WHERE type = 'host_adjust'",
      )
      .run();
    expect(t.store.verifyChain(t.s.id)).not.toBeNull();
  });

  it("server restart: sesi dibangun ulang dari log", () => {
    const t = make(3);
    t.claimAndWin("s1", "A3", 4000);
    const reg2 = new Registry({ store: t.store, bank, config, badges, emitter: { emit: () => undefined } });
    expect(reg2.restoreAll()).toBe(1);
    const s2 = reg2.get(t.s.id)!;
    expect(scoreOf(s2.state, "s1")).toBe(scoreOf(t.s.state, "s1"));
    expect(s2.publicCard("A3").initials).toBe("RP");
  });
});

describe("anti-curang (M7)", () => {
  const flagsOf = (t: ReturnType<typeof make>, type?: string) =>
    t.store.listFlags(t.s.id).filter((f) => !type || f.type === type);
  const wrongFor = (q: QuestionDeliver) => {
    const item = bank.find((b) => b.sel === q.cell && b.soal === q.soal)!;
    const answer = item.tipe === "pg" ? item.jawaban : "";
    return [...q.opsi!].filter((o) => o.text !== answer).sort((a, b) => a.text.localeCompare(b.text))[0]!;
  };

  it("fokus hilang 2× pada satu soal: gagal otomatis dan tercatat di flags (DoD 5)", () => {
    const t = make();
    t.s.claim("s1", "A3");
    const q = t.deliver("s1");
    t.s.focusLost("s1", q.deliveryId);
    t.s.focusLost("s1", q.deliveryId);
    expect(t.s.publicCard("A3").status).toBe("OPEN");
    expect(flagsOf(t, "fokus_hilang")).toHaveLength(1);
    expect(flagsOf(t, "fokus_gagal")).toHaveLength(1);
    expect(t.sent.some((m) => m.event === "host:flags")).toBe(true);
  });

  it("terlalu cepat (level ≥ 5, benar) hanya memberi bendera kuning tanpa penalti", () => {
    const t = make();
    t.claimAndWin("s1", "F6", 0);
    const f = flagsOf(t, "terlalu_cepat");
    expect(f).toHaveLength(1);
    expect(f[0]!.severity).toBe("kuning");
    expect(t.s.publicCard("F6").ownerId).toBe("s1");
    // level rendah tidak diperiksa
    t.claimAndWin("s2", "A2", 0);
    expect(flagsOf(t, "terlalu_cepat")).toHaveLength(1);
  });

  it("perangkat bersama dan login ganda → bendera merah; Mode Stasiun dikecualikan", () => {
    const t = make();
    t.s.join("s1", t.s.pins.s1!, "perangkat-x");
    t.s.join("s2", t.s.pins.s2!, "perangkat-x");
    expect(flagsOf(t, "perangkat_bersama")).toHaveLength(1);
    t.s.join("s2", t.s.pins.s2!, "perangkat-x"); // tidak berulang
    expect(flagsOf(t, "perangkat_bersama")).toHaveLength(1);
    t.s.reportMultiLogin("s3");
    expect(flagsOf(t, "login_ganda")[0]!.severity).toBe("merah");

    const t2 = make();
    t2.s.stationMode = true;
    t2.s.join("s1", t2.s.pins.s1!, "stasiun-1");
    t2.s.join("s2", t2.s.pins.s2!, "stasiun-1");
    expect(flagsOf(t2, "perangkat_bersama")).toHaveLength(0);
  });

  it("pola jawaban salah sama ≥ 3 kali antara dua murid → bendera oranye", () => {
    const t = make();
    for (const cell of ["B1", "C1", "D1"]) {
      for (const id of ["s1", "s2", "s3"]) {
        t.s.claim(id, cell);
        const q = t.deliver(id);
        t.s.answer(id, { deliveryId: q.deliveryId, nonce: q.nonce, optId: wrongFor(q).optId });
        t.advance(21_000);
      }
    }
    const f = flagsOf(t, "pola_sama");
    expect(f.length).toBeGreaterThanOrEqual(1);
    expect(f[0]!.severity).toBe("oranye");
  });

  it("relay aktif hanya dengan peta kursi", () => {
    const t = make();
    t.s.setNeighbors({ s1: ["s2"], s2: ["s1"] });
    t.s.claim("s1", "G6");
    const q1 = t.deliver("s1");
    t.s.answer("s1", { deliveryId: q1.deliveryId, nonce: q1.nonce, value: "x", optId: "salah" });
    t.advance(21_000);
    t.claimAndWin("s2", "G6", 0);
    expect(flagsOf(t, "relay").length + flagsOf(t, "terlalu_cepat").length).toBeGreaterThanOrEqual(1);
  });

  it("sanksi berjenjang: peringatan, batalkan klaim, −1 tiket −30 poin, bekukan 3 menit", () => {
    const t = make();
    t.claimAndWin("s1", "E3", 20_000);
    const before = scoreOf(t.s.state, "s1");
    expect(t.s.sanction("s1", 1, "uji")).toMatch(/Peringatan/);
    expect(t.sent.some((m) => m.event === "toast" && m.room === "player:s1")).toBe(true);
    expect(t.s.sanction("s1", 3, "uji")).toMatch(/1 tiket/);
    expect(t.s.state.players.s1!.tickets).toBe(1);
    expect(scoreOf(t.s.state, "s1")).toBe(before - 30);
    expect(t.s.sanction("s1", 2, "uji")).toMatch(/dibatalkan/);
    expect(t.s.publicCard("E3").status).toBe("OPEN");
    expect(t.s.sanction("s1", 2, "uji")).toMatch(/tidak punya klaim/);
    t.s.sanction("s1", 4, "uji");
    t.s.claim("s1", "A1");
    expect(t.s.state.players.s1!.active).toBeNull();
    t.advance(3 * 60_000 + 1000);
    t.s.claim("s1", "A1");
    expect(t.s.state.players.s1!.active).not.toBeNull();
  });

  it("guru mengabaikan atau menindak bendera; status tersimpan dan pulih setelah restart", () => {
    const t = make();
    t.s.reportMultiLogin("s1");
    t.s.reportMultiLogin("s2");
    const [a, b] = t.s.flagList();
    expect(t.s.resolveFlag(a!.id, "abaikan")).toMatch(/diabaikan/);
    expect(t.s.resolveFlag(b!.id, "tindak")).toMatch(/Pilih sanksi/);
    expect(t.s.resolveFlag(b!.id, "tindak", 1)).toMatch(/Peringatan/);
    expect(t.s.flagList().map((f) => f.status)).toEqual(["diabaikan", "ditindak"]);
    const reg2 = new Registry({ store: t.store, bank, config, badges, emitter: { emit: () => undefined } });
    reg2.restoreAll();
    expect(
      reg2
        .get(t.s.id)!
        .flagList()
        .map((f) => f.status),
    ).toEqual(["diabaikan", "ditindak"]);
    expect(t.s.snapshotFor("host").flags).toHaveLength(2);
    expect(t.s.snapshotFor("projector").flags).toBeUndefined();
    expect(t.s.snapshotFor("player", "s1").flags).toBeUndefined();
  });
});

describe("gamifikasi (M8) dan PIN seragam", () => {
  it("PIN seragam: semua siswa satu kelas memakai PIN yang sama (4 digit)", () => {
    const t = make();
    const pins = Object.values(t.s.pins);
    expect(pins).toHaveLength(roster.length);
    expect(new Set(pins).size).toBe(1);
    expect(pins[0]).toMatch(/^\d{4}$/);
    // PIN bersama tetap diverifikasi
    expect(t.s.join("s1", pins[0] === "0000" ? "1111" : "0000", "dx")).toEqual({ ok: false, error: "bad_pin" });
  });

  it("badge diumumkan di ticker, toast pribadi, siaran fx, dan tampil di me()", () => {
    const t = make();
    t.claimAndWin("s1", "A8", 20_000);
    const me = t.s.me("s1")!;
    expect(me.badges).toEqual(expect.arrayContaining(["first_blood", "sniper"]));
    expect(t.s.ticker.some((x) => x.text.includes("badge Sniper"))).toBe(true);
    expect(
      t.sent.some((m) => m.event === "toast" && m.room === "player:s1" && JSON.stringify(m.payload).includes("Sniper")),
    ).toBe(true);
    const fx = t.sent
      .filter((m) => m.event === "fx")
      .map((m) => m.payload as { type: string; data: { nama?: string } });
    expect(fx.some((f) => f.type === "badge_awarded" && f.data.nama === "Sniper")).toBe(true);
    expect(t.s.snapshotFor("projector").badgeDefs.length).toBeGreaterThan(10);
  });

  it("selesai: penghargaan diumumkan, XP lintas sesi tersimpan sekali dan terakumulasi antar sesi", () => {
    const t = make();
    t.claimAndWin("s1", "A8", 20_000);
    t.claimAndWin("s2", "B7", 20_000);
    expect(t.s.snapshotFor("player", "s1").awards).toBeUndefined();
    t.s.host({ type: "host_phase", phase: "END" });
    expect(t.sent.some((m) => m.event === "awards")).toBe(true);
    const awards = t.s.snapshotFor("player", "s1").awards!;
    expect(awards.find((a) => a.id === "juara_1")).toBeDefined();
    const gain = Math.floor(scoreOf(t.s.state, "s1") / 10);
    expect(gain).toBeGreaterThan(0);
    expect(t.store.getXp("s1")).toBe(gain);
    expect(t.s.me("s1")!.xp).toMatchObject({ gain, total: gain });
    expect(t.store.studentBadges("s1")).toEqual(expect.arrayContaining(["sniper"]));
    // restart tidak menggandakan XP
    const reg2 = new Registry({ store: t.store, bank, config, badges, emitter: { emit: () => undefined } });
    reg2.restoreAll();
    expect(t.store.getXp("s1")).toBe(gain);
    expect(reg2.get(t.s.id)!.snapshotFor("player", "s1").awards).toBeDefined();
    // sesi kedua untuk siswa yang sama menambah XP
    const s2 = reg2.create({ className: "5A", roster, autoApprove: true, seed: 7 });
    for (const r of roster) s2.join(r.id, s2.pins[r.id]!, `d-${r.id}`);
    s2.host({ type: "start" });
    s2.host({ type: "host_adjust", playerId: "s1", delta: 100, reason: "uji xp" });
    s2.host({ type: "host_phase", phase: "END" });
    expect(t.store.getXp("s1")).toBe(gain + 10);
  });

  it("siswa dengan id manual tidak disimpan lintas sesi", () => {
    const store = new Store(":memory:");
    const reg = new Registry({ store, bank, config, badges, emitter: { emit: () => undefined } });
    const s = reg.create({
      className: "X",
      roster: [{ id: "manual-1", name: "Rina Putri", absen: 1 }],
      autoApprove: true,
    });
    s.join("manual-1", s.pins["manual-1"]!, "d");
    s.host({ type: "start" });
    s.host({ type: "host_adjust", playerId: "manual-1", delta: 200, reason: "uji" });
    s.host({ type: "host_phase", phase: "END" });
    expect(store.getXp("manual-1")).toBe(0);
    expect(s.me("manual-1")!.xp).toMatchObject({ gain: 20, total: 20 });
  });
});

describe("Voice-Over (M8b)", () => {
  const plays = (t: ReturnType<typeof make>) => t.sent.filter((m) => m.event === "vo:play");
  const bigClass = () => {
    const students = Array.from({ length: 14 }, (_, i) => ({
      id: `v${i + 1}`,
      name: `Siswa${i + 1} Uji`,
      absen: i + 1,
    }));
    let now = 1_700_000_000_000;
    const sent: Sent[] = [];
    const store = new Store(":memory:");
    const reg = new Registry({
      store,
      bank,
      config,
      badges,
      clock: () => now,
      emitter: { emit: (room, event, payload) => void sent.push({ room, event, payload }) },
    });
    const s = reg.create({ className: "6B", roster: students, autoApprove: true, seed: 11 });
    for (const r of students) s.join(r.id, s.pins[r.id]!, `dev-${r.id}`);
    s.host({ type: "start" });
    return {
      s,
      sent,
      advance: (ms: number) => {
        now += ms;
        s.tick();
      },
      win(id: string, cell: string) {
        s.claim(id, cell);
        const q = [...sent].reverse().find((m) => m.event === "question:deliver" && m.room === `player:${id}`)!
          .payload as QuestionDeliver;
        const item = bank.find((b) => b.sel === q.cell && b.soal === q.soal)!;
        const ans =
          item.tipe === "pg"
            ? { optId: q.opsi!.find((o) => o.text === item.jawaban)!.optId }
            : { value: String(item.tipe === "angka" ? item.jawaban : item.jawaban_diterima[0]) };
        now += 4000;
        s.answer(id, { deliveryId: q.deliveryId, nonce: q.nonce, ...ans });
      },
    };
  };

  it("klaim benar → vo:play hanya ke room proyektor, langsung (tanpa tunggu), berisi nama dan sel; murid dapat toast", () => {
    const t = make();
    t.claimAndWin("s1", "E6", 20_000);
    const p = plays(t);
    expect(p).toHaveLength(1);
    expect(p[0]!.room).toBe(`projector:${t.s.id}`);
    const v = p[0]!.payload as { teks: string; sorotSel: string; segmen: { k: string }[] };
    expect(v.teks).toMatch(/Rina/);
    expect(v.teks).toMatch(/E enam/);
    expect(v.sorotSel).toBe("E6");
    expect(v.segmen.map((s) => s.k)).toEqual(expect.arrayContaining(["nama", "sel", "teks"]));
    expect(t.sent.filter((m) => m.event === "vo:play" && m.room !== `projector:${t.s.id}`)).toHaveLength(0);
    expect(
      t.sent.some(
        (m) => m.event === "toast" && m.room === "player:s1" && JSON.stringify(m.payload).includes("diumumkan"),
      ),
    ).toBe(true);
  });

  it("jawaban salah tidak pernah menghasilkan VO dan isi soal/jawaban tidak pernah dibacakan", () => {
    const t = make();
    t.s.claim("s1", "E4");
    const q = t.deliver("s1");
    t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, value: "-1", optId: "salah" });
    t.advance(30_000);
    expect(plays(t)).toHaveLength(0);
    t.claimAndWin("s2", "E5", 20_000);
    const blob = JSON.stringify(plays(t).map((m) => m.payload));
    expect(blob).not.toContain(q.soal);
    expect(blob).not.toMatch(/jawaban|pembahasan/);
  });

  it("10 klaim dalam 3 detik → VO gabungan, bukan 10 VO berturut-turut (DoD 12)", () => {
    const t = bigClass();
    const cells = ["A1", "B1", "C1", "D1", "E1", "F1", "G1", "A2", "B2", "C2"];
    cells.forEach((c, i) => {
      t.win(`v${i + 1}`, c);
      t.advance(0);
    });
    // proyektor menyelesaikan satu per satu
    const done = () => {
      const last = [...t.sent].reverse().find((m) => m.event === "vo:play");
      if (last) t.s.voDone((last.payload as { id: string }).id);
    };
    for (let i = 0; i < 12; i++) {
      done();
      t.advance(450);
    }
    const texts = t.sent.filter((m) => m.event === "vo:play").map((m) => (m.payload as { teks: string }).teks);
    expect(texts.length).toBeLessThan(6);
    expect(texts.some((x) => /kartu baru terklaim|Papan makin ramai/.test(x))).toBe(true);
  });

  it("hitung mundur 10 detik terakhir dan VO selesai; fase BATTLE diumumkan", () => {
    const t = bigClass();
    t.advance(15 * 60_000 + 500);
    expect(t.sent.some((m) => m.event === "vo:play" && /BATTLE/.test((m.payload as { teks: string }).teks))).toBe(true);
    const total = 40 * 60_000;
    // lompat ke 6 detik terakhir; fase otomatis melewati RUSH
    t.advance(total - 15 * 60_000 - 500 - 6_000);
    for (let i = 0; i < 6; i++) {
      const last = [...t.sent].reverse().find((m) => m.event === "vo:play");
      if (last) t.s.voDone((last.payload as { id: string }).id);
      t.advance(1000);
    }
    const nums = t.sent
      .filter((m) => m.event === "vo:play")
      .map((m) => (m.payload as { teks: string }).teks)
      .filter((x) => /^\d+$/.test(x));
    expect(nums.length).toBeGreaterThan(0);
    const lastPlay = () => [...t.sent].reverse().find((m) => m.event === "vo:play");
    if (lastPlay()) t.s.voDone((lastPlay()!.payload as { id: string }).id);
    t.advance(1500); // lewat batas waktu: fase END
    expect(t.sent.some((m) => m.event === "vo:play" && /Waktu habis/.test((m.payload as { teks: string }).teks))).toBe(
      true,
    );
  });

  it("nama VO fonetik dari guru dipakai, disimpan, dan pengaturan disiarkan ke proyektor dan guru", () => {
    const t = make();
    t.s.setVoName("s1", "Rii-na");
    t.claimAndWin("s1", "E6", 20_000);
    expect((plays(t)[0]!.payload as { teks: string }).teks).toMatch(/Rii-na/);
    expect(t.store.listVoNames(t.s.id)).toEqual({ s1: "Rii-na" });
    t.s.setVoSettings({ mode: "penting_saja", volume: 0.4 });
    expect(t.sent.some((m) => m.event === "vo:settings" && m.room === `projector:${t.s.id}`)).toBe(true);
    expect(t.sent.some((m) => m.event === "vo:settings" && m.room === `host:${t.s.id}`)).toBe(true);
    expect(t.s.snapshotFor("host").vo).toMatchObject({ mode: "penting_saja", volume: 0.4 });
    expect(t.s.snapshotFor("player", "s1").vo).toBeUndefined();
  });

  it("Tes VO guru memutar suara tanpa mengubah skor", () => {
    const t = make();
    const before = scoreOf(t.s.state, "s2");
    t.s.voTest("s2");
    expect(plays(t)).toHaveLength(1);
    expect(scoreOf(t.s.state, "s2")).toBe(before);
    expect(t.s.state.cards.E6!.status).toBe("OPEN");
  });
});

describe("PIN kelas berganti tiap 5 menit", () => {
  const slotStart = Math.floor(1_700_000_000_000 / 300_000) * 300_000;
  function pinSetup(autoApprove = false) {
    let now = slotStart + 1000;
    const sent: Sent[] = [];
    const store = new Store(":memory:");
    const mk = () =>
      new Registry({
        store,
        bank,
        config,
        badges,
        clock: () => now,
        emitter: { emit: (room, event, payload) => void sent.push({ room, event, payload }) },
      });
    const reg = mk();
    const s = reg.create({ className: "5C", roster, autoApprove, seed: 21 });
    return {
      s,
      sent,
      store,
      reg,
      mk,
      set: (ms: number) => (now = ms),
      get now() {
        return now;
      },
    };
  }

  it("PIN sama dalam satu slot, berganti di slot berikutnya, deterministik setelah restart", () => {
    const t = pinSetup();
    const p1 = t.s.currentPin();
    expect(p1).toMatch(/^\d{4}$/);
    t.set(slotStart + 299_000);
    expect(t.s.currentPin()).toBe(p1);
    t.set(slotStart + 301_000);
    const p2 = t.s.currentPin();
    expect(p2).not.toBe(p1);
    // slot demi slot berbeda (peluang bentrok 1/10000 per pasang; seed tetap sehingga deterministik)
    const seen = new Set<string>();
    for (let i = 0; i < 6; i++) {
      t.set(slotStart + i * 300_000 + 5000);
      seen.add(t.s.currentPin());
    }
    expect(seen.size).toBeGreaterThanOrEqual(5);
    // restart: sesi dipulihkan memberi PIN yang sama pada waktu yang sama
    t.set(slotStart + 301_000);
    const reg2 = t.mk();
    reg2.restoreAll();
    expect(reg2.get(t.s.id)!.currentPin()).toBe(p2);
    expect(t.s.pinExpiresAt()).toBe(slotStart + 600_000);
  });

  it("PIN lama ditolak, kecuali PIN sebelumnya selama 20 detik pertama slot baru", () => {
    const t = pinSetup();
    const old = t.s.currentPin();
    t.set(slotStart + 300_000 + 10_000);
    expect(t.s.join("s1", old, "d1")).toEqual({ ok: true, status: "pending" });
    t.set(slotStart + 300_000 + 25_000);
    expect(t.s.join("s2", old, "d2")).toEqual({ ok: false, error: "bad_pin" });
    expect(t.s.join("s2", t.s.currentPin(), "d2")).toEqual({ ok: true, status: "pending" });
  });

  it("murid yang sudah masuk menyambung ulang dari perangkat yang sama tanpa PIN terbaru; perangkat lain wajib PIN terbaru", () => {
    const t = pinSetup(true);
    const first = t.s.currentPin();
    expect(t.s.join("s1", first, "hp-rina")).toEqual({ ok: true, status: "approved" });
    t.set(slotStart + 3 * 300_000 + 60_000);
    expect(t.s.join("s1", first, "hp-rina")).toEqual({ ok: true, status: "approved" });
    expect(t.s.join("s1", first, "hp-lain")).toEqual({ ok: false, error: "bad_pin" });
    expect(t.s.join("s1", t.s.currentPin(), "hp-lain")).toEqual({ ok: true, status: "approved" });
    // setelah restart (perangkat belum diketahui) murid yang sudah disetujui tetap bisa menyambung
    const reg2 = t.mk();
    reg2.restoreAll();
    expect(reg2.get(t.s.id)!.join("s1", first, "hp-rina")).toEqual({ ok: true, status: "approved" });
    // tetapi murid yang belum pernah disetujui tidak bisa memakai PIN basi
    expect(reg2.get(t.s.id)!.join("s3", first, "hp-sari")).toEqual({ ok: false, error: "bad_pin" });
  });

  it("guru menerima PIN terbaru di snapshot dan lewat siaran saat PIN berganti", () => {
    const t = pinSetup();
    t.s.tick();
    expect(t.sent.filter((m) => m.event === "host:pin")).toHaveLength(1);
    t.s.tick();
    expect(t.sent.filter((m) => m.event === "host:pin")).toHaveLength(1); // belum berganti
    t.set(slotStart + 301_000);
    t.s.tick();
    const pins = t.sent.filter((m) => m.event === "host:pin");
    expect(pins).toHaveLength(2);
    expect((pins[1]!.payload as { value: string }).value).toBe(t.s.currentPin());
    const snap = t.s.snapshotFor("host");
    expect(snap.pin).toMatchObject({ value: t.s.currentPin(), intervalMs: 300_000, expiresAt: slotStart + 600_000 });
    expect(t.s.snapshotFor("projector").pin).toBeUndefined();
    expect(t.s.snapshotFor("host").roster!.every((r) => r.pin === t.s.currentPin())).toBe(true);
  });
});

describe("laporan (M9)", () => {
  it("setiap percobaan tercatat: benar, salah (teks opsi), waktu habis, dan fokus hilang", () => {
    const t = make();
    // salah pada soal pilihan ganda: teks opsi yang dipilih tersimpan
    t.s.claim("s1", "B1");
    const q1 = t.deliver("s1");
    const item = bank.find((b) => b.sel === "B1" && b.soal === q1.soal)!;
    const answer = item.tipe === "pg" ? item.jawaban : "";
    const wrong = q1.opsi!.find((o) => o.text !== answer)!;
    t.s.answer("s1", { deliveryId: q1.deliveryId, nonce: q1.nonce, optId: wrong.optId });
    // waktu habis
    t.s.claim("s2", "C1");
    t.advance(120_000);
    // fokus hilang 2x
    t.s.claim("s3", "D1");
    const q3 = t.deliver("s3");
    t.s.focusLost("s3", q3.deliveryId);
    t.s.focusLost("s3", q3.deliveryId);
    // benar
    t.claimAndWin("s4", "A2", 4_000);

    const rep = t.s.report();
    const by = (id: string) => rep.siswa.find((s) => s.id === id)!;
    expect(rep.jumlahPercobaan).toBe(4);
    expect(by("s1").indikator.percobaan).toBe(1);
    const all = t.store.listDeliveries(t.s.id);
    expect(all.find((d) => d.student_id === "s1")!.answer_raw).toBe(wrong.text);
    expect(all.find((d) => d.student_id === "s2")!.answer_raw).toBe("timeout");
    expect(all.find((d) => d.student_id === "s3")!.answer_raw).toBe("fokus");
    expect(by("s4").indikator.benar).toBe(1);
    expect(rep.heatmap).toHaveLength(80);
    expect(rep.butir.length).toBe(4);
    // pengecoh tercatat untuk butir B1 (varian yang ditampilkan)
    const butir = rep.butir.find((b) => b.cell === "B1")!;
    expect(butir.pengecoh[wrong.text]).toBe(1);
    // rapor tidak memuat kunci jawaban soal
    expect(JSON.stringify(rep)).not.toContain('"pembahasan"');
  });

  it("laporan tersedia saat permainan berjalan dan urut sesuai papan skor", () => {
    const t = make();
    t.claimAndWin("s1", "E2", 4_000);
    t.claimAndWin("s2", "J6", 20_000);
    const rep = t.s.report();
    expect(rep.siswa.map((s) => s.rank)).toEqual([1, 2, 3, 4]);
    expect(rep.siswa[0]!.score).toBeGreaterThanOrEqual(rep.siswa[1]!.score);
    expect(rep.endedAt).toBeNull();
    t.s.host({ type: "host_phase", phase: "END" });
    expect(t.s.report().endedAt).not.toBeNull();
    expect(t.s.report().siswa[0]!.xpGain).not.toBeNull();
  });
});

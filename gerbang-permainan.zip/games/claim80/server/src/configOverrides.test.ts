import { describe, expect, it } from "vitest";
import { applyOverrides, scaleFase, validatePatch } from "./configOverrides";
import { loadConfig } from "./questions/bank";

const base = loadConfig();

describe("pengaturan guru → konfigurasi efektif", () => {
  it("tanpa perubahan: sama dengan config dasar", () => {
    const c = applyOverrides(base, { autoApprove: false });
    expect(c.durasi_menit).toBe(40);
    expect(c.fase.map((f) => f.mulai_menit)).toEqual([0, 15, 35, 40]);
    expect(c.kecepatan.pengali_waktu).toBe(base.kecepatan.pengali_waktu);
    expect(c.jeda_soal).toMatchObject({ setiap: 2, detik: 5 });
  });

  it("durasi lain: fase diskalakan dan tetap berurutan", () => {
    for (const d of [5, 6, 10, 20, 25, 60, 90, 120]) {
      const f = scaleFase(base, d);
      const m = f.map((x) => x.mulai_menit);
      expect(m[0]).toBe(0);
      expect(m[3]).toBe(d);
      expect(m[1]!).toBeGreaterThanOrEqual(1);
      expect(m[1]!).toBeLessThan(m[2]!);
      expect(m[2]!).toBeLessThan(m[3]!);
      expect(f.map((x) => x.id)).toEqual(["OPEN", "BATTLE", "RUSH", "END"]);
    }
    expect(scaleFase(base, 20).map((x) => x.mulai_menit)).toEqual([0, 8, 15, 20]);
    expect(scaleFase(base, 60).map((x) => x.mulai_menit)).toEqual([0, 23, 55, 60]);
    expect(scaleFase(base, 20).find((x) => x.id === "RUSH")!.pengali_poin).toBe(1.5);
  });

  it("waktu menjawab dan jeda dapat diubah dan dibatasi", () => {
    const c = applyOverrides(base, {
      autoApprove: false,
      pengaliWaktu: 1,
      waktuMin: 20,
      jedaSetiap: 3,
      jedaDetik: 0,
      durasiMenit: 999,
    });
    expect(c.kecepatan.pengali_waktu).toBe(1);
    expect(c.kecepatan.waktu_min_detik).toBe(20);
    expect(c.jeda_soal).toMatchObject({ setiap: 3, detik: 0 });
    expect(c.durasi_menit).toBe(120);
  });

  it("validasi patch memberi pesan ramah", () => {
    expect(validatePatch({ durasiMenit: 30, pengaliWaktu: 0.8, jedaDetik: 5 })).toBeNull();
    expect(validatePatch({ durasiMenit: 2 })).toMatch(/Durasi/);
    expect(validatePatch({ pengaliWaktu: 5 })).toMatch(/Pengali/);
    expect(validatePatch({ waktuMin: 1 })).toMatch(/minimum/);
    expect(validatePatch({ jedaSetiap: 0 })).toMatch(/Jeda/);
    expect(validatePatch({ jedaDetik: 999 })).toMatch(/Lama jeda/);
    expect(validatePatch({ durasiMenit: Number.NaN })).toMatch(/Durasi/);
  });
});

import type { Question } from "@claim80/shared";

/** Hash FNV-1a 32-bit untuk menurunkan seed dari (sesi, murid, sel, percobaan). */
export function seedFrom(...parts: (string | number)[]): number {
  let h = 0x811c9dc5;
  for (const ch of parts.join("|")) {
    h ^= ch.charCodeAt(0);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

/** RNG deterministik (mulberry32). */
export function rngFrom(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

type Rng = () => number;
const int = (r: Rng, a: number, b: number) => a + Math.floor(r() * (b - a + 1));
const pick = <T>(r: Rng, xs: readonly T[]): T => xs[Math.floor(r() * xs.length)]!;
const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
const lcm = (a: number, b: number) => (a / gcd(a, b)) * b;
const divisors = (n: number) => {
  let c = 0;
  for (let i = 1; i <= n; i++) if (n % i === 0) c++;
  return c;
};

interface Gen {
  soal: string;
  jawaban: number | string[];
  satuan?: string;
}

const WORDS_VALUE = ["BACA", "CABE", "DADU", "BADAK", "KAKI", "BUKU", "AYAM", "DAGING", "BEBEK", "ACAR"];
const WORDS_CODE = ["pasar", "kursi", "buku", "meja", "sapi", "pisang", "kucing", "sepatu", "jambu", "mangga"];
const shift = (w: string, k: number) =>
  [...w].map((c) => String.fromCharCode(((c.charCodeAt(0) - 97 + k) % 26) + 97)).join("");
const seq = (xs: number[]) => xs.join(", ");

/** Templat parametrik per sel untuk kolom A, E, I (SPEC §7.4): soal setara level dengan angka acak. */
const GENERATORS: Record<string, (r: Rng) => Gen> = {
  // ----- E Aritmetika -----
  E1: (r) => {
    const a = int(r, 3, 9);
    const b = int(r, 2, a);
    return r() < 0.5 ? { soal: `${a} + ${b} = ...`, jawaban: a + b } : { soal: `${a} − ${b} = ...`, jawaban: a - b };
  },
  E2: (r) => {
    const a = int(r, 3, 9);
    const b = int(r, 3, 9);
    return r() < 0.5 ? { soal: `${a} × ${b} = ...`, jawaban: a * b } : { soal: `${a * b} : ${b} = ...`, jawaban: a };
  },
  E3: (r) => {
    let a = 0;
    let b = 0;
    for (let i = 0; i < 30; i++) {
      a = int(r, 100, 499);
      b = int(r, 100, 499);
      if ((a % 10) + (b % 10) >= 10) break; // ada simpan
    }
    return { soal: `${a} + ${b} = ...`, jawaban: a + b };
  },
  E4: (r) => {
    const a = int(r, 12, 19);
    const b = int(r, 11, 16);
    return { soal: `${a} × ${b} = ...`, jawaban: a * b };
  },
  E5: (r) => {
    const a = int(r, 2, 12);
    const b = int(r, 2, 9);
    const c = int(r, 2, 9);
    const d = int(r, 1, a + b * c - 1);
    return { soal: `${a} + ${b} × ${c} − ${d} = ...`, jawaban: a + b * c - d };
  },
  E6: (r) => {
    const b = int(r, 2, 9);
    const q = int(r, 2, 9);
    const c = int(r, 8, 20);
    const d = int(r, 1, c - 1);
    return { soal: `(${b * q} : ${b}) × (${c} − ${d}) = ...`, jawaban: q * (c - d) };
  },
  E7: (r) => {
    const m = int(r, 8, 30);
    let x = 0;
    for (let i = 0; i < 100; i++) {
      x = int(r, 1, 5 * m - 1);
      if ((5 * m - x) % 4 === 0) break;
    }
    if ((5 * m - x) % 4 !== 0) x = 5 * m - 4 * m; // x = m membuat sisa bulat
    return {
      soal: `Rata-rata 5 bilangan adalah ${m}. Jika bilangan ${x} dihapus, berapa rata-rata 4 bilangan sisanya?`,
      jawaban: (5 * m - x) / 4,
    };
  },
  E8: (r) => {
    const k = int(r, 3, 4);
    const n = int(r, 12, 99);
    return { soal: `Hitung: ${"9".repeat(k)} × ${n}`, jawaban: (10 ** k - 1) * n };
  },
  // ----- A Numerik -----
  A1: (r) => {
    const n = int(r, 20, 198);
    return r() < 0.5
      ? { soal: `Bilangan apa yang datang tepat setelah ${n}?`, jawaban: n + 1 }
      : { soal: `Bilangan apa yang datang tepat sebelum ${n}?`, jawaban: n - 1 };
  },
  A2: (r) => {
    const digits = [1, 2, 3, 4, 5, 6, 7, 8, 9];
    const d: number[] = [];
    while (d.length < 3) {
      const x = pick(r, digits);
      if (!d.includes(x)) d.push(x);
    }
    const pos = int(r, 0, 2); // 0 = satuan
    const digit = d[2 - pos]!;
    return { soal: `Berapa nilai angka ${digit} pada bilangan ${d.join("")}?`, jawaban: digit * 10 ** pos };
  },
  A3: (r) => {
    if (r() < 0.5) {
      const a = int(r, 2, 30);
      const d = int(r, 2, 9);
      return { soal: `Lanjutkan pola: ${seq([a, a + d, a + 2 * d, a + 3 * d])}, ...`, jawaban: a + 4 * d };
    }
    const a = int(r, 1, 5);
    const q = int(r, 2, 3);
    return { soal: `Lanjutkan pola: ${seq([a, a * q, a * q ** 2, a * q ** 3])}, ...`, jawaban: a * q ** 4 };
  },
  A4: (r) => {
    const g = int(r, 2, 9);
    let p = 0;
    let q = 0;
    do {
      p = int(r, 2, 9);
      q = int(r, 2, 9);
    } while (p === q || gcd(p, q) !== 1);
    return { soal: `FPB dari ${g * p} dan ${g * q} adalah...`, jawaban: g };
  },
  A5: (r) => {
    const s = new Set<number>();
    while (s.size < 3) s.add(int(r, 2, 12));
    const [a, b, c] = [...s] as [number, number, number];
    return { soal: `KPK dari ${a}, ${b}, dan ${c} adalah...`, jawaban: lcm(lcm(a, b), c) };
  },
  A6: (r) => {
    const n = pick(r, [24, 36, 48, 60, 72, 80, 90, 96, 100, 120]);
    return { soal: `Berapa banyak faktor dari ${n}?`, jawaban: divisors(n) };
  },
  A7: (r) => {
    const n = int(r, 30, 200);
    return { soal: `Berapa jumlah semua bilangan genap dari 2 sampai ${2 * n}?`, jawaban: n * (n + 1) };
  },
  A8: (r) => {
    const n = int(r, 60, 200);
    let z = 0;
    for (let p = 5; p <= n; p *= 5) z += Math.floor(n / p);
    return { soal: `Ada berapa angka 0 di ujung hasil perkalian 1 × 2 × 3 × ... × ${n}?`, jawaban: z };
  },
  // ----- I Sandi & Pola -----
  I1: (r) => {
    const a = int(r, 1, 10);
    const d = int(r, 2, 6);
    return { soal: `Lanjutkan pola: ${seq([a, a + d, a + 2 * d, a + 3 * d])}, ...`, jawaban: a + 4 * d };
  },
  I2: (r) => {
    const w = pick(r, WORDS_VALUE);
    const v = [...w].reduce((s, c) => s + c.charCodeAt(0) - 64, 0);
    return { soal: `Jika A = 1, B = 2, C = 3, dan seterusnya, berapa nilai kata ${w}?`, jawaban: v };
  },
  I3: (r) => {
    let a = int(r, 1, 5);
    let b = int(r, 1, 5);
    const t = [a, b];
    for (let i = 0; i < 5; i++) {
      [a, b] = [b, a + b];
      t.push(b);
    }
    return { soal: `Lanjutkan pola: ${seq(t.slice(0, 6))}, ...`, jawaban: t[6]! };
  },
  I4: (r) => {
    const s = int(r, 80, 150);
    const k = int(r, 9, 12);
    const t = [s, s - k, s - k - (k - 1), s - k - (k - 1) - (k - 2)];
    return { soal: `Lanjutkan pola: ${seq(t)}, ...`, jawaban: t[3]! - (k - 3) };
  },
  I5: (r) => {
    const o = int(r, 1, 3);
    const m = int(r, 1, 4);
    const t = [0, 1, 2, 3, 4].map((i) => (m + i) * (m + i + o));
    return { soal: `Lanjutkan pola: ${seq(t)}, ...`, jawaban: (m + 5) * (m + 5 + o) };
  },
  I6: (r) => {
    const n = int(r, 8, 14);
    return { soal: `Pola: 1, 2, 4, 7, 11, 16, ... Berapa suku ke-${n}?`, jawaban: 1 + (n * (n - 1)) / 2 };
  },
  I7: (r) => {
    const w = pick(r, WORDS_CODE);
    const k = int(r, 1, 3);
    return {
      soal: `Setiap huruf sebuah kata digeser maju ${k} (A jadi ${String.fromCharCode(65 + k)}, dst.) sehingga tertulis ${shift(w, k).toUpperCase()}. Apa kata aslinya?`,
      jawaban: [w],
    };
  },
  I8: (r) => {
    const a = int(r, 1, 6);
    const b = int(r, a + 1, 9);
    return {
      soal: `Sebuah bilangan dua angka memiliki jumlah angka ${a + b}. Jika urutan angkanya dibalik, bilangan itu bertambah ${9 * (b - a)}. Bilangan berapakah itu?`,
      jawaban: 10 * a + b,
    };
  },
};

export const GENERATED_CELLS = Object.keys(GENERATORS);
export const GENERATED_COLUMNS = ["A", "E", "I"] as const;

export function hasGenerator(cell: string): boolean {
  return cell in GENERATORS;
}

/**
 * Membuat soal acak setara level dari templat sel. Waktu, poin, kategori, dan pembahasan singkat mengikuti soal bank sel itu
 * (`template`), sehingga skor dan batas waktu tidak berubah. Deterministik untuk seed yang sama.
 */
export function generateQuestion(cell: string, seed: number, template: Question): Question | null {
  const gen = GENERATORS[cell];
  if (!gen) return null;
  const g = gen(rngFrom(seed));
  const base = {
    id: `${cell}-g${seed.toString(16)}`,
    sel: template.sel,
    kolom: template.kolom,
    level: template.level,
    varian: template.varian,
    kategori_kolom: template.kategori_kolom,
    subkategori: template.subkategori,
    soal: g.soal,
    waktu_detik: template.waktu_detik,
    poin_dasar: template.poin_dasar,
    pembahasan: "Soal acak (angka berbeda untuk tiap murid).",
    ...(g.satuan ? { satuan: g.satuan } : {}),
  };
  return Array.isArray(g.jawaban)
    ? { ...base, tipe: "teks", jawaban_diterima: g.jawaban }
    : { ...base, tipe: "angka", jawaban: g.jawaban, toleransi: 0 };
}

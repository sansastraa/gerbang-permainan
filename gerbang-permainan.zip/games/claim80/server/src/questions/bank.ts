import { readFileSync } from "node:fs";
import { badgesFileSchema, configSchema, validateBank } from "@claim80/shared";
import type { BadgeDef, GameConfig, Question } from "@claim80/shared";

const rootUrl = new URL("../../../", import.meta.url);
const readJson = (rel: string): unknown => JSON.parse(readFileSync(new URL(rel, rootUrl), "utf8"));

/** Memuat dan memvalidasi bank soal (SPEC §7.5). Melempar galat bila tidak valid agar server tidak jalan dengan bank rusak. */
export function loadBank(path = "data/bank_soal.json"): Question[] {
  const r = validateBank(readJson(path));
  if (!r.ok) throw new Error(`Bank soal tidak valid:\n${r.errors.join("\n")}`);
  return r.soal;
}

export function loadBadges(path = "config/badges.json"): BadgeDef[] {
  return badgesFileSchema
    .parse(readJson(path))
    .badges.map((b) => ({ id: b.id, nama: b.nama, ikon: b.ikon, bonus: b.bonus, syarat: b.syarat }));
}

export function loadConfig(path = "config/game.config.json"): GameConfig {
  return configSchema.parse(readJson(path));
}

import { describe, expect, it } from "vitest";
import { judgeValue, questionSchema } from "@claim80/shared";
import type { Question } from "@claim80/shared";
import { loadBank } from "./bank";
import { GENERATED_CELLS, generateQuestion, hasGenerator, rngFrom, seedFrom } from "./generators";

const bank = loadBank();
const template = (cell: string) => bank.find((q) => q.sel === cell && q.varian === 1)!;

describe("generator parametrik (SPEC §7.4)", () => {
  it("mencakup seluruh 24 sel kolom A, E, dan I", () => {
    const want = [..."AEI"].flatMap((c) => [1, 2, 3, 4, 5, 6, 7, 8].map((r) => `${c}${r}`));
    expect([...GENERATED_CELLS].sort()).toEqual(want.sort());
    expect(hasGenerator("B3")).toBe(false);
    expect(generateQuestion("B3", 1, template("B3"))).toBeNull();
  });

  it("hasilnya lolos skema soal, mewarisi level/waktu/poin, dan jawabannya konsisten (150 seed per sel)", () => {
    for (const cell of GENERATED_CELLS) {
      const t = template(cell);
      for (let i = 0; i < 150; i++) {
        const q = generateQuestion(cell, seedFrom("uji", cell, i), t)!;
        expect(() => questionSchema.parse(q), `${cell} seed ${i}`).not.toThrow();
        expect(q.level).toBe(t.level);
        expect(q.waktu_detik).toBe(t.waktu_detik);
        expect(q.poin_dasar).toBe(t.poin_dasar);
        expect(q.soal).not.toMatch(/NaN|undefined|Infinity/);
        if (q.tipe === "angka") {
          expect(Number.isInteger(q.jawaban), `${cell}: ${q.soal}`).toBe(true);
          expect(q.jawaban, `${cell}: ${q.soal}`).toBeGreaterThanOrEqual(0);
          // penilai yang sama dengan penilai bank menerima jawaban benar (dan menolak jawaban salah)
          expect(judgeValue(q, String(q.jawaban))).toBe(true);
          expect(judgeValue(q, String(q.jawaban + 1))).toBe(false);
        } else if (q.tipe === "teks") {
          expect(judgeValue(q, q.jawaban_diterima[0]!.toUpperCase())).toBe(true);
        } else {
          throw new Error(`generator ${cell} tidak boleh menghasilkan pilihan ganda`);
        }
      }
    }
  }, 60_000);

  it("deterministik untuk seed sama dan bervariasi antar murid/percobaan", () => {
    for (const cell of GENERATED_CELLS) {
      const t = template(cell);
      const a = generateQuestion(cell, 12345, t)!;
      const b = generateQuestion(cell, 12345, t)!;
      expect(a).toEqual(b);
      const texts = new Set(
        Array.from({ length: 40 }, (_, i) => generateQuestion(cell, seedFrom("sesi", `murid${i}`, cell), t)!.soal),
      );
      expect(texts.size, cell).toBeGreaterThanOrEqual(4);
    }
  });

  it("jawaban benar diperiksa dengan perhitungan independen untuk beberapa templat", () => {
    const solve = (q: Question) => (q.tipe === "angka" ? q.jawaban : NaN);
    for (let i = 0; i < 200; i++) {
      const s = seedFrom("cek", i);
      const e5 = generateQuestion("E5", s, template("E5"))!;
      const m5 = /^(\d+) \+ (\d+) × (\d+) − (\d+) = \.\.\.$/.exec(e5.soal)!;
      expect(solve(e5)).toBe(Number(m5[1]) + Number(m5[2]) * Number(m5[3]) - Number(m5[4]));

      const i8 = generateQuestion("I8", s, template("I8"))!;
      const m8 = /jumlah angka (\d+)\. .* bertambah (\d+)\./.exec(i8.soal)!;
      const n = solve(i8);
      const [x, y] = [Math.floor(n / 10), n % 10];
      expect(x + y).toBe(Number(m8[1]));
      expect(y * 10 + x - n).toBe(Number(m8[2]));

      const a4 = generateQuestion("A4", s, template("A4"))!;
      const m4 = /FPB dari (\d+) dan (\d+)/.exec(a4.soal)!;
      const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b));
      expect(solve(a4)).toBe(gcd(Number(m4[1]), Number(m4[2])));

      const a8 = generateQuestion("A8", s, template("A8"))!;
      const N = Number(/× \.\.\. × (\d+)\?/.exec(a8.soal)![1]);
      let zeros = 0;
      let f = 1n;
      for (let k = 2n; k <= BigInt(N); k++) f *= k;
      for (const ch of [...f.toString()].reverse()) {
        if (ch === "0") zeros++;
        else break;
      }
      expect(solve(a8)).toBe(zeros);
    }
  });

  it("RNG dan hash stabil", () => {
    expect(seedFrom("a", 1)).toBe(seedFrom("a", 1));
    expect(seedFrom("a", 1)).not.toBe(seedFrom("a", 2));
    const r1 = rngFrom(7);
    const r2 = rngFrom(7);
    expect([r1(), r1(), r1()]).toEqual([r2(), r2(), r2()]);
  });
});

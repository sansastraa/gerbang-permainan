import { randomBytes, timingSafeEqual } from "node:crypto";
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname } from "node:path";
import { createServer } from "node:http";
import { networkInterfaces } from "node:os";
import { fileURLToPath } from "node:url";
import express from "express";
import { Server } from "socket.io";
import { z } from "zod";
import { normalizeBasePath, viaProxy } from "./basePath";
import { Store } from "./db";
import { Registry } from "./registry";
import { attemptsCsv, itemsCsv, studentsCsv, summaryJson } from "./stats/report";
import { buildAttempts } from "./stats/stats";
import { attachSockets } from "./socket";
import { loadBadges, loadBank, loadConfig } from "./questions/bank";

const PORT = Number(process.env.PORT ?? 3080);

export interface AppOptions {
  dbPath?: string;
  clock?: () => number;
  hostToken?: string;
  /** asal (origin) yang boleh memanggil /api dari browser, mis. alamat SIMPETERI */
  allowedOrigins?: string[];
  tickMs?: number;
  /** awalan jalur di belakang gerbang, mis. "/games/claim80" (bawaan: env BASE_PATH; kosong = akar) */
  basePath?: string;
  /** folder klien hasil build (bawaan: ../../client/dist) */
  distDir?: string;
}

const rosterBody = z.object({
  className: z.string().min(1).max(80),
  autoApprove: z.boolean().optional(),
  seed: z.number().int().optional(),
  roster: z
    .array(
      z.object({
        id: z.string().min(1).max(80),
        name: z.string().min(1).max(120),
        absen: z.number().int().nullable().optional(),
      }),
    )
    .min(1)
    .max(60),
});

/** Token guru yang stabil antar-restart (disimpan di server/var) agar guru tidak perlu mencari token baru tiap kali. */
function loadHostToken(persist: boolean): string {
  if (process.env.HOST_TOKEN) return process.env.HOST_TOKEN;
  if (!persist) return randomBytes(6).toString("hex");
  const path = fileURLToPath(new URL("../var/host-token.txt", import.meta.url));
  try {
    const t = readFileSync(path, "utf8").trim();
    if (t.length >= 6) return t;
  } catch {
    /* belum ada */
  }
  const t = randomBytes(4).toString("hex");
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, t);
  return t;
}

const safeEq = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));

export function createApp(opt: AppOptions = {}) {
  const base = normalizeBasePath(opt.basePath ?? process.env.BASE_PATH);
  const app = express();
  /** Semua rute dipasang di router ini, lalu router dipasang di bawah awalan jalur. */
  const router = express.Router();
  const http = createServer(app);
  const io = new Server(http, { serveClient: false, path: `${base}/socket.io` });
  const bank = loadBank();
  const config = loadConfig();
  const badges = loadBadges();
  const store = new Store(opt.dbPath ?? fileURLToPath(new URL("../var/claim80.db", import.meta.url)));
  const clock = opt.clock ?? Date.now;
  const hostToken = opt.hostToken ?? loadHostToken(opt.dbPath !== ":memory:");
  const reg = new Registry({
    store,
    bank,
    config,
    badges,
    clock,
    emitter: { emit: (room, ev, payload) => void io.to(room).emit(ev, payload) },
  });
  reg.restoreAll();
  attachSockets(io, reg, hostToken, clock);
  reg.start(opt.tickMs ?? 250);

  const allowed = new Set(opt.allowedOrigins ?? (process.env.ALLOWED_ORIGINS ?? "").split(",").filter(Boolean));
  router.use("/api", (req, res, next) => {
    const origin = req.headers.origin;
    if (origin && allowed.has(origin)) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Headers", "content-type, x-host-token");
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    }
    if (req.method === "OPTIONS") return void res.sendStatus(204);
    next();
  });
  router.use(express.json({ limit: "256kb" }));

  const isHost = (req: express.Request) => {
    const t = req.headers["x-host-token"];
    return typeof t === "string" && safeEq(t, hostToken);
  };
  const needHost: express.RequestHandler = (req, res, next) => {
    if (isHost(req)) return next();
    res.status(401).json({ error: "token_guru_salah" });
  };

  router.get("/health", (_req, res) => {
    res.json({ ok: true, soal: bank.length, durasi_menit: config.durasi_menit, sesi: reg.list().length });
  });

  /** Token guru hanya diberikan kepada permintaan dari laptop server itu sendiri (loopback). */
  router.get("/api/host-token", (req, res) => {
    const ip = req.socket.remoteAddress ?? "";
    // Lewat gerbang/proxy (ada X-Forwarded-For dsb.) alamat soket selalu loopback, jadi tolak: token hanya untuk akses langsung.
    if (viaProxy(req.headers) || !["127.0.0.1", "::1", "::ffff:127.0.0.1"].includes(ip))
      return void res.status(403).json({ error: "hanya_dari_laptop_guru" });
    res.json({ token: hostToken });
  });

  /** Alamat LAN laptop ini, untuk QR di layar proyektor yang dibuka lewat localhost. */
  router.get("/api/lan", (_req, res) => {
    res.json({ urls: lanUrls(Number(process.env.PORT ?? PORT), base) });
  });

  router.post("/api/sessions", needHost, (req, res) => {
    const p = rosterBody.safeParse(req.body);
    if (!p.success)
      return void res.status(400).json({ error: "data_tidak_valid", detail: p.error.issues.map((i) => i.message) });
    const ids = new Set(p.data.roster.map((r) => r.id));
    if (ids.size !== p.data.roster.length) return void res.status(400).json({ error: "id_siswa_ganda" });
    const s = reg.create({
      className: p.data.className,
      roster: p.data.roster.map((r) => ({ id: r.id, name: r.name, absen: r.absen ?? null })),
      ...(p.data.autoApprove !== undefined ? { autoApprove: p.data.autoApprove } : {}),
      ...(p.data.seed !== undefined ? { seed: p.data.seed } : {}),
    });
    res.status(201).json({ id: s.id, code: s.code, className: s.className });
  });

  router.get("/api/sessions", needHost, (_req, res) => {
    res.json(
      reg.list().map((s) => ({
        id: s.id,
        code: s.code,
        className: s.className,
        phase: s.state.phase,
        students: s.roster.length,
      })),
    );
  });

  router.get("/api/sessions/:id/pins", needHost, (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    res.json({
      code: s.code,
      className: s.className,
      pin: s.currentPin(),
      expiresAt: s.pinExpiresAt(),
      cards: s.roster.map((r) => ({ id: r.id, name: r.name, absen: r.absen ?? null, pin: s.currentPin() })),
    });
  });

  /** Log audit berantai hash untuk guru: dapat diekspor, diputar ulang, dan diverifikasi (SPEC §5.3). */
  router.get("/api/sessions/:id/log", needHost, (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    const rows = store.db
      .prepare(
        "SELECT seq, ts, type, actor_id, prev_hash, hash, payload_json FROM events WHERE session_id = ? ORDER BY seq",
      )
      .all(s.id) as { payload_json: string }[];
    res.json({
      sessionId: s.id,
      chainBrokenAtSeq: store.verifyChain(s.id),
      events: rows.map((r) => ({ ...r, payload_json: undefined, payload: JSON.parse(r.payload_json) as unknown })),
      flags: s.flagList(),
    });
  });

  /** Naskah rekaman VO untuk guru (frasa tetap, 80 sel, nama murid). */
  router.get("/api/sessions/:id/vo-script", needHost, (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    res.json(s.voScript());
  });

  /** Laporan lengkap untuk guru (rapor, heatmap, analisis butir). */
  router.get("/api/sessions/:id/report.json", needHost, (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    res.json(s.report());
  });

  /** Ekspor CSV (butir, murid, percobaan mentah) untuk guru. */
  router.get("/api/sessions/:id/:file(attempts.csv|students.csv|items.csv)", needHost, (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    const file = String(req.params.file);
    const r = s.report();
    const body =
      file === "attempts.csv"
        ? attemptsCsv(buildAttempts(store.listDeliveries(s.id), bank), s.attemptNames())
        : file === "students.csv"
          ? studentsCsv(r)
          : itemsCsv(r);
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="claim80-${s.code}-${file}"`);
    res.send(body);
  });

  /**
   * Ringkasan hasil per siswa untuk SIMPETERI (Multi Permainan). Tanpa token karena dipanggil dari browser SIMPETERI;
   * URL berisi id sesi yang tidak bisa ditebak, hanya tersedia setelah permainan selesai, dan CORS dibatasi ke ALLOWED_ORIGINS.
   */
  router.get("/api/sessions/:id/summary.json", (req, res) => {
    const s = reg.get(String(req.params.id));
    if (!s) return void res.status(404).json({ error: "tidak_ada" });
    if (!s.hasEnded && !isHost(req)) {
      return void res
        .status(403)
        .json({ error: "belum_selesai", message: "Hasil tersedia setelah permainan selesai." });
    }
    res.json(summaryJson(s.report()));
  });

  /** Info publik untuk layar masuk murid: nama kelas dan daftar nama (tanpa PIN). */
  router.get("/api/join/:code", (req, res) => {
    const s = reg.byCode(String(req.params.code));
    if (!s) return void res.status(404).json({ error: "kode_salah" });
    res.json({
      sessionId: s.id,
      className: s.className,
      phase: s.state.phase,
      students: s.roster.map((r) => ({ id: r.id, name: r.name, absen: r.absen ?? null })),
    });
  });

  const dist = opt.distDir ?? fileURLToPath(new URL("../../client/dist", import.meta.url));
  if (existsSync(dist)) {
    router.use(express.static(dist));
    router.get(/^\/(?!socket\.io|health|api).*/, (_req, res) => res.sendFile(`${dist}/index.html`));
  }

  app.use(base || "/", router);

  const close = () => {
    reg.stop();
    io.close();
    store.close();
  };
  return { app, http, io, registry: reg, store, hostToken, base, close };
}

export function lanUrls(port: number, base = ""): string[] {
  const out: string[] = [];
  for (const list of Object.values(networkInterfaces())) {
    for (const i of list ?? []) if (i.family === "IPv4" && !i.internal) out.push(`http://${i.address}:${port}${base}`);
  }
  return out;
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const { http, hostToken, base } = createApp();
  http.listen(PORT, "0.0.0.0", () => {
    console.log(`CLAIM 80 berjalan di http://localhost:${PORT}${base}`);
    for (const u of lanUrls(PORT, base)) console.log(`  LAN: ${u}`);
    console.log(`Token guru: ${hostToken}`);
  });
}

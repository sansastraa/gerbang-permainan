import { createHash } from "node:crypto";
import { mkdirSync } from "node:fs";
import { dirname } from "node:path";
import Database from "better-sqlite3";
import type { Action, GameEvent, RosterEntry } from "@claim80/shared";

export interface SessionOptions {
  autoApprove: boolean;
  /** kolom yang selalu memakai soal acak dari generator */
  alwaysRandom?: string[];
  stationMode?: boolean;
  /** pengaturan guru (hanya bisa diubah di lobi) */
  durasiMenit?: number;
  pengaliWaktu?: number;
  waktuMin?: number;
  jedaSetiap?: number;
  jedaDetik?: number;
}

export interface SessionRow {
  id: string;
  code: string;
  className: string;
  seed: number;
  roster: RosterEntry[];
  /** PIN 4 digit per siswa (disimpan agar Kartu PIN dapat dicetak ulang; ini alat kelas lokal) */
  pins: Record<string, string>;
  options: SessionOptions;
  createdAt: number;
  endedAt: number | null;
}

export interface LoggedAction {
  seq: number;
  ts: number;
  action: Action;
  events: GameEvent[];
}

const SCHEMA = `
CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY, code TEXT UNIQUE NOT NULL, class_name TEXT NOT NULL, seed INTEGER NOT NULL,
  roster_json TEXT NOT NULL, pins_json TEXT NOT NULL, options_json TEXT NOT NULL,
  created_at INTEGER NOT NULL, ended_at INTEGER
);
CREATE TABLE IF NOT EXISTS events (
  seq INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, ts INTEGER NOT NULL, type TEXT NOT NULL,
  actor_id TEXT, payload_json TEXT NOT NULL, prev_hash TEXT NOT NULL, hash TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS events_session ON events(session_id, seq);
CREATE TABLE IF NOT EXISTS flags (
  id INTEGER PRIMARY KEY AUTOINCREMENT, session_id TEXT NOT NULL, student_id TEXT, type TEXT NOT NULL,
  severity TEXT NOT NULL, detail_json TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'open', created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS deliveries (
  id TEXT PRIMARY KEY, session_id TEXT NOT NULL, cell TEXT NOT NULL, student_id TEXT NOT NULL, question_id TEXT NOT NULL,
  mode TEXT NOT NULL, sent_at INTEGER NOT NULL, deadline INTEGER NOT NULL, answered_at INTEGER, answer_raw TEXT,
  correct INTEGER, focus_lost_count INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS vo_names (
  session_id TEXT NOT NULL, student_id TEXT NOT NULL, name TEXT NOT NULL, PRIMARY KEY (session_id, student_id)
);
CREATE TABLE IF NOT EXISTS xp_awards (
  session_id TEXT NOT NULL, student_id TEXT NOT NULL, xp INTEGER NOT NULL, PRIMARY KEY (session_id, student_id)
);
CREATE TABLE IF NOT EXISTS student_badges (
  student_id TEXT NOT NULL, badge_id TEXT NOT NULL, session_id TEXT NOT NULL, ts INTEGER NOT NULL,
  PRIMARY KEY (student_id, badge_id, session_id)
);
CREATE TABLE IF NOT EXISTS students (
  id TEXT PRIMARY KEY, name TEXT NOT NULL, class_name TEXT, xp INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL
);
`;

export const GENESIS = "GENESIS";

export function hashEvent(
  prevHash: string,
  ts: number,
  type: string,
  actorId: string | null,
  payloadJson: string,
): string {
  return createHash("sha256")
    .update(`${prevHash}|${ts}|${type}|${actorId ?? ""}|${payloadJson}`)
    .digest("hex");
}

export class Store {
  readonly db: Database.Database;

  constructor(path: string) {
    if (path !== ":memory:") mkdirSync(dirname(path), { recursive: true });
    this.db = new Database(path);
    this.db.pragma("journal_mode = WAL");
    this.db.exec(SCHEMA);
  }

  close() {
    this.db.close();
  }

  insertSession(r: SessionRow) {
    this.db
      .prepare(
        `INSERT INTO sessions (id, code, class_name, seed, roster_json, pins_json, options_json, created_at, ended_at)
         VALUES (?,?,?,?,?,?,?,?,?)`,
      )
      .run(
        r.id,
        r.code,
        r.className,
        r.seed,
        JSON.stringify(r.roster),
        JSON.stringify(r.pins),
        JSON.stringify(r.options),
        r.createdAt,
        r.endedAt,
      );
  }

  setOptions(id: string, options: SessionOptions) {
    this.db.prepare("UPDATE sessions SET options_json = ? WHERE id = ?").run(JSON.stringify(options), id);
  }

  markEnded(id: string, ts: number) {
    this.db.prepare("UPDATE sessions SET ended_at = ? WHERE id = ?").run(ts, id);
  }

  listSessions(): SessionRow[] {
    const rows = this.db.prepare("SELECT * FROM sessions ORDER BY created_at").all() as Record<string, unknown>[];
    return rows.map((r) => ({
      id: r.id as string,
      code: r.code as string,
      className: r.class_name as string,
      seed: r.seed as number,
      roster: JSON.parse(r.roster_json as string) as RosterEntry[],
      pins: JSON.parse(r.pins_json as string) as Record<string, string>,
      options: JSON.parse(r.options_json as string) as SessionOptions,
      createdAt: r.created_at as number,
      endedAt: (r.ended_at as number | null) ?? null,
    }));
  }

  /** Menambah satu entri ke log append-only berantai hash. */
  appendAction(sessionId: string, ts: number, action: Action, events: GameEvent[]): number {
    const last = this.db
      .prepare("SELECT hash FROM events WHERE session_id = ? ORDER BY seq DESC LIMIT 1")
      .get(sessionId) as { hash: string } | undefined;
    const prev = last?.hash ?? GENESIS;
    const payload = JSON.stringify({ action, events });
    const actor = "playerId" in action ? action.playerId : null;
    const hash = hashEvent(prev, ts, action.type, actor, payload);
    const r = this.db
      .prepare(
        "INSERT INTO events (session_id, ts, type, actor_id, payload_json, prev_hash, hash) VALUES (?,?,?,?,?,?,?)",
      )
      .run(sessionId, ts, action.type, actor, payload, prev, hash);
    return Number(r.lastInsertRowid);
  }

  readActions(sessionId: string): LoggedAction[] {
    const rows = this.db
      .prepare("SELECT seq, ts, payload_json FROM events WHERE session_id = ? ORDER BY seq")
      .all(sessionId) as {
      seq: number;
      ts: number;
      payload_json: string;
    }[];
    return rows.map((r) => {
      const p = JSON.parse(r.payload_json) as { action: Action; events: GameEvent[] };
      return { seq: r.seq, ts: r.ts, action: p.action, events: p.events };
    });
  }

  /** Memeriksa rantai hash; mengembalikan seq pertama yang rusak atau null bila utuh. */
  verifyChain(sessionId: string): number | null {
    const rows = this.db
      .prepare(
        "SELECT seq, ts, type, actor_id, payload_json, prev_hash, hash FROM events WHERE session_id = ? ORDER BY seq",
      )
      .all(sessionId) as {
      seq: number;
      ts: number;
      type: string;
      actor_id: string | null;
      payload_json: string;
      prev_hash: string;
      hash: string;
    }[];
    let prev = GENESIS;
    for (const r of rows) {
      if (r.prev_hash !== prev || hashEvent(prev, r.ts, r.type, r.actor_id, r.payload_json) !== r.hash) return r.seq;
      prev = r.hash;
    }
    return null;
  }

  /** XP lintas sesi (SPEC §4.8). Satu kali per sesi per murid; mengembalikan total XP baru, atau null bila sudah pernah dicatat. */
  awardXp(
    sessionId: string,
    studentId: string,
    name: string,
    className: string,
    xp: number,
    ts: number,
  ): number | null {
    const ins = this.db
      .prepare("INSERT OR IGNORE INTO xp_awards (session_id, student_id, xp) VALUES (?,?,?)")
      .run(sessionId, studentId, xp);
    if (ins.changes === 0) return null;
    this.db
      .prepare(
        `INSERT INTO students (id, name, class_name, xp, created_at) VALUES (?,?,?,?,?)
         ON CONFLICT(id) DO UPDATE SET xp = xp + excluded.xp, name = excluded.name, class_name = excluded.class_name`,
      )
      .run(studentId, name, className, xp, ts);
    return this.getXp(studentId);
  }

  setVoName(sessionId: string, studentId: string, name: string) {
    this.db
      .prepare(
        `INSERT INTO vo_names (session_id, student_id, name) VALUES (?,?,?)
         ON CONFLICT(session_id, student_id) DO UPDATE SET name = excluded.name`,
      )
      .run(sessionId, studentId, name);
  }

  listVoNames(sessionId: string): Record<string, string> {
    const rows = this.db.prepare("SELECT student_id, name FROM vo_names WHERE session_id = ?").all(sessionId) as {
      student_id: string;
      name: string;
    }[];
    return Object.fromEntries(rows.map((r) => [r.student_id, r.name]));
  }

  getXp(studentId: string): number {
    const r = this.db.prepare("SELECT xp FROM students WHERE id = ?").get(studentId) as { xp: number } | undefined;
    return r?.xp ?? 0;
  }

  addBadges(sessionId: string, studentId: string, ids: string[], ts: number) {
    const st = this.db.prepare(
      "INSERT OR IGNORE INTO student_badges (student_id, badge_id, session_id, ts) VALUES (?,?,?,?)",
    );
    for (const id of ids) st.run(studentId, id, sessionId, ts);
  }

  studentBadges(studentId: string): string[] {
    return (
      this.db.prepare("SELECT DISTINCT badge_id FROM student_badges WHERE student_id = ?").all(studentId) as {
        badge_id: string;
      }[]
    ).map((r) => r.badge_id);
  }

  listDeliveries(sessionId: string) {
    return this.db
      .prepare(
        "SELECT id, cell, student_id, question_id, mode, sent_at, deadline, answered_at, answer_raw, correct, focus_lost_count FROM deliveries WHERE session_id = ? AND answered_at IS NOT NULL ORDER BY sent_at",
      )
      .all(sessionId) as {
      id: string;
      cell: string;
      student_id: string;
      question_id: string;
      mode: string;
      sent_at: number;
      deadline: number;
      answered_at: number;
      answer_raw: string | null;
      correct: number | null;
      focus_lost_count: number;
    }[];
  }

  insertFlag(
    sessionId: string,
    studentId: string | null,
    type: string,
    severity: string,
    detail: unknown,
    ts: number,
  ): number {
    const r = this.db
      .prepare(
        "INSERT INTO flags (session_id, student_id, type, severity, detail_json, created_at) VALUES (?,?,?,?,?,?)",
      )
      .run(sessionId, studentId, type, severity, JSON.stringify(detail), ts);
    return Number(r.lastInsertRowid);
  }

  listFlags(sessionId: string) {
    return this.db.prepare("SELECT * FROM flags WHERE session_id = ? ORDER BY id").all(sessionId) as {
      id: number;
      student_id: string | null;
      type: string;
      severity: string;
      detail_json: string;
      status: string;
      created_at: number;
    }[];
  }

  setFlagStatus(id: number, status: string) {
    this.db.prepare("UPDATE flags SET status = ? WHERE id = ?").run(status, id);
  }

  upsertDelivery(d: {
    id: string;
    sessionId: string;
    cell: string;
    studentId: string;
    questionId: string;
    mode: string;
    sentAt: number;
    deadline: number;
  }) {
    this.db
      .prepare(
        `INSERT OR REPLACE INTO deliveries (id, session_id, cell, student_id, question_id, mode, sent_at, deadline)
         VALUES (?,?,?,?,?,?,?,?)`,
      )
      .run(d.id, d.sessionId, d.cell, d.studentId, d.questionId, d.mode, d.sentAt, d.deadline);
  }

  finishDelivery(id: string, ts: number, raw: string, correct: boolean, focusLost: number) {
    this.db
      .prepare("UPDATE deliveries SET answered_at = ?, answer_raw = ?, correct = ?, focus_lost_count = ? WHERE id = ?")
      .run(ts, raw, correct ? 1 : 0, focusLost, id);
  }
}

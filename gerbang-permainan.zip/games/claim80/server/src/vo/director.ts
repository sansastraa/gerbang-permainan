import { z } from "zod";
import type { VoMode, VoPlay, VoPrioritas, VoSettings } from "@claim80/shared";
import { PRIORITAS_URUT, fillTemplate } from "./naskah";
import type { Naskah, VoParams } from "./naskah";

const voConfigSchema = z
  .object({
    mode: z.enum(["semua", "penting_dan_klaim", "penting_saja", "mati"]).default("penting_dan_klaim"),
    kecepatan: z.number().default(1.05),
    nada: z.number().default(1.1),
    volume: z.number().default(1),
    jeda_antar_vo_ms: z.number().default(400),
    gabung_jika_antre_min: z.number().default(3),
    kedaluwarsa_ms: z
      .object({ rendah: z.number(), normal: z.number(), tinggi: z.number() })
      .default({ rendah: 6000, normal: 8000, tinggi: 15000 }),
  })
  .passthrough();
export type VoConfig = z.infer<typeof voConfigSchema>;

export interface VoEventInput {
  key: string;
  params?: VoParams;
  studentId?: string;
  sorotSel?: string;
  /** timpa batas kedaluwarsa (mis. hitung mundur yang cepat basi) */
  expireMs?: number;
}

export interface DirectorOptions {
  naskah: Naskah;
  config: unknown;
  clock: () => number;
  /** kirim perintah putar ke proyektor */
  emit: (p: VoPlay) => void;
  /** VO dibuang (kedaluwarsa / dibatasi / disaring mode) sehingga hanya muncul di ticker */
  onDrop?: (key: string, why: "kedaluwarsa" | "dibatasi" | "mode") => void;
  rng?: () => number;
}

interface Item {
  key: string;
  prioritas: VoPrioritas;
  play: VoPlay;
  createdAt: number;
  expireAt: number;
  studentId?: string;
  /** hanya untuk klaim rendah yang boleh digabung */
  mergeable: boolean;
  cellSpoken?: string;
}

const SAFETY_MS = 15_000;
const LIMIT_WINDOW_MS = 20_000;
const LIMIT_MAX = 2;

/** Antrean VO di server: prioritas, penggabungan, kedaluwarsa, pembatasan sebut murid (SPEC §7a.4). */
export class VoDirector {
  readonly settings: VoSettings;
  private cfg: VoConfig;
  private queue: Item[] = [];
  private current: { item: Item; since: number } | null = null;
  private nextAt = 0;
  private seq = 0;
  private lastVariant = new Map<string, number>();
  private mentions = new Map<string, number[]>();
  private rng: () => number;

  constructor(private o: DirectorOptions) {
    this.cfg = voConfigSchema.parse(o.config);
    this.rng = o.rng ?? Math.random;
    this.settings = {
      mode: this.cfg.mode,
      volume: this.cfg.volume,
      kecepatan: this.cfg.kecepatan,
      nada: this.cfg.nada,
      subtitle: true,
    };
  }

  setSettings(p: Partial<Pick<VoSettings, "mode" | "volume" | "kecepatan" | "nada">>) {
    if (p.mode) this.settings.mode = p.mode;
    if (p.volume !== undefined) this.settings.volume = Math.min(1, Math.max(0, p.volume));
    if (p.kecepatan !== undefined) this.settings.kecepatan = Math.min(1.6, Math.max(0.6, p.kecepatan));
    if (p.nada !== undefined) this.settings.nada = Math.min(2, Math.max(0.5, p.nada));
    if (this.settings.mode === "mati") {
      this.queue = [];
    }
  }

  get pending(): number {
    return this.queue.length;
  }

  get speakingId(): string | null {
    return this.current?.item.play.id ?? null;
  }

  private allowed(key: string, pr: VoPrioritas, mode: VoMode): boolean {
    if (mode === "mati") return false;
    if (mode === "semua") return true;
    if (mode === "penting_saja") return pr === "tinggi";
    return key.startsWith("klaim") || key === "gabungan" || pr === "tinggi";
  }

  private pickVariant(key: string, n: number): number {
    if (n === 1) return 0;
    const last = this.lastVariant.get(key);
    let i = Math.floor(this.rng() * n);
    if (i === last) i = (i + 1) % n;
    this.lastVariant.set(key, i);
    return i;
  }

  /** Mengantrekan satu VO. Mengembalikan false bila dibuang (mode, pembatasan). Tidak pernah dipanggil untuk jawaban salah. */
  enqueue(input: VoEventInput): boolean {
    const ev = this.o.naskah.event[input.key];
    if (!ev) throw new Error(`Event VO tidak dikenal: ${input.key}`);
    const now = this.o.clock();
    if (!this.allowed(input.key, ev.prioritas, this.settings.mode)) {
      this.o.onDrop?.(input.key, "mode");
      return false;
    }
    if (ev.prioritas === "rendah" && input.studentId) {
      const recent = (this.mentions.get(input.studentId) ?? []).filter((t) => now - t < LIMIT_WINDOW_MS);
      if (recent.length >= LIMIT_MAX) {
        this.o.onDrop?.(input.key, "dibatasi");
        return false;
      }
      recent.push(now);
      this.mentions.set(input.studentId, recent);
    }
    const tpl = ev.varian[this.pickVariant(input.key, ev.varian.length)]!;
    const { teks, segmen } = fillTemplate(tpl, input.params ?? {});
    const exp = input.expireMs ?? this.cfg.kedaluwarsa_ms[ev.prioritas];
    const item: Item = {
      key: input.key,
      prioritas: ev.prioritas,
      createdAt: now,
      expireAt: now + exp,
      mergeable: input.key === "klaim_l1_3",
      ...(input.studentId ? { studentId: input.studentId } : {}),
      ...(input.params?.sel ? { cellSpoken: input.params.sel } : {}),
      play: {
        id: `vo${++this.seq}`,
        teks,
        segmen,
        jingle: this.o.naskah.jingle[ev.jingle] ?? ev.jingle,
        prioritas: ev.prioritas,
        ...(input.sorotSel ? { sorotSel: input.sorotSel } : {}),
        ...(input.studentId ? { studentId: input.studentId } : {}),
        minMs: Math.max(2200, teks.length * 55),
      },
    };
    this.queue.push(item);
    this.merge();
    this.pump();
    return true;
  }

  /** Gabungkan klaim rendah yang menumpuk menjadi satu pengumuman. */
  private merge() {
    const minCount = this.cfg.gabung_jika_antre_min;
    const lows = this.queue.filter((q) => q.mergeable);
    if (lows.length < minCount) return;
    const ev = this.o.naskah.event["gabungan"];
    if (!ev) return;
    const cells = lows.map((l) => l.cellSpoken ?? "").filter(Boolean);
    const daftar =
      cells.length > 1 ? `${cells.slice(0, -1).join(", ")}, dan ${cells[cells.length - 1]}` : (cells[0] ?? "");
    const now = this.o.clock();
    const tpl = ev.varian[this.pickVariant("gabungan", ev.varian.length)]!;
    const { teks, segmen } = fillTemplate(tpl, { n: lows.length, daftar });
    const merged: Item = {
      key: "gabungan",
      prioritas: "rendah",
      createdAt: now,
      expireAt: now + this.cfg.kedaluwarsa_ms.rendah,
      mergeable: false,
      play: {
        id: `vo${++this.seq}`,
        teks,
        segmen,
        jingle: this.o.naskah.jingle[ev.jingle] ?? ev.jingle,
        prioritas: "rendah",
        minMs: Math.max(2600, teks.length * 55),
      },
    };
    this.queue = this.queue.filter((q) => !q.mergeable);
    this.queue.push(merged);
  }

  /** Proyektor selesai membacakan. */
  done(id: string) {
    if (this.current?.item.play.id !== id) return;
    this.current = null;
    this.nextAt = this.o.clock() + this.cfg.jeda_antar_vo_ms;
    this.pump();
  }

  /** Dipanggil oleh loop 250 ms: buang yang kedaluwarsa, putus VO macet, mulai berikutnya. */
  tick() {
    const now = this.o.clock();
    const keep: Item[] = [];
    for (const q of this.queue) {
      if (q.expireAt < now) this.o.onDrop?.(q.key, "kedaluwarsa");
      else keep.push(q);
    }
    this.queue = keep;
    if (this.current && now - this.current.since > SAFETY_MS) {
      this.current = null;
      this.nextAt = now;
    }
    this.pump();
  }

  private pump() {
    if (this.current || this.queue.length === 0) return;
    const now = this.o.clock();
    if (now < this.nextAt) return;
    this.queue.sort((a, b) => PRIORITAS_URUT[a.prioritas] - PRIORITAS_URUT[b.prioritas] || a.createdAt - b.createdAt);
    const item = this.queue.shift()!;
    this.current = { item, since: now };
    this.o.emit(item.play);
  }
}

import { describe, expect, it } from "vitest";
import type { VoPlay } from "@claim80/shared";
import { loadConfig } from "../questions/bank";
import { VoDirector } from "./director";
import { fillTemplate, fixedPhrases, loadNaskah, spokenCell } from "./naskah";

const naskah = loadNaskah();
const cfg = loadConfig();

function make(mode?: string, rng?: () => number) {
  let now = 1_000_000;
  const played: VoPlay[] = [];
  const drops: string[] = [];
  const d = new VoDirector({
    naskah,
    config: { ...cfg.voice_over, ...(mode ? { mode } : {}) },
    clock: () => now,
    emit: (p) => played.push(p),
    onDrop: (k, why) => drops.push(`${k}:${why}`),
    ...(rng ? { rng } : {}),
  });
  const claim = (id: string, cell: string, key = "klaim_l1_3", nama = id) =>
    d.enqueue({ key, studentId: id, sorotSel: cell, params: { nama, namaId: id, sel: spokenCell(naskah, cell) } });
  return {
    d,
    played,
    drops,
    claim,
    advance(ms: number) {
      now += ms;
      d.tick();
    },
    finish() {
      if (d.speakingId) d.done(d.speakingId);
    },
  };
}

describe("naskah", () => {
  it("sel diucapkan sebagai huruf + angka kata", () => {
    expect(spokenCell(naskah, "E6")).toBe("E enam");
    expect(spokenCell(naskah, "J8")).toBe("Je delapan");
    expect(spokenCell(naskah, "B2")).toBe("Be dua");
  });
  it("templat dipecah menjadi segmen nama / sel / teks", () => {
    const r = fillTemplate("{nama} telah mengklaim kartu {sel}!", { nama: "Rina", namaId: "s1", sel: "E enam" });
    expect(r.teks).toBe("Rina telah mengklaim kartu E enam!");
    expect(r.segmen).toEqual([
      { k: "nama", v: "Rina", id: "s1" },
      { k: "teks", v: " telah mengklaim kartu " },
      { k: "sel", v: "E enam" },
      { k: "teks", v: "!" },
    ]);
  });
  it("daftar frasa tetap untuk direkam guru tidak kosong dan tanpa placeholder", () => {
    const f = fixedPhrases(naskah);
    expect(f.length).toBeGreaterThan(20);
    expect(f.some((x) => x.includes("{"))).toBe(false);
  });
});

describe("VoDirector", () => {
  it("VO pertama diputar langsung (< 1 detik) dan hanya satu pada satu waktu", () => {
    const t = make();
    t.claim("a", "E6", "klaim_l4_6", "Rina");
    expect(t.played).toHaveLength(1);
    expect(t.played[0]!.teks).toContain("Rina");
    expect(t.played[0]!.sorotSel).toBe("E6");
    t.claim("b", "A1", "klaim_l4_6", "Budi");
    expect(t.played).toHaveLength(1);
    t.finish();
    expect(t.played).toHaveLength(1); // jeda 400 ms
    t.advance(450);
    expect(t.played).toHaveLength(2);
  });

  it("prioritas tinggi menyalip antrean tetapi tidak memotong yang sedang berbicara", () => {
    const t = make();
    t.claim("a", "A1");
    const first = t.played[0]!.id;
    t.claim("b", "B2");
    t.claim("c", "C3", "klaim_l4_6");
    t.d.enqueue({ key: "emas", studentId: "d", sorotSel: "G7", params: { nama: "Dewi", sel: "Ge tujuh" } });
    expect(t.played).toHaveLength(1);
    t.d.done(first);
    t.advance(450);
    expect(t.played[1]!.prioritas).toBe("tinggi");
    t.finish();
    t.advance(450);
    expect(t.played[2]!.prioritas).toBe("normal");
  });

  it("10 klaim rendah dalam 3 detik → VO gabungan, bukan 10 VO berturut-turut (DoD 12)", () => {
    const t = make();
    for (let i = 0; i < 10; i++) {
      t.claim(`s${i}`, `${"ABCDEFGHIJ"[i]}1`, "klaim_l1_3", `Siswa${i}`);
      t.advance(300);
    }
    // total VO yang pernah diputar sampai antrean habis
    for (let n = 0; n < 5 && t.d.pending + (t.d.speakingId ? 1 : 0) > 0; n++) {
      t.finish();
      t.advance(450);
    }
    expect(t.played.length).toBeLessThan(5);
    const merged = t.played.find((p) => /kartu baru terklaim|Papan makin ramai/.test(p.teks));
    expect(merged).toBeDefined();
    expect(merged!.teks).toMatch(/Be satu/);
    expect(merged!.teks).toMatch(/dan /);
  });

  it("kedaluwarsa: rendah 6 dtk, normal 8 dtk, tinggi 15 dtk; yang basi dibuang ke ticker", () => {
    const t = make();
    t.claim("a", "A1"); // sedang bicara
    t.d.enqueue({ key: "klaim_l4_6", studentId: "b", params: { nama: "B", sel: "x" } });
    t.d.enqueue({ key: "fase_battle" });
    t.d.enqueue({ key: "klaim_l1_3", studentId: "c", params: { nama: "C", sel: "y" } });
    t.advance(6100);
    expect(t.drops).toContain("klaim_l1_3:kedaluwarsa");
    expect(t.drops).not.toContain("klaim_l4_6:kedaluwarsa");
    t.advance(2000);
    expect(t.drops).toContain("klaim_l4_6:kedaluwarsa");
    expect(t.drops).not.toContain("fase_battle:kedaluwarsa");
    t.advance(7000);
    expect(t.drops).toContain("fase_battle:kedaluwarsa");
  });

  it("satu murid tidak disebut lebih dari 2 kali dalam 20 detik pada prioritas rendah", () => {
    const t = make();
    expect(t.claim("a", "A1")).toBe(true);
    expect(t.claim("a", "B1")).toBe(true);
    expect(t.claim("a", "C1")).toBe(false);
    expect(t.drops).toContain("klaim_l1_3:dibatasi");
    t.advance(21_000);
    expect(t.claim("a", "D1")).toBe(true);
    // prioritas tinggi tidak dibatasi
    expect(t.d.enqueue({ key: "emas", studentId: "a", params: { nama: "A", sel: "x" } })).toBe(true);
  });

  it("mode: semua / penting_dan_klaim / penting_saja / mati", () => {
    const run = (mode: string) => {
      const t = make(mode);
      t.finish();
      const r = {
        l13: t.d.enqueue({ key: "klaim_l1_3", params: { nama: "A", sel: "x" } }),
        l46: t.d.enqueue({ key: "klaim_l4_6", params: { nama: "A", sel: "x" } }),
        rebutMulai: t.d.enqueue({ key: "rebut_mulai", params: { nama: "A", pemilik: "B", sel: "x" } }),
        fase: t.d.enqueue({ key: "fase_rush" }),
      };
      return r;
    };
    expect(run("semua")).toEqual({ l13: true, l46: true, rebutMulai: true, fase: true });
    expect(run("penting_dan_klaim")).toEqual({ l13: true, l46: true, rebutMulai: false, fase: true });
    expect(run("penting_saja")).toEqual({ l13: false, l46: false, rebutMulai: false, fase: true });
    expect(run("mati")).toEqual({ l13: false, l46: false, rebutMulai: false, fase: false });
  });

  it("varian tidak sama dengan varian terakhir untuk event yang sama", () => {
    const t = make(undefined, () => 0); // rng selalu memilih indeks 0
    const texts: string[] = [];
    for (let i = 0; i < 6; i++) {
      t.d.enqueue({ key: "klaim_l7", studentId: `s${i}`, params: { nama: "X", sel: "E tujuh" } });
      texts.push(t.played.at(-1)!.teks);
      t.finish();
      t.advance(450);
    }
    for (let i = 1; i < texts.length; i++) expect(texts[i]).not.toBe(texts[i - 1]);
  });

  it("VO yang macet dilepas otomatis setelah batas pengaman", () => {
    const t = make();
    t.claim("a", "A1");
    t.d.enqueue({ key: "klaim_l4_6", studentId: "b", expireMs: 60_000, params: { nama: "B", sel: "x" } });
    t.advance(16_000);
    expect(t.played.length).toBeGreaterThanOrEqual(2);
  });

  it("pengaturan dapat diubah dan dibatasi; mode mati mengosongkan antrean", () => {
    const t = make();
    t.claim("a", "A1");
    t.claim("b", "B1", "klaim_l4_6");
    t.d.setSettings({ volume: 5, kecepatan: 0.1, mode: "mati" });
    expect(t.d.settings.volume).toBe(1);
    expect(t.d.settings.kecepatan).toBe(0.6);
    expect(t.d.pending).toBe(0);
  });
});

import { readFileSync } from "node:fs";
import { z } from "zod";
import type { VoPrioritas, VoSegmen } from "@claim80/shared";

const eventSchema = z.object({
  prioritas: z.enum(["rendah", "normal", "tinggi"]),
  jingle: z.string(),
  varian: z.array(z.string().min(1)).min(1),
});

export const naskahSchema = z.object({
  ucapan_kolom: z.record(z.string(), z.string()),
  ucapan_baris: z.record(z.string(), z.string()),
  jingle: z.record(z.string(), z.string()),
  event: z.record(z.string(), eventSchema),
});
export type Naskah = z.infer<typeof naskahSchema>;
export type NaskahEvent = z.infer<typeof eventSchema>;

export function loadNaskah(path = "config/vo_naskah.json"): Naskah {
  const raw = JSON.parse(readFileSync(new URL(`../../../${path}`, import.meta.url), "utf8")) as unknown;
  return naskahSchema.parse(raw);
}

/** "E6" → "E enam", "J8" → "Je delapan" (SPEC §7a.3). */
export function spokenCell(n: Naskah, cell: string): string {
  const col = n.ucapan_kolom[cell[0] ?? ""] ?? cell[0] ?? "";
  const row = n.ucapan_baris[cell.slice(1)] ?? cell.slice(1);
  return `${col} ${row}`;
}

export interface VoParams {
  nama?: string;
  namaId?: string;
  pemilik?: string;
  pemilikId?: string;
  sel?: string;
  kolom?: string;
  n?: number;
  daftar?: string;
}

/** Mengisi templat dan memecahnya menjadi segmen (nama / sel / teks) agar rekaman guru bisa disambung. */
export function fillTemplate(tpl: string, p: VoParams): { teks: string; segmen: VoSegmen[] } {
  const segmen: VoSegmen[] = [];
  let teks = "";
  const push = (s: VoSegmen) => {
    teks += s.v;
    const last = segmen[segmen.length - 1];
    if (s.k === "teks" && last?.k === "teks") last.v += s.v;
    else segmen.push(s);
  };
  for (const part of tpl.split(/(\{[a-z]+\})/)) {
    const m = /^\{([a-z]+)\}$/.exec(part);
    if (!m) {
      if (part) push({ k: "teks", v: part });
      continue;
    }
    switch (m[1]) {
      case "nama":
        push({ k: "nama", v: p.nama ?? "teman-teman", ...(p.namaId ? { id: p.namaId } : {}) });
        break;
      case "pemilik":
        push({ k: "nama", v: p.pemilik ?? "temanmu", ...(p.pemilikId ? { id: p.pemilikId } : {}) });
        break;
      case "sel":
        push({ k: "sel", v: p.sel ?? "" });
        break;
      case "kolom":
        push({ k: "teks", v: p.kolom ?? "" });
        break;
      case "n":
        push({ k: "teks", v: String(p.n ?? "") });
        break;
      case "daftar":
        push({ k: "teks", v: p.daftar ?? "" });
        break;
      default:
        push({ k: "teks", v: part });
    }
  }
  return { teks, segmen };
}

/** Semua potongan teks tetap yang perlu direkam guru (templat dipecah di tempat placeholder). */
export function fixedPhrases(n: Naskah): string[] {
  const out = new Set<string>();
  for (const ev of Object.values(n.event)) {
    for (const v of ev.varian) {
      for (const seg of fillTemplate(v, {}).segmen) {
        if (seg.k === "teks" && seg.v.trim()) out.add(seg.v.trim());
      }
    }
  }
  return [...out].sort();
}

export const PRIORITAS_URUT: Record<VoPrioritas, number> = { tinggi: 0, normal: 1, rendah: 2 };

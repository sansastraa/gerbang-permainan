import { z } from "zod";
import type { Server, Socket } from "socket.io";
import type { Action, JoinResult } from "@claim80/shared";
import type { Registry } from "./registry";
import type { GameSession } from "./session";

interface SockData {
  role: "player" | "projector" | "host" | "station";
  sessionId: string;
  studentId?: string;
  hits: number[];
}

const powerUp = z.enum(["50_50", "plus15", "perisai", "streak_saver", "mata_elang", "kunci_emas"]);
const cell = z.string().regex(/^[A-J][1-8]$/);
const schemas = {
  join: z.object({
    sessionCode: z.string().max(12),
    studentId: z.string().max(80),
    pin: z.string().max(8),
    deviceId: z.string().max(80),
  }),
  cell: z.object({ cell }),
  answer: z.object({
    deliveryId: z.string().max(40),
    nonce: z.string().max(40),
    optId: z.string().max(40).optional(),
    value: z.string().max(80).optional(),
  }),
  powerup: z.object({ type: powerUp, cell: cell.optional() }),
  focus: z.object({ deliveryId: z.string().max(40) }),
  student: z.object({ studentId: z.string().max(80) }),
  phase: z.object({ phase: z.enum(["OPEN", "BATTLE", "RUSH", "END"]) }),
  flagResolve: z.object({
    id: z.number().int(),
    action: z.enum(["abaikan", "tindak"]),
    level: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4)]).optional(),
  }),
  voDone: z.object({ id: z.string().max(20) }),
  voStatus: z.object({ engine: z.string().max(60) }),
  voSettings: z.object({
    mode: z.enum(["semua", "penting_dan_klaim", "penting_saja", "mati"]).optional(),
    volume: z.number().min(0).max(1).optional(),
    kecepatan: z.number().min(0.6).max(1.6).optional(),
    nada: z.number().min(0.5).max(2).optional(),
  }),
  voName: z.object({ studentId: z.string().max(80), name: z.string().min(1).max(40) }),
  voTest: z.object({ studentId: z.string().max(80).optional() }),
  gameSettings: z.object({
    durasiMenit: z.number().optional(),
    pengaliWaktu: z.number().optional(),
    waktuMin: z.number().optional(),
    jedaSetiap: z.number().optional(),
    jedaDetik: z.number().optional(),
  }),
  random: z.object({ cols: z.array(z.string().max(1)).max(10) }),
  stationMode: z.object({ on: z.boolean() }),
  stationCall: z.object({ studentId: z.string().max(80).optional() }),
  stationNo: z.object({ no: z.number().int().min(1).max(20) }),
  badge: z.object({ studentId: z.string().max(80), badgeId: z.string().max(40) }),
  sanction: z.object({
    studentId: z.string().max(80),
    level: z.union([z.literal(1), z.literal(2), z.literal(3), z.literal(4)]),
  }),
  freeze: z.object({
    studentId: z.string().max(80),
    frozen: z.boolean(),
    seconds: z.number().positive().max(3600).optional(),
  }),
  adjust: z.object({
    studentId: z.string().max(80),
    delta: z.number().int().min(-1000).max(1000),
    reason: z.string().min(1).max(200),
  }),
};

/** Laju maksimum aksi per socket: 5 permintaan per 10 detik (SPEC §5.1 no. 7). */
function limited(d: SockData, now: number): boolean {
  d.hits = d.hits.filter((t) => now - t < 10_000);
  if (d.hits.length >= 5) return true;
  d.hits.push(now);
  return false;
}

export function attachSockets(io: Server, reg: Registry, hostToken: string, clock: () => number = Date.now) {
  io.on("connection", (socket: Socket) => {
    const auth = (socket.handshake.auth ?? {}) as {
      role?: string;
      sessionId?: string;
      sessionCode?: string;
      hostToken?: string;
    };
    const session: GameSession | undefined =
      (auth.sessionId ? reg.get(auth.sessionId) : undefined) ??
      (auth.sessionCode ? reg.byCode(auth.sessionCode) : undefined);
    if (!session) {
      socket.emit("fatal", { message: "Sesi tidak ditemukan." });
      socket.disconnect(true);
      return;
    }
    const role = auth.role === "host" || auth.role === "projector" || auth.role === "station" ? auth.role : "player";
    if ((role === "host" || role === "station") && auth.hostToken !== hostToken) {
      socket.emit("fatal", { message: "Token guru salah." });
      socket.disconnect(true);
      return;
    }
    const data: SockData = { role, sessionId: session.id, hits: [] };
    socket.data = data;
    socket.join(`session:${session.id}`);
    if (role === "projector") {
      socket.join(session.roomProjector());
      socket.emit("state:snapshot", session.snapshotFor("projector"));
    }
    if (role === "host") {
      socket.join(`host:${session.id}`);
      socket.emit("state:snapshot", session.snapshotFor("host"));
      socket.emit("ticker:backlog", session.ticker);
    }
    if (role === "projector") socket.emit("ticker:backlog", session.ticker);
    if (role === "station") {
      const no = session.registerStation(socket.id);
      socket.emit("station:info", { no, className: session.className, code: session.code });
      socket.emit("station:state", session.stationState());
      socket.emit("session:info", { className: session.className, code: session.code, phase: session.state.phase });
    }
    if (role === "player")
      socket.emit("session:info", { className: session.className, code: session.code, phase: session.state.phase });

    const guard =
      <S extends z.ZodTypeAny>(schema: S, fn: (v: z.infer<S>) => void) =>
      (raw: unknown) => {
        const p = schema.safeParse(raw);
        if (p.success) fn(p.data);
      };
    const player = (fn: (id: string, v: never) => void, schema: z.ZodTypeAny, rate = true) =>
      guard(schema, (v) => {
        if ((data.role !== "player" && data.role !== "station") || !data.studentId) return;
        if (rate && limited(data, clock())) {
          socket.emit("action:rejected", { reason: "rate", message: "Pelan-pelan ya, terlalu banyak ketukan." });
          return;
        }
        fn(data.studentId, v as never);
      });

    if (role === "player" || role === "station") {
      if (role === "player")
        socket.on("join", (raw: unknown, ack?: (r: JoinResult) => void) => {
          const p = schemas.join.safeParse(raw);
          if (!p.success) return ack?.({ ok: false, error: "no_student" });
          const r = session.join(p.data.studentId, p.data.pin, p.data.deviceId);
          if (r.ok) {
            // satu murid = satu socket aktif: socket lama diputus (SPEC §5.1 no. 6)
            for (const other of io.sockets.sockets.values()) {
              const od = other.data as SockData | undefined;
              if (
                other.id !== socket.id &&
                od?.role === "player" &&
                od.sessionId === session.id &&
                od.studentId === p.data.studentId
              ) {
                other.emit("fatal", { message: "Akunmu dipakai di perangkat lain." });
                other.disconnect(true);
                session.reportMultiLogin(p.data.studentId);
              }
            }
            data.studentId = p.data.studentId;
            socket.join(`player:${p.data.studentId}`);
            session.setOnline(p.data.studentId, true);
            if (r.status === "approved") socket.emit("state:snapshot", session.snapshotFor("player", p.data.studentId));
          }
          ack?.(r);
        });
      socket.on(
        "card:open",
        player((id, v: { cell: string }) => session.claim(id, v.cell), schemas.cell),
      );
      socket.on(
        "card:steal",
        player((id, v: { cell: string }) => session.steal(id, v.cell), schemas.cell),
      );
      socket.on(
        "answer:submit",
        player((id, v: z.infer<typeof schemas.answer>) => session.answer(id, v), schemas.answer, false),
      );
      socket.on(
        "powerup:use",
        player((id, v: z.infer<typeof schemas.powerup>) => session.usePowerUp(id, v.type, v.cell), schemas.powerup),
      );
      socket.on(
        "focus:lost",
        player((id, v: z.infer<typeof schemas.focus>) => session.focusLost(id, v.deliveryId), schemas.focus, false),
      );
      socket.on("state:request", () => {
        if (data.studentId) socket.emit("state:snapshot", session.snapshotFor("player", data.studentId));
      });
      socket.on("disconnect", () => {
        if (data.studentId) {
          const still = [...io.sockets.sockets.values()].some(
            (s) =>
              s.id !== socket.id &&
              (s.data as SockData).studentId === data.studentId &&
              (s.data as SockData).sessionId === session.id,
          );
          if (!still) session.setOnline(data.studentId, false);
        }
      });
    }

    if (role === "station") {
      const release = () => {
        if (data.studentId) socket.leave(`player:${data.studentId}`);
        data.studentId = undefined;
        session.releaseStation(socket.id);
        socket.emit("station:released");
      };
      socket.on(
        "station:call",
        guard(schemas.stationCall, (v) => {
          if (data.studentId)
            return socket.emit("station:error", { message: "Selesaikan giliran yang sedang berjalan dulu." });
          const r = session.callStation(socket.id, v.studentId);
          if (!r.ok) return socket.emit("station:error", { message: r.error });
          data.studentId = r.studentId;
          socket.join(`player:${r.studentId}`);
          socket.emit("station:assigned", { studentId: r.studentId });
          socket.emit("state:snapshot", session.snapshotFor("player", r.studentId));
        }),
      );
      socket.on("station:release", release);
      socket.on(
        "station:enqueue",
        guard(schemas.student, (v) => {
          if (!session.enqueue(v.studentId))
            socket.emit("station:error", { message: "Murid itu sudah antre atau sedang di stasiun." });
        }),
      );
      socket.on(
        "station:dequeue",
        guard(schemas.student, (v) => session.dequeue(v.studentId)),
      );
      socket.on("disconnect", () => session.unregisterStation(socket.id));
    }

    if (role === "projector") {
      socket.on("state:request", () => socket.emit("state:snapshot", session.snapshotFor("projector")));
      socket.on(
        "vo:done",
        guard(schemas.voDone, (v) => session.voDone(v.id)),
      );
      socket.on(
        "vo:status",
        guard(schemas.voStatus, (v) => session.setVoEngine(v.engine)),
      );
    }

    if (role === "host") {
      const h = (fn: (v: never) => void, schema: z.ZodTypeAny = z.object({}).passthrough()) =>
        guard(schema, (v) => fn(v as never));
      const doHost = (a: Action) => {
        const events = session.host(a);
        const rej = events.find((e) => e.type === "rejected");
        if (rej) socket.emit("host:rejected", { message: String(rej.data?.message ?? "Aksi ditolak.") });
      };
      socket.on(
        "host:game-settings",
        h((v: z.infer<typeof schemas.gameSettings>) => {
          const patch: Parameters<typeof session.setGameSettings>[0] = {};
          if (v.durasiMenit !== undefined) patch.durasiMenit = v.durasiMenit;
          if (v.pengaliWaktu !== undefined) patch.pengaliWaktu = v.pengaliWaktu;
          if (v.waktuMin !== undefined) patch.waktuMin = v.waktuMin;
          if (v.jedaSetiap !== undefined) patch.jedaSetiap = v.jedaSetiap;
          if (v.jedaDetik !== undefined) patch.jedaDetik = v.jedaDetik;
          const err = session.setGameSettings(patch);
          socket.emit("host:rejected", { message: err ?? "Pengaturan disimpan." });
        }, schemas.gameSettings),
      );
      socket.on(
        "host:random",
        h((v: z.infer<typeof schemas.random>) => session.setAlwaysRandom(v.cols), schemas.random),
      );
      socket.on(
        "host:station-mode",
        h((v: z.infer<typeof schemas.stationMode>) => session.setStationMode(v.on), schemas.stationMode),
      );
      socket.on(
        "host:queue:add",
        h((v: { studentId: string }) => session.enqueue(v.studentId), schemas.student),
      );
      socket.on(
        "host:queue:remove",
        h((v: { studentId: string }) => session.dequeue(v.studentId), schemas.student),
      );
      socket.on("host:queue:clear", () => session.clearQueue());
      socket.on(
        "host:station:release",
        h((v: { no: number }) => {
          const sid = session.releaseStationByNo(v.no);
          if (sid) {
            const other = io.sockets.sockets.get(sid);
            if (other) {
              const od = other.data as SockData;
              if (od.studentId) other.leave(`player:${od.studentId}`);
              od.studentId = undefined;
              other.emit("station:released");
            }
          }
        }, schemas.stationNo),
      );
      socket.on(
        "host:approve",
        h((v: { studentId: string }) => session.approve(v.studentId), schemas.student),
      );
      socket.on("host:approveAll", () => {
        for (const r of session.hostRoster()) if (r.status === "pending") session.approve(r.id);
      });
      socket.on(
        "host:flag:resolve",
        h(
          (v: z.infer<typeof schemas.flagResolve>) =>
            socket.emit("host:rejected", { message: session.resolveFlag(v.id, v.action, v.level) }),
          schemas.flagResolve,
        ),
      );
      socket.on(
        "host:sanction",
        h(
          (v: z.infer<typeof schemas.sanction>) =>
            socket.emit("host:rejected", { message: session.sanction(v.studentId, v.level, "keputusan guru") }),
          schemas.sanction,
        ),
      );
      socket.on(
        "host:badge",
        h(
          (v: z.infer<typeof schemas.badge>) =>
            doHost({ type: "host_badge", playerId: v.studentId, badgeId: v.badgeId }),
          schemas.badge,
        ),
      );
      socket.on(
        "host:vo:settings",
        h((v: z.infer<typeof schemas.voSettings>) => {
          const patch: Parameters<typeof session.setVoSettings>[0] = {};
          if (v.mode) patch.mode = v.mode;
          if (v.volume !== undefined) patch.volume = v.volume;
          if (v.kecepatan !== undefined) patch.kecepatan = v.kecepatan;
          if (v.nada !== undefined) patch.nada = v.nada;
          session.setVoSettings(patch);
        }, schemas.voSettings),
      );
      socket.on(
        "host:vo:name",
        h((v: z.infer<typeof schemas.voName>) => session.setVoName(v.studentId, v.name), schemas.voName),
      );
      socket.on(
        "host:vo:test",
        h((v: z.infer<typeof schemas.voTest>) => session.voTest(v.studentId), schemas.voTest),
      );
      socket.emit("vo:status", { engine: session.voEngineName() });
      socket.on("host:start", () => doHost({ type: "start" }));
      socket.on(
        "host:phase",
        h(
          (v: { phase: "OPEN" | "BATTLE" | "RUSH" | "END" }) => doHost({ type: "host_phase", phase: v.phase }),
          schemas.phase,
        ),
      );
      socket.on("host:pause", () => doHost({ type: "host_pause" }));
      socket.on("host:resume", () => doHost({ type: "host_resume" }));
      socket.on(
        "host:freeze",
        h(
          (v: z.infer<typeof schemas.freeze>) =>
            doHost({
              type: "host_freeze",
              playerId: v.studentId,
              frozen: v.frozen,
              ...(v.seconds ? { untilMs: v.seconds * 1000 } : {}),
            }),
          schemas.freeze,
        ),
      );
      socket.on(
        "host:void",
        h((v: { cell: string }) => doHost({ type: "host_void", cell: v.cell }), schemas.cell),
      );
      socket.on(
        "host:restore",
        h((v: { cell: string }) => doHost({ type: "host_restore", cell: v.cell }), schemas.cell),
      );
      socket.on(
        "host:adjust",
        h(
          (v: z.infer<typeof schemas.adjust>) =>
            doHost({ type: "host_adjust", playerId: v.studentId, delta: v.delta, reason: v.reason }),
          schemas.adjust,
        ),
      );
    }
  });
}

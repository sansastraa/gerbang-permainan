import type { BadgeDef, GameConfig, Question, RosterEntry } from "@claim80/shared";
import type { Store } from "./db";
import { GameSession } from "./session";
import type { Emitter } from "./session";

export interface RegistryOptions {
  store: Store;
  bank: Question[];
  config: GameConfig;
  badges: BadgeDef[];
  clock?: () => number;
  emitter: Emitter;
}

/** Daftar sesi aktif + loop timer tunggal 250 ms (SPEC §9.6). */
export class Registry {
  private byId = new Map<string, GameSession>();
  private timer: NodeJS.Timeout | null = null;
  private clock: () => number;

  constructor(private o: RegistryOptions) {
    this.clock = o.clock ?? Date.now;
  }

  private deps() {
    return {
      store: this.o.store,
      bank: this.o.bank,
      config: this.o.config,
      badges: this.o.badges,
      clock: this.clock,
      emitter: this.o.emitter,
    };
  }

  create(input: { className: string; roster: RosterEntry[]; autoApprove?: boolean; seed?: number }): GameSession {
    const s = GameSession.create(this.deps(), input);
    this.byId.set(s.id, s);
    return s;
  }

  /** Setelah server restart: bangun ulang semua sesi yang belum selesai dari log (SPEC §9.6). */
  restoreAll(): number {
    let n = 0;
    for (const row of this.o.store.listSessions()) {
      if (this.byId.has(row.id)) continue;
      this.byId.set(row.id, GameSession.restore(this.deps(), row));
      n++;
    }
    return n;
  }

  get(id: string): GameSession | undefined {
    return this.byId.get(id);
  }

  byCode(code: string): GameSession | undefined {
    const c = code.trim().toUpperCase();
    for (const s of this.byId.values()) if (s.code === c) return s;
    return undefined;
  }

  list(): GameSession[] {
    return [...this.byId.values()];
  }

  tickAll() {
    for (const s of this.byId.values()) if (!s.hasEnded) s.tick();
  }

  start(intervalMs = 250) {
    if (this.timer) return;
    this.timer = setInterval(() => this.tickAll(), intervalMs);
    this.timer.unref?.();
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }
}

import { describe, expect, it } from "vitest";
import { loadConfig } from "../questions/bank";
import { WrongPatternTracker, isRelay, isTooFast, minReadMs, wordCount } from "./detectors";

const cfg = loadConfig();

describe("terlalu cepat", () => {
  it("batas = 1500 ms + 150 ms per kata", () => {
    expect(wordCount("  satu dua  tiga ")).toBe(3);
    expect(minReadMs(cfg, 10)).toBe(3000);
  });
  it("hanya level ≥ 5 dan jawaban benar", () => {
    const o = { level: 6, correct: true, elapsedMs: 1200, words: 10 };
    expect(isTooFast(cfg, o)).toBe(true);
    expect(isTooFast(cfg, { ...o, elapsedMs: 3000 })).toBe(false);
    expect(isTooFast(cfg, { ...o, level: 4 })).toBe(false);
    expect(isTooFast(cfg, { ...o, correct: false })).toBe(false);
  });
});

describe("pola jawaban salah sama", () => {
  it("bendera tepat saat sepasang murid memilih opsi salah yang sama pada 3 soal", () => {
    const t = new WrongPatternTracker(3);
    expect(t.record("a", "B1-1", "tinggi")).toEqual([]);
    expect(t.record("b", "B1-1", "tinggi")).toEqual([]); // pasangan 1
    t.record("a", "C2-1", "dog");
    expect(t.record("b", "C2-1", "dog")).toEqual([]); // pasangan 2
    t.record("a", "D3-2", "Bulan");
    expect(t.record("b", "D3-2", "Bulan")).toEqual([{ other: "a", count: 3 }]);
    t.record("a", "A4-1", "x");
    expect(t.record("b", "A4-1", "x")).toEqual([]); // sudah berbendera, tidak berulang
  });
  it("opsi berbeda atau murid yang sama tidak dihitung", () => {
    const t = new WrongPatternTracker(2);
    t.record("a", "B1-1", "tinggi");
    expect(t.record("b", "B1-1", "luas")).toEqual([]);
    expect(t.record("a", "B1-1", "tinggi")).toEqual([]);
  });
});

describe("relay", () => {
  const neighbors = { x: ["y"], y: ["x"] };
  const fails = [{ cell: "E5", studentId: "x", ts: 1000 }];
  it("aktif hanya dengan peta kursi, jendela waktu, dan klaim sangat cepat", () => {
    const claim = { cell: "E5", studentId: "y", ts: 20_000, tooFast: true };
    expect(isRelay({ fails, claim, neighbors, windowMs: 60_000 })).not.toBeNull();
    expect(isRelay({ fails, claim, neighbors: {}, windowMs: 60_000 })).toBeNull();
    expect(isRelay({ fails, claim: { ...claim, ts: 90_000 }, neighbors, windowMs: 60_000 })).toBeNull();
    expect(isRelay({ fails, claim: { ...claim, tooFast: false }, neighbors, windowMs: 60_000 })).toBeNull();
    expect(isRelay({ fails, claim: { ...claim, studentId: "z" }, neighbors, windowMs: 60_000 })).toBeNull();
  });
});

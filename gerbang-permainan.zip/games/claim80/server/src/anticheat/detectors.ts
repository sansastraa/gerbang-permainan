import type { GameConfig } from "@claim80/shared";

/** Jumlah kata sebuah soal, dipakai untuk batas "terlalu cepat". */
export function wordCount(text: string): number {
  return text.trim().split(/\s+/).filter(Boolean).length;
}

/** Batas waktu baca minimum (ms): dasar + per kata (SPEC §5.2 "Terlalu cepat"). */
export function minReadMs(cfg: GameConfig, words: number): number {
  const a = cfg.anti_curang;
  return a.waktu_baca_min_dasar_ms + a.waktu_baca_min_per_kata_ms * words;
}

/** Level ≥ 5, benar, dan lebih cepat dari waktu baca manusia → bendera kuning (tanpa penalti otomatis). */
export function isTooFast(
  cfg: GameConfig,
  o: { level: number; correct: boolean; elapsedMs: number; words: number },
): boolean {
  return o.correct && o.level >= cfg.anti_curang.level_cek_terlalu_cepat_min && o.elapsedMs < minReadMs(cfg, o.words);
}

export interface PairHit {
  other: string;
  count: number;
}

/**
 * Pola jawaban salah yang sama: dua murid memilih opsi salah yang sama pada soal (varian) yang sama.
 * Dihitung per pasangan murid lintas soal; bendera saat sebuah pasangan mencapai `ambang` kejadian.
 */
export class WrongPatternTracker {
  private byKey = new Map<string, string[]>();
  private pair = new Map<string, number>();

  constructor(private ambang = 3) {}

  /** Mencatat jawaban salah; mengembalikan pasangan yang baru saja mencapai ambang. */
  record(studentId: string, questionId: string, wrongText: string): PairHit[] {
    const key = `${questionId}|${wrongText}`;
    const prev = this.byKey.get(key) ?? [];
    if (prev.includes(studentId)) return [];
    const hits: PairHit[] = [];
    for (const other of prev) {
      const pk = [studentId, other].sort().join("~");
      const n = (this.pair.get(pk) ?? 0) + 1;
      this.pair.set(pk, n);
      if (n === this.ambang) hits.push({ other, count: n });
    }
    prev.push(studentId);
    this.byKey.set(key, prev);
    return hits;
  }
}

export interface FailRecord {
  cell: string;
  studentId: string;
  ts: number;
}

/**
 * Relay: murid X gagal di kartu K, lalu dalam `windowMs` murid Y (yang duduk dekat X menurut peta kursi) mengklaim K
 * dengan sangat cepat. Tanpa peta kursi (`neighbors` kosong) detektor ini tidak aktif agar tidak menuduh sembarang murid.
 */
export function isRelay(o: {
  fails: FailRecord[];
  claim: { cell: string; studentId: string; ts: number; tooFast: boolean };
  neighbors: Record<string, string[]>;
  windowMs: number;
}): FailRecord | null {
  if (!o.claim.tooFast) return null;
  for (const f of o.fails) {
    if (f.cell !== o.claim.cell || f.studentId === o.claim.studentId) continue;
    if (o.claim.ts - f.ts > o.windowMs || o.claim.ts < f.ts) continue;
    if (o.neighbors[f.studentId]?.includes(o.claim.studentId) || o.neighbors[o.claim.studentId]?.includes(f.studentId))
      return f;
  }
  return null;
}

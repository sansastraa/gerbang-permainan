/**
 * Awalan jalur (BASE_PATH) untuk menjalankan CLAIM 80 di belakang gerbang SIMPETERI, mis. `/games/claim80`.
 * Kosong = berjalan di akar seperti biasa. Hasil normalisasi: diawali `/`, tanpa `/` akhir, tanpa `//`.
 */
export function normalizeBasePath(raw: string | undefined | null): string {
  const parts = (raw ?? "").split("/").filter((p) => p.trim() !== "");
  return parts.length ? "/" + parts.map((p) => p.trim()).join("/") : "";
}

/** Header yang ditambahkan reverse proxy; bila ada, permintaan bukan akses langsung dari laptop server. */
export const PROXY_HEADERS = ["x-forwarded-for", "forwarded", "x-real-ip"] as const;

export function viaProxy(headers: Record<string, string | string[] | undefined>): boolean {
  return PROXY_HEADERS.some((h) => headers[h] !== undefined);
}

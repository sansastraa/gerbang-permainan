import type { AddressInfo } from "node:net";
import { afterAll, beforeAll, expect, it } from "vitest";
import { createApp } from "./main";

const app = createApp({ dbPath: ":memory:", tickMs: 1_000_000 });
let port = 0;
beforeAll(async () => {
  await new Promise<void>((r) => app.http.listen(0, r));
  port = (app.http.address() as AddressInfo).port;
});
afterAll(() => app.close());

it("/health melaporkan 160 soal", async () => {
  const res = await fetch(`http://127.0.0.1:${port}/health`);
  expect(await res.json()).toMatchObject({ ok: true, soal: 160 });
});

it("endpoint guru butuh token", async () => {
  const res = await fetch(`http://127.0.0.1:${port}/api/sessions`);
  expect(res.status).toBe(401);
  const ok = await fetch(`http://127.0.0.1:${port}/api/sessions`, { headers: { "x-host-token": app.hostToken } });
  expect(ok.status).toBe(200);
});

it("log audit berantai hash dapat diekspor guru dan rantainya utuh", async () => {
  const create = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": app.hostToken },
    body: JSON.stringify({ className: "5A", roster: [{ id: "a", name: "Rina Putri" }], autoApprove: true }),
  });
  const { id } = (await create.json()) as { id: string };
  const s = app.registry.get(id)!;
  s.join("a", s.pins.a!, "d1");
  const noAuth = await fetch(`http://127.0.0.1:${port}/api/sessions/${id}/log`);
  expect(noAuth.status).toBe(401);
  const res = await fetch(`http://127.0.0.1:${port}/api/sessions/${id}/log`, {
    headers: { "x-host-token": app.hostToken },
  });
  const log = (await res.json()) as {
    chainBrokenAtSeq: number | null;
    events: { type: string; hash: string }[];
    flags: unknown[];
  };
  expect(log.chainBrokenAtSeq).toBeNull();
  expect(log.events[0]!.type).toBe("join");
  expect(log.events[0]!.hash).toMatch(/^[0-9a-f]{64}$/);
});

it("summary.json untuk SIMPETERI: ditolak sebelum selesai, tersedia sesudahnya; ekspor CSV butuh token", async () => {
  const create = await fetch(`http://127.0.0.1:${port}/api/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": app.hostToken },
    body: JSON.stringify({
      className: "6A",
      roster: [
        { id: "sis-1", name: "Rina Putri" },
        { id: "sis-2", name: "Budi Santoso" },
      ],
      autoApprove: true,
    }),
  });
  const { id } = (await create.json()) as { id: string };
  const s = app.registry.get(id)!;
  s.join("sis-1", s.currentPin(), "d1");
  s.join("sis-2", s.currentPin(), "d2");
  s.host({ type: "start" });
  const url = `http://127.0.0.1:${port}/api/sessions/${id}/summary.json`;
  expect((await fetch(url)).status).toBe(403);
  s.host({ type: "host_phase", phase: "END" });
  const ok = await fetch(url);
  expect(ok.status).toBe(200);
  const j = (await ok.json()) as { game: string; ended: boolean; students: { studentId: string; points: number }[] };
  expect(j.game).toBe("claim80");
  expect(j.ended).toBe(true);
  expect(j.students.map((x) => x.studentId).sort()).toEqual(["sis-1", "sis-2"]);
  const noAuth = await fetch(`http://127.0.0.1:${port}/api/sessions/${id}/students.csv`);
  expect(noAuth.status).toBe(401);
  const csv = await fetch(`http://127.0.0.1:${port}/api/sessions/${id}/students.csv`, {
    headers: { "x-host-token": app.hostToken },
  });
  expect(csv.status).toBe(200);
  expect(csv.headers.get("content-type")).toMatch(/text\/csv/);
  expect(await csv.text()).toContain("Rina Putri");
  const rep = await fetch(`http://127.0.0.1:${port}/api/sessions/${id}/report.json`, {
    headers: { "x-host-token": app.hostToken },
  });
  expect(((await rep.json()) as { heatmap: unknown[] }).heatmap).toHaveLength(80);
});

import { createHmac, randomBytes, randomInt, timingSafeEqual } from "node:crypto";
import {
  KOLOM_LABEL,
  computeAwards,
  createGame,
  effectiveTimeMs,
  levelForXp,
  xpFromScore,
  judgeValue,
  leaderboard,
  makeInitials,
  playerColor,
  reduce,
  scoreOf,
} from "@claim80/shared";
import type {
  HostSettings,
  StationState,
  Award,
  BadgeDef,
  FlagItem,
  FlagSeverity,
  FlagType,
  Action,
  AnswerResult,
  GameConfig,
  GameEvent,
  GameState,
  HostPlayer,
  JoinResult,
  LeaderEntry,
  MeState,
  Player,
  PowerUp,
  PublicCard,
  QuestionDeliver,
  Question,
  RosterEntry,
  Snapshot,
  TickerItem,
} from "@claim80/shared";
import type { SessionOptions, SessionRow, Store } from "./db";
import { generateQuestion, hasGenerator, seedFrom } from "./questions/generators";
import { applyOverrides, validatePatch } from "./configOverrides";
import type { GamePatch } from "./configOverrides";
import { WrongPatternTracker, isRelay, isTooFast, wordCount } from "./anticheat/detectors";
import { VoDirector } from "./vo/director";
import { buildReport } from "./stats/report";
import type { ClassReport } from "./stats/report";
import { buildAttempts } from "./stats/stats";
import { fixedPhrases, loadNaskah, spokenCell } from "./vo/naskah";
import type { Naskah } from "./vo/naskah";
import type { FailRecord } from "./anticheat/detectors";

export interface Emitter {
  emit(room: string, event: string, payload: unknown): void;
}

export interface SessionDeps {
  store: Store;
  bank: Question[];
  config: GameConfig;
  badges: BadgeDef[];
  clock: () => number;
  emitter: Emitter;
}

interface DeliveryRec {
  deliveryId: string;
  nonce: string;
  q: Question;
  cell: string;
  mode: "claim" | "steal";
  /** token opsi, urutan tampil */
  options: { optId: string; text: string }[] | null;
  correctToken: string | null;
  hidden: Set<string>;
  used: boolean;
}

interface Ident {
  id: string;
  name: string;
  initials: string;
  color: string;
  absen: number | null;
}

const token = (n = 6) => randomBytes(n).toString("hex");
const shuffle = <T>(a: T[]): T[] => {
  const r = a.slice();
  for (let i = r.length - 1; i > 0; i--) {
    const j = randomInt(i + 1);
    [r[i], r[j]] = [r[j]!, r[i]!];
  }
  return r;
};
const shortName = (n: string) => n.trim().split(/\s+/).slice(0, 2).join(" ");

export class GameSession {
  readonly id: string;
  readonly code: string;
  readonly className: string;
  readonly roster: RosterEntry[];
  private pinKey: string;
  private lastPinSlot = -1;
  readonly autoApprove: boolean;
  readonly seed: number;
  state: GameState;
  private idents = new Map<string, Ident>();
  private pending = new Set<string>();
  private deviceOf = new Map<string, string>();
  private online = new Set<string>();
  private deliveries = new Map<string, DeliveryRec>();
  private bankById: Map<string, Question>;
  private lastBoard = new Map<string, string>();
  private lastMe = new Map<string, string>();
  private tickerSeq = 0;
  readonly ticker: TickerItem[] = [];
  private ended = false;
  private naskah: Naskah = loadNaskah();
  private vo!: VoDirector;
  private voNames: Record<string, string> = {};
  private voEngine = "belum terhubung";
  private lastCountdown: number | null = null;
  private missionNear = false;
  private flags: FlagItem[] = [];
  private flagKeys = new Set<string>();
  private wrongTracker = new WrongPatternTracker(3);
  private fails: FailRecord[] = [];
  /** peta kursi opsional (id murid → tetangga) untuk detektor relay */
  private neighbors: Record<string, string[]> = {};
  /** Mode Stasiun: satu perangkat memang dipakai banyak murid */
  stationMode = false;
  private baseConfig: GameConfig;
  private alwaysRandom = new Set<string>();
  private options: SessionOptions;
  private queue: string[] = [];
  private stations = new Map<string, { no: number; studentId: string | null }>();

  constructor(
    private deps: SessionDeps,
    row: SessionRow,
  ) {
    this.id = row.id;
    this.code = row.code;
    this.className = row.className;
    this.roster = row.roster;
    this.pinKey = `${row.id}:${row.seed}`;
    this.baseConfig = deps.config;
    this.deps = { ...this.deps, config: applyOverrides(deps.config, row.options) };
    this.autoApprove = row.options.autoApprove;
    this.options = row.options;
    this.alwaysRandom = new Set(row.options.alwaysRandom ?? []);
    this.stationMode = row.options.stationMode ?? false;
    this.seed = row.seed;
    this.bankById = new Map(deps.bank.map((q) => [q.id, q]));
    const initials = makeInitials(row.roster.map((r) => r.name));
    row.roster.forEach((r, i) =>
      this.idents.set(r.id, {
        id: r.id,
        name: r.name,
        initials: initials[i]!,
        color: playerColor(i),
        absen: r.absen ?? null,
      }),
    );
    const waktu: Record<number, number> = {};
    for (const q of deps.bank) waktu[q.level] = q.waktu_detik;
    this.state = createGame({ config: this.deps.config, waktuPerLevel: waktu, badges: deps.badges }, row.seed);
    this.ended = row.endedAt !== null;
    this.voNames = deps.store.listVoNames(row.id);
    this.vo = new VoDirector({
      naskah: this.naskah,
      config: deps.config.voice_over,
      clock: deps.clock,
      emit: (p) => {
        // VO hanya ke proyektor; perangkat murid tidak memutar suara (SPEC §7a.7)
        this.emit(this.roomProjector(), "vo:play", p);
        if (p.studentId) {
          this.emit(this.roomPlayer(p.studentId), "toast", { level: "info", text: "Namamu sedang diumumkan!" });
        }
      },
    });
    for (const f of deps.store.listFlags(row.id)) {
      const d = JSON.parse(f.detail_json) as { text?: string };
      this.flags.push({
        id: f.id,
        ts: f.created_at,
        studentId: f.student_id,
        name: f.student_id ? shortName(this.idents.get(f.student_id)?.name ?? "?") : "",
        type: f.type as FlagType,
        severity: f.severity as FlagSeverity,
        text: d.text ?? "",
        status: f.status as FlagItem["status"],
      });
    }
  }

  /** Membuat sesi baru: kode, seed, dan PIN 4 digit per siswa dibangkitkan di sini. */
  static create(
    deps: SessionDeps,
    o: { className: string; roster: RosterEntry[]; autoApprove?: boolean; seed?: number },
  ): GameSession {
    const pins: Record<string, string> = {};
    // PIN seragam untuk satu kelas (permintaan guru); identitas dijaga persetujuan guru, satu socket per murid, dan bendera perangkat.
    const classPin = String(randomInt(10000)).padStart(4, "0");
    for (const r of o.roster) pins[r.id] = classPin;
    const row: SessionRow = {
      id: token(5),
      code: Array.from({ length: 5 }, () => "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"[randomInt(32)]).join(""),
      className: o.className,
      seed: o.seed ?? randomInt(1, 2 ** 31),
      roster: o.roster,
      pins,
      options: { autoApprove: o.autoApprove ?? false },
      createdAt: deps.clock(),
      endedAt: null,
    };
    deps.store.insertSession(row);
    return new GameSession(deps, row);
  }

  /** Membangun ulang state dari log (replay identik; DoD 7). */
  static restore(deps: SessionDeps, row: SessionRow): GameSession {
    const s = new GameSession(deps, row);
    s.state = s.replayState();
    return s;
  }

  replayState(): GameState {
    const waktu: Record<number, number> = {};
    for (const q of this.deps.bank) waktu[q.level] = q.waktu_detik;
    let st = createGame({ config: this.deps.config, waktuPerLevel: waktu, badges: this.deps.badges }, this.seed);
    for (const e of this.deps.store.readActions(this.id)) st = reduce(st, e.action, e.ts).state;
    return st;
  }

  get now(): number {
    return this.deps.clock();
  }

  get hasEnded(): boolean {
    return this.ended;
  }

  ident(id: string): Ident | undefined {
    return this.idents.get(id);
  }

  // ---------- inti: terapkan aksi ----------

  private apply(action: Action): GameEvent[] {
    const now = this.now;
    const prev = this.state;
    const r = reduce(prev, action, now);
    if (r.state !== prev) {
      this.state = r.state;
      this.deps.store.appendAction(this.id, now, action, r.events);
      this.afterApply(r.events);
    }
    return r.events;
  }

  private rejection(events: GameEvent[]): { reason: string; message: string } | null {
    const e = events.find((x) => x.type === "rejected");
    return e ? { reason: String(e.data?.reason ?? ""), message: String(e.data?.message ?? "") } : null;
  }

  private emit(room: string, event: string, payload: unknown) {
    this.deps.emitter.emit(room, event, payload);
  }
  private roomSession = () => `session:${this.id}`;
  private roomHost = () => `host:${this.id}`;
  private roomPlayer = (id: string) => `player:${id}`;
  roomProjector = () => `projector:${this.id}`;

  private nameOf(id: string | null | undefined): string {
    return id ? shortName(this.idents.get(id)?.name ?? "?") : "?";
  }

  private pushTicker(text: string, kind: TickerItem["kind"]) {
    const item: TickerItem = { id: ++this.tickerSeq, ts: this.now, text, kind };
    this.ticker.push(item);
    if (this.ticker.length > 60) this.ticker.shift();
    this.emit(this.roomSession(), "ticker:push", item);
  }

  /** Efek visual untuk proyektor: hanya peristiwa publik, tanpa isi soal atau jawaban. */
  private fx(e: GameEvent) {
    const PUBLIC = [
      "claimed",
      "stolen",
      "golden",
      "streak",
      "steal_started",
      "steal_failed",
      "phase",
      "mission",
      "ended",
      "gift",
      "jackpot",
      "badge_awarded",
    ];
    if (!PUBLIC.includes(e.type)) return;
    const id = e.playerId ? this.idents.get(e.playerId) : undefined;
    const from = e.data?.from ? this.idents.get(String(e.data.from)) : undefined;
    const owner = e.data?.owner ? this.idents.get(String(e.data.owner)) : undefined;
    this.emit(this.roomSession(), "fx", {
      type: e.type,
      ...(e.cell ? { cell: e.cell } : {}),
      ...(id ? { name: shortName(id.name), initials: id.initials, color: id.color } : {}),
      ...(from ? { fromName: shortName(from.name), fromInitials: from.initials } : {}),
      ...(owner ? { fromName: shortName(owner.name), fromInitials: owner.initials } : {}),
      data: {
        ...(e.data?.streak !== undefined ? { streak: e.data.streak } : {}),
        ...(e.data?.label !== undefined ? { label: e.data.label } : {}),
        ...(e.data?.phase !== undefined ? { phase: e.data.phase } : {}),
        ...(e.data?.pct !== undefined ? { pct: e.data.pct } : {}),
        ...(e.data?.nama !== undefined ? { nama: e.data.nama } : {}),
        ...(e.data?.ikon !== undefined ? { ikon: e.data.ikon } : {}),
      },
    });
  }

  private afterApply(events: GameEvent[]) {
    for (const e of events) {
      this.fx(e);
      this.voFor(e, events);
      const who = this.nameOf(e.playerId);
      switch (e.type) {
        case "claimed":
          if (e.data?.golden) this.pushTicker(`🌟 Kartu emas ${e.cell} diklaim ${who}!`, "special");
          else this.pushTicker(`${who} mengklaim ${e.cell}`, "claim");
          this.finishAnswer(e, true);
          break;
        case "stolen":
          this.pushTicker(`⚔️ ${who} berhasil merebut ${e.cell} dari ${this.nameOf(String(e.data?.from))}!`, "steal");
          this.finishAnswer(e, true);
          break;
        case "steal_started": {
          const owner = String(e.data?.owner ?? "");
          this.pushTicker(`⚔️ ${who} mencoba merebut ${e.cell} dari ${this.nameOf(owner)}!`, "steal");
          this.emit(this.roomPlayer(owner), "toast", { level: "warn", text: `Kartumu ${e.cell} sedang direbut!` });
          break;
        }
        case "steal_failed":
          this.pushTicker(`🛡️ ${this.nameOf(String(e.data?.owner))} bertahan di ${e.cell}`, "steal");
          this.finishAnswer(e, false);
          break;
        case "claim_failed":
          if (e.playerId && e.cell) this.fails.push({ cell: e.cell, studentId: e.playerId, ts: this.now });
          this.finishAnswer(e, false);
          break;
        case "jackpot":
          // hanya jackpot besar yang layak diumumkan agar ticker tidak penuh pesan berulang
          if (Number(e.data?.pct ?? 0) >= 30)
            this.pushTicker(`💰 Jackpot ${e.cell} naik jadi +${e.data?.pct}%`, "special");
          break;
        case "streak":
          this.pushTicker(`🔥 ${who}: ${e.data?.label}`, "special");
          break;
        case "phase":
          this.pushTicker(`Fase ${e.data?.phase}!`, "phase");
          break;
        case "mission":
          this.pushTicker("🏆 Misi kelas tercapai! Semua mendapat hadiah.", "special");
          break;
        case "paused":
          this.pushTicker("⏸ Permainan dijeda guru", "info");
          break;
        case "resumed":
          this.pushTicker("▶️ Permainan dilanjutkan", "info");
          break;
        case "powerup_granted":
          this.emit(this.roomPlayer(String(e.playerId)), "toast", {
            level: "good",
            text: `Kamu dapat power-up: ${e.data?.powerUp}`,
          });
          break;
        case "focus_warning":
          this.flag(e.playerId, "fokus_hilang", "kuning", `meninggalkan layar soal ${e.cell} (peringatan)`);
          this.emit(this.roomPlayer(String(e.playerId)), "toast", {
            level: "warn",
            text: "Kamu meninggalkan layar soal. Sekali lagi, soal ini otomatis gagal ya.",
          });
          break;
        case "badge_awarded": {
          const nama = String(e.data?.nama ?? "");
          this.pushTicker(`🏅 ${who} meraih badge ${nama}!`, "special");
          this.emit(this.roomPlayer(String(e.playerId)), "toast", {
            level: "good",
            text: `Badge baru: ${e.data?.ikon ?? ""} ${nama}`,
          });
          break;
        }
        case "ended":
          this.ended = true;
          this.deps.store.markEnded(this.id, this.now);
          this.onEnded();
          break;
        default:
          break;
      }
    }
    this.broadcast();
  }

  /** Kirim hasil jawaban ke murid dan hapus pengiriman soalnya. */
  private finishAnswer(e: GameEvent, correct: boolean) {
    const pid = e.playerId;
    if (!pid) return;
    const rec = this.deliveries.get(pid);
    this.deliveries.delete(pid);
    const why = String(e.data?.reason ?? "");
    if (!correct && rec && (why === "timeout" || why === "fokus")) {
      // gagal tanpa jawaban terkirim: catat agar masuk statistik percobaan
      this.deps.store.finishDelivery(
        rec.deliveryId,
        this.now,
        why,
        false,
        this.state.players[pid]?.active?.focusLost ?? (why === "fokus" ? 2 : 0),
      );
    }
    const p = this.state.players[pid];
    const mode = rec?.mode ?? (e.type === "stolen" || e.type === "steal_failed" ? "steal" : "claim");
    const reason = String(e.data?.reason ?? "");
    if (!correct && reason === "fokus") {
      this.flag(pid, "fokus_gagal", "oranye", `soal ${e.cell} otomatis gagal: layar ditinggalkan dua kali`);
    }
    const gained = correct ? Number(e.data?.value ?? 0) : 0;
    let message: string;
    if (correct)
      message =
        mode === "steal" ? `Berhasil merebut ${e.cell}! +${gained}` : `Benar! ${e.cell} jadi milikmu (+${gained})`;
    else if (reason === "timeout") message = "Waktu habis. Coba kartu lain ya!";
    else if (reason === "fokus") message = "Soal gagal karena layar ditinggalkan.";
    else message = "Belum tepat. Semangat, coba lagi!";
    const result: AnswerResult = {
      correct,
      ...(reason ? { reason } : {}),
      pointsGained: gained,
      streak: p?.streak ?? 0,
      cell: e.cell ?? "",
      mode,
      message,
    };
    this.emit(this.roomPlayer(pid), "answer:result", result);
  }

  // ---------- tampilan publik ----------

  publicCard(cell: string): PublicCard {
    const c = this.state.cards[cell]!;
    const own = c.owner ? this.idents.get(c.owner) : undefined;
    const tryId = c.status === "LOCKED" ? c.lockedBy : c.status === "CONTESTED" ? c.challenger : null;
    const claimed = c.status === "CLAIMED" || c.status === "CONTESTED";
    const now = this.now;
    return {
      cell,
      status: c.status,
      ownerId: claimed ? c.owner : null,
      initials: claimed ? (own?.initials ?? null) : null,
      color: claimed ? (own?.color ?? null) : null,
      value: claimed ? c.value : 0,
      jackpotPct: c.jackpotPct,
      shielded: c.shieldUntil > now,
      immune: c.immuneUntil > now,
      cooldownUntil: c.status === "COOLDOWN" ? c.cooldownUntil : 0,
      tryingId: tryId,
      tryingInitials: tryId ? (this.idents.get(tryId)?.initials ?? null) : null,
      golden: claimed && c.golden,
    };
  }

  board(): PublicCard[] {
    return Object.keys(this.state.cards).map((c) => this.publicCard(c));
  }

  leaderboardTop(): LeaderEntry[] {
    const n = this.deps.config.papan_skor.tampilkan_top;
    return leaderboard(this.state)
      .slice(0, n)
      .map((r) => {
        const i = this.idents.get(r.playerId)!;
        return {
          id: i.id,
          name: shortName(i.name),
          initials: i.initials,
          color: i.color,
          score: r.score,
          cards: r.cards,
          streak: this.state.players[r.playerId]?.streak ?? 0,
        };
      });
  }

  me(id: string): MeState | undefined {
    const p: Player | undefined = this.state.players[id];
    const i = this.idents.get(id);
    if (!p || !i) return undefined;
    const lb = leaderboard(this.state);
    return {
      id,
      name: i.name,
      initials: i.initials,
      color: i.color,
      score: scoreOf(this.state, id),
      cards: lb.find((r) => r.playerId === id)?.cards ?? 0,
      streak: p.streak,
      bestStreak: p.bestStreak,
      tickets: p.tickets,
      powerUps: p.powerUps,
      saver: p.saver,
      goldenKey: p.goldenKey,
      cooldownUntil: p.cooldownUntil,
      frozen: p.frozen || p.frozenUntil > this.now,
      rank: lb.findIndex((r) => r.playerId === id) + 1,
      badges: p.badges,
      ...(this.ended ? { xp: this.xpFor(id) } : {}),
    };
  }

  /** XP sesi ini dan total lintas sesi. ID manual (tanpa SIMPETERI) tidak disimpan lintas sesi. */
  private xpFor(id: string) {
    const gain = xpFromScore(scoreOf(this.state, id));
    const persisted = !id.startsWith("manual-");
    const total = persisted ? Math.max(this.deps.store.getXp(id), gain) : gain;
    const lv = levelForXp(total);
    return { gain, total, level: lv.nama, next: lv.next };
  }

  awardsList(): Award[] {
    return this.ended ? computeAwards(this.state) : [];
  }

  /** Dipanggil sekali saat permainan berakhir: umumkan penghargaan dan simpan XP serta badge lintas sesi. */
  private onEnded() {
    const awards = computeAwards(this.state);
    const ts = this.now;
    for (const p of Object.values(this.state.players)) {
      if (p.id.startsWith("manual-")) continue;
      const i = this.idents.get(p.id);
      this.deps.store.awardXp(
        this.id,
        p.id,
        i?.name ?? p.name,
        this.className,
        xpFromScore(scoreOf(this.state, p.id)),
        ts,
      );
      this.deps.store.addBadges(this.id, p.id, p.badges, ts);
    }
    this.emit(this.roomSession(), "awards", awards);
    for (const id of Object.keys(this.state.players)) {
      this.emit(this.roomPlayer(id), "player:update", this.me(id));
    }
  }

  hostRoster(): HostPlayer[] {
    const lb = new Map(leaderboard(this.state).map((r) => [r.playerId, r]));
    return this.roster.map((r) => {
      const i = this.idents.get(r.id)!;
      const p = this.state.players[r.id];
      return {
        id: r.id,
        name: i.name,
        initials: i.initials,
        color: i.color,
        absen: i.absen,
        pin: this.currentPin(),
        status: p ? "approved" : this.pending.has(r.id) ? "pending" : "none",
        deviceId: this.deviceOf.get(r.id) ?? null,
        online: this.online.has(r.id),
        score: lb.get(r.id)?.score ?? 0,
        cards: lb.get(r.id)?.cards ?? 0,
        streak: p?.streak ?? 0,
        frozen: !!p && (p.frozen || p.frozenUntil > this.now),
        badges: p?.badges.length ?? 0,
      };
    });
  }

  private mission() {
    const claimed = Object.values(this.state.cards).filter(
      (c) => c.status === "CLAIMED" || c.status === "CONTESTED",
    ).length;
    return { claimed, target: this.deps.config.misi_kelas.target_kartu_terklaim, done: this.state.missionDone };
  }

  snapshotFor(role: "player" | "projector" | "host", studentId?: string): Snapshot {
    const s = this.state;
    const cfg = this.deps.config;
    const waktuDetik: Record<number, number> = {};
    for (let l = 1; l <= 8; l++) waktuDetik[l] = Math.round(effectiveTimeMs(s, l, "claim") / 1000);
    const snap: Snapshot = {
      rules: {
        pajak: cfg.pajak_juara,
        zona: {
          baris: cfg.zona_pemula.baris,
          maks: cfg.zona_pemula.maks_kartu_dimiliki,
          sampaiMenit: cfg.zona_pemula.berlaku_sampai_menit,
        },
        poin: Object.fromEntries(Object.entries(cfg.poin_per_level).map(([k, v]) => [Number(k), v])),
        waktuDetik,
        pengaliKolom: cfg.pengali_kolom,
        audioMaks: cfg.anti_curang.audio_putar_maks,
        fokusToleransiMs: cfg.anti_curang.fokus_hilang_toleransi_ms,
        rebutFase: cfg.fase.filter((f) => f.rebut_aktif).map((f) => f.id),
      },
      sessionId: this.id,
      code: this.code,
      className: this.className,
      phase: s.phase,
      serverNow: this.now,
      startedAt: s.startedAt,
      pausedAt: s.pausedAt,
      durationMs: this.deps.config.durasi_menit * 60_000,
      board: this.board(),
      leaderboard: this.leaderboardTop(),
      mission: this.mission(),
      badgeDefs: this.deps.badges.map((b) => ({
        id: b.id,
        nama: b.nama,
        ikon: b.ikon,
        syarat: b.syarat ?? "",
        bonus: b.bonus,
      })),
      ...(this.ended ? { awards: this.awardsList() } : {}),
    };
    if (role === "player" && studentId) {
      const me = this.me(studentId);
      if (me) snap.me = me;
      const q = this.questionFor(studentId);
      if (q) snap.question = q;
    }
    if (role === "host" || role === "projector") snap.vo = this.vo.settings;
    if (role === "host") snap.pin = this.pinInfo();
    if (role === "host" || role === "projector") snap.station = this.stationState();
    if (role === "host") {
      snap.settings = this.settings();
      snap.voNames = this.voNames;
      snap.roster = this.hostRoster();
      snap.flags = this.flags;
    }
    return snap;
  }

  /** Mengirim perubahan ke seluruh room (diff papan, papan skor, status pribadi, daftar host). */
  private broadcast() {
    const changed: PublicCard[] = [];
    for (const cell of Object.keys(this.state.cards)) {
      const pc = this.publicCard(cell);
      const js = JSON.stringify(pc);
      if (this.lastBoard.get(cell) !== js) {
        this.lastBoard.set(cell, js);
        changed.push(pc);
      }
    }
    const s = this.state;
    this.emit(this.roomSession(), "board:diff", {
      cells: changed,
      phase: s.phase,
      startedAt: s.startedAt,
      pausedAt: s.pausedAt,
      serverNow: this.now,
      mission: this.mission(),
    });
    this.emit(this.roomSession(), "leaderboard:update", this.leaderboardTop());
    for (const id of Object.keys(s.players)) {
      const me = this.me(id);
      const js = JSON.stringify(me);
      if (this.lastMe.get(id) !== js) {
        this.lastMe.set(id, js);
        this.emit(this.roomPlayer(id), "player:update", me);
      }
    }
    this.emit(this.roomHost(), "host:roster", this.hostRoster());
  }

  // ---------- pemain ----------

  // ---------- PIN kelas yang berganti (permintaan guru) ----------

  private get pinMs(): number {
    return this.deps.config.pin_kelas.ganti_tiap_menit * 60_000;
  }

  private pinFor(slot: number): string {
    const h = createHmac("sha256", this.pinKey).update(String(slot)).digest();
    return String(h.readUInt32BE(0) % 10000).padStart(4, "0");
  }

  /** PIN yang berlaku sekarang; diturunkan dari rahasia sesi + slot waktu sehingga tetap sama setelah server restart. */
  currentPin(now = this.now): string {
    return this.pinFor(Math.floor(now / this.pinMs));
  }

  pinExpiresAt(now = this.now): number {
    return (Math.floor(now / this.pinMs) + 1) * this.pinMs;
  }

  pinInfo() {
    return { value: this.currentPin(), expiresAt: this.pinExpiresAt(), intervalMs: this.pinMs };
  }

  /** PIN berlaku bila sama dengan PIN sekarang, atau PIN sebelumnya selama masa toleransi di awal slot baru. */
  pinValid(pin: string, now = this.now): boolean {
    const slot = Math.floor(now / this.pinMs);
    const same = (a: string, b: string) => a.length === b.length && timingSafeEqual(Buffer.from(a), Buffer.from(b));
    const given = String(pin);
    if (same(given, this.pinFor(slot))) return true;
    const sinceSlot = now - slot * this.pinMs;
    return sinceSlot < this.deps.config.pin_kelas.toleransi_detik * 1000 && same(given, this.pinFor(slot - 1));
  }

  /** Semua murid memakai PIN yang sama pada satu waktu (dipakai alat bantu dan tes). */
  get pins(): Record<string, string> {
    const pin = this.currentPin();
    return Object.fromEntries(this.roster.map((r) => [r.id, pin]));
  }

  join(studentId: string, pin: string, deviceId: string): JoinResult {
    if (!this.idents.has(studentId)) return { ok: false, error: "no_student" };
    // murid yang sudah disetujui boleh menyambung ulang dari perangkat yang sama tanpa PIN terbaru (PIN berganti tiap beberapa menit)
    const approved = !!this.state.players[studentId];
    const known = this.deviceOf.get(studentId);
    const sameDevice = approved && (known === undefined || known === deviceId);
    if (!sameDevice && !this.pinValid(pin)) return { ok: false, error: "bad_pin" };
    this.deviceOf.set(studentId, deviceId);
    if (!this.stationMode) {
      for (const [other, dev] of this.deviceOf) {
        if (other !== studentId && dev === deviceId) {
          const key = `perangkat:${[studentId, other].sort().join("~")}`;
          this.flag(
            studentId,
            "perangkat_bersama",
            "merah",
            `satu perangkat dipakai bersama ${this.nameOf(other)}`,
            key,
          );
        }
      }
    }
    if (this.state.players[studentId]) {
      this.broadcast();
      return { ok: true, status: "approved" };
    }
    if (this.autoApprove) {
      this.approve(studentId);
      return { ok: true, status: "approved" };
    }
    this.pending.add(studentId);
    this.emit(this.roomHost(), "host:roster", this.hostRoster());
    return { ok: true, status: "pending" };
  }

  approve(studentId: string): boolean {
    const i = this.idents.get(studentId);
    if (!i) return false;
    this.pending.delete(studentId);
    if (!this.state.players[studentId]) {
      this.apply({ type: "join", playerId: studentId, name: i.name, initials: i.initials, color: i.color });
    }
    this.emit(this.roomPlayer(studentId), "joined", { status: "approved" });
    return true;
  }

  setOnline(studentId: string, on: boolean) {
    if (on) this.online.add(studentId);
    else this.online.delete(studentId);
    this.emit(this.roomHost(), "host:roster", this.hostRoster());
  }

  private notify(studentId: string, events: GameEvent[]) {
    const rej = this.rejection(events);
    if (rej) this.emit(this.roomPlayer(studentId), "action:rejected", rej);
  }

  claim(studentId: string, cell: string): void {
    this.open(studentId, cell, "claim");
  }

  steal(studentId: string, cell: string): void {
    this.open(studentId, cell, "steal");
  }

  private open(studentId: string, cell: string, mode: "claim" | "steal") {
    const deliveryId = token(8);
    const events = this.apply({ type: mode, playerId: studentId, cell, deliveryId });
    this.notify(studentId, events);
    if (!events.some((e) => e.type === "locked" || e.type === "steal_started")) return;
    const q = this.questionFor(studentId);
    if (q) {
      const rec = this.deliveries.get(studentId)!;
      this.deps.store.upsertDelivery({
        id: deliveryId,
        sessionId: this.id,
        cell,
        studentId,
        questionId: rec.q.id,
        mode,
        sentAt: this.now,
        deadline: q.deadline,
      });
      this.emit(this.roomPlayer(studentId), "question:deliver", q);
    }
  }

  /** Membentuk (atau memakai ulang) pengiriman soal untuk pemain yang sedang punya soal aktif. */
  private questionFor(studentId: string): QuestionDeliver | undefined {
    const p = this.state.players[studentId];
    const act = p?.active;
    if (!p || !act) return undefined;
    let rec = this.deliveries.get(studentId);
    if (!rec || rec.deliveryId !== act.deliveryId) {
      let q = this.bankById.get(`${act.cell}-${act.variant}`);
      if (!q) return undefined;
      // soal acak: kolom diset "Selalu Acak" oleh guru, atau kedua varian bank sudah terpakai (SPEC §3.4, §7.4)
      if (hasGenerator(act.cell) && (act.reused || this.alwaysRandom.has(act.cell[0]!))) {
        const seed = seedFrom(this.seed, studentId, act.cell, this.state.cards[act.cell]?.served ?? 0);
        q = generateQuestion(act.cell, seed, q) ?? q;
      }
      let options: DeliveryRec["options"] = null;
      let correctToken: string | null = null;
      if (q.tipe === "pg") {
        const base = q.acak_opsi ? shuffle(q.opsi) : q.opsi.slice();
        options = base.map((text) => ({ optId: token(4), text }));
        correctToken = options.find((o) => o.text === q.jawaban)!.optId;
      }
      rec = {
        deliveryId: act.deliveryId,
        nonce: token(8),
        q,
        cell: act.cell,
        mode: act.mode,
        options,
        correctToken,
        hidden: new Set(),
        used: false,
      };
      this.deliveries.set(studentId, rec);
    }
    return this.deliverPayload(rec, p);
  }

  private deliverPayload(rec: DeliveryRec, p: Player): QuestionDeliver {
    const act = p.active!;
    const q = rec.q;
    const kol = KOLOM_LABEL[q.kolom]!;
    return {
      deliveryId: rec.deliveryId,
      nonce: rec.nonce,
      cell: rec.cell,
      mode: rec.mode,
      level: q.level,
      kategori: q.kolom === "H" ? "Mystery" : kol.nama,
      tipe: q.tipe,
      soal: q.soal,
      opsi: rec.options ? rec.options.filter((o) => !rec.hidden.has(o.optId)) : null,
      ...(q.satuan ? { satuan: q.satuan } : {}),
      ...(q.audio ? { audio: q.audio } : {}),
      serverNow: this.now,
      deadline: act.deadline,
      totalMs: act.totalMs,
    };
  }

  answer(studentId: string, a: { deliveryId: string; nonce: string; optId?: string; value?: string }): void {
    const rec = this.deliveries.get(studentId);
    if (!rec || rec.deliveryId !== a.deliveryId || rec.nonce !== a.nonce || rec.used) {
      this.emit(this.roomPlayer(studentId), "action:rejected", {
        reason: "bad_delivery",
        message: "Soal ini sudah tidak aktif.",
      });
      return;
    }
    rec.used = true;
    let correct = false;
    let raw = "";
    if (rec.q.tipe === "pg") {
      // simpan teks opsi yang dipilih (bukan token acak) agar sebaran pengecoh dapat dianalisis
      raw = rec.options?.find((o) => o.optId === a.optId)?.text ?? "";
      correct = rec.correctToken !== null && a.optId === rec.correctToken && !rec.hidden.has(a.optId);
    } else {
      raw = String(a.value ?? "").slice(0, 80);
      correct = judgeValue(rec.q, raw);
    }
    const act = this.state.players[studentId]?.active;
    const startedAt = act?.startedAt ?? this.now;
    const focusLost = act?.focusLost ?? 0;
    const events = this.apply({ type: "answer", playerId: studentId, deliveryId: a.deliveryId, correct });
    const rej = this.rejection(events);
    if (rej) {
      this.deliveries.delete(studentId);
      this.emit(this.roomPlayer(studentId), "answer:result", {
        correct: false,
        reason: "expired",
        pointsGained: 0,
        streak: this.state.players[studentId]?.streak ?? 0,
        cell: rec.cell,
        mode: rec.mode,
        message: "Soal ini sudah tidak aktif.",
      } satisfies AnswerResult);
    }
    const ok = events.some((e) => e.type === "claimed" || e.type === "stolen");
    this.deps.store.finishDelivery(a.deliveryId, this.now, raw, ok, focusLost);
    this.inspectAnswer(studentId, rec, a, ok, this.now - startedAt);
  }

  /** Detektor SPEC §5.2 yang berjalan setelah jawaban dinilai. Hanya mencatat bendera, tidak memberi penalti otomatis. */
  private inspectAnswer(studentId: string, rec: DeliveryRec, a: { optId?: string }, ok: boolean, elapsedMs: number) {
    const q = rec.q;
    const cfg = this.deps.config;
    const tooFast = isTooFast(cfg, { level: q.level, correct: ok, elapsedMs, words: wordCount(q.soal) });
    if (tooFast) {
      this.flag(
        studentId,
        "terlalu_cepat",
        "kuning",
        `menjawab ${q.sel} benar dalam ${(elapsedMs / 1000).toFixed(1)} detik`,
      );
    }
    const relay = isRelay({
      fails: this.fails,
      claim: { cell: rec.cell, studentId, ts: this.now, tooFast: ok && tooFast },
      neighbors: this.neighbors,
      windowMs: cfg.anti_curang.relay_jendela_detik * 1000,
    });
    if (relay) {
      this.flag(
        studentId,
        "relay",
        "oranye",
        `mengklaim ${rec.cell} sangat cepat setelah ${this.nameOf(relay.studentId)} gagal di kartu itu`,
      );
    }
    if (!ok && q.tipe === "pg" && a.optId) {
      const chosen = rec.options?.find((o) => o.optId === a.optId)?.text;
      if (chosen) {
        for (const hit of this.wrongTracker.record(studentId, q.id, chosen)) {
          this.flag(
            studentId,
            "pola_sama",
            "oranye",
            `memilih jawaban salah yang sama dengan ${this.nameOf(hit.other)} sebanyak ${hit.count} kali`,
            `pola:${[studentId, hit.other].sort().join("~")}`,
          );
        }
      }
    }
  }

  // ---------- bendera & sanksi (SPEC §5.2, §5.4, §5.5) ----------

  /** Peta kursi opsional untuk detektor relay. */
  setNeighbors(map: Record<string, string[]>) {
    this.neighbors = map;
  }

  flagList(): FlagItem[] {
    return this.flags;
  }

  /** Mencatat bendera (dengan kunci untuk mencegah duplikat) dan memberi tahu guru. */
  flag(studentId: string | undefined | null, type: FlagType, severity: FlagSeverity, text: string, key?: string) {
    if (key) {
      if (this.flagKeys.has(key)) return;
      this.flagKeys.add(key);
    }
    const ts = this.now;
    const id = this.deps.store.insertFlag(this.id, studentId ?? null, type, severity, { text }, ts);
    const item: FlagItem = {
      id,
      ts,
      studentId: studentId ?? null,
      name: studentId ? shortName(this.idents.get(studentId)?.name ?? "?") : "",
      type,
      severity,
      text,
      status: "open",
    };
    this.flags.push(item);
    this.emit(this.roomHost(), "host:flags", this.flags);
  }

  /** Dipanggil socket saat perangkat lama murid diputus karena login ganda. */
  reportMultiLogin(studentId: string) {
    this.flag(studentId, "login_ganda", "merah", "masuk dari perangkat kedua; perangkat lama diputus");
  }

  resolveFlag(id: number, action: "abaikan" | "tindak", level?: 1 | 2 | 3 | 4): string {
    const f = this.flags.find((x) => x.id === id);
    if (!f) return "Bendera tidak ditemukan.";
    let msg = "Bendera diabaikan.";
    if (action === "tindak") {
      if (!f.studentId || !level) return "Pilih sanksi untuk murid ini.";
      msg = this.sanction(f.studentId, level, `bendera ${f.type}`);
      f.status = "ditindak";
    } else f.status = "diabaikan";
    this.deps.store.setFlagStatus(id, f.status);
    this.emit(this.roomHost(), "host:flags", this.flags);
    return msg;
  }

  /** Sanksi berjenjang yang mendidik: 1 peringatan pribadi, 2 batalkan klaim terakhir, 3 −1 tiket & −30 poin, 4 bekukan 3 menit. */
  sanction(studentId: string, level: 1 | 2 | 3 | 4, why: string): string {
    const p = this.state.players[studentId];
    if (!p) return "Murid belum bergabung.";
    const name = this.nameOf(studentId);
    if (level === 1) {
      this.emit(this.roomPlayer(studentId), "toast", {
        level: "warn",
        text: "Pesan dari guru: ayo bermain jujur ya. Strategi boleh licik, cara harus jujur.",
      });
      return `Peringatan pribadi dikirim ke ${name}.`;
    }
    if (level === 2) {
      const cell = p.lastClaim;
      const card = cell ? this.state.cards[cell] : undefined;
      if (!cell || !card || card.owner !== studentId || card.status !== "CLAIMED")
        return `${name} tidak punya klaim terakhir yang bisa dibatalkan.`;
      this.apply({ type: "host_void", cell });
      return `Klaim ${cell} milik ${name} dibatalkan.`;
    }
    if (level === 3) {
      this.apply({ type: "host_ticket", playerId: studentId, delta: -1, reason: `sanksi: ${why}` });
      this.apply({ type: "host_adjust", playerId: studentId, delta: -30, reason: `sanksi: ${why}` });
      return `${name} kehilangan 1 tiket rebut dan 30 poin.`;
    }
    this.apply({ type: "host_freeze", playerId: studentId, frozen: true, untilMs: 3 * 60_000 });
    return `${name} dibekukan 3 menit.`;
  }

  focusLost(studentId: string, deliveryId: string) {
    this.notify(studentId, this.apply({ type: "focus_lost", playerId: studentId, deliveryId }));
  }

  usePowerUp(studentId: string, powerUp: PowerUp, cell?: string) {
    const events = this.apply({ type: "powerup", playerId: studentId, powerUp, ...(cell ? { cell } : {}) });
    this.notify(studentId, events);
    if (!events.some((e) => e.type === "powerup_used")) return;
    const p = this.state.players[studentId];
    const rec = this.deliveries.get(studentId);
    if (powerUp === "50_50" && rec?.options) {
      const wrong = shuffle(rec.options.filter((o) => o.optId !== rec.correctToken));
      if (rec.options.length >= 4) wrong.slice(0, 2).forEach((o) => rec.hidden.add(o.optId));
    }
    if ((powerUp === "50_50" || powerUp === "plus15") && rec && p?.active) {
      this.emit(this.roomPlayer(studentId), "question:update", this.deliverPayload(rec, p));
    }
    if (powerUp === "mata_elang" && cell) {
      const q = this.deps.bank.find((x) => x.sel === cell);
      const label = q ? q.subkategori.replace(/_/g, " ") : "?";
      this.emit(this.roomPlayer(studentId), "toast", {
        level: "good",
        text: `Mata Elang: kartu ${cell} bertema ${label}`,
      });
    }
  }

  // ---------- loop & host ----------

  tick(): void {
    this.apply({ type: "tick" });
    const slot = Math.floor(this.now / this.pinMs);
    if (slot !== this.lastPinSlot) {
      this.lastPinSlot = slot;
      this.emit(this.roomHost(), "host:pin", this.pinInfo());
    }
    this.countdown();
    this.vo.tick();
  }

  // ---------- Voice-Over (SPEC §7a) ----------

  /** Nama panggilan untuk VO: ejaan fonetik dari guru, atau kata pertama nama. */
  voName(id: string): string {
    return this.voNames[id] ?? this.idents.get(id)?.name.trim().split(/\s+/)[0] ?? "teman";
  }

  voSettings() {
    return this.vo.settings;
  }

  setVoSettings(p: Parameters<VoDirector["setSettings"]>[0]) {
    this.vo.setSettings(p);
    this.emit(this.roomProjector(), "vo:settings", this.vo.settings);
    this.emit(this.roomHost(), "vo:settings", this.vo.settings);
  }

  setVoName(studentId: string, name: string) {
    if (!this.idents.has(studentId)) return;
    const clean = name.trim().slice(0, 40);
    if (clean) {
      this.voNames[studentId] = clean;
      this.deps.store.setVoName(this.id, studentId, clean);
    }
    this.emit(this.roomHost(), "vo:names", this.voNames);
  }

  /** Tombol "Tes VO" guru: tidak melewati engine permainan dan tidak mengubah skor. */
  voTest(studentId?: string) {
    const id = studentId && this.idents.has(studentId) ? studentId : undefined;
    this.vo.enqueue({
      key: "klaim_l7",
      ...(id ? { studentId: id } : {}),
      sorotSel: "E6",
      params: {
        nama: id ? this.voName(id) : "teman-teman",
        ...(id ? { namaId: id } : {}),
        sel: spokenCell(this.naskah, "E6"),
      },
    });
  }

  /** Laporan kelas: rapor murid, heatmap 10×8, analisis butir (SPEC §6). Dapat dipanggil kapan saja, final setelah END. */
  report(): ClassReport {
    const lb = leaderboard(this.state);
    const attempts = buildAttempts(this.deps.store.listDeliveries(this.id), this.deps.bank);
    const badgeNames = Object.fromEntries(this.deps.badges.map((b) => [b.id, b.nama]));
    const students = lb.map((r, i) => {
      const p = this.state.players[r.playerId]!;
      const ident = this.idents.get(r.playerId)!;
      const mine = this.flags.filter((f) => f.studentId === r.playerId);
      return {
        id: r.playerId,
        name: ident.name,
        absen: ident.absen,
        initials: ident.initials,
        score: r.score,
        rank: i + 1,
        cards: r.cards,
        claims: p.claims,
        stealsWon: p.stealsWon,
        defends: p.defends,
        bestStreak: p.bestStreak,
        badges: p.badges,
        xpGain: this.ended ? xpFromScore(r.score) : null,
        flags: {
          kuning: mine.filter((f) => f.severity === "kuning").length,
          oranye: mine.filter((f) => f.severity === "oranye").length,
          merah: mine.filter((f) => f.severity === "merah").length,
        },
      };
    });
    const row = this.deps.store.listSessions().find((s) => s.id === this.id);
    return buildReport({
      sessionId: this.id,
      className: this.className,
      createdAt: row?.createdAt ?? 0,
      endedAt: this.ended ? (row?.endedAt ?? this.now) : null,
      phase: this.state.phase,
      students,
      attempts,
      badgeNames,
    });
  }

  attemptNames(): Record<string, string> {
    return Object.fromEntries([...this.idents.values()].map((i) => [i.id, i.name]));
  }

  // ---------- pengaturan sesi + Mode Stasiun ----------

  settings(): HostSettings {
    const c = this.deps.config;
    return {
      alwaysRandom: [...this.alwaysRandom].sort(),
      stationMode: this.stationMode,
      durasiMenit: c.durasi_menit,
      pengaliWaktu: c.kecepatan.pengali_waktu,
      waktuMin: c.kecepatan.waktu_min_detik,
      jedaSetiap: c.jeda_soal.setiap,
      jedaDetik: c.jeda_soal.detik,
      locked: this.state.phase !== "LOBBY",
    };
  }

  /**
   * Pengaturan waktu permainan, waktu menjawab, dan jeda. Hanya di lobi: konfigurasi ikut menentukan tenggat dan jadwal fase,
   * jadi mengubahnya di tengah permainan akan membuat replay log tidak konsisten. Mengembalikan pesan galat atau null.
   */
  setGameSettings(patch: GamePatch): string | null {
    if (this.state.phase !== "LOBBY") return "Pengaturan waktu dikunci setelah permainan dimulai.";
    const err = validatePatch(patch);
    if (err) return err;
    this.options = { ...this.options, ...patch };
    this.deps = { ...this.deps, config: applyOverrides(this.baseConfig, this.options) };
    this.deps.store.setOptions(this.id, this.options);
    // lobi hanya berisi aksi bergabung; replay membangun state baru dengan konfigurasi baru
    this.state = this.replayState();
    this.lastBoard.clear();
    this.lastMe.clear();
    this.emit(this.roomHost(), "host:settings", this.settings());
    this.emit(this.roomHost(), "state:snapshot", this.snapshotFor("host"));
    this.emit(this.roomProjector(), "state:snapshot", this.snapshotFor("projector"));
    return null;
  }

  private persistOptions() {
    this.options = { ...this.options, alwaysRandom: [...this.alwaysRandom].sort(), stationMode: this.stationMode };
    this.deps.store.setOptions(this.id, this.options);
    this.emit(this.roomHost(), "host:settings", this.settings());
    this.broadcastStations();
  }

  setAlwaysRandom(cols: string[]) {
    this.alwaysRandom = new Set(cols.filter((c) => /^[A-J]$/.test(c) && ["A", "E", "I"].includes(c)));
    this.persistOptions();
  }

  setStationMode(on: boolean) {
    this.stationMode = on;
    this.persistOptions();
  }

  stationState(): StationState {
    const ident = (id: string | null) => (id ? this.idents.get(id) : undefined);
    return {
      mode: this.stationMode,
      stations: [...this.stations.values()]
        .sort((a, b) => a.no - b.no)
        .map((s) => ({
          no: s.no,
          studentId: s.studentId,
          name: ident(s.studentId) ? shortName(ident(s.studentId)!.name) : null,
          initials: ident(s.studentId)?.initials ?? null,
        })),
      queue: this.queue.map((id) => {
        const i = this.idents.get(id)!;
        return { id, name: shortName(i.name), initials: i.initials, color: i.color };
      }),
    };
  }

  private broadcastStations() {
    this.emit(this.roomSession(), "station:state", this.stationState());
  }

  /** Mendaftarkan tablet stasiun; nomor terkecil yang kosong diberikan. */
  registerStation(socketId: string): number {
    const used = new Set([...this.stations.values()].map((s) => s.no));
    let no = 1;
    while (used.has(no)) no++;
    this.stations.set(socketId, { no, studentId: null });
    this.broadcastStations();
    return no;
  }

  unregisterStation(socketId: string) {
    const st = this.stations.get(socketId);
    if (st?.studentId) this.setOnline(st.studentId, false);
    this.stations.delete(socketId);
    this.broadcastStations();
  }

  enqueue(studentId: string): boolean {
    if (!this.idents.has(studentId) || this.queue.includes(studentId)) return false;
    if ([...this.stations.values()].some((s) => s.studentId === studentId)) return false;
    this.queue.push(studentId);
    this.broadcastStations();
    return true;
  }

  dequeue(studentId: string) {
    this.queue = this.queue.filter((x) => x !== studentId);
    this.broadcastStations();
  }

  clearQueue() {
    this.queue = [];
    this.broadcastStations();
  }

  /**
   * Stasiun memanggil murid (yang pertama di antrean bila `studentId` kosong). Murid disetujui otomatis karena stasiun
   * diawasi guru. Mengembalikan id murid, atau alasan gagal.
   */
  callStation(socketId: string, studentId?: string): { ok: true; studentId: string } | { ok: false; error: string } {
    const st = this.stations.get(socketId);
    if (!st) return { ok: false, error: "Stasiun belum terdaftar." };
    if (st.studentId) return { ok: false, error: "Stasiun ini sedang dipakai." };
    const id = studentId ?? this.queue[0];
    if (!id) return { ok: false, error: "Antrean kosong." };
    if (!this.idents.has(id)) return { ok: false, error: "Murid tidak ditemukan." };
    if ([...this.stations.values()].some((s) => s.studentId === id))
      return { ok: false, error: "Murid itu sudah di stasiun lain." };
    if (this.state.players[id]?.active) return { ok: false, error: "Murid itu sedang mengerjakan soal." };
    this.queue = this.queue.filter((x) => x !== id);
    if (!this.state.players[id]) this.approve(id);
    st.studentId = id;
    this.setOnline(id, true);
    this.broadcastStations();
    return { ok: true, studentId: id };
  }

  releaseStation(socketId: string) {
    const st = this.stations.get(socketId);
    if (!st?.studentId) return;
    this.setOnline(st.studentId, false);
    st.studentId = null;
    this.broadcastStations();
  }

  /** Guru melepas stasiun yang macet; mengembalikan id socket stasiun itu bila ada. */
  releaseStationByNo(no: number): string | null {
    for (const [sid, st] of this.stations) {
      if (st.no === no) {
        this.releaseStation(sid);
        return sid;
      }
    }
    return null;
  }

  stationOf(socketId: string): { no: number; studentId: string | null } | undefined {
    return this.stations.get(socketId);
  }

  /** Daftar yang perlu direkam guru: frasa tetap, ucapan 80 sel, dan nama murid. */
  voScript() {
    const sel: string[] = [];
    for (const c of "ABCDEFGHIJ") for (let r = 1; r <= 8; r++) sel.push(spokenCell(this.naskah, `${c}${r}`));
    return {
      frasa: fixedPhrases(this.naskah),
      sel,
      nama: this.roster.map((r) => ({ id: r.id, nama: this.voName(r.id) })),
    };
  }

  voDone(id: string) {
    this.vo.done(id);
  }

  setVoEngine(engine: string) {
    this.voEngine = engine.slice(0, 60);
    this.emit(this.roomHost(), "vo:status", { engine: this.voEngine });
  }

  voEngineName() {
    return this.voEngine;
  }

  /** Hitung mundur 10 detik terakhir (suara tiap detik; cepat basi). */
  private countdown() {
    const s = this.state;
    if (s.pausedAt !== null || !["OPEN", "BATTLE", "RUSH"].includes(s.phase)) return;
    const remain = this.deps.config.durasi_menit * 60_000 - (this.now - s.startedAt);
    const sec = Math.ceil(remain / 1000);
    if (sec > 10 || sec < 1) {
      if (sec > 10) this.lastCountdown = null;
      return;
    }
    if (this.lastCountdown === sec) return;
    this.lastCountdown = sec;
    this.vo.enqueue({ key: "hitung_mundur", expireMs: 1500, params: { n: sec } });
  }

  /** Memetakan peristiwa engine yang sudah tersimpan ke VO. Jawaban salah tidak pernah menghasilkan VO (SPEC §7a.7). */
  private voFor(e: GameEvent, batch: GameEvent[]) {
    const nm = (id: unknown) => (typeof id === "string" && id ? this.voName(id) : undefined);
    const who = e.playerId;
    switch (e.type) {
      case "claimed": {
        const cell = e.cell!;
        const card = this.state.cards[cell]!;
        const sel = spokenCell(this.naskah, cell);
        const base = { nama: nm(who) ?? "teman", ...(who ? { namaId: who } : {}), sel };
        const bonus = (why: string) =>
          batch.some((b) => b.type === "bonus" && b.playerId === who && b.data?.why === why);
        let key =
          card.row >= 8
            ? "klaim_l8"
            : card.row === 7
              ? "klaim_l7"
              : card.col === "H"
                ? "klaim_mystery"
                : card.row >= 4
                  ? "klaim_l4_6"
                  : "klaim_l1_3";
        if (e.data?.golden) key = "emas";
        else if (card.attempts >= 2 && card.jackpotPct > 0)
          key = "jackpot"; // jackpot baru layak diumumkan setelah ≥ 2 kali gagal
        else if (bonus("terjun_bebas")) key = "terjun_bebas";
        this.vo.enqueue({
          key,
          ...(who ? { studentId: who } : {}),
          sorotSel: cell,
          params: { ...base, n: card.attempts },
        });
        if (bonus("penakluk_puncak")) {
          this.vo.enqueue({
            key: "penakluk_puncak",
            ...(who ? { studentId: who } : {}),
            sorotSel: cell,
            params: { ...base, kolom: this.naskah.ucapan_kolom[cell[0]!] ?? cell[0] },
          });
        }
        if (batch.some((b) => b.type === "gift" && b.cell === cell)) {
          this.vo.enqueue({ key: "hadiah", ...(who ? { studentId: who } : {}), sorotSel: cell, params: base });
        }
        const claimed = Object.values(this.state.cards).filter(
          (c) => c.status === "CLAIMED" || c.status === "CONTESTED",
        ).length;
        const target = this.deps.config.misi_kelas.target_kartu_terklaim;
        if (!this.missionNear && !this.state.missionDone && claimed === target - 5) {
          this.missionNear = true;
          this.vo.enqueue({ key: "misi_kelas_dekat", params: { n: 5 } });
        }
        break;
      }
      case "stolen":
        this.vo.enqueue({
          key: "rebut_berhasil",
          ...(who ? { studentId: who } : {}),
          sorotSel: e.cell!,
          params: {
            nama: nm(who) ?? "teman",
            ...(who ? { namaId: who } : {}),
            pemilik: nm(e.data?.from),
            sel: spokenCell(this.naskah, e.cell!),
          },
        });
        break;
      case "steal_started":
        this.vo.enqueue({
          key: "rebut_mulai",
          ...(who ? { studentId: who } : {}),
          sorotSel: e.cell!,
          params: {
            nama: nm(who) ?? "teman",
            ...(who ? { namaId: who } : {}),
            pemilik: nm(e.data?.owner),
            sel: spokenCell(this.naskah, e.cell!),
          },
        });
        break;
      case "steal_failed":
        this.vo.enqueue({
          key: "rebut_gagal",
          sorotSel: e.cell!,
          params: { pemilik: nm(e.data?.owner), sel: spokenCell(this.naskah, e.cell!) },
        });
        break;
      case "streak": {
        const n = Number(e.data?.streak);
        if (n === 3 || n === 5 || n === 8) {
          this.vo.enqueue({
            key: `streak_${n}`,
            ...(who ? { studentId: who } : {}),
            params: { nama: nm(who) ?? "teman", ...(who ? { namaId: who } : {}) },
          });
        }
        break;
      }
      case "phase":
        if (e.data?.phase === "BATTLE") this.vo.enqueue({ key: "fase_battle" });
        if (e.data?.phase === "RUSH") this.vo.enqueue({ key: "fase_rush" });
        break;
      case "mission":
        this.vo.enqueue({ key: "misi_kelas_tercapai" });
        break;
      case "ended":
        this.vo.enqueue({ key: "selesai" });
        break;
      default:
        break;
    }
  }

  /** Aksi guru; pemanggil (socket host) bertanggung jawab hanya meneruskan aksi bertipe host_* / start. */
  host(action: Action): GameEvent[] {
    return this.apply(action);
  }
}

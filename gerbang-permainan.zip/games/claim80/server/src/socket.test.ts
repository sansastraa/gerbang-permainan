import type { AddressInfo } from "node:net";
import { io as connect } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { JoinResult, QuestionDeliver, Snapshot } from "@claim80/shared";
import { createApp } from "./main";

const app = createApp({ dbPath: ":memory:", tickMs: 100, hostToken: "token-tes" });
let base = "";
const roster = [
  { id: "s1", name: "Rina Putri", absen: 1 },
  { id: "s2", name: "Budi Santoso", absen: 2 },
];
const sockets: Socket[] = [];
let sessionId = "";
let code = "";
let pins: Record<string, string> = {};

const open = (auth: Record<string, unknown>) => {
  const s = connect(base, { auth, transports: ["websocket"], forceNew: true });
  sockets.push(s);
  return s;
};
const once = <T>(s: Socket, ev: string) => new Promise<T>((r) => s.once(ev, r));
const joinAs = async (id: string, device: string) => {
  const s = open({ role: "player", sessionCode: code });
  await once(s, "session:info");
  const snap = once<Snapshot>(s, "state:snapshot");
  const r = await new Promise<JoinResult>((res) =>
    s.emit("join", { sessionCode: code, studentId: id, pin: pins[id], deviceId: device }, res),
  );
  expect(r).toEqual({ ok: true, status: "approved" });
  return { s, snap: await snap };
};

beforeAll(async () => {
  await new Promise<void>((r) => app.http.listen(0, r));
  base = `http://127.0.0.1:${(app.http.address() as AddressInfo).port}`;
  const created = await fetch(`${base}/api/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": "token-tes" },
    body: JSON.stringify({ className: "5A", roster, autoApprove: true }),
  });
  expect(created.status).toBe(201);
  const j = (await created.json()) as { id: string; code: string };
  sessionId = j.id;
  code = j.code;
  const p = (await (
    await fetch(`${base}/api/sessions/${sessionId}/pins`, { headers: { "x-host-token": "token-tes" } })
  ).json()) as {
    cards: { id: string; pin: string }[];
  };
  pins = Object.fromEntries(p.cards.map((c) => [c.id, c.pin]));
});
afterAll(() => {
  sockets.forEach((s) => s.close());
  app.close();
});

describe("Socket.IO", () => {
  it("host tanpa token ditolak; info join publik tidak memuat PIN", async () => {
    const bad = open({ role: "host", sessionId, hostToken: "salah" });
    const fatal = await once<{ message: string }>(bad, "fatal");
    expect(fatal.message).toMatch(/Token/);
    const info = await (await fetch(`${base}/api/join/${code}`)).json();
    expect(JSON.stringify(info)).not.toContain(pins.s1!);
    expect((info as { students: unknown[] }).students).toHaveLength(2);
  });

  it("alur lengkap: host mulai, murid klaim, soal tanpa kunci hanya ke murid, proyektor melihat papan", async () => {
    const host = open({ role: "host", sessionId, hostToken: "token-tes" });
    const hostSnap = await once<Snapshot>(host, "state:snapshot");
    expect(hostSnap.roster).toHaveLength(2);
    const proj = open({ role: "projector", sessionId });
    await once<Snapshot>(proj, "state:snapshot");
    const projEvents: string[] = [];
    proj.onAny((ev) => projEvents.push(ev));

    const { s: p1 } = await joinAs("s1", "dev1");
    host.emit("host:start");
    await new Promise((r) => setTimeout(r, 150));

    const qp = once<QuestionDeliver>(p1, "question:deliver");
    p1.emit("card:open", { cell: "J8" });
    const q = await qp;
    expect(q.cell).toBe("J8");
    expect(JSON.stringify(q)).not.toMatch(/jawaban|pembahasan/);
    await new Promise((r) => setTimeout(r, 150));
    expect(projEvents).not.toContain("question:deliver");
    expect(projEvents).toContain("board:diff");

    // reconnect: perangkat baru dengan murid yang sama memutus yang lama dan mendapat soal aktif yang sama
    const old = once<{ message: string }>(p1, "fatal");
    const { snap } = await joinAs("s1", "dev1b");
    expect((await old).message).toMatch(/perangkat lain/);
    expect(snap.question?.deliveryId).toBe(q.deliveryId);
    expect(snap.board.find((c) => c.cell === "J8")?.status).toBe("LOCKED");
  });

  it("payload tidak valid atau terlalu sering diabaikan dengan sopan", async () => {
    const { s } = await joinAs("s2", "dev2");
    s.emit("card:open", { cell: "ZZ9" });
    const rejected: unknown[] = [];
    s.on("action:rejected", (m) => rejected.push(m));
    for (let i = 0; i < 8; i++) s.emit("card:open", { cell: "A1" });
    await new Promise((r) => setTimeout(r, 300));
    expect(rejected.length).toBeGreaterThan(0);
  });
});

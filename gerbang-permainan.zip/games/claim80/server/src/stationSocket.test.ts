import type { AddressInfo } from "node:net";
import { io as connect } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import type { AnswerResult, HostSettings, QuestionDeliver, StationState } from "@claim80/shared";
import { createApp } from "./main";
import { loadBank } from "./questions/bank";

const bank = loadBank();
const app = createApp({ dbPath: ":memory:", tickMs: 100, hostToken: "token-stasiun" });
const sockets: Socket[] = [];
let base = "";
let sessionId = "";
let code = "";

const open = (auth: Record<string, unknown>) => {
  const s = connect(base, { auth, transports: ["websocket"], forceNew: true });
  sockets.push(s);
  return s;
};
const once = <T>(s: Socket, ev: string) => new Promise<T>((r) => s.once(ev, r));
const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));

beforeAll(async () => {
  await new Promise<void>((r) => app.http.listen(0, r));
  base = `http://127.0.0.1:${(app.http.address() as AddressInfo).port}`;
  const res = await fetch(`${base}/api/sessions`, {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": "token-stasiun" },
    body: JSON.stringify({
      className: "5A",
      roster: [
        { id: "s1", name: "Rina Putri", absen: 1 },
        { id: "s2", name: "Budi Santoso", absen: 2 },
      ],
    }),
  });
  const j = (await res.json()) as { id: string; code: string };
  sessionId = j.id;
  code = j.code;
});
afterAll(() => {
  sockets.forEach((s) => s.close());
  app.close();
});

describe("Mode Stasiun lewat Socket.IO", () => {
  it("stasiun wajib token guru", async () => {
    const bad = open({ role: "station", sessionCode: code, hostToken: "salah" });
    expect((await once<{ message: string }>(bad, "fatal")).message).toMatch(/Token/);
  });

  it("guru mengatur sesi di lobi; murid dipanggil dari antrean, menjawab lewat pipeline pemain, lalu dilepas", async () => {
    const host = open({ role: "host", sessionId, hostToken: "token-stasiun" });
    await once(host, "state:snapshot");

    // pengaturan lewat socket: berhasil di lobi
    const setP = once<HostSettings>(host, "host:settings");
    host.emit("host:game-settings", { durasiMenit: 30, pengaliWaktu: 1, jedaSetiap: 2, jedaDetik: 0 });
    expect((await setP).durasiMenit).toBe(30);
    host.emit("host:random", { cols: ["E"] });
    host.emit("host:station-mode", { on: true });
    await sleep(150);
    expect(app.registry.get(sessionId)!.settings()).toMatchObject({
      durasiMenit: 30,
      alwaysRandom: ["E"],
      stationMode: true,
    });

    // tablet stasiun
    const st = open({ role: "station", sessionCode: code, hostToken: "token-stasiun" });
    const info = await once<{ no: number }>(st, "station:info");
    expect(info.no).toBe(1);

    host.emit("host:start");
    host.emit("host:queue:add", { studentId: "s1" });
    await sleep(200);
    const state = app.registry.get(sessionId)!.stationState();
    expect(state.queue.map((q) => q.id)).toEqual(["s1"]);

    const assigned = once<{ studentId: string }>(st, "station:assigned");
    st.emit("station:call", {});
    expect((await assigned).studentId).toBe("s1");

    const qP = once<QuestionDeliver>(st, "question:deliver");
    st.emit("card:open", { cell: "A2" });
    const q = await qP;
    expect(JSON.stringify(q)).not.toMatch(/jawaban|pembahasan/);
    const item = bank.find((b) => b.sel === "A2" && b.soal === q.soal)!;
    const rP = once<AnswerResult>(st, "answer:result");
    st.emit("answer:submit", {
      deliveryId: q.deliveryId,
      nonce: q.nonce,
      ...(item.tipe === "pg"
        ? { optId: q.opsi!.find((o) => o.text === item.jawaban)!.optId }
        : { value: String(item.tipe === "angka" ? item.jawaban : "") }),
    });
    expect((await rP).correct).toBe(true);
    expect(app.registry.get(sessionId)!.publicCard("A2").ownerId).toBe("s1");

    // dilepas: stasiun kosong lagi dan tidak lagi menerima aksi murid itu
    const rel = once(st, "station:released");
    st.emit("station:release");
    await rel;
    await sleep(100);
    expect(app.registry.get(sessionId)!.stationState().stations[0]!.studentId).toBeNull();
    const rejected: unknown[] = [];
    st.on("question:deliver", (m) => rejected.push(m));
    st.emit("card:open", { cell: "B2" });
    await sleep(200);
    expect(rejected).toHaveLength(0);
  });

  it("pengaturan waktu ditolak setelah permainan dimulai; panggilan ke stasiun yang terpakai ditolak", async () => {
    const host = open({ role: "host", sessionId, hostToken: "token-stasiun" });
    await once(host, "state:snapshot");
    const msg = once<{ message: string }>(host, "host:rejected");
    host.emit("host:game-settings", { durasiMenit: 10 });
    expect((await msg).message).toMatch(/dikunci/);

    const st = open({ role: "station", sessionCode: code, hostToken: "token-stasiun" });
    await once(st, "station:info");
    st.emit("station:call", { studentId: "s2" });
    await once(st, "station:assigned");
    const err = once<{ message: string }>(st, "station:error");
    st.emit("station:call", { studentId: "s1" });
    expect((await err).message).toMatch(/giliran/);

    // guru melepas stasiun yang macet
    const rel = once(st, "station:released");
    host.emit("host:station:release", { no: app.registry.get(sessionId)!.stationOf(st.id!)!.no });
    await rel;
    const states: StationState[] = [];
    host.on("station:state", (s: StationState) => states.push(s));
    st.close();
    await sleep(200);
    expect(
      app.registry
        .get(sessionId)!
        .stationState()
        .stations.some((s) => s.studentId === "s2"),
    ).toBe(false);
  });
});

import type { GameConfig } from "@claim80/shared";
import type { SessionOptions } from "./db";

export const LIMITS = {
  durasiMenit: [5, 120],
  pengaliWaktu: [0.3, 2],
  waktuMin: [5, 60],
  jedaSetiap: [1, 10],
  jedaDetik: [0, 60],
} as const;

const clamp = (v: number, [lo, hi]: readonly [number, number]) => Math.min(hi, Math.max(lo, v));

/**
 * Jadwal fase untuk durasi tertentu. Durasi bawaan memakai jadwal config apa adanya; durasi lain diskalakan:
 * BATTLE di 37,5% waktu (seperti 15 dari 40 menit), RUSH pada menit-menit terakhir (5 menit, atau seperempat durasi bila pendek).
 */
export function scaleFase(base: GameConfig, durasi: number): GameConfig["fase"] {
  if (durasi === base.durasi_menit) return base.fase;
  const battle = Math.max(1, Math.round(durasi * (15 / 40)));
  const rushLen = Math.min(5, Math.max(1, Math.floor(durasi / 4)));
  const rush = Math.max(battle + 1, durasi - rushLen);
  const start: Record<string, number> = { OPEN: 0, BATTLE: battle, RUSH: rush, END: durasi };
  return base.fase.map((f) => ({ ...f, mulai_menit: start[f.id] ?? f.mulai_menit }));
}

/** Konfigurasi efektif sebuah sesi: config dasar + pengaturan guru (dikunci setelah permainan dimulai agar replay konsisten). */
export function applyOverrides(base: GameConfig, o: SessionOptions): GameConfig {
  const durasi = clamp(o.durasiMenit ?? base.durasi_menit, LIMITS.durasiMenit);
  return {
    ...base,
    durasi_menit: durasi,
    fase: scaleFase(base, durasi),
    kecepatan: {
      ...base.kecepatan,
      pengali_waktu: clamp(o.pengaliWaktu ?? base.kecepatan.pengali_waktu, LIMITS.pengaliWaktu),
      waktu_min_detik: clamp(o.waktuMin ?? base.kecepatan.waktu_min_detik, LIMITS.waktuMin),
    },
    jeda_soal: {
      ...base.jeda_soal,
      setiap: Math.round(clamp(o.jedaSetiap ?? base.jeda_soal.setiap, LIMITS.jedaSetiap)),
      detik: clamp(o.jedaDetik ?? base.jeda_soal.detik, LIMITS.jedaDetik),
    },
  };
}

export type GamePatch = Partial<
  Pick<SessionOptions, "durasiMenit" | "pengaliWaktu" | "waktuMin" | "jedaSetiap" | "jedaDetik">
>;

/** Memeriksa patch dari guru; mengembalikan pesan galat ramah atau null bila valid. */
export function validatePatch(p: GamePatch): string | null {
  const bad = (k: keyof typeof LIMITS, v: number | undefined) =>
    v !== undefined && (!Number.isFinite(v) || v < LIMITS[k][0] || v > LIMITS[k][1]);
  if (bad("durasiMenit", p.durasiMenit)) return `Durasi harus ${LIMITS.durasiMenit[0]}–${LIMITS.durasiMenit[1]} menit.`;
  if (bad("pengaliWaktu", p.pengaliWaktu)) return "Pengali waktu menjawab harus 30%–200%.";
  if (bad("waktuMin", p.waktuMin)) return `Waktu minimum harus ${LIMITS.waktuMin[0]}–${LIMITS.waktuMin[1]} detik.`;
  if (bad("jedaSetiap", p.jedaSetiap)) return "Jeda dihitung tiap 1–10 soal.";
  if (bad("jedaDetik", p.jedaDetik)) return "Lama jeda 0–60 detik (0 = tanpa jeda).";
  return null;
}

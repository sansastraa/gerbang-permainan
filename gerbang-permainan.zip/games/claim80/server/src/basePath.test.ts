import { mkdtempSync, writeFileSync } from "node:fs";
import type { AddressInfo } from "node:net";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { io as connect } from "socket.io-client";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { normalizeBasePath, viaProxy } from "./basePath";
import { createApp, lanUrls } from "./main";

describe("normalizeBasePath", () => {
  it("menormalkan ke awalan / tanpa / akhir", () => {
    expect(normalizeBasePath(undefined)).toBe("");
    expect(normalizeBasePath("")).toBe("");
    expect(normalizeBasePath("/")).toBe("");
    expect(normalizeBasePath("games/claim80")).toBe("/games/claim80");
    expect(normalizeBasePath("/games/claim80/")).toBe("/games/claim80");
    expect(normalizeBasePath("//games//claim80//")).toBe("/games/claim80");
  });
  it("viaProxy mengenali header proxy", () => {
    expect(viaProxy({})).toBe(false);
    expect(viaProxy({ "x-forwarded-for": "10.0.0.5" })).toBe(true);
    expect(viaProxy({ forwarded: "for=1.2.3.4" })).toBe(true);
    expect(viaProxy({ "x-real-ip": "1.2.3.4" })).toBe(true);
  });
  it("lanUrls memuat awalan jalur", () => {
    for (const u of lanUrls(3080, "/games/claim80")) expect(u).toMatch(/:3080\/games\/claim80$/);
  });
});

const dist = mkdtempSync(join(tmpdir(), "c80-dist-"));
writeFileSync(join(dist, "index.html"), "<!doctype html><title>SPA-CLAIM80</title>");
const BASE = "/games/claim80";
const app = createApp({ dbPath: ":memory:", tickMs: 1_000_000, basePath: BASE, distDir: dist });
let root = "";
beforeAll(async () => {
  await new Promise<void>((r) => app.http.listen(0, r));
  root = `http://127.0.0.1:${(app.http.address() as AddressInfo).port}`;
});
afterAll(() => app.close());

describe("BASE_PATH=/games/claim80", () => {
  it("/health dan /api hanya di bawah awalan", async () => {
    const h = await fetch(`${root}${BASE}/health`);
    expect(h.status).toBe(200);
    expect(await h.json()).toMatchObject({ ok: true, soal: 160 });
    expect((await fetch(`${root}/health`)).status).toBe(404);
    expect((await fetch(`${root}/api/sessions`)).status).toBe(404);
    expect((await fetch(`${root}${BASE}/api/sessions`)).status).toBe(401);
    const ok = await fetch(`${root}${BASE}/api/sessions`, { headers: { "x-host-token": app.hostToken } });
    expect(ok.status).toBe(200);
  });

  it("fallback SPA untuk /host, /play, /projector, /station, dan akar awalan", async () => {
    for (const p of ["", "/", "/host", "/host/abc", "/play/KODE", "/projector/KODE", "/station/KODE", "/report/x"]) {
      const r = await fetch(`${root}${BASE}${p}`);
      expect(r.status, p).toBe(200);
      expect(await r.text(), p).toContain("SPA-CLAIM80");
    }
    // /api yang tidak ada jangan jatuh ke SPA
    expect((await fetch(`${root}${BASE}/api/tidak-ada`)).status).toBe(404);
  });

  it("socket.io di bawah awalan: handshake polling dan klien tersambung; jalur akar tidak", async () => {
    const poll = await fetch(`${root}${BASE}/socket.io/?EIO=4&transport=polling`);
    expect(poll.status).toBe(200);
    expect(await poll.text()).toMatch(/^0\{.*"sid"/);
    const akar = await fetch(`${root}/socket.io/?EIO=4&transport=polling`);
    expect(akar.status).not.toBe(200);

    const create = await fetch(`${root}${BASE}/api/sessions`, {
      method: "POST",
      headers: { "content-type": "application/json", "x-host-token": app.hostToken },
      body: JSON.stringify({ className: "5A", roster: [{ id: "a", name: "Rina Putri" }], autoApprove: true }),
    });
    const { id } = (await create.json()) as { id: string };
    const code = app.registry.get(id)!.code;
    const s = connect(root, {
      path: `${BASE}/socket.io`,
      auth: { role: "projector", sessionCode: code },
      transports: ["websocket"],
    });
    await new Promise<void>((res, rej) => {
      s.on("connect", () => res());
      s.on("connect_error", rej);
    });
    expect(s.connected).toBe(true);
    s.close();
  });

  it("/api/host-token: langsung dari loopback boleh, lewat gerbang (X-Forwarded-For) ditolak", async () => {
    const direct = await fetch(`${root}${BASE}/api/host-token`);
    expect(direct.status).toBe(200);
    expect(((await direct.json()) as { token: string }).token).toBe(app.hostToken);
    for (const h of <Record<string, string>[]>[
      { "x-forwarded-for": "192.168.1.9" },
      { forwarded: "for=192.168.1.9" },
      { "x-real-ip": "1.2.3.4" },
    ]) {
      const r = await fetch(`${root}${BASE}/api/host-token`, { headers: h });
      expect(r.status).toBe(403);
      expect(await r.text()).not.toContain(app.hostToken);
    }
  });
});

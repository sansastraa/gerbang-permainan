import { describe, expect, it } from "vitest";
import type { QuestionDeliver } from "@claim80/shared";
import { judgeValue, scoreOf } from "@claim80/shared";
import { Store } from "./db";
import { generateQuestion, seedFrom } from "./questions/generators";
import { loadBadges, loadBank, loadConfig } from "./questions/bank";
import { Registry } from "./registry";

const bank = loadBank();
const badges = loadBadges();
const roster = ["Rina Putri", "Budi Santoso", "Sari Dewi", "Andi Saputra"].map((name, i) => ({
  id: `s${i + 1}`,
  name,
  absen: i + 1,
}));

interface Sent {
  room: string;
  event: string;
  payload: unknown;
}

function make(opts: { jeda?: boolean; autoApprove?: boolean } = {}) {
  let now = 1_700_000_000_000;
  const sent: Sent[] = [];
  const store = new Store(":memory:");
  const config = opts.jeda ? loadConfig() : { ...loadConfig(), jeda_soal: { setiap: 2, detik: 0 } };
  const mk = () =>
    new Registry({
      store,
      bank,
      config,
      badges,
      clock: () => now,
      emitter: { emit: (room, event, payload) => void sent.push({ room, event, payload }) },
    });
  const reg = mk();
  const s = reg.create({ className: "5A", roster, autoApprove: opts.autoApprove ?? true, seed: 33 });
  for (const r of roster) s.join(r.id, s.currentPin(), `dev-${r.id}`);
  return {
    s,
    sent,
    store,
    reg,
    mk,
    set: (t: number) => (now = t),
    advance: (ms: number) => {
      now += ms;
      s.tick();
    },
    get now() {
      return now;
    },
    deliver: (id: string) =>
      [...sent].reverse().find((m) => m.event === "question:deliver" && m.room === `player:${id}`)
        ?.payload as QuestionDeliver,
  };
}

describe("pengaturan waktu permainan (lobi)", () => {
  it("durasi, waktu menjawab, dan jeda berlaku; disimpan dan pulih setelah restart", () => {
    const t = make({ autoApprove: true });
    expect(t.s.settings()).toMatchObject({ durasiMenit: 40, jedaSetiap: 2, jedaDetik: 0, locked: false });
    expect(
      t.s.setGameSettings({ durasiMenit: 20, pengaliWaktu: 1, waktuMin: 10, jedaSetiap: 3, jedaDetik: 8 }),
    ).toBeNull();
    expect(t.s.settings()).toMatchObject({
      durasiMenit: 20,
      pengaliWaktu: 1,
      waktuMin: 10,
      jedaSetiap: 3,
      jedaDetik: 8,
    });
    // pemain yang sudah bergabung di lobi tetap ada setelah state dibangun ulang
    expect(Object.keys(t.s.state.players)).toHaveLength(4);
    const snap = t.s.snapshotFor("projector");
    expect(snap.durationMs).toBe(20 * 60_000);
    expect(snap.rules.waktuDetik[2]).toBe(30); // A2: 30 dtk × 100%
    expect(t.s.state.rules.config.fase.map((f) => f.mulai_menit)).toEqual([0, 8, 15, 20]);
    // kartu level 2 memakai waktu menjawab baru
    t.s.host({ type: "start" });
    t.s.claim("s1", "A2");
    expect(t.deliver("s1").totalMs).toBe(30_000);
    // restart: pengaturan ikut pulih
    const reg2 = t.mk();
    reg2.restoreAll();
    const s2 = reg2.get(t.s.id)!;
    expect(s2.settings()).toMatchObject({
      durasiMenit: 20,
      pengaliWaktu: 1,
      jedaSetiap: 3,
      jedaDetik: 8,
      locked: true,
    });
    expect(s2.state.rules.config.durasi_menit).toBe(20);
  });

  it("waktu menjawab bawaan lebih ketat; fase berjalan menurut durasi baru", () => {
    const t = make();
    t.s.setGameSettings({ durasiMenit: 10 });
    t.s.host({ type: "start" });
    t.advance(60_000 * 4.1); // BATTLE dimulai di menit ke-4 (37,5% dari 10 menit)
    expect(t.s.state.phase).toBe("BATTLE");
    t.advance(60_000 * 3.5); // menit 7,6: RUSH baru mulai di menit 8 (10 − 2)
    expect(t.s.state.phase).toBe("BATTLE");
    t.advance(60_000 * 0.5);
    expect(t.s.state.phase).toBe("RUSH");
    t.advance(60_000 * 2);
    expect(t.s.state.phase).toBe("END");
  });

  it("dikunci setelah permainan dimulai dan nilai tak wajar ditolak", () => {
    const t = make();
    expect(t.s.setGameSettings({ durasiMenit: 2 })).toMatch(/Durasi/);
    expect(t.s.setGameSettings({ jedaDetik: 500 })).toMatch(/Lama jeda/);
    expect(t.s.settings().durasiMenit).toBe(40);
    t.s.host({ type: "start" });
    expect(t.s.setGameSettings({ durasiMenit: 10 })).toMatch(/dikunci/);
    expect(t.s.settings()).toMatchObject({ durasiMenit: 40, locked: true });
  });

  it("jeda 5 detik setiap 2 soal berlaku di sesi sungguhan dan murid melihat batas waktunya", () => {
    const t = make({ jeda: true });
    t.s.host({ type: "start" });
    const ans = (id: string, cell: string) => {
      t.s.claim(id, cell);
      const q = t.deliver(id);
      t.s.answer(id, { deliveryId: q.deliveryId, nonce: q.nonce, value: "-1", optId: "salah" });
    };
    ans("s1", "A1");
    expect(t.s.me("s1")!.cooldownUntil).toBe(0);
    ans("s1", "B1");
    expect(t.s.me("s1")!.cooldownUntil).toBe(t.now + 5000);
    t.s.claim("s1", "C1");
    expect(
      t.sent.some(
        (m) => m.event === "action:rejected" && m.room === "player:s1" && /tunggu/.test(JSON.stringify(m.payload)),
      ),
    ).toBe(true);
    expect(t.s.state.players.s1!.active).toBeNull();
    t.advance(5100);
    t.s.claim("s1", "C1");
    expect(t.s.state.players.s1!.active).not.toBeNull();
  });
});

describe("soal acak (generator parametrik)", () => {
  it("kolom diset Selalu Acak: tiap murid mendapat angka berbeda dan penilaian memakai soal acak itu", () => {
    const t = make();
    t.s.setAlwaysRandom(["E", "A", "B"]); // B tidak punya generator → diabaikan
    expect(t.s.settings().alwaysRandom).toEqual(["A", "E"]);
    t.s.host({ type: "start" });
    t.s.claim("s1", "E5");
    t.s.claim("s2", "E6");
    const q1 = t.deliver("s1");
    const tmpl = bank.find((b) => b.sel === "E5" && b.varian === t.s.state.players.s1!.active!.variant)!;
    const expected = generateQuestion("E5", seedFrom(t.s.seed, "s1", "E5", t.s.state.cards.E5!.served), tmpl)!;
    expect(q1.soal).toBe(expected.soal);
    expect(q1.soal).not.toBe(tmpl.soal);
    expect(JSON.stringify(q1)).not.toMatch(/jawaban|pembahasan/);
    if (expected.tipe !== "angka") throw new Error("E5 harus angka");
    t.s.answer("s1", { deliveryId: q1.deliveryId, nonce: q1.nonce, value: String(expected.jawaban) });
    expect(t.s.publicCard("E5").ownerId).toBe("s1");
    expect(scoreOf(t.s.state, "s1")).toBeGreaterThan(0);
    expect(judgeValue(expected, String(expected.jawaban))).toBe(true);
    // reconnect memberi soal yang sama (seed deterministik)
    const q2 = t.deliver("s2");
    expect(t.s.snapshotFor("player", "s2").question?.soal).toBe(q2.soal);
  });

  it("setelah kedua varian bank terpakai, percobaan berikutnya memakai soal acak (SPEC §3.4)", () => {
    const t = make();
    t.s.host({ type: "start" });
    const texts: string[] = [];
    for (let i = 0; i < 3; i++) {
      t.s.claim("s1", "E3");
      const q = t.deliver("s1");
      texts.push(q.soal);
      t.s.answer("s1", { deliveryId: q.deliveryId, nonce: q.nonce, value: "-1" });
    }
    const bankTexts = bank.filter((b) => b.sel === "E3").map((b) => b.soal);
    expect(bankTexts).toContain(texts[0]);
    expect(bankTexts).toContain(texts[1]);
    expect(bankTexts).not.toContain(texts[2]); // percobaan ke-3 = soal acak
    const rep = t.s.report();
    expect(rep.jumlahPercobaan).toBe(3);
    // soal acak ikut statistik murid tetapi tidak masuk analisis butir bank
    expect(rep.butir.every((b) => !/-g/.test(b.questionId))).toBe(true);
  });
});

describe("Mode Stasiun", () => {
  it("stasiun mendapat nomor terkecil yang kosong dan dilepas saat terputus", () => {
    const t = make();
    expect(t.s.registerStation("sock-a")).toBe(1);
    expect(t.s.registerStation("sock-b")).toBe(2);
    t.s.unregisterStation("sock-a");
    expect(t.s.registerStation("sock-c")).toBe(1);
    expect(t.s.stationState().stations.map((s) => s.no)).toEqual([1, 2]);
  });

  it("antrean: tambah, tolak ganda, hapus, kosongkan; tampil nama singkat dan inisial", () => {
    const t = make();
    expect(t.s.enqueue("s1")).toBe(true);
    expect(t.s.enqueue("s1")).toBe(false);
    expect(t.s.enqueue("nope")).toBe(false);
    t.s.enqueue("s2");
    expect(t.s.stationState().queue.map((q) => q.id)).toEqual(["s1", "s2"]);
    expect(t.s.stationState().queue[0]).toMatchObject({ initials: "RP", name: "Rina Putri" });
    t.s.dequeue("s1");
    expect(t.s.stationState().queue.map((q) => q.id)).toEqual(["s2"]);
    t.s.clearQueue();
    expect(t.s.stationState().queue).toHaveLength(0);
    expect(t.sent.filter((m) => m.event === "station:state").length).toBeGreaterThan(3);
  });

  it("memanggil murid pertama di antrean, menyetujuinya otomatis, dan satu murid hanya di satu stasiun", () => {
    const t = make({ autoApprove: false });
    t.s.host({ type: "start" });
    t.s.registerStation("A");
    t.s.registerStation("B");
    t.s.enqueue("s2");
    t.s.enqueue("s3");
    const r = t.s.callStation("A");
    expect(r).toEqual({ ok: true, studentId: "s2" });
    expect(t.s.state.players.s2).toBeDefined(); // disetujui otomatis
    expect(t.s.stationState().queue.map((q) => q.id)).toEqual(["s3"]);
    expect(t.s.callStation("A")).toMatchObject({ ok: false }); // stasiun A masih dipakai
    expect(t.s.callStation("B", "s2")).toMatchObject({ ok: false, error: expect.stringMatching(/stasiun lain/) });
    expect(t.s.callStation("B")).toEqual({ ok: true, studentId: "s3" });
    expect(t.s.callStation("B", "s4")).toMatchObject({ ok: false });
    expect(t.s.stationState().stations).toMatchObject([
      { no: 1, studentId: "s2", name: "Budi Santoso" },
      { no: 2, studentId: "s3", name: "Sari Dewi" },
    ]);
    // tidak bisa masuk antrean saat sedang di stasiun
    expect(t.s.enqueue("s2")).toBe(false);
    t.s.releaseStation("A");
    expect(t.s.stationState().stations[0]!.studentId).toBeNull();
    expect(t.s.callStation("A")).toMatchObject({ ok: false, error: expect.stringMatching(/Antrean kosong/) });
  });

  it("alur stasiun: murid yang dipanggil mengklaim satu kartu lewat pipeline pemain yang sama", () => {
    const t = make({ autoApprove: false });
    t.s.host({ type: "start" });
    t.s.registerStation("A");
    t.s.enqueue("s1");
    const c = t.s.callStation("A");
    expect(c.ok).toBe(true);
    t.s.claim("s1", "A2");
    const q = t.deliver("s1");
    const item = bank.find((b) => b.sel === "A2" && b.soal === q.soal)!;
    t.s.answer("s1", {
      deliveryId: q.deliveryId,
      nonce: q.nonce,
      value: String(item.tipe === "angka" ? item.jawaban : ""),
      optId: item.tipe === "pg" ? q.opsi!.find((o) => o.text === item.jawaban)!.optId : undefined,
    });
    expect(t.s.publicCard("A2").ownerId).toBe("s1");
    t.s.releaseStation("A");
    expect(t.s.releaseStationByNo(1)).toBe("A");
    expect(t.s.releaseStationByNo(9)).toBeNull();
  });

  it("mode stasiun tersimpan, memengaruhi bendera perangkat bersama, dan ikut snapshot guru/proyektor", () => {
    const t = make({ autoApprove: false });
    t.s.setStationMode(true);
    expect(t.s.settings().stationMode).toBe(true);
    expect(t.s.snapshotFor("projector").station?.mode).toBe(true);
    expect(t.s.snapshotFor("host").station?.mode).toBe(true);
    expect(t.s.snapshotFor("player", "s1").station).toBeUndefined();
    const reg2 = t.mk();
    reg2.restoreAll();
    expect(reg2.get(t.s.id)!.settings().stationMode).toBe(true);
  });
});

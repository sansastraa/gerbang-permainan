import { classMedians, heatmap, itemAnalysis, rapotText, studentIndicators } from "./stats";
import type { Attempt, HeatCell, ItemStat, KategoriStat, StudentIndicators } from "./stats";

export interface ReportStudentInput {
  id: string;
  name: string;
  absen: number | null;
  initials: string;
  score: number;
  rank: number;
  cards: number;
  claims: number;
  stealsWon: number;
  defends: number;
  bestStreak: number;
  badges: string[];
  xpGain: number | null;
  flags: { kuning: number; oranye: number; merah: number };
}

export interface ReportInput {
  sessionId: string;
  className: string;
  createdAt: number;
  endedAt: number | null;
  phase: string;
  students: ReportStudentInput[];
  attempts: Attempt[];
  badgeNames: Record<string, string>;
}

export interface ReportStudent extends ReportStudentInput {
  indikator: StudentIndicators;
  rapor: { semangat: string; saran: string };
  badgeNames: string[];
}

export interface ClassReport {
  sessionId: string;
  className: string;
  createdAt: number;
  endedAt: number | null;
  phase: string;
  jumlahMurid: number;
  jumlahPercobaan: number;
  akurasiKelas: number | null;
  siswa: ReportStudent[];
  heatmap: HeatCell[];
  butir: ItemStat[];
  /** catatan etis yang ikut di setiap ekspor (SPEC §6.4) */
  catatan: string;
}

export const CATATAN_ETIS =
  "Profil ini adalah potret performa pada satu permainan, bukan tes IQ atau diagnosis. Kategori diilhami teori kecerdasan majemuk yang populer di pendidikan tetapi bukan alat ukur baku.";

export function buildReport(i: ReportInput): ClassReport {
  const medians = classMedians(i.attempts);
  const scores = Object.fromEntries(i.students.map((s) => [s.id, s.score]));
  const siswa = i.students.map((s): ReportStudent => {
    const indikator = studentIndicators(
      i.attempts.filter((a) => a.studentId === s.id),
      medians,
    );
    return {
      ...s,
      indikator,
      rapor: rapotText(indikator.kategori),
      badgeNames: s.badges.map((b) => i.badgeNames[b] ?? b),
    };
  });
  const right = i.attempts.filter((a) => a.correct).length;
  return {
    sessionId: i.sessionId,
    className: i.className,
    createdAt: i.createdAt,
    endedAt: i.endedAt,
    phase: i.phase,
    jumlahMurid: i.students.length,
    jumlahPercobaan: i.attempts.length,
    akurasiKelas: i.attempts.length ? right / i.attempts.length : null,
    siswa,
    heatmap: heatmap(i.attempts),
    butir: itemAnalysis(i.attempts, scores),
    catatan: CATATAN_ETIS,
  };
}

// ---------- ekspor ----------

const esc = (v: unknown): string => {
  const s = v === null || v === undefined ? "" : String(v);
  return /[",\r\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
const row = (cells: unknown[]) => cells.map(esc).join(",");
/** BOM agar Excel membaca UTF-8, CRLF agar sesuai CSV. */
const BOM = String.fromCharCode(0xfeff);
const csv = (lines: string[]) => `${BOM}${lines.join("\r\n")}\r\n`;

export function attemptsCsv(attempts: Attempt[], names: Record<string, string>): string {
  return csv([
    row([
      "murid_id",
      "nama",
      "sel",
      "varian",
      "kategori",
      "level",
      "mode",
      "benar",
      "waktu_ms",
      "alasan_gagal",
      "jawaban",
      "fokus_hilang",
    ]),
    ...attempts.map((a) =>
      row([
        a.studentId,
        names[a.studentId] ?? "",
        a.cell,
        a.variant,
        a.kategori,
        a.level,
        a.mode,
        a.correct ? 1 : 0,
        a.timeMs,
        a.reason,
        a.chosen,
        a.focusLost,
      ]),
    ),
  ]);
}

export function studentsCsv(r: ClassReport): string {
  const head = [
    "peringkat",
    "murid_id",
    "nama",
    "absen",
    "skor",
    "kartu",
    "percobaan",
    "benar",
    "akurasi",
    "level_puncak",
    "streak_terbaik",
    "keberanian",
    "ketangguhan",
    "median_waktu_ms",
    "badge",
    "bendera_kuning",
    "bendera_oranye",
    "bendera_merah",
  ];
  const kat = r.siswa[0]?.indikator.kategori ?? [];
  return csv([
    row([...head, ...kat.map((k) => `skor_${k.id}`)]),
    ...r.siswa.map((s) =>
      row([
        s.rank,
        s.id,
        s.name,
        s.absen,
        s.score,
        s.cards,
        s.indikator.percobaan,
        s.indikator.benar,
        s.indikator.akurasi === null ? "" : Math.round(s.indikator.akurasi * 1000) / 10,
        s.indikator.kategori.reduce((m: number, k: KategoriStat) => Math.max(m, k.levelPuncak), 0),
        s.bestStreak,
        s.indikator.keberanian,
        s.indikator.ketangguhan,
        s.indikator.kecepatan.medianMs,
        s.badgeNames.join(" | "),
        s.flags.kuning,
        s.flags.oranye,
        s.flags.merah,
        ...s.indikator.kategori.map((k) => k.skor),
      ]),
    ),
  ]);
}

export function itemsCsv(r: ClassReport): string {
  return csv([
    row(["soal_id", "sel", "varian", "level", "percobaan", "benar", "p_kesukaran", "daya_beda_D", "pengecoh"]),
    ...r.butir.map((b) =>
      row([
        b.questionId,
        b.cell,
        b.variant,
        b.level,
        b.percobaan,
        b.benar,
        b.p,
        b.d,
        Object.entries(b.pengecoh)
          .map(([k, v]) => `${k}: ${v}`)
          .join(" | "),
      ]),
    ),
  ]);
}

/**
 * Ringkasan hasil per siswa untuk menu "Buat Multi Permainan" di SIMPETERI. Bentuk mengikuti summary.json Route Rush
 * (`students[].studentId/name/points`), ditambah profil kecerdasan per kategori dan peringkat.
 */
export function summaryJson(r: ClassReport): unknown {
  return {
    game: "claim80",
    sessionId: r.sessionId,
    kind: "CLAIM80",
    className: r.className,
    createdAt: r.createdAt,
    endedAt: r.endedAt,
    ended: r.endedAt !== null,
    maxPoints: null,
    students: r.siswa.map((s) => ({
      studentId: s.id,
      name: s.name,
      absen: s.absen,
      isBot: false,
      points: s.score,
      rank: s.rank,
      cards: s.cards,
      attempts: s.indikator.percobaan,
      correct: s.indikator.benar,
      accuracy: s.indikator.akurasi === null ? null : Math.round(s.indikator.akurasi * 1000) / 1000,
      peakLevel: s.indikator.kategori.reduce((m, k) => Math.max(m, k.levelPuncak), 0),
      bestStreak: s.bestStreak,
      xpGain: s.xpGain,
      // profil untuk Multi Permainan: Skor Kecerdasan 0–100 per kategori (null bila percobaan < 2)
      profile: Object.fromEntries(s.indikator.kategori.map((k) => [k.id, k.skor])),
      boldness: s.indikator.keberanian,
      resilience: s.indikator.ketangguhan,
      badges: s.badges,
      integrity: s.flags,
    })),
    note: r.catatan,
  };
}

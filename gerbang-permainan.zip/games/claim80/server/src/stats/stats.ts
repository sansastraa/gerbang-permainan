import type { Question } from "@claim80/shared";

/** Kategori untuk radar (SPEC §6.2): Numerik, Linguistik (B+C), Pengetahuan Umum, Aritmetika, Spasial, Musikal, Logika (I+J). */
export const KATEGORI = [
  { id: "numerik", nama: "Numerik" },
  { id: "linguistik", nama: "Linguistik" },
  { id: "pengetahuan_umum", nama: "Pengetahuan Umum" },
  { id: "aritmetika", nama: "Aritmetika" },
  { id: "spasial", nama: "Spasial" },
  { id: "musikal", nama: "Musikal" },
  { id: "logika", nama: "Logika" },
] as const;
export type KategoriId = (typeof KATEGORI)[number]["id"];

/** Subkategori bank soal → kategori radar. Kartu H memakai subkategori soalnya; numerik_logika (kolom I) masuk Logika. */
export function kategoriOf(sub: string): KategoriId {
  if (sub === "numerik_logika") return "logika";
  return (KATEGORI.find((k) => k.id === sub)?.id ?? "logika") as KategoriId;
}

export interface Attempt {
  studentId: string;
  cell: string;
  col: string;
  level: number;
  variant: number;
  questionId: string;
  mode: "claim" | "steal";
  correct: boolean;
  /** waktu menjawab (ms); null bila tidak ada jawaban (waktu habis / layar ditinggalkan) */
  timeMs: number | null;
  /** teks opsi yang dipilih (pg) atau isian (angka/teks) */
  chosen: string | null;
  focusLost: number;
  reason: "timeout" | "fokus" | null;
  sentAt: number;
  kategori: KategoriId;
  /** soal acak dari generator (angka berbeda tiap murid): ikut statistik murid, tidak ikut analisis butir */
  generated: boolean;
}

export interface DeliveryRow {
  id: string;
  cell: string;
  student_id: string;
  question_id: string;
  mode: string;
  sent_at: number;
  answered_at: number;
  answer_raw: string | null;
  correct: number | null;
  focus_lost_count: number;
}

/** Data mentah per percobaan (SPEC §6.1) dari tabel `deliveries` + bank soal. */
export function buildAttempts(rows: DeliveryRow[], bank: Question[]): Attempt[] {
  const byId = new Map(bank.map((q) => [q.id, q]));
  const out: Attempt[] = [];
  for (const r of rows) {
    const generated = /-g[0-9a-f]+$/.test(r.question_id);
    // soal acak memakai soal bank varian 1 pada sel yang sama sebagai rujukan level dan kategori
    const q = byId.get(r.question_id) ?? (generated ? byId.get(`${r.question_id.split("-")[0]}-1`) : undefined);
    if (!q) continue;
    const reason =
      r.answer_raw === "timeout" || r.answer_raw === "fokus" ? (r.answer_raw as "timeout" | "fokus") : null;
    out.push({
      studentId: r.student_id,
      cell: r.cell,
      col: q.kolom,
      level: q.level,
      variant: q.varian,
      questionId: generated ? r.question_id : q.id,
      generated,
      mode: r.mode === "steal" ? "steal" : "claim",
      correct: r.correct === 1,
      timeMs: reason ? null : Math.max(0, r.answered_at - r.sent_at),
      chosen: reason ? null : r.answer_raw,
      focusLost: r.focus_lost_count,
      reason,
      sentAt: r.sent_at,
      kategori: kategoriOf(q.subkategori),
    });
  }
  return out;
}

export function median(xs: number[]): number | null {
  if (xs.length === 0) return null;
  const s = [...xs].sort((a, b) => a - b);
  const m = Math.floor(s.length / 2);
  return s.length % 2 ? s[m]! : (s[m - 1]! + s[m]!) / 2;
}

const round = (n: number, d = 1) => Math.round(n * 10 ** d) / 10 ** d;

export interface KategoriStat {
  id: KategoriId;
  nama: string;
  percobaan: number;
  benar: number;
  /** benar ÷ percobaan (0..1) */
  akurasi: number | null;
  /** Skor Kecerdasan 0–100; hanya bila percobaan ≥ 2 (SPEC §6.2) */
  skor: number | null;
  levelPuncak: number;
}

export interface StudentIndicators {
  percobaan: number;
  benar: number;
  akurasi: number | null;
  kategori: KategoriStat[];
  kecepatan: { medianMs: number | null; relatifKelas: number | null };
  keberanian: number | null;
  ketangguhan: number | null;
  eksplorasi: number;
}

/** Indikator per murid (SPEC §6.2). `classMedianByLevel` = median waktu benar kelas pada tiap level. */
export function studentIndicators(
  attempts: Attempt[],
  classMedianByLevel: Record<number, number | null>,
): StudentIndicators {
  const sorted = [...attempts].sort((a, b) => a.sentAt - b.sentAt);
  const kategori: KategoriStat[] = KATEGORI.map((k) => {
    const a = sorted.filter((x) => x.kategori === k.id);
    const sumTried = a.reduce((s, x) => s + x.level, 0);
    const sumRight = a.filter((x) => x.correct).reduce((s, x) => s + x.level, 0);
    return {
      id: k.id,
      nama: k.nama,
      percobaan: a.length,
      benar: a.filter((x) => x.correct).length,
      akurasi: a.length ? a.filter((x) => x.correct).length / a.length : null,
      skor: a.length >= 2 && sumTried > 0 ? round((sumRight / sumTried) * 100) : null,
      levelPuncak: a.filter((x) => x.correct).reduce((m, x) => Math.max(m, x.level), 0),
    };
  });
  const right = sorted.filter((x) => x.correct);
  const times = right.map((x) => x.timeMs).filter((t): t is number => t !== null);
  const rel = right
    .map((x) => {
      const m = classMedianByLevel[x.level];
      return x.timeMs !== null && m ? x.timeMs / m : null;
    })
    .filter((v): v is number => v !== null);
  let afterFail = 0;
  let afterFailRight = 0;
  for (let i = 1; i < sorted.length; i++) {
    if (!sorted[i - 1]!.correct) {
      afterFail++;
      if (sorted[i]!.correct) afterFailRight++;
    }
  }
  return {
    percobaan: sorted.length,
    benar: right.length,
    akurasi: sorted.length ? right.length / sorted.length : null,
    kategori,
    kecepatan: { medianMs: median(times), relatifKelas: median(rel) === null ? null : round(median(rel)!, 2) },
    keberanian: sorted.length ? round(sorted.reduce((s, x) => s + x.level, 0) / sorted.length, 2) : null,
    ketangguhan: afterFail ? round(afterFailRight / afterFail, 2) : null,
    eksplorasi: new Set(sorted.map((x) => x.kategori)).size,
  };
}

export function classMedians(attempts: Attempt[]): Record<number, number | null> {
  const out: Record<number, number | null> = {};
  for (let l = 1; l <= 8; l++) {
    out[l] = median(
      attempts.filter((a) => a.correct && a.level === l && a.timeMs !== null).map((a) => a.timeMs as number),
    );
  }
  return out;
}

export interface HeatCell {
  cell: string;
  percobaan: number;
  benar: number;
  p: number | null;
  /** tanda revisi bank soal: terlalu sulit (p < 0,2) atau terlalu mudah (p > 0,9 pada baris ≥ 5) */
  tanda: "terlalu_sulit" | "terlalu_mudah" | null;
}

const MIN_DATA_TANDA = 3;

export function heatmap(attempts: Attempt[]): HeatCell[] {
  const out: HeatCell[] = [];
  for (const c of "ABCDEFGHIJ") {
    for (let r = 1; r <= 8; r++) {
      const cell = `${c}${r}`;
      const a = attempts.filter((x) => x.cell === cell);
      const benar = a.filter((x) => x.correct).length;
      const p = a.length ? benar / a.length : null;
      let tanda: HeatCell["tanda"] = null;
      if (p !== null && a.length >= MIN_DATA_TANDA) {
        if (p < 0.2) tanda = "terlalu_sulit";
        else if (p > 0.9 && r >= 5) tanda = "terlalu_mudah";
      }
      out.push({ cell, percobaan: a.length, benar, p: p === null ? null : round(p, 3), tanda });
    }
  }
  return out;
}

export interface ItemStat {
  questionId: string;
  cell: string;
  variant: number;
  level: number;
  percobaan: number;
  benar: number;
  /** tingkat kesukaran p */
  p: number | null;
  /** daya beda D = p(27% atas) − p(27% bawah) */
  d: number | null;
  /** sebaran jawaban pengecoh (teks opsi → jumlah) */
  pengecoh: Record<string, number>;
}

/** Analisis butir (SPEC §6.3): p, daya beda D (27% atas vs bawah berdasarkan skor total), dan sebaran pengecoh. */
export function itemAnalysis(attempts: Attempt[], totalScoreByStudent: Record<string, number>): ItemStat[] {
  const ids = Object.keys(totalScoreByStudent).sort(
    (a, b) => totalScoreByStudent[b]! - totalScoreByStudent[a]! || a.localeCompare(b),
  );
  const n = Math.max(1, Math.round(ids.length * 0.27));
  const upper = new Set(ids.slice(0, n));
  const lower = new Set(ids.slice(Math.max(n, ids.length - n)));
  const byQ = new Map<string, Attempt[]>();
  for (const a of attempts.filter((x) => !x.generated)) {
    const l = byQ.get(a.questionId) ?? [];
    l.push(a);
    byQ.set(a.questionId, l);
  }
  const pOf = (xs: Attempt[]) => (xs.length ? xs.filter((x) => x.correct).length / xs.length : null);
  return [...byQ.entries()]
    .map(([questionId, xs]): ItemStat => {
      const pu = pOf(xs.filter((x) => upper.has(x.studentId)));
      const pl = pOf(xs.filter((x) => lower.has(x.studentId)));
      const pengecoh: Record<string, number> = {};
      for (const x of xs) if (!x.correct && x.chosen) pengecoh[x.chosen] = (pengecoh[x.chosen] ?? 0) + 1;
      return {
        questionId,
        cell: xs[0]!.cell,
        variant: xs[0]!.variant,
        level: xs[0]!.level,
        percobaan: xs.length,
        benar: xs.filter((x) => x.correct).length,
        p: round(pOf(xs)!, 3),
        d: pu !== null && pl !== null && ids.length >= 2 ? round(pu - pl, 3) : null,
        pengecoh,
      };
    })
    .sort((a, b) => a.cell.localeCompare(b.cell) || a.variant - b.variant);
}

/** Kalimat penyemangat dari kategori terkuat dan saran latihan dari kategori terlemah (bahasa penyemangat, bukan label). */
export function rapotText(kategori: KategoriStat[]): { semangat: string; saran: string } {
  const ada = kategori.filter((k) => k.skor !== null);
  if (ada.length === 0) {
    return {
      semangat: "Terima kasih sudah ikut bermain! Di permainan berikutnya coba ambil lebih banyak kartu.",
      saran: "Cobalah menjawab minimal dua kartu di beberapa kategori agar profilmu terlihat.",
    };
  }
  const kuat = [...ada].sort((a, b) => b.skor! - a.skor!)[0]!;
  const lemah = [...ada].sort((a, b) => a.skor! - b.skor!)[0]!;
  return {
    semangat: `Kamu tampil kuat di ${kuat.nama}${kuat.levelPuncak ? ` dan sudah menaklukkan level ${kuat.levelPuncak}` : ""}. Pertahankan ya!`,
    saran:
      ada.length > 1 && lemah.id !== kuat.id
        ? `Untuk berlatih, coba perbanyak soal ${lemah.nama} dari level yang mudah dulu, lalu naik pelan-pelan.`
        : "Coba jelajahi kategori lain supaya profilmu makin lengkap.",
  };
}

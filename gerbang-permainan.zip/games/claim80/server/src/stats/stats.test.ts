import { describe, expect, it } from "vitest";
import { attemptsCsv, buildReport, itemsCsv, studentsCsv, summaryJson } from "./report";
import type { ReportStudentInput } from "./report";
import { classMedians, heatmap, itemAnalysis, kategoriOf, median, rapotText, studentIndicators } from "./stats";
import type { Attempt } from "./stats";

let seq = 0;
const at = (o: Partial<Attempt> & { studentId: string; cell: string; level: number; correct: boolean }): Attempt => ({
  col: o.cell[0]!,
  variant: 1,
  questionId: `${o.cell}-1`,
  mode: "claim",
  timeMs: 5000,
  chosen: null,
  focusLost: 0,
  reason: null,
  sentAt: ++seq * 1000,
  kategori: "aritmetika",
  generated: false,
  ...o,
});

describe("kategori", () => {
  it("subkategori dipetakan ke 7 kategori radar", () => {
    expect(kategoriOf("numerik_logika")).toBe("logika");
    expect(kategoriOf("logika")).toBe("logika");
    expect(kategoriOf("linguistik")).toBe("linguistik");
    expect(kategoriOf("musikal")).toBe("musikal");
  });
});

describe("indikator murid", () => {
  const a = [
    at({ studentId: "s", cell: "E2", level: 2, correct: true, kategori: "aritmetika", timeMs: 4000 }),
    at({ studentId: "s", cell: "E6", level: 6, correct: false, kategori: "aritmetika", timeMs: 9000 }),
    at({ studentId: "s", cell: "E3", level: 3, correct: true, kategori: "aritmetika", timeMs: 6000 }),
    at({ studentId: "s", cell: "G1", level: 1, correct: true, kategori: "musikal", timeMs: 3000 }),
  ];
  it("Skor Kecerdasan = Σ level benar ÷ Σ level dicoba × 100, hanya bila ≥ 2 percobaan", () => {
    const i = studentIndicators(a, classMedians(a));
    const ar = i.kategori.find((k) => k.id === "aritmetika")!;
    expect(ar.percobaan).toBe(3);
    expect(ar.skor).toBeCloseTo(((2 + 3) / (2 + 6 + 3)) * 100, 1);
    expect(ar.levelPuncak).toBe(3);
    const mu = i.kategori.find((k) => k.id === "musikal")!;
    expect(mu.skor).toBeNull(); // hanya 1 percobaan
    expect(mu.akurasi).toBe(1);
    expect(i.kategori.find((k) => k.id === "spasial")!.percobaan).toBe(0);
  });
  it("keberanian, ketangguhan, eksplorasi, kecepatan relatif kelas", () => {
    const i = studentIndicators(a, classMedians(a));
    expect(i.keberanian).toBe(3); // (2+6+3+1)/4
    expect(i.ketangguhan).toBe(1); // satu kegagalan, percobaan berikutnya benar
    expect(i.eksplorasi).toBe(2);
    expect(i.kecepatan.medianMs).toBe(4000);
    expect(i.kecepatan.relatifKelas).toBe(1); // murid itu sendiri = median kelas
    expect(i.akurasi).toBe(0.75);
  });
  it("tanpa data: semuanya null/0 dan tidak melempar", () => {
    const i = studentIndicators([], classMedians([]));
    expect(i).toMatchObject({ percobaan: 0, akurasi: null, keberanian: null, ketangguhan: null, eksplorasi: 0 });
    expect(median([])).toBeNull();
    expect(median([1, 3, 2])).toBe(2);
    expect(median([1, 2, 3, 4])).toBe(2.5);
  });
});

describe("heatmap kelas", () => {
  it("80 sel; p; tanda terlalu sulit (<0,2) dan terlalu mudah (>0,9 baris ≥ 5) dengan data minimum 3", () => {
    const many = (cell: string, level: number, right: number, wrong: number) => [
      ...Array.from({ length: right }, (_, i) => at({ studentId: `r${i}`, cell, level, correct: true })),
      ...Array.from({ length: wrong }, (_, i) => at({ studentId: `w${i}`, cell, level, correct: false })),
    ];
    const h = heatmap([
      ...many("J8", 8, 0, 5),
      ...many("A6", 6, 10, 0),
      ...many("A2", 2, 10, 0),
      ...many("B3", 3, 0, 2),
    ]);
    expect(h).toHaveLength(80);
    const c = (cell: string) => h.find((x) => x.cell === cell)!;
    expect(c("J8").tanda).toBe("terlalu_sulit");
    expect(c("A6").tanda).toBe("terlalu_mudah");
    expect(c("A2").tanda).toBeNull(); // mudah di baris rendah itu wajar
    expect(c("B3").tanda).toBeNull(); // data kurang
    expect(c("C1").p).toBeNull();
  });
});

describe("analisis butir", () => {
  it("p, daya beda D (27% atas vs bawah), dan sebaran pengecoh", () => {
    const ids = Array.from({ length: 10 }, (_, i) => `s${i}`);
    const scores = Object.fromEntries(ids.map((id, i) => [id, 100 - i * 10])); // s0 tertinggi
    const attempts = ids.map((id, i) =>
      at({
        studentId: id,
        cell: "B3",
        level: 3,
        correct: i < 3,
        chosen: i < 3 ? "benar" : i < 8 ? "tinggi" : "luas",
        questionId: "B3-1",
      }),
    );
    const [it] = itemAnalysis(attempts, scores);
    expect(it!.percobaan).toBe(10);
    expect(it!.p).toBe(0.3);
    expect(it!.d).toBe(1); // 3 teratas benar semua, 3 terbawah salah semua
    expect(it!.pengecoh).toEqual({ tinggi: 5, luas: 2 });
  });
  it("D null bila salah satu kelompok tidak mengerjakan butir itu", () => {
    const scores = { a: 10, b: 5 };
    const [it] = itemAnalysis(
      [at({ studentId: "a", cell: "A1", level: 1, correct: true, questionId: "A1-1" })],
      scores,
    );
    expect(it!.d).toBeNull();
  });
});

describe("teks rapor", () => {
  it("penyemangat dari kategori terkuat, saran dari terlemah, tanpa label negatif", () => {
    const i = studentIndicators(
      [
        at({ studentId: "s", cell: "E3", level: 3, correct: true, kategori: "aritmetika" }),
        at({ studentId: "s", cell: "E4", level: 4, correct: true, kategori: "aritmetika" }),
        at({ studentId: "s", cell: "G5", level: 5, correct: false, kategori: "musikal" }),
        at({ studentId: "s", cell: "G2", level: 2, correct: true, kategori: "musikal" }),
      ],
      {},
    );
    const t = rapotText(i.kategori);
    expect(t.semangat).toMatch(/Aritmetika/);
    expect(t.saran).toMatch(/Musikal/);
    expect(`${t.semangat} ${t.saran}`).not.toMatch(/bodoh|tidak pintar|lemah/i);
    expect(rapotText([]).semangat).toMatch(/Terima kasih/);
  });
});

describe("laporan dan ekspor", () => {
  const stu = (id: string, name: string, score: number, rank: number): ReportStudentInput => ({
    id,
    name,
    absen: rank,
    initials: name.slice(0, 2).toUpperCase(),
    score,
    rank,
    cards: 2,
    claims: 2,
    stealsWon: 0,
    defends: 0,
    bestStreak: 2,
    badges: ["sniper"],
    xpGain: 7,
    flags: { kuning: 1, oranye: 0, merah: 0 },
  });
  const attempts = [
    at({ studentId: "a", cell: "E2", level: 2, correct: true }),
    at({ studentId: "a", cell: "E3", level: 3, correct: true }),
    at({ studentId: "b", cell: "E2", level: 2, correct: false, chosen: 'jawaban, "aneh"' }),
    at({ studentId: "b", cell: "E3", level: 3, correct: false, timeMs: null, reason: "timeout" }),
  ];
  const rep = buildReport({
    sessionId: "x1",
    className: "5A",
    createdAt: 1,
    endedAt: 2,
    phase: "END",
    students: [stu("a", "Rina Putri", 120, 1), stu("b", "Budi Santoso", 40, 2)],
    attempts,
    badgeNames: { sniper: "Sniper" },
  });
  it("memuat murid, heatmap 80 sel, butir, catatan etis, dan nama badge", () => {
    expect(rep.siswa).toHaveLength(2);
    expect(rep.heatmap).toHaveLength(80);
    expect(rep.butir.length).toBeGreaterThan(0);
    expect(rep.catatan).toMatch(/bukan tes IQ/);
    expect(rep.siswa[0]!.badgeNames).toEqual(["Sniper"]);
    expect(rep.akurasiKelas).toBe(0.5);
  });
  it("CSV: BOM, CRLF, kutip untuk koma/kutip, dan kolom skor per kategori", () => {
    const c = attemptsCsv(attempts, { a: "Rina Putri", b: "Budi Santoso" });
    expect(c.charCodeAt(0)).toBe(0xfeff);
    expect(c).toContain("\r\n");
    expect(c).toContain('"jawaban, ""aneh"""');
    expect(c).toMatch(/timeout/);
    const s = studentsCsv(rep);
    expect(s.split("\r\n")[0]).toContain("skor_aritmetika");
    expect(s).toContain("Rina Putri");
    expect(itemsCsv(rep).split("\r\n")[0]).toContain("daya_beda_D");
  });
  it("summary.json untuk SIMPETERI: studentId/name/points + profil, tanpa jawaban soal", () => {
    const j = summaryJson(rep) as {
      game: string;
      students: { studentId: string; name: string; points: number; profile: Record<string, number | null> }[];
    };
    expect(j.game).toBe("claim80");
    expect(j.students[0]).toMatchObject({ studentId: "a", name: "Rina Putri", points: 120 });
    expect(Object.keys(j.students[0]!.profile).sort()).toEqual([
      "aritmetika",
      "linguistik",
      "logika",
      "musikal",
      "numerik",
      "pengetahuan_umum",
      "spasial",
    ]);
    expect(JSON.stringify(j)).not.toMatch(/jawaban|pembahasan/);
  });
});

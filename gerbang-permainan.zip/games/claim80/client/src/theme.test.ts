import { describe, expect, it } from "vitest";
import type { FxEvent } from "@claim80/shared";
import { COL_HUE, bannerFor } from "./theme";

const fx = (o: Partial<FxEvent>): FxEvent => ({ type: "claimed", data: {}, ...o });

describe("bannerFor", () => {
  it("klaim biasa tidak memunculkan banner layar penuh", () => {
    expect(bannerFor(fx({ type: "claimed", cell: "A1" }))).toBeNull();
  });
  it("streak baru muncul pada 5 ke atas", () => {
    expect(bannerFor(fx({ type: "streak", name: "Rina", data: { streak: 3, label: "On Fire" } }))).toBeNull();
    const b = bannerFor(fx({ type: "streak", name: "Rina", data: { streak: 5, label: "Unstoppable" } }));
    expect(b?.kind).toBe("streak");
    expect(b?.sub).toContain("Rina");
  });
  it("kartu emas, rebut, bertahan, fase, misi, selesai", () => {
    expect(bannerFor(fx({ type: "golden", name: "Budi", cell: "G7" }))?.kind).toBe("golden");
    expect(bannerFor(fx({ type: "steal_started", name: "Rina", fromName: "Budi", cell: "E6" }))?.title).toContain(
      "menantang",
    );
    expect(bannerFor(fx({ type: "stolen", name: "Rina", fromName: "Budi", cell: "E6" }))?.title).toContain("merebut");
    expect(bannerFor(fx({ type: "steal_failed", fromName: "Budi", cell: "E6" }))?.kind).toBe("defend");
    expect(bannerFor(fx({ type: "phase", data: { phase: "RUSH" } }))?.sub).toMatch(/1,5/);
    expect(bannerFor(fx({ type: "mission" }))?.kind).toBe("mission");
    expect(bannerFor(fx({ type: "ended" }))?.kind).toBe("end");
  });
  it("tiap kolom punya warna", () => {
    expect(Object.keys(COL_HUE).sort().join("")).toBe("ABCDEFGHIJ");
  });
});

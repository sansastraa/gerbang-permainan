import { appOrigin, appUrl } from "../base";
import { useEffect, useMemo, useState } from "react";
import { AnimatePresence, MotionConfig, motion } from "framer-motion";
import { useParams } from "react-router-dom";
import QRCode from "qrcode";
import { KOLOM_LABEL } from "@claim80/shared";
import type { PublicCard } from "@claim80/shared";
import { COL_HUE } from "../theme";
import { COLS, ROWS, formatClock } from "../play/logic";
import { Ceremony } from "./Ceremony";
import { Leaderboard } from "./Leaderboard";
import { StationBoard } from "./StationBoard";
import { useProj } from "./projStore";
import "./projector.css";

function useNow(ms = 250): number {
  const [n, setN] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setN(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

function useAnimPref(): [boolean, () => void] {
  const [on, setOn] = useState(() => {
    try {
      const saved = localStorage.getItem("claim80.anim");
      if (saved !== null) return saved !== "0";
      // tanpa pilihan tersimpan, hormati pengaturan sistem "kurangi gerakan"
      return !(window.matchMedia?.("(prefers-reduced-motion: reduce)").matches ?? false);
    } catch {
      return true;
    }
  });
  const toggle = () =>
    setOn((v) => {
      try {
        localStorage.setItem("claim80.anim", v ? "0" : "1");
      } catch {
        /* abaikan */
      }
      return !v;
    });
  return [on, toggle];
}

export function Projector() {
  const { code: urlCode } = useParams();
  const connect = useProj((s) => s.connect);
  const code = useProj((s) => s.code);
  const error = useProj((s) => s.error);
  const rules = useProj((s) => s.rules);
  const [input, setInput] = useState("");
  useEffect(() => {
    const c = urlCode ?? new URLSearchParams(location.search).get("code");
    if (c) connect(c.toUpperCase());
  }, [urlCode, connect]);

  if (!code) {
    return (
      <div className="pj pj-enter">
        <div className="pj-brand">
          CLAIM <b>80</b>
        </div>
        <p>Masukkan kode sesi untuk membuka layar proyektor.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            connect(input.trim().toUpperCase());
          }}
        >
          <input value={input} onChange={(e) => setInput(e.target.value)} placeholder="KODE" aria-label="Kode sesi" />
          <button disabled={input.trim().length < 4}>Buka</button>
        </form>
      </div>
    );
  }
  if (error) {
    return (
      <div className="pj pj-enter">
        <p>{error}</p>
      </div>
    );
  }
  if (!rules) {
    return (
      <div className="pj pj-enter">
        <p>Menghubungkan…</p>
      </div>
    );
  }
  return <Stage />;
}

function Stage() {
  const s = useProj();
  const now = useNow();
  const [anim, toggleAnim] = useAnimPref();
  const [spot, setSpot] = useState<string | null>(null);
  useEffect(() => {
    const h = (e: KeyboardEvent) => {
      if (e.key.toLowerCase() === "a") toggleAnim();
      if (e.key === "Escape") setSpot(null);
    };
    window.addEventListener("keydown", h);
    return () => window.removeEventListener("keydown", h);
  });
  const serverNow = now + s.offset;
  const elapsed = s.phase === "LOBBY" ? 0 : (s.pausedAt ?? serverNow) - s.startedAt;
  const remain = Math.max(0, s.durationMs - elapsed);
  const spotCard = spot ? s.board[spot] : undefined;

  return (
    <MotionConfig reducedMotion={anim ? "never" : "always"}>
      <div className={`pj ph-${s.phase}${anim ? "" : " no-anim"}`}>
        <header className="pj-head">
          <div className="pj-brand">
            <span className="t">
              CLAIM <b>80</b>
            </span>
            <small>Kelas {s.className}</small>
          </div>
          <div className={`pj-phase ph-${s.phase}`}>{s.phase === "LOBBY" ? "Menunggu" : s.phase}</div>
          <div className="pj-clock" aria-label="Sisa waktu">
            {s.phase === "LOBBY" ? "--:--" : formatClock(remain)}
            {s.pausedAt !== null && <em>dijeda</em>}
          </div>
          <div className="pj-mission">
            <span>Misi Kelas</span>
            <div className="bar">
              <motion.i
                animate={{ width: `${Math.min(100, (s.mission.claimed / s.mission.target) * 100)}%` }}
                transition={{ type: "spring", stiffness: 80, damping: 18 }}
              />
            </div>
            <b>
              {s.mission.claimed}/{s.mission.target}
            </b>
          </div>
        </header>

        <main className="pj-main">
          <section className="pj-board" aria-label="Papan kartu">
            <div className="pj-corner" />
            {COLS.map((c) => (
              <div key={c} className="pj-deck" style={{ ["--hue" as string]: COL_HUE[c] }}>
                <span className="ico">{KOLOM_LABEL[c]!.ikon}</span>
                <b>{c}</b>
                <small>{KOLOM_LABEL[c]!.nama}</small>
              </div>
            ))}
            {ROWS.map((r) => (
              <Row key={r} row={r} now={serverNow} onSpot={setSpot} />
            ))}
          </section>
          <aside className="pj-side">
            <Leaderboard rows={s.leaderboard} />
            <StationBoard />
            <div className="pj-hint">Hanya 10 teratas yang ditampilkan.</div>
          </aside>
        </main>

        <footer className="pj-foot">
          <Subtitle />
          <Ticker />
        </footer>

        {s.phase === "RUSH" && <div className="pj-fog" aria-hidden />}
        <Banners />
        {s.phase === "LOBBY" && <Lobby />}
        {!s.soundReady && (
          <button className="pj-sound" onClick={s.enableSound}>
            Klik untuk mengaktifkan suara pengumuman
          </button>
        )}
        {s.phase === "END" && <Ceremony />}
        <AnimatePresence>
          {spotCard && (
            <motion.div
              className="pj-spot-bg"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setSpot(null)}
            >
              <motion.div layoutId={`card-${spotCard.cell}`} className="pj-spot" onClick={(e) => e.stopPropagation()}>
                <CardFace card={spotCard} now={serverNow} big />
                <SpotInfo card={spotCard} />
              </motion.div>
            </motion.div>
          )}
        </AnimatePresence>
        <button className="pj-anim" onClick={toggleAnim} aria-label="Animasi" title="Tombol A: animasi">
          {anim ? "Animasi: nyala" : "Animasi: mati"}
        </button>
      </div>
    </MotionConfig>
  );
}

function Subtitle() {
  const line = useProj((s) => s.voLine);
  const engine = useProj((s) => s.voEngine);
  return (
    <div className="pj-sub" aria-live="polite">
      <AnimatePresence mode="wait">
        {line && (
          <motion.div
            key={line.id}
            className="pj-subline"
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            transition={{ type: "spring", stiffness: 300, damping: 24 }}
          >
            <span className="spk">SUARA</span>
            {line.teks}
          </motion.div>
        )}
      </AnimatePresence>
      {!line && engine && <span className="pj-engine">Suara: {engine}</span>}
    </div>
  );
}

function Row({ row, now, onSpot }: { row: number; now: number; onSpot: (c: string) => void }) {
  const board = useProj((s) => s.board);
  const poin = useProj((s) => s.rules?.poin[row]);
  return (
    <>
      <div className="pj-level">
        <b>{row}</b>
        <small>{poin}</small>
      </div>
      {COLS.map((c) => {
        const card = board[`${c}${row}`];
        return card ? (
          <button key={c} className="pj-slot" onClick={() => onSpot(card.cell)} aria-label={`Kartu ${card.cell}`}>
            <CardFace card={card} now={now} />
          </button>
        ) : (
          <span key={c} />
        );
      })}
    </>
  );
}

function CardFace({ card, now, big = false }: { card: PublicCard; now: number; big?: boolean }) {
  const col = card.cell[0]!;
  const row = Number(card.cell.slice(1));
  const poin = useProj((s) => s.rules?.poin[row]);
  const claimed = card.status === "CLAIMED" || card.status === "CONTESTED";
  const flash = useProj((s) => s.flash[card.cell]);
  const voiced = useProj((s) => s.voLine?.sorotSel === card.cell);
  const key = `${card.status}-${card.ownerId ?? ""}`;
  const style: Record<string, string> = { "--hue": COL_HUE[col]! };
  if (claimed && card.color) style["--own"] = card.color;
  return (
    <motion.div
      key={key}
      className={`pc ${card.status.toLowerCase()}${voiced ? " voice" : ""}${card.golden ? " gold" : ""}${big ? " big" : ""}${card.shielded || card.immune ? " shield" : ""}`}
      style={style}
      initial={flash ? { rotateY: 88, scale: 0.9, opacity: 0.4 } : false}
      animate={{ rotateY: 0, scale: 1, opacity: 1 }}
      transition={{ type: "spring", stiffness: 190, damping: 17 }}
      whileHover={{ y: -4, transition: { duration: 0.15 } }}
      data-cell={card.cell}
      data-status={card.status}
    >
      <span className="idx tl">{card.cell}</span>
      {card.status === "OPEN" && (
        <>
          <span className="mid ico">{col === "H" ? "❓" : KOLOM_LABEL[col]!.ikon}</span>
          <span className="idx br">{poin}</span>
        </>
      )}
      {card.status === "LOCKED" && (
        <>
          <span className="mid av pulse">{card.tryingInitials}</span>
          <span className="idx br">⏳</span>
        </>
      )}
      {card.status === "COOLDOWN" && (
        <>
          <span className="mid crack">{Math.max(0, Math.ceil((card.cooldownUntil - now) / 1000))}</span>
          <span className="idx br">retak</span>
        </>
      )}
      {claimed && (
        <>
          <span className="mid own">{card.initials}</span>
          <span className="idx br">{card.value}</span>
          {(card.shielded || card.immune) && <span className="sh">🛡</span>}
          {card.status === "CONTESTED" && <span className="sw">⚔️</span>}
        </>
      )}
      {card.jackpotPct > 0 && !claimed && <span className="jp">+{card.jackpotPct}%</span>}
    </motion.div>
  );
}

function SpotInfo({ card }: { card: PublicCard }) {
  const col = card.cell[0]!;
  const row = Number(card.cell.slice(1));
  const poin = useProj((s) => s.rules?.poin[row]);
  const lb = useProj((s) => s.leaderboard);
  const owner = lb.find((l) => l.id === card.ownerId);
  const label = col === "H" && card.status === "OPEN" ? "Mystery" : KOLOM_LABEL[col]!.nama;
  return (
    <div className="pj-spot-info">
      <h2>
        {card.cell} · {label}
      </h2>
      <p>
        Level {row} · {poin} poin
      </p>
      {card.status === "CLAIMED" && (
        <p>
          Dimiliki {owner?.name ?? card.initials} · bernilai {card.value}
        </p>
      )}
      {card.status === "LOCKED" && <p>Sedang dicoba {card.tryingInitials}</p>}
      {card.jackpotPct > 0 && <p>Jackpot +{card.jackpotPct}%</p>}
    </div>
  );
}

function Ticker() {
  const items = useProj((s) => s.ticker);
  const last = items.slice(-3);
  return (
    <div className="pj-ticker" aria-label="Kabar terbaru">
      <AnimatePresence initial={false}>
        {last.map((t) => (
          <motion.span
            key={t.id}
            layout
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -8 }}
            className={`tk ${t.kind}`}
          >
            {t.text}
          </motion.span>
        ))}
      </AnimatePresence>
      {last.length === 0 && <span className="tk idle">Kabar permainan akan muncul di sini.</span>}
    </div>
  );
}

function Banners() {
  const banners = useProj((s) => s.banners);
  return (
    <div className="pj-banners" aria-live="polite">
      <AnimatePresence>
        {banners.map((b) => (
          <motion.div
            key={b.id}
            className={`pj-banner ${b.kind}`}
            style={b.color ? { ["--c" as string]: b.color } : undefined}
            initial={{ opacity: 0, scale: 0.85, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 1.05, y: -20 }}
            transition={{ type: "spring", stiffness: 220, damping: 20 }}
          >
            <b>{b.title}</b>
            {b.sub && <span>{b.sub}</span>}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
}

function Lobby() {
  const code = useProj((s) => s.code);
  const className = useProj((s) => s.className);
  const [url, setUrl] = useState("");
  const [qr, setQr] = useState("");
  useEffect(() => {
    let off = false;
    void (async () => {
      let origin = appOrigin();
      try {
        if (/localhost|127\.0\.0\.1/.test(location.hostname)) {
          const r = (await (await fetch(appUrl("/api/lan"))).json()) as { urls: string[] };
          if (r.urls[0]) origin = r.urls[0];
        }
      } catch {
        /* pakai origin saat ini */
      }
      const u = `${origin}/play/${code}`;
      const svg = await QRCode.toString(u, { type: "svg", margin: 1, color: { dark: "#17202e", light: "#ffffff" } });
      if (!off) {
        setUrl(u);
        setQr(svg);
      }
    })();
    return () => {
      off = true;
    };
  }, [code]);
  const dataUrl = useMemo(() => (qr ? `data:image/svg+xml;utf8,${encodeURIComponent(qr)}` : ""), [qr]);
  return (
    <motion.div className="pj-lobby" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <div className="box">
        <div className="pj-brand big">
          CLAIM <b>80</b>
        </div>
        <p>Kelas {className} — scan untuk bergabung</p>
        {dataUrl && <img src={dataUrl} alt="QR bergabung" />}
        <div className="url">{url}</div>
        <div className="code">{code}</div>
        <p className="muted">Menunggu guru memulai permainan…</p>
      </div>
    </motion.div>
  );
}

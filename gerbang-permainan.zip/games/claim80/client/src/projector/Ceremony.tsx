import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Confetti } from "../Confetti";
import { useProj } from "./projStore";

/**
 * Upacara Penghargaan (SPEC §4.7): podium Juara Umum muncul dari peringkat 3 ke 1,
 * lalu penghargaan lain bergantian satu per satu agar banyak murid mendapat panggung.
 */
export function Ceremony() {
  const awards = useProj((s) => s.awards);
  const [step, setStep] = useState(0);
  const podium = ["juara_3", "juara_2", "juara_1"].map((id) => awards.find((a) => a.id === id)).filter(Boolean);
  const others = awards.filter((a) => !a.id.startsWith("juara_"));
  const [idx, setIdx] = useState(0);

  useEffect(() => {
    if (step >= podium.length) return;
    const t = setTimeout(() => setStep((n) => n + 1), 1500);
    return () => clearTimeout(t);
  }, [step, podium.length]);
  useEffect(() => {
    if (others.length < 2 || step < podium.length) return;
    const t = setInterval(() => setIdx((n) => (n + 1) % others.length), 4200);
    return () => clearInterval(t);
  }, [others.length, step, podium.length]);

  if (awards.length === 0) {
    return (
      <div className="pj-ceremony">
        <div className="pj-cer-title">Permainan selesai</div>
        <p className="pj-cer-sub">Terima kasih sudah bermain.</p>
      </div>
    );
  }
  const current = others[idx];
  return (
    <motion.div className="pj-ceremony" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      {step >= podium.length && podium.length > 0 && <Confetti />}
      <div className="pj-cer-title">Upacara Penghargaan</div>
      <div className="pj-podium">
        {podium.map((a, i) => {
          const rank = 3 - i;
          return (
            <AnimatePresence key={a!.id}>
              {step > i && (
                <motion.div
                  className={`pj-pod r${rank}`}
                  initial={{ y: 80, opacity: 0, rotate: -4 }}
                  animate={{ y: 0, opacity: 1, rotate: 0 }}
                  transition={{ type: "spring", stiffness: 180, damping: 14 }}
                >
                  <span className="medal">{a!.ikon}</span>
                  <b>{a!.detail.split(" · ")[0]}</b>
                  <small>{a!.detail.split(" · ")[1]}</small>
                  <i className="base">{rank}</i>
                </motion.div>
              )}
            </AnimatePresence>
          );
        })}
      </div>
      <div className="pj-cer-others">
        <AnimatePresence mode="wait">
          {current && step >= podium.length && (
            <motion.div
              key={current.id}
              className="pj-award"
              initial={{ y: 30, opacity: 0, scale: 0.94 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -20, opacity: 0 }}
              transition={{ type: "spring", stiffness: 240, damping: 20 }}
            >
              <span className="ik">{current.ikon}</span>
              <div>
                <small>{current.title}</small>
                <b>{current.detail}</b>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </motion.div>
  );
}

import { useEffect, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { LeaderEntry } from "@claim80/shared";
import { useProj } from "./projStore";
import { rankMarks, scoreGains, streakTier } from "./rankMarks";
import type { Mark } from "./rankMarks";

const MARK_MS = 2600;

/**
 * Top 10 interaktif: pendatang baru meluncur masuk, peserta yang tersingkir (peringkat 11) memudar keluar,
 * yang naik peringkat bergeser ke atas dengan sorot hijau + chip ▲, yang turun diberi sorot merah lembut,
 * kenaikan skor memunculkan +N, dan streak beruntun tampil sebagai chip ungu yang hilang saat streak putus.
 */
export function Leaderboard({ rows }: { rows: LeaderEntry[] }) {
  const prevIds = useRef<string[]>([]);
  const prevScores = useRef<Record<string, number>>({});
  const [marks, setMarks] = useState<Record<string, Mark>>({});
  const [gains, setGains] = useState<Record<string, number>>({});
  const speaking = useProj((s) => s.voLine?.studentId);

  useEffect(() => {
    const ids = rows.map((r) => r.id);
    const m = rankMarks(prevIds.current, ids);
    const g = scoreGains(prevScores.current, rows);
    prevIds.current = ids;
    prevScores.current = Object.fromEntries(rows.map((r) => [r.id, r.score]));
    if (Object.keys(m).length === 0 && Object.keys(g).length === 0) return;
    setMarks((cur) => ({ ...cur, ...m }));
    setGains((cur) => ({ ...cur, ...g }));
    const t = setTimeout(() => {
      setMarks((cur) => Object.fromEntries(Object.entries(cur).filter(([id]) => !(id in m) || cur[id] !== m[id])));
      setGains((cur) => Object.fromEntries(Object.entries(cur).filter(([id]) => !(id in g) || cur[id] !== g[id])));
    }, MARK_MS);
    return () => clearTimeout(t);
  }, [rows]);

  return (
    <div className="pj-lb">
      <h2>Top 10</h2>
      <ol>
        <AnimatePresence initial={false} mode="popLayout">
          {rows.map((r, i) => {
            const mk = marks[r.id];
            const tier = streakTier(r.streak);
            return (
              <motion.li
                key={r.id}
                layout="position"
                initial={{ opacity: 0, x: 60, scale: 0.96 }}
                animate={{ opacity: 1, x: 0, scale: 1 }}
                exit={{ opacity: 0, x: -40, scale: 0.94 }}
                transition={{ type: "spring", stiffness: 280, damping: 26 }}
                className={`${i === 0 ? "first " : ""}${mk ? `mk-${mk.kind}` : ""}${speaking === r.id ? " speaking" : ""}`}
              >
                <span className="rk">{i + 1}</span>
                <span className="av" style={{ background: r.color }}>
                  {r.initials}
                </span>
                <span className="nm">
                  <span className="n">{r.name}</span>
                  <AnimatePresence>
                    {tier !== "none" && (
                      <motion.span
                        key="stk"
                        className={`stk ${tier}`}
                        initial={{ scale: 0, opacity: 0 }}
                        animate={{ scale: 1, opacity: 1 }}
                        exit={{ scale: 0, opacity: 0, rotate: -25 }}
                        transition={{ type: "spring", stiffness: 420, damping: 18 }}
                        title="Streak jawaban benar beruntun"
                      >
                        {tier === "legend" ? "👑" : "⚡"}
                        {r.streak}
                      </motion.span>
                    )}
                  </AnimatePresence>
                  {mk?.kind === "up" && <span className="chip up">▲{mk.n}</span>}
                  {mk?.kind === "down" && <span className="chip down">▼{mk.n}</span>}
                  {mk?.kind === "new" && <span className="chip new">BARU</span>}
                </span>
                <b className="sc">
                  {r.score}
                  <AnimatePresence>
                    {gains[r.id] && (
                      <motion.em
                        key={`g${r.score}`}
                        className="gain"
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: -2 }}
                        exit={{ opacity: 0, y: -14 }}
                      >
                        +{gains[r.id]}
                      </motion.em>
                    )}
                  </AnimatePresence>
                </b>
              </motion.li>
            );
          })}
        </AnimatePresence>
        {rows.length === 0 && <li className="empty">Belum ada skor.</li>}
      </ol>
    </div>
  );
}

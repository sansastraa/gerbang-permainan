export interface Mark {
  kind: "up" | "down" | "new";
  /** jumlah peringkat berubah (untuk up/down) */
  n: number;
}

/**
 * Membandingkan urutan id papan skor sebelum dan sesudah pembaruan.
 * Pembaruan pertama (prev kosong) tidak menandai apa pun agar papan tidak berkedip semua saat dibuka.
 */
export function rankMarks(prev: string[], next: string[]): Record<string, Mark> {
  const out: Record<string, Mark> = {};
  if (prev.length === 0) return out;
  const before = new Map(prev.map((id, i) => [id, i]));
  next.forEach((id, i) => {
    const was = before.get(id);
    if (was === undefined) out[id] = { kind: "new", n: 0 };
    else if (was > i) out[id] = { kind: "up", n: was - i };
    else if (was < i) out[id] = { kind: "down", n: i - was };
  });
  return out;
}

/** Kenaikan skor per id (hanya yang naik) antara dua pembaruan. */
export function scoreGains(
  prev: Record<string, number>,
  next: { id: string; score: number }[],
): Record<string, number> {
  const out: Record<string, number> = {};
  for (const r of next) {
    const was = prev[r.id];
    if (was !== undefined && r.score > was) out[r.id] = r.score - was;
  }
  return out;
}

/** Tingkat tampilan chip streak: tidak tampil di bawah 2; 'hot' dari 3; 'max' dari 5; 'legend' dari 8. */
export function streakTier(streak: number): "none" | "warm" | "hot" | "max" | "legend" {
  if (streak >= 8) return "legend";
  if (streak >= 5) return "max";
  if (streak >= 3) return "hot";
  if (streak >= 2) return "warm";
  return "none";
}

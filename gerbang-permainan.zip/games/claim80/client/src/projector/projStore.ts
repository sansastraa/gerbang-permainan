import { SOCKET_PATH } from "../base";
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { create } from "zustand";
import { ENGINE_LABEL, VoPlayer } from "../audio/vo";
import type {
  Award,
  ClientRules,
  FxEvent,
  VoPlay,
  VoSettings,
  StationState,
  LeaderEntry,
  Phase,
  PublicCard,
  Snapshot,
  TickerItem,
} from "@claim80/shared";
import { bannerFor } from "../theme";
import type { Banner } from "../theme";

export interface ProjState {
  connected: boolean;
  error: string;
  className: string;
  code: string;
  board: Record<string, PublicCard>;
  leaderboard: LeaderEntry[];
  rules: ClientRules | null;
  phase: Phase;
  startedAt: number;
  pausedAt: number | null;
  durationMs: number;
  mission: { claimed: number; target: number; done: boolean };
  offset: number;
  ticker: TickerItem[];
  banners: (Banner & { id: number })[];
  awards: Award[];
  /** VO yang sedang tampil sebagai subtitle */
  station: StationState | null;
  voLine: { id: string; teks: string; sorotSel?: string; studentId?: string } | null;
  voSettings: VoSettings | null;
  voEngine: string;
  soundReady: boolean;
  enableSound: () => void;
  /** sel yang baru berubah, untuk kilau singkat */
  flash: Record<string, number>;
  connect: (code: string) => void;
}

const player = new VoPlayer();
let voChain: Promise<void> = Promise.resolve();
let socket: Socket | null = null;
let seq = 0;

export const useProj = create<ProjState>((set, get) => ({
  connected: false,
  error: "",
  className: "",
  code: "",
  board: {},
  leaderboard: [],
  rules: null,
  phase: "LOBBY",
  startedAt: 0,
  pausedAt: null,
  durationMs: 0,
  mission: { claimed: 0, target: 70, done: false },
  offset: 0,
  ticker: [],
  banners: [],
  awards: [],
  station: null,
  voLine: null,
  voSettings: null,
  voEngine: "",
  soundReady: false,
  enableSound() {
    player.unlock();
    set({ soundReady: true });
  },
  flash: {},

  connect(code) {
    socket?.close();
    set({ code, error: "" });
    const s = io({
      path: SOCKET_PATH,
      auth: { role: "projector", sessionCode: code },
      transports: ["websocket", "polling"],
    });
    socket = s;
    s.on("connect", () => set({ connected: true }));
    s.on("disconnect", () => set({ connected: false }));
    s.on("fatal", (m: { message: string }) => set({ error: m.message }));
    s.on("state:snapshot", (snap: Snapshot) => {
      const board: Record<string, PublicCard> = {};
      for (const c of snap.board) board[c.cell] = c;
      set({
        board,
        leaderboard: snap.leaderboard,
        rules: snap.rules,
        phase: snap.phase,
        startedAt: snap.startedAt,
        pausedAt: snap.pausedAt,
        durationMs: snap.durationMs,
        mission: snap.mission,
        className: snap.className,
        awards: snap.awards ?? get().awards,
        voSettings: snap.vo ?? get().voSettings,
        station: snap.station ?? get().station,
        offset: snap.serverNow - Date.now(),
      });
    });
    s.on(
      "board:diff",
      (d: {
        cells: PublicCard[];
        phase: Phase;
        startedAt: number;
        pausedAt: number | null;
        serverNow: number;
        mission: ProjState["mission"];
      }) => {
        const board = { ...get().board };
        const flash = { ...get().flash };
        for (const c of d.cells) {
          board[c.cell] = c;
          flash[c.cell] = ++seq;
        }
        set({
          board,
          flash,
          phase: d.phase,
          startedAt: d.startedAt,
          pausedAt: d.pausedAt,
          mission: d.mission,
          offset: d.serverNow - Date.now(),
        });
      },
    );
    s.on("awards", (a: Award[]) => set({ awards: a }));
    s.on("station:state", (st: StationState) => set({ station: st }));
    s.on("vo:settings", (v: VoSettings) => {
      player.settings = v;
      set({ voSettings: v });
    });
    s.on("vo:play", (p: VoPlay) => {
      // satu per satu; server hanya mengirim berikutnya setelah `vo:done`
      voChain = voChain.then(async () => {
        const cur = get().voSettings;
        if (cur) player.settings = cur;
        set({
          voLine: {
            id: p.id,
            teks: p.teks,
            ...(p.sorotSel ? { sorotSel: p.sorotSel } : {}),
            ...(p.studentId ? { studentId: p.studentId } : {}),
          },
        });
        const engine = await player.play(p);
        set({ voLine: null, voEngine: ENGINE_LABEL[engine] });
        s.emit("vo:status", { engine: ENGINE_LABEL[engine] });
        s.emit("vo:done", { id: p.id });
      });
    });
    s.on("leaderboard:update", (l: LeaderEntry[]) => set({ leaderboard: l }));
    s.on("ticker:backlog", (t: TickerItem[]) => set({ ticker: t.slice(-8) }));
    s.on("ticker:push", (t: TickerItem) => set({ ticker: [...get().ticker.slice(-7), t] }));
    s.on("fx", (fx: FxEvent) => {
      const b = bannerFor(fx);
      if (!b) return;
      const id = ++seq;
      set({ banners: [...get().banners.slice(-2), { ...b, id }] });
      setTimeout(
        () => set({ banners: get().banners.filter((x) => x.id !== id) }),
        b.kind === "streak" || b.kind === "end" ? 2600 : 2000,
      );
    });
  },
}));

import { describe, expect, it } from "vitest";
import { rankMarks, scoreGains, streakTier } from "./rankMarks";

describe("rankMarks", () => {
  it("pembaruan pertama tidak menandai apa pun", () => {
    expect(rankMarks([], ["a", "b"])).toEqual({});
  });
  it("menandai naik, turun, dan pendatang baru", () => {
    const m = rankMarks(["a", "b", "c", "d"], ["a", "c", "n", "b"]);
    expect(m.a).toBeUndefined();
    expect(m.c).toEqual({ kind: "up", n: 1 });
    expect(m.n).toEqual({ kind: "new", n: 0 });
    expect(m.b).toEqual({ kind: "down", n: 2 });
    expect(m.d).toBeUndefined(); // tersingkir dari 10 besar: tidak ada di next
  });
  it("lompatan beberapa peringkat", () => {
    expect(rankMarks(["a", "b", "c", "d"], ["d", "a", "b", "c"]).d).toEqual({ kind: "up", n: 3 });
  });
});

describe("scoreGains & streakTier", () => {
  it("hanya kenaikan skor yang dilaporkan", () => {
    const g = scoreGains({ a: 10, b: 20 }, [
      { id: "a", score: 35 },
      { id: "b", score: 20 },
      { id: "c", score: 9 },
    ]);
    expect(g).toEqual({ a: 25 });
  });
  it("tingkat streak", () => {
    expect([0, 1, 2, 3, 4, 5, 7, 8, 12].map(streakTier)).toEqual([
      "none",
      "none",
      "warm",
      "hot",
      "hot",
      "max",
      "max",
      "legend",
      "legend",
    ]);
  });
});

import { AnimatePresence, motion } from "framer-motion";
import { useProj } from "./projStore";

/** Antrean dan nomor stasiun di proyektor (SPEC §8.4). Hanya tampil bila ada tablet terhubung atau antrean tidak kosong. */
export function StationBoard() {
  const st = useProj((s) => s.station);
  if (!st || (st.stations.length === 0 && st.queue.length === 0 && !st.mode)) return null;
  return (
    <div className="pj-stn" aria-label="Antrean stasiun">
      <h3>Stasiun Jawab</h3>
      <ul className="stations">
        {st.stations.length === 0 && <li className="idle">Belum ada tablet stasiun</li>}
        {st.stations.map((s) => (
          <li key={s.no} className={s.studentId ? "busy" : "idle"}>
            <b className="no">{s.no}</b>
            <span>{s.name ?? "Menunggu giliran"}</span>
          </li>
        ))}
      </ul>
      {st.queue.length > 0 && (
        <>
          <h4>Antre berikutnya</h4>
          <ol className="queue">
            <AnimatePresence initial={false}>
              {st.queue.slice(0, 6).map((q, i) => (
                <motion.li
                  key={q.id}
                  layout
                  initial={{ opacity: 0, x: 24 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -24 }}
                  transition={{ type: "spring", stiffness: 280, damping: 26 }}
                >
                  <span className="n">{i + 1}</span>
                  <span className="av" style={{ background: q.color }}>
                    {q.initials}
                  </span>
                  <span className="nm">{q.name}</span>
                </motion.li>
              ))}
            </AnimatePresence>
          </ol>
          {st.queue.length > 6 && <small>+{st.queue.length - 6} lagi</small>}
        </>
      )}
    </div>
  );
}

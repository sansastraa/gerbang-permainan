import type { VoPlay, VoSegmen, VoSettings } from "@claim80/shared";
import { isMuted, jingle, unlockAudio } from "./synth";

/** Mesin suara VO, berurutan dari yang terbaik (SPEC §7a.5). */
export type VoEngine = "rekaman" | "web_speech_lokal" | "web_speech_online" | "teks";

export const ENGINE_LABEL: Record<VoEngine, string> = {
  rekaman: "Rekaman suara guru",
  web_speech_lokal: "Suara Indonesia bawaan perangkat",
  web_speech_online: "Suara Indonesia online",
  teks: "Hanya teks (tidak ada suara Indonesia)",
};

export interface VoiceLike {
  lang: string;
  localService: boolean;
  name: string;
}

/** Memilih suara id-ID: yang lokal lebih dulu, lalu yang online; null bila tidak ada. */
export function pickVoice<T extends VoiceLike>(
  voices: T[],
): { voice: T; engine: "web_speech_lokal" | "web_speech_online" } | null {
  const id = voices.filter((v) => v.lang.toLowerCase().replace("_", "-").startsWith("id"));
  const local = id.find((v) => v.localService);
  if (local) return { voice: local, engine: "web_speech_lokal" };
  const any = id[0];
  return any ? { voice: any, engine: "web_speech_online" } : null;
}

const norm = (s: string) =>
  s
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, "")
    .replace(/\s+/g, " ")
    .trim();

/** Kunci rekaman untuk satu segmen VO. */
export function recKey(seg: VoSegmen): string {
  if (seg.k === "nama") return `nama:${seg.id ?? norm(seg.v)}`;
  if (seg.k === "sel") return `sel:${norm(seg.v)}`;
  return `teks:${norm(seg.v)}`;
}

/** Rekaman dipakai hanya bila seluruh segmen bermakna (selain tanda baca) sudah direkam. */
export function allRecorded(segmen: VoSegmen[], have: ReadonlySet<string>): boolean {
  const meaningful = segmen.filter((s) => norm(s.v) !== "");
  return meaningful.length > 0 && meaningful.every((s) => have.has(recKey(s)));
}

/** Perkiraan lama ucapan (ms) saat tidak ada sinyal selesai dari mesin suara. */
export function estimateSpeechMs(text: string, kecepatan: number): number {
  return Math.round((text.length * 70) / Math.max(0.5, kecepatan)) + 600;
}

// ---------- penyimpanan rekaman (IndexedDB, dengan cadangan memori) ----------

const DB = "claim80-vo";
const STORE = "rekaman";
const memory = new Map<string, Blob>();

function open(): Promise<IDBDatabase | null> {
  return new Promise((resolve) => {
    try {
      const r = indexedDB.open(DB, 1);
      r.onupgradeneeded = () => r.result.createObjectStore(STORE);
      r.onsuccess = () => resolve(r.result);
      r.onerror = () => resolve(null);
    } catch {
      resolve(null);
    }
  });
}

function tx<T>(mode: IDBTransactionMode, fn: (s: IDBObjectStore) => IDBRequest<T>): Promise<T | undefined> {
  return open().then(
    (db) =>
      new Promise<T | undefined>((resolve) => {
        if (!db) return resolve(undefined);
        try {
          const req = fn(db.transaction(STORE, mode).objectStore(STORE));
          req.onsuccess = () => resolve(req.result);
          req.onerror = () => resolve(undefined);
        } catch {
          resolve(undefined);
        }
      }),
  );
}

export const recordings = {
  async put(key: string, blob: Blob) {
    memory.set(key, blob);
    await tx("readwrite", (s) => s.put(blob, key));
  },
  async get(key: string): Promise<Blob | undefined> {
    return memory.get(key) ?? ((await tx("readonly", (s) => s.get(key))) as Blob | undefined);
  },
  async keys(): Promise<Set<string>> {
    const k = ((await tx("readonly", (s) => s.getAllKeys())) as IDBValidKey[] | undefined) ?? [];
    return new Set([...k.map(String), ...memory.keys()]);
  },
  async delete(key: string) {
    memory.delete(key);
    await tx("readwrite", (s) => s.delete(key));
  },
};

// ---------- pemutar ----------

const wait = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function voicesReady(): Promise<SpeechSynthesisVoice[]> {
  return new Promise((resolve) => {
    const ss = window.speechSynthesis as SpeechSynthesis | undefined;
    if (!ss) return resolve([]);
    const v = ss.getVoices();
    if (v.length) return resolve(v);
    const t = setTimeout(() => resolve(ss.getVoices()), 600);
    ss.addEventListener?.("voiceschanged", () => {
      clearTimeout(t);
      resolve(ss.getVoices());
    });
  });
}

async function playBlob(blob: Blob, volume: number, rate: number): Promise<void> {
  const url = URL.createObjectURL(blob);
  try {
    await new Promise<void>((resolve) => {
      const a = new Audio(url);
      a.volume = volume;
      a.playbackRate = rate;
      a.onended = () => resolve();
      a.onerror = () => resolve();
      a.play().catch(() => resolve());
    });
  } finally {
    URL.revokeObjectURL(url);
  }
}

/** Mesin yang akan dipakai untuk saat ini (tanpa memutar), untuk ditampilkan ke guru. */
export async function detectEngine(segmen?: VoSegmen[]): Promise<VoEngine> {
  if (segmen && allRecorded(segmen, await recordings.keys())) return "rekaman";
  const p = pickVoice(await voicesReady());
  return p ? p.engine : "teks";
}

export class VoPlayer {
  settings: VoSettings = { mode: "penting_dan_klaim", volume: 1, kecepatan: 1.05, nada: 1.1, subtitle: true };
  lastEngine: VoEngine = "teks";

  unlock() {
    unlockAudio();
  }

  /**
   * Memutar satu VO: jingle → ucapan (rekaman guru → suara lokal → suara online → teks saja).
   * Selalu selesai (tidak melempar) dan minimal selama `minMs` agar subtitle sempat terbaca.
   */
  async play(p: VoPlay): Promise<VoEngine> {
    const started = Date.now();
    let engine: VoEngine = "teks";
    if (!isMuted()) {
      const jMs = jingle(p.jingle);
      await wait(Math.min(jMs, 900));
      try {
        engine = await this.speak(p);
      } catch {
        engine = "teks";
      }
    }
    this.lastEngine = engine;
    const rest = p.minMs - (Date.now() - started);
    if (rest > 0) await wait(rest);
    return engine;
  }

  private async speak(p: VoPlay): Promise<VoEngine> {
    const s = this.settings;
    const have = await recordings.keys();
    if (allRecorded(p.segmen, have)) {
      for (const seg of p.segmen) {
        if (norm(seg.v) === "") continue;
        const blob = await recordings.get(recKey(seg));
        if (blob) await playBlob(blob, s.volume, s.kecepatan);
      }
      return "rekaman";
    }
    const ss = window.speechSynthesis as SpeechSynthesis | undefined;
    const chosen = ss ? pickVoice(await voicesReady()) : null;
    if (!ss || !chosen) return "teks";
    await new Promise<void>((resolve) => {
      const u = new SpeechSynthesisUtterance(p.teks);
      u.voice = chosen.voice;
      u.lang = "id-ID";
      u.rate = s.kecepatan;
      u.pitch = s.nada;
      u.volume = s.volume;
      const guard = setTimeout(resolve, estimateSpeechMs(p.teks, s.kecepatan) + 2500);
      u.onend = () => {
        clearTimeout(guard);
        resolve();
      };
      u.onerror = () => {
        clearTimeout(guard);
        resolve();
      };
      ss.speak(u);
    });
    return chosen.engine;
  }

  /** Dipakai halaman guru untuk mencoba nama/sel/frasa langsung di perangkat ini. */
  async preview(text: string, segmen?: VoSegmen[]) {
    this.unlock();
    await this.play({
      id: "preview",
      teks: text,
      segmen: segmen ?? [{ k: "teks", v: text }],
      jingle: "",
      prioritas: "tinggi",
      minMs: 0,
    });
  }
}

import { describe, expect, it } from "vitest";
import type { VoSegmen } from "@claim80/shared";
import { allRecorded, estimateSpeechMs, pickVoice, recKey } from "./vo";

const v = (lang: string, localService: boolean, name = lang) => ({ lang, localService, name });

describe("pickVoice", () => {
  it("memilih suara Indonesia lokal lebih dulu, lalu online, lalu tidak ada", () => {
    const en = v("en-US", true);
    const idOnline = v("id-ID", false, "online");
    const idLocal = v("id_ID", true, "lokal");
    expect(pickVoice([en, idOnline, idLocal])?.voice.name).toBe("lokal");
    expect(pickVoice([en, idOnline, idLocal])?.engine).toBe("web_speech_lokal");
    expect(pickVoice([en, idOnline])?.engine).toBe("web_speech_online");
    expect(pickVoice([en])).toBeNull();
    expect(pickVoice([])).toBeNull();
  });
});

describe("rekaman guru", () => {
  const segmen: VoSegmen[] = [
    { k: "nama", v: "Rina", id: "s1" },
    { k: "teks", v: " telah mengklaim kartu " },
    { k: "sel", v: "E enam" },
    { k: "teks", v: "!" },
  ];
  it("kunci rekaman stabil dan mengabaikan tanda baca/kapital", () => {
    expect(recKey({ k: "teks", v: "  Telah  mengklaim, kartu! " })).toBe(
      recKey({ k: "teks", v: "telah mengklaim kartu" }),
    );
    expect(recKey({ k: "sel", v: "E enam" })).toBe("sel:e enam");
    expect(recKey({ k: "nama", v: "Rina", id: "s1" })).toBe("nama:s1");
  });
  it("rekaman dipakai hanya bila semua bagian bermakna sudah direkam (tanda baca saja diabaikan)", () => {
    const all = new Set([recKey(segmen[0]!), recKey(segmen[1]!), recKey(segmen[2]!)]);
    expect(allRecorded(segmen, all)).toBe(true);
    all.delete(recKey(segmen[2]!));
    expect(allRecorded(segmen, all)).toBe(false);
    expect(allRecorded([], new Set())).toBe(false);
  });
});

describe("estimateSpeechMs", () => {
  it("lebih lama untuk teks panjang dan bicara lambat", () => {
    expect(estimateSpeechMs("halo", 1)).toBeLessThan(estimateSpeechMs("halo teman teman semua", 1));
    expect(estimateSpeechMs("halo teman", 0.6)).toBeGreaterThan(estimateSpeechMs("halo teman", 1.4));
  });
});

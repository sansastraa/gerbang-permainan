/** Synth Web Audio tanpa berkas rekaman (bebas hak cipta), SPEC §7.3 dan CLAUDE.md M4. */

const SEMI: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };

/** Frekuensi nada ilmiah (A4 = 440 Hz), mis. "C4" → 261.63, "F#3", "Bb4". */
export function noteFreq(note: string): number {
  const m = /^([A-G])([#b]?)(-?\d)$/.exec(note);
  if (!m) throw new Error(`Nada tidak valid: ${note}`);
  const [, letter, acc, oct] = m;
  const n = SEMI[letter!]! + (acc === "#" ? 1 : acc === "b" ? -1 : 0) + (Number(oct) + 1) * 12;
  return 440 * Math.pow(2, (n - 69) / 12);
}

type Ctx = AudioContext;
let ctx: Ctx | null = null;
let muted = false;
try {
  muted = localStorage.getItem("claim80.muted") === "1";
} catch {
  /* penyimpanan tidak tersedia */
}

export function isMuted(): boolean {
  return muted;
}
export function setMuted(m: boolean) {
  muted = m;
  try {
    localStorage.setItem("claim80.muted", m ? "1" : "0");
  } catch {
    /* abaikan */
  }
}

/** Harus dipanggil dari gerakan pengguna (ketuk) agar berjalan di Chrome Android dan Safari iOS. */
export function unlockAudio(): void {
  try {
    const AC =
      window.AudioContext ?? (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
    if (!AC) return;
    ctx ??= new AC();
    if (ctx.state === "suspended") void ctx.resume();
  } catch {
    /* tanpa audio */
  }
}

function tone(freq: number, start: number, dur: number, type: OscillatorType, gain: number, c: Ctx) {
  const o = c.createOscillator();
  const g = c.createGain();
  o.type = type;
  o.frequency.value = freq;
  g.gain.setValueAtTime(0.0001, start);
  g.gain.exponentialRampToValueAtTime(gain, start + 0.02);
  g.gain.exponentialRampToValueAtTime(0.0001, start + dur);
  o.connect(g).connect(c.destination);
  o.start(start);
  o.stop(start + dur + 0.05);
}

function play(fn: (c: Ctx, t: number) => void) {
  if (muted || !ctx) return;
  try {
    fn(ctx, ctx.currentTime + 0.02);
  } catch {
    /* abaikan */
  }
}

/** Memutar nada soal musikal secara berurutan; mengembalikan total durasi (detik). */
export function playNotes(notes: string[], durasi: number): number {
  play((c, t) => notes.forEach((n, i) => tone(noteFreq(n), t + i * durasi * 1.15, durasi, "triangle", 0.28, c)));
  return notes.length * durasi * 1.15;
}

export const sfx = {
  tap: () => play((c, t) => tone(660, t, 0.07, "sine", 0.12, c)),
  correct: () =>
    play((c, t) => {
      [523.25, 659.25, 783.99].forEach((f, i) => tone(f, t + i * 0.09, 0.22, "triangle", 0.22, c));
    }),
  wrong: () =>
    play((c, t) => {
      tone(220, t, 0.18, "sine", 0.18, c);
      tone(185, t + 0.14, 0.26, "sine", 0.16, c);
    }),
  steal: () =>
    play((c, t) => {
      tone(392, t, 0.1, "sawtooth", 0.1, c);
      tone(523.25, t + 0.1, 0.16, "sawtooth", 0.1, c);
    }),
  warn: () => play((c, t) => tone(440, t, 0.12, "square", 0.08, c)),
};

interface JingleDef {
  notes: number[];
  step: number;
  dur: number;
  type: OscillatorType;
  gain: number;
}

/** Jingle pendek per jenis kejadian (nama dari config/vo_naskah.json). Semuanya sintetis, tanpa berkas rekaman. */
const JINGLES: Record<string, JingleDef> = {
  chime_pendek: { notes: [880, 1175], step: 0.09, dur: 0.25, type: "sine", gain: 0.16 },
  fanfare: { notes: [523.25, 659.25, 783.99, 1046.5], step: 0.11, dur: 0.3, type: "triangle", gain: 0.22 },
  kilau_emas: { notes: [1318.5, 1568, 1975.5, 2349.3], step: 0.07, dur: 0.28, type: "sine", gain: 0.14 },
  pedang: { notes: [392, 523.25, 392, 659.25], step: 0.08, dur: 0.14, type: "sawtooth", gain: 0.09 },
  perisai: { notes: [329.63, 261.63], step: 0.14, dur: 0.3, type: "square", gain: 0.08 },
  api: { notes: [440, 554.37, 659.25, 880], step: 0.07, dur: 0.2, type: "sawtooth", gain: 0.08 },
  gong: { notes: [196, 392], step: 0.04, dur: 1.1, type: "sine", gain: 0.22 },
  detak: { notes: [660], step: 0, dur: 0.12, type: "square", gain: 0.07 },
};

/** Memutar jingle dan mengembalikan perkiraan lamanya (ms). Nama tak dikenal = tanpa suara. */
export function jingle(name: string): number {
  const d = JINGLES[name];
  if (!d) return 0;
  play((c, t) => d.notes.forEach((f, i) => tone(f, t + i * d.step, d.dur, d.type, d.gain, c)));
  return Math.round(((d.notes.length - 1) * d.step + d.dur) * 1000);
}

export const JINGLE_NAMES = Object.keys(JINGLES);

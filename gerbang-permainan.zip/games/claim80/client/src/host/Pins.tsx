import { appOrigin, appUrl } from "../base";
import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { formatClock } from "../play/logic";
import { useHost } from "./hostStore";
import "./host.css";

interface PinData {
  code: string;
  className: string;
  pin: string;
  expiresAt: number;
  cards: { id: string; name: string; absen: number | null }[];
}

/** Poster PIN kelas: PIN yang sama untuk semua murid dan berganti otomatis; halaman ini ikut memperbarui. */
export function Pins() {
  const { id = "" } = useParams();
  const token = useHost((s) => s.token);
  const init = useHost((s) => s.initToken);
  const [data, setData] = useState<PinData | null>(null);
  const [err, setErr] = useState("");
  const [base, setBase] = useState(appOrigin());
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    void init();
  }, [init]);
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 500);
    return () => clearInterval(t);
  }, []);
  useEffect(() => {
    if (!token) return;
    let off = false;
    const load = async () => {
      const r = await fetch(appUrl(`/api/sessions/${id}/pins`), { headers: { "x-host-token": token } });
      if (off) return;
      if (r.ok) setData((await r.json()) as PinData);
      else setErr("Tidak bisa memuat PIN kelas.");
    };
    void load();
    const poll = setInterval(() => void load(), 3000);
    void (async () => {
      if (/localhost|127\.0\.0\.1/.test(location.hostname)) {
        try {
          const lan = (await (await fetch(appUrl("/api/lan"))).json()) as { urls: string[] };
          if (lan.urls[0]) setBase(lan.urls[0]);
        } catch {
          /* tetap pakai origin */
        }
      }
    })();
    return () => {
      off = true;
      clearInterval(poll);
    };
  }, [id, token]);

  if (err) return <div className="h-root h-center">{err}</div>;
  if (!data) return <div className="h-root h-center">Memuat…</div>;
  const remain = Math.max(0, data.expiresAt - now);
  return (
    <div className="h-root pins-page">
      <div className="no-print pins-bar">
        <Link to={`/host/${id}`} className="btn">
          ← Kembali
        </Link>
        <button className="primary" onClick={() => window.print()}>
          Cetak
        </button>
        <span className="muted">
          PIN berganti otomatis tiap beberapa menit, jadi cetakan hanya berlaku sebentar. Untuk menyebutkan atau
          menuliskan PIN di papan, pakai tampilan ini.
        </span>
      </div>
      <article className="pin-poster">
        <div className="muted">
          CLAIM 80 · Kelas {data.className} · {data.cards.length} murid
        </div>
        <h1>PIN kelas</h1>
        <div className="big">{data.pin}</div>
        <p className="muted">berganti dalam {formatClock(remain)}</p>
        <p>
          Buka{" "}
          <span className="url">
            {base}/play/{data.code}
          </span>
        </p>
        <p>
          Kode sesi <b>{data.code}</b>, pilih namamu, lalu masukkan PIN di atas.
        </p>
      </article>
    </div>
  );
}

/** Pesan dari SIMPETERI (jendela pembuka) berisi daftar siswa satu kelas. Pola sama dengan Route Rush. */
export const ROSTER_MESSAGE = "claim80:roster";
/** Balasan dari layar guru ke jendela pembuka: "saya siap menerima daftar". */
export const READY_MESSAGE = "claim80:host-ready";

export interface ImportedStudent {
  /** id siswa di SIMPETERI (siswa.id) */
  id: string;
  name: string;
  absen?: number;
}

export interface ImportedRoster {
  kelas: string;
  roster: ImportedStudent[];
  /** PIN guru dari SIMPETERI (4–32 karakter); dipakai sebagai token guru, hanya di memori. */
  pin?: string;
  /** URL mutlak (http/https) halaman SIMPETERI untuk kembali setelah game selesai. */
  kembali?: string;
  /** id sesi Multi Permainan di SIMPETERI. */
  multiSesi?: string;
}

/** Hanya URL http/https yang sah; selain itu null. */
export function parseKembaliUrl(v: unknown): string | null {
  if (typeof v !== "string" || v.length > 2000) return null;
  try {
    const u = new URL(v);
    return u.protocol === "http:" || u.protocol === "https:" ? u.toString() : null;
  } catch {
    return null;
  }
}

/**
 * URL tujuan kembali ke SIMPETERI: hanya bila `kembali` satu origin dengan pengirim pesan roster.
 * Menambahkan `selesai=1&gameSesi=<id sesi game>`. Mengembalikan null bila origin tidak cocok.
 */
export function buildKembaliUrl(kembali: string, senderOrigin: string, gameSesi: string): string | null {
  const base = parseKembaliUrl(kembali);
  if (!base) return null;
  const u = new URL(base);
  if (u.origin !== senderOrigin) return null;
  u.searchParams.set("selesai", "1");
  u.searchParams.set("gameSesi", gameSesi);
  return u.toString();
}

const MAX_STUDENTS = 60;

/**
 * Memeriksa dan membersihkan pesan impor. Mengembalikan null bila bentuknya salah, sehingga pesan asing atau rusak diabaikan.
 * Nama dan id dipotong ke panjang wajar; id wajib unik; absen (bila ada) bilangan bulat 1–200.
 */
export function parseImportMessage(data: unknown): ImportedRoster | null {
  if (typeof data !== "object" || data === null) return null;
  const m = data as Record<string, unknown>;
  if (m["type"] !== ROSTER_MESSAGE || !Array.isArray(m["roster"])) return null;
  const raw = m["roster"] as unknown[];
  if (raw.length === 0 || raw.length > MAX_STUDENTS) return null;
  const seen = new Set<string>();
  const roster: ImportedStudent[] = [];
  for (const r of raw) {
    if (typeof r !== "object" || r === null) return null;
    const e = r as Record<string, unknown>;
    const id = typeof e["id"] === "string" ? e["id"].trim().slice(0, 64) : "";
    const name = typeof e["name"] === "string" ? e["name"].trim().replace(/\s+/g, " ").slice(0, 60) : "";
    if (!id || !name || seen.has(id)) return null;
    seen.add(id);
    const absen = e["absen"];
    if (
      absen !== undefined &&
      absen !== null &&
      !(typeof absen === "number" && Number.isInteger(absen) && absen >= 1 && absen <= 200)
    ) {
      return null;
    }
    roster.push({ id, name, ...(typeof absen === "number" ? { absen } : {}) });
  }
  const kelas = typeof m["kelas"] === "string" ? m["kelas"].trim().slice(0, 40) : "";
  // Field opsional dari Multi Permainan; bila ada tetapi tidak sah, seluruh pesan ditolak.
  const out: ImportedRoster = { kelas, roster };
  const pin = m["pin"];
  if (pin !== undefined && pin !== null) {
    if (typeof pin !== "string" || pin.length < 4 || pin.length > 32) return null;
    out.pin = pin;
  }
  const kembali = m["kembali"];
  if (kembali !== undefined && kembali !== null) {
    const k = parseKembaliUrl(kembali);
    if (!k) return null;
    out.kembali = k;
  }
  const ms = m["multiSesi"];
  if (ms !== undefined && ms !== null) {
    if (typeof ms !== "string" || !ms.trim() || ms.length > 100) return null;
    out.multiSesi = ms.trim();
  }
  return out;
}

/** Impor manual (tanpa SIMPETERI): satu nama per baris. */
export function parseManualNames(text: string): ImportedStudent[] {
  const names = text
    .split(/\r?\n/)
    .map((l) => l.trim().replace(/\s+/g, " ").slice(0, 60))
    .filter(Boolean)
    .slice(0, MAX_STUDENTS);
  return names.map((name, i) => ({ id: `manual-${i + 1}`, name, absen: i + 1 }));
}

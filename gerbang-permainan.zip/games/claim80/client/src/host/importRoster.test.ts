import { describe, expect, it } from "vitest";
import { ROSTER_MESSAGE, buildKembaliUrl, parseImportMessage, parseManualNames } from "./importRoster";

const ok = {
  type: ROSTER_MESSAGE,
  kelas: "6C",
  roster: [
    { id: "a1", name: "  Adnan   Fahreza ", absen: 1 },
    { id: "a2", name: "Adnan Sharif", absen: 2 },
    { id: "a3", name: "Budi" },
  ],
};

describe("parseImportMessage", () => {
  it("menerima pesan sah dan merapikan nama", () => {
    const r = parseImportMessage(ok)!;
    expect(r.kelas).toBe("6C");
    expect(r.roster[0]).toEqual({ id: "a1", name: "Adnan Fahreza", absen: 1 });
    expect(r.roster[2]).toEqual({ id: "a3", name: "Budi" });
  });
  it("menolak pesan asing atau rusak", () => {
    expect(parseImportMessage(null)).toBeNull();
    expect(parseImportMessage("x")).toBeNull();
    expect(parseImportMessage({ type: "route-rush:roster", roster: ok.roster })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [] })).toBeNull();
    expect(
      parseImportMessage({
        type: ROSTER_MESSAGE,
        roster: Array.from({ length: 61 }, (_, i) => ({ id: `s${i}`, name: "N" })),
      }),
    ).toBeNull();
    expect(
      parseImportMessage({
        type: ROSTER_MESSAGE,
        roster: [
          { id: "x", name: "A" },
          { id: "x", name: "B" },
        ],
      }),
    ).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "A", absen: 0 }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "" }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: 5, name: "A" }] })).toBeNull();
  });
  it("memotong id dan nama yang kepanjangan", () => {
    const r = parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "i".repeat(100), name: "n".repeat(100) }] })!;
    expect(r.roster[0]!.id).toHaveLength(64);
    expect(r.roster[0]!.name).toHaveLength(60);
  });
});

describe("parseManualNames", () => {
  it("satu nama per baris, baris kosong diabaikan", () => {
    expect(parseManualNames("Rina\n\n  Budi  Santoso \r\n")).toEqual([
      { id: "manual-1", name: "Rina", absen: 1 },
      { id: "manual-2", name: "Budi Santoso", absen: 2 },
    ]);
  });
});

describe("field Multi Permainan (pin, kembali, multiSesi)", () => {
  const multi = { ...ok, pin: "1234", kembali: "https://simpeteri.example/multi-permainan?x=1", multiSesi: "ms-1" };

  it("menerima pin, kembali, dan multiSesi yang sah", () => {
    const r = parseImportMessage(multi)!;
    expect(r.pin).toBe("1234");
    expect(r.kembali).toBe("https://simpeteri.example/multi-permainan?x=1");
    expect(r.multiSesi).toBe("ms-1");
  });
  it("ketiganya opsional", () => {
    const r = parseImportMessage(ok)!;
    expect(r.pin).toBeUndefined();
    expect(r.kembali).toBeUndefined();
    expect(r.multiSesi).toBeUndefined();
  });
  it("menolak pin di luar 4-32 karakter atau bukan string", () => {
    expect(parseImportMessage({ ...multi, pin: "123" })).toBeNull();
    expect(parseImportMessage({ ...multi, pin: "x".repeat(33) })).toBeNull();
    expect(parseImportMessage({ ...multi, pin: 1234 })).toBeNull();
  });
  it("menolak kembali yang bukan URL http/https", () => {
    expect(parseImportMessage({ ...multi, kembali: "javascript:alert(1)" })).toBeNull();
    expect(parseImportMessage({ ...multi, kembali: "/relatif" })).toBeNull();
    expect(parseImportMessage({ ...multi, kembali: 5 })).toBeNull();
  });
  it("menolak multiSesi kosong atau bukan string", () => {
    expect(parseImportMessage({ ...multi, multiSesi: "  " })).toBeNull();
    expect(parseImportMessage({ ...multi, multiSesi: 7 })).toBeNull();
  });
});

describe("buildKembaliUrl", () => {
  it("menambah selesai=1 dan gameSesi, mempertahankan query lama", () => {
    const u = new URL(buildKembaliUrl("https://s.example/multi?x=1", "https://s.example", "g-9")!);
    expect(u.searchParams.get("x")).toBe("1");
    expect(u.searchParams.get("selesai")).toBe("1");
    expect(u.searchParams.get("gameSesi")).toBe("g-9");
  });
  it("menolak origin yang berbeda dari pengirim roster", () => {
    expect(buildKembaliUrl("https://jahat.example/x", "https://s.example", "g")).toBeNull();
    expect(buildKembaliUrl("http://s.example/x", "https://s.example", "g")).toBeNull();
  });
  it("menolak URL non-http", () => {
    expect(buildKembaliUrl("javascript:1", "https://s.example", "g")).toBeNull();
  });
});

import { useState } from "react";
import { useHost } from "./hostStore";

/** Antrean dan stasiun untuk guru (SPEC §2 Mode Stasiun). */
export function StationPanel({ code }: { code: string }) {
  const station = useHost((s) => s.station);
  const roster = useHost((s) => s.roster);
  const send = useHost((s) => s.send);
  const [pick, setPick] = useState("");
  if (!station) return <p className="muted">Memuat…</p>;
  const taken = new Set([
    ...station.queue.map((q) => q.id),
    ...station.stations.map((s) => s.studentId).filter(Boolean),
  ]);
  const free = roster.filter((r) => !taken.has(r.id));
  return (
    <div className="set-grid">
      <section className="h-card">
        <h2>Stasiun ({station.stations.length})</h2>
        {station.stations.length === 0 ? (
          <p className="muted">
            Belum ada tablet. Di tiap tablet buka <b>/station</b>, masukkan kode sesi <b>{code}</b> dan token guru satu
            kali.
          </p>
        ) : (
          <ul className="stn-list">
            {station.stations.map((s) => (
              <li key={s.no}>
                <span className="no">{s.no}</span>
                <span className="nm">{s.name ? `${s.name} sedang menjawab` : "Menunggu giliran"}</span>
                {s.studentId && (
                  <button className="sm" onClick={() => send("host:station:release", { no: s.no })}>
                    Lepas
                  </button>
                )}
              </li>
            ))}
          </ul>
        )}
        <p className="muted">
          Mode Stasiun {station.mode ? "aktif" : "belum diaktifkan (tab Pengaturan)"}. Tablet tetap bisa dipakai.
        </p>
      </section>

      <section className="h-card">
        <h2>Antrean ({station.queue.length})</h2>
        <div className="stn-add">
          <select value={pick} onChange={(e) => setPick(e.target.value)} aria-label="Pilih murid">
            <option value="">Pilih murid…</option>
            {free.map((r) => (
              <option key={r.id} value={r.id}>
                {r.absen ? `${r.absen}. ` : ""}
                {r.name}
              </option>
            ))}
          </select>
          <button
            className="primary"
            disabled={!pick}
            onClick={() => {
              send("host:queue:add", { studentId: pick });
              setPick("");
            }}
          >
            Tambah antrean
          </button>
        </div>
        <ol className="stn-queue">
          {station.queue.map((q) => (
            <li key={q.id}>
              <span className="av" style={{ background: q.color }}>
                {q.initials}
              </span>
              <span className="nm">{q.name}</span>
              <button className="sm" onClick={() => send("host:queue:remove", { studentId: q.id })}>
                Keluarkan
              </button>
            </li>
          ))}
          {station.queue.length === 0 && <li className="muted">Antrean kosong.</li>}
        </ol>
        {station.queue.length > 0 && (
          <button className="danger" onClick={() => send("host:queue:clear")}>
            Kosongkan antrean
          </button>
        )}
      </section>
    </div>
  );
}

import { appUrl } from "../base";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import type { VoMode } from "@claim80/shared";
import { ENGINE_LABEL, VoPlayer, detectEngine, recKey, recordings } from "../audio/vo";
import type { VoEngine } from "../audio/vo";
import { useHost } from "./hostStore";
import "./host.css";

interface Script {
  frasa: string[];
  sel: string[];
  nama: { id: string; nama: string }[];
}

const MODES: { id: VoMode; label: string; info: string }[] = [
  {
    id: "penting_dan_klaim",
    label: "Penting dan klaim",
    info: "Setiap klaim, rebut, streak, dan pergantian fase (bawaan)",
  },
  { id: "semua", label: "Semua", info: "Termasuk pengumuman kecil dan hitung mundur" },
  { id: "penting_saja", label: "Penting saja", info: "Hanya kejadian besar: level 7–8, emas, rebut berhasil, fase" },
  { id: "mati", label: "Mati", info: "Tanpa suara; subtitle tetap tampil di proyektor" },
];

const player = new VoPlayer();

/** Halaman Suara (VO): pengaturan, tes, ejaan nama, dan perekam suara guru. */
export function VoPage() {
  const { id = "" } = useParams();
  const s = useHost();
  const [script, setScript] = useState<Script | null>(null);
  const [engine, setEngine] = useState<VoEngine>("teks");
  const [have, setHave] = useState<Set<string>>(new Set());

  useEffect(() => {
    void s.initToken();
  }, [s.initToken]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (id && s.token) s.open(id);
  }, [id, s.token]); // eslint-disable-line react-hooks/exhaustive-deps
  useEffect(() => {
    if (!s.token) return;
    void (async () => {
      const r = await fetch(appUrl(`/api/sessions/${id}/vo-script`), { headers: { "x-host-token": s.token } });
      if (r.ok) setScript((await r.json()) as Script);
    })();
  }, [id, s.token]);
  useEffect(() => {
    void recordings.keys().then(setHave);
    void detectEngine().then(setEngine);
  }, []);

  const vo = s.vo;
  const set = (patch: Record<string, unknown>) => s.send("host:vo:settings", patch);
  const refresh = () => void recordings.keys().then(setHave);

  const recItems = useMemo(() => {
    if (!script) return { frasa: [], sel: [], nama: [] };
    return {
      frasa: script.frasa.map((f) => ({ key: recKey({ k: "teks", v: f }), label: f })),
      sel: script.sel.map((c) => ({ key: recKey({ k: "sel", v: c }), label: c })),
      nama: script.nama.map((n) => ({
        key: recKey({ k: "nama", v: n.nama, id: n.id }),
        label: s.voNames[n.id] ?? n.nama,
      })),
    };
  }, [script, s.voNames]);
  const total = recItems.frasa.length + recItems.sel.length + recItems.nama.length;
  const done = [...recItems.frasa, ...recItems.sel, ...recItems.nama].filter((i) => have.has(i.key)).length;

  return (
    <div className="h-root">
      <header className="h-top">
        <Link to={`/host/${id}`} className="back" aria-label="Kembali">
          ←
        </Link>
        <div className="brand">
          <span className="t">
            CLAIM <b>80</b>
          </span>
          <small>Suara pengumuman (VO) · Kelas {s.className}</small>
        </div>
      </header>

      <main className="vo-grid">
        <section className="h-card">
          <h2>Pengaturan suara</h2>
          <p className="muted">Suara hanya keluar dari layar proyektor. Perangkat murid tidak memutar suara.</p>
          <div className="vo-modes" role="radiogroup" aria-label="Mode suara">
            {MODES.map((m) => (
              <button
                key={m.id}
                role="radio"
                aria-checked={vo?.mode === m.id}
                className={vo?.mode === m.id ? "on" : ""}
                onClick={() => set({ mode: m.id })}
              >
                <b>{m.label}</b>
                <small>{m.info}</small>
              </button>
            ))}
          </div>
          <label className="vo-slider">
            Volume {Math.round((vo?.volume ?? 1) * 100)}%
            <input
              type="range"
              min={0}
              max={1}
              step={0.05}
              value={vo?.volume ?? 1}
              onChange={(e) => set({ volume: Number(e.target.value) })}
            />
          </label>
          <label className="vo-slider">
            Kecepatan bicara {(vo?.kecepatan ?? 1).toFixed(2)}×
            <input
              type="range"
              min={0.6}
              max={1.6}
              step={0.05}
              value={vo?.kecepatan ?? 1}
              onChange={(e) => set({ kecepatan: Number(e.target.value) })}
            />
          </label>
          <label className="vo-slider">
            Nada suara {(vo?.nada ?? 1).toFixed(2)}
            <input
              type="range"
              min={0.5}
              max={2}
              step={0.05}
              value={vo?.nada ?? 1}
              onChange={(e) => set({ nada: Number(e.target.value) })}
            />
          </label>
          <p className="muted">Subtitle selalu tampil di proyektor untuk aksesibilitas.</p>
        </section>

        <section className="h-card">
          <h2>Mesin suara aktif</h2>
          <div className="vo-engine">
            <div>
              <small>Di proyektor</small>
              <b>{s.voEngine || "Belum ada pengumuman diputar"}</b>
            </div>
            <div>
              <small>Di peramban ini</small>
              <b>{ENGINE_LABEL[engine]}</b>
            </div>
          </div>
          <p className="muted">
            Urutan: rekaman suara guru, lalu suara Indonesia bawaan perangkat, lalu suara online (bila ada internet),
            lalu hanya teks. Windows biasanya menyediakan suara Indonesia lewat Pengaturan, Waktu & Bahasa, Ucapan.
          </p>
          <div className="vo-actions">
            <button className="primary" onClick={() => s.send("host:vo:test")}>
              Tes VO di proyektor
            </button>
            <button
              onClick={() => {
                void player
                  .preview("Halo teman-teman! Ini tes suara pengumuman CLAIM 80.")
                  .then(() => detectEngine().then(setEngine));
              }}
            >
              Dengar di sini
            </button>
          </div>
          <p className="muted">
            Buka layar proyektor lalu klik tombol "aktifkan suara" sekali agar peramban mengizinkan suara.
          </p>
        </section>

        <section className="h-card wide">
          <h2>Ejaan nama untuk VO</h2>
          <p className="muted">Tulis sesuai bunyi bila nama sering salah dibaca, mis. Kayla menjadi "Kei-la".</p>
          <ul className="vo-names">
            {s.roster.map((r) => (
              <NameRow key={r.id} id={r.id} name={r.name} current={s.voNames[r.id] ?? ""} />
            ))}
          </ul>
        </section>

        <section className="h-card wide">
          <h2>
            Rekaman suara guru{" "}
            <em>
              {done}/{total}
            </em>
          </h2>
          <p className="muted">
            Rekam frasa, ucapan sel, dan nama murid. Rekaman dipakai hanya jika seluruh bagian sebuah kalimat sudah
            direkam; kalau belum, suara bawaan perangkat yang dipakai. Rekaman tersimpan di peramban ini, jadi buka
            proyektor di peramban dan alamat yang sama (mis. http://localhost:3080). Merekam butuh izin mikrofon dan
            hanya berjalan di localhost atau HTTPS.
          </p>
          <RecSection title="Frasa tetap" items={recItems.frasa} have={have} onChange={refresh} />
          <RecSection title="Ucapan sel (80)" items={recItems.sel} have={have} onChange={refresh} />
          <RecSection title="Nama murid" items={recItems.nama} have={have} onChange={refresh} />
        </section>
      </main>
      {s.toast && <div className="h-toast">{s.toast}</div>}
    </div>
  );
}

function NameRow({ id, name, current }: { id: string; name: string; current: string }) {
  const send = useHost((s) => s.send);
  const [v, setV] = useState(current);
  useEffect(() => setV(current), [current]);
  const spoken = v.trim() || name.trim().split(/\s+/)[0] || name;
  return (
    <li>
      <span className="nm">{name}</span>
      <input
        value={v}
        onChange={(e) => setV(e.target.value)}
        placeholder={name.trim().split(/\s+/)[0]}
        aria-label={`Ejaan VO ${name}`}
      />
      <button
        className="sm"
        disabled={!v.trim()}
        onClick={() => send("host:vo:name", { studentId: id, name: v.trim() })}
      >
        Simpan
      </button>
      <button
        className="sm"
        onClick={() =>
          void player.preview(`${spoken} telah mengklaim kartu E enam!`, [
            { k: "nama", v: spoken, id },
            { k: "teks", v: " telah mengklaim kartu " },
            { k: "sel", v: "E enam" },
          ])
        }
      >
        Dengar
      </button>
      <button className="sm" title="Putar di proyektor" onClick={() => send("host:vo:test", { studentId: id })}>
        Di proyektor
      </button>
    </li>
  );
}

function RecSection({
  title,
  items,
  have,
  onChange,
}: {
  title: string;
  items: { key: string; label: string }[];
  have: Set<string>;
  onChange: () => void;
}) {
  const done = items.filter((i) => have.has(i.key)).length;
  return (
    <details className="vo-rec">
      <summary>
        {title}{" "}
        <em>
          {done}/{items.length}
        </em>
      </summary>
      <ul>
        {items.map((i) => (
          <RecRow key={i.key} k={i.key} label={i.label} has={have.has(i.key)} onChange={onChange} />
        ))}
      </ul>
    </details>
  );
}

function RecRow({ k, label, has, onChange }: { k: string; label: string; has: boolean; onChange: () => void }) {
  const [rec, setRec] = useState(false);
  const [err, setErr] = useState("");
  const mr = useRef<MediaRecorder | null>(null);
  const chunks = useRef<Blob[]>([]);

  const start = async () => {
    setErr("");
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const r = new MediaRecorder(stream);
      chunks.current = [];
      r.ondataavailable = (e) => chunks.current.push(e.data);
      r.onstop = () => {
        stream.getTracks().forEach((t) => t.stop());
        void recordings.put(k, new Blob(chunks.current, { type: r.mimeType || "audio/webm" })).then(onChange);
      };
      r.start();
      mr.current = r;
      setRec(true);
    } catch {
      setErr("Mikrofon tidak bisa dipakai (izin ditolak atau bukan localhost/HTTPS).");
    }
  };
  const stop = () => {
    mr.current?.stop();
    setRec(false);
  };
  const play = async () => {
    const b = await recordings.get(k);
    if (!b) return;
    const url = URL.createObjectURL(b);
    const a = new Audio(url);
    a.onended = () => URL.revokeObjectURL(url);
    void a.play();
  };
  return (
    <li className={has ? "ok" : ""}>
      <span className="lb">{label}</span>
      <span className="st">{has ? "Sudah" : "Belum"}</span>
      {rec ? (
        <button className="sm danger" onClick={stop}>
          Berhenti
        </button>
      ) : (
        <button className="sm" onClick={() => void start()}>
          {has ? "Rekam ulang" : "Rekam"}
        </button>
      )}
      {has && (
        <>
          <button className="sm" onClick={() => void play()}>
            Putar
          </button>
          <button className="sm" onClick={() => void recordings.delete(k).then(onChange)}>
            Hapus
          </button>
        </>
      )}
      {err && <small className="err">{err}</small>}
    </li>
  );
}

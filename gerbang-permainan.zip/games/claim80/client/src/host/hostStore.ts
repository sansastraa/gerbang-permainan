import { SOCKET_PATH, appUrl } from "../base";
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { create } from "zustand";
import type {
  FlagItem,
  HostPlayer,
  HostSettings,
  StationState,
  Phase,
  PublicCard,
  Snapshot,
  TickerItem,
  VoSettings,
} from "@claim80/shared";
import type { ImportedRoster, ImportedStudent } from "./importRoster";

export interface SessionSummary {
  id: string;
  code: string;
  className: string;
  phase: Phase;
  students: number;
}

export interface HostState {
  token: string;
  tokenError: string;
  sessions: SessionSummary[];
  imported: ImportedRoster | null;
  error: string;
  // sesi aktif
  sessionId: string;
  code: string;
  className: string;
  phase: Phase;
  startedAt: number;
  pausedAt: number | null;
  durationMs: number;
  offset: number;
  board: Record<string, PublicCard>;
  roster: HostPlayer[];
  ticker: TickerItem[];
  flags: FlagItem[];
  pin: { value: string; expiresAt: number; intervalMs: number } | null;
  settings: HostSettings | null;
  station: StationState | null;
  vo: VoSettings | null;
  voNames: Record<string, string>;
  voEngine: string;
  mission: { claimed: number; target: number; done: boolean };
  toast: string;

  /** true bila token guru berasal dari PIN SIMPETERI (hanya di memori, tidak disimpan). */
  pinMode: boolean;
  /** origin jendela SIMPETERI pengirim roster; satu-satunya tujuan "kembali" yang diizinkan. */
  senderOrigin: string;
  kembali: string;
  multiSesi: string;

  initToken: () => Promise<void>;
  setToken: (t: string) => Promise<boolean>;
  /** Menerima roster dari SIMPETERI: simpan, dan bila ada PIN pakai sebagai token guru. */
  receiveRoster: (r: ImportedRoster, origin: string) => Promise<void>;
  loadSessions: () => Promise<void>;
  createSession: (className: string, roster: ImportedStudent[], autoApprove: boolean) => Promise<string | null>;
  open: (id: string) => void;
  send: (event: string, payload?: unknown) => void;
  setImported: (r: ImportedRoster | null) => void;
  flash: (m: string) => void;
}

let socket: Socket | null = null;
const KEY = "claim80.hostToken";
const read = (): string => {
  try {
    return sessionStorage.getItem(KEY) ?? "";
  } catch {
    return "";
  }
};

async function api<T>(
  token: string,
  path: string,
  init?: RequestInit,
): Promise<{ ok: boolean; status: number; data: T }> {
  const r = await fetch(appUrl(path), {
    ...init,
    headers: { "content-type": "application/json", "x-host-token": token, ...(init?.headers ?? {}) },
  });
  let data = null as T;
  try {
    data = (await r.json()) as T;
  } catch {
    /* tanpa isi */
  }
  return { ok: r.ok, status: r.status, data };
}

let pinArrived: () => void = () => {};
const pinPromise = new Promise<void>((res) => {
  pinArrived = res;
});
/** Beri SIMPETERI waktu singkat mengirim PIN sebelum token otomatis loopback dicoba. */
function waitForPin(ms: number): Promise<void> {
  return Promise.race([pinPromise, new Promise<void>((res) => setTimeout(res, ms))]);
}

export const useHost = create<HostState>((set, get) => ({
  pinMode: false,
  senderOrigin: "",
  kembali: "",
  multiSesi: "",
  token: read(),
  tokenError: "",
  sessions: [],
  imported: null,
  error: "",
  sessionId: "",
  code: "",
  className: "",
  phase: "LOBBY",
  startedAt: 0,
  pausedAt: null,
  durationMs: 0,
  offset: 0,
  board: {},
  roster: [],
  ticker: [],
  flags: [],
  pin: null,
  settings: null,
  station: null,
  vo: null,
  voNames: {},
  voEngine: "",
  mission: { claimed: 0, target: 70, done: false },
  toast: "",

  async receiveRoster(r, origin) {
    set({ imported: r, senderOrigin: origin, kembali: r.kembali ?? "", multiSesi: r.multiSesi ?? "" });
    if (!r.pin) {
      pinArrived();
      return;
    }
    // PIN dari SIMPETERI menggantikan token apa pun; tidak ditulis ke storage, URL, maupun log.
    set({ pinMode: true });
    const res = await api<unknown>(r.pin, "/api/sessions");
    if (res.ok) set({ token: r.pin, tokenError: "" });
    else set({ token: "", tokenError: "PIN guru salah, samakan dengan PIN di SIMPETERI" });
    pinArrived();
  },

  async initToken() {
    if (typeof window !== "undefined" && window.opener) await waitForPin(1500);
    if (get().pinMode) return;
    const cur = get().token;
    if (cur) {
      // token tersimpan bisa basi setelah server dimulai ulang; periksa dulu
      const r = await api<unknown>(cur, "/api/sessions");
      if (r.ok) return;
      try {
        sessionStorage.removeItem(KEY);
      } catch {
        /* abaikan */
      }
      set({ token: "" });
    }
    try {
      const r = await fetch(appUrl("/api/host-token"));
      if (r.ok) {
        const { token } = (await r.json()) as { token: string };
        sessionStorage.setItem(KEY, token);
        set({ token });
      }
    } catch {
      /* diisi manual */
    }
  },

  async setToken(t) {
    const r = await api<unknown>(t.trim(), "/api/sessions");
    if (!r.ok) {
      set({ tokenError: "Token tidak cocok." });
      return false;
    }
    try {
      sessionStorage.setItem(KEY, t.trim());
    } catch {
      /* abaikan */
    }
    set({ token: t.trim(), tokenError: "" });
    return true;
  },

  async loadSessions() {
    const r = await api<SessionSummary[]>(get().token, "/api/sessions");
    if (r.ok) set({ sessions: r.data });
  },

  async createSession(className, roster, autoApprove) {
    const r = await api<{ id: string; error?: string }>(get().token, "/api/sessions", {
      method: "POST",
      body: JSON.stringify({
        className,
        autoApprove,
        roster: roster.map((s) => ({ id: s.id, name: s.name, absen: s.absen ?? null })),
      }),
    });
    if (!r.ok) {
      set({ error: "Gagal membuat sesi. Periksa daftar siswa." });
      return null;
    }
    await get().loadSessions();
    return r.data.id;
  },

  open(id) {
    socket?.close();
    set({ sessionId: id, board: {}, roster: [], ticker: [], flags: [], phase: "LOBBY", toast: "" });
    const s = io({
      path: SOCKET_PATH,
      auth: { role: "host", sessionId: id, hostToken: get().token },
      transports: ["websocket", "polling"],
    });
    socket = s;
    s.on("fatal", (m: { message: string }) => set({ error: m.message }));
    s.on("state:snapshot", (snap: Snapshot) => {
      const board: Record<string, PublicCard> = {};
      for (const c of snap.board) board[c.cell] = c;
      set({
        board,
        roster: snap.roster ?? [],
        flags: snap.flags ?? [],
        pin: snap.pin ?? null,
        settings: snap.settings ?? null,
        station: snap.station ?? null,
        vo: snap.vo ?? null,
        voNames: snap.voNames ?? {},
        code: snap.code,
        className: snap.className,
        phase: snap.phase,
        startedAt: snap.startedAt,
        pausedAt: snap.pausedAt,
        durationMs: snap.durationMs,
        mission: snap.mission,
        offset: snap.serverNow - Date.now(),
      });
    });
    s.on(
      "board:diff",
      (d: {
        cells: PublicCard[];
        phase: Phase;
        startedAt: number;
        pausedAt: number | null;
        serverNow: number;
        mission: HostState["mission"];
      }) => {
        const board = { ...get().board };
        for (const c of d.cells) board[c.cell] = c;
        set({
          board,
          phase: d.phase,
          startedAt: d.startedAt,
          pausedAt: d.pausedAt,
          mission: d.mission,
          offset: d.serverNow - Date.now(),
        });
      },
    );
    s.on("host:roster", (r: HostPlayer[]) => set({ roster: r }));
    s.on("host:flags", (f: FlagItem[]) => set({ flags: f }));
    s.on("host:settings", (v: HostSettings) => set({ settings: v }));
    s.on("station:state", (v: StationState) => set({ station: v }));
    s.on("host:pin", (p: { value: string; expiresAt: number; intervalMs: number }) => set({ pin: p }));
    s.on("vo:settings", (v: VoSettings) => set({ vo: v }));
    s.on("vo:names", (n: Record<string, string>) => set({ voNames: n }));
    s.on("vo:status", (m: { engine: string }) => set({ voEngine: m.engine }));
    s.on("ticker:backlog", (t: TickerItem[]) => set({ ticker: t }));
    s.on("ticker:push", (t: TickerItem) => set({ ticker: [...get().ticker.slice(-59), t] }));
    s.on("host:rejected", (m: { message: string }) => get().flash(m.message));
  },

  send: (event, payload) => socket?.emit(event, payload),
  setImported: (r) => set({ imported: r }),
  flash(m) {
    set({ toast: m });
    setTimeout(() => {
      if (get().toast === m) set({ toast: "" });
    }, 3500);
  },
}));

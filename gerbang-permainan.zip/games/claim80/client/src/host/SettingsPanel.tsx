import { useEffect, useState } from "react";
import { useHost } from "./hostStore";

/** Waktu soal di bank (detik) per level 1–8, untuk pratinjau waktu menjawab efektif. */
const BANK_WAKTU = [30, 30, 45, 60, 60, 90, 120, 180];
const RANDOM_COLS = [
  { c: "A", nama: "Numerik" },
  { c: "E", nama: "Aritmetika" },
  { c: "I", nama: "Sandi & Pola" },
];

const num = (v: string, fallback: number) => (v.trim() === "" || Number.isNaN(Number(v)) ? fallback : Number(v));

/** Pengaturan permainan: durasi, waktu menjawab, jeda tiap N soal, soal acak, dan Mode Stasiun. */
export function SettingsPanel() {
  const settings = useHost((s) => s.settings);
  const send = useHost((s) => s.send);
  const [durasi, setDurasi] = useState("40");
  const [pct, setPct] = useState("60");
  const [min, setMin] = useState("15");
  const [setiap, setSetiap] = useState("2");
  const [detik, setDetik] = useState("5");

  useEffect(() => {
    if (!settings) return;
    setDurasi(String(settings.durasiMenit));
    setPct(String(Math.round(settings.pengaliWaktu * 100)));
    setMin(String(settings.waktuMin));
    setSetiap(String(settings.jedaSetiap));
    setDetik(String(settings.jedaDetik));
  }, [settings]);

  if (!settings) return <p className="muted">Memuat pengaturan…</p>;
  const locked = settings.locked;
  const pengali = num(pct, 60) / 100;
  const waktuMin = num(min, 15);
  const eff = BANK_WAKTU.map((w) => Math.max(waktuMin, Math.round(w * pengali)));
  const save = () =>
    send("host:game-settings", {
      durasiMenit: num(durasi, 40),
      pengaliWaktu: pengali,
      waktuMin,
      jedaSetiap: num(setiap, 2),
      jedaDetik: num(detik, 5),
    });
  const toggleRandom = (c: string) => {
    const has = settings.alwaysRandom.includes(c);
    send("host:random", { cols: has ? settings.alwaysRandom.filter((x) => x !== c) : [...settings.alwaysRandom, c] });
  };
  const battle = Math.max(1, Math.round(num(durasi, 40) * (15 / 40)));

  return (
    <div className="set-grid">
      <section className="h-card">
        <h2>Waktu permainan dan soal</h2>
        {locked && (
          <p className="set-lock">Dikunci karena permainan sudah dimulai. Buat sesi baru untuk mengubah waktu.</p>
        )}
        <label className="set-f">
          <span>Durasi permainan (menit)</span>
          <input
            type="number"
            min={5}
            max={120}
            value={durasi}
            disabled={locked}
            onChange={(e) => setDurasi(e.target.value)}
          />
          <small>BATTLE (rebut aktif) mulai menit ke-{battle}; RUSH di beberapa menit terakhir. Bawaan 40 menit.</small>
        </label>
        <label className="set-f">
          <span>Waktu menjawab: {pct}% dari waktu bank</span>
          <input
            type="range"
            min={30}
            max={200}
            step={5}
            value={num(pct, 60)}
            disabled={locked}
            onChange={(e) => setPct(e.target.value)}
          />
          <small>Makin kecil makin cepat (menyulitkan menyalin soal ke AI). Bawaan 60%.</small>
        </label>
        <label className="set-f">
          <span>Waktu minimum per soal (detik)</span>
          <input
            type="number"
            min={5}
            max={60}
            value={min}
            disabled={locked}
            onChange={(e) => setMin(e.target.value)}
          />
        </label>
        <div className="set-eff" aria-label="Waktu menjawab efektif per level">
          {eff.map((e, i) => (
            <span key={i}>
              <small>Level {i + 1}</small>
              <b>{e} dtk</b>
            </span>
          ))}
        </div>
        <div className="set-row">
          <label className="set-f">
            <span>Dibekukan setelah menjawab (soal)</span>
            <input
              type="number"
              min={1}
              max={10}
              value={setiap}
              disabled={locked}
              onChange={(e) => setSetiap(e.target.value)}
            />
          </label>
          <label className="set-f">
            <span>Lama dibekukan (detik)</span>
            <input
              type="number"
              min={0}
              max={60}
              value={detik}
              disabled={locked}
              onChange={(e) => setDetik(e.target.value)}
            />
          </label>
        </div>
        <small className="muted">
          Contoh bawaan: setiap 2 soal selesai (benar atau salah), murid itu dibekukan 5 detik. Isi lama 0 untuk
          mematikan.
        </small>
        <button className="primary" disabled={locked} onClick={save}>
          Simpan pengaturan
        </button>
      </section>

      <section className="h-card">
        <h2>Soal acak (anti-hafal)</h2>
        <p className="muted">
          Kolom yang dipilih memakai soal dengan angka berbeda untuk tiap murid, jadi jawaban tidak bisa dibisikkan atau
          disalin. Kolom lain tetap memakai bank soal. Setelah kedua varian bank terpakai, soal acak dipakai otomatis.
        </p>
        <div className="set-chips">
          {RANDOM_COLS.map((r) => (
            <button
              key={r.c}
              className={settings.alwaysRandom.includes(r.c) ? "on" : ""}
              aria-pressed={settings.alwaysRandom.includes(r.c)}
              onClick={() => toggleRandom(r.c)}
            >
              <b>{r.c}</b> {r.nama}
            </button>
          ))}
        </div>
        <h2>Mode Stasiun</h2>
        <p className="muted">
          Untuk kelas dengan sedikit perangkat: murid antre dan bergiliran di 2–4 tablet di depan kelas. Buka{" "}
          <b>/station</b> di tiap tablet, lalu kelola antrean di tab Stasiun.
        </p>
        <label className="check">
          <input
            type="checkbox"
            checked={settings.stationMode}
            onChange={(e) => send("host:station-mode", { on: e.target.checked })}
          />
          Aktifkan Mode Stasiun (antrean tampil di proyektor)
        </label>
      </section>
    </div>
  );
}

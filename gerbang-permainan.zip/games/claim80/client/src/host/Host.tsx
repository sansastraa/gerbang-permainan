import { appOrigin, appUrl } from "../base";
import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { KOLOM_LABEL } from "@claim80/shared";
import type { FlagItem, HostPlayer, Phase, PublicCard } from "@claim80/shared";
import { COLS, ROWS, formatClock } from "../play/logic";
import { COL_HUE } from "../theme";
import { READY_MESSAGE, buildKembaliUrl, parseImportMessage, parseManualNames } from "./importRoster";
import type { ImportedStudent } from "./importRoster";
import { SettingsPanel } from "./SettingsPanel";
import { StationPanel } from "./StationPanel";
import { useHost } from "./hostStore";
import "./host.css";

function useNow(ms = 500): number {
  const [n, setN] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setN(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

/** Gerbang token guru: otomatis dari laptop server, atau diketik bila membuka dari perangkat lain. */
function TokenGate({ children }: { children: React.ReactNode }) {
  const token = useHost((s) => s.token);
  const err = useHost((s) => s.tokenError);
  const init = useHost((s) => s.initToken);
  const set = useHost((s) => s.setToken);
  const [v, setV] = useState("");
  const [tried, setTried] = useState(false);
  useEffect(() => {
    void init().then(() => setTried(true));
  }, [init]);
  if (token && tried) return <>{children}</>;
  if (!tried) return <div className="h-root h-center">Memeriksa…</div>;
  return (
    <div className="h-root h-center">
      <div className="h-card narrow">
        <h1>Konsol Guru</h1>
        <p className="muted">Buka dari laptop server, atau masukkan token guru yang tercetak di terminal server.</p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            void set(v);
          }}
        >
          <input value={v} onChange={(e) => setV(e.target.value)} placeholder="Token guru" aria-label="Token guru" />
          <button className="primary" disabled={!v.trim()}>
            Masuk
          </button>
        </form>
        {err && <p className="err">{err}</p>}
      </div>
    </div>
  );
}

/**
 * Terima daftar siswa (dan PIN guru) dari SIMPETERI (jendela pembuka); asal pesan dipastikan jendela pembuka itu sendiri.
 * Dipasang di atas TokenGate agar PIN sudah dipakai sebelum token otomatis dicoba.
 */
function useRosterBridge(): void {
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (!window.opener || e.source !== window.opener) return;
      const r = parseImportMessage(e.data);
      if (r) void useHost.getState().receiveRoster(r, e.origin);
    };
    window.addEventListener("message", onMsg);
    window.opener?.postMessage({ type: READY_MESSAGE }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);
}

export function Host() {
  useRosterBridge();
  return (
    <TokenGate>
      <HostHome />
    </TokenGate>
  );
}

export function HostSession() {
  useRosterBridge();
  return (
    <TokenGate>
      <Console />
      <ReturnBanner />
    </TokenGate>
  );
}

/** Setelah sesi berakhir, kembali ke SIMPETERI (hanya ke origin pengirim roster) dengan hitung mundur yang bisa dibatalkan. */
function ReturnBanner() {
  const phase = useHost((s) => s.phase);
  const kembali = useHost((s) => s.kembali);
  const multiSesi = useHost((s) => s.multiSesi);
  const origin = useHost((s) => s.senderOrigin);
  const sessionId = useHost((s) => s.sessionId);
  const [left, setLeft] = useState(10);
  const [cancel, setCancel] = useState(false);
  const target = useMemo(
    () => (kembali && multiSesi && sessionId ? buildKembaliUrl(kembali, origin, sessionId) : null),
    [kembali, multiSesi, origin, sessionId],
  );
  const active = phase === "END" && !!target && !cancel;
  useEffect(() => {
    if (!active) return;
    if (left <= 0) {
      window.location.assign(target!);
      return;
    }
    const t = setTimeout(() => setLeft((v) => v - 1), 1000);
    return () => clearTimeout(t);
  }, [active, left, target]);
  if (phase !== "END" || !target) return null;
  return (
    <div className="h-toast" role="status">
      Permainan selesai. {cancel ? "Kembali otomatis dibatalkan." : `Kembali ke SIMPETERI dalam ${left} detik…`}{" "}
      <button className="sm" onClick={() => window.location.assign(target)}>
        Kembali sekarang
      </button>{" "}
      {!cancel && (
        <button className="sm" onClick={() => setCancel(true)}>
          Tetap di sini
        </button>
      )}
    </div>
  );
}

function HostHome() {
  const s = useHost();
  const nav = useNavigate();
  const [manual, setManual] = useState("");
  const [name, setName] = useState("");
  const [auto, setAuto] = useState(false);

  useEffect(() => {
    void s.loadSessions();
  }, [s.loadSessions]); // eslint-disable-line react-hooks/exhaustive-deps

  const manualList = useMemo(() => parseManualNames(manual), [manual]);
  const create = async (kelas: string, roster: ImportedStudent[]) => {
    const id = await s.createSession(kelas, roster, auto);
    if (id) nav(`/host/${id}`);
  };

  return (
    <div className="h-root">
      <header className="h-top">
        <div className="brand">
          <span className="t">
            CLAIM <b>80</b>
          </span>
          <small>Konsol Guru</small>
        </div>
        <div className="grow" />
        <TokenChip />
      </header>
      <main className="h-grid2">
        <section className="h-card">
          <h2>Sesi baru</h2>
          {s.imported ? (
            <>
              <p>
                Dari SIMPETERI: <b>Kelas {s.imported.kelas || "—"}</b> · {s.imported.roster.length} siswa
              </p>
              <ul className="h-names">
                {s.imported.roster.slice(0, 6).map((r) => (
                  <li key={r.id}>
                    {r.absen ?? "·"}. {r.name}
                  </li>
                ))}
                {s.imported.roster.length > 6 && (
                  <li className="muted">… dan {s.imported.roster.length - 6} lainnya</li>
                )}
              </ul>
              <label className="check">
                <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
                Setujui murid otomatis (tanpa persetujuan satu per satu)
              </label>
              <button className="primary" onClick={() => void create(s.imported!.kelas || "Kelas", s.imported!.roster)}>
                Buat sesi untuk kelas ini
              </button>
            </>
          ) : (
            <>
              <p className="muted">
                Buka halaman ini dari menu <b>CLAIM 80</b> di SIMPETERI agar daftar siswa kelas terisi otomatis. Tanpa
                itu, tempel nama siswa di bawah (satu per baris).
              </p>
              <input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Nama kelas, mis. 5A"
                aria-label="Nama kelas"
              />
              <textarea
                value={manual}
                onChange={(e) => setManual(e.target.value)}
                rows={7}
                placeholder={"Rina Putri\nBudi Santoso\nSari Dewi"}
                aria-label="Daftar siswa"
              />
              <label className="check">
                <input type="checkbox" checked={auto} onChange={(e) => setAuto(e.target.checked)} />
                Setujui murid otomatis
              </label>
              <button
                className="primary"
                disabled={manualList.length === 0 || !name.trim()}
                onClick={() => void create(name.trim(), manualList)}
              >
                Buat sesi ({manualList.length} siswa)
              </button>
            </>
          )}
          {s.error && <p className="err">{s.error}</p>}
        </section>
        <section className="h-card">
          <h2>Sesi berjalan</h2>
          {s.sessions.length === 0 && <p className="muted">Belum ada sesi.</p>}
          <ul className="h-sessions">
            {s.sessions.map((x) => (
              <li key={x.id}>
                <div>
                  <b>Kelas {x.className}</b>
                  <small>
                    {x.students} siswa · kode {x.code} · {x.phase}
                  </small>
                </div>
                <Link className="btn" to={`/host/${x.id}`}>
                  Buka
                </Link>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
}

// -----------------------------------------------------------------------------------------------

function Console() {
  const { id = "" } = useParams();
  const s = useHost();
  const now = useNow();
  const [tab, setTab] = useState<"lobi" | "papan" | "bendera" | "pengaturan" | "stasiun" | "kabar">("lobi");
  const [adjust, setAdjust] = useState<HostPlayer | null>(null);
  const [cell, setCell] = useState<string | null>(null);

  useEffect(() => {
    if (id && s.token) s.open(id);
  }, [id, s.token]); // eslint-disable-line react-hooks/exhaustive-deps

  const serverNow = now + s.offset;
  const elapsed = s.phase === "LOBBY" ? 0 : (s.pausedAt ?? serverNow) - s.startedAt;
  const remain = Math.max(0, s.durationMs - elapsed);
  const pending = s.roster.filter((r) => r.status === "pending").length;
  const openFlags = s.flags.filter((f) => f.status === "open").length;
  const joined = s.roster.filter((r) => r.status === "approved").length;
  const origin = appOrigin();

  const confirmEnd = () => {
    if (window.confirm("Akhiri permainan sekarang? Papan akan dibekukan.")) s.send("host:phase", { phase: "END" });
  };

  return (
    <div className="h-root">
      <header className="h-top">
        <Link to="/host" className="back" aria-label="Kembali">
          ←
        </Link>
        <div className="brand">
          <span className="t">
            CLAIM <b>80</b>
          </span>
          <small>Kelas {s.className}</small>
        </div>
        <div className={`h-phase ph-${s.phase}`}>{s.phase === "LOBBY" ? "Lobi" : s.phase}</div>
        <div className="h-clock">{s.phase === "LOBBY" ? "--:--" : formatClock(remain)}</div>
        <div className="grow" />
        <div className="h-links">
          <a href={appUrl(`/projector/${s.code}`)} target="_blank" rel="noreferrer" className="btn">
            Buka proyektor
          </a>
          <Link to={`/report/${id}`} className="btn">
            Laporan
          </Link>
          <Link to={`/host/${id}/vo`} className="btn">
            Suara (VO)
          </Link>
          <Link to={`/host/${id}/pins`} className="btn">
            Cetak PIN kelas
          </Link>
        </div>
      </header>

      <div className="h-controls">
        {s.phase === "LOBBY" ? (
          <button className="primary" onClick={() => s.send("host:start")} disabled={joined === 0}>
            ▶ Mulai permainan ({joined} murid)
          </button>
        ) : (
          <>
            <div className="seg" role="group" aria-label="Fase">
              {(["OPEN", "BATTLE", "RUSH"] as Phase[]).map((p) => (
                <button
                  key={p}
                  className={s.phase === p ? "on" : ""}
                  onClick={() => s.send("host:phase", { phase: p })}
                  disabled={s.phase === "END"}
                >
                  {p}
                </button>
              ))}
            </div>
            {s.pausedAt === null ? (
              <button onClick={() => s.send("host:pause")} disabled={s.phase === "END"}>
                ⏸ Jeda
              </button>
            ) : (
              <button className="primary" onClick={() => s.send("host:resume")}>
                ▶ Lanjutkan
              </button>
            )}
            <button className="danger" onClick={confirmEnd} disabled={s.phase === "END"}>
              ■ Akhiri
            </button>
          </>
        )}
        <span className="grow" />
        <span className="muted">
          Misi {s.mission.claimed}/{s.mission.target}
        </span>
      </div>

      <div className="h-stats">
        <div>
          <b>{s.roster.filter((r) => r.online).length}</b>
          <span>murid online</span>
        </div>
        <div>
          <b>{joined}</b>
          <span>sudah masuk dari {s.roster.length}</span>
        </div>
        <div>
          <b>{s.mission.claimed}</b>
          <span>kartu terklaim dari 80</span>
        </div>
        <div className={openFlags > 0 ? "alert" : ""}>
          <b>{openFlags}</b>
          <span>bendera belum dicek</span>
        </div>
      </div>

      <nav className="h-tabs">
        <button className={tab === "lobi" ? "on" : ""} onClick={() => setTab("lobi")}>
          Murid {pending > 0 && <em>{pending}</em>}
        </button>
        <button className={tab === "papan" ? "on" : ""} onClick={() => setTab("papan")}>
          Papan
        </button>
        <button className={tab === "bendera" ? "on" : ""} onClick={() => setTab("bendera")}>
          Bendera {openFlags > 0 && <em>{openFlags}</em>}
        </button>
        <button className={tab === "pengaturan" ? "on" : ""} onClick={() => setTab("pengaturan")}>
          Pengaturan
        </button>
        <button className={tab === "stasiun" ? "on" : ""} onClick={() => setTab("stasiun")}>
          Stasiun {s.station && s.station.queue.length > 0 && <em>{s.station.queue.length}</em>}
        </button>
        <button className={tab === "kabar" ? "on" : ""} onClick={() => setTab("kabar")}>
          Kabar
        </button>
      </nav>

      {tab === "lobi" && (
        <section className="h-card flat">
          <div className="h-join">
            <div>
              Kode sesi <b className="code">{s.code}</b>
              <small>
                Murid buka{" "}
                <b>
                  {origin}/play/{s.code}
                </b>
              </small>
            </div>
            <div className="h-join-r">
              {pending > 0 && (
                <button className="primary" onClick={() => s.send("host:approveAll")}>
                  Setujui semua ({pending})
                </button>
              )}
              <PinBox pin={s.pin} fallback={s.roster[0]?.pin} serverNow={serverNow} />
            </div>
          </div>
          <RosterTable roster={s.roster} onAdjust={setAdjust} />
        </section>
      )}

      {tab === "papan" && (
        <section className="h-card flat h-boardwrap">
          <AdminBoard board={s.board} selected={cell} onSelect={setCell} />
          <CellPanel cell={cell ? s.board[cell] : undefined} roster={s.roster} />
        </section>
      )}

      {tab === "pengaturan" && <SettingsPanel />}
      {tab === "stasiun" && <StationPanel code={s.code} />}

      {tab === "bendera" && (
        <section className="h-card flat">
          <FlagPanel flags={s.flags} />
        </section>
      )}

      {tab === "kabar" && (
        <section className="h-card flat">
          <ul className="h-ticker">
            {[...s.ticker].reverse().map((t) => (
              <li key={t.id} className={t.kind}>
                <time>
                  {new Date(t.ts).toLocaleTimeString("id-ID", {
                    hour: "2-digit",
                    minute: "2-digit",
                    second: "2-digit",
                  })}
                </time>
                {t.text}
              </li>
            ))}
            {s.ticker.length === 0 && <li className="muted">Belum ada kabar.</li>}
          </ul>
        </section>
      )}

      {adjust && <AdjustModal p={adjust} onClose={() => setAdjust(null)} />}
      {s.error && <div className="h-toast err">{s.error}</div>}
      {s.toast && <div className="h-toast">{s.toast}</div>}
    </div>
  );
}

function RosterTable({ roster, onAdjust }: { roster: HostPlayer[]; onAdjust: (p: HostPlayer) => void }) {
  const send = useHost((s) => s.send);
  return (
    <div className="h-tablewrap">
      <table className="h-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Nama</th>
            <th>Status</th>
            <th className="num">Badge</th>
            <th className="num">Skor</th>
            <th className="num">Kartu</th>
            <th className="num">Streak</th>
            <th />
          </tr>
        </thead>
        <tbody>
          {roster.map((r) => (
            <tr key={r.id} className={r.frozen ? "frozen" : ""}>
              <td>{r.absen ?? "·"}</td>
              <td>
                <span className="dot" style={{ background: r.color }} aria-hidden />
                {r.name} <small className="muted">{r.initials}</small>
              </td>
              <td>
                {r.status === "approved" && (
                  <span className={`badge ${r.online ? "ok" : "off"}`}>{r.online ? "Online" : "Putus"}</span>
                )}
                {r.status === "pending" && <span className="badge wait">Menunggu</span>}
                {r.status === "none" && <span className="badge none">Belum masuk</span>}
                {r.frozen && <span className="badge frz">Beku</span>}
              </td>
              <td className="num">{r.badges}</td>
              <td className="num">{r.score}</td>
              <td className="num">{r.cards}</td>
              <td className="num">{r.streak > 1 ? <span className="stk">⚡{r.streak}</span> : r.streak}</td>
              <td className="acts">
                {r.status === "pending" && (
                  <button className="primary sm" onClick={() => send("host:approve", { studentId: r.id })}>
                    Setujui
                  </button>
                )}
                {r.status === "approved" && (
                  <>
                    <button className="sm" onClick={() => send("host:freeze", { studentId: r.id, frozen: !r.frozen })}>
                      {r.frozen ? "Cairkan" : "Bekukan"}
                    </button>
                    <button className="sm" onClick={() => onAdjust(r)}>
                      ± Poin
                    </button>
                    <button
                      className="sm"
                      title="Beri badge Jujur Itu Keren (+20)"
                      onClick={() => send("host:badge", { studentId: r.id, badgeId: "jujur_itu_keren" })}
                    >
                      Jujur ✓
                    </button>
                  </>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AdminBoard({
  board,
  selected,
  onSelect,
}: {
  board: Record<string, PublicCard>;
  selected: string | null;
  onSelect: (c: string) => void;
}) {
  return (
    <div className="h-board">
      <span />
      {COLS.map((c) => (
        <span key={c} className="ch" style={{ borderColor: COL_HUE[c] }}>
          {KOLOM_LABEL[c]!.ikon}
          {c}
        </span>
      ))}
      {ROWS.map((r) => (
        <Row key={r} row={r} board={board} selected={selected} onSelect={onSelect} />
      ))}
    </div>
  );
}

function Row({
  row,
  board,
  selected,
  onSelect,
}: {
  row: number;
  board: Record<string, PublicCard>;
  selected: string | null;
  onSelect: (c: string) => void;
}) {
  return (
    <>
      <span className="rh">{row}</span>
      {COLS.map((c) => {
        const card = board[`${c}${row}`];
        if (!card) return <span key={c} />;
        const claimed = card.status === "CLAIMED" || card.status === "CONTESTED";
        return (
          <button
            key={c}
            className={`hc ${card.status.toLowerCase()}${selected === card.cell ? " sel" : ""}`}
            style={claimed ? { background: card.color ?? "#999", color: "#fff" } : { borderTopColor: COL_HUE[c] }}
            onClick={() => onSelect(card.cell)}
            aria-label={`Kartu ${card.cell} ${card.status}`}
          >
            {claimed ? card.initials : card.cell}
          </button>
        );
      })}
    </>
  );
}

function CellPanel({ cell, roster }: { cell: PublicCard | undefined; roster: HostPlayer[] }) {
  const send = useHost((s) => s.send);
  if (!cell) return <aside className="h-cell muted">Pilih kartu untuk melihat dan mengelolanya.</aside>;
  const owner = roster.find((r) => r.id === cell.ownerId);
  return (
    <aside className="h-cell">
      <h3>
        {cell.cell} · {KOLOM_LABEL[cell.cell[0]!]!.nama}
      </h3>
      <p>
        Status <b>{cell.status}</b>
        {owner && (
          <>
            {" "}
            · milik <b>{owner.name}</b> · nilai {cell.value}
          </>
        )}
      </p>
      {cell.jackpotPct > 0 && <p>Jackpot +{cell.jackpotPct}%</p>}
      <div className="stack">
        <button
          onClick={() => {
            if (window.confirm(`Batalkan klaim ${cell.cell}? Kartu kembali terbuka.`))
              send("host:void", { cell: cell.cell });
          }}
        >
          Batalkan klaim (kartu kembali OPEN)
        </button>
        <button onClick={() => send("host:restore", { cell: cell.cell })}>Kembalikan ke pemilik sebelumnya</button>
      </div>
    </aside>
  );
}

function AdjustModal({ p, onClose }: { p: HostPlayer; onClose: () => void }) {
  const send = useHost((s) => s.send);
  const [delta, setDelta] = useState("-30");
  const [why, setWhy] = useState("");
  const n = Number(delta);
  const valid = Number.isInteger(n) && n !== 0 && Math.abs(n) <= 1000 && why.trim().length > 0;
  return (
    <div className="h-modal-bg" onClick={onClose}>
      <div className="h-modal" onClick={(e) => e.stopPropagation()} role="dialog" aria-label="Ubah poin">
        <h3>Ubah poin · {p.name}</h3>
        <label>
          Perubahan poin (negatif = kurangi)
          <input value={delta} onChange={(e) => setDelta(e.target.value)} inputMode="numeric" />
        </label>
        <label>
          Alasan (wajib, tercatat di log)
          <input value={why} onChange={(e) => setWhy(e.target.value)} placeholder="mis. membantu teman" />
        </label>
        <div className="row">
          <button onClick={onClose}>Batal</button>
          <button
            className="primary"
            disabled={!valid}
            onClick={() => {
              send("host:adjust", { studentId: p.id, delta: n, reason: why.trim() });
              onClose();
            }}
          >
            Simpan
          </button>
        </div>
      </div>
    </div>
  );
}

const SEV: Record<string, { ikon: string; label: string }> = {
  kuning: { ikon: "🟡", label: "Perlu dicek" },
  oranye: { ikon: "🟠", label: "Mencurigakan" },
  merah: { ikon: "🔴", label: "Pelanggaran jelas" },
};
const TYPE_LABEL: Record<string, string> = {
  fokus_hilang: "Meninggalkan layar soal",
  fokus_gagal: "Soal gagal: layar ditinggalkan",
  terlalu_cepat: "Menjawab terlalu cepat",
  relay: "Dugaan bisik jawaban",
  pola_sama: "Pola jawaban salah sama",
  login_ganda: "Login ganda",
  perangkat_bersama: "Perangkat dipakai bersama",
};
const SANKSI = [
  { level: 1, label: "1 · Peringatan pribadi" },
  { level: 2, label: "2 · Batalkan klaim terakhir" },
  { level: 3, label: "3 · −1 tiket & −30 poin" },
  { level: 4, label: "4 · Bekukan 3 menit" },
] as const;

/** Bendera dari sistem adalah sinyal untuk dicek guru, bukan vonis. */
function FlagPanel({ flags }: { flags: FlagItem[] }) {
  const send = useHost((s) => s.send);
  const [pick, setPick] = useState<number | null>(null);
  const list = [...flags].reverse();
  return (
    <div>
      <p className="muted">
        Bendera hanyalah sinyal untuk dicek, bukan vonis. Bicaralah dengan murid sebelum menindak; sanksi dimulai dari
        yang paling ringan.
      </p>
      {list.length === 0 && <p className="muted">Belum ada bendera.</p>}
      <ul className="h-flags">
        {list.map((f) => (
          <li key={f.id} className={`${f.severity} ${f.status}`}>
            <div className="top">
              <span>
                {SEV[f.severity]!.ikon} <b>{f.name || "—"}</b> · {TYPE_LABEL[f.type] ?? f.type}
              </span>
              <time>
                {new Date(f.ts).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", second: "2-digit" })}
              </time>
            </div>
            <p>
              {f.name ? `${f.name} ` : ""}
              {f.text}
            </p>
            {f.status === "open" ? (
              <div className="acts">
                <button className="sm" onClick={() => send("host:flag:resolve", { id: f.id, action: "abaikan" })}>
                  Abaikan
                </button>
                {f.studentId && (
                  <button className="sm danger" onClick={() => setPick(pick === f.id ? null : f.id)}>
                    Tindak…
                  </button>
                )}
              </div>
            ) : (
              <small className="muted">{f.status === "diabaikan" ? "Diabaikan" : "Sudah ditindak"}</small>
            )}
            {pick === f.id && (
              <div className="sanksi">
                {SANKSI.map((s) => (
                  <button
                    key={s.level}
                    className="sm"
                    onClick={() => {
                      send("host:flag:resolve", { id: f.id, action: "tindak", level: s.level });
                      setPick(null);
                    }}
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}

/** PIN kelas yang berganti otomatis; guru membacakan atau menuliskannya untuk murid yang baru bergabung. */
function PinBox({
  pin,
  fallback,
  serverNow,
}: {
  pin: { value: string; expiresAt: number; intervalMs: number } | null;
  fallback: string | undefined;
  serverNow: number;
}) {
  const remain = pin ? Math.max(0, pin.expiresAt - serverNow) : 0;
  const frac = pin ? Math.min(1, remain / pin.intervalMs) : 0;
  return (
    <div className="h-pin" title="PIN yang sama untuk semua murid dan berganti otomatis">
      <span>PIN kelas</span>
      <b>{pin?.value ?? fallback ?? "—"}</b>
      {pin && (
        <>
          <i className="pinbar" aria-hidden>
            <u style={{ width: `${frac * 100}%` }} />
          </i>
          <small>berganti dalam {formatClock(remain)}</small>
        </>
      )}
    </div>
  );
}

/** Token guru untuk membuka konsol dari perangkat lain. */
function TokenChip() {
  const token = useHost((s) => s.token);
  const pinMode = useHost((s) => s.pinMode);
  const [show, setShow] = useState(false);
  if (pinMode) return null; // token = PIN guru dari SIMPETERI; tidak ditampilkan lagi
  return (
    <div className="h-token">
      <button className="sm" onClick={() => setShow((v) => !v)}>
        {show ? "Sembunyikan token" : "Token guru"}
      </button>
      {show && (
        <span>
          <b>{token}</b>
          <small>Ketik di layar "Konsol Guru" bila membuka dari perangkat lain. Dari laptop server tidak perlu.</small>
        </span>
      )}
    </div>
  );
}

import { BASE } from "./base";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Home } from "./Home";
import { Play } from "./play/Play";
import { Projector } from "./projector/Projector";
import { Host, HostSession } from "./host/Host";
import { Pins } from "./host/Pins";
import { VoPage } from "./host/VoPage";
import { Report } from "./report/Report";
import { Station } from "./station/Station";

export function App() {
  return (
    <BrowserRouter basename={BASE}>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/play" element={<Play />} />
        <Route path="/play/:code" element={<Play />} />
        <Route path="/projector" element={<Projector />} />
        <Route path="/projector/:code" element={<Projector />} />
        <Route path="/host" element={<Host />} />
        <Route path="/host/:id" element={<HostSession />} />
        <Route path="/host/:id/pins" element={<Pins />} />
        <Route path="/host/:id/vo" element={<VoPage />} />
        <Route path="/report/:id" element={<Report />} />
        <Route path="/station" element={<Station />} />
        <Route path="/station/:code" element={<Station />} />
      </Routes>
    </BrowserRouter>
  );
}

export interface RadarPoint {
  label: string;
  /** 0–100; null = belum cukup data */
  value: number | null;
}

/** Titik pada radar untuk sumbu ke-i dari n, nilai 0–100 (nilai kosong dianggap 0). Dipisah agar mudah diuji. */
export function radarPoint(
  i: number,
  n: number,
  value: number | null,
  r: number,
  cx: number,
  cy: number,
): [number, number] {
  const a = -Math.PI / 2 + (i / n) * Math.PI * 2;
  const rr = ((value ?? 0) / 100) * r;
  return [cx + Math.cos(a) * rr, cy + Math.sin(a) * rr];
}

/** Grafik radar 7 kategori untuk rapor murid. SVG murni (tanpa pustaka) agar ikut tercetak. */
export function Radar({ values, size = 260 }: { values: RadarPoint[]; size?: number }) {
  const n = values.length;
  const cx = size / 2;
  const cy = size / 2;
  const r = size / 2 - 52;
  const poly = values.map((v, i) => radarPoint(i, n, v.value, r, cx, cy).join(",")).join(" ");
  return (
    <svg
      viewBox={`-70 0 ${size + 140} ${size}`}
      width={size + 140}
      height={size}
      role="img"
      aria-label="Radar kategori kecerdasan"
      className="radar"
    >
      {[25, 50, 75, 100].map((ring) => (
        <polygon
          key={ring}
          points={values.map((_, i) => radarPoint(i, n, ring, r, cx, cy).join(",")).join(" ")}
          fill="none"
          stroke="#dcd2bb"
          strokeWidth={ring === 100 ? 1.6 : 1}
        />
      ))}
      {values.map((v, i) => {
        const [x, y] = radarPoint(i, n, 100, r, cx, cy);
        const [lx, ly] = radarPoint(i, n, 100, r + 26, cx, cy);
        return (
          <g key={v.label}>
            <line x1={cx} y1={cy} x2={x} y2={y} stroke="#dcd2bb" />
            <text
              x={lx}
              y={ly}
              textAnchor={lx < cx - 4 ? "end" : lx > cx + 4 ? "start" : "middle"}
              dominantBaseline="middle"
              fontSize="11"
              fontWeight="700"
              fill="#14213d"
            >
              {v.label}
            </text>
          </g>
        );
      })}
      <polygon points={poly} fill="rgba(255,90,54,0.28)" stroke="#14213d" strokeWidth="2.4" strokeLinejoin="round" />
      {values.map((v, i) => {
        if (v.value === null) return null;
        const [x, y] = radarPoint(i, n, v.value, r, cx, cy);
        return <circle key={v.label} cx={x} cy={y} r="4" fill="#ff5a36" stroke="#14213d" strokeWidth="2" />;
      })}
    </svg>
  );
}

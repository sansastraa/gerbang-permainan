/** Bentuk JSON laporan dari server (`/api/sessions/:id/report.json`), disalin sebagai tipe klien. */
export interface KategoriStat {
  id: string;
  nama: string;
  percobaan: number;
  benar: number;
  akurasi: number | null;
  skor: number | null;
  levelPuncak: number;
}

export interface ReportStudent {
  id: string;
  name: string;
  absen: number | null;
  initials: string;
  score: number;
  rank: number;
  cards: number;
  claims: number;
  bestStreak: number;
  badgeNames: string[];
  xpGain: number | null;
  flags: { kuning: number; oranye: number; merah: number };
  indikator: {
    percobaan: number;
    benar: number;
    akurasi: number | null;
    kategori: KategoriStat[];
    kecepatan: { medianMs: number | null; relatifKelas: number | null };
    keberanian: number | null;
    ketangguhan: number | null;
    eksplorasi: number;
  };
  rapor: { semangat: string; saran: string };
}

export interface ClassReport {
  sessionId: string;
  className: string;
  createdAt: number;
  endedAt: number | null;
  phase: string;
  jumlahMurid: number;
  jumlahPercobaan: number;
  akurasiKelas: number | null;
  siswa: ReportStudent[];
  heatmap: {
    cell: string;
    percobaan: number;
    benar: number;
    p: number | null;
    tanda: "terlalu_sulit" | "terlalu_mudah" | null;
  }[];
  butir: {
    questionId: string;
    cell: string;
    variant: number;
    level: number;
    percobaan: number;
    benar: number;
    p: number | null;
    d: number | null;
    pengecoh: Record<string, number>;
  }[];
  catatan: string;
}

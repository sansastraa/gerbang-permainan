import { appOrigin, appUrl } from "../base";
import { useEffect, useMemo, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useHost } from "../host/hostStore";
import { COL_HUE } from "../theme";
import { Radar } from "./Radar";
import type { ClassReport, ReportStudent } from "./types";
import "../host/host.css";
import "./report.css";

type Tab = "rapor" | "heatmap" | "butir" | "ekspor";

const pct = (v: number | null) => (v === null ? "—" : `${Math.round(v * 100)}%`);

/** Laporan sesi: rapor murid (radar), heatmap kelas 10×8, analisis butir, dan ekspor (SPEC §6.3, §8.5). */
export function Report() {
  const { id = "" } = useParams();
  const token = useHost((s) => s.token);
  const init = useHost((s) => s.initToken);
  const [rep, setRep] = useState<ClassReport | null>(null);
  const [err, setErr] = useState("");
  const [tab, setTab] = useState<Tab>("rapor");
  const [sel, setSel] = useState<string | null>(null);

  useEffect(() => {
    void init();
  }, [init]);
  const load = async () => {
    const r = await fetch(appUrl(`/api/sessions/${id}/report.json`), { headers: { "x-host-token": token } });
    if (r.ok) setRep((await r.json()) as ClassReport);
    else setErr("Tidak bisa memuat laporan.");
  };
  useEffect(() => {
    if (token) void load();
  }, [id, token]); // eslint-disable-line react-hooks/exhaustive-deps

  if (err) return <div className="h-root h-center">{err}</div>;
  if (!rep) return <div className="h-root h-center">Memuat laporan…</div>;
  const current = rep.siswa.find((s) => s.id === sel) ?? rep.siswa[0];

  return (
    <div className="h-root rp">
      <header className="h-top no-print">
        <Link to={`/host/${id}`} className="back" aria-label="Kembali">
          ←
        </Link>
        <div className="brand">
          <span className="t">
            CLAIM <b>80</b>
          </span>
          <small>
            Laporan · Kelas {rep.className} · {rep.phase === "END" ? "selesai" : "sesi berjalan"}
          </small>
        </div>
        <div className="grow" />
        <button onClick={() => void load()}>Muat ulang</button>
      </header>

      <div className="rp-sum no-print">
        <div>
          <b>{rep.jumlahMurid}</b>
          <span>murid</span>
        </div>
        <div>
          <b>{rep.jumlahPercobaan}</b>
          <span>percobaan</span>
        </div>
        <div>
          <b>{pct(rep.akurasiKelas)}</b>
          <span>akurasi kelas</span>
        </div>
        <div>
          <b>{rep.heatmap.filter((h) => h.tanda).length}</b>
          <span>kartu perlu ditinjau</span>
        </div>
      </div>

      <nav className="h-tabs no-print">
        {(
          [
            ["rapor", "Rapor murid"],
            ["heatmap", "Heatmap kelas"],
            ["butir", "Analisis butir"],
            ["ekspor", "Ekspor"],
          ] as [Tab, string][]
        ).map(([k, label]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>
            {label}
          </button>
        ))}
      </nav>

      {tab === "rapor" && current && (
        <section className="rp-grid">
          <aside className="h-card flat no-print rp-list">
            <ul>
              {rep.siswa.map((s) => (
                <li key={s.id}>
                  <button className={s.id === current.id ? "on" : ""} onClick={() => setSel(s.id)}>
                    <span className="rk">{s.rank}</span>
                    <span className="nm">{s.name}</span>
                    <b>{s.score}</b>
                  </button>
                </li>
              ))}
            </ul>
            <button
              className="primary"
              onClick={() => {
                document.body.dataset.print = "all";
                window.print();
              }}
            >
              Cetak rapor semua murid
            </button>
          </aside>
          <div>
            <div className="no-print rp-actions">
              <button
                onClick={() => {
                  document.body.dataset.print = "one";
                  window.print();
                }}
              >
                Cetak rapor ini (A5)
              </button>
            </div>
            <RaporCard s={current} rep={rep} selected />
          </div>
        </section>
      )}

      {tab === "heatmap" && <Heat rep={rep} />}
      {tab === "butir" && <Items rep={rep} />}
      {tab === "ekspor" && <Export id={id} token={token} code={rep.className} />}

      <div className="print-all" aria-hidden>
        {rep.siswa.map((s) => (
          <RaporCard key={s.id} s={s} rep={rep} />
        ))}
      </div>
    </div>
  );
}

function RaporCard({ s, rep, selected = false }: { s: ReportStudent; rep: ClassReport; selected?: boolean }) {
  const ind = s.indikator;
  const puncak = ind.kategori.reduce((m, k) => Math.max(m, k.levelPuncak), 0);
  return (
    <article className={`rk-card${selected ? " sel" : ""}`}>
      <header>
        <div>
          <small>CLAIM 80 · Kelas {rep.className}</small>
          <h2>{s.name}</h2>
        </div>
        <div className="big">
          <b>{s.score}</b>
          <span>poin · peringkat {s.rank}</span>
        </div>
      </header>
      <div className="rk-body">
        <Radar values={ind.kategori.map((k) => ({ label: k.nama, value: k.skor }))} />
        <div className="rk-stats">
          <dl>
            <dt>Kartu dimiliki</dt>
            <dd>{s.cards}</dd>
            <dt>Percobaan</dt>
            <dd>
              {ind.benar}/{ind.percobaan} benar ({pct(ind.akurasi)})
            </dd>
            <dt>Level puncak</dt>
            <dd>{puncak || "—"}</dd>
            <dt>Streak terbaik</dt>
            <dd>{s.bestStreak}</dd>
            <dt>Keberanian (rata-rata level)</dt>
            <dd>{ind.keberanian ?? "—"}</dd>
            <dt>Ketangguhan (bangkit setelah gagal)</dt>
            <dd>{ind.ketangguhan === null ? "—" : pct(ind.ketangguhan)}</dd>
            <dt>Kecepatan (median)</dt>
            <dd>
              {ind.kecepatan.medianMs === null ? "—" : `${(ind.kecepatan.medianMs / 1000).toFixed(1)} dtk`}
              {ind.kecepatan.relatifKelas !== null && <small> ({ind.kecepatan.relatifKelas}× median kelas)</small>}
            </dd>
            <dt>Kategori dicoba</dt>
            <dd>{ind.eksplorasi} dari 7</dd>
          </dl>
        </div>
      </div>
      <table className="rk-kat">
        <thead>
          <tr>
            <th>Kategori</th>
            <th>Percobaan</th>
            <th>Akurasi</th>
            <th>Skor</th>
            <th>Level puncak</th>
          </tr>
        </thead>
        <tbody>
          {ind.kategori.map((k) => (
            <tr key={k.id}>
              <td>{k.nama}</td>
              <td>{k.percobaan}</td>
              <td>{pct(k.akurasi)}</td>
              <td>{k.skor === null ? "—" : k.skor}</td>
              <td>{k.levelPuncak || "—"}</td>
            </tr>
          ))}
        </tbody>
      </table>
      {s.badgeNames.length > 0 && (
        <p className="rk-badges">
          <b>Badge:</b> {s.badgeNames.join(" · ")}
        </p>
      )}
      <p className="rk-say">{s.rapor.semangat}</p>
      <p className="rk-tip">
        <b>Saran latihan:</b> {s.rapor.saran}
      </p>
      <footer>{rep.catatan}</footer>
    </article>
  );
}

function Heat({ rep }: { rep: ClassReport }) {
  const byCell = useMemo(() => new Map(rep.heatmap.map((h) => [h.cell, h])), [rep]);
  const cols = "ABCDEFGHIJ".split("");
  return (
    <section className="h-card flat">
      <p className="muted">
        Persentase jawaban benar tiap kartu. Bingkai merah: terlalu sulit (di bawah 20%). Bingkai kuning: terlalu mudah
        (di atas 90% pada baris 5 ke atas). Keduanya layak ditinjau untuk revisi bank soal. Tanda baru muncul bila ada
        minimal 3 percobaan.
      </p>
      <div className="rp-heat">
        <span />
        {cols.map((c) => (
          <b key={c} className="hh" style={{ borderColor: COL_HUE[c] }}>
            {c}
          </b>
        ))}
        {[1, 2, 3, 4, 5, 6, 7, 8].map((r) => (
          <HeatRow key={r} r={r} cols={cols} byCell={byCell} />
        ))}
      </div>
    </section>
  );
}

function HeatRow({
  r,
  cols,
  byCell,
}: {
  r: number;
  cols: string[];
  byCell: Map<string, ClassReport["heatmap"][number]>;
}) {
  return (
    <>
      <b className="hr">{r}</b>
      {cols.map((c) => {
        const h = byCell.get(`${c}${r}`)!;
        const p = h.p;
        return (
          <div
            key={c}
            className={`hc2 ${h.tanda ?? ""}`}
            style={{
              background: p === null ? "#f3ead7" : `color-mix(in srgb, #17a870 ${Math.round(p * 100)}%, #fffdf7)`,
            }}
            title={`${c}${r}: ${h.benar}/${h.percobaan} benar`}
          >
            <b>{p === null ? "·" : Math.round(p * 100)}</b>
            <small>{h.percobaan}×</small>
          </div>
        );
      })}
    </>
  );
}

function Items({ rep }: { rep: ClassReport }) {
  return (
    <section className="h-card flat">
      <p className="muted">
        p = tingkat kesukaran (makin kecil makin sulit). D = daya beda: selisih p kelompok 27% teratas dan 27% terbawah;
        D di bawah 0,2 berarti butir kurang membedakan murid kuat dan lemah.
      </p>
      <div className="h-tablewrap">
        <table className="h-table">
          <thead>
            <tr>
              <th>Soal</th>
              <th className="num">Level</th>
              <th className="num">Percobaan</th>
              <th className="num">p</th>
              <th className="num">D</th>
              <th>Jawaban pengecoh</th>
            </tr>
          </thead>
          <tbody>
            {rep.butir.map((b) => (
              <tr key={b.questionId} className={b.d !== null && b.d < 0.2 && b.percobaan >= 5 ? "weak" : ""}>
                <td>{b.questionId}</td>
                <td className="num">{b.level}</td>
                <td className="num">{b.percobaan}</td>
                <td className="num">{b.p}</td>
                <td className="num">{b.d ?? "—"}</td>
                <td className="small">
                  {Object.entries(b.pengecoh)
                    .sort((a, c) => c[1] - a[1])
                    .map(([k, v]) => `${k} (${v})`)
                    .join(" · ") || "—"}
                </td>
              </tr>
            ))}
            {rep.butir.length === 0 && (
              <tr>
                <td colSpan={6} className="muted">
                  Belum ada percobaan.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}

function Export({ id, token, code }: { id: string; token: string; code: string }) {
  const [msg, setMsg] = useState("");
  const get = async (file: string, label: string) => {
    const r = await fetch(appUrl(`/api/sessions/${id}/${file}`), { headers: { "x-host-token": token } });
    if (!r.ok) return setMsg(`Gagal mengunduh ${label}.`);
    const url = URL.createObjectURL(await r.blob());
    const a = document.createElement("a");
    a.href = url;
    a.download = `claim80-${code}-${file}`;
    a.click();
    URL.revokeObjectURL(url);
    setMsg(`${label} diunduh.`);
  };
  const files: [string, string, string][] = [
    [
      "students.csv",
      "Ringkasan murid (CSV)",
      "Satu baris per murid: skor, akurasi, skor per kategori, badge, bendera.",
    ],
    ["attempts.csv", "Percobaan mentah (CSV)", "Satu baris per percobaan: sel, varian, kategori, level, benar, waktu."],
    ["items.csv", "Analisis butir (CSV)", "p, daya beda D, dan sebaran pengecoh per soal."],
    ["report.json", "Laporan lengkap (JSON)", "Seluruh data laporan, termasuk heatmap dan rapor."],
    [
      "summary.json",
      "Ringkasan untuk SIMPETERI (JSON)",
      "Dipakai menu Buat Multi Permainan: studentId, nama, poin, dan profil kecerdasan.",
    ],
  ];
  return (
    <section className="h-card flat">
      <ul className="ex-list">
        {files.map(([f, label, info]) => (
          <li key={f}>
            <div>
              <b>{label}</b>
              <small>{info}</small>
            </div>
            <button onClick={() => void get(f, label)}>Unduh</button>
          </li>
        ))}
      </ul>
      <p className="muted">
        Alamat ringkasan untuk SIMPETERI (tersedia setelah permainan selesai):
        <br />
        <code>
          {appOrigin()}/api/sessions/{id}/summary.json
        </code>
      </p>
      {msg && <p>{msg}</p>}
    </section>
  );
}

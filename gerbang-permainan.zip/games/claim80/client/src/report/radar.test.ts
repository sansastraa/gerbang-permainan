import { describe, expect, it } from "vitest";
import { radarPoint } from "./Radar";

describe("radarPoint", () => {
  it("sumbu pertama menghadap ke atas, nilai 100 di tepi dan 0 di pusat", () => {
    const [x, y] = radarPoint(0, 7, 100, 100, 150, 150);
    expect(x).toBeCloseTo(150, 5);
    expect(y).toBeCloseTo(50, 5);
    const [cx, cy] = radarPoint(3, 7, 0, 100, 150, 150);
    expect([cx, cy]).toEqual([150, 150]);
    const [nx, ny] = radarPoint(3, 7, null, 100, 150, 150);
    expect([nx, ny]).toEqual([150, 150]);
  });
  it("nilai 50 berada di setengah jari-jari dan sumbu berputar searah jarum jam", () => {
    const [x1, y1] = radarPoint(1, 4, 50, 100, 0, 0);
    expect(x1).toBeCloseTo(50, 5); // sumbu ke-2 dari 4 menghadap ke kanan
    expect(y1).toBeCloseTo(0, 5);
    const [x2, y2] = radarPoint(2, 4, 100, 100, 0, 0);
    expect(x2).toBeCloseTo(0, 5);
    expect(y2).toBeCloseTo(100, 5); // ke bawah
  });
});

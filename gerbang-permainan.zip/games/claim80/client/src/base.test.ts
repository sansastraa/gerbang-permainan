import { describe, expect, it } from "vitest";
import { baseFrom, withBase } from "./base";

describe("penyusun URL berawalan", () => {
  it("baseFrom menormalkan base Vite", () => {
    expect(baseFrom(undefined)).toBe("");
    expect(baseFrom("/")).toBe("");
    expect(baseFrom("/games/claim80/")).toBe("/games/claim80");
    expect(baseFrom("/games/claim80")).toBe("/games/claim80");
  });
  it("withBase menambah awalan ke jalur internal", () => {
    expect(withBase("", "/api/lan")).toBe("/api/lan");
    expect(withBase("/games/claim80", "/api/sessions")).toBe("/games/claim80/api/sessions");
    expect(withBase("/games/claim80", "/socket.io")).toBe("/games/claim80/socket.io");
    expect(withBase("/games/claim80", "projector/ABC")).toBe("/games/claim80/projector/ABC");
  });
});

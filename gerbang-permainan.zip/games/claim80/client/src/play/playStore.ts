import { SOCKET_PATH, appUrl } from "../base";
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { create } from "zustand";
import type {
  Award,
  AnswerResult,
  StationState,
  BadgeInfo,
  ClientRules,
  JoinResult,
  LeaderEntry,
  MeState,
  Phase,
  PowerUp,
  PublicCard,
  QuestionDeliver,
  Snapshot,
} from "@claim80/shared";
import { sfx } from "../audio/synth";

export interface JoinInfo {
  sessionId: string;
  className: string;
  phase: Phase;
  students: { id: string; name: string; absen: number | null }[];
}

export type Stage = "code" | "pick" | "pin" | "waiting" | "game" | "fatal";

export interface Toast {
  id: number;
  level: "good" | "warn" | "info";
  text: string;
}

export interface PlayState {
  stage: Stage;
  code: string;
  info: JoinInfo | null;
  studentId: string | null;
  error: string;
  fatal: string;
  waitingText: string;
  board: Record<string, PublicCard>;
  leaderboard: LeaderEntry[];
  me: MeState | null;
  rules: ClientRules | null;
  phase: Phase;
  startedAt: number;
  pausedAt: number | null;
  durationMs: number;
  mission: { claimed: number; target: number; done: boolean };
  badgeDefs: BadgeInfo[];
  awards: Award[];
  /** selisih jam server - klien (ms) */
  offset: number;
  question: QuestionDeliver | null;
  result: AnswerResult | null;
  toasts: Toast[];
  className: string;
  /** Mode Stasiun: nomor tablet ini, daftar antrean/stasiun, dan murid yang sedang dipanggil */
  stationNo: number;
  station: StationState | null;
  stationError: string;

  connectStation: (code: string, token: string) => void;
  stationCall: (studentId?: string) => void;
  stationRelease: () => void;
  stationEnqueue: (studentId: string) => void;
  stationDequeue: (studentId: string) => void;
  lookup: (code: string) => Promise<boolean>;
  choose: (id: string) => void;
  submitPin: (pin: string) => Promise<void>;
  openCard: (cell: string) => void;
  stealCard: (cell: string) => void;
  answer: (a: { optId?: string; value?: string }) => void;
  usePowerUp: (type: PowerUp, cell?: string) => void;
  focusLost: () => void;
  dismissResult: () => void;
  pushToast: (level: Toast["level"], text: string) => void;
  reset: () => void;
}

let socket: Socket | null = null;
let toastSeq = 0;

const store = (k: string): string | null => {
  try {
    return localStorage.getItem(k);
  } catch {
    return null;
  }
};
const save = (k: string, v: string) => {
  try {
    localStorage.setItem(k, v);
  } catch {
    /* abaikan */
  }
};

export function deviceId(): string {
  let d = store("claim80.device");
  if (!d) {
    d = crypto.randomUUID?.() ?? `dev-${Math.random().toString(36).slice(2)}${Date.now().toString(36)}`;
    save("claim80.device", d);
  }
  return d;
}

const initial = {
  stage: "code" as Stage,
  code: "",
  info: null,
  studentId: null,
  error: "",
  fatal: "",
  waitingText: "",
  board: {},
  leaderboard: [],
  me: null,
  rules: null,
  phase: "LOBBY" as Phase,
  startedAt: 0,
  pausedAt: null,
  durationMs: 0,
  mission: { claimed: 0, target: 70, done: false },
  badgeDefs: [] as BadgeInfo[],
  awards: [] as Award[],
  offset: 0,
  question: null,
  result: null,
  toasts: [] as Toast[],
  className: "",
};

let pinCache = "";

export const usePlay = create<PlayState>((set, get) => {
  const applySnapshot = (s: Snapshot) => {
    const board: Record<string, PublicCard> = {};
    for (const c of s.board) board[c.cell] = c;
    set({
      board,
      leaderboard: s.leaderboard,
      me: s.me ?? get().me,
      rules: s.rules,
      phase: s.phase,
      startedAt: s.startedAt,
      pausedAt: s.pausedAt,
      durationMs: s.durationMs,
      mission: s.mission,
      badgeDefs: s.badgeDefs,
      awards: s.awards ?? get().awards,
      offset: s.serverNow - Date.now(),
      question: s.question ?? null,
      className: s.className,
      stage: s.me ? "game" : get().stage,
    });
  };

  const connect = (code: string, extra: Record<string, unknown> = {}) => {
    socket?.close();
    const s = io({
      path: SOCKET_PATH,
      auth: { role: "player", sessionCode: code, ...extra },
      transports: ["websocket", "polling"],
      reconnectionDelayMax: 2000,
    });
    socket = s;
    let first = true;
    s.on("connect", () => {
      if (!first && get().studentId && pinCache) {
        // sambungan pulih: masuk lagi otomatis lalu minta snapshot
        s.emit("join", { sessionCode: code, studentId: get().studentId, pin: pinCache, deviceId: deviceId() });
      }
      first = false;
    });
    s.on("state:snapshot", applySnapshot);
    s.on(
      "board:diff",
      (d: {
        cells: PublicCard[];
        phase: Phase;
        startedAt: number;
        pausedAt: number | null;
        serverNow: number;
        mission: PlayState["mission"];
      }) => {
        const board = { ...get().board };
        for (const c of d.cells) board[c.cell] = c;
        set({
          board,
          phase: d.phase,
          startedAt: d.startedAt,
          pausedAt: d.pausedAt,
          mission: d.mission,
          offset: d.serverNow - Date.now(),
        });
      },
    );
    s.on("leaderboard:update", (l: LeaderEntry[]) => set({ leaderboard: l }));
    s.on("player:update", (m: MeState) => set({ me: m }));
    s.on("awards", (a: Award[]) => set({ awards: a }));
    s.on("question:deliver", (q: QuestionDeliver) => {
      set({ question: q, result: null, offset: q.serverNow - Date.now() });
      if (q.mode === "steal") sfx.steal();
    });
    s.on("question:update", (q: QuestionDeliver) => set({ question: q, offset: q.serverNow - Date.now() }));
    s.on("answer:result", (r: AnswerResult) => {
      set({ question: null, result: r });
      if (r.correct) {
        sfx.correct();
        navigator.vibrate?.(60);
      } else sfx.wrong();
    });
    s.on("action:rejected", (m: { message: string }) => get().pushToast("warn", m.message));
    s.on("toast", (t: { level: Toast["level"]; text: string }) => {
      get().pushToast(t.level, t.text);
      if (t.level === "warn") sfx.warn();
    });
    s.on("joined", () => s.emit("state:request"));
    s.on("fatal", (m: { message: string }) => set({ stage: "fatal", fatal: m.message }));
    s.on("station:info", (m: { no: number; className: string }) =>
      set({ stationNo: m.no, className: m.className, stage: "game" }),
    );
    s.on("station:state", (st: StationState) => set({ station: st }));
    s.on("station:error", (m: { message: string }) => set({ stationError: m.message }));
    s.on("station:assigned", (m: { studentId: string }) =>
      set({ studentId: m.studentId, stationError: "", result: null, question: null }),
    );
    s.on("station:released", () => set({ studentId: null, me: null, question: null, result: null }));
  };

  return {
    ...initial,
    stationNo: 0,
    station: null,
    stationError: "",

    connectStation(code, token) {
      set({ code, error: "", fatal: "" });
      connect(code, { role: "station", hostToken: token });
    },
    stationCall: (id) => socket?.emit("station:call", id ? { studentId: id } : {}),
    stationRelease: () => socket?.emit("station:release"),
    stationEnqueue: (id) => socket?.emit("station:enqueue", { studentId: id }),
    stationDequeue: (id) => socket?.emit("station:dequeue", { studentId: id }),

    async lookup(code) {
      const c = code.trim().toUpperCase();
      set({ error: "" });
      try {
        const r = await fetch(appUrl(`/api/join/${encodeURIComponent(c)}`));
        if (!r.ok) {
          set({ error: "Kode sesi tidak ditemukan. Cek lagi ya." });
          return false;
        }
        const info = (await r.json()) as JoinInfo;
        set({ code: c, info, className: info.className, stage: "pick" });
        connect(c);
        return true;
      } catch {
        set({ error: "Tidak bisa terhubung ke server. Pastikan Wi-Fi-nya sama dengan laptop guru." });
        return false;
      }
    },

    choose(id) {
      set({ studentId: id, stage: "pin", error: "" });
    },

    submitPin(pin) {
      return new Promise<void>((resolve) => {
        const { studentId, code } = get();
        if (!socket || !studentId) return resolve();
        socket.emit("join", { sessionCode: code, studentId, pin, deviceId: deviceId() }, (r: JoinResult) => {
          if (!r.ok) {
            set({
              error:
                r.error === "bad_pin"
                  ? "PIN salah. Cek Kartu PIN-mu."
                  : r.error === "no_student"
                    ? "Nama tidak ditemukan."
                    : "Tidak bisa masuk.",
            });
          } else {
            pinCache = pin;
            save("claim80.last", JSON.stringify({ code, studentId }));
            set({
              error: "",
              stage: r.status === "approved" ? "game" : "waiting",
              waitingText: "Menunggu persetujuan guru…",
            });
          }
          resolve();
        });
      });
    },

    openCard: (cell) => socket?.emit("card:open", { cell }),
    stealCard: (cell) => socket?.emit("card:steal", { cell }),
    answer(a) {
      const q = get().question;
      if (!q) return;
      socket?.emit("answer:submit", { deliveryId: q.deliveryId, nonce: q.nonce, ...a });
    },
    usePowerUp: (type, cell) => socket?.emit("powerup:use", { type, ...(cell ? { cell } : {}) }),
    focusLost() {
      const q = get().question;
      if (q) socket?.emit("focus:lost", { deliveryId: q.deliveryId });
    },
    dismissResult: () => set({ result: null }),
    pushToast(level, text) {
      const id = ++toastSeq;
      set({ toasts: [...get().toasts.slice(-2), { id, level, text }] });
      setTimeout(() => set({ toasts: get().toasts.filter((t) => t.id !== id) }), 3200);
    },
    reset() {
      socket?.close();
      socket = null;
      pinCache = "";
      set({ ...initial, toasts: [] });
    },
  };
});

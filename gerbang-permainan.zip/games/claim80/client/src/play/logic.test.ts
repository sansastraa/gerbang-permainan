import { describe, expect, it } from "vitest";
import type { ClientRules, MeState, PublicCard } from "@claim80/shared";
import { noteFreq } from "../audio/synth";
import { actionFor, formatClock, minRowFor, pressKey, remainingMs } from "./logic";
import type { BoardContext } from "./logic";

const rules: ClientRules = {
  pajak: [
    { min_kartu: 5, baris_minimal: 4 },
    { min_kartu: 8, baris_minimal: 6 },
  ],
  zona: { baris: [1, 2], maks: 1, sampaiMenit: 10 },
  poin: { 1: 10 },
  waktuDetik: { 1: 18 },
  pengaliKolom: { H: 1.5 },
  audioMaks: 3,
  fokusToleransiMs: 1500,
  rebutFase: ["BATTLE", "RUSH"],
};
const me = (o: Partial<MeState> = {}): MeState => ({
  id: "me",
  name: "Aku",
  initials: "AK",
  color: "red",
  score: 0,
  cards: 0,
  streak: 0,
  bestStreak: 0,
  tickets: 2,
  powerUps: [],
  saver: false,
  goldenKey: false,
  cooldownUntil: 0,
  frozen: false,
  rank: 1,
  badges: [],
  ...o,
});
const card = (o: Partial<PublicCard> = {}): PublicCard => ({
  cell: "C3",
  status: "OPEN",
  ownerId: null,
  initials: null,
  color: null,
  value: 0,
  jackpotPct: 0,
  shielded: false,
  immune: false,
  cooldownUntil: 0,
  tryingId: null,
  tryingInitials: null,
  golden: false,
  ...o,
});
const ctx = (o: Partial<BoardContext> = {}): BoardContext => ({
  rules,
  me: me(),
  phase: "OPEN",
  elapsedMin: 1,
  now: 1000,
  hasQuestion: false,
  ...o,
});

describe("petunjuk papan", () => {
  it("Pajak Juara menaikkan baris minimal", () => {
    expect(minRowFor(rules, 4)).toBe(1);
    expect(minRowFor(rules, 5)).toBe(4);
    expect(minRowFor(rules, 9)).toBe(6);
    const a = actionFor(card({ cell: "C3" }), ctx({ me: me({ cards: 5 }) }));
    expect(a.action).toBe("none");
    expect(a.blocked?.reason).toBe("pajak");
  });
  it("Zona Pemula memblokir baris 1–2 bagi pemilik > 1 kartu sebelum menit 10", () => {
    const c = card({ cell: "C1" });
    expect(actionFor(c, ctx({ me: me({ cards: 2 }) })).blocked?.reason).toBe("zona");
    expect(actionFor(c, ctx({ me: me({ cards: 2 }), elapsedMin: 11 })).action).toBe("claim");
  });
  it("cooldown, beku, dan soal aktif memblokir", () => {
    expect(actionFor(card(), ctx({ me: me({ cooldownUntil: 5000 }) })).blocked?.reason).toBe("cooldown");
    expect(actionFor(card(), ctx({ me: me({ frozen: true }) })).blocked?.reason).toBe("frozen");
    expect(actionFor(card(), ctx({ hasQuestion: true })).blocked?.reason).toBe("busy");
    expect(actionFor(card(), ctx({ phase: "LOBBY" })).blocked?.reason).toBe("phase");
  });
  it("rebut hanya di fase BATTLE/RUSH, punya tiket, kartu orang lain tanpa perlindungan", () => {
    const c = card({ status: "CLAIMED", ownerId: "other", initials: "BU" });
    expect(actionFor(c, ctx({ phase: "OPEN" })).action).toBe("none");
    expect(actionFor(c, ctx({ phase: "BATTLE" })).action).toBe("steal");
    expect(actionFor(c, ctx({ phase: "BATTLE", me: me({ tickets: 0 }) })).action).toBe("none");
    expect(actionFor({ ...c, shielded: true }, ctx({ phase: "BATTLE" })).action).toBe("none");
    expect(actionFor({ ...c, ownerId: "me" }, ctx({ phase: "BATTLE" })).action).toBe("none");
  });
});

describe("utilitas", () => {
  it("keypad angka", () => {
    expect(pressKey("", "5")).toBe("5");
    expect(pressKey("5", ",")).toBe("5,");
    expect(pressKey("5,", ",")).toBe("5,");
    expect(pressKey("", ",")).toBe("0,");
    expect(pressKey("12", "-")).toBe("-12");
    expect(pressKey("-12", "-")).toBe("12");
    expect(pressKey("123", "⌫")).toBe("12");
    expect(pressKey("1".repeat(14), "2")).toHaveLength(14);
  });
  it("jam dan sisa waktu memakai selisih jam server", () => {
    expect(formatClock(65_000)).toBe("01:05");
    expect(formatClock(-5)).toBe("00:00");
    expect(remainingMs(10_000, 4_000, 2_000)).toBe(4_000);
    expect(remainingMs(10_000, 20_000, 0)).toBe(0);
  });
  it("frekuensi nada", () => {
    expect(noteFreq("A4")).toBeCloseTo(440, 5);
    expect(noteFreq("C4")).toBeCloseTo(261.63, 1);
    expect(noteFreq("C5")).toBeCloseTo(523.25, 1);
    expect(() => noteFreq("H9")).toThrow();
  });
});

import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { KOLOM_LABEL } from "@claim80/shared";
import type { PublicCard, QuestionDeliver } from "@claim80/shared";
import { COL_HUE } from "../theme";
import { streakTier } from "../projector/rankMarks";
import { isMuted, playNotes, setMuted, sfx, unlockAudio } from "../audio/synth";
import { COLS, POWERUP_INFO, ROWS, actionFor, formatClock, pressKey, remainingMs } from "./logic";
import type { BoardContext } from "./logic";
import { Confetti } from "../Confetti";
import { usePlay } from "./playStore";
import "./play.css";

/** Jam yang berdetak setiap `ms` untuk hitung mundur. */
function useNow(ms = 250): number {
  const [n, setN] = useState(() => Date.now());
  useEffect(() => {
    const t = setInterval(() => setN(Date.now()), ms);
    return () => clearInterval(t);
  }, [ms]);
  return n;
}

export function Play() {
  const { code: urlCode } = useParams();
  const stage = usePlay((s) => s.stage);
  const lookup = usePlay((s) => s.lookup);
  useEffect(() => {
    const c = urlCode ?? new URLSearchParams(location.search).get("code");
    if (c && usePlay.getState().stage === "code") void lookup(c);
  }, [urlCode, lookup]);
  return (
    <div className="p-root">
      {stage === "code" && <CodeStage />}
      {stage === "pick" && <PickStage />}
      {stage === "pin" && <PinStage />}
      {stage === "waiting" && <WaitingStage />}
      {stage === "game" && <GameStage />}
      {stage === "fatal" && <FatalStage />}
      <Toasts />
    </div>
  );
}

function Brand() {
  return (
    <div className="p-brand">
      CLAIM <b>80</b>
    </div>
  );
}

function CodeStage() {
  const [code, setCode] = useState("");
  const error = usePlay((s) => s.error);
  const lookup = usePlay((s) => s.lookup);
  return (
    <main className="p-center">
      <Brand />
      <p className="p-muted">Masukkan kode sesi dari layar guru.</p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          unlockAudio();
          void lookup(code);
        }}
      >
        <input
          className="p-input p-code"
          value={code}
          onChange={(e) => setCode(e.target.value.toUpperCase().slice(0, 8))}
          placeholder="KODE"
          autoCapitalize="characters"
          autoComplete="off"
          aria-label="Kode sesi"
        />
        <button className="p-btn p-primary" disabled={code.length < 4}>
          Lanjut
        </button>
      </form>
      {error && <p className="p-error">{error}</p>}
    </main>
  );
}

function PickStage() {
  const info = usePlay((s) => s.info)!;
  const choose = usePlay((s) => s.choose);
  const [q, setQ] = useState("");
  const list = useMemo(
    () => info.students.filter((s) => s.name.toLowerCase().includes(q.trim().toLowerCase())),
    [info.students, q],
  );
  return (
    <main className="p-pick">
      <Brand />
      <h1 className="p-h">Kelas {info.className}</h1>
      <p className="p-muted">Ketuk namamu.</p>
      <input
        className="p-input"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Cari nama…"
        aria-label="Cari nama"
      />
      <ul className="p-names">
        {list.map((s) => (
          <li key={s.id}>
            <button className="p-name" onClick={() => choose(s.id)}>
              <span className="p-absen">{s.absen ?? "·"}</span>
              {s.name}
            </button>
          </li>
        ))}
        {list.length === 0 && <li className="p-muted">Tidak ada nama yang cocok.</li>}
      </ul>
    </main>
  );
}

function PinStage() {
  const info = usePlay((s) => s.info)!;
  const sid = usePlay((s) => s.studentId)!;
  const submit = usePlay((s) => s.submitPin);
  const error = usePlay((s) => s.error);
  const [pin, setPin] = useState("");
  const [agree, setAgree] = useState(false);
  const [busy, setBusy] = useState(false);
  const student = info.students.find((s) => s.id === sid);
  const press = (k: string) => {
    sfx.tap();
    if (k === "⌫") setPin((p) => p.slice(0, -1));
    else setPin((p) => (p.length < 4 ? p + k : p));
  };
  const go = async () => {
    unlockAudio();
    document.documentElement.requestFullscreen?.().catch(() => undefined);
    setBusy(true);
    await submit(pin);
    setBusy(false);
    setPin("");
  };
  return (
    <main className="p-center">
      <Brand />
      <h1 className="p-h">Halo, {student?.name.split(" ")[0]}!</h1>
      <p className="p-muted">Masukkan PIN 4 digit dari Kartu PIN-mu.</p>
      <div className="p-dots" aria-label="PIN">
        {[0, 1, 2, 3].map((i) => (
          <span key={i} className={i < pin.length ? "on" : ""} />
        ))}
      </div>
      <div className="p-pad">
        {["1", "2", "3", "4", "5", "6", "7", "8", "9", "", "0", "⌫"].map((k, i) =>
          k ? (
            <button key={i} className="p-key" onClick={() => press(k)} aria-label={k === "⌫" ? "Hapus" : k}>
              {k}
            </button>
          ) : (
            <span key={i} />
          ),
        )}
      </div>
      <label className="p-honor">
        <input type="checkbox" checked={agree} onChange={(e) => setAgree(e.target.checked)} />
        <span>
          Aku setuju <b>Kode Kehormatan</b>: <i>Strategi boleh licik, cara harus jujur.</i>
        </span>
      </label>
      <button className="p-btn p-primary" disabled={pin.length !== 4 || !agree || busy} onClick={go}>
        Masuk
      </button>
      {error && <p className="p-error">{error}</p>}
      <button className="p-link" onClick={() => usePlay.setState({ stage: "pick", error: "" })}>
        Bukan kamu? Ganti nama
      </button>
    </main>
  );
}

function WaitingStage() {
  const text = usePlay((s) => s.waitingText);
  return (
    <main className="p-center">
      <Brand />
      <div className="p-pulse" />
      <p className="p-h2">{text}</p>
      <p className="p-muted">Tetap di halaman ini ya.</p>
    </main>
  );
}

function FatalStage() {
  const fatal = usePlay((s) => s.fatal);
  const reset = usePlay((s) => s.reset);
  return (
    <main className="p-center">
      <Brand />
      <p className="p-h2">{fatal}</p>
      <button className="p-btn p-primary" onClick={reset}>
        Mulai lagi
      </button>
    </main>
  );
}

function Toasts() {
  const toasts = usePlay((s) => s.toasts);
  return (
    <div className="p-toasts" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={`p-toast ${t.level}`}>
          {t.text}
        </div>
      ))}
    </div>
  );
}

// ---------------------------------------------------------------------------------------------

const LEVEL_NAMA = ["Sangat Mudah", "Mudah", "Sedang", "Menengah", "Sulit", "Sangat Sulit", "Expert", "EXTREME"];

export function GameStage() {
  const s = usePlay();
  const now = useNow();
  const [sheet, setSheet] = useState<string | null>(null);
  const [badgeOpen, setBadgeOpen] = useState(false);
  const me = s.me;
  const rules = s.rules;
  if (!me || !rules) return <WaitingStage />;
  const serverNow = now + s.offset;
  const elapsedMs = s.phase === "LOBBY" ? -1 : (s.pausedAt ?? serverNow) - s.startedAt;
  const ctx: BoardContext = {
    rules,
    me,
    phase: s.phase,
    elapsedMin: elapsedMs / 60000,
    now: serverNow,
    hasQuestion: !!s.question,
  };
  const remain = Math.max(0, s.durationMs - elapsedMs);
  const sheetCard = sheet ? s.board[sheet] : undefined;
  const ended = s.phase === "END";

  return (
    <div className="p-game">
      <TopBar onBadges={() => setBadgeOpen(true)} />
      <div className="p-strip">
        <span className={`p-phase ph-${s.phase}`}>{s.phase === "LOBBY" ? "Menunggu mulai" : s.phase}</span>
        {s.phase !== "LOBBY" && !ended && <span className="p-clock">{formatClock(remain)}</span>}
        {s.pausedAt !== null && <span className="p-paused">Dijeda guru</span>}
        <span className="p-mission" title="Misi kelas: klaim 70 kartu bersama-sama">
          <i style={{ width: `${Math.min(100, (s.mission.claimed / s.mission.target) * 100)}%` }} />
          <em>
            Misi kelas {s.mission.claimed}/{s.mission.target}
          </em>
        </span>
      </div>
      <PowerTray />
      {ended ? <EndScreen /> : <DeckBoard ctx={ctx} onPick={(cell) => setSheet(cell)} />}
      {sheetCard && <CellSheet card={sheetCard} ctx={ctx} onClose={() => setSheet(null)} />}
      {badgeOpen && <BadgeSheet onClose={() => setBadgeOpen(false)} />}
      {s.question && <QuestionView q={s.question} />}
      {s.result && !s.question && <ResultOverlay />}
    </div>
  );
}

function TopBar({ onBadges }: { onBadges: () => void }) {
  const me = usePlay((s) => s.me)!;
  const tier = streakTier(me.streak);
  const [muted, setM] = useState(isMuted());
  return (
    <header className="p-top">
      <span className="p-avatar" style={{ background: me.color }} aria-hidden>
        {me.initials}
      </span>
      <div className="p-who">
        <b>{me.name.split(" ").slice(0, 2).join(" ")}</b>
        <small>
          Peringkat {me.rank} · {me.cards} kartu
        </small>
      </div>
      <div className="p-score" aria-label="Skor">
        {me.score}
      </div>
      <div className="p-pills">
        <span title="Streak jawaban benar beruntun" className={tier === "none" ? "pill off" : `pill stk ${tier}`}>
          {tier === "legend" ? "MAHKOTA" : "STREAK"} {me.streak}
        </span>
        <span className="pill" title="Tiket rebut">
          Rebut {me.tickets}
        </span>
        <button className="pill btn" onClick={onBadges} aria-label="Badge">
          Badge {me.badges.length}
        </button>
        <button
          className="pill btn"
          aria-label={muted ? "Nyalakan suara" : "Matikan suara"}
          onClick={() => {
            unlockAudio();
            setMuted(!muted);
            setM(!muted);
          }}
        >
          {muted ? "Suara mati" : "Suara"}
        </button>
      </div>
    </header>
  );
}

function PowerTray() {
  const me = usePlay((s) => s.me)!;
  const q = usePlay((s) => s.question);
  const use = usePlay((s) => s.usePowerUp);
  if (me.powerUps.length === 0 && !me.saver && !me.goldenKey) return null;
  return (
    <div className="p-tray" aria-label="Power-up">
      {me.powerUps.map((pu, i) => {
        const info = POWERUP_INFO[pu]!;
        const needsCard = pu === "perisai" || pu === "mata_elang";
        const onlyQuestion = pu === "50_50" || pu === "plus15";
        const disabled = (onlyQuestion && !q) || needsCard;
        return (
          <button
            key={`${pu}${i}`}
            className="p-chip"
            disabled={disabled}
            title={needsCard ? `${info.info} (ketuk kartunya)` : info.info}
            onClick={() => use(pu)}
          >
            <span>{info.ikon}</span>
            {info.nama}
          </button>
        );
      })}
      {me.saver && <span className="p-chip on">Streak Saver aktif</span>}
      {me.goldenKey && <span className="p-chip on">Kunci Emas ×2 aktif</span>}
    </div>
  );
}

/** Pilih dek (kolom) lalu pilih kartu besar — pengganti papan 10×8 yang mungil. */
function DeckBoard({ ctx, onPick }: { ctx: BoardContext; onPick: (cell: string) => void }) {
  const board = usePlay((s) => s.board);
  const [deck, setDeck] = useState<string>("A");
  const now = ctx.now;
  return (
    <section className="p-deckwrap" aria-label="Papan kartu">
      <div className="p-rail" role="tablist" aria-label="Pilih dek">
        {COLS.map((c) => {
          const cards = ROWS.map((r) => board[`${c}${r}`]).filter((x): x is PublicCard => !!x);
          const open = cards.filter((x) => x.status === "OPEN").length;
          return (
            <button
              key={c}
              role="tab"
              aria-selected={deck === c}
              className={`p-deck${deck === c ? " on" : ""}`}
              style={{ ["--hue" as string]: COL_HUE[c] }}
              onClick={() => {
                sfx.tap();
                setDeck(c);
              }}
              title={KOLOM_LABEL[c]!.nama}
            >
              <span className="ico">{KOLOM_LABEL[c]!.ikon}</span>
              <b>{c}</b>
              <span className="pips" aria-hidden>
                {cards.map((x) => (
                  <i
                    key={x.cell}
                    className={
                      x.status === "CLAIMED" || x.status === "CONTESTED"
                        ? x.ownerId === ctx.me.id
                          ? "mine"
                          : "taken"
                        : ""
                    }
                    style={
                      x.color && (x.status === "CLAIMED" || x.status === "CONTESTED")
                        ? { background: x.color }
                        : undefined
                    }
                  />
                ))}
              </span>
              <small>{open} terbuka</small>
            </button>
          );
        })}
      </div>
      <div className="p-decktitle" style={{ ["--hue" as string]: COL_HUE[deck] }}>
        <span className="ico">{KOLOM_LABEL[deck]!.ikon}</span>
        <div>
          <b>Dek {deck}</b>
          <small>{deck === "H" ? "Mystery: tema tersembunyi, poin ×1,5" : KOLOM_LABEL[deck]!.nama}</small>
        </div>
      </div>
      <div className="p-cards">
        {ROWS.map((r) => {
          const card = board[`${deck}${r}`];
          return card ? <BigCard key={card.cell} card={card} ctx={ctx} now={now} onPick={onPick} /> : null;
        })}
      </div>
    </section>
  );
}

function BigCard({
  card,
  ctx,
  now,
  onPick,
}: {
  card: PublicCard;
  ctx: BoardContext;
  now: number;
  onPick: (c: string) => void;
}) {
  const row = Number(card.cell.slice(1));
  const col = card.cell[0]!;
  const mine = card.ownerId === ctx.me.id;
  const { action, blocked } = actionFor(card, ctx);
  const poin = ctx.rules.poin[row];
  const claimed = card.status === "CLAIMED" || card.status === "CONTESTED";
  const style: React.CSSProperties & Record<string, string> = { "--hue": COL_HUE[col]! };
  if (claimed && card.color) style["--own"] = card.color;
  let main: React.ReactNode;
  let foot: string;
  if (card.status === "OPEN") {
    main = col === "H" ? "?" : poin;
    foot = card.jackpotPct > 0 ? `Jackpot +${card.jackpotPct}%` : `${ctx.rules.waktuDetik[row]} detik`;
  } else if (card.status === "LOCKED") {
    main = card.tryingInitials;
    foot = "sedang dicoba";
  } else if (card.status === "COOLDOWN") {
    main = Math.max(0, Math.ceil((card.cooldownUntil - now) / 1000));
    foot = "retak";
  } else {
    main = card.initials;
    foot = mine ? `milikmu · ${card.value}` : `bernilai ${card.value}`;
  }
  return (
    <button
      className={`bc ${card.status.toLowerCase()}${mine ? " mine" : ""}${blocked && card.status === "OPEN" ? " dim" : ""}${card.golden ? " gold" : ""}`}
      style={style}
      onClick={() => {
        sfx.tap();
        onPick(card.cell);
      }}
      aria-label={`Kartu ${card.cell}, ${card.status}${card.initials ? `, milik ${card.initials}` : ""}`}
      data-cell={card.cell}
      data-status={card.status}
      data-action={action}
    >
      <span className="bc-top">
        <b>{card.cell}</b>
        <em>{LEVEL_NAMA[row - 1]}</em>
      </span>
      <span className="bc-main">{main}</span>
      <span className="bc-foot">{foot}</span>
      {(card.shielded || card.immune) && claimed && <i className="bc-sh">Terlindung</i>}
      {card.status === "CONTESTED" && <i className="bc-sh war">Direbut!</i>}
    </button>
  );
}

function CellSheet({ card, ctx, onClose }: { card: PublicCard; ctx: BoardContext; onClose: () => void }) {
  const s = usePlay.getState();
  const row = Number(card.cell.slice(1));
  const col = card.cell[0]!;
  const info = KOLOM_LABEL[col]!;
  const { action, blocked } = actionFor(card, ctx);
  const mine = card.ownerId === ctx.me.id;
  const owner = s.leaderboard.find((l) => l.id === card.ownerId);
  const has = (p: string) => ctx.me.powerUps.includes(p as never);
  const mult = ctx.rules.pengaliKolom[col] ?? 1;
  const go = () => {
    onClose();
    if (action === "claim") s.openCard(card.cell);
    else if (action === "steal") s.stealCard(card.cell);
  };
  return (
    <div className="p-sheet-bg" onClick={onClose}>
      <div className="p-sheet" role="dialog" aria-label={`Kartu ${card.cell}`} onClick={(e) => e.stopPropagation()}>
        <div className="p-sheet-h" style={{ ["--hue" as string]: COL_HUE[col] }}>
          <span className="p-cellname">{card.cell}</span>
          <div>
            <b>{col === "H" && card.status === "OPEN" ? "Mystery" : info.nama}</b>
            <small>
              Level {row} · {ctx.rules.poin[row]} poin{mult !== 1 ? ` ×${mult}` : ""} · {ctx.rules.waktuDetik[row]}{" "}
              detik
            </small>
          </div>
        </div>
        {card.jackpotPct > 0 && card.status === "OPEN" && (
          <p className="p-note">Jackpot +{card.jackpotPct}% karena sudah ada yang gagal.</p>
        )}
        {card.status === "CLAIMED" && (
          <p className="p-note">
            {mine ? "Kartu ini milikmu." : `Milik ${owner?.name ?? card.initials}.`} Bernilai {card.value} poin.
            {card.shielded || card.immune ? " Sedang terlindung." : ""}
          </p>
        )}
        {card.status === "LOCKED" && <p className="p-note">Sedang dicoba {card.tryingInitials}.</p>}
        {blocked && <p className="p-note warn">{blocked.text}</p>}
        <div className="p-sheet-a">
          {action === "claim" && (
            <button className="p-btn p-primary" onClick={go}>
              Ambil kartu
            </button>
          )}
          {action === "steal" && (
            <button className="p-btn p-danger" onClick={go}>
              Rebut kartu (tiket {ctx.me.tickets})
            </button>
          )}
          {col === "H" && card.status === "OPEN" && has("mata_elang") && (
            <button className="p-btn" onClick={() => s.usePowerUp("mata_elang", card.cell)}>
              Pakai Mata Elang
            </button>
          )}
          {mine && has("perisai") && (
            <button
              className="p-btn"
              onClick={() => {
                s.usePowerUp("perisai", card.cell);
                onClose();
              }}
            >
              Pakai Perisai
            </button>
          )}
          <button className="p-btn ghost" onClick={onClose}>
            Tutup
          </button>
        </div>
      </div>
    </div>
  );
}

function BadgeSheet({ onClose }: { onClose: () => void }) {
  const defs = usePlay((s) => s.badgeDefs);
  const me = usePlay((s) => s.me)!;
  return (
    <div className="p-sheet-bg" onClick={onClose}>
      <div className="p-sheet tall" role="dialog" aria-label="Badge" onClick={(e) => e.stopPropagation()}>
        <h2 className="p-h2">
          Badge kamu · {me.badges.length}/{defs.length}
        </h2>
        <ul className="p-badges">
          {defs.map((b) => {
            const got = me.badges.includes(b.id);
            return (
              <li key={b.id} className={got ? "got" : ""}>
                <span className="bi">{b.ikon}</span>
                <div>
                  <b>{b.nama}</b>
                  <small>{b.syarat}</small>
                </div>
                {b.bonus > 0 && <em>+{b.bonus}</em>}
              </li>
            );
          })}
        </ul>
        <button className="p-btn" onClick={onClose}>
          Tutup
        </button>
      </div>
    </div>
  );
}

function EndScreen() {
  const me = usePlay((s) => s.me)!;
  const awards = usePlay((s) => s.awards);
  const defs = usePlay((s) => s.badgeDefs);
  const mine = awards.filter((a) => a.playerIds.includes(me.id));
  const xp = me.xp;
  const pct = xp && xp.next ? Math.min(100, Math.round((xp.total / xp.next) * 100)) : 100;
  return (
    <section className="p-end">
      <h2>Permainan selesai</h2>
      <div className="p-end-score">
        <b>{me.score}</b>
        <span>poin · peringkat {me.rank}</span>
      </div>
      {mine.length > 0 && (
        <ul className="p-awards">
          {mine.map((a) => (
            <li key={a.id}>
              <span>{a.ikon}</span>
              <div>
                <b>{a.title}</b>
                <small>{a.detail}</small>
              </div>
            </li>
          ))}
        </ul>
      )}
      {xp && (
        <div className="p-xp">
          <div className="top">
            <b>{xp.level}</b>
            <span>
              +{xp.gain} XP · total {xp.total}
              {xp.next ? ` / ${xp.next}` : ""}
            </span>
          </div>
          <div className="bar">
            <i style={{ width: `${pct}%` }} />
          </div>
        </div>
      )}
      {me.badges.length > 0 && (
        <p className="p-note">
          Badge sesi ini:{" "}
          {me.badges
            .map((id) => defs.find((d) => d.id === id))
            .filter(Boolean)
            .map((d) => `${d!.ikon} ${d!.nama}`)
            .join(" · ")}
        </p>
      )}
      <p className="p-muted">Lihat layar proyektor untuk upacara penghargaan.</p>
    </section>
  );
}

// ---------------------------------------------------------------------------------------------

/** Deteksi meninggalkan layar soal lebih dari toleransi (SPEC §5.2: fokus hilang). */
function useFocusGuard(active: boolean, toleranceMs: number) {
  const focusLost = usePlay((s) => s.focusLost);
  useEffect(() => {
    if (!active) return;
    let timer: ReturnType<typeof setTimeout> | null = null;
    const away = () => {
      if (timer) return;
      timer = setTimeout(() => {
        timer = null;
        focusLost();
      }, toleranceMs);
    };
    const back = () => {
      if (timer) clearTimeout(timer);
      timer = null;
    };
    const vis = () => (document.hidden ? away() : back());
    document.addEventListener("visibilitychange", vis);
    window.addEventListener("blur", away);
    window.addEventListener("focus", back);
    return () => {
      document.removeEventListener("visibilitychange", vis);
      window.removeEventListener("blur", away);
      window.removeEventListener("focus", back);
      if (timer) clearTimeout(timer);
    };
  }, [active, toleranceMs, focusLost]);
}

function QuestionView({ q }: { q: QuestionDeliver }) {
  const rules = usePlay((s) => s.rules)!;
  const offset = usePlay((s) => s.offset);
  const me = usePlay((s) => s.me)!;
  const answer = usePlay((s) => s.answer);
  const use = usePlay((s) => s.usePowerUp);
  const now = useNow(100);
  const [val, setVal] = useState("");
  const [sent, setSent] = useState(false);
  const [plays, setPlays] = useState(0);
  const left = remainingMs(q.deadline, now, offset);
  const frac = Math.min(1, left / q.totalMs);
  useFocusGuard(!sent, rules.fokusToleransiMs);
  const col = q.cell[0]!;
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setVal("");
    setSent(false);
    setPlays(0);
  }, [q.deliveryId]);

  const submit = (a: { optId?: string; value?: string }) => {
    if (sent) return;
    setSent(true);
    sfx.tap();
    answer(a);
  };
  const block = (e: React.SyntheticEvent) => e.preventDefault();
  const R = 26;
  const C = 2 * Math.PI * R;
  const hasPU = (p: string) => me.powerUps.includes(p as never);
  const audioLeft = rules.audioMaks - plays;

  return (
    <div
      className="p-q"
      ref={ref}
      onContextMenu={block}
      onCopy={block}
      onCut={block}
      onPaste={block}
      onDragStart={block}
      role="dialog"
      aria-label="Soal"
    >
      <div className="p-q-top">
        <span className="p-cellname sm">{q.cell}</span>
        <div className="p-q-meta">
          <b>
            {q.mode === "steal" ? "⚔️ Rebut · " : ""}
            {q.kategori}
          </b>
          <small>Level {q.level}</small>
        </div>
        <div className={`p-ring${frac < 0.25 ? " low" : ""}`} aria-label={`Sisa ${Math.ceil(left / 1000)} detik`}>
          <svg viewBox="0 0 60 60" width="60" height="60">
            <circle cx="30" cy="30" r={R} className="bg" />
            <circle cx="30" cy="30" r={R} className="fg" strokeDasharray={C} strokeDashoffset={C * (1 - frac)} />
          </svg>
          <span>{Math.ceil(left / 1000)}</span>
        </div>
      </div>
      <div className="p-q-body">
        <p className="p-qtext">{q.soal}</p>
        {q.audio && (
          <button
            className="p-btn"
            disabled={audioLeft <= 0}
            onClick={() => {
              unlockAudio();
              setPlays((n) => n + 1);
              playNotes(q.audio!.notes, q.audio!.durasi);
            }}
          >
            🔊 Putar nada ({Math.max(0, audioLeft)}× lagi)
          </button>
        )}
        {q.tipe === "pg" && q.opsi && (
          <div className="p-opts">
            {q.opsi.map((o, i) => (
              <button key={o.optId} className="p-opt" disabled={sent} onClick={() => submit({ optId: o.optId })}>
                <span className="l">{"ABCD"[i]}</span>
                {o.text}
              </button>
            ))}
          </div>
        )}
        {q.tipe === "angka" && (
          <>
            <div className="p-answer" aria-label="Jawabanmu">
              {val || <span className="ph">Jawabanmu</span>}
              {q.satuan && <small>{q.satuan}</small>}
            </div>
            <div className="p-numpad">
              {["7", "8", "9", "4", "5", "6", "1", "2", "3", "-", "0", ","].map((k) => (
                <button key={k} className="p-key" onClick={() => setVal((v) => pressKey(v, k))}>
                  {k}
                </button>
              ))}
              <button className="p-key" onClick={() => setVal((v) => pressKey(v, "⌫"))} aria-label="Hapus">
                ⌫
              </button>
              <button className="p-key send" disabled={!val || sent} onClick={() => submit({ value: val })}>
                Kirim
              </button>
            </div>
          </>
        )}
        {q.tipe === "teks" && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (val.trim()) submit({ value: val });
            }}
          >
            <input
              className="p-input"
              value={val}
              onChange={(e) => setVal(e.target.value)}
              autoComplete="off"
              autoCorrect="off"
              autoCapitalize="off"
              spellCheck={false}
              placeholder="Ketik jawabanmu"
              aria-label="Jawaban"
              onPaste={block}
            />
            <button className="p-btn p-primary" disabled={!val.trim() || sent}>
              Kirim
            </button>
          </form>
        )}
      </div>
      {(hasPU("50_50") || hasPU("plus15")) && (
        <div className="p-q-pu">
          {hasPU("50_50") && q.tipe === "pg" && (q.opsi?.length ?? 0) >= 4 && (
            <button className="p-chip" onClick={() => use("50_50")}>
              ✂️ 50:50
            </button>
          )}
          {hasPU("plus15") && (
            <button className="p-chip" onClick={() => use("plus15")}>
              ⏱️ +15 Detik
            </button>
          )}
        </div>
      )}
      {col === "H" && <p className="p-hint">Kartu Mystery: poin ×1,5</p>}
    </div>
  );
}

function ResultOverlay() {
  const r = usePlay((s) => s.result)!;
  const dismiss = usePlay((s) => s.dismissResult);
  useEffect(() => {
    const t = setTimeout(dismiss, r.correct ? 1900 : 2300);
    return () => clearTimeout(t);
  }, [r, dismiss]);
  return (
    <div className={`p-result ${r.correct ? "ok" : "no"}`} onClick={dismiss} role="status">
      {r.correct && <Confetti />}
      <div className="p-result-card">
        <div className="big">{r.correct ? "✓" : "…"}</div>
        <p className="p-h2">{r.message}</p>
        {r.correct && r.pointsGained > 0 && <div className="pts">+{r.pointsGained}</div>}
        {r.streak >= 2 && <p className="p-streak">🔥 Streak {r.streak}</p>}
      </div>
    </div>
  );
}

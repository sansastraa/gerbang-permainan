import type { ClientRules, MeState, Phase, PublicCard } from "@claim80/shared";

export const COLS = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"] as const;
export const ROWS = [1, 2, 3, 4, 5, 6, 7, 8] as const;

export interface Blocked {
  reason: "cooldown" | "frozen" | "busy" | "pajak" | "zona" | "phase";
  text: string;
}

/** Baris minimum yang boleh dibuka sesuai Pajak Juara. */
export function minRowFor(rules: ClientRules, owned: number): number {
  let m = 1;
  for (const t of rules.pajak) if (owned >= t.min_kartu) m = Math.max(m, t.baris_minimal);
  return m;
}

export interface BoardContext {
  rules: ClientRules;
  me: MeState;
  phase: Phase;
  /** menit sejak mulai (jam server), < 0 bila belum dimulai */
  elapsedMin: number;
  /** waktu server sekarang (ms) */
  now: number;
  hasQuestion: boolean;
}

/** Petunjuk visual saja; keputusan sebenarnya selalu di server. */
export function blockedFor(card: PublicCard, ctx: BoardContext): Blocked | null {
  if (ctx.phase === "LOBBY") return { reason: "phase", text: "Permainan belum dimulai." };
  if (ctx.phase === "END") return { reason: "phase", text: "Permainan sudah selesai." };
  if (ctx.me.frozen) return { reason: "frozen", text: "Kamu sedang dibekukan guru." };
  if (ctx.hasQuestion) return { reason: "busy", text: "Selesaikan dulu soalmu." };
  if (ctx.me.cooldownUntil > ctx.now) {
    return { reason: "cooldown", text: `Tunggu ${Math.ceil((ctx.me.cooldownUntil - ctx.now) / 1000)} detik lagi.` };
  }
  if (card.status !== "OPEN") return null; // kartu bukan OPEN dibahas terpisah (rebut / terkunci)
  const row = Number(card.cell.slice(1));
  const minRow = minRowFor(ctx.rules, ctx.me.cards);
  if (row < minRow) return { reason: "pajak", text: `Kamu sudah jago! Coba baris ${minRow} ke atas 💪` };
  if (
    ctx.elapsedMin < ctx.rules.zona.sampaiMenit &&
    ctx.rules.zona.baris.includes(row) &&
    ctx.me.cards > ctx.rules.zona.maks
  ) {
    return { reason: "zona", text: "Baris 1–2 dulu untuk teman yang belum punya kartu." };
  }
  return null;
}

export type CellAction = "claim" | "steal" | "none";

export function actionFor(card: PublicCard, ctx: BoardContext): { action: CellAction; blocked: Blocked | null } {
  const blocked = blockedFor(card, ctx);
  if (card.status === "OPEN") return { action: blocked ? "none" : "claim", blocked };
  const hardBlock = blocked && blocked.reason !== "pajak" && blocked.reason !== "zona";
  if (
    card.status === "CLAIMED" &&
    card.ownerId !== ctx.me.id &&
    ctx.rules.rebutFase.includes(ctx.phase) &&
    ctx.me.tickets > 0 &&
    !card.shielded &&
    !card.immune &&
    !hardBlock
  ) {
    return { action: "steal", blocked: null };
  }
  return { action: "none", blocked };
}

export function formatClock(ms: number): string {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`;
}

/** Sisa waktu soal dengan koreksi selisih jam server. */
export function remainingMs(deadline: number, clientNow: number, offset: number): number {
  return Math.max(0, deadline - (clientNow + offset));
}

export const POWERUP_INFO: Record<string, { nama: string; ikon: string; info: string }> = {
  "50_50": { nama: "50:50", ikon: "✂️", info: "Hapus 2 pilihan salah" },
  plus15: { nama: "+15 Detik", ikon: "⏱️", info: "Tambah waktu soal" },
  perisai: { nama: "Perisai", ikon: "🛡️", info: "Lindungi satu kartumu 5 menit" },
  streak_saver: { nama: "Streak Saver", ikon: "🔥", info: "Salah berikutnya tak memutus streak" },
  mata_elang: { nama: "Mata Elang", ikon: "🦅", info: "Intip tema kartu Mystery" },
  kunci_emas: { nama: "Kunci Emas", ikon: "🔑", info: "Kartu berikutnya bernilai ×2" },
};

/** Membersihkan input angka dari keypad. */
export function pressKey(cur: string, key: string): string {
  if (key === "⌫") return cur.slice(0, -1);
  if (cur.length >= 14) return cur;
  if (key === "-") return cur.startsWith("-") ? cur.slice(1) : `-${cur}`;
  if (key === ",")
    return cur.includes(",") || cur.includes(".") ? cur : `${cur === "" || cur === "-" ? `${cur}0` : cur},`;
  if (/^\d$/.test(key)) return cur + key;
  return cur;
}

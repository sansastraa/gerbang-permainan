import type { FxEvent } from "@claim80/shared";

/** Warna kategori per kolom (strip kartu). Kontras ke teks gelap tetap terjaga karena hanya dipakai sebagai aksen. */
export const COL_HUE: Record<string, string> = {
  A: "#3b82f6",
  B: "#f43f5e",
  C: "#14b8a6",
  D: "#f59e0b",
  E: "#8b5cf6",
  F: "#0ea5e9",
  G: "#ec4899",
  H: "#475569",
  I: "#22c55e",
  J: "#f97316",
};

/** Teks banner untuk efek proyektor; null bila efek tidak perlu banner layar penuh. */
export interface Banner {
  kind: "streak" | "golden" | "steal" | "defend" | "phase" | "mission" | "end" | "gift";
  title: string;
  sub?: string;
  color?: string;
}

export function bannerFor(fx: FxEvent): Banner | null {
  switch (fx.type) {
    case "streak":
      if ((fx.data.streak ?? 0) >= 5) {
        return {
          kind: "streak",
          title: fx.data.label ?? "Streak!",
          sub: `${fx.name} · ${fx.data.streak} beruntun`,
          ...(fx.color ? { color: fx.color } : {}),
        };
      }
      return null;
    case "golden":
      return { kind: "golden", title: "Kartu Emas!", sub: `${fx.name} menemukan ${fx.cell}` };
    case "gift":
      return { kind: "gift", title: "Kartu Hadiah", sub: `${fx.name} mendapat power-up` };
    case "steal_started":
      return { kind: "steal", title: `${fx.name} menantang ${fx.fromName}`, sub: `Rebut ${fx.cell}` };
    case "stolen":
      return { kind: "steal", title: `${fx.name} merebut ${fx.cell}`, sub: `dari ${fx.fromName}` };
    case "steal_failed":
      return { kind: "defend", title: `${fx.fromName} bertahan`, sub: `${fx.cell} dilindungi perisai` };
    case "phase":
      return { kind: "phase", title: fx.data.phase ?? "", sub: PHASE_SUB[fx.data.phase ?? ""] ?? "" };
    case "mission":
      return { kind: "mission", title: "Misi Kelas Tercapai!", sub: "Semua murid mendapat hadiah" };
    case "ended":
      return { kind: "end", title: "Selesai!", sub: "Terima kasih sudah bermain" };
    default:
      return null;
  }
}

const PHASE_SUB: Record<string, string> = {
  OPEN: "Semua kartu terbuka, pilih strategimu",
  BATTLE: "Rebut kini aktif ⚔️",
  RUSH: "Semua poin ×1,5 — ngebut!",
  END: "Papan dibekukan",
};

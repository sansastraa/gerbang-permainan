import { appUrl } from "../base";
import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { GameStage } from "../play/Play";
import { usePlay } from "../play/playStore";
import "../play/play.css";
import "./station.css";

const KEY = "claim80.station";
const RELEASE_MS = 5000;

interface Saved {
  code: string;
  token: string;
}
const read = (): Saved | null => {
  try {
    return JSON.parse(sessionStorage.getItem(KEY) ?? "null") as Saved | null;
  } catch {
    return null;
  }
};

/** Stasiun Jawab (SPEC §8.4): tablet di depan kelas; murid dipanggil dari antrean, mengklaim satu kartu, lalu kembali ke tempat duduk. */
export function Station() {
  const { code: urlCode } = useParams();
  const connect = usePlay((s) => s.connectStation);
  const no = usePlay((s) => s.stationNo);
  const stage = usePlay((s) => s.stage);
  const fatal = usePlay((s) => s.fatal);
  const [code, setCode] = useState(urlCode?.toUpperCase() ?? read()?.code ?? "");
  const [token, setToken] = useState(read()?.token ?? "");

  useEffect(() => {
    const s = read();
    if (s && (!urlCode || urlCode.toUpperCase() === s.code)) connect(s.code, s.token);
  }, [connect, urlCode]);

  const submit = () => {
    const c = code.trim().toUpperCase();
    try {
      sessionStorage.setItem(KEY, JSON.stringify({ code: c, token: token.trim() }));
    } catch {
      /* abaikan */
    }
    connect(c, token.trim());
  };

  if (no > 0 && stage !== "fatal") return <StationScreen code={read()?.code ?? code} />;
  return (
    <div className="p-root">
      <main className="p-center">
        <div className="p-brand">
          CLAIM <b>80</b>
        </div>
        <h1 className="p-h">Stasiun Jawab</h1>
        <p className="p-muted">
          Masukkan kode sesi dan token guru satu kali. Setelah itu murid tinggal dipanggil dari antrean.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
        >
          <input
            className="p-input p-code"
            value={code}
            onChange={(e) => setCode(e.target.value.toUpperCase())}
            placeholder="KODE"
            aria-label="Kode sesi"
          />
          <input
            className="p-input"
            value={token}
            onChange={(e) => setToken(e.target.value)}
            placeholder="Token guru"
            aria-label="Token guru"
          />
          <button className="p-btn p-primary" disabled={code.trim().length < 4 || !token.trim()}>
            Buka stasiun
          </button>
        </form>
        {fatal && <p className="p-error">{fatal}</p>}
      </main>
    </div>
  );
}

function StationScreen({ code }: { code: string }) {
  const s = usePlay();
  const [names, setNames] = useState<{ id: string; name: string; absen: number | null }[]>([]);
  const [q, setQ] = useState("");
  const armed = useRef(false);
  const assigned = !!s.me && !!s.rules;

  useEffect(() => {
    void fetch(appUrl(`/api/join/${encodeURIComponent(code)}`))
      .then((r) => (r.ok ? r.json() : null))
      .then((j: { students: typeof names } | null) => j && setNames(j.students))
      .catch(() => undefined);
  }, [code]);

  // kembali otomatis ke layar antrean 5 detik setelah soal dijawab (benar, salah, atau waktu habis)
  useEffect(() => {
    if (!assigned) {
      armed.current = false;
      return;
    }
    if (s.result && !armed.current) {
      armed.current = true;
      setTimeout(() => usePlay.getState().stationRelease(), RELEASE_MS);
    }
  }, [assigned, s.result]);

  const list = useMemo(() => names.filter((n) => n.name.toLowerCase().includes(q.trim().toLowerCase())), [names, q]);

  if (assigned) {
    return (
      <div className="st-play">
        <div className="st-bar">
          <span>
            Stasiun <b>{s.stationNo}</b> · {s.me!.name.split(" ").slice(0, 2).join(" ")}
          </span>
          <button className="p-btn" onClick={() => s.stationRelease()}>
            Selesai / batal
          </button>
        </div>
        <GameStage />
      </div>
    );
  }

  const st = s.station;
  const next = st?.queue[0];
  return (
    <div className="p-root">
      <main className="st-idle">
        <header>
          <div className="st-no">
            <small>STASIUN</small>
            <b>{s.stationNo}</b>
          </div>
          <div>
            <h1 className="p-h">Giliran berikutnya</h1>
            <p className="p-muted">
              Kelas {s.className}. Satu murid mengklaim satu kartu, lalu kembali ke tempat duduk.
            </p>
          </div>
        </header>

        {next ? (
          <section className="st-next">
            <span className="av" style={{ background: next.color }}>
              {next.initials}
            </span>
            <b>{next.name}</b>
            <button className="p-btn p-primary" onClick={() => s.stationCall()}>
              Panggil sekarang
            </button>
          </section>
        ) : (
          <section className="st-next empty">
            <b>Antrean kosong</b>
            <small>Tambahkan murid lewat daftar nama di bawah, atau panggil langsung.</small>
          </section>
        )}
        {s.stationError && <p className="p-error">{s.stationError}</p>}

        {st && st.queue.length > 1 && (
          <section>
            <h2 className="p-h2">Antre ({st.queue.length})</h2>
            <ul className="st-queue">
              {st.queue.map((m, i) => (
                <li key={m.id}>
                  <span className="n">{i + 1}</span>
                  <span className="av" style={{ background: m.color }}>
                    {m.initials}
                  </span>
                  {m.name}
                  <button className="p-link" onClick={() => s.stationDequeue(m.id)}>
                    keluarkan
                  </button>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section>
          <h2 className="p-h2">Pilih nama</h2>
          <input
            className="p-input"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Cari nama…"
            aria-label="Cari nama"
          />
          <ul className="st-names">
            {list.map((n) => {
              const inQueue = st?.queue.some((x) => x.id === n.id);
              const busy = st?.stations.some((x) => x.studentId === n.id);
              return (
                <li key={n.id}>
                  <span className="ab">{n.absen ?? "·"}</span>
                  <span className="nm">{n.name}</span>
                  <button className="p-btn" disabled={inQueue || busy} onClick={() => s.stationEnqueue(n.id)}>
                    {inQueue ? "Antre" : "Antre"}
                  </button>
                  <button className="p-btn p-primary" disabled={busy} onClick={() => s.stationCall(n.id)}>
                    Panggil
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      </main>
    </div>
  );
}

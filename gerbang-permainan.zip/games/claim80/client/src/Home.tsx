import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { KOLOM_LABEL } from "@claim80/shared";
import { COL_HUE } from "./theme";
import "./home.css";

const DECK = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J"];

/** Halaman depan: murid masuk dengan kode, guru membuka konsol, proyektor membuka layar kelas. */
export function Home() {
  const nav = useNavigate();
  const [code, setCode] = useState("");
  const [pcode, setPcode] = useState("");
  const clean = (v: string) =>
    v
      .toUpperCase()
      .replace(/[^A-Z0-9]/g, "")
      .slice(0, 8);
  return (
    <div className="hm">
      <header className="hm-hero">
        <div className="hm-fan" aria-hidden>
          {DECK.map((c, i) => (
            <span
              key={c}
              style={{
                ["--hue" as string]: COL_HUE[c],
                ["--i" as string]: i - 4.5,
                ["--d" as string]: `${i * 45}ms`,
              }}
            >
              <b>{c}</b>
              <i>{KOLOM_LABEL[c]!.ikon}</i>
            </span>
          ))}
        </div>
        <h1 className="hm-title">
          <span>CLAIM</span> <em>80</em>
        </h1>
        <p className="hm-sub">
          80 kartu soal, satu kelas, satu papan. Jawab benar, klaim kartunya, lalu pertahankan dari teman-temanmu.
        </p>
      </header>

      <main className="hm-grid">
        <section className="hm-card join">
          <span className="tag">Untuk murid</span>
          <h2>Masuk ke permainan</h2>
          <p>Ketik kode sesi yang tampil di layar proyektor atau yang diberikan gurumu.</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (code.length >= 4) nav(`/play/${code}`);
            }}
          >
            <input
              value={code}
              onChange={(e) => setCode(clean(e.target.value))}
              placeholder="KODE"
              aria-label="Kode sesi"
              autoCapitalize="characters"
              autoComplete="off"
              inputMode="text"
            />
            <button disabled={code.length < 4}>Masuk</button>
          </form>
        </section>

        <section className="hm-card proj">
          <span className="tag">Untuk layar kelas</span>
          <h2>Buka proyektor</h2>
          <p>Tampilkan papan kartu, Top 10, dan upacara penghargaan di layar besar.</p>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (pcode.length >= 4) nav(`/projector/${pcode}`);
            }}
          >
            <input
              value={pcode}
              onChange={(e) => setPcode(clean(e.target.value))}
              placeholder="KODE"
              aria-label="Kode sesi untuk proyektor"
              autoComplete="off"
            />
            <button disabled={pcode.length < 4}>Buka</button>
          </form>
        </section>

        <section className="hm-card host">
          <span className="tag">Untuk guru</span>
          <h2>Konsol guru</h2>
          <p>
            Buat sesi dari daftar siswa, setujui murid yang masuk, atur fase, dan pantau bendera. Buka dari laptop yang
            menjalankan server.
          </p>
          <Link to="/host" className="go">
            Buka konsol guru
          </Link>
        </section>
      </main>

      <footer className="hm-foot">
        Berjalan di jaringan sekolah tanpa internet. Semua penilaian dilakukan server, jadi kunci jawaban tidak pernah
        sampai ke perangkat murid.
      </footer>
    </div>
  );
}

/**
 * Awalan jalur aplikasi. Build biasa memakai "/" (BASE = ""); di belakang gerbang SIMPETERI dibuild dengan
 * `BASE_PATH=/games/claim80` sehingga Vite `base` = "/games/claim80/" dan semua jalur internal memakai awalan itu.
 */
export function baseFrom(viteBase: string | undefined): string {
  const parts = (viteBase ?? "/").split("/").filter(Boolean);
  return parts.length ? "/" + parts.join("/") : "";
}

/** Gabungkan awalan dengan jalur absolut internal, mis. ("/games/claim80", "/api/x") → "/games/claim80/api/x". */
export function withBase(base: string, path: string): string {
  return base + (path.startsWith("/") ? path : "/" + path);
}

export const BASE = baseFrom(import.meta.env.BASE_URL);

/** Jalur internal (fetch, tautan biasa, socket) lengkap dengan awalan. */
export const appUrl = (path: string): string => withBase(BASE, path);

/** Path Socket.IO untuk `io({ path })`. */
export const SOCKET_PATH = appUrl("/socket.io");

/** Asal + awalan, dasar untuk URL yang dibagikan (QR murid, alamat ringkasan). */
export const appOrigin = (): string => location.origin + BASE;

import { useMemo } from "react";

const CONFETTI_COLORS = ["#ff5a36", "#f2a900", "#17a870", "#14213d", "#3b82f6", "#ec4899"];

/** Ledakan konfeti murni CSS (sepuluh lebih potong kertas berarah acak). */
export function Confetti() {
  const bits = useMemo(
    () =>
      Array.from({ length: 28 }, (_, i) => {
        const angle = (i / 28) * Math.PI * 2 + Math.random() * 0.4;
        const dist = 90 + Math.random() * 120;
        return {
          dx: Math.cos(angle) * dist,
          dy: Math.sin(angle) * dist - 40,
          rot: Math.round(Math.random() * 540 - 270),
          color: CONFETTI_COLORS[i % CONFETTI_COLORS.length]!,
          delay: Math.round(Math.random() * 90),
        };
      }),
    [],
  );
  return (
    <div className="p-confetti" aria-hidden>
      {bits.map((b, i) => (
        <i
          key={i}
          style={{
            background: b.color,
            animationDelay: `${b.delay}ms`,
            ["--dx" as string]: `${b.dx}px`,
            ["--dy" as string]: `${b.dy}px`,
            ["--rot" as string]: `${b.rot}deg`,
          }}
        />
      ))}
    </div>
  );
}

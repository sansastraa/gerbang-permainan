import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";
import { defineConfig } from "vitest/config";

/** BASE_PATH=/games/claim80 → base "/games/claim80/" (di belakang gerbang SIMPETERI); kosong → "/". */
const basePath = (process.env.BASE_PATH ?? "").split("/").filter((p) => p.trim() !== "");
const base = basePath.length ? `/${basePath.join("/")}/` : "/";

export default defineConfig({
  base,
  plugins: [react(), tailwindcss()],
  server: {
    port: 5180,
    proxy: { "/socket.io": { target: "http://localhost:3080", ws: true }, "/health": "http://localhost:3080" },
  },
  build: { outDir: "dist", sourcemap: false },
  test: { environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"] },
});

# CLAIM 80

Game kelas real-time: 80 kartu soal (A–J × 1–8) diperebutkan ±25 murid, tampil di proyektor, dikendalikan guru, berjalan **offline di jaringan lokal**. Aturan lengkap: `docs/SPEC.md`; angka permainan: `config/game.config.json`; catatan kemajuan dan hal yang belum diuji: `docs/PROGRESS.md`.

## 1. Menjalankan di kelas (satu laptop guru)

Dari akar repositori SIMPETERI:

```bash
npm run c80:install      # sekali
npm run c80:build
npm run c80:start        # mencetak alamat LAN dan token guru
```

- Murid membuka alamat LAN (mis. `http://192.168.1.20:3080`), memasukkan kode sesi, memilih nama, lalu memasukkan PIN kelas (berganti tiap 5 menit, tampil di konsol guru).
- Proyektor: `/projector/<KODE>`. Guru: `/host`. Tablet stasiun: `/station/<KODE>`.
- Dari laptop server, token guru otomatis (loopback). Dari perangkat lain, token ada di `server/var/host-token.txt` dan stabil antar-restart.
- Dari SIMPETERI: menu **Clash of Git → CLAIM 80** memilih kelas dan mengirim daftar siswa ke layar guru (`/claim-80`).
- Untuk pengembangan: `npm run c80:dev` (server + klien dengan hot reload).

## 2. Simulasi Definition of Done

```bash
npm run c80:sim                              # 25 bot, 40 menit permainan, jam dipercepat 10x (±4,5 menit nyata)
npm run c80:sim -- --minutes 10 --speed 20   # versi singkat
```

Server berjalan di dalam proses simulasi (DB di memori) dengan jam yang dipercepat; bot memakai Socket.IO sungguhan. Keluaran: daftar butir SPEC §10 yang diperiksa (LULUS/GAGAL) dan kode keluar 1 bila ada yang gagal. Butir 6 (aturan kartu) diuji oleh tes unit; butir 8–9 (audio di perangkat nyata, keterbacaan 8 m) hanya bisa diuji manual.

## 3. Deploy terpisah (server online)

CLAIM 80 butuh proses Node yang hidup terus (WebSocket); tidak bisa berjalan di hosting statis/Lovable. Syarat dan pengaturan:

- Node ≥ 20. Build klien (`npm run c80:build`), jalankan `npm run c80:start` di belakang reverse proxy yang meneruskan WebSocket (`Upgrade`) dan memberi **https** (Caddy, nginx, atau layanan PaaS yang mendukung WebSocket).
- Variabel lingkungan: `PORT` (bawaan 3080); `HOST_TOKEN` (token guru tetap, **wajib diisi sendiri di server online**; tanpa itu dibuat acak lalu disimpan di `server/var/host-token.txt`); `ALLOWED_ORIGINS` (daftar asal dipisah koma yang boleh memanggil `/api` dari peramban, mis. `https://simpeteri.example`, dipakai untuk ringkasan `summary.json`).
- Data sesi (SQLite + log aksi berantai hash) ada di `server/var/`. Pasang sebagai volume yang bertahan agar sesi bisa dipulihkan setelah restart.
- Di SIMPETERI, isi `VITE_CLAIM_80_URL` (https) pada pengaturan build agar tombol "Buka layar guru CLAIM 80" menunjuk ke server itu.
- Tidak ada layanan cloud/analytics pihak ketiga saat runtime. Suara VO memakai rekaman guru atau suara bawaan perangkat.

## 4. Ekspor hasil

Konsol guru → Laporan: CSV (`students.csv`, `items.csv`, `attempts.csv`, dengan BOM agar terbaca di Excel), rapor cetak A5 per murid, heatmap kelas. Ringkasan per siswa untuk Multi Permainan SIMPETERI: `GET /api/sessions/<id>/summary.json` (tanpa token; alamat sesi sulit ditebak, CORS dibatasi `ALLOWED_ORIGINS`).

## 4b. Dipanggil dari Multi Permainan SIMPETERI

Pesan `claim80:roster` (balasan atas `claim80:host-ready`, hanya dari jendela pembuka) boleh membawa tiga field opsional:

- `pin` (string 4–32): dipakai sebagai token guru (header `x-host-token` dan handshake socket) tanpa meminta PIN di game dan tanpa memanggil `/api/host-token`. Server harus dijalankan dengan `HOST_TOKEN` yang sama dengan PIN; bila tidak, layar guru menampilkan "PIN guru salah, samakan dengan PIN di SIMPETERI". PIN hanya disimpan di memori halaman (bukan URL, log, localStorage, maupun sessionStorage) dan tidak ditampilkan.
- `kembali` (URL http/https mutlak) dan `multiSesi` (id sesi Multi Permainan): bila keduanya ada, saat fase `END` layar guru menampilkan hitung mundur 10 detik (bisa dibatalkan) lalu `location.assign` ke `kembali` dengan tambahan `selesai=1&gameSesi=<id sesi CLAIM 80>`. Tujuan hanya diizinkan bila origin `kembali` sama dengan origin pengirim pesan roster (`e.origin`); selain itu tidak ada pengalihan.
- Pesan dengan field yang tidak sah (pin di luar 4–32, `kembali` bukan http/https, `multiSesi` kosong) ditolak seluruhnya.

`summary.json` tetap bisa ditarik SIMPETERI dengan `x-host-token` = PIN (CORS `ALLOWED_ORIGINS`).
## 4c. Di belakang gerbang dengan awalan jalur (`BASE_PATH`)

Agar semua game diakses satu pintu lewat SIMPETERI (mis. `http://<host>/games/claim80`), CLAIM 80 bisa berjalan di bawah awalan jalur. Gerbang meneruskan `/games/claim80/**` apa adanya (tanpa memotong awalan) ke server CLAIM 80, termasuk upgrade WebSocket.

```bash
# build klien dengan awalan (Vite base = /games/claim80/) lalu jalankan server dengan awalan yang sama
BASE_PATH=/games/claim80 npm run c80:build
BASE_PATH=/games/claim80 PORT=3080 HOST_TOKEN=<PIN guru> npm run c80:start
```

PowerShell: `$env:BASE_PATH="/games/claim80"; npm run c80:build; $env:PORT="3080"; npm run c80:start`.

- `BASE_PATH` kosong = perilaku biasa di akar. Nilai dinormalkan (diawali `/`, tanpa `/` akhir). **Awalan di build klien dan di server harus sama.**
- Di bawah awalan: klien statis dan fallback SPA (`/host`, `/play`, `/projector`, `/station`, `/report`), `/health`, `/api/**`, dan Socket.IO di `<awalan>/socket.io`. Jalur di luar awalan (mis. `/health`) tidak dilayani.
- Klien memakai `src/base.ts` (`appUrl`, `SOCKET_PATH`, `appOrigin`) untuk semua fetch, socket, tautan, router (`basename`), serta URL murid di QR/proyektor dan alamat ringkasan. Alamat `kembali` ke SIMPETERI tetap URL mutlak dari pesan roster.
- `/api/host-token` hanya untuk akses langsung dari loopback. Bila ada header proxy (`X-Forwarded-For`, `Forwarded`, `X-Real-IP`) permintaan ditolak 403, jadi token tidak bocor lewat gerbang; di mode gerbang pakai `HOST_TOKEN` = PIN guru.
- Semuanya same-origin lewat gerbang, jadi `ALLOWED_ORIGINS` hanya perlu bila SIMPETERI memanggil server ini lintas-origin.
## 5. Struktur

`shared/` engine murni (`reduce(state, action, now)`) dan skema; `server/` Express + Socket.IO + SQLite; `client/` Vite + React; `config/`, `data/`, `docs/`, `scripts/` (`simulate.ts`, `seed-demo.ts`, `demo-bots.ts`).

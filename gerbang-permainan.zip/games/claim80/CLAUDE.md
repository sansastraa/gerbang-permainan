# CLAUDE.md — CLAIM 80

Kamu sedang membangun **CLAIM 80**, game kelas real-time: 80 kartu soal (grid A–J × 1–8, boleh diklaim bebas urutan) diperebutkan ±25 murid SD/SMP awal, ditampilkan di proyektor, dikendalikan guru, dan berjalan **offline di jaringan lokal**.

## Sumber kebenaran

- `docs/SPEC.md` — aturan permainan, anti-curang, gamifikasi, statistik, arsitektur, kriteria penerimaan. **Baca seluruhnya sebelum menulis kode.**
- `config/game.config.json` — semua angka permainan. Jangan hardcode angka yang ada di sini.
- `config/vo_naskah.json` — naskah Voice-Over (SPEC §7a).
- `data/bank_soal.json` — 160 soal (80 sel × 2 varian). Jangan ubah isi soal tanpa diminta; jika menemukan kesalahan, laporkan.
- `docs/BANK_SOAL.md` — versi baca guru, dibangkitkan oleh `python3 scripts/build_bank.py`.

## Aturan kerja

- TypeScript strict di semua paket. Stack sesuai SPEC §9.1; jangan ganti tanpa alasan kuat.
- Logika permainan **wajib** berupa fungsi murni di `shared/src/engine` (`reduce(state, action, now)`), lalu diuji dengan Vitest sebelum dihubungkan ke socket.
- **Server-authoritative**: kunci jawaban, penilaian, timer, dan RNG hanya di server. Klien tidak pernah menerima jawaban benar selama sesi berjalan.
- Teks UI dalam Bahasa Indonesia yang ramah anak. Nama game dan label fase tetap Bahasa Inggris.
- Setiap milestone selesai = semua tes hijau + `npm run lint` bersih + catatan singkat di `docs/PROGRESS.md`.
- Jangan tambahkan layanan cloud, analytics pihak ketiga, atau dependensi yang butuh internet saat runtime.

## Perintah (buat di M0)

```
npm install
npm run dev        # server + client watch
npm run test       # vitest semua paket
npm run sim        # 25 bot, sesi dipercepat 10×
npm run build && npm run start   # cetak URL LAN + QR
```

## Milestone (kerjakan berurutan)

- **M0 Scaffold** — npm workspaces `shared`, `server`, `client`; Vite+React+Tailwind; Express+Socket.IO; ESLint/Prettier; Vitest.
- **M1 Bank & validasi** — muat `bank_soal.json`, validasi zod (SPEC §7.5), `judge.ts` dengan normalisasi jawaban (SPEC §7.3) + tes untuk "5.000", "Rp5000", "0,5", huruf besar/kecil.
- **M2 Engine** — state machine kartu (SPEC §9.3), kelayakan (§3.3), skor & streak (§3.5, §4.1), rebut (§3.4), jackpot, kartu golden/gift, combo (§4.4). Tes unit lengkap termasuk race condition dua klaim bersamaan.
- **M3 Server realtime** — SQLite (§9.4), event socket (§9.5), room, loop timer 250 ms, event log berantai hash, reconnect + snapshot.
- **M4 `/play`** — grid mobile, layar soal, keypad angka, synth audio Web Audio (`client/src/audio/synth.ts`), power-up, notifikasi.
- **M5 `/projector`** — grid 10×8 besar, status sel, ticker, top 10, misi kelas, animasi (Framer Motion), fase berkabut.
- **M6 `/host`** — lobby + persetujuan + cetak Kartu PIN, kontrol fase, kendali murid, panel bendera.
- **M7 Anti-curang** — semua butir SPEC §5.1–5.4, termasuk tes otomatis bahwa payload soal bebas kunci.
- **M8 Gamifikasi lanjutan** — badge (`config/badges.json`), misi kelas, penghargaan akhir, XP lintas sesi.
- **M8b Voice-Over** — `server/vo/director.ts` (antrean, prioritas, penggabungan, kedaluwarsa), `client/src/audio/vo.ts` (fallback rekaman guru → Web Speech lokal → online → teks), subtitle + sorot sel di proyektor, perekam VO di `/host/vo`. Tes: klaim benar → `vo:play` hanya ke room proyektor; salah → tidak ada VO.
- **M9 Statistik & laporan** — indikator §6.2, rapor radar, heatmap, analisis butir, ekspor CSV/JSON, tampilan cetak.
- **M10 Mode Stasiun & generator** — `/station`, antrean, generator parametrik kolom A/E/I (§7.4).
- **M11 Simulasi & polish** — `scripts/simulate.ts` (25 bot dengan akurasi acak per kategori), lulus seluruh kriteria SPEC §10, aksesibilitas (kontras, inisial selain warna), opsi matikan animasi/suara.

## Definition of Done

Seluruh daftar di SPEC §10 terpenuhi dan didemonstrasikan dengan `npm run sim` + satu sesi manual (1 proyektor, 1 host, 3 perangkat murid).

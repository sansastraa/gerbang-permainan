// ============================================================
// LOGIC RUSH — engine (fungsi murni: tanpa jaringan, tanpa jam)
// Port TypeScript dari paket spesifikasi `engine/lr-engine.js` TANPA mengubah perilaku.
// Berkas asli disimpan di `shared/reference/lr-engine.cjs`; `engine.parity.test.ts`
// membandingkan keluaran keduanya pada ribuan masukan.
//
// Papan: { id, n, rules: ['row','col','zone','blocked','diag'], zones: string[], solution?: number[] }
//   zones[r][c] = '0'..'9' nomor zona (dibaca basis-36), '#' = kotak arsir
//   Ukuran papan 3..10. R5 diagonal hanya untuk ukuran >= 4.
//   solution[r] = kolom permata di baris r (HANYA server)
// ============================================================

export type Rule = "row" | "col" | "zone" | "blocked" | "diag";
export type Cell = { r: number; c: number };
export type Tier = "T1" | "T2" | "T3";
export type Level = "mudah" | "sedang" | "sulit";

export interface PublicBoard {
  id: string | null;
  n: number;
  rules: Rule[];
  zones: string[];
}
export interface Board extends PublicBoard {
  solution?: number[];
  tier?: Tier;
  difficulty?: number;
  steps?: { T1: number; T2: number; T3: number };
  approved?: boolean;
  transform?: number;
  zonePerm?: number[] | null;
}
export interface Conflict {
  a: Cell;
  b: Cell;
  rules: Rule[];
}
export interface CheckResult {
  ok: boolean;
  complete: boolean;
  conflicts: Conflict[];
  cellErrors: { r: number; c: number; rule: "blocked" }[];
  duplicate: boolean;
}
export interface LogicResult {
  solved: boolean;
  contradiction?: boolean;
  tier: number;
  steps: { T1: number; T2: number; T3: number };
  placed: Cell[];
  difficulty?: number;
}
export interface Stage {
  n: number;
  arsir?: boolean;
  diagonal?: boolean;
  level?: Level;
}
export interface GenerateOptions {
  n: number;
  rules: Rule[];
  blocked?: [number, number];
  maxTier?: number;
  minTier?: number;
  band?: [number, number];
  maxAttempts?: number;
}
export type Rng = () => number;
export type Move = { op: "gem" | "clear" | "x" | "unx" | "hint"; r: number; c: number };

// ---------- RNG ----------
function hashStr(s: string): number {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}
export function rngFrom(seed: string | number): Rng {
  let a = hashStr(String(seed));
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle<T>(a: T[], rng: Rng): T[] {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

export const MIN_N = 3;
export const MAX_N = 10;
type ZoneBoard = { n: number; rules: Rule[]; zones: string[] };
const zoneAt = (b: ZoneBoard, r: number, c: number): string => b.zones[r][c];
export const zoneNum = (ch: string): number => parseInt(ch, 36);
const isBlocked = (b: ZoneBoard, r: number, c: number): boolean => b.zones[r][c] === "#";
const has = (b: { rules: Rule[] }, rule: Rule): boolean => b.rules.includes(rule);

// ---------- R1–R5: pemeriksa aturan ----------
export function check(b: ZoneBoard, gems: Cell[]): CheckResult {
  const conflicts: Conflict[] = [];
  const cellErrors: CheckResult["cellErrors"] = [];
  for (const g of gems) if (isBlocked(b, g.r, g.c)) cellErrors.push({ r: g.r, c: g.c, rule: "blocked" });
  for (let i = 0; i < gems.length; i++)
    for (let j = i + 1; j < gems.length; j++) {
      const a = gems[i];
      const q = gems[j];
      const rules: Rule[] = [];
      if (a.r === q.r) rules.push("row");
      if (a.c === q.c) rules.push("col");
      if (!isBlocked(b, a.r, a.c) && !isBlocked(b, q.r, q.c) && zoneAt(b, a.r, a.c) === zoneAt(b, q.r, q.c))
        rules.push("zone");
      if (has(b, "diag") && Math.abs(a.r - q.r) === Math.abs(a.c - q.c)) rules.push("diag");
      if (rules.length) conflicts.push({ a, b: q, rules });
    }
  const dupe = new Set(gems.map((g) => g.r + "," + g.c)).size !== gems.length;
  const ok = !dupe && conflicts.length === 0 && cellErrors.length === 0;
  return { ok, complete: ok && gems.length === b.n, conflicts, cellErrors, duplicate: dupe };
}
export const RULE_TEXT: Record<Rule, string> = {
  row: "satu baris",
  col: "satu kolom",
  zone: "satu zona warna",
  blocked: "kotak arsir",
  diag: "sejajar miring",
};

// ---------- hitung solusi (backtracking dengan topeng) ----------
export function solutions(b: ZoneBoard, limit = 2): number[][] {
  const n = b.n;
  const out: number[][] = [];
  const cols: number[] = [];
  let colM = 0;
  let zoneM = 0;
  let d1 = 0;
  let d2 = 0;
  const diag = has(b, "diag");
  (function rec(r: number): void {
    if (out.length >= limit) return;
    if (r === n) {
      out.push(cols.slice());
      return;
    }
    for (let c = 0; c < n; c++) {
      if (isBlocked(b, r, c) || (colM >> c) & 1) continue;
      const z = parseInt(zoneAt(b, r, c), 36);
      if ((zoneM >> z) & 1) continue;
      if (diag && ((d1 >> (r - c + n)) & 1 || (d2 >> (r + c)) & 1)) continue;
      colM |= 1 << c;
      zoneM |= 1 << z;
      if (diag) {
        d1 |= 1 << (r - c + n);
        d2 |= 1 << (r + c);
      }
      cols.push(c);
      rec(r + 1);
      cols.pop();
      colM &= ~(1 << c);
      zoneM &= ~(1 << z);
      if (diag) {
        d1 &= ~(1 << (r - c + n));
        d2 &= ~(1 << (r + c));
      }
      if (out.length >= limit) return;
    }
  })(0);
  return out;
}

// ---------- solver logika (meniru cara anak berpikir) ----------
function combos<T>(arr: T[], k: number, start = 0, acc: T[] = [], out: T[][] = []): T[][] {
  if (acc.length === k) {
    out.push(acc.slice());
    return out;
  }
  for (let i = start; i < arr.length; i++) {
    acc.push(arr[i]);
    combos(arr, k, i + 1, acc, out);
    acc.pop();
  }
  return out;
}
export function logicSolve(b: ZoneBoard, maxTier = 3): LogicResult {
  const n = b.n;
  const diag = has(b, "diag");
  const cand = new Set<number>();
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (!isBlocked(b, r, c)) cand.add(r * n + c);
  const placed: Cell[] = [];
  const usedRow = new Set<number>();
  const usedCol = new Set<number>();
  const usedZone = new Set<string>();
  const steps = { T1: 0, T2: 0, T3: 0 };
  let tier = 0;
  const z = (i: number): string => zoneAt(b, Math.floor(i / n), i % n);
  const place = (i: number): void => {
    const r = Math.floor(i / n);
    const c = i % n;
    const zz = z(i);
    placed.push({ r, c });
    usedRow.add(r);
    usedCol.add(c);
    usedZone.add(zz);
    for (const j of [...cand]) {
      const rr = Math.floor(j / n);
      const cc = j % n;
      if (rr === r || cc === c || z(j) === zz || (diag && Math.abs(rr - r) === Math.abs(cc - c))) cand.delete(j);
    }
  };
  const units = (): number[][] => {
    const U: number[][] = [];
    for (let r = 0; r < n; r++) if (!usedRow.has(r)) U.push([...cand].filter((i) => Math.floor(i / n) === r));
    for (let c = 0; c < n; c++) if (!usedCol.has(c)) U.push([...cand].filter((i) => i % n === c));
    for (let k = 0; k < n; k++) {
      const key = k.toString(36);
      if (!usedZone.has(key)) U.push([...cand].filter((i) => z(i) === key));
    }
    return U;
  };
  const zonesOpen = (): string[] => {
    const a: string[] = [];
    for (let k = 0; k < n; k++) if (!usedZone.has(k.toString(36))) a.push(k.toString(36));
    return a;
  };
  const linesOf = (cells: number[], kind: "row" | "col"): Set<number> =>
    new Set(cells.map((i) => (kind === "row" ? Math.floor(i / n) : i % n)));
  while (placed.length < n) {
    const U = units();
    if (U.some((u) => u.length === 0)) return { solved: false, contradiction: true, tier, steps, placed };
    const single = U.find((u) => u.length === 1);
    if (single) {
      place(single[0]);
      steps.T1++;
      tier = Math.max(tier, 1);
      continue;
    }
    let progress = false;
    const tryTier = (t: number): boolean => {
      for (const k of t === 2 ? [1] : Array.from({ length: n - 2 }, (_, i) => i + 2)) {
        for (const kind of ["row", "col"] as const) {
          // k zona → k garis
          for (const zs of combos(zonesOpen(), k)) {
            const cells = [...cand].filter((i) => zs.includes(z(i)));
            const lines = linesOf(cells, kind);
            if (lines.size === k) {
              for (const j of [...cand]) {
                const ln = kind === "row" ? Math.floor(j / n) : j % n;
                if (lines.has(ln) && !zs.includes(z(j))) {
                  cand.delete(j);
                  progress = true;
                }
              }
            }
            if (progress) return true;
          }
          // k garis → k zona
          const openLines: number[] = [];
          for (let x = 0; x < n; x++) if (!(kind === "row" ? usedRow : usedCol).has(x)) openLines.push(x);
          for (const ls of combos(openLines, k)) {
            const cells = [...cand].filter((i) => ls.includes(kind === "row" ? Math.floor(i / n) : i % n));
            const zs = new Set(cells.map(z));
            if (zs.size === k) {
              for (const j of [...cand]) {
                const ln = kind === "row" ? Math.floor(j / n) : j % n;
                if (zs.has(z(j)) && !ls.includes(ln)) {
                  cand.delete(j);
                  progress = true;
                }
              }
            }
            if (progress) return true;
          }
        }
      }
      return false;
    };
    if (maxTier >= 2 && tryTier(2)) {
      steps.T2++;
      tier = Math.max(tier, 2);
      continue;
    }
    if (maxTier >= 3 && tryTier(3)) {
      steps.T3++;
      tier = Math.max(tier, 3);
      continue;
    }
    return { solved: false, contradiction: false, tier, steps, placed };
  }
  return { solved: true, tier, steps, placed, difficulty: steps.T1 + 3 * steps.T2 + 6 * steps.T3 };
}

// ---------- pembangkit ----------
function randomSolution(n: number, diag: boolean, rng: Rng): number[] | null {
  const cols: number[] = [];
  const used = new Set<number>();
  return (function rec(r: number): number[] | null {
    if (r === n) return cols.slice();
    for (const c of shuffle([...Array(n).keys()], rng)) {
      if (used.has(c)) continue;
      if (diag && cols.some((cc, rr) => Math.abs(rr - r) === Math.abs(cc - c))) continue;
      used.add(c);
      cols.push(c);
      const res = rec(r + 1);
      if (res) return res;
      cols.pop();
      used.delete(c);
    }
    return null;
  })(0);
}
type Grid = (number | "#" | null)[][];
function growZones(n: number, sol: number[], rng: Rng): Grid {
  const g: Grid = Array.from({ length: n }, () => new Array(n).fill(null));
  const ids = shuffle([...Array(n).keys()], rng);
  const frontier: [number, number][] = [];
  const nb = (r: number, c: number): [number, number][] =>
    (
      [
        [r + 1, c],
        [r - 1, c],
        [r, c + 1],
        [r, c - 1],
      ] as [number, number][]
    ).filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n);
  sol.forEach((c, r) => {
    g[r][c] = ids[r];
    frontier.push([r, c]);
  });
  let left = n * n - n;
  while (left > 0) {
    const fi = Math.floor(rng() * frontier.length);
    const [r, c] = frontier[fi];
    const free = nb(r, c).filter(([a, b]) => g[a][b] === null);
    if (!free.length) {
      frontier.splice(fi, 1);
      continue;
    }
    const [a, bb] = free[Math.floor(rng() * free.length)];
    g[a][bb] = g[r][c];
    frontier.push([a, bb]);
    left--;
  }
  return g;
}
export function zonesConnected(n: number, g: Grid): boolean {
  for (let k = 0; k < n; k++) {
    const cells: [number, number][] = [];
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === k) cells.push([r, c]);
    if (!cells.length) return false;
    const q: [number, number][] = [cells[0]];
    const vis = new Set<string>([cells[0].join()]);
    while (q.length) {
      const [r, c] = q.pop()!;
      for (const [a, b] of [
        [r + 1, c],
        [r - 1, c],
        [r, c + 1],
        [r, c - 1],
      ] as [number, number][])
        if (a >= 0 && b >= 0 && a < n && b < n && g[a][b] === k && !vis.has(a + "," + b)) {
          vis.add(a + "," + b);
          q.push([a, b]);
        }
    }
    if (vis.size !== cells.length) return false;
  }
  return true;
}
const toRows = (g: Grid): string[] =>
  g.map((row) => row.map((v) => (v === "#" ? "#" : (v as number).toString(36))).join(""));

// Setelah zona A kehilangan kotak: bagian A yang terputus dari kotak jawaban-aslinya diserap zona B
function absorbFragments(n: number, g: Grid, A: number, B: number, keepCell: number): void {
  const seen = new Set<number>([keepCell]);
  const q = [keepCell];
  while (q.length) {
    const cur = q.pop()!;
    const r = Math.floor(cur / n);
    const c = cur % n;
    for (const [a, b] of [
      [r + 1, c],
      [r - 1, c],
      [r, c + 1],
      [r, c - 1],
    ] as [number, number][]) {
      const j = a * n + b;
      if (a >= 0 && b >= 0 && a < n && b < n && g[a][b] === A && !seen.has(j)) {
        seen.add(j);
        q.push(j);
      }
    }
  }
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === A && !seen.has(r * n + c)) g[r][c] = B;
}

// Perbaikan zona: patahkan jawaban kedua tanpa menyentuh jawaban asli.
function repairUnique(n: number, g: Grid, sol: number[], rules: Rule[], rng: Rng, maxIter: number): boolean {
  const blocked = rules.includes("blocked");
  const solSet = new Set(sol.map((c, r) => r * n + c));
  const asBoard = (): ZoneBoard => ({ n, rules, zones: toRows(g) });
  for (let it = 0; it < maxIter; it++) {
    const sols = solutions(asBoard(), 2);
    if (sols.length === 1) return true;
    if (sols.length === 0) return false;
    const alt = sols[0].join() === sol.join() ? sols[1] : sols[0];
    const altCells = alt.map((c, r) => r * n + c);
    let fixed = false;
    const solOfZone = new Map<number | "#" | null, number>(sol.map((c, r) => [g[r][c], r * n + c]));
    const xs = shuffle(
      altCells.filter((i) => !solSet.has(i)),
      rng,
    );
    // Langkah 1: kotak x di tepi zona → pindahkan langsung ke zona tetangga
    for (const x of xs) {
      const r = Math.floor(x / n);
      const c = x % n;
      const A = g[r][c] as number;
      const opts = shuffle(
        (
          [
            [r + 1, c],
            [r - 1, c],
            [r, c + 1],
            [r, c - 1],
          ] as [number, number][]
        ).filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n && g[a][b] !== "#" && g[a][b] !== A),
        rng,
      );
      if (opts.length) {
        const B = g[opts[0][0]][opts[0][1]] as number;
        g[r][c] = B;
        absorbFragments(n, g, A, B, solOfZone.get(A)!);
        fixed = zonesConnected(n, g);
        if (fixed) break;
      }
      if (blocked) {
        g[r][c] = "#";
        if (zonesConnected(n, g)) {
          fixed = true;
          break;
        }
        g[r][c] = A;
      }
    }
    // Langkah 2: kotak x di tengah zona → zona tetangga menggali jalur terpendek ke x
    if (!fixed)
      for (const x of xs) {
        const r0 = Math.floor(x / n);
        const c0 = x % n;
        const A = g[r0][c0] as number;
        const prev = new Map<number, number>([[x, -1]]);
        const q = [x];
        let hit: { cell: number; zone: number } | null = null;
        for (let qi = 0; qi < q.length && !hit; qi++) {
          const cur = q[qi];
          const r = Math.floor(cur / n);
          const c = cur % n;
          for (const [a, b] of shuffle(
            [
              [r + 1, c],
              [r - 1, c],
              [r, c + 1],
              [r, c - 1],
            ] as [number, number][],
            rng,
          )) {
            if (a < 0 || b < 0 || a >= n || b >= n) continue;
            const j = a * n + b;
            const zz = g[a][b];
            if (zz === "#") continue;
            if (zz !== A) {
              hit = { cell: cur, zone: zz as number };
              break;
            }
            if (!prev.has(j) && !solSet.has(j)) {
              prev.set(j, cur);
              q.push(j);
            }
          }
        }
        if (!hit) continue;
        const path: number[] = [];
        for (let cur = hit.cell; cur !== -1; cur = prev.get(cur)!) path.push(cur);
        const backup = g.map((row) => row.slice());
        path.forEach((i) => {
          g[Math.floor(i / n)][i % n] = hit!.zone;
        });
        absorbFragments(n, g, A, hit.zone, solOfZone.get(A)!);
        if (zonesConnected(n, g)) {
          fixed = true;
          break;
        }
        backup.forEach((row, r) => {
          g[r] = row;
        });
      }
    if (!fixed) return false;
  }
  return solutions(asBoard(), 2).length === 1;
}

export function generateBoard(seed: string | number, opt: GenerateOptions): Board {
  const { n, rules, maxTier = 2, minTier = 1, band = [0, Infinity] } = opt;
  const diag = rules.includes("diag");
  const maxAttempts = opt.maxAttempts || 5000;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const rng = rngFrom(seed + "#" + attempt);
    const sol = randomSolution(n, diag, rng);
    if (!sol) continue;
    const g = growZones(n, sol, rng);
    if (rules.includes("blocked")) {
      const [lo, hi] = opt.blocked || [0, 0];
      const k = lo + Math.floor(rng() * (hi - lo + 1));
      const nonSol = shuffle(
        [...Array(n * n).keys()].filter((i) => sol[Math.floor(i / n)] !== i % n),
        rng,
      );
      let placedK = 0;
      for (const i of nonSol) {
        if (placedK === k) break;
        const r = Math.floor(i / n);
        const c = i % n;
        const prev = g[r][c];
        g[r][c] = "#";
        if (zonesConnected(n, g)) placedK++;
        else g[r][c] = prev;
      }
      if (placedK < k) continue;
    }
    if (!repairUnique(n, g, sol, rules, rng, n * n * 2)) continue;
    const b: Board = { id: null, n, rules: rules.slice(), zones: toRows(g), solution: sol };
    if (solutions(b, 2).length !== 1) continue;
    const ls = logicSolve(b, maxTier);
    if (!ls.solved || ls.tier < minTier || ls.difficulty! < band[0] || ls.difficulty! > band[1]) continue;
    b.tier = ("T" + ls.tier) as Tier;
    b.difficulty = ls.difficulty!;
    b.steps = ls.steps;
    return b;
  }
  throw new Error("generateBoard gagal: " + seed);
}

// ---------- keadilan: 8 simetri + acak nomor zona ----------
export function tcell(n: number, r: number, c: number, k: number): Cell {
  if (k >= 4) c = n - 1 - c;
  for (let i = 0; i < k % 4; i++) {
    const nr = c;
    const nc = n - 1 - r;
    r = nr;
    c = nc;
  }
  return { r, c };
}
export function inverseCell(n: number, r: number, c: number, k: number): Cell {
  for (let i = 0; i < (4 - (k % 4)) % 4; i++) {
    const nr = c;
    const nc = n - 1 - r;
    r = nr;
    c = nc;
  }
  if (k >= 4) c = n - 1 - c;
  return { r, c };
}
export function transformBoard(b: Board, k: number, zonePerm?: number[] | null): Board {
  const n = b.n;
  const g: string[][] = Array.from({ length: n }, () => new Array<string>(n));
  for (let r = 0; r < n; r++)
    for (let c = 0; c < n; c++) {
      const t = tcell(n, r, c, k);
      const ch = b.zones[r][c];
      g[t.r][t.c] = ch === "#" ? "#" : zonePerm ? zonePerm[parseInt(ch, 36)].toString(36) : ch;
    }
  const out: Board = { ...b, zones: g.map((x) => x.join("")), transform: k, zonePerm: zonePerm || null };
  if (b.solution) {
    const s = new Array<number>(n);
    b.solution.forEach((c, r) => {
      const t = tcell(n, r, c, k);
      s[t.r] = t.c;
    });
    out.solution = s;
  }
  return out;
}

// Bentuk kanonik (untuk membuang papan kembar di bank)
export function canonical(b: ZoneBoard): string {
  let best: string | null = null;
  for (let k = 0; k < 8; k++) {
    const t = transformBoard({ id: null, n: b.n, rules: b.rules, zones: b.zones }, k);
    const map: Record<string, string> = {};
    let next = 0;
    const s = t.zones
      .map((row) =>
        row
          .split("")
          .map((ch) => (ch === "#" ? "#" : (map[ch] ??= (next++).toString(36))))
          .join(""),
      )
      .join("/");
    if (best === null || s < best) best = s;
  }
  return best as string;
}

export const publicBoard = (b: PublicBoard): PublicBoard => ({ id: b.id, n: b.n, rules: b.rules, zones: b.zones });
export const solutionCells = (b: { solution?: number[] }): Cell[] => b.solution!.map((c, r) => ({ r, c }));
export function matchesSolution(b: Board, gems: Cell[]): boolean {
  if (gems.length !== b.n) return false;
  const s = new Set(solutionCells(b).map((x) => x.r + "," + x.c));
  return gems.every((g) => s.has(g.r + "," + g.c));
}

// ---------- bantuan: buka satu permata benar ----------
export function hintCell(b: Board, gems: Cell[], locked: Cell[] = []): Cell | null {
  const key = (x: Cell): string => x.r + "," + x.c;
  const gemSet = new Set(gems.map(key));
  const lockSet = new Set(locked.map(key));
  const zoneSize: Record<string, number> = {};
  for (const row of b.zones) for (const ch of row) zoneSize[ch] = (zoneSize[ch] || 0) + 1;
  const sol = solutionCells(b).filter((x) => !lockSet.has(key(x)));
  const missing = sol.filter((x) => !gemSet.has(key(x)));
  const pool = missing.length ? missing : sol;
  pool.sort((a, q) => zoneSize[b.zones[a.r][a.c]] - zoneSize[b.zones[q.r][q.c]] || a.r - q.r || a.c - q.c);
  return pool[0] || null;
}

// ---------- replay langkah ----------
export function replay(moves: Move[]): { gems: Cell[]; xs: Cell[]; locked: string[] } {
  const gems = new Map<string, Cell>();
  const xs = new Set<string>();
  const locked = new Set<string>();
  for (const m of moves) {
    const k = m.r + "," + m.c;
    if (m.op === "gem") {
      gems.set(k, { r: m.r, c: m.c });
      xs.delete(k);
    } else if (m.op === "clear") {
      if (!locked.has(k)) gems.delete(k);
    } else if (m.op === "x") {
      if (!gems.has(k)) xs.add(k);
    } else if (m.op === "unx") xs.delete(k);
    else if (m.op === "hint") {
      gems.set(k, { r: m.r, c: m.c });
      locked.add(k);
      xs.delete(k);
    }
  }
  const sortRC = (a: Cell, b: Cell): number => a.r - b.r || a.c - b.c;
  return {
    gems: [...gems.values()].sort(sortRC),
    xs: [...xs]
      .map((s) => {
        const [r, c] = s.split(",").map(Number);
        return { r, c };
      })
      .sort(sortRC),
    locked: [...locked],
  };
}

// ---------- pembagian papan ke pemain (sampai 40 orang) ----------
export interface Assignment {
  seq: number;
  boardId: string;
  transform: number;
  zonePerm: number[];
  reuse: number;
}
export function assignBoards(
  playerIds: string[],
  pools: { id: string; n: number }[][],
  seed: string | number,
): Record<string, Assignment[]> {
  const rng = rngFrom("assign|" + seed);
  const out: Record<string, Assignment[]> = {};
  const plan = pools.map((pool) => ({
    offset: Math.floor(rng() * pool.length),
    baseK: pool.map(() => Math.floor(rng() * 7)),
  }));
  playerIds.forEach((pid, i) => {
    out[pid] = pools.map((pool, s) => {
      const P = pool.length;
      const idx = (plan[s].offset + i) % P;
      const round = Math.floor(i / P);
      const base = pool[idx];
      const k = 1 + ((plan[s].baseK[idx] + round) % 7);
      const perm = shuffle([...Array(base.n).keys()], rng);
      return { seq: s + 1, boardId: base.id, transform: k, zonePerm: perm, reuse: round };
    });
  });
  return out;
}

// ---------- tahap yang diatur guru ----------
const RULESET = (s: Stage): string => (s.arsir ? (s.diagonal ? "ad" : "a") : s.diagonal ? "d" : "x");
export function rulesFor(stage: { arsir?: boolean; diagonal?: boolean }): Rule[] {
  const r: Rule[] = ["row", "col", "zone"];
  if (stage.arsir) r.push("blocked");
  if (stage.diagonal) r.push("diag");
  return r;
}
export const poolKey = (stage: Stage): string => `LR${stage.n}${RULESET(stage)}`;
export function validateStage(st: Stage): string[] {
  const err: string[] = [];
  if (!Number.isInteger(st.n) || st.n < MIN_N || st.n > MAX_N) err.push(`ukuran harus ${MIN_N}–${MAX_N}`);
  if (!["mudah", "sedang", "sulit"].includes(st.level || "sedang")) err.push("level harus mudah/sedang/sulit");
  if (st.diagonal && st.n < 4) err.push("aturan diagonal (R5) butuh ukuran minimal 4×4");
  return err;
}
export function pickByLevel<T extends { id: string; difficulty: number }>(
  pool: T[],
  level: Level = "sedang",
  count = 40,
): T[] {
  const sorted = pool.slice().sort((a, b) => a.difficulty - b.difficulty);
  const target =
    sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * { mudah: 0.2, sedang: 0.5, sulit: 0.8 }[level]))]
      .difficulty;
  return sorted
    .slice()
    .sort((a, b) => Math.abs(a.difficulty - target) - Math.abs(b.difficulty - target) || a.id.localeCompare(b.id))
    .slice(0, Math.min(count, sorted.length));
}
export const TARGET_MENIT: Record<number, number> = { 3: 0.5, 4: 1, 5: 2.5, 6: 4.5, 7: 6, 8: 8, 9: 10, 10: 12 };
export const suggestMinutes = (stages: Stage[]): number =>
  Math.ceil(stages.reduce((a, s) => a + TARGET_MENIT[s.n] * (s.diagonal ? 1.2 : 1), 0));
export const marathonPoints = (n: number): number => Math.round(2.5 * n * n - 12.5 * n + 20);

// ---------- peringkat ----------
export interface RankRun {
  id: string;
  done: number;
  lastFinishMs: number | null;
  hints: number;
}
export function rank<T extends RankRun>(runs: T[]): (T & { rank: number })[] {
  const sorted = runs
    .slice()
    .sort(
      (a, b) => b.done - a.done || (a.lastFinishMs ?? Infinity) - (b.lastFinishMs ?? Infinity) || a.hints - b.hints,
    );
  let pos = 0;
  let prev: string | null = null;
  return sorted.map((r, i) => {
    const key = [r.done, r.lastFinishMs, r.hints].join("|");
    if (key !== prev) {
      pos = i + 1;
      prev = key;
    }
    return { ...r, rank: pos };
  });
}

export const _internal = { randomSolution, growZones, repairUnique, toRows };

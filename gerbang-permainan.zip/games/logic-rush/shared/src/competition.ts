// Format kompetisi ala RTC: pertandingan 2–3 pemain, papan dasar sama, best-of-N. Fungsi murni.
import { rngFrom } from "./engine";
import {
  BONUS_MENANG_PERTANDINGAN,
  POIN_PERINGKAT,
  UKURAN_PERTANDINGAN_MAKS,
  UKURAN_PERTANDINGAN_MIN,
} from "./settings";

/** Hasil satu pemain dalam satu game. `ms` = waktu efektif (waktu nyata + penalti bantuan); null = tidak selesai. */
export interface HasilPemainGame {
  pid: string;
  ms: number | null;
  gems: number;
  hints: number;
  /** papan yang sudah tuntas dalam game ini (game satu papan: 0 atau 1) */
  done?: number;
}
export interface PeringkatGame extends HasilPemainGame {
  rank: number;
  poin: number;
  menang: boolean;
}

/** Urutan game: selesai lebih cepat dulu (ms, lalu bantuan); yang tidak selesai menyusul menurut jumlah permata. */
export function peringkatGame(hasil: HasilPemainGame[], tabel: readonly number[] = POIN_PERINGKAT): PeringkatGame[] {
  const sorted = hasil.slice().sort((a, b) => {
    const fa = a.ms !== null;
    const fb = b.ms !== null;
    if (fa !== fb) return fa ? -1 : 1;
    if (fa && fb) return (a.ms as number) - (b.ms as number) || a.hints - b.hints;
    return (b.done ?? 0) - (a.done ?? 0) || b.gems - a.gems || a.hints - b.hints;
  });
  let pos = 0;
  let prev: string | null = null;
  return sorted.map((h, i) => {
    const key = h.ms !== null ? `f|${h.ms}|${h.hints}` : `u|${h.done ?? 0}|${h.gems}|${h.hints}`;
    if (key !== prev) {
      pos = i + 1;
      prev = key;
    }
    const selesai = h.ms !== null;
    return { ...h, rank: pos, poin: selesai ? (tabel[pos - 1] ?? 0) : 0, menang: selesai && pos === 1 };
  });
}

export interface RingkasGame {
  no: number;
  hasil: PeringkatGame[];
  /** true bila tidak ada yang menyelesaikan papan (game tanpa pemenang). */
  tanpaPemenang: boolean;
}

export interface StatusPertandingan {
  menang: Record<string, number>;
  /** Game yang dibutuhkan untuk menang (mayoritas dari best-of-N). */
  perluMenang: number;
  selesai: boolean;
  pemenang: string | null;
  seri: boolean;
}

export const perluMenang = (bestOf: number): number => Math.floor(bestOf / 2) + 1;

/** Status pertandingan dari daftar game yang sudah selesai. `batasMs` = nilai pengganti waktu untuk game tidak selesai. */
export function statusPertandingan(
  pemain: string[],
  games: RingkasGame[],
  bestOf: number,
  batasMs: number,
  gameTambahan = 0,
  massal = false,
): StatusPertandingan {
  const menang: Record<string, number> = Object.fromEntries(pemain.map((p) => [p, 0]));
  const waktu: Record<string, number> = Object.fromEntries(pemain.map((p) => [p, 0]));
  const bantuan: Record<string, number> = Object.fromEntries(pemain.map((p) => [p, 0]));
  const poin: Record<string, number> = Object.fromEntries(pemain.map((p) => [p, 0]));
  for (const g of games)
    for (const h of g.hasil) {
      if (h.menang) menang[h.pid] += 1;
      waktu[h.pid] += h.ms ?? batasMs;
      bantuan[h.pid] += h.hints;
      poin[h.pid] += h.poin;
    }
  const need = perluMenang(bestOf);
  const maks = Math.max(0, ...Object.values(menang));
  // Format massal: semua game dimainkan; pemenang = poin game terbanyak (bukan mayoritas kemenangan)
  const selesaiMayoritas = !massal && maks >= need;
  const habis = games.length >= bestOf + gameTambahan;
  if (!selesaiMayoritas && !habis) return { menang, perluMenang: need, selesai: false, pemenang: null, seri: false };
  if (massal) {
    const u = pemain
      .slice()
      .sort((a, b) => poin[b] - poin[a] || menang[b] - menang[a] || waktu[a] - waktu[b] || bantuan[a] - bantuan[b]);
    const [a, b] = u;
    const sm =
      b !== undefined &&
      poin[a] === poin[b] &&
      menang[a] === menang[b] &&
      waktu[a] === waktu[b] &&
      bantuan[a] === bantuan[b];
    const seriM = sm || Math.max(0, ...Object.values(poin)) === 0;
    return { menang, perluMenang: need, selesai: true, pemenang: seriM ? null : a, seri: seriM };
  }
  // Penentuan: kemenangan terbanyak → waktu total terkecil → bantuan paling sedikit
  const urut = pemain.slice().sort((a, b) => menang[b] - menang[a] || waktu[a] - waktu[b] || bantuan[a] - bantuan[b]);
  const [p1, p2] = urut;
  const sama = p2 !== undefined && menang[p1] === menang[p2] && waktu[p1] === waktu[p2] && bantuan[p1] === bantuan[p2];
  // Tanpa satu pun kemenangan (tak ada yang menyelesaikan papan) → seri, walau waktu pengganti berbeda
  const seri = sama || maks === 0;
  return { menang, perluMenang: need, selesai: true, pemenang: seri ? null : p1, seri };
}

/** Skor satu pemain di seluruh sesi: poin tiap game + bonus tiap pertandingan yang dimenangkan. */
export function skorPemain(
  pid: string,
  matches: { pemain: string[]; games: RingkasGame[]; pemenang: string | null }[],
): number {
  let total = 0;
  for (const m of matches) {
    for (const g of m.games) total += g.hasil.find((h) => h.pid === pid)?.poin ?? 0;
    if (m.pemenang === pid) total += BONUS_MENANG_PERTANDINGAN;
  }
  return total;
}

// ---------------------------------------------------------------- antrean & bracket

/** Bagi `ids` ke kelompok 2–3 orang, tak pernah 1. `ukuran` = target (2 atau 3). Urutan diacak deterministik oleh `seed`. */
export function buatKelompok(ids: string[], ukuran: number, seed: string | number): string[][] {
  const n = ids.length;
  if (n < UKURAN_PERTANDINGAN_MIN) return [];
  const rng = rngFrom("kelompok|" + seed);
  const a = ids.slice();
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  const ukur = ukuran >= UKURAN_PERTANDINGAN_MAKS ? UKURAN_PERTANDINGAN_MAKS : UKURAN_PERTANDINGAN_MIN;
  // Target 3: ceil(n/3) kelompok (4 → 2+2, 7 → 3+2+2). Target 2: floor(n/2) kelompok (5 → 3+2). Selalu 2..3 orang per kelompok.
  const k = Math.max(1, ukur === UKURAN_PERTANDINGAN_MAKS ? Math.ceil(n / ukur) : Math.floor(n / ukur));
  // ukuran dasar floor(n/k), sisanya dibagi satu per satu
  const base = Math.floor(n / k);
  let extra = n - base * k;
  const out: string[][] = [];
  let i = 0;
  for (let g = 0; g < k; g++) {
    const size = base + (extra > 0 ? 1 : 0);
    if (extra > 0) extra--;
    out.push(a.slice(i, i + size));
    i += size;
  }
  return out;
}

/** Babak berikutnya: satu pemenang per pertandingan maju; seri → semua yang seri maju. Mengembalikan null bila sudah juara. */
export function pemajuBabak(hasil: { pemain: string[]; pemenang: string | null; seri: boolean }[]): string[] {
  const maju: string[] = [];
  for (const m of hasil) {
    if (m.pemenang) maju.push(m.pemenang);
    else maju.push(...m.pemain); // seri: belum ada yang gugur, guru dapat memainkan game tambahan
  }
  return maju;
}

export function batasKelompok(n: number): { bisa: boolean; alasan?: string } {
  if (n < UKURAN_PERTANDINGAN_MIN) return { bisa: false, alasan: "Butuh minimal 2 pemain untuk satu pertandingan." };
  return { bisa: true };
}

// ---------------------------------------------------------------- papan peringkat langsung (selama game berjalan)
export interface BarisLangsung {
  pid: string;
  /** papan tuntas dan jumlah papan dalam game */
  done: number;
  total: number;
  /** ukuran papan yang sedang dikerjakan (untuk teks kemajuan) */
  n?: number;
  gems: number;
  selesaiMs: number | null;
  hints: number;
  pelanggaran: number;
}
export interface PeringkatLangsung extends BarisLangsung {
  rank: number;
}
/** Selesai lebih cepat di atas; yang belum selesai menurut permata terbanyak, lalu bantuan paling sedikit. Seri berbagi nomor. */
export function peringkatLangsung(baris: BarisLangsung[]): PeringkatLangsung[] {
  const s = baris.slice().sort((a, b) => {
    const fa = a.selesaiMs !== null;
    const fb = b.selesaiMs !== null;
    if (fa !== fb) return fa ? -1 : 1;
    if (fa && fb)
      return (a.selesaiMs as number) - (b.selesaiMs as number) || a.hints - b.hints || a.pid.localeCompare(b.pid);
    return (
      b.done - a.done ||
      b.gems - a.gems ||
      a.hints - b.hints ||
      a.pelanggaran - b.pelanggaran ||
      a.pid.localeCompare(b.pid)
    );
  });
  let pos = 0;
  let prev = "";
  return s.map((r, i) => {
    const key = r.selesaiMs !== null ? `f|${r.selesaiMs}|${r.hints}` : `u|${r.done}|${r.gems}|${r.hints}`;
    if (key !== prev) {
      pos = i + 1;
      prev = key;
    }
    return { ...r, rank: pos };
  });
}

// Protokol klien ↔ server. Server adalah wasit: `solution` tidak pernah ada di tipe publik di bawah ini.
import { z } from "zod";
import type { PublicBoard } from "./engine";
import type { PeringkatGame } from "./competition";
import type { SesiSettings } from "./settings";

// ---------------------------------------------------------------- tipe publik (server → semua)
export type KameraStatus = "mati" | "meminta" | "diizinkan" | "menyala";
export type StatusSesi = "lobi" | "berjalan" | "selesai";
export type StatusMatch = "antre" | "siap" | "hitung" | "main" | "rehat" | "selesai" | "batal";

export interface PemainPublik {
  id: string;
  nama: string;
  absen: number | null;
  terhubung: boolean;
  kamera: KameraStatus;
  mikrofon: boolean;
}
export interface TahapPublik {
  n: number;
  arsir: boolean;
  diagonal: boolean;
}
export interface PemainLive {
  /** papan yang sudah tuntas dan jumlah papan dalam game ini */
  papanSelesai: number;
  papanTotal: number;
  gems: number;
  hints: number;
  /** waktu efektif (ms) bila sudah selesai */
  selesaiMs: number | null;
  /** jumlah pelanggaran aturan yang sedang tampak di papan */
  pelanggaran: number;
}
export interface GameLive {
  no: number;
  stage: TahapPublik;
  /** tahap tiap papan dalam game ini */
  stages: TahapPublik[];
  /** aturan yang baru muncul dibanding game sebelumnya (kartu aturan baru) */
  aturanBaru: string[];
  /** detik hitung mundur berakhir (epoch ms server); null bila tidak sedang hitung */
  hitungSampaiTs: number | null;
  mulaiTs: number | null;
  deadlineTs: number | null;
  pemain: Record<string, PemainLive>;
  /** format massal: pemain yang sedang disorot dan kapan sorotan berganti (epoch ms server) */
  sorotPid: string | null;
  sorotSampaiTs: number | null;
}
export interface GameSelesaiPublik {
  no: number;
  stage: TahapPublik;
  stages: TahapPublik[];
  hasil: PeringkatGame[];
  tanpaPemenang: boolean;
}
export interface MatchPublik {
  id: string;
  babak: number;
  nomor: number;
  pemain: string[];
  bestOf: number;
  status: StatusMatch;
  siap: Record<string, boolean>;
  menang: Record<string, number>;
  perluMenang: number;
  games: GameSelesaiPublik[];
  game: GameLive | null;
  pemenang: string | null;
  seri: boolean;
  jeda: boolean;
  /** true = format massal (di atas 3 pemain): tanpa kamera/RTC */
  massal: boolean;
}
export interface SkorPublik {
  pid: string;
  skor: number;
  pertandinganMenang: number;
  pertandingan: number;
  gameMenang: number;
  gameMain: number;
  kalah: number;
}
export interface SettingsPublik extends Omit<SesiSettings, "kamera"> {
  kamera: Pick<SesiSettings["kamera"], "mode" | "mikrofon" | "siapaBolehLihat">;
}
export interface StatePublik {
  v: 1;
  serverTs: number;
  sesi: { id: string; nama: string; status: StatusSesi; babak: number; adaDaftarHadir: boolean };
  settings: SettingsPublik;
  pemain: PemainPublik[];
  matches: MatchPublik[];
  aktif: string | null;
  skor: SkorPublik[];
}
export interface HostExtra {
  pin: string;
  obsKey: string;
  kameraMinta: string[];
  flags: { pid: string; tipe: string; ts: number; detail?: string }[];
  /** jumlah penonton video per pemain */
  penontonVideo: Record<string, number>;
}

// ---------------------------------------------------------------- pemain
export interface BoardKirim {
  matchId: string;
  gameNo: number;
  /** papan ke berapa dalam game ini (mulai 1) dan jumlah papan */
  boardNo: number;
  boardTotal: number;
  /** nomor urut spectate terakhir yang diketahui server (pemain melanjutkan dari lastS+1) */
  lastS: number;
  board: PublicBoard;
  serverTs: number;
  hitungSampaiTs: number | null;
  mulaiTs: number | null;
  deadlineTs: number | null;
  aturanBaru: string[];
  bantuanSisa: number;
  penaltiDetik: number;
  /** keadaan permata saat sambung ulang */
  gems: { r: number; c: number }[];
  xs: { r: number; c: number }[];
  locked: string[];
  hintsPakai: number;
}

export type FinishResult =
  | { ok: true; ms: number; rank: number; lanjut?: boolean; boardNo?: number; boardTotal?: number }
  | { ok: false; alasan: "bukan-game-aktif" | "belum-lengkap" | "sudah-selesai" | "bukan-peserta" | "salah" };

// ---------------------------------------------------------------- skema masukan (tidak dipercaya)
export const cellSchema = z.object({ r: z.number().int().min(0).max(9), c: z.number().int().min(0).max(9) });
export const joinSchema = z.object({
  pin: z.string().regex(/^\d{6}$/),
  nama: z.string().trim().min(1).max(32).optional(),
  siswaId: z.union([z.string().max(64), z.number()]).optional(),
  token: z.string().max(100).optional(),
  deviceId: z.string().max(64).optional(),
});
export const finishSchema = z.object({
  boardNo: z.number().int().min(1).max(6).optional(),
  matchId: z.string().max(40),
  gameNo: z.number().int().min(1).max(99),
  gems: z.array(cellSchema).max(10),
});
export const hintSchema = z.object({
  matchId: z.string().max(40),
  gameNo: z.number().int().min(1).max(99),
  gems: z.array(cellSchema).max(10),
});
export const rosterSchema = z.array(
  z.object({
    siswaId: z.union([z.string().max(64), z.number()]),
    nama: z.string().trim().min(1).max(60),
    absen: z.number().int().min(0).max(999).nullable().optional(),
  }),
);
export type RosterItem = z.infer<typeof rosterSchema>[number];

// WebRTC: sinyal murni (SDP/ICE) — server tidak pernah memegang media.
export const sdpSchema = z.object({ type: z.enum(["offer", "answer"]), sdp: z.string().max(20000) });
export const iceSchema = z.object({}).passthrough();
export const rtcWatchSchema = z.object({ pid: z.string().max(40), wantVideo: z.boolean().default(true) });
export const rtcOfferSchema = z.object({ viewerId: z.string().max(40), sdp: sdpSchema });
export const rtcAnswerSchema = z.object({ pid: z.string().max(40), sdp: sdpSchema });
export const rtcIceSchema = z.object({
  pid: z.string().max(40).optional(),
  viewerId: z.string().max(40).optional(),
  candidate: iceSchema,
});

// ---------------------------------------------------------------- ringkasan hasil (Hall of Fame di SIMPETERI)
export interface RingkasanSiswa {
  siswaId: string | number | null;
  nama: string;
  absen: number | null;
  skor: number;
  peringkat: number;
  pertandingan: number;
  pertandinganMenang: number;
  gameMenang: number;
  gameMain: number;
  bantuan: number;
  waktuMs: number;
}
export interface RingkasanLogicRush {
  game: "logic-rush";
  versi: 1;
  sesiId: string;
  nama: string;
  selesai: boolean;
  dibuat: number;
  siswa: RingkasanSiswa[];
}

// ---------------------------------------------------------------- statistik hasil (validasi dan jawaban per papan)
export interface StatistikPapan {
  /** papan ke berapa dalam game (mulai 1) */
  boardNo: number;
  matchId: string;
  babak: number;
  laga: number;
  gameNo: number;
  /** id papan dasar; di format massal berisi beberapa papan dasar */
  papan: string[];
  n: number;
  arsir: boolean;
  diagonal: boolean;
  pemain: number;
  selesai: number;
  validasi: number;
  benar: number;
  salah: number;
  waktuMedianMs: number | null;
  waktuTercepatMs: number | null;
  bantuan: number;
  tanpaPemenang: boolean;
}
export interface StatistikPemain {
  pid: string;
  nama: string;
  validasi: number;
  benar: number;
  salah: number;
  game: number;
  selesai: number;
}
export interface Statistik {
  validasi: { total: number; benar: number; salah: number };
  papan: StatistikPapan[];
  pemain: StatistikPemain[];
}

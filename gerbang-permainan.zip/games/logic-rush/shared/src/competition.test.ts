import { describe, expect, it } from "vitest";
import { batasWaktuGameMs, defaultSettings, stageForGame, validateSettings } from "./settings";
import { buatKelompok, peringkatGame, pemajuBabak, skorPemain, statusPertandingan } from "./competition";
import type { RingkasGame } from "./competition";

const game = (no: number, h: { pid: string; ms: number | null; gems?: number; hints?: number }[]): RingkasGame => {
  const hasil = peringkatGame(h.map((x) => ({ pid: x.pid, ms: x.ms, gems: x.gems ?? 0, hints: x.hints ?? 0 })));
  return { no, hasil, tanpaPemenang: !hasil.some((x) => x.menang) };
};

describe("pengaturan sesi", () => {
  it("bawaan sah; ukuran di luar 3–10 dan diagonal 3×3 ditolak di server", () => {
    expect(validateSettings(defaultSettings()).ok).toBe(true);
    const s = { ...defaultSettings(), tahap: [{ n: 11, arsir: false, diagonal: false, level: "sedang" }] };
    expect(validateSettings(s).ok).toBe(false);
    const d = { ...defaultSettings(), tahap: [{ n: 3, arsir: false, diagonal: true, level: "sedang" }] };
    const r = validateSettings(d);
    expect(r.ok).toBe(false);
    if (!r.ok) expect(r.errors.join(" ")).toMatch(/diagonal/);
    expect(validateSettings({ ...defaultSettings(), tahap: [] }).ok).toBe(false);
    expect(validateSettings({ ...defaultSettings(), ukuranPertandingan: 4 }).ok).toBe(false);
    expect(validateSettings({ ...defaultSettings(), ukuranPertandingan: 1 }).ok).toBe(false);
  });
  it("kamera hanya sah bila izin orang tua dikonfirmasi guru", () => {
    const k = { ...defaultSettings(), kamera: { ...defaultSettings().kamera, mode: "opsional" as const } };
    expect(validateSettings(k).ok).toBe(false);
    expect(validateSettings({ ...k, kamera: { ...k.kamera, izinOrtuDikonfirmasi: true } }).ok).toBe(true);
    expect(validateSettings({ ...defaultSettings(), kamera: { ...defaultSettings().kamera, mikrofon: true } }).ok).toBe(
      false,
    );
  });
  it("tahap berulang menurut nomor game; batas waktu otomatis dari ukuran", () => {
    const s = defaultSettings();
    expect(stageForGame(s, 0).n).toBe(4);
    expect(stageForGame(s, 3).n).toBe(4);
    const satuPapan = { ...s, papanPerGame: 1 };
    expect(batasWaktuGameMs(satuPapan, 1)).toBeGreaterThan(batasWaktuGameMs(satuPapan, 0));
    expect(batasWaktuGameMs({ ...s, batasWaktuDetik: 90 }, 0)).toBe(90_000);
  });
});

describe("kelompok pertandingan 2–3 pemain", () => {
  it("tak pernah satu orang dan tak pernah lebih dari tiga, untuk 2..40 pemain", () => {
    for (let n = 2; n <= 40; n++) {
      const ids = Array.from({ length: n }, (_, i) => "p" + i);
      for (const ukuran of [2, 3]) {
        const gs = buatKelompok(ids, ukuran, "s");
        expect(gs.flat().sort()).toEqual(ids.slice().sort());
        for (const g of gs) {
          expect(g.length).toBeGreaterThanOrEqual(2);
          expect(g.length).toBeLessThanOrEqual(3);
        }
      }
    }
    expect(buatKelompok(["a"], 2, "s")).toEqual([]);
    expect(buatKelompok(["a", "b", "c", "d"], 3, "s").map((g) => g.length)).toEqual([2, 2]);
    expect(
      buatKelompok(
        Array.from({ length: 7 }, (_, i) => "p" + i),
        3,
        "s",
      ).map((g) => g.length),
    ).toEqual([3, 2, 2]);
    expect(buatKelompok(["a", "b", "c", "d", "e"], 2, "s").map((g) => g.length)).toEqual([3, 2]);
  });
  it("deterministik menurut seed", () => {
    const ids = Array.from({ length: 9 }, (_, i) => "p" + i);
    expect(buatKelompok(ids, 3, "x")).toEqual(buatKelompok(ids, 3, "x"));
    expect(buatKelompok(ids, 3, "x")).not.toEqual(buatKelompok(ids, 3, "y"));
  });
});

describe("peringkat game & status pertandingan", () => {
  it("yang selesai lebih cepat menang; yang tidak selesai di bawah; seri berbagi peringkat", () => {
    const r = peringkatGame([
      { pid: "a", ms: 9000, gems: 4, hints: 0 },
      { pid: "b", ms: null, gems: 3, hints: 0 },
      { pid: "c", ms: 7000, gems: 4, hints: 1 },
    ]);
    expect(r.map((x) => x.pid + x.rank)).toEqual(["c1", "a2", "b3"]);
    expect(r.map((x) => x.poin)).toEqual([5, 3, 0]);
    expect(r[0].menang).toBe(true);
    const seri = peringkatGame([
      { pid: "a", ms: 5000, gems: 4, hints: 0 },
      { pid: "b", ms: 5000, gems: 4, hints: 0 },
    ]);
    expect(seri.every((x) => x.menang && x.rank === 1)).toBe(true);
  });
  it("best-of-3: berhenti begitu ada yang 2 kemenangan", () => {
    const g1 = game(1, [
      { pid: "a", ms: 5000 },
      { pid: "b", ms: 7000 },
    ]);
    const g2 = game(2, [
      { pid: "a", ms: 5000 },
      { pid: "b", ms: 4000 },
    ]);
    const g3 = game(3, [
      { pid: "a", ms: 3000 },
      { pid: "b", ms: 4000 },
    ]);
    expect(statusPertandingan(["a", "b"], [g1], 3, 60000).selesai).toBe(false);
    expect(statusPertandingan(["a", "b"], [g1, g2], 3, 60000).selesai).toBe(false);
    const st = statusPertandingan(["a", "b"], [g1, g2, g3], 3, 60000);
    expect(st).toMatchObject({ selesai: true, pemenang: "a", seri: false });
    expect(
      statusPertandingan(
        ["a", "b"],
        [
          g1,
          game(2, [
            { pid: "a", ms: 1 },
            { pid: "b", ms: 2 },
          ]),
        ],
        3,
        60000,
      ),
    ).toMatchObject({ selesai: true, pemenang: "a" });
  });
  it("trio 1-1-1: ditentukan waktu total lalu bantuan; tanpa pemenang sama sekali = seri", () => {
    const gs = [
      game(1, [
        { pid: "a", ms: 1000 },
        { pid: "b", ms: 9000 },
        { pid: "c", ms: 9500 },
      ]),
      game(2, [
        { pid: "a", ms: 9000 },
        { pid: "b", ms: 1000 },
        { pid: "c", ms: 9500 },
      ]),
      game(3, [
        { pid: "a", ms: 9000 },
        { pid: "b", ms: 9500 },
        { pid: "c", ms: 1000 },
      ]),
    ];
    const st = statusPertandingan(["a", "b", "c"], gs, 3, 60000);
    expect(st.selesai).toBe(true);
    expect(st.menang).toEqual({ a: 1, b: 1, c: 1 });
    expect(st.pemenang).toBe("a"); // waktu total a = 19000 < b 19500 < c 20000
    const kosong = [
      game(1, [
        { pid: "a", ms: null },
        { pid: "b", ms: null },
      ]),
    ];
    expect(statusPertandingan(["a", "b"], kosong, 1, 60000)).toMatchObject({
      selesai: true,
      seri: true,
      pemenang: null,
    });
  });
  it("game tambahan memperpanjang pertandingan seri", () => {
    const g1 = game(1, [
      { pid: "a", ms: 1000 },
      { pid: "b", ms: null },
    ]);
    const g2 = game(2, [
      { pid: "a", ms: null },
      { pid: "b", ms: 1000 },
    ]);
    expect(statusPertandingan(["a", "b"], [g1, g2], 2 as 1, 1000).selesai).toBe(true);
    expect(statusPertandingan(["a", "b"], [g1, g2], 2 as 1, 1000, 1).selesai).toBe(false);
  });
  it("skor sesi = poin game + bonus menang pertandingan; babak berikut membawa pemenang", () => {
    const g = game(1, [
      { pid: "a", ms: 1000 },
      { pid: "b", ms: 2000 },
    ]);
    const m = [{ pemain: ["a", "b"], games: [g], pemenang: "a" as string | null }];
    expect(skorPemain("a", m)).toBe(5 + 5);
    expect(skorPemain("b", m)).toBe(3);
    expect(
      pemajuBabak([
        { pemain: ["a", "b"], pemenang: "a", seri: false },
        { pemain: ["c", "d"], pemenang: null, seri: true },
      ]),
    ).toEqual(["a", "c", "d"]);
  });
});

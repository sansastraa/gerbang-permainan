// Bukti "tanpa mengubah perilaku": port TS dibandingkan dengan berkas JS asli pada banyak masukan.
import { createRequire } from "node:module";
import { describe, expect, it } from "vitest";
import * as E from "./engine";
import * as S from "./spectate";
import { loadBankIndex, loadPool } from "./bank-node";

const require = createRequire(import.meta.url);
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const R: any = require("../reference/lr-engine.cjs");
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const RS: any = require("../reference/spectate-protocol.cjs");

describe("paritas engine TS ↔ referensi JS", () => {
  it("generateBoard menghasilkan papan identik untuk seed yang sama", { timeout: 120_000 }, () => {
    for (let n = 3; n <= 8; n++)
      for (const st of [{}, { arsir: true }, { diagonal: true }, { arsir: true, diagonal: true }]) {
        if (n < 4 && (st as { diagonal?: boolean }).diagonal) continue;
        for (let i = 0; i < 4; i++) {
          const o = {
            n,
            rules: E.rulesFor(st),
            blocked: [Math.floor(n / 2), n - 1] as [number, number],
            maxTier: 2,
            maxAttempts: 200,
          };
          const a = E.generateBoard(`par-${n}-${i}`, o);
          const b = R.generateBoard(`par-${n}-${i}`, o);
          expect(a).toEqual(b);
        }
      }
  });

  it(
    "check, solutions, logicSolve, transform, hint, rank, assign identik pada seluruh bank",
    { timeout: 120_000 },
    () => {
      const idx = loadBankIndex();
      const rng = E.rngFrom("paritas");
      for (const k of idx.kolam) {
        const papan = loadPool(k.key);
        for (const b of papan.slice(0, 12)) {
          expect(E.solutions(b, 2)).toEqual(R.solutions(b, 2));
          expect(E.logicSolve(b, 3)).toEqual(R.logicSolve(b, 3));
          expect(E.canonical(b)).toBe(R.canonical(b));
          const gems = Array.from({ length: Math.floor(rng() * (b.n + 1)) }, () => ({
            r: Math.floor(rng() * b.n),
            c: Math.floor(rng() * b.n),
          }));
          expect(E.check(b, gems)).toEqual(R.check(b, gems));
          for (let t = 0; t < 8; t++) {
            const perm = E._internal.randomSolution(b.n, false, E.rngFrom("p" + t))!; // permutasi 0..n-1 acak
            expect(E.transformBoard(b, t, perm)).toEqual(R.transformBoard(b, t, perm));
          }
          expect(E.hintCell(b, gems.slice(0, 1))).toEqual(R.hintCell(b, gems.slice(0, 1)));
        }
      }
      const ids = Array.from({ length: 40 }, (_, i) => "p" + i);
      const pools = ["LR4x", "LR10ad", "LR3x"].map((key) => loadPool(key).map((b) => ({ id: b.id as string, n: b.n })));
      expect(E.assignBoards(ids, pools, "s")).toEqual(R.assignBoards(ids, pools, "s"));
      const runs = Array.from({ length: 30 }, (_, i) => ({
        id: "r" + i,
        done: Math.floor(rng() * 4),
        lastFinishMs: rng() < 0.2 ? null : Math.floor(rng() * 5) * 1000,
        hints: Math.floor(rng() * 3),
      }));
      expect(E.rank(runs)).toEqual(R.rank(runs));
      const stages = [{ n: 4 }, { n: 6, diagonal: true }];
      expect(E.suggestMinutes(stages)).toBe(R.suggestMinutes(stages));
      for (const lvl of ["mudah", "sedang", "sulit"] as const) {
        const p = loadPool("LR6ad") as (E.Board & { difficulty: number; id: string })[];
        expect(E.pickByLevel(p, lvl, 10)).toEqual(R.pickByLevel(p, lvl, 10));
      }
      for (let n = 2; n <= 11; n++)
        for (const diagonal of [false, true])
          expect(E.validateStage({ n, diagonal })).toEqual(R.validateStage({ n, diagonal }));
    },
  );

  it("protokol penonton identik", () => {
    const b = E.publicBoard(loadPool("LR5a")[0]);
    const tx = S.makeSender();
    const rtx = RS.makeSender();
    const body = { t: "snap", seq: 1, board: b, gems: [], xs: [], locked: [], hints: 0, elapsedMs: 5 };
    const m1 = tx.next(body);
    expect(m1).toEqual(rtx.next(body));
    const ops = ["gem", "x", "gem", "hint", "clear", "unx", "clear"] as const;
    let v = S.applyMsg(S.initialView(), m1);
    let rv = RS.applyMsg(RS.initialView(), m1);
    ops.forEach((op, i) => {
      const mv = { t: "mv", op, r: i % 5, c: (i * 2) % 5, at: 0 };
      const m = tx.next(mv);
      expect(m).toEqual(rtx.next(mv));
      expect(S.decode(S.encode(m))).toEqual(RS.decode(RS.encode(m)));
      v = S.applyMsg(v, m);
      rv = RS.applyMsg(rv, m);
      expect(v).toEqual(rv);
    });
    for (const bad of [
      '{"t":"mv","s":1,"op":"hack","r":0,"c":0}',
      "bukan json",
      '{"t":"mv","s":1,"op":"gem","r":10,"c":0}',
    ])
      expect(S.decode(bad)).toEqual(RS.decode(bad));
  });
});

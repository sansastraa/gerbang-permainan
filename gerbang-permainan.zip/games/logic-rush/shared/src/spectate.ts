/* eslint-disable @typescript-eslint/no-explicit-any -- batas protokol: pesan JSON dari jaringan, divalidasi oleh validate() */
// ============================================================
// LOGIC RUSH — protokol penonton (DataChannel WebRTC atau relay WebSocket).
// Port TypeScript dari `engine/spectate-protocol.js` TANPA mengubah perilaku;
// `spectate.parity.test.ts` membandingkan dengan berkas asli.
//
// Pesan dari ponsel pemain → penonton (JSON, maks 2 KB):
//   { t:'snap', s, seq, board:{n,rules,zones}, gems, xs, locked, hints, elapsedMs }
//   { t:'mv',   s, op:'gem'|'clear'|'x'|'unx'|'hint', r, c, at }
//   { t:'stage',s, seq, board, elapsedMs }
//   { t:'done', s, totalMs }
//   { t:'ping', s }
// s = nomor urut pesan per pemain. Lompatan nomor → penonton minta { t:'need-snap' }.
// ============================================================
import type { Cell, PublicBoard } from "./engine";

export const MAX_BYTES = 2048;
const OPS = new Set(["gem", "clear", "x", "unx", "hint"]);

export type SpectateMsg = { t: string; s: number; [k: string]: any };

export function validate(msg: any): boolean {
  if (!msg || typeof msg !== "object" || typeof msg.t !== "string" || !Number.isInteger(msg.s) || msg.s < 0)
    return false;
  const inGrid = (n: number, v: unknown): boolean => Number.isInteger(v) && (v as number) >= 0 && (v as number) < n;
  switch (msg.t) {
    case "snap":
    case "stage":
      if (!msg.board || !Number.isInteger(msg.board.n) || msg.board.n < 3 || msg.board.n > 10) return false;
      if (!Array.isArray(msg.board.zones) || msg.board.zones.length !== msg.board.n) return false;
      return (
        msg.t === "stage" ||
        (Array.isArray(msg.gems) && msg.gems.every((g: Cell) => inGrid(msg.board.n, g.r) && inGrid(msg.board.n, g.c)))
      );
    case "mv":
      return (
        OPS.has(msg.op) &&
        Number.isInteger(msg.r) &&
        Number.isInteger(msg.c) &&
        msg.r >= 0 &&
        msg.c >= 0 &&
        msg.r < 10 &&
        msg.c < 10
      );
    case "done":
    case "ping":
      return true;
    default:
      return false;
  }
}
export function encode(msg: SpectateMsg): string {
  const s = JSON.stringify(msg);
  if (s.length > MAX_BYTES) throw new Error("pesan terlalu besar");
  return s;
}
export function decode(raw: string): SpectateMsg | null {
  try {
    const m = JSON.parse(raw);
    return validate(m) ? m : null;
  } catch {
    return null;
  }
}

export interface SpectateView {
  ready: boolean;
  lastS: number;
  seq: number;
  board: PublicBoard | null;
  gems: Cell[];
  xs: Cell[];
  locked: string[];
  hints: number;
  elapsedMs: number;
  done: boolean;
  needSnap: boolean;
}
export function initialView(): SpectateView {
  return {
    ready: false,
    lastS: -1,
    seq: 0,
    board: null,
    gems: [],
    xs: [],
    locked: [],
    hints: 0,
    elapsedMs: 0,
    done: false,
    needSnap: true,
  };
}
const k = (r: number, c: number): string => r + "," + c;
export function applyMsg(v: SpectateView, m: SpectateMsg | null): SpectateView {
  if (!m) return v;
  if (m.t === "snap")
    return {
      ready: true,
      lastS: m.s,
      seq: m.seq,
      board: m.board,
      gems: m.gems.slice(),
      xs: (m.xs || []).slice(),
      locked: (m.locked || []).slice(),
      hints: m.hints || 0,
      elapsedMs: m.elapsedMs || 0,
      done: false,
      needSnap: false,
    };
  if (!v.ready || m.s <= v.lastS) return v;
  if (m.s !== v.lastS + 1) return { ...v, needSnap: true };
  const nv: SpectateView = { ...v, lastS: m.s };
  if (m.t === "mv") {
    const gems = new Map(v.gems.map((g) => [k(g.r, g.c), g] as const));
    const xs = new Set(v.xs.map((x) => k(x.r, x.c)));
    const locked = new Set(v.locked);
    const key = k(m.r, m.c);
    if (m.op === "gem") {
      gems.set(key, { r: m.r, c: m.c });
      xs.delete(key);
    } else if (m.op === "clear") {
      if (!locked.has(key)) gems.delete(key);
    } else if (m.op === "x") {
      if (!gems.has(key)) xs.add(key);
    } else if (m.op === "unx") xs.delete(key);
    else if (m.op === "hint") {
      gems.set(key, { r: m.r, c: m.c });
      locked.add(key);
      xs.delete(key);
      nv.hints = v.hints + 1;
    }
    const toRC = (s: string): Cell => {
      const [r, c] = s.split(",").map(Number);
      return { r, c };
    };
    nv.gems = [...gems.values()];
    nv.xs = [...xs].map(toRC);
    nv.locked = [...locked];
  } else if (m.t === "stage") {
    nv.seq = m.seq;
    nv.board = m.board;
    nv.gems = [];
    nv.xs = [];
    nv.locked = [];
    nv.elapsedMs = m.elapsedMs || v.elapsedMs;
  } else if (m.t === "done") {
    nv.done = true;
    nv.elapsedMs = m.totalMs;
  }
  return nv;
}

export function makeSender(): {
  next: (body: Record<string, unknown> & { t: string }) => SpectateMsg;
  readonly s: number;
} {
  let s = 0;
  return {
    next: (body) => ({ ...body, s: s++ }),
    get s() {
      return s;
    },
  };
}

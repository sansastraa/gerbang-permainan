// Pembaca bank papan dari disk (hanya Node: server, tes, alat). Bank berisi SOLUSI — jangan impor dari klien.
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import type { Board } from "./engine";

export interface PoolInfo {
  key: string;
  file: string;
  n: number;
  set: string;
  aturan: string;
  jumlah: number;
  kesulitan: [number, number];
  tier: string[];
}
export interface BankIndex {
  meta: Record<string, unknown>;
  kolam: PoolInfo[];
}

export function defaultBankDir(): string {
  return path.join(path.dirname(fileURLToPath(import.meta.url)), "..", "..", "data", "bank");
}

export function loadBankIndex(dir = defaultBankDir()): BankIndex {
  return JSON.parse(fs.readFileSync(path.join(dir, "index.json"), "utf8")) as BankIndex;
}

export function loadPool(key: string, dir = defaultBankDir()): Board[] {
  const raw = JSON.parse(fs.readFileSync(path.join(dir, key + ".json"), "utf8")) as { papan: Board[] };
  return raw.papan;
}

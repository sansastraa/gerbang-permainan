// Pengaturan sesi (diatur guru) — divalidasi dengan zod + validateStage di UI DAN server.
import { z } from "zod";
import cfg from "../../config/logic-rush.config.json";
import { MAX_N, MIN_N, suggestMinutes, validateStage } from "./engine";
import type { Level, Stage } from "./engine";

export const CONFIG = cfg as unknown as {
  pemain: { maks: number; min: number };
  pin: {
    panjang: number;
    kedaluwarsa_menit: number;
    percobaan_salah_maks_per_menit: number;
    nama_maks_karakter: number;
  };
  bantuan: { aktif: boolean; per_papan: number; penalti_detik: number };
  hitung_mundur_detik: number;
  kartu_aturan_baru_detik: number;
  webrtc: { batas_waktu_ice_detik: number; maks_penonton_p2p_per_pemain: number; ice_servers_lan: unknown[] };
  anti_curang: {
    fokus_hilang_toleransi_ms: number;
    fokus_hilang_bendera: number;
    finish_terlalu_cepat_ms: Record<string, number>;
  };
  papan: {
    ukuran_min: number;
    ukuran_maks: number;
    jumlah_tahap: { min: number; maks: number };
    preset: Record<string, { label: string; tahap: Required<Stage>[] }>;
    preset_bawaan: string;
  };
};

/** Pertandingan ala RTC: 2–3 pemain, papan dasar sama, best-of-N. */
export const UKURAN_PERTANDINGAN_MIN = 2;
export const UKURAN_PERTANDINGAN_MAKS = 3;
export const BEST_OF_PILIHAN = [1, 3, 5] as const;
/** Poin per peringkat game (hanya pemain yang menyelesaikan papan). */
export const POIN_PERINGKAT = [5, 3, 1] as const;
export const BONUS_MENANG_PERTANDINGAN = 5;
/** Format massal (di atas 3 pemain): satu arena sampai 40 pemain, tanpa kamera/RTC, hanya papan peringkat + sorotan bergilir. */
export const UKURAN_MASSAL_MAKS = 40;
export const POIN_MASSAL = [10, 8, 6, 5, 4, 3, 2, 1] as const;
export const FORMAT_PILIHAN = ["laga", "massal"] as const;

export const stageSchema = z.object({
  n: z.number().int().min(MIN_N).max(MAX_N),
  arsir: z.boolean().default(false),
  diagonal: z.boolean().default(false),
  level: z.enum(["mudah", "sedang", "sulit"]).default("sedang"),
});

export const settingsSchema = z.object({
  nama: z.string().trim().max(40).default("Logic Rush"),
  tahap: z.array(stageSchema).min(cfg.papan.jumlah_tahap.min).max(cfg.papan.jumlah_tahap.maks),
  /** laga = 2–3 pemain (boleh pakai kamera/RTC); massal = di atas 3 pemain, tanpa RTC. */
  format: z.enum(FORMAT_PILIHAN).default("laga"),
  ukuranPertandingan: z.number().int().min(UKURAN_PERTANDINGAN_MIN).max(UKURAN_PERTANDINGAN_MAKS).default(2),
  /** Berapa papan dalam satu game: selesai satu papan, pemain langsung lanjut ke papan berikutnya tanpa menunggu lawan. */
  papanPerGame: z.number().int().min(1).max(6).default(3),
  /** Format massal: berapa detik satu pemain disorot sebelum bergilir ke pemain berikutnya. */
  sorotDetik: z.number().int().min(3).max(30).default(5),
  bestOf: z.union([z.literal(1), z.literal(3), z.literal(5)]).default(3),
  /** Batas waktu per game (detik); null = otomatis dari usulan per ukuran papan. */
  batasWaktuDetik: z.number().int().min(20).max(3600).nullable().default(null),
  bantuan: z
    .object({
      aktif: z.boolean().default(cfg.bantuan.aktif),
      perPapan: z.number().int().min(0).max(3).default(cfg.bantuan.per_papan),
      penaltiDetik: z.number().int().min(0).max(120).default(cfg.bantuan.penalti_detik),
    })
    .default({}),
  kamera: z
    .object({
      /** mati = tidak ada kamera sama sekali; opsional = pemain boleh menyalakan sendiri. */
      mode: z.enum(["mati", "opsional"]).default("mati"),
      /** Guru harus menyetujui kamera tiap pemain sebelum menyala. */
      persetujuanGuru: z.boolean().default(true),
      /** Guru menyatakan izin orang tua/wali sudah ada (wajib bila mode ≠ mati). */
      izinOrtuDikonfirmasi: z.boolean().default(false),
      mikrofon: z.boolean().default(false),
      /** operator-obs = hanya operator dan halaman OBS; semua = seluruh penonton /watch. */
      siapaBolehLihat: z.enum(["operator-obs", "semua"]).default("operator-obs"),
    })
    .default({}),
  hitungMundurDetik: z.number().int().min(0).max(10).default(cfg.hitung_mundur_detik),
  rehatDetik: z.number().int().min(3).max(60).default(8),
  /** Setelah pemain pertama selesai, yang lain punya waktu segini (detik) untuk menyusul; 0 = tunggu batas waktu. */
  grasiSetelahPemenangDetik: z.number().int().min(0).max(300).default(60),
  /** Penonton di /watch boleh masuk hanya dengan PIN sesi. */
  penontonBolehMasuk: z.boolean().default(true),
});
export type SesiSettings = z.infer<typeof settingsSchema>;
export type SesiSettingsInput = z.input<typeof settingsSchema>;

export function presetTahap(key: string): Required<Stage>[] {
  const p = CONFIG.papan.preset[key];
  if (!p) throw new Error("preset tidak dikenal: " + key);
  return p.tahap.map((t) => ({ ...t }));
}

export function defaultSettings(): SesiSettings {
  return settingsSchema.parse({ tahap: presetTahap(CONFIG.papan.preset_bawaan) });
}

/** Validasi lengkap: skema + validateStage per tahap + aturan kamera. Mengembalikan pesan galat berbahasa Indonesia. */
export function validateSettings(input: unknown): { ok: true; value: SesiSettings } | { ok: false; errors: string[] } {
  const parsed = settingsSchema.safeParse(input);
  if (!parsed.success) {
    return { ok: false, errors: parsed.error.issues.map((i) => `${i.path.join(".") || "pengaturan"}: ${i.message}`) };
  }
  const v = parsed.data;
  const errors: string[] = [];
  v.tahap.forEach((t, i) => validateStage(t).forEach((e) => errors.push(`Tahap ${i + 1}: ${e}`)));
  if (v.kamera.mode !== "mati" && !v.kamera.izinOrtuDikonfirmasi)
    errors.push("Kamera hanya boleh dinyalakan setelah guru menyatakan izin orang tua/wali sudah ada.");
  if (v.kamera.mikrofon && v.kamera.mode === "mati") errors.push("Mikrofon butuh kamera mode opsional.");
  if (v.format === "massal" && v.kamera.mode !== "mati")
    errors.push("Format massal (di atas 3 pemain) tidak memakai kamera atau RTC.");
  return errors.length ? { ok: false, errors } : { ok: true, value: v };
}

/** Papan untuk game ke-`gameNo` (mulai 0): tahap berulang bila game lebih banyak dari tahap. */
export function stageForGame(s: SesiSettings, gameNo: number): Required<Stage> {
  const t = s.tahap[gameNo % s.tahap.length];
  return { n: t.n, arsir: t.arsir, diagonal: t.diagonal, level: t.level as Level };
}

/** Tahap untuk papan ke-`papanKe` (mulai 0) di game ke-`gameNo` (mulai 0): tahap berurutan, berulang bila lebih sedikit dari papan. */
export function stageForBoard(s: SesiSettings, gameNo: number, papanKe: number): Required<Stage> {
  return stageForGame(s, gameNo * s.papanPerGame + papanKe);
}
export function stagesForGame(s: SesiSettings, gameNo: number): Required<Stage>[] {
  return Array.from({ length: s.papanPerGame }, (_, j) => stageForBoard(s, gameNo, j));
}

/** Longgar 1,5× dari usulan waktu per ukuran (usulan wajib dikalibrasi dengan uji anak; lihat PROGRESS). */
export const LONGGAR_WAKTU = 1.5;
/** Batas waktu sebuah game dalam milidetik (otomatis = jumlah usulan semua papan dalam game × LONGGAR_WAKTU). */
export function batasWaktuGameMs(s: SesiSettings, gameNo: number): number {
  if (s.batasWaktuDetik) return s.batasWaktuDetik * 1000;
  return Math.max(45, Math.round(suggestMinutes(stagesForGame(s, gameNo)) * 60 * LONGGAR_WAKTU)) * 1000;
}

// Port vitest dari `engine/lr-engine.test.js` (paket spesifikasi). Isi pemeriksaan sama.
import { describe, expect, it } from "vitest";
import * as E from "./engine";
import type { Board } from "./engine";
import { loadBankIndex, loadPool } from "./bank-node";

const index = loadBankIndex();
const pool = (key: string): Board[] => loadPool(key);

describe("engine Logic Rush (port)", () => {
  it("semua pemeriksaan engine asli lulus", { timeout: 120_000 }, () => {
    let pass = 0;
    const ok = (c: unknown, m: string): void => {
      if (!c) throw new Error("GAGAL: " + m);
      pass++;
    };

    // 1. Pemeriksa aturan R1–R5
    const B4 = { n: 4, rules: ["row", "col", "zone"] as E.Rule[], zones: ["0011", "0011", "2233", "2233"] };
    ok(
      E.check(B4, [
        { r: 0, c: 0 },
        { r: 0, c: 3 },
      ]).conflicts[0].rules.includes("row"),
      "R1 baris",
    );
    ok(
      E.check(B4, [
        { r: 0, c: 0 },
        { r: 3, c: 0 },
      ]).conflicts[0].rules.includes("col"),
      "R2 kolom",
    );
    ok(
      E.check(B4, [
        { r: 0, c: 0 },
        { r: 1, c: 1 },
      ]).conflicts[0].rules.join() === "zone",
      "R3 zona",
    );
    const B5 = {
      n: 4,
      rules: ["row", "col", "zone", "blocked", "diag"] as E.Rule[],
      zones: ["0#11", "0011", "2233", "22#3"],
    };
    ok(E.check(B5, [{ r: 0, c: 1 }]).cellErrors[0].rule === "blocked", "R4 arsir");
    ok(
      E.check(B5, [
        { r: 0, c: 0 },
        { r: 3, c: 3 },
      ]).conflicts[0].rules.join() === "diag",
      "R5 diagonal jauh",
    );
    ok(
      E.check(B5, [
        { r: 0, c: 0 },
        { r: 0, c: 0 },
      ]).duplicate,
      "permata ganda",
    );
    ok(!E.check(B4, [{ r: 0, c: 0 }]).complete, "belum lengkap");

    // 2. Bank: setiap papan tepat satu solusi, sah, dan bisa diselesaikan dengan logika
    const all: Board[] = [];
    for (const k of index.kolam)
      for (const b of pool(k.key)) {
        const sols = E.solutions(b, 2);
        ok(sols.length === 1 && sols[0].join() === b.solution!.join(), "unik " + b.id);
        ok(E.check(b, E.solutionCells(b)).complete, "solusi sah " + b.id);
        const ls = E.logicSolve(b, 3);
        ok(ls.solved && "T" + ls.tier === b.tier && ls.difficulty === b.difficulty, "logika " + b.id);
        all.push(b);
      }
    for (const k of index.kolam) {
      const ps = pool(k.key);
      ok(new Set(ps.map(E.canonical)).size === ps.length, "tidak ada kembar di " + k.key);
    }
    for (let n = E.MIN_N; n <= E.MAX_N; n++)
      for (const set of ["x", "a", "d", "ad"]) {
        if (n < 4 && set.includes("d")) continue;
        ok(
          index.kolam.some((k) => k.n === n && k.set === set),
          `kolam ${n}${set} tersedia`,
        );
      }
    ok(!index.kolam.some((k) => k.n === 3 && k.set.includes("d")), "3×3 tanpa diagonal");
    ok(
      all.some((b) => b.n === 10 && b.rules.includes("diag") && b.rules.includes("blocked")),
      "ada papan 10×10 semua aturan",
    );
    ok(!all.some((b) => b.n > 10 || b.n < 3), "semua papan dalam rentang 3–10");
    ok(
      all.length === 1287 || all.length === 1287 + 8 || all.length > 1200,
      "jumlah papan bank masuk akal: " + all.length,
    );

    // 3. 8 simetri × acak zona
    const rr = E.rngFrom("perm");
    for (const k of index.kolam)
      for (const b of pool(k.key).slice(0, k.n <= 8 ? 48 : 4))
        for (let t = 0; t < 8; t++) {
          const perm = [...Array(b.n).keys()].sort(() => rr() - 0.5);
          const tb = E.transformBoard(b, t, perm);
          ok(E.check(tb, E.solutionCells(tb)).complete, `transform sah ${b.id} k=${t}`);
          const s = E.solutions(tb, 2);
          ok(s.length === 1 && s[0].join() === tb.solution!.join(), `transform unik ${b.id} k=${t}`);
          for (let r = 0; r < b.n; r++)
            for (let c = 0; c < b.n; c++) {
              const x = E.tcell(b.n, r, c, t);
              const y = E.inverseCell(b.n, x.r, x.c, t);
              ok(y.r === r && y.c === c, "invers");
            }
        }
    ok(!("solution" in E.publicBoard(all[0])), "publicBoard tanpa solusi");

    // 4. Pembangkit: 1.000 papan acak
    const cfg: E.GenerateOptions[] = [];
    for (let n = 4; n <= 8; n++)
      for (const st of [{}, { arsir: true }, { diagonal: true }, { arsir: true, diagonal: true }])
        cfg.push({ n, rules: E.rulesFor(st), blocked: [Math.floor(n / 2), n - 1], maxTier: 2 });
    for (let i = 0; i < 1000; i++) {
      const o = cfg[i % cfg.length];
      const b = E.generateBoard("rand-" + i, o);
      ok(
        E.solutions(b, 2).length === 1 &&
          E.logicSolve(b, o.maxTier).solved &&
          E.zonesConnected(
            b.n,
            b.zones.map((r) => r.split("").map((ch) => (ch === "#" ? "#" : E.zoneNum(ch)))),
          ),
        "acak " + i,
      );
    }

    // 5. Bantuan
    for (const b of all.filter((_, i) => i % 25 === 0)) {
      const sol = E.solutionCells(b);
      const gems = sol.slice(0, 2);
      const h = E.hintCell(b, gems)!;
      ok(
        sol.some((x) => x.r === h.r && x.c === h.c) && !gems.some((g) => g.r === h.r && g.c === h.c),
        "bantuan " + b.id,
      );
    }

    // 6. Replay
    const mv: E.Move[] = [
      { op: "gem", r: 0, c: 0 },
      { op: "x", r: 1, c: 1 },
      { op: "hint", r: 2, c: 2 },
      { op: "clear", r: 2, c: 2 },
      { op: "gem", r: 1, c: 1 },
      { op: "clear", r: 0, c: 0 },
    ];
    const s1 = E.replay(mv);
    const s2 = E.replay(mv);
    ok(JSON.stringify(s1) === JSON.stringify(s2), "replay deterministik");
    ok(
      s1.gems.length === 2 && s1.gems.some((g) => g.r === 2 && g.c === 2) && s1.xs.length === 0,
      "bantuan terkunci & X tertimpa permata",
    );

    // 7. Pembagian 40 pemain
    const ids = Array.from({ length: 40 }, (_, i) => "p" + i);
    const P4 = pool("LR4x").map((b) => ({ id: b.id as string, n: b.n }));
    const P10 = pool("LR10ad").map((b) => ({ id: b.id as string, n: b.n }));
    const asg = E.assignBoards(ids, [P4, P10], "sesi-1");
    ok(new Set(ids.map((id) => asg[id][0].boardId)).size === 40, "kolam ≥ 40: papan dasar unik");
    ok(
      new Set(ids.map((id) => asg[id][1].boardId + "|" + asg[id][1].transform)).size === 40,
      "kolam 32 untuk 40 pemain unik",
    );
    ok(
      ids.every((id) => asg[id].every((a) => a.transform >= 1 && a.transform <= 7)),
      "transform bukan identitas",
    );
    ok(JSON.stringify(E.assignBoards(ids, [P4, P10], "sesi-1")) === JSON.stringify(asg), "pembagian deterministik");

    // 7b. Parameter guru
    ok(E.validateStage({ n: 10, arsir: true, diagonal: true, level: "sulit" }).length === 0, "tahap 10×10 sah");
    ok(E.validateStage({ n: 3 }).length === 0, "tahap 3×3 sah");
    ok(
      E.validateStage({ n: 11 }).length === 1 && E.validateStage({ n: 2 }).length === 1,
      "ukuran di luar 3–10 ditolak",
    );
    ok(E.validateStage({ n: 3, diagonal: true }).length === 1, "3×3 + diagonal ditolak");
    {
      const p3 = pool("LR3x").map((b) => ({ id: b.id as string, n: 3 }));
      const a3 = E.assignBoards(ids, [p3], "s3");
      ok(
        ids.every((id) => a3[id][0].transform >= 1),
        "kolam 3×3 kecil tetap terbagi",
      );
    }
    const lv = (l: E.Level): number =>
      E.pickByLevel(pool("LR8x") as (Board & { id: string; difficulty: number })[], l, 10).reduce(
        (a, b) => a + b.difficulty,
        0,
      ) / 10;
    ok(lv("mudah") <= lv("sedang") && lv("sedang") <= lv("sulit"), "level mudah ≤ sedang ≤ sulit");
    ok(
      E.marathonPoints(3) === 5 &&
        E.marathonPoints(10) === 145 &&
        E.marathonPoints(4) === 10 &&
        E.marathonPoints(5) === 20 &&
        E.marathonPoints(6) === 35,
      "poin maraton",
    );

    // 8. Peringkat
    const rk = E.rank([
      { id: "a", done: 3, lastFinishMs: 500000, hints: 1 },
      { id: "b", done: 3, lastFinishMs: 420000, hints: 2 },
      { id: "c", done: 2, lastFinishMs: 300000, hints: 0 },
      { id: "d", done: 3, lastFinishMs: 420000, hints: 2 },
    ]);
    ok(rk.map((r) => r.id + r.rank).join() === "b1,d1,a3,c4", "urutan peringkat & seri");

    expect(pass).toBeGreaterThan(300_000);
  });
});

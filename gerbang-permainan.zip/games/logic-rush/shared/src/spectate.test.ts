// Port vitest dari `engine/spectate-protocol.test.js`.
import { describe, expect, it } from "vitest";
import * as E from "./engine";
import * as P from "./spectate";
import { loadPool } from "./bank-node";

describe("protokol penonton", () => {
  const b = E.publicBoard(loadPool("LR5a")[0]);
  const big = E.publicBoard(loadPool("LR10ad")[0]);
  const mk = () => {
    const tx = P.makeSender();
    const snap = tx.next({ t: "snap", seq: 2, board: b, gems: [], xs: [], locked: [], hints: 0, elapsedMs: 61000 });
    const moves = [
      { op: "gem", r: 0, c: 1 },
      { op: "x", r: 1, c: 1 },
      { op: "gem", r: 1, c: 1 },
      { op: "hint", r: 2, c: 3 },
      { op: "clear", r: 2, c: 3 },
      { op: "clear", r: 0, c: 1 },
    ].map((m) => tx.next({ t: "mv", ...m, at: 0 }));
    return { tx, snap, moves };
  };

  it("ukuran & validasi", () => {
    const { snap, moves } = mk();
    expect(P.encode(snap).length).toBeLessThan(600);
    const bigSnap = {
      t: "snap",
      s: 0,
      seq: 1,
      board: big,
      gems: Array.from({ length: 10 }, (_, i) => ({ r: i, c: i })),
      xs: Array.from({ length: 40 }, (_, i) => ({ r: i % 10, c: (i * 3) % 10 })),
      locked: [],
      hints: 0,
      elapsedMs: 1,
    };
    expect(P.encode(bigSnap).length).toBeLessThanOrEqual(P.MAX_BYTES);
    expect(P.decode(P.encode(bigSnap))).toBeTruthy();
    expect(P.decode(JSON.stringify({ t: "mv", s: 1, op: "gem", r: 9, c: 9, at: 0 }))).toBeTruthy();
    expect(P.decode(JSON.stringify({ t: "mv", s: 1, op: "gem", r: 10, c: 0, at: 0 }))).toBeNull();
    expect(P.decode(P.encode(moves[0]))).toBeTruthy();
    expect(P.decode('{"t":"mv","s":1,"op":"hack","r":0,"c":0}')).toBeNull();
    expect(P.decode("bukan json")).toBeNull();
  });

  it("tampilan penonton = keadaan pemain", () => {
    const { snap, moves } = mk();
    let v = P.initialView();
    for (const m of [snap, ...moves]) v = P.applyMsg(v, P.decode(P.encode(m)));
    const truth = E.replay(moves.map((m) => ({ op: m.op, r: m.r, c: m.c })));
    const norm = (a: E.Cell[]): string =>
      a
        .map((g) => g.r + "," + g.c)
        .sort()
        .join();
    expect(norm(v.gems)).toBe(norm(truth.gems));
    expect(v.hints).toBe(1);
    expect(v.needSnap).toBe(false);
  });

  it("pesan hilang → minta snapshot; duplikat/basi diabaikan", () => {
    const { snap, moves } = mk();
    let w = P.applyMsg(P.initialView(), snap);
    w = P.applyMsg(w, moves[0]);
    w = P.applyMsg(w, moves[2]);
    expect(w.needSnap).toBe(true);
    let d = P.applyMsg(P.applyMsg(P.initialView(), snap), moves[0]);
    const before = JSON.stringify(d);
    d = P.applyMsg(d, moves[0]);
    expect(JSON.stringify(d)).toBe(before);
    expect(P.applyMsg(P.initialView(), moves[0]).ready).toBe(false);
  });

  it("pergantian papan, selesai, dan tanpa solusi", () => {
    const { tx, snap, moves } = mk();
    let s = P.applyMsg(P.initialView(), snap);
    moves.forEach((m) => (s = P.applyMsg(s, m)));
    s = P.applyMsg(s, tx.next({ t: "stage", seq: 3, board: big, elapsedMs: 200000 }));
    expect(s.seq).toBe(3);
    expect(s.gems.length).toBe(0);
    expect(s.board!.n).toBe(10);
    s = P.applyMsg(s, tx.next({ t: "done", totalMs: 512345 }));
    expect(s.done && s.elapsedMs === 512345).toBe(true);
    expect(P.encode(snap)).not.toMatch(/solution/);
  });
});

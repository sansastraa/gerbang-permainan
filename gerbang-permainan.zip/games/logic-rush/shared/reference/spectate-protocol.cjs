// ============================================================
// LOGIC RUSH — protokol penonton (dipakai di atas WebRTC DataChannel
// atau relay WebSocket sebagai cadangan). Fungsi murni & bisa diuji.
//
// Pesan dari ponsel pemain → penonton (JSON, maks ~300 byte):
//   { t:'snap', s, seq, board:{n,rules,zones}, gems, xs, locked, hints, elapsedMs }
//   { t:'mv',   s, op:'gem'|'clear'|'x'|'unx'|'hint', r, c, at }
//   { t:'stage',s, seq, board, elapsedMs }      // papan berikutnya
//   { t:'done', s, totalMs }                     // selesai semua papan
//   { t:'ping', s }
// s = nomor urut pesan per pemain (naik terus). Penonton yang melihat lompatan
// nomor urut meminta snapshot ulang: { t:'need-snap' } (penonton → pemain).
// ============================================================
const MAX_BYTES = 2048;
const OPS = new Set(["gem", "clear", "x", "unx", "hint"]);

function validate(msg) {
  if (!msg || typeof msg !== "object" || typeof msg.t !== "string" || !Number.isInteger(msg.s) || msg.s < 0)
    return false;
  const inGrid = (n, v) => Number.isInteger(v) && v >= 0 && v < n;
  switch (msg.t) {
    case "snap":
    case "stage":
      if (!msg.board || !Number.isInteger(msg.board.n) || msg.board.n < 3 || msg.board.n > 10) return false;
      if (!Array.isArray(msg.board.zones) || msg.board.zones.length !== msg.board.n) return false;
      return (
        msg.t === "stage" ||
        (Array.isArray(msg.gems) && msg.gems.every((g) => inGrid(msg.board.n, g.r) && inGrid(msg.board.n, g.c)))
      );
    case "mv":
      return (
        OPS.has(msg.op) &&
        Number.isInteger(msg.r) &&
        Number.isInteger(msg.c) &&
        msg.r >= 0 &&
        msg.c >= 0 &&
        msg.r < 10 &&
        msg.c < 10
      );
    case "done":
    case "ping":
      return true;
    default:
      return false;
  }
}
function encode(msg) {
  const s = JSON.stringify(msg);
  if (s.length > MAX_BYTES) throw new Error("pesan terlalu besar");
  return s;
}
function decode(raw) {
  try {
    const m = JSON.parse(raw);
    return validate(m) ? m : null;
  } catch (e) {
    return null;
  }
}

// Status yang digambar penonton
function initialView() {
  return {
    ready: false,
    lastS: -1,
    seq: 0,
    board: null,
    gems: [],
    xs: [],
    locked: [],
    hints: 0,
    elapsedMs: 0,
    done: false,
    needSnap: true,
  };
}
const k = (r, c) => r + "," + c;
function applyMsg(v, m) {
  if (!m) return v;
  if (m.t === "snap")
    return {
      ready: true,
      lastS: m.s,
      seq: m.seq,
      board: m.board,
      gems: m.gems.slice(),
      xs: (m.xs || []).slice(),
      locked: (m.locked || []).slice(),
      hints: m.hints || 0,
      elapsedMs: m.elapsedMs || 0,
      done: false,
      needSnap: false,
    };
  if (!v.ready || m.s <= v.lastS) return v; // belum punya snapshot, atau pesan basi/duplikat
  if (m.s !== v.lastS + 1) return { ...v, needSnap: true }; // ada pesan hilang → minta snapshot
  const nv = { ...v, lastS: m.s };
  if (m.t === "mv") {
    const gems = new Map(v.gems.map((g) => [k(g.r, g.c), g])),
      xs = new Set(v.xs.map((x) => k(x.r, x.c))),
      locked = new Set(v.locked);
    const key = k(m.r, m.c);
    if (m.op === "gem") {
      gems.set(key, { r: m.r, c: m.c });
      xs.delete(key);
    } else if (m.op === "clear") {
      if (!locked.has(key)) gems.delete(key);
    } else if (m.op === "x") {
      if (!gems.has(key)) xs.add(key);
    } else if (m.op === "unx") xs.delete(key);
    else if (m.op === "hint") {
      gems.set(key, { r: m.r, c: m.c });
      locked.add(key);
      xs.delete(key);
      nv.hints = v.hints + 1;
    }
    const toRC = (s) => {
      const [r, c] = s.split(",").map(Number);
      return { r, c };
    };
    nv.gems = [...gems.values()];
    nv.xs = [...xs].map(toRC);
    nv.locked = [...locked];
  } else if (m.t === "stage") {
    nv.seq = m.seq;
    nv.board = m.board;
    nv.gems = [];
    nv.xs = [];
    nv.locked = [];
    nv.elapsedMs = m.elapsedMs || v.elapsedMs;
  } else if (m.t === "done") {
    nv.done = true;
    nv.elapsedMs = m.totalMs;
  }
  return nv;
}

// Sisi pemain: penyusun pesan dengan nomor urut
function makeSender() {
  let s = 0;
  return {
    next: (body) => ({ ...body, s: s++ }),
    get s() {
      return s;
    },
  };
}

const API = { validate, encode, decode, initialView, applyMsg, makeSender, MAX_BYTES };
if (typeof module !== "undefined") module.exports = API;

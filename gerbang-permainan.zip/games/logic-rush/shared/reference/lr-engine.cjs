// ============================================================
// LOGIC RUSH — lr-engine (fungsi murni: tanpa jaringan, tanpa jam)
// Dipakai server (wasit), browser pemain (sorotan pelanggaran),
// penonton WebRTC (menggambar ulang), dan alat offline (pembangkit bank).
//
// Papan: { id, n, rules: ['row','col','zone','blocked','diag'], zones: string[], solution?: number[] }
//   zones[r][c] = '0'..'9' nomor zona (dibaca basis-36 agar bisa diperluas), '#' = kotak arsir
//   Ukuran papan: 3 sampai 10 (MIN_N..MAX_N). R5 diagonal hanya untuk ukuran >= 4.
//   solution[r] = kolom permata di baris r (HANYA server)
// Permata: [{ r, c }]
// ============================================================

// ---------- RNG ----------
function hashStr(s) {
  let h = 1779033703 ^ s.length;
  for (let i = 0; i < s.length; i++) {
    h = Math.imul(h ^ s.charCodeAt(i), 3432918353);
    h = (h << 13) | (h >>> 19);
  }
  return h >>> 0;
}
function rngFrom(seed) {
  let a = hashStr(String(seed));
  return () => {
    a |= 0;
    a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
function shuffle(a, rng) {
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(rng() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

const MIN_N = 3,
  MAX_N = 10;
const zoneAt = (b, r, c) => b.zones[r][c];
const zoneNum = (ch) => parseInt(ch, 36);
const isBlocked = (b, r, c) => b.zones[r][c] === "#";
const has = (b, rule) => b.rules.includes(rule);

// ---------- R1–R5: pemeriksa aturan ----------
// Mengembalikan pelanggaran yang bisa disorot TANPA melihat solusi.
function check(b, gems) {
  const conflicts = [],
    cellErrors = [];
  for (const g of gems) if (isBlocked(b, g.r, g.c)) cellErrors.push({ r: g.r, c: g.c, rule: "blocked" });
  for (let i = 0; i < gems.length; i++)
    for (let j = i + 1; j < gems.length; j++) {
      const a = gems[i],
        q = gems[j],
        rules = [];
      if (a.r === q.r) rules.push("row");
      if (a.c === q.c) rules.push("col");
      if (!isBlocked(b, a.r, a.c) && !isBlocked(b, q.r, q.c) && zoneAt(b, a.r, a.c) === zoneAt(b, q.r, q.c))
        rules.push("zone");
      if (has(b, "diag") && Math.abs(a.r - q.r) === Math.abs(a.c - q.c)) rules.push("diag");
      if (rules.length) conflicts.push({ a, b: q, rules });
    }
  const dupe = new Set(gems.map((g) => g.r + "," + g.c)).size !== gems.length;
  const ok = !dupe && conflicts.length === 0 && cellErrors.length === 0;
  return { ok, complete: ok && gems.length === b.n, conflicts, cellErrors, duplicate: dupe };
}
const RULE_TEXT = {
  row: "satu baris",
  col: "satu kolom",
  zone: "satu zona warna",
  blocked: "kotak arsir",
  diag: "sejajar miring",
};

// ---------- hitung solusi (backtracking dengan topeng) ----------
function solutions(b, limit = 2) {
  const n = b.n,
    out = [],
    cols = [];
  let colM = 0,
    zoneM = 0,
    d1 = 0,
    d2 = 0;
  const diag = has(b, "diag");
  (function rec(r) {
    if (out.length >= limit) return;
    if (r === n) {
      out.push(cols.slice());
      return;
    }
    for (let c = 0; c < n; c++) {
      if (isBlocked(b, r, c) || (colM >> c) & 1) continue;
      const z = parseInt(zoneAt(b, r, c), 36);
      if ((zoneM >> z) & 1) continue;
      if (diag && ((d1 >> (r - c + n)) & 1 || (d2 >> (r + c)) & 1)) continue;
      colM |= 1 << c;
      zoneM |= 1 << z;
      if (diag) {
        d1 |= 1 << (r - c + n);
        d2 |= 1 << (r + c);
      }
      cols.push(c);
      rec(r + 1);
      cols.pop();
      colM &= ~(1 << c);
      zoneM &= ~(1 << z);
      if (diag) {
        d1 &= ~(1 << (r - c + n));
        d2 &= ~(1 << (r + c));
      }
      if (out.length >= limit) return;
    }
  })(0);
  return out;
}

// ---------- solver logika (meniru cara anak berpikir) ----------
// T1: kandidat tunggal di baris/kolom/zona + coret akibat penempatan
// T2: zona terkurung dalam satu garis (dan kebalikannya)
// T3: k zona terkurung dalam k garis (dan kebalikannya)
function combos(arr, k, start = 0, acc = [], out = []) {
  if (acc.length === k) {
    out.push(acc.slice());
    return out;
  }
  for (let i = start; i < arr.length; i++) {
    acc.push(arr[i]);
    combos(arr, k, i + 1, acc, out);
    acc.pop();
  }
  return out;
}
function logicSolve(b, maxTier = 3) {
  const n = b.n,
    diag = has(b, "diag");
  const cand = new Set();
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (!isBlocked(b, r, c)) cand.add(r * n + c);
  const placed = [],
    usedRow = new Set(),
    usedCol = new Set(),
    usedZone = new Set();
  const steps = { T1: 0, T2: 0, T3: 0 };
  let tier = 0;
  const z = (i) => zoneAt(b, Math.floor(i / n), i % n);
  const place = (i) => {
    const r = Math.floor(i / n),
      c = i % n,
      zz = z(i);
    placed.push({ r, c });
    usedRow.add(r);
    usedCol.add(c);
    usedZone.add(zz);
    for (const j of [...cand]) {
      const rr = Math.floor(j / n),
        cc = j % n;
      if (rr === r || cc === c || z(j) === zz || (diag && Math.abs(rr - r) === Math.abs(cc - c))) cand.delete(j);
    }
  };
  const units = () => {
    const U = [];
    for (let r = 0; r < n; r++) if (!usedRow.has(r)) U.push([...cand].filter((i) => Math.floor(i / n) === r));
    for (let c = 0; c < n; c++) if (!usedCol.has(c)) U.push([...cand].filter((i) => i % n === c));
    for (let k = 0; k < n; k++) {
      const key = k.toString(36);
      if (!usedZone.has(key)) U.push([...cand].filter((i) => z(i) === key));
    }
    return U;
  };
  const zonesOpen = () => {
    const a = [];
    for (let k = 0; k < n; k++) if (!usedZone.has(k.toString(36))) a.push(k.toString(36));
    return a;
  };
  const linesOf = (cells, kind) => new Set(cells.map((i) => (kind === "row" ? Math.floor(i / n) : i % n)));
  while (placed.length < n) {
    const U = units();
    if (U.some((u) => u.length === 0)) return { solved: false, contradiction: true, tier, steps, placed };
    const single = U.find((u) => u.length === 1);
    if (single) {
      place(single[0]);
      steps.T1++;
      tier = Math.max(tier, 1);
      continue;
    }
    let progress = false;
    const tryTier = (t) => {
      for (const k of t === 2 ? [1] : Array.from({ length: n - 2 }, (_, i) => i + 2)) {
        for (const kind of ["row", "col"]) {
          // k zona → k garis
          for (const zs of combos(zonesOpen(), k)) {
            const cells = [...cand].filter((i) => zs.includes(z(i))),
              lines = linesOf(cells, kind);
            if (lines.size === k) {
              for (const j of [...cand]) {
                const ln = kind === "row" ? Math.floor(j / n) : j % n;
                if (lines.has(ln) && !zs.includes(z(j))) {
                  cand.delete(j);
                  progress = true;
                }
              }
            }
            if (progress) return true;
          }
          // k garis → k zona
          const openLines = [];
          for (let x = 0; x < n; x++) if (!(kind === "row" ? usedRow : usedCol).has(x)) openLines.push(x);
          for (const ls of combos(openLines, k)) {
            const cells = [...cand].filter((i) => ls.includes(kind === "row" ? Math.floor(i / n) : i % n)),
              zs = new Set(cells.map(z));
            if (zs.size === k) {
              for (const j of [...cand]) {
                const ln = kind === "row" ? Math.floor(j / n) : j % n;
                if (zs.has(z(j)) && !ls.includes(ln)) {
                  cand.delete(j);
                  progress = true;
                }
              }
            }
            if (progress) return true;
          }
        }
      }
      return false;
    };
    if (maxTier >= 2 && tryTier(2)) {
      steps.T2++;
      tier = Math.max(tier, 2);
      continue;
    }
    if (maxTier >= 3 && tryTier(3)) {
      steps.T3++;
      tier = Math.max(tier, 3);
      continue;
    }
    return { solved: false, contradiction: false, tier, steps, placed };
  }
  return { solved: true, tier, steps, placed, difficulty: steps.T1 + 3 * steps.T2 + 6 * steps.T3 };
}

// ---------- pembangkit ----------
function randomSolution(n, diag, rng) {
  const cols = [],
    used = new Set();
  return (function rec(r) {
    if (r === n) return cols.slice();
    for (const c of shuffle([...Array(n).keys()], rng)) {
      if (used.has(c)) continue;
      if (diag && cols.some((cc, rr) => Math.abs(rr - r) === Math.abs(cc - c))) continue;
      used.add(c);
      cols.push(c);
      const res = rec(r + 1);
      if (res) return res;
      cols.pop();
      used.delete(c);
    }
    return null;
  })(0);
}
function growZones(n, sol, rng) {
  const g = Array.from({ length: n }, () => new Array(n).fill(null));
  const ids = shuffle([...Array(n).keys()], rng);
  const frontier = [];
  const nb = (r, c) =>
    [
      [r + 1, c],
      [r - 1, c],
      [r, c + 1],
      [r, c - 1],
    ].filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n);
  sol.forEach((c, r) => {
    g[r][c] = ids[r];
    frontier.push([r, c]);
  });
  let left = n * n - n;
  while (left > 0) {
    const fi = Math.floor(rng() * frontier.length),
      [r, c] = frontier[fi];
    const free = nb(r, c).filter(([a, b]) => g[a][b] === null);
    if (!free.length) {
      frontier.splice(fi, 1);
      continue;
    }
    const [a, bb] = free[Math.floor(rng() * free.length)];
    g[a][bb] = g[r][c];
    frontier.push([a, bb]);
    left--;
  }
  return g;
}
function zonesConnected(n, g) {
  const seen = new Set();
  for (let k = 0; k < n; k++) {
    const cells = [];
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === k) cells.push([r, c]);
    if (!cells.length) return false;
    const q = [cells[0]],
      vis = new Set([cells[0].join()]);
    while (q.length) {
      const [r, c] = q.pop();
      for (const [a, b] of [
        [r + 1, c],
        [r - 1, c],
        [r, c + 1],
        [r, c - 1],
      ])
        if (a >= 0 && b >= 0 && a < n && b < n && g[a][b] === k && !vis.has(a + "," + b)) {
          vis.add(a + "," + b);
          q.push([a, b]);
        }
    }
    if (vis.size !== cells.length) return false;
  }
  return true;
}
const toRows = (g) => g.map((row) => row.map((v) => (v === "#" ? "#" : v.toString(36))).join(""));

// Setelah zona A kehilangan kotak: bagian A yang terputus dari kotak jawaban-aslinya diserap zona B
function absorbFragments(n, g, A, B, keepCell) {
  const seen = new Set([keepCell]),
    q = [keepCell];
  while (q.length) {
    const cur = q.pop(),
      r = Math.floor(cur / n),
      c = cur % n;
    for (const [a, b] of [
      [r + 1, c],
      [r - 1, c],
      [r, c + 1],
      [r, c - 1],
    ]) {
      const j = a * n + b;
      if (a >= 0 && b >= 0 && a < n && b < n && g[a][b] === A && !seen.has(j)) {
        seen.add(j);
        q.push(j);
      }
    }
  }
  for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (g[r][c] === A && !seen.has(r * n + c)) g[r][c] = B;
}

// Perbaikan zona: patahkan jawaban kedua tanpa menyentuh jawaban asli.
// Ambil satu kotak x milik jawaban kedua (bukan milik jawaban asli), pindahkan ke zona tetangga
// yang sudah berisi kotak lain dari jawaban kedua → jawaban kedua punya 2 permata dalam satu zona.
function repairUnique(n, g, sol, rules, rng, maxIter) {
  const diag = rules.includes("diag"),
    blocked = rules.includes("blocked");
  const solSet = new Set(sol.map((c, r) => r * n + c));
  const asBoard = () => ({ n, rules, zones: toRows(g) });
  for (let it = 0; it < maxIter; it++) {
    const sols = solutions(asBoard(), 2);
    if (sols.length === 1) return true;
    if (sols.length === 0) return false;
    const alt = sols[0].join() === sol.join() ? sols[1] : sols[0];
    const altCells = alt.map((c, r) => r * n + c);
    const zoneOfAlt = new Map(altCells.map((i) => [g[Math.floor(i / n)][i % n], i]));
    let fixed = false;
    const solOfZone = new Map(sol.map((c, r) => [g[r][c], r * n + c]));
    const xs = shuffle(
      altCells.filter((i) => !solSet.has(i)),
      rng,
    );
    // Langkah 1: kotak x di tepi zona → pindahkan langsung ke zona tetangga
    for (const x of xs) {
      const r = Math.floor(x / n),
        c = x % n,
        A = g[r][c];
      const opts = shuffle(
        [
          [r + 1, c],
          [r - 1, c],
          [r, c + 1],
          [r, c - 1],
        ].filter(([a, b]) => a >= 0 && b >= 0 && a < n && b < n && g[a][b] !== "#" && g[a][b] !== A),
        rng,
      );
      if (opts.length) {
        const B = g[opts[0][0]][opts[0][1]];
        g[r][c] = B;
        absorbFragments(n, g, A, B, solOfZone.get(A));
        fixed = zonesConnected(n, g);
        if (fixed) break;
      }
      if (blocked) {
        g[r][c] = "#";
        if (zonesConnected(n, g)) {
          fixed = true;
          break;
        }
        g[r][c] = A;
      }
    }
    // Langkah 2: kotak x di tengah zona → zona tetangga menggali jalur terpendek ke x (menghindari kotak jawaban asli)
    if (!fixed)
      for (const x of xs) {
        const r0 = Math.floor(x / n),
          c0 = x % n,
          A = g[r0][c0];
        const prev = new Map([[x, -1]]),
          q = [x];
        let hit = null;
        for (let qi = 0; qi < q.length && !hit; qi++) {
          const cur = q[qi],
            r = Math.floor(cur / n),
            c = cur % n;
          for (const [a, b] of shuffle(
            [
              [r + 1, c],
              [r - 1, c],
              [r, c + 1],
              [r, c - 1],
            ],
            rng,
          )) {
            if (a < 0 || b < 0 || a >= n || b >= n) continue;
            const j = a * n + b,
              z = g[a][b];
            if (z === "#") continue;
            if (z !== A) {
              hit = { cell: cur, zone: z };
              break;
            }
            if (!prev.has(j) && !solSet.has(j)) {
              prev.set(j, cur);
              q.push(j);
            }
          }
        }
        if (!hit) continue;
        const path = [];
        for (let cur = hit.cell; cur !== -1; cur = prev.get(cur)) path.push(cur);
        const saved = path.map((i) => g[Math.floor(i / n)][i % n]);
        const backup = g.map((row) => row.slice());
        path.forEach((i) => {
          g[Math.floor(i / n)][i % n] = hit.zone;
        });
        absorbFragments(n, g, A, hit.zone, solOfZone.get(A));
        if (zonesConnected(n, g)) {
          fixed = true;
          break;
        }
        backup.forEach((row, r) => {
          g[r] = row;
        });
      }
    if (!fixed) return false;
  }
  return solutions(asBoard(), 2).length === 1;
}

// opsi: { n, rules, blocked:[min,max], maxTier, minTier, band }
function generateBoard(seed, opt) {
  const { n, rules, maxTier = 2, minTier = 1, band = [0, Infinity] } = opt,
    diag = rules.includes("diag");
  const maxAttempts = opt.maxAttempts || 5000;
  for (let attempt = 0; attempt < maxAttempts; attempt++) {
    const rng = rngFrom(seed + "#" + attempt);
    const sol = randomSolution(n, diag, rng);
    if (!sol) continue;
    const g = growZones(n, sol, rng);
    if (rules.includes("blocked")) {
      const [lo, hi] = opt.blocked || [0, 0],
        k = lo + Math.floor(rng() * (hi - lo + 1));
      const nonSol = shuffle(
        [...Array(n * n).keys()].filter((i) => sol[Math.floor(i / n)] !== i % n),
        rng,
      );
      let placedK = 0;
      for (const i of nonSol) {
        if (placedK === k) break;
        const r = Math.floor(i / n),
          c = i % n,
          prev = g[r][c];
        g[r][c] = "#";
        if (zonesConnected(n, g)) placedK++;
        else g[r][c] = prev;
      }
      if (placedK < k) continue;
    }
    if (!repairUnique(n, g, sol, rules, rng, n * n * 2)) continue;
    const b = { id: null, n, rules: rules.slice(), zones: toRows(g), solution: sol };
    if (solutions(b, 2).length !== 1) continue;
    const ls = logicSolve(b, maxTier);
    if (!ls.solved || ls.tier < minTier || ls.difficulty < band[0] || ls.difficulty > band[1]) continue;
    b.tier = "T" + ls.tier;
    b.difficulty = ls.difficulty;
    b.steps = ls.steps;
    return b;
  }
  throw new Error("generateBoard gagal: " + seed);
}

// ---------- keadilan: 8 simetri + acak nomor zona ----------
function tcell(n, r, c, k) {
  if (k >= 4) c = n - 1 - c;
  for (let i = 0; i < k % 4; i++) {
    const nr = c,
      nc = n - 1 - r;
    r = nr;
    c = nc;
  }
  return { r, c };
}
function inverseCell(n, r, c, k) {
  for (let i = 0; i < (4 - (k % 4)) % 4; i++) {
    const nr = c,
      nc = n - 1 - r;
    r = nr;
    c = nc;
  }
  if (k >= 4) c = n - 1 - c;
  return { r, c };
}
function transformBoard(b, k, zonePerm /* array: lama → baru */) {
  const n = b.n,
    g = Array.from({ length: n }, () => new Array(n));
  for (let r = 0; r < n; r++)
    for (let c = 0; c < n; c++) {
      const t = tcell(n, r, c, k),
        ch = b.zones[r][c];
      g[t.r][t.c] = ch === "#" ? "#" : zonePerm ? zonePerm[parseInt(ch, 36)].toString(36) : ch;
    }
  const out = { ...b, zones: g.map((x) => x.join("")), transform: k, zonePerm: zonePerm || null };
  if (b.solution) {
    const s = new Array(n);
    b.solution.forEach((c, r) => {
      const t = tcell(n, r, c, k);
      s[t.r] = t.c;
    });
    out.solution = s;
  }
  return out;
}

// Bentuk kanonik (untuk membuang papan kembar di bank): minimum dari 8 simetri, nomor zona dinormalisasi
function canonical(b) {
  let best = null;
  for (let k = 0; k < 8; k++) {
    const t = transformBoard({ n: b.n, rules: b.rules, zones: b.zones }, k),
      map = {};
    let next = 0;
    const s = t.zones
      .map((row) =>
        row
          .split("")
          .map((ch) => (ch === "#" ? "#" : (map[ch] ??= (next++).toString(36))))
          .join(""),
      )
      .join("/");
    if (best === null || s < best) best = s;
  }
  return best;
}

const publicBoard = (b) => ({ id: b.id, n: b.n, rules: b.rules, zones: b.zones }); // yang boleh dikirim ke ponsel
const solutionCells = (b) => b.solution.map((c, r) => ({ r, c }));
function matchesSolution(b, gems) {
  if (gems.length !== b.n) return false;
  const s = new Set(solutionCells(b).map((x) => x.r + "," + x.c));
  return gems.every((g) => s.has(g.r + "," + g.c));
}

// ---------- bantuan: buka satu permata benar ----------
function hintCell(b, gems, locked = []) {
  const key = (x) => x.r + "," + x.c;
  const gemSet = new Set(gems.map(key)),
    lockSet = new Set(locked.map(key));
  const zoneSize = {};
  for (const row of b.zones) for (const ch of row) zoneSize[ch] = (zoneSize[ch] || 0) + 1;
  const sol = solutionCells(b).filter((x) => !lockSet.has(key(x)));
  const missing = sol.filter((x) => !gemSet.has(key(x)));
  const pool = missing.length ? missing : sol;
  pool.sort((a, q) => zoneSize[b.zones[a.r][a.c]] - zoneSize[b.zones[q.r][q.c]] || a.r - q.r || a.c - q.c);
  return pool[0] || null;
}

// ---------- replay langkah ----------
// moves: [{ op: 'gem'|'clear'|'x'|'unx'|'hint', r, c }]
function replay(moves) {
  const gems = new Map(),
    xs = new Set(),
    locked = new Set();
  for (const m of moves) {
    const k = m.r + "," + m.c;
    if (m.op === "gem") {
      gems.set(k, { r: m.r, c: m.c });
      xs.delete(k);
    } else if (m.op === "clear") {
      if (!locked.has(k)) gems.delete(k);
    } else if (m.op === "x") {
      if (!gems.has(k)) xs.add(k);
    } else if (m.op === "unx") xs.delete(k);
    else if (m.op === "hint") {
      gems.set(k, { r: m.r, c: m.c });
      locked.add(k);
      xs.delete(k);
    }
  }
  const sortRC = (a, b) => a.r - b.r || a.c - b.c;
  return {
    gems: [...gems.values()].sort(sortRC),
    xs: [...xs]
      .map((s) => {
        const [r, c] = s.split(",").map(Number);
        return { r, c };
      })
      .sort(sortRC),
    locked: [...locked],
  };
}

// ---------- pembagian papan ke pemain (sampai 40 orang) ----------
// Setiap pemain mendapat papan dasar BERBEDA dari kolam setara, plus simetri bukan identitas dan acakan zona.
function assignBoards(playerIds, pools /* [[{id,n},...] per tahap] */, seed) {
  const rng = rngFrom("assign|" + seed),
    out = {};
  const plan = pools.map((pool) => ({
    offset: Math.floor(rng() * pool.length),
    baseK: pool.map(() => Math.floor(rng() * 7)),
  }));
  playerIds.forEach((pid, i) => {
    out[pid] = pools.map((pool, s) => {
      const P = pool.length,
        idx = (plan[s].offset + i) % P,
        round = Math.floor(i / P);
      const base = pool[idx];
      // papan dasar sama dipakai ulang (kolam < jumlah pemain) → simetri pasti berbeda (maks 7 pemakaian)
      const k = 1 + ((plan[s].baseK[idx] + round) % 7);
      const perm = shuffle([...Array(base.n).keys()], rng);
      return { seq: s + 1, boardId: base.id, transform: k, zonePerm: perm, reuse: round };
    });
  });
  return out;
}

// ---------- tahap yang diatur guru ----------
// stage: { n: 4..12, arsir: bool, diagonal: bool, level: 'mudah'|'sedang'|'sulit' }
const RULESET = (s) => (s.arsir ? (s.diagonal ? "ad" : "a") : s.diagonal ? "d" : "x");
function rulesFor(stage) {
  const r = ["row", "col", "zone"];
  if (stage.arsir) r.push("blocked");
  if (stage.diagonal) r.push("diag");
  return r;
}
function poolKey(stage) {
  return `LR${stage.n}${RULESET(stage)}`;
}
function validateStage(st) {
  const err = [];
  if (!Number.isInteger(st.n) || st.n < MIN_N || st.n > MAX_N) err.push(`ukuran harus ${MIN_N}–${MAX_N}`);
  if (!["mudah", "sedang", "sulit"].includes(st.level || "sedang")) err.push("level harus mudah/sedang/sulit");
  if (st.diagonal && st.n < 4) err.push("aturan diagonal (R5) butuh ukuran minimal 4×4");
  return err;
}
// Pilih `count` papan dari kolam dengan kesulitan paling dekat ke persentil level (mudah 20%, sedang 50%, sulit 80%)
function pickByLevel(pool, level = "sedang", count = 40) {
  const sorted = pool.slice().sort((a, b) => a.difficulty - b.difficulty);
  const target =
    sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * { mudah: 0.2, sedang: 0.5, sulit: 0.8 }[level]))]
      .difficulty;
  return sorted
    .slice()
    .sort((a, b) => Math.abs(a.difficulty - target) - Math.abs(b.difficulty - target) || a.id.localeCompare(b.id))
    .slice(0, Math.min(count, sorted.length));
}
// Usulan waktu (menit) per papan menurut ukuran — WAJIB dikalibrasi dengan uji anak
const TARGET_MENIT = { 3: 0.5, 4: 1, 5: 2.5, 6: 4.5, 7: 6, 8: 8, 9: 10, 10: 12 };
const suggestMinutes = (stages) =>
  Math.ceil(stages.reduce((a, s) => a + TARGET_MENIT[s.n] * (s.diagonal ? 1.2 : 1), 0));
const marathonPoints = (n) => Math.round(2.5 * n * n - 12.5 * n + 20); // 3→5, 4→10, 5→20, 6→35, … 10→145

// ---------- peringkat ----------
// run: { id, done (papan selesai), lastFinishMs (waktu efektif papan terakhir yang selesai), hints }
function rank(runs) {
  const sorted = runs
    .slice()
    .sort(
      (a, b) => b.done - a.done || (a.lastFinishMs ?? Infinity) - (b.lastFinishMs ?? Infinity) || a.hints - b.hints,
    );
  let pos = 0,
    prev = null;
  return sorted.map((r, i) => {
    const key = [r.done, r.lastFinishMs, r.hints].join("|");
    if (key !== prev) {
      pos = i + 1;
      prev = key;
    }
    return { ...r, rank: pos };
  });
}

const API = {
  MIN_N,
  MAX_N,
  zoneNum,
  rngFrom,
  _internal: { randomSolution, growZones, repairUnique, toRows },
  check,
  RULE_TEXT,
  solutions,
  logicSolve,
  generateBoard,
  transformBoard,
  tcell,
  inverseCell,
  publicBoard,
  solutionCells,
  matchesSolution,
  hintCell,
  replay,
  assignBoards,
  rank,
  zonesConnected,
  canonical,
  rulesFor,
  poolKey,
  validateStage,
  pickByLevel,
  suggestMinutes,
  marathonPoints,
  TARGET_MENIT,
};
if (typeof module !== "undefined") module.exports = API;

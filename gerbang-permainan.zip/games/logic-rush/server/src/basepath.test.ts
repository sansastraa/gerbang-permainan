import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { io as ioc } from "socket.io-client";
import { buatApp, normalisasiBasePath } from "./app";
import type { App } from "./app";

const HOST_PIN = "guru-rahasia";
const BASE = "/games/logic-rush";
let app: App;
let url = "";
let dist = "";
const sock: ReturnType<typeof ioc>[] = [];

beforeAll(async () => {
  dist = fs.mkdtempSync(path.join(os.tmpdir(), "lr-dist-"));
  fs.writeFileSync(path.join(dist, "index.html"), "<!doctype html><title>SPA</title>");
  fs.mkdirSync(path.join(dist, "assets"));
  fs.writeFileSync(path.join(dist, "assets", "a.js"), "console.log(1)");
  app = buatApp({ hostPin: HOST_PIN, basePath: BASE + "/", staticDir: dist, trustProxy: true });
  url = `http://127.0.0.1:${await app.listen(0, "127.0.0.1")}`;
});
afterAll(async () => {
  sock.forEach((s) => s.close());
  await app.tutup();
  fs.rmSync(dist, { recursive: true, force: true });
});

const post = (p: string, body: unknown, h: Record<string, string> = {}) =>
  fetch(url + p, { method: "POST", headers: { "content-type": "application/json", ...h }, body: JSON.stringify(body) });

describe("BASE_PATH", () => {
  it("normalisasi: diawali /, tanpa / akhir, kosong tetap kosong", () => {
    expect(normalisasiBasePath("games/logic-rush/")).toBe("/games/logic-rush");
    expect(normalisasiBasePath("/")).toBe("");
    expect(normalisasiBasePath(undefined)).toBe("");
    expect(normalisasiBasePath("  /x//  ")).toBe("/x");
  });
  it("health, api, statis, dan fallback SPA hidup di bawah awalan; akar tidak melayani apa pun", async () => {
    expect(((await (await fetch(`${url}${BASE}/health`)).json()) as { game: string }).game).toBe("logic-rush");
    expect((await fetch(`${url}/health`)).status).toBe(404);
    expect((await fetch(`${url}${BASE}/api/presets`)).status).toBe(200);
    expect((await fetch(`${url}/api/presets`)).status).toBe(404);
    expect((await fetch(`${url}${BASE}/assets/a.js`)).status).toBe(200);
    for (const p of ["/", "/host", "/watch", "/obs", "/operator"]) {
      const r = await fetch(`${url}${BASE}${p}`);
      expect(r.status).toBe(200);
      expect(await r.text()).toContain("<title>SPA</title>");
    }
    const tak = await fetch(`${url}${BASE}/api/tidak-ada`);
    expect(tak.status).not.toBe(200);
  });
  it("sesi dibuat lewat awalan dan socket.io tersambung di BASE_PATH/socket.io", async () => {
    const r = await post(`${BASE}/api/sessions`, { settings: undefined }, { "x-host-token": HOST_PIN });
    expect(r.status).toBe(201);
    const ses = (await r.json()) as { id: string; pin: string };
    const s = ioc(url, {
      path: `${BASE}/socket.io`,
      auth: { peran: "penonton", pin: ses.pin },
      transports: ["websocket"],
      reconnection: false,
    });
    sock.push(s);
    await new Promise<void>((res, rej) => {
      s.on("connect", () => res());
      s.on("connect_error", rej);
    });
    const salah = ioc(url, {
      path: "/socket.io",
      auth: { peran: "penonton", pin: ses.pin },
      transports: ["websocket"],
      reconnection: false,
    });
    sock.push(salah);
    await expect(
      new Promise<void>((res, rej) => {
        salah.on("connect", () => res());
        salah.on("connect_error", rej);
      }),
    ).rejects.toBeTruthy();
  });
  it("TRUST_PROXY: batas percobaan PIN per IP memakai X-Forwarded-For (IP berbeda tidak saling mengunci)", async () => {
    const coba = (ip: string) =>
      fetch(`${url}${BASE}/api/lookup`, {
        method: "POST",
        headers: { "content-type": "application/json", "x-forwarded-for": ip },
        body: JSON.stringify({ pin: "000000" }),
      });
    let st = 0;
    for (let i = 0; i < 11; i++) st = (await coba("10.0.0.1")).status;
    expect(st).toBe(429);
    expect((await coba("10.0.0.2")).status).toBe(404); // IP lain belum terkunci
  });
  it("tanpa TRUST_PROXY, X-Forwarded-For diabaikan (tak bisa dipalsukan untuk menghindari batas)", async () => {
    const polos = buatApp({ hostPin: HOST_PIN });
    const u = `http://127.0.0.1:${await polos.listen(0, "127.0.0.1")}`;
    let st = 0;
    for (let i = 0; i < 11; i++)
      st = (
        await fetch(`${u}/api/lookup`, {
          method: "POST",
          headers: { "content-type": "application/json", "x-forwarded-for": `9.9.9.${i}` },
          body: JSON.stringify({ pin: "000000" }),
        })
      ).status;
    expect(st).toBe(429);
    await polos.tutup();
  });
});

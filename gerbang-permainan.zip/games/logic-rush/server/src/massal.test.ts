import { describe, expect, it } from "vitest";
import { POIN_MASSAL, validateSettings, defaultSettings, peringkatLangsung } from "@logic-rush/shared";
import { bikinSesi, jawabanBenar } from "./harness";
import type { Sesi } from "./session";
import type { FakeClock } from "./util";

const massal = (n: number, over = {}) => {
  const h = bikinSesi({ format: "massal", bestOf: 1, sorotDetik: 5, batasWaktuDetik: 120, ...over });
  const ids = Array.from({ length: n }, (_, i) => {
    const r = h.sesi.join({ nama: "Anak" + (i + 1) });
    if (!r.ok) throw new Error(r.alasan);
    return r.pid;
  });
  return { ...h, ids };
};
const mulai = (s: Sesi, c: FakeClock, ids: string[]) => {
  const r = s.buatMatch(ids);
  if (!r.ok) throw new Error(r.alasan);
  s.panggil(r.matchId);
  for (const p of ids) s.siap(p, r.matchId);
  expect(s.mulai(r.matchId).ok).toBe(true);
  c.advance(3000);
  return r.matchId;
};

describe("format massal (di atas 3 pemain)", () => {
  it("pengaturan: massal tak boleh memakai kamera", () => {
    const s = {
      ...defaultSettings(),
      format: "massal" as const,
      kamera: { ...defaultSettings().kamera, mode: "opsional" as const, izinOrtuDikonfirmasi: true },
    };
    expect(validateSettings(s).ok).toBe(false);
    expect(validateSettings({ ...defaultSettings(), format: "massal" }).ok).toBe(true);
  });
  it("butuh 4–40 pemain; laga biasa tetap 2–3", () => {
    const { sesi, ids } = massal(6);
    expect(sesi.buatMatch(ids.slice(0, 3)).ok).toBe(false);
    expect(sesi.buatMatch(ids).ok).toBe(true);
    const lain = bikinSesi();
    const ids2 = Array.from({ length: 5 }, (_, i) => (lain.sesi.join({ nama: "P" + i }) as { pid: string }).pid);
    expect(lain.sesi.buatMatch(ids2).ok).toBe(false);
  });
  it("antrean otomatis membuat satu arena berisi semua pemain; 40 pemain didukung", () => {
    const { sesi } = massal(0);
    for (let i = 1; i <= 40; i++) sesi.join({ nama: "Anak" + i });
    expect(sesi.buatAntrean()).toEqual({ ok: true, jumlah: 1 });
    expect(sesi.statePublik().matches[0].pemain.length).toBe(40);
    expect(sesi.statePublik().matches[0].massal).toBe(true);
  });
  it("papan dasar berbeda per pemain, pasangan (papan, transformasi) unik untuk 40 pemain, tanpa kebocoran solusi", () => {
    const { sesi, clock, ids } = massal(40);
    mulai(sesi, clock, ids);
    const pasang = new Set<string>();
    const dasar = new Set<string>();
    for (const id of ids) {
      const b = sesi._papanLengkap(id)!;
      pasang.add(`${b.id}|${b.transform}`);
      dasar.add(b.id as string);
    }
    expect(pasang.size).toBe(40);
    expect(dasar.size).toBeGreaterThan(5);
    expect(JSON.stringify(sesi.statePublik())).not.toMatch(/solution/);
  });
  it("sorotan bergilir tiap 5 detik antar pemain yang masih bermain; hanya langkah yang disorot direlay", () => {
    const { sesi, clock, ids, rekam } = massal(5);
    const mid = mulai(sesi, clock, ids);
    const g = () => sesi.statePublik().matches.find((m) => m.id === mid)!.game!;
    const urutan: string[] = [];
    urutan.push(g().sorotPid as string);
    for (let i = 0; i < 4; i++) {
      clock.advance(5000);
      urutan.push(g().sorotPid as string);
    }
    expect(new Set(urutan).size).toBe(5); // lima giliran, lima pemain berbeda
    expect(g().sorotSampaiTs).toBeGreaterThan(clock.now());
    const sorot = g().sorotPid as string;
    const bukan = ids.find((p) => p !== sorot)!;
    const n0 = rekam.filter((r) => r.ev === "lr:sp").length;
    sesi.ingestSpectate(bukan, { t: "mv", s: 1, op: "gem", r: 0, c: 0, at: 0 });
    expect(rekam.filter((r) => r.ev === "lr:sp").length).toBe(n0); // bukan yang disorot: tidak direlay
    sesi.ingestSpectate(sorot, { t: "mv", s: 1, op: "gem", r: 0, c: 0, at: 0 });
    expect(rekam.filter((r) => r.ev === "lr:sp").length).toBe(n0 + 1);
    expect(sesi.snapsAktif().length).toBe(1);
  });
  it("pemain yang sudah selesai dilewati dalam giliran sorotan; jeda menghentikan giliran", () => {
    const { sesi, clock, ids } = massal(4);
    const mid = mulai(sesi, clock, ids);
    const g = () => sesi.statePublik().matches.find((m) => m.id === mid)!.game!;
    const selesai = ids[0];
    clock.advance(3000);
    sesi.finish(selesai, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, selesai) });
    for (let i = 0; i < 8; i++) {
      clock.advance(5000);
      expect(g().sorotPid).not.toBe(selesai);
    }
    const sebelum = g().sorotPid;
    sesi.jeda(true);
    clock.advance(30_000);
    expect(g().sorotPid).toBe(sebelum);
    sesi.jeda(false);
    clock.advance(5000);
    expect(g().sorotPid).not.toBe(sebelum);
  });
  it("poin massal 10/8/6/5…, pemenang = poin game terbanyak, dan tidak ada kamera/RTC", () => {
    const { sesi, clock, ids } = massal(5);
    const mid = mulai(sesi, clock, ids);
    for (const [i, p] of ids.entries()) {
      clock.advance(2000 + i);
      sesi.finish(p, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, p) });
    }
    const m = sesi.statePublik().matches[0];
    expect(m.status).toBe("selesai");
    expect(m.pemenang).toBe(ids[0]);
    expect(m.games[0].hasil.map((h) => h.poin)).toEqual([...POIN_MASSAL.slice(0, 5)]);
    expect(sesi.boleLihatVideo("host", true)).toBe(false);
    expect(sesi.mintaKamera(ids[0]).ok).toBe(false);
  });
  it("statistik: jumlah validasi keseluruhan dan per papan, waktu median", () => {
    const { sesi, clock, ids } = massal(4);
    const mid = mulai(sesi, clock, ids);
    clock.advance(4000);
    // dua percobaan salah (belum lengkap) lalu benar
    expect(sesi.finish(ids[0], { matchId: mid, gameNo: 1, gems: [{ r: 0, c: 0 }] }).ok).toBe(false);
    expect(
      sesi.finish(ids[0], {
        matchId: mid,
        gameNo: 1,
        gems: [
          { r: 0, c: 0 },
          { r: 1, c: 0 },
        ],
      }).ok,
    ).toBe(false);
    for (const [i, p] of ids.entries()) {
      clock.advance(1000 * (i + 1));
      expect(sesi.finish(p, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, p) }).ok).toBe(true);
    }
    const st = sesi.statistik();
    expect(st.validasi).toEqual({ total: 6, benar: 4, salah: 2 });
    expect(st.papan.length).toBe(1);
    expect(st.papan[0]).toMatchObject({ pemain: 4, selesai: 4, validasi: 6, benar: 4, salah: 2, n: 4 });
    expect(st.papan[0].waktuMedianMs).toBeGreaterThan(0);
    expect(st.papan[0].papan.length).toBeGreaterThan(1);
    expect(st.pemain.find((p) => p.pid === ids[0])).toMatchObject({ validasi: 3, benar: 1, salah: 2, selesai: 1 });
  });
  it("papan peringkat langsung: selesai tercepat di atas, lalu permata terbanyak", () => {
    const r = peringkatLangsung([
      { pid: "a", gems: 2, selesaiMs: null, hints: 0, pelanggaran: 0, done: 0, total: 1 },
      { pid: "b", gems: 4, selesaiMs: 9000, hints: 0, pelanggaran: 0, done: 1, total: 1 },
      { pid: "c", gems: 3, selesaiMs: null, hints: 0, pelanggaran: 0, done: 0, total: 1 },
      { pid: "d", gems: 4, selesaiMs: 7000, hints: 0, pelanggaran: 0, done: 1, total: 1 },
    ]);
    expect(r.map((x) => x.pid + x.rank)).toEqual(["d1", "b2", "c3", "a4"]);
  });
  it("klasemen sementara: kalah dan game dimainkan dihitung", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1 });
    const [a, b] = ["A", "B"].map((n) => (sesi.join({ nama: n }) as { pid: string }).pid);
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    sesi.panggil(mid);
    sesi.siap(a, mid);
    sesi.siap(b, mid);
    sesi.mulai(mid);
    clock.advance(3000);
    clock.advance(2000);
    sesi.finish(a, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, a) });
    clock.advance(1000);
    sesi.finish(b, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, b) });
    const sk = sesi.statePublik().skor;
    expect(sk.find((s) => s.pid === a)).toMatchObject({ pertandinganMenang: 1, kalah: 0, gameMain: 1 });
    expect(sk.find((s) => s.pid === b)).toMatchObject({ pertandinganMenang: 0, kalah: 1, gameMain: 1 });
  });
});

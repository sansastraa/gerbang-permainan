// Daftar sesi aktif: PIN 6 digit unik, kedaluwarsa 180 menit.
import crypto from "node:crypto";
import path from "node:path";
import { CONFIG } from "@logic-rush/shared";
import type { SesiSettings } from "@logic-rush/shared";
import { Sesi } from "./session";
import type { Emit } from "./session";
import type { Bank } from "./util";
import type { Clock } from "./util";

export class Registry {
  private byId = new Map<string, Sesi>();
  private byPin = new Map<string, string>();
  constructor(
    private clock: Clock,
    private bank: Bank,
    private emitFor: (sesiId: string) => Emit,
    private dataDir?: string,
  ) {}

  private buatPin(): string {
    for (let i = 0; i < 1000; i++) {
      const pin = String(crypto.randomInt(0, 10 ** CONFIG.pin.panjang)).padStart(CONFIG.pin.panjang, "0");
      if (!this.byPin.has(pin)) return pin;
    }
    throw new Error("PIN habis");
  }
  buat(settings: SesiSettings): Sesi {
    this.bersihkan();
    const id = "lr-" + crypto.randomBytes(5).toString("hex");
    const pin = this.buatPin();
    const sesi = new Sesi({
      id,
      pin,
      settings,
      clock: this.clock,
      emit: this.emitFor(id),
      bank: this.bank,
      seed: id,
      ...(this.dataDir ? { logFile: path.join(this.dataDir, "sessions", id + ".jsonl") } : {}),
    });
    this.byId.set(id, sesi);
    this.byPin.set(pin, id);
    return sesi;
  }
  get(id: string): Sesi | undefined {
    return this.byId.get(id);
  }
  dariPin(pin: string): Sesi | undefined {
    this.bersihkan();
    const id = this.byPin.get(pin);
    return id ? this.byId.get(id) : undefined;
  }
  semua(): Sesi[] {
    return [...this.byId.values()];
  }
  hapus(id: string): void {
    const s = this.byId.get(id);
    if (s) this.byPin.delete(s.pin);
    this.byId.delete(id);
  }
  /** PIN kedaluwarsa setelah N menit: sesi tetap ada untuk ekspor hasil, tetapi PIN tak bisa dipakai masuk lagi. */
  bersihkan(): void {
    const now = this.clock.now();
    for (const [pin, id] of this.byPin) {
      const s = this.byId.get(id);
      if (s && now - s.dibuat > CONFIG.pin.kedaluwarsa_menit * 60_000) this.byPin.delete(pin);
    }
  }
}

// Harness tes sesi: jam terkendali + perekam kejadian keluar. Juga dipakai simulator bot.
import { defaultSettings, settingsSchema } from "@logic-rush/shared";
import type { Cell, SesiSettings } from "@logic-rush/shared";
import { Sesi } from "./session";
import type { Emit, Target } from "./session";
import { Bank, FakeClock } from "./util";

export interface Rekam {
  t: Target;
  ev: string;
  payload: unknown;
}
export function bikinSesi(
  over: Partial<SesiSettings> = {},
  seed = "tes",
): { sesi: Sesi; clock: FakeClock; rekam: Rekam[]; bank: Bank } {
  const clock = new FakeClock();
  const rekam: Rekam[] = [];
  const emit: Emit = (t, ev, payload) => {
    // Pengaman utama: tak satu pun muatan keluar boleh memuat solusi papan
    const s = JSON.stringify(payload);
    if (/"solution"/.test(s)) throw new Error(`BOCOR: ${ev} memuat solution`);
    rekam.push({ t, ev, payload: JSON.parse(s) });
  };
  const bank = new Bank();
  const base = defaultSettings();
  const settings = settingsSchema.parse({
    ...base,
    tahap: [
      { n: 4, arsir: false, diagonal: false, level: "mudah" },
      { n: 5, arsir: true, diagonal: false, level: "sedang" },
    ],
    hitungMundurDetik: 3,
    papanPerGame: 1,
    ...over,
  });
  const sesi = new Sesi({ id: "s1", pin: "123456", settings, clock, emit, bank, seed });
  return { sesi, clock, rekam, bank };
}

/** Isi permata benar menurut papan lengkap server (hanya untuk tes/bot lokal). */
export function jawabanBenar(sesi: Sesi, pid: string): Cell[] {
  const b = sesi._papanLengkap(pid);
  if (!b?.solution) throw new Error("tak ada papan aktif untuk " + pid);
  return b.solution.map((c, r) => ({ r, c }));
}

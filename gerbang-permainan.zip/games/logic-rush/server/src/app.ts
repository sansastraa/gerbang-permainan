// HTTP + Socket.IO. Server = wasit; sinyal WebRTC hanya meneruskan SDP/ICE (tidak ada media di server).
import crypto from "node:crypto";
import fs from "node:fs";
import http from "node:http";
import path from "node:path";
import express from "express";
import { Server } from "socket.io";
import type { Socket } from "socket.io";
import {
  CONFIG,
  defaultSettings,
  finishSchema,
  hintSchema,
  joinSchema,
  presetTahap,
  rosterSchema,
  rtcAnswerSchema,
  rtcIceSchema,
  rtcOfferSchema,
  rtcWatchSchema,
  validateSettings,
} from "@logic-rush/shared";
import type { SesiSettings } from "@logic-rush/shared";
import { Registry } from "./registry";
import type { Emit, Sesi, Target } from "./session";
import { Bank, PinGuard, realClock } from "./util";
import type { Clock } from "./util";
import { csvHasil } from "./export";

export interface AppOpsi {
  hostPin: string;
  allowedOrigins?: string[];
  clock?: Clock;
  bank?: Bank;
  staticDir?: string;
  dataDir?: string;
  iceServers?: unknown[];
  /** Awalan jalur, mis. "/games/logic-rush" (kosong = di akar). Dinormalisasi: diawali /, tanpa / akhir. */
  basePath?: string;
  /** Percayai X-Forwarded-For (hanya di belakang gerbang tepercaya) untuk batas percobaan PIN per IP. */
  trustProxy?: boolean;
}

export const normalisasiBasePath = (b?: string | null): string => {
  let s = (b ?? "").trim();
  if (!s || s === "/") return "";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "");
};
type Peran = "host" | "pemain" | "penonton" | "obs";
interface Data {
  peran: Peran;
  sesiId: string;
  pid?: string;
  obsBerkunci?: boolean;
}
type Ack = (res: unknown) => void;
const ack = (cb: unknown, res: unknown): void => {
  if (typeof cb === "function") (cb as Ack)(res);
};
const sama = (a: string, b: string): boolean => {
  const x = Buffer.from(a);
  const y = Buffer.from(b);
  return x.length === y.length && crypto.timingSafeEqual(x, y);
};

export function buatApp(o: AppOpsi) {
  const clock = o.clock ?? realClock;
  const bank = o.bank ?? new Bank();
  const origins = new Set(o.allowedOrigins ?? []);
  const basePath = normalisasiBasePath(o.basePath);
  const trustProxy = o.trustProxy === true;
  const app = express();
  /** Semua rute (health, api, statis, SPA) hidup di bawah basePath; di akar bila kosong. */
  const raut = express.Router();
  /** IP klien: X-Forwarded-For hanya dipercaya bila trustProxy (gerbang menulis ulang dan membuang kiriman klien). */
  const ipDari = (xff: unknown, langsung: string | undefined): string => {
    const v = Array.isArray(xff) ? xff[0] : xff;
    if (trustProxy && typeof v === "string" && v.trim()) return v.split(",")[0]!.trim();
    return langsung ?? "?";
  };
  const server = http.createServer(app);
  const io = new Server(server, {
    path: `${basePath}/socket.io`,
    cors: { origin: o.allowedOrigins?.length ? [...origins] : true },
    maxHttpBufferSize: 64_000,
    pingInterval: 10_000,
    pingTimeout: 10_000,
  });
  const pinGuard = new PinGuard(clock);
  const hostGuard = new PinGuard(clock, 20);

  const emitFor =
    (sesiId: string): Emit =>
    (t: Target, ev: string, payload: unknown) => {
      const room =
        t.k === "sesi"
          ? `s:${sesiId}`
          : t.k === "host"
            ? `h:${sesiId}`
            : t.k === "pemain"
              ? `p:${sesiId}:${t.pid}`
              : `w:${sesiId}`;
      io.to(room).emit(ev, payload);
    };
  const reg = new Registry(clock, bank, emitFor, o.dataDir);
  /** pid → id socket pemain, per sesi (untuk sinyal WebRTC) */
  const sockPemain = new Map<string, Map<string, string>>();

  // ------------------------------------------------------------ HTTP
  app.disable("x-powered-by");
  app.use(express.json({ limit: "64kb" }));
  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (origins.size === 0 || origins.has(origin))) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Headers", "content-type, x-host-token");
      res.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
    }
    if (req.method === "OPTIONS") return void res.sendStatus(204);
    next();
  });
  raut.get("/health", (_req, res) => void res.json({ ok: true, game: "logic-rush", sesi: reg.semua().length }));

  const adalahHost = (req: express.Request): boolean => {
    const t = req.header("x-host-token") ?? "";
    return t.length > 0 && sama(t, o.hostPin);
  };
  const jagaHost = (req: express.Request, res: express.Response): boolean => {
    const key = ipDari(req.headers["x-forwarded-for"], req.ip);
    const sisa = hostGuard.terkunci(key);
    if (sisa)
      return (
        void res.status(429).json({ error: "Terlalu banyak percobaan. Coba lagi nanti.", sisaDetik: sisa }),
        false
      );
    if (!adalahHost(req)) return (hostGuard.gagal(key), void res.status(401).json({ error: "PIN guru salah." }), false);
    hostGuard.berhasil(key);
    return true;
  };

  raut.get("/api/presets", (_req, res) => {
    res.json({
      bawaan: CONFIG.papan.preset_bawaan,
      preset: Object.fromEntries(
        Object.entries(CONFIG.papan.preset).map(([k, v]) => [k, { label: v.label, tahap: presetTahap(k) }]),
      ),
      batas: {
        ukuranMin: CONFIG.papan.ukuran_min,
        ukuranMaks: CONFIG.papan.ukuran_maks,
        tahap: CONFIG.papan.jumlah_tahap,
      },
      bawaanPengaturan: defaultSettings(),
    });
  });
  raut.get("/api/ice", (_req, res) => void res.json({ iceServers: o.iceServers ?? [] }));

  /** Guru membuat sesi (PIN guru di header). */
  raut.post("/api/sessions", (req, res) => {
    if (!jagaHost(req, res)) return;
    const v = validateSettings(req.body?.settings ?? defaultSettings());
    if (!v.ok) return void res.status(400).json({ error: v.errors.join(" "), errors: v.errors });
    const s = reg.buat(v.value);
    if (Array.isArray(req.body?.roster)) {
      const r = rosterSchema.safeParse(req.body.roster);
      if (!r.success) return void res.status(400).json({ error: "Daftar siswa tidak sah." });
      s.setRoster(r.data);
    }
    res.status(201).json({ id: s.id, pin: s.pin, obsKey: s.obsKey, settings: v.value });
  });
  /** Murid memeriksa PIN: mengembalikan nama sesi dan daftar hadir (tanpa data lain). Dibatasi percobaan per IP. */
  raut.post("/api/lookup", (req, res) => {
    const key = ipDari(req.headers["x-forwarded-for"], req.ip);
    const sisa = pinGuard.terkunci(key);
    if (sisa)
      return void res.status(429).json({ error: `Terlalu banyak percobaan. Tunggu ${sisa} detik.`, sisaDetik: sisa });
    const pin = String(req.body?.pin ?? "");
    const s = /^\d{6}$/.test(pin) ? reg.dariPin(pin) : undefined;
    if (!s || s.status === "selesai")
      return (pinGuard.gagal(key), void res.status(404).json({ error: "PIN tidak ditemukan." }));
    pinGuard.berhasil(key);
    res.json({ id: s.id, nama: s.settings.nama, roster: s.rosterPublik(), kamera: s.settings.kamera.mode });
  });
  raut.get("/api/sessions/:id/summary.json", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    if (s.status !== "selesai" && req.query.includeTest !== "1")
      return void res.status(403).json({ error: "Sesi belum selesai." });
    res.json(s.ringkasan());
  });
  raut.get("/api/sessions/:id/results.csv", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.type("text/csv; charset=utf-8").send(csvHasil(s.ringkasan()));
  });
  raut.get("/api/sessions/:id/statistik.json", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.json(s.statistik());
  });
  raut.get("/api/sessions/:id/log.jsonl", (req, res) => {
    const s = reg.get(req.params.id);
    if (!s) return void res.sendStatus(404);
    if (!jagaHost(req, res)) return;
    res.type("application/x-ndjson").send(s.log.rows.map((r) => JSON.stringify(r)).join("\n"));
  });

  if (o.staticDir && fs.existsSync(o.staticDir)) {
    raut.use(express.static(o.staticDir, { maxAge: "1h", index: "index.html" }));
    raut.get(
      /^\/(?!api|socket\.io|health).*/,
      (_req, res) => void res.sendFile(path.join(o.staticDir as string, "index.html")),
    );
  }
  app.use(basePath || "/", raut);

  // ------------------------------------------------------------ Socket.IO
  const sesiDari = (sock: Socket): { s: Sesi; d: Data } | null => {
    const d = sock.data as Data;
    const s = d.sesiId ? reg.get(d.sesiId) : undefined;
    return s ? { s, d } : null;
  };
  const tolak = (cb: unknown, alasan: string): void => ack(cb, { ok: false, alasan });

  io.use((sock, next) => {
    const a = (sock.handshake.auth ?? {}) as Record<string, unknown>;
    const peran = a.peran as Peran;
    const key = ipDari(sock.handshake.headers["x-forwarded-for"], sock.handshake.address);
    if (!["host", "pemain", "penonton", "obs"].includes(peran)) return next(new Error("peran tidak dikenal"));
    if (peran === "host") {
      const sisa = hostGuard.terkunci(key);
      if (sisa) return next(new Error(`terkunci ${sisa}`));
      if (typeof a.hostToken !== "string" || !sama(a.hostToken, o.hostPin))
        return (hostGuard.gagal(key), next(new Error("PIN guru salah")));
      const s = typeof a.sesiId === "string" ? reg.get(a.sesiId) : undefined;
      if (!s) return next(new Error("sesi tidak ditemukan"));
      hostGuard.berhasil(key);
      sock.data = { peran, sesiId: s.id } satisfies Data;
      return next();
    }
    // pemain/penonton/obs: PIN sesi (dibatasi percobaan), atau id sesi + token pemain untuk masuk ulang
    let s: Sesi | undefined;
    if (peran === "pemain" && typeof a.sesiId === "string" && typeof a.token === "string") s = reg.get(a.sesiId);
    if (!s) {
      const sisa = pinGuard.terkunci(key);
      if (sisa) return next(new Error(`terkunci ${sisa}`));
      s = typeof a.pin === "string" && /^\d{6}$/.test(a.pin) ? reg.dariPin(a.pin) : undefined;
      if (!s) return (pinGuard.gagal(key), next(new Error("PIN tidak ditemukan")));
      pinGuard.berhasil(key);
    }
    if (peran === "penonton" && !s.settings.penontonBolehMasuk) return next(new Error("penonton tidak diizinkan"));
    const obsBerkunci = peran === "obs" && typeof a.obsKey === "string" && sama(a.obsKey, s.obsKey);
    sock.data = { peran, sesiId: s.id, obsBerkunci } satisfies Data;
    next();
  });

  io.on("connection", (sock) => {
    const d0 = sock.data as Data;
    const s0 = reg.get(d0.sesiId)!;
    void sock.join(`s:${s0.id}`);
    if (d0.peran === "host") void sock.join(`h:${s0.id}`);
    // semua peran boleh menonton papan (ringan: maks 3 pemain per pertandingan)
    sock.emit("lr:state", s0.statePublik());
    if (d0.peran === "host") sock.emit("lr:host-extra", s0.hostExtra());

    // ---------------- penonton
    sock.on("lr:tonton", (_p: unknown, cb: unknown) => {
      const c = sesiDari(sock);
      if (!c) return tolak(cb, "sesi hilang");
      void sock.join(`w:${c.s.id}`);
      for (const { pid, msg } of c.s.snapsAktif()) sock.emit("lr:sp", { pid, msg });
      ack(cb, { ok: true });
    });
    sock.on("lr:berhenti-tonton", () => void sock.leave(`w:${d0.sesiId}`));

    // ---------------- pemain
    sock.on("lr:join", (p: unknown, cb: unknown) => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "pemain") return tolak(cb, "bukan pemain");
      const parsed = joinSchema.safeParse({ pin: c.s.pin, ...(p as object) });
      if (!parsed.success) return tolak(cb, "Data masuk tidak sah.");
      const r = c.s.join(parsed.data);
      if (!r.ok) return tolak(cb, r.alasan);
      c.d.pid = r.pid;
      void sock.join(`p:${c.s.id}:${r.pid}`);
      void sock.join(`w:${c.s.id}`);
      const m = sockPemain.get(c.s.id) ?? new Map<string, string>();
      m.set(r.pid, sock.id);
      sockPemain.set(c.s.id, m);
      ack(cb, { ok: true, pid: r.pid, token: r.token, pemain: r.pemain, sesiId: c.s.id });
      const b = c.s.boardUntuk(r.pid);
      if (b) sock.emit("lr:board", b);
      for (const { pid, msg } of c.s.snapsAktif()) sock.emit("lr:sp", { pid, msg });
    });
    const pemainSaja = (cb: unknown): { s: Sesi; pid: string } | null => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "pemain" || !c.d.pid) return (tolak(cb, "Masuk dulu."), null);
      return { s: c.s, pid: c.d.pid };
    };
    sock.on("lr:siap", (p: { matchId?: string; siap?: boolean }, cb: unknown) => {
      const c = pemainSaja(cb);
      if (c) ack(cb, c.s.siap(c.pid, String(p?.matchId ?? ""), p?.siap !== false));
    });
    sock.on("lr:sp", (raw: unknown) => {
      const c = pemainSaja(null);
      if (c) c.s.ingestSpectate(c.pid, raw);
    });
    sock.on("lr:finish", (p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      const parsed = finishSchema.safeParse(p);
      if (!parsed.success) return tolak(cb, "Data tidak sah.");
      ack(cb, c.s.finish(c.pid, parsed.data));
    });
    sock.on("lr:hint", (p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (!c) return;
      const parsed = hintSchema.safeParse(p);
      if (!parsed.success) return tolak(cb, "Data tidak sah.");
      ack(cb, c.s.hint(c.pid, parsed.data));
    });
    sock.on("lr:fokus", (p: { ms?: number }) => {
      const c = pemainSaja(null);
      if (c && Number.isFinite(p?.ms)) c.s.fokusHilang(c.pid, Number(p.ms));
    });
    sock.on("kamera:minta", (_p: unknown, cb: unknown) => {
      const c = pemainSaja(cb);
      if (c) ack(cb, c.s.mintaKamera(c.pid));
    });
    sock.on("kamera:status", (p: { on?: boolean; mikrofon?: boolean }, cb: unknown) => {
      const c = pemainSaja(cb);
      if (c) ack(cb, c.s.kameraMenyala(c.pid, !!p?.on, !!p?.mikrofon));
    });
    sock.on("lr:ping", (_p: unknown, cb: unknown) => ack(cb, { serverTs: clock.now() }));

    // ---------------- WebRTC: sinyal saja
    sock.on("rtc:watch", (p: unknown, cb: unknown) => {
      const c = sesiDari(sock);
      const parsed = rtcWatchSchema.safeParse(p);
      if (!c || !parsed.success) return tolak(cb, "Data tidak sah.");
      const { pid, wantVideo } = parsed.data;
      const pem = c.s.getPemain(pid);
      const peranLihat = c.d.peran === "host" ? "host" : c.d.peran === "obs" ? "obs" : "penonton";
      if (!pem || pem.dikeluarkan) return tolak(cb, "Pemain tidak ditemukan.");
      if (!wantVideo || pem.kamera !== "menyala")
        return ack(cb, { ok: true, video: false, alasan: pem.kamera === "menyala" ? "tanpa-video" : "kamera-mati" });
      if (!c.s.boleLihatVideo(peranLihat, !!c.d.obsBerkunci))
        return ack(cb, { ok: true, video: false, alasan: "tidak-diizinkan" });
      const ps = sockPemain.get(c.s.id)?.get(pid);
      if (!ps) return ack(cb, { ok: true, video: false, alasan: "pemain-terputus" });
      if (!c.s.tambahPenontonVideo(pid, sock.id)) return ack(cb, { ok: true, video: false, alasan: "kuota" });
      io.to(ps).emit("rtc:viewer-request", { viewerId: sock.id, peran: peranLihat });
      ack(cb, { ok: true, video: true });
    });
    sock.on("rtc:unwatch", (p: { pid?: string }) =>
      c0(sock)?.hapusPenontonVideo(sock.id, typeof p?.pid === "string" ? p.pid : undefined),
    );
    sock.on("rtc:fallback", (p: { pid?: string }) => {
      const c = sesiDari(sock);
      if (c && typeof p?.pid === "string") c.s.catatFallbackRelay(sock.id, p.pid);
    });
    sock.on("rtc:offer", (p: unknown) => {
      const c = pemainSaja(null);
      const parsed = rtcOfferSchema.safeParse(p);
      if (c && parsed.success) io.to(parsed.data.viewerId).emit("rtc:offer", { pid: c.pid, sdp: parsed.data.sdp });
    });
    sock.on("rtc:answer", (p: unknown) => {
      const c = sesiDari(sock);
      const parsed = rtcAnswerSchema.safeParse(p);
      if (!c || !parsed.success) return;
      const ps = sockPemain.get(c.s.id)?.get(parsed.data.pid);
      if (ps) io.to(ps).emit("rtc:answer", { viewerId: sock.id, sdp: parsed.data.sdp });
    });
    sock.on("rtc:ice", (p: unknown) => {
      const c = sesiDari(sock);
      const parsed = rtcIceSchema.safeParse(p);
      if (!c || !parsed.success) return;
      if (c.d.peran === "pemain" && parsed.data.viewerId)
        io.to(parsed.data.viewerId).emit("rtc:ice", { pid: c.d.pid, candidate: parsed.data.candidate });
      else if (parsed.data.pid) {
        const ps = sockPemain.get(c.s.id)?.get(parsed.data.pid);
        if (ps) io.to(ps).emit("rtc:ice", { viewerId: sock.id, candidate: parsed.data.candidate });
      }
    });
    const c0 = (sk: Socket): Sesi | undefined => sesiDari(sk)?.s;

    // ---------------- operator (host)
    const hostSaja = (cb: unknown): Sesi | null => {
      const c = sesiDari(sock);
      if (!c || c.d.peran !== "host") return (tolak(cb, "Khusus guru."), null);
      return c.s;
    };
    const aksi: Record<string, (s: Sesi, p: Record<string, unknown>) => unknown> = {
      "host:match-buat": (s, p) => s.buatMatch(Array.isArray(p.pids) ? p.pids.map(String) : []),
      "host:antrean": (s, p) => s.buatAntrean(p.ukuran === 3 ? 3 : p.ukuran === 2 ? 2 : s.settings.ukuranPertandingan),
      "host:babak-berikut": (s) => s.babakBerikut(),
      "host:panggil": (s, p) => s.panggil(String(p.mid)),
      "host:mulai": (s, p) => s.mulai(String(p.mid), p.paksa === true),
      "host:lanjut": (s, p) => s.lanjut(String(p.mid)),
      "host:akhiri-game": (s, p) => s.akhiriGame(String(p.mid)),
      "host:batal": (s, p) => s.batalMatch(String(p.mid)),
      "host:jeda": (s, p) => s.jeda(p.on !== false),
      "host:game-tambahan": (s, p) => s.gameTambahan(String(p.mid)),
      "host:kick": (s, p) => s.kick(String(p.pid)),
      "host:kamera-izin": (s, p) => s.izinKamera(String(p.pid), p.izin === true),
      "host:statistik": (s) => ({ ok: true, statistik: s.statistik() }),
      "host:selesai-sesi": (s) => (s.selesaikanSesi(), { ok: true }),
      "host:roster": (s, p) => {
        const r = rosterSchema.safeParse(p.items);
        if (!r.success) return { ok: false, alasan: "Daftar siswa tidak sah." };
        s.setRoster(r.data);
        return { ok: true };
      },
      "host:settings": (s, p) => {
        if (s.statePublik().matches.length)
          return { ok: false, alasan: "Pengaturan tidak bisa diubah setelah pertandingan dibuat." };
        const v = validateSettings(p.settings);
        if (!v.ok) return { ok: false, alasan: v.errors.join(" ") };
        s.settings = v.value as SesiSettings;
        s.flushState();
        return { ok: true };
      },
    };
    for (const [ev, fn] of Object.entries(aksi))
      sock.on(ev, (p: unknown, cb: unknown) => {
        const s = hostSaja(cb);
        if (!s) return;
        try {
          ack(cb, fn(s, (p ?? {}) as Record<string, unknown>));
        } catch (e) {
          ack(cb, { ok: false, alasan: e instanceof Error ? e.message : "Galat." });
        }
        s.flushState();
      });

    sock.on("disconnect", () => {
      const c = sesiDari(sock);
      if (!c) return;
      c.s.hapusPenontonVideo(sock.id);
      if (c.d.peran === "pemain" && c.d.pid) {
        const m = sockPemain.get(c.s.id);
        if (m?.get(c.d.pid) === sock.id) {
          m.delete(c.d.pid);
          c.s.setTerhubung(c.d.pid, false);
        }
      }
    });
  });

  return {
    app,
    server,
    io,
    reg,
    bank,
    listen: (port: number, host: string) =>
      new Promise<number>((resolve) =>
        server.listen(port, host, () => resolve((server.address() as { port: number }).port)),
      ),
    tutup: () =>
      new Promise<void>((resolve) => {
        void io.close(() => resolve());
      }),
  };
}
export type App = ReturnType<typeof buatApp>;

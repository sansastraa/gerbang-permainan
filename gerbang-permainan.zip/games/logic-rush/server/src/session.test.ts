import { describe, expect, it } from "vitest";
import { spectate as SP, publicBoard } from "@logic-rush/shared";
import { bikinSesi, jawabanBenar } from "./harness";
import { EventLog } from "./util";
import type { Sesi } from "./session";
import type { FakeClock } from "./util";

const masuk = (s: Sesi, nama: string) => {
  const r = s.join({ nama });
  if (!r.ok) throw new Error(r.alasan);
  return r.pid;
};
/** panggil → semua siap → mulai → hitung mundur lewat → game berjalan */
const mulaiMatch = (s: Sesi, c: FakeClock, mid: string) => {
  expect(s.panggil(mid).ok).toBe(true);
  for (const p of s.statePublik().matches.find((m) => m.id === mid)!.pemain) s.siap(p, mid);
  expect(s.mulai(mid).ok).toBe(true);
  c.advance(3000);
};
const mainSampaiSelesai = (s: Sesi, c: FakeClock, mid: string, urutan: string[], selangMs = 4000) => {
  const m = s.statePublik().matches.find((x) => x.id === mid)!;
  const gameNo = m.game!.no;
  for (const pid of urutan) {
    c.advance(selangMs);
    const r = s.finish(pid, { matchId: mid, gameNo, gems: jawabanBenar(s, pid) });
    expect(r.ok).toBe(true);
  }
};

describe("masuk sesi", () => {
  it("nama kembar diberi akhiran, nama kasar ditolak, ke-41 ditolak", () => {
    const { sesi } = bikinSesi();
    expect(sesi.join({ nama: "Rina" }).ok).toBe(true);
    const r2 = sesi.join({ nama: "Rina" });
    expect(r2.ok && r2.pemain.nama).toBe("Rina 2");
    expect(sesi.join({ nama: "dasar anjing" }).ok).toBe(false);
    expect(sesi.join({ nama: "   " }).ok).toBe(false);
    for (let i = 3; i <= 40; i++) expect(sesi.join({ nama: "Anak" + i }).ok).toBe(true);
    const penuh = sesi.join({ nama: "Terlambat" });
    expect(penuh).toEqual({ ok: false, alasan: "Sesi penuh." });
  });
  it("token masuk ulang memulihkan pemain yang sama; nama dipotong 16 karakter", () => {
    const { sesi } = bikinSesi();
    const a = sesi.join({ nama: "Nama yang sangat panjang sekali" });
    if (!a.ok) throw new Error();
    expect(a.pemain.nama.length).toBeLessThanOrEqual(16);
    sesi.setTerhubung(a.pid, false);
    const b = sesi.join({ token: a.token });
    expect(b.ok && b.pid).toBe(a.pid);
    expect(sesi.join({ token: "salah", nama: "Lain" }).ok).toBe(true);
  });
  it("daftar hadir: wajib memilih nama; satu nama satu perangkat", () => {
    const { sesi } = bikinSesi();
    sesi.setRoster([
      { siswaId: 11, nama: "Budi", absen: 1 },
      { siswaId: 12, nama: "Citra", absen: 2 },
    ]);
    expect(sesi.join({ nama: "Budi" }).ok).toBe(false);
    const a = sesi.join({ siswaId: 11 });
    expect(a.ok && a.pemain.absen).toBe(1);
    expect(sesi.join({ siswaId: 11 }).ok).toBe(false);
    expect(sesi.join({ siswaId: 999 }).ok).toBe(false);
  });
  it("kick mengeluarkan pemain dan token lamanya tidak berlaku", () => {
    const { sesi } = bikinSesi();
    const a = sesi.join({ nama: "Doni" });
    if (!a.ok) throw new Error();
    expect(sesi.kick(a.pid).ok).toBe(true);
    expect(sesi.join({ token: a.token }).ok).toBe(false);
    expect(sesi.statePublik().pemain.length).toBe(0);
  });
});

describe("pertandingan 2–3 pemain", () => {
  it("hanya 2 atau 3 pemain; satu pemain tak bisa ada di dua pertandingan terbuka", () => {
    const { sesi } = bikinSesi();
    const [a, b, c, d] = ["A", "B", "C", "D"].map((n) => masuk(sesi, n));
    expect(sesi.buatMatch([a]).ok).toBe(false);
    expect(sesi.buatMatch([a, b, c, d]).ok).toBe(false);
    expect(sesi.buatMatch([a, a]).ok).toBe(false);
    expect(sesi.buatMatch([a, b]).ok).toBe(true);
    expect(sesi.buatMatch([b, c]).ok).toBe(false);
    expect(sesi.buatMatch([c, d]).ok).toBe(true);
  });
  it("antrean otomatis membagi semua pemain ke kelompok 2–3", () => {
    const { sesi } = bikinSesi({ ukuranPertandingan: 3 });
    for (let i = 1; i <= 7; i++) masuk(sesi, "P" + i);
    const r = sesi.buatAntrean();
    expect(r).toEqual({ ok: true, jumlah: 3 });
    const ms = sesi.statePublik().matches;
    expect(ms.map((m) => m.pemain.length).sort()).toEqual([2, 2, 3]);
    expect(sesi.buatAntrean().ok).toBe(false);
  });
  it("papan dasar SAMA untuk semua, tetapi transformasi/warna zona berbeda; muatan tak pernah memuat solusi", () => {
    const { sesi, clock, rekam } = bikinSesi({ ukuranPertandingan: 3 });
    const ids = ["A", "B", "C"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch(ids) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    const boards = rekam
      .filter((r) => r.ev === "lr:board")
      .map((r) => (r.payload as { board: { id: string; zones: string[] } }).board);
    expect(boards.length).toBe(3);
    expect(new Set(boards.map((b) => b.id)).size).toBe(1);
    expect(new Set(boards.map((b) => b.zones.join())).size).toBe(3);
    const lengkap = ids.map((i) => sesi._papanLengkap(i)!);
    expect(new Set(lengkap.map((b) => b.transform)).size).toBe(3);
    expect(lengkap.every((b) => b.transform !== 0)).toBe(true);
    for (const r of rekam) expect(JSON.stringify(r.payload)).not.toMatch(/solution/);
    expect(JSON.stringify(sesi.statePublik())).not.toMatch(/solution/);
    // yang dikirim tepat publicBoard()
    for (const [i, id] of ids.entries()) {
      const kirim = rekam.find((r) => r.ev === "lr:board" && r.t.k === "pemain" && r.t.pid === id)!.payload as {
        board: unknown;
      };
      expect(kirim.board).toEqual(JSON.parse(JSON.stringify(publicBoard(lengkap[i]))));
    }
  });
  it("best-of-3 duel: pemenang game pertama & kedua menang pertandingan; skor dan ringkasan cocok", () => {
    const { sesi, clock } = bikinSesi();
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    mainSampaiSelesai(sesi, clock, mid, [a, b]); // game 1: Ayu dulu
    let m = sesi.statePublik().matches[0];
    expect(m.status).toBe("rehat");
    expect(m.menang[a]).toBe(1);
    clock.advance(8000); // rehat otomatis → hitung mundur
    clock.advance(3000);
    expect(sesi.statePublik().matches[0].status).toBe("main");
    expect(sesi.statePublik().matches[0].game!.no).toBe(2);
    mainSampaiSelesai(sesi, clock, mid, [b, a]); // game 2: Beni dulu → 1-1
    m = sesi.statePublik().matches[0];
    expect(m.status).toBe("rehat");
    expect(m.menang).toEqual({ [a]: 1, [b]: 1 });
    clock.advance(11000);
    mainSampaiSelesai(sesi, clock, mid, [a, b]); // game 3
    m = sesi.statePublik().matches[0];
    expect(m.status).toBe("selesai");
    expect(m.pemenang).toBe(a);
    const ring = sesi.ringkasan();
    expect(ring.game).toBe("logic-rush");
    const ayu = ring.siswa.find((s) => s.nama === "Ayu")!;
    expect(ayu.peringkat).toBe(1);
    expect(ayu.pertandinganMenang).toBe(1);
    expect(ayu.skor).toBe(5 + 3 + 5 + 5); // 5 (g1) + 3 (g2 kedua) + 5 (g3) + 5 bonus menang
    expect(JSON.stringify(ring)).not.toMatch(/solution/);
    expect(EventLog.verify(sesi.log.rows)).toBe(true);
  });
  it("game selesai lebih awal dari batas bila semua selesai; batas waktu menutup game yang belum selesai", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, batasWaktuDetik: 60 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(20_000);
    expect(sesi.finish(a, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, a) }).ok).toBe(true);
    // masa grasi 60 dtk > sisa batas, jadi tetap batas 60 dtk
    clock.advance(41_000);
    const m = sesi.statePublik().matches[0];
    expect(m.status).toBe("selesai");
    expect(m.pemenang).toBe(a);
    expect(m.games[0].hasil.find((h) => h.pid === b)!.ms).toBeNull();
  });
  it("grasi setelah pemenang memperpendek batas waktu", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, batasWaktuDetik: 600, grasiSetelahPemenangDetik: 30 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(10_000);
    sesi.finish(a, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, a) });
    clock.advance(29_000);
    expect(sesi.statePublik().matches[0].status).toBe("main");
    clock.advance(2000);
    expect(sesi.statePublik().matches[0].status).toBe("selesai");
  });
});

describe("wasit: finish & bantuan", () => {
  it("finish idempoten, menolak belum lengkap/pelanggaran, game lain, dan non-peserta", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 3 });
    const [a, b, z] = ["Ayu", "Beni", "Zed"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    const sol = jawabanBenar(sesi, a);
    clock.advance(5000);
    expect(sesi.finish(a, { matchId: mid, gameNo: 1, gems: sol.slice(0, 3) })).toEqual({
      ok: false,
      alasan: "belum-lengkap",
    });
    const salah = sol.map((c) => ({ ...c }));
    salah[0].c = salah[1].c; // dua permata sekolom
    expect(sesi.finish(a, { matchId: mid, gameNo: 1, gems: salah })).toEqual({ ok: false, alasan: "belum-lengkap" });
    expect(sesi.finish(a, { matchId: mid, gameNo: 2, gems: sol })).toEqual({ ok: false, alasan: "bukan-game-aktif" });
    expect(sesi.finish(z, { matchId: mid, gameNo: 1, gems: sol })).toEqual({ ok: false, alasan: "bukan-peserta" });
    const r1 = sesi.finish(a, { matchId: mid, gameNo: 1, gems: sol });
    const r2 = sesi.finish(a, { matchId: mid, gameNo: 1, gems: sol });
    expect(r1).toEqual(r2);
    expect(r1.ok && r1.ms).toBe(5000);
    expect(sesi.log.rows.filter((r) => r.tipe === "lr.finish_ok").length).toBe(1);
  });
  it("urutan kedatangan = urutan pemeriksaan: finish yang datang lebih dulu menjadi peringkat 1", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, ukuranPertandingan: 3 });
    const ids = ["A", "B", "C"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch(ids) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(7000);
    const hasil = [ids[2], ids[0], ids[1]].map((p) =>
      sesi.finish(p, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, p) }),
    );
    expect(hasil.map((h) => (h.ok ? h.rank : 0))).toEqual([1, 1, 1]); // waktu server sama → seri peringkat 1
    expect(sesi.statePublik().matches[0].status).toBe("selesai");
  });
  it("bantuan: satu per papan, penalti 30 dtk ditambahkan ke waktu efektif, kotak benar yang belum terisi", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(4000);
    const sol = jawabanBenar(sesi, a);
    const h = sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] });
    expect(h.ok).toBe(true);
    if (!h.ok) return;
    expect(sol.some((c) => c.r === h.cell.r && c.c === h.cell.c)).toBe(true);
    expect(h.penaltiMs).toBe(30_000);
    expect(sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] }).ok).toBe(false);
    const r = sesi.finish(a, { matchId: mid, gameNo: 1, gems: sol });
    expect(r.ok && r.ms).toBe(34_000);
  });
  it("bantuan dimatikan guru → ditolak", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, bantuan: { aktif: false, perPapan: 1, penaltiDetik: 30 } });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    expect(sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] }).ok).toBe(false);
  });
  it("jeda membekukan jam: waktu efektif dan batas bergeser sebesar lama jeda", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, batasWaktuDetik: 100 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(10_000);
    expect(sesi.jeda(true).ok).toBe(true);
    clock.advance(500_000); // jauh melewati batas, tapi dijeda
    expect(sesi.statePublik().matches[0].status).toBe("main");
    expect(sesi.jeda(false).ok).toBe(true);
    clock.advance(5000);
    const r = sesi.finish(a, { matchId: mid, gameNo: 1, gems: jawabanBenar(sesi, a) });
    expect(r.ok && r.ms).toBe(15_000);
  });
});

describe("spectate: tampilan server = keadaan pemain, direlay ke penonton", () => {
  it("langkah pemain diterapkan berurutan dan direlay; langkah liar ditolak", () => {
    const { sesi, clock, rekam } = bikinSesi({ bestOf: 1 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    const kirim = rekam.find((r) => r.ev === "lr:board" && r.t.k === "pemain" && r.t.pid === a)!.payload as {
      lastS: number;
    };
    const tx = SP.makeSender();
    for (let i = 0; i < kirim.lastS + 1; i++) tx.next({ t: "ping" });
    const n1 = rekam.filter((r) => r.ev === "lr:sp").length;
    sesi.ingestSpectate(a, tx.next({ t: "mv", op: "gem", r: 0, c: 1, at: 0 }));
    sesi.ingestSpectate(a, tx.next({ t: "mv", op: "x", r: 2, c: 2, at: 0 }));
    expect(rekam.filter((r) => r.ev === "lr:sp").length).toBe(n1 + 2);
    sesi.ingestSpectate(a, { t: "mv", s: 99, op: "gem", r: 1, c: 1, at: 0 }); // lompatan → diabaikan
    sesi.ingestSpectate(a, { t: "mv", s: 3, op: "gem", r: 50, c: 1, at: 0 }); // di luar papan → ditolak
    sesi.ingestSpectate(a, "bukan json");
    expect(rekam.filter((r) => r.ev === "lr:sp").length).toBe(n1 + 2);
    expect(sesi.langkah(a).length).toBe(2);
    clock.advance(200);
    const live = sesi.statePublik().matches[0].game!.pemain[a];
    expect(live.gems).toBe(1);
  });
  it("pemain yang masuk ulang menerima keadaan terakhirnya (tanpa solusi)", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    sesi.ingestSpectate(a, { t: "mv", s: 1, op: "gem", r: 0, c: 0, at: 0 });
    const lagi = sesi.boardUntuk(a)!;
    expect(lagi.lastS).toBe(1);
    expect(lagi.gems).toEqual([{ r: 0, c: 0 }]);
    expect(JSON.stringify(lagi)).not.toMatch(/solution/);
  });
});

describe("kamera & privasi", () => {
  it("kamera mati total secara bawaan; opsional butuh izin orang tua dan persetujuan guru", () => {
    const mati = bikinSesi();
    const a = masuk(mati.sesi, "Ayu");
    expect(mati.sesi.mintaKamera(a).ok).toBe(false);
    const { sesi } = bikinSesi({
      kamera: {
        mode: "opsional",
        persetujuanGuru: true,
        izinOrtuDikonfirmasi: true,
        mikrofon: false,
        siapaBolehLihat: "operator-obs",
      },
    });
    const p = masuk(sesi, "Ayu");
    expect(sesi.kameraMenyala(p, true).ok).toBe(false); // belum diizinkan
    expect(sesi.mintaKamera(p)).toEqual({ ok: true, status: "meminta" });
    expect(sesi.hostExtra().kameraMinta).toEqual([p]);
    expect(sesi.kameraMenyala(p, true).ok).toBe(false); // masih menunggu guru
    sesi.izinKamera(p, true);
    expect(sesi.kameraMenyala(p, true, true).ok).toBe(true);
    expect(sesi.statePublik().pemain[0].kamera).toBe("menyala");
    expect(sesi.statePublik().pemain[0].mikrofon).toBe(false); // mikrofon dimatikan guru
    sesi.izinKamera(p, false);
    expect(sesi.statePublik().pemain[0].kamera).toBe("mati");
  });
  it("siapa boleh lihat video: operator selalu, OBS hanya dengan kunci, penonton biasa hanya bila diizinkan; kuota per pemain", () => {
    const { sesi } = bikinSesi({
      kamera: {
        mode: "opsional",
        persetujuanGuru: false,
        izinOrtuDikonfirmasi: true,
        mikrofon: false,
        siapaBolehLihat: "operator-obs",
      },
    });
    expect(sesi.boleLihatVideo("host", true)).toBe(true);
    expect(sesi.boleLihatVideo("obs", false)).toBe(false);
    expect(sesi.boleLihatVideo("obs", true)).toBe(true);
    expect(sesi.boleLihatVideo("penonton", false)).toBe(false);
    const bebas = bikinSesi({
      kamera: {
        mode: "opsional",
        persetujuanGuru: false,
        izinOrtuDikonfirmasi: true,
        mikrofon: false,
        siapaBolehLihat: "semua",
      },
    });
    expect(bebas.sesi.boleLihatVideo("penonton", false)).toBe(true);
    const mati = bikinSesi();
    expect(mati.sesi.boleLihatVideo("host", true)).toBe(false);
    expect(sesi.tambahPenontonVideo("p1", "v1")).toBe(true);
    expect(sesi.tambahPenontonVideo("p1", "v2")).toBe(true);
    expect(sesi.tambahPenontonVideo("p1", "v3")).toBe(true);
    expect(sesi.tambahPenontonVideo("p1", "v4")).toBe(false);
    sesi.hapusPenontonVideo("v1");
    expect(sesi.tambahPenontonVideo("p1", "v4")).toBe(true);
  });
});

describe("bracket", () => {
  it("antrean → babak berikut → juara", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, ukuranPertandingan: 2 });
    const ids = ["A", "B", "C", "D"].map((n) => masuk(sesi, n));
    expect(sesi.buatAntrean()).toEqual({ ok: true, jumlah: 2 });
    expect(sesi.babakBerikut().ok).toBe(false);
    const juaraPertama: string[] = [];
    for (const m of sesi.statePublik().matches.slice()) {
      mulaiMatch(sesi, clock, m.id);
      mainSampaiSelesai(sesi, clock, m.id, [m.pemain[0], m.pemain[1]]);
      juaraPertama.push(m.pemain[0]);
    }
    const r = sesi.babakBerikut();
    expect(r).toEqual({ ok: true, jumlah: 1 });
    const final = sesi.statePublik().matches.find((m) => m.babak === 2)!;
    expect(final.pemain.sort()).toEqual(juaraPertama.sort());
    mulaiMatch(sesi, clock, final.id);
    mainSampaiSelesai(sesi, clock, final.id, [final.pemain[1], final.pemain[0]]);
    const akhir = sesi.babakBerikut();
    expect(akhir.ok && akhir.juara).toBe(sesi.statePublik().matches.find((m) => m.id === final.id)!.pemenang);
    expect(ids.length).toBe(4);
  });
  it("pertandingan seri bisa ditambah game", () => {
    const { sesi, clock } = bikinSesi({ bestOf: 1, batasWaktuDetik: 30 });
    const [a, b] = ["Ayu", "Beni"].map((n) => masuk(sesi, n));
    const mid = (sesi.buatMatch([a, b]) as { matchId: string }).matchId;
    mulaiMatch(sesi, clock, mid);
    clock.advance(31_000); // tak ada yang selesai
    const m = sesi.statePublik().matches[0];
    expect(m).toMatchObject({ status: "selesai", seri: true, pemenang: null });
    expect(sesi.gameTambahan(mid).ok).toBe(true);
    for (const p of [a, b]) sesi.siap(p, mid);
    expect(sesi.mulai(mid).ok).toBe(true);
    clock.advance(3000);
    mainSampaiSelesai(sesi, clock, mid, [b, a]);
    expect(sesi.statePublik().matches[0]).toMatchObject({ status: "selesai", pemenang: b });
  });
});

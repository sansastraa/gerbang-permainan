// Inti server Logic Rush: satu Sesi = satu kelas. Pertandingan 2–3 pemain, papan dasar sama, best-of-N.
// SERVER ADALAH WASIT: papan lengkap (dengan solusi) hanya hidup di sini; klien hanya menerima publicBoard().
// Seluruh waktu memakai Clock yang disuntik, sehingga tes bisa mengendalikan jam.
import * as E from "@logic-rush/shared";
import {
  CONFIG,
  POIN_MASSAL,
  UKURAN_MASSAL_MAKS,
  batasWaktuGameMs,
  buatKelompok,
  peringkatGame,
  pemajuBabak,
  skorPemain,
  spectate as SP,
  stagesForGame,
  statusPertandingan,
} from "@logic-rush/shared";
import type {
  Board,
  BoardKirim,
  Cell,
  FinishResult,
  GameLive,
  HostExtra,
  KameraStatus,
  MatchPublik,
  PemainPublik,
  PeringkatGame,
  RingkasanLogicRush,
  RingkasanSiswa,
  RingkasGame,
  RosterItem,
  SesiSettings,
  SkorPublik,
  StatePublik,
  Statistik,
  StatusMatch,
  TahapPublik,
} from "@logic-rush/shared";
import { EventLog, randomToken, sha256 } from "./util";
import type { Bank, Clock } from "./util";

export type Target = { k: "sesi" } | { k: "host" } | { k: "pemain"; pid: string } | { k: "watch"; pid: string };
export type Emit = (t: Target, ev: string, payload: unknown) => void;
export type Hasil<T = object> = ({ ok: true } & T) | { ok: false; alasan: string };

const KATA_KASAR = [
  "anjing",
  "babi",
  "bangsat",
  "bajingan",
  "kontol",
  "memek",
  "ngentot",
  "tolol",
  "goblok",
  "bego",
  "jancok",
  "asu",
];
const ATURAN_DASAR = ["row", "col", "zone"];

interface Pemain {
  id: string;
  nama: string;
  absen: number | null;
  siswaId: string | number | null;
  tokenHash: string;
  deviceId: string | null;
  terhubung: boolean;
  kamera: KameraStatus;
  mikrofon: boolean;
  fokusHilang: number;
  dikeluarkan: boolean;
  /** statistik sesi (untuk ringkasan) */
  bantuan: number;
}
interface Run {
  pid: string;
  board: Board; // lengkap, termasuk solusi — TIDAK PERNAH dikirim
  view: SP.SpectateView;
  lastS: number;
  hintsUsed: number;
  penaltyMs: number;
  locked: Cell[];
  finishMs: number | null;
  badFinish: number;
  moves: E.Move[];
  baseId: string;
  /** urutan papan milik pemain ini dalam game; selesai satu papan → langsung lanjut ke berikutnya */
  boards: Board[];
  seq: number;
  done: number;
  /** waktu efektif kumulatif (ms) saat tiap papan tuntas */
  boardMs: number[];
  hintsTotal: number;
}
interface ValidasiRow {
  matchId: string;
  gameNo: number;
  boardNo: number;
  pid: string;
  ok: boolean;
}
interface BantuanRow {
  matchId: string;
  gameNo: number;
  boardNo: number;
  pid: string;
}
interface GameInt {
  no: number;
  stage: TahapPublik & { level: E.Level };
  stages: (TahapPublik & { level: E.Level })[];
  aturanBaruBoard: string[][];
  papanIds: string[][];
  base: Board;
  runs: Map<string, Run>;
  hitungSampaiTs: number | null;
  mulaiTs: number | null;
  deadlineTs: number | null;
  graceDipasang: boolean;
  aturanBaru: string[];
  timer: unknown;
  pauseAt: number | null;
  /** format massal: pemain yang sedang disorot (hanya langkahnya yang direlay ke penonton) */
  sorotPid: string | null;
  sorotSampaiTs: number | null;
  sorotTimer: unknown;
  sorotIdx: number;
}
interface GameSelesaiInt extends RingkasGame {
  stage: TahapPublik;
  stages: TahapPublik[];
  /** id papan dasar per papan ke-j (beberapa id bila format massal) */
  papanIds: string[][];
  boardMs: Record<string, number[]>;
}
interface MatchInt {
  id: string;
  babak: number;
  nomor: number;
  pemain: string[];
  status: StatusMatch;
  siap: Record<string, boolean>;
  games: GameSelesaiInt[];
  game: GameInt | null;
  pemenang: string | null;
  seri: boolean;
  jeda: boolean;
  gameTambahan: number;
  rehatTimer: unknown;
  rehatSisaMs: number | null;
  rehatMulai: number | null;
}

export interface SesiOpsi {
  id: string;
  pin: string;
  settings: SesiSettings;
  clock: Clock;
  emit: Emit;
  bank: Bank;
  seed?: string;
  obsKey?: string;
  logFile?: string;
}

const dedup = <T>(a: T[]): T[] => [...new Set(a)];

export class Sesi {
  readonly id: string;
  readonly pin: string;
  readonly obsKey: string;
  settings: SesiSettings;
  status: "lobi" | "berjalan" | "selesai" = "lobi";
  readonly dibuat: number;
  readonly log: EventLog;
  babak = 0;
  private pemain = new Map<string, Pemain>();
  private matches: MatchInt[] = [];
  private roster: RosterItem[] = [];
  private dipakaiBoard = new Set<string>();
  private flags: HostExtra["flags"] = [];
  private kameraMinta = new Set<string>();
  private videoViewers = new Map<string, Set<string>>();
  private dirtyTimer: unknown = null;
  private validasiLog: ValidasiRow[] = [];
  private bantuanLog: BantuanRow[] = [];
  private seqPemain = 0;
  private seqMatch = 0;
  private readonly seed: string;
  private readonly clock: Clock;
  private readonly emit: Emit;
  private readonly bank: Bank;

  constructor(o: SesiOpsi) {
    this.id = o.id;
    this.pin = o.pin;
    this.settings = o.settings;
    this.clock = o.clock;
    this.emit = o.emit;
    this.bank = o.bank;
    this.seed = o.seed ?? o.id;
    this.obsKey = o.obsKey ?? randomToken().slice(0, 12);
    this.dibuat = o.clock.now();
    this.log = new EventLog(o.clock, o.logFile);
    this.log.add("lr.sesi_dibuat", "host", {
      id: o.id,
      bestOf: o.settings.bestOf,
      ukuran: o.settings.ukuranPertandingan,
    });
  }

  // ------------------------------------------------------------ pemain
  setRoster(items: RosterItem[]): void {
    this.roster = items.slice(0, CONFIG.pemain.maks);
    this.dirty();
  }
  private bersihkanNama(nama: string): string {
    return nama.replace(/\s+/g, " ").trim().slice(0, CONFIG.pin.nama_maks_karakter);
  }
  join(i: {
    nama?: string;
    siswaId?: string | number;
    token?: string;
    deviceId?: string;
  }): Hasil<{ pemain: PemainPublik; token: string; pid: string }> {
    // masuk ulang dengan token
    if (i.token) {
      const h = sha256(i.token);
      const p = [...this.pemain.values()].find((x) => x.tokenHash === h);
      if (p && !p.dikeluarkan) {
        p.terhubung = true;
        if (i.deviceId) p.deviceId = i.deviceId;
        this.log.add("lr.join_ulang", p.id, { deviceId: p.deviceId });
        this.dirty();
        return { ok: true, pemain: this.pub(p), token: i.token, pid: p.id };
      }
      if (p?.dikeluarkan) return { ok: false, alasan: "Kamu dikeluarkan dari sesi ini." };
    }
    const aktif = [...this.pemain.values()].filter((p) => !p.dikeluarkan);
    if (aktif.length >= CONFIG.pemain.maks) return { ok: false, alasan: "Sesi penuh." };
    let nama = this.bersihkanNama(i.nama ?? "");
    let absen: number | null = null;
    let siswaId: string | number | null = null;
    if (this.roster.length) {
      // daftar hadir: wajib memilih nama dari daftar
      const r = this.roster.find((x) => String(x.siswaId) === String(i.siswaId));
      if (!r) return { ok: false, alasan: "Pilih namamu dari daftar." };
      if (aktif.some((p) => String(p.siswaId) === String(r.siswaId)))
        return { ok: false, alasan: "Nama ini sudah dipakai di perangkat lain." };
      nama = this.bersihkanNama(r.nama);
      absen = r.absen ?? null;
      siswaId = r.siswaId;
    }
    if (!nama) return { ok: false, alasan: "Isi namamu dulu." };
    const lower = nama.toLowerCase();
    if (KATA_KASAR.some((k) => lower.includes(k))) return { ok: false, alasan: "Pakai nama yang sopan, ya." };
    const base = nama;
    let n = 2;
    while (aktif.some((p) => p.nama.toLowerCase() === nama.toLowerCase()))
      nama = `${base} ${n++}`.slice(0, CONFIG.pin.nama_maks_karakter + 2);
    const token = randomToken();
    const p: Pemain = {
      id: "p" + ++this.seqPemain,
      nama,
      absen,
      siswaId,
      tokenHash: sha256(token),
      deviceId: i.deviceId ?? null,
      terhubung: true,
      kamera: "mati",
      mikrofon: false,
      fokusHilang: 0,
      dikeluarkan: false,
      bantuan: 0,
    };
    this.pemain.set(p.id, p);
    this.log.add("lr.join", p.id, { nama, siswaId });
    this.dirty();
    return { ok: true, pemain: this.pub(p), token, pid: p.id };
  }
  setTerhubung(pid: string, on: boolean): void {
    const p = this.pemain.get(pid);
    if (!p || p.terhubung === on) return;
    p.terhubung = on;
    if (!on && p.kamera === "menyala") p.kamera = "diizinkan";
    this.dirty();
  }
  kick(pid: string): Hasil {
    const p = this.pemain.get(pid);
    if (!p) return { ok: false, alasan: "Pemain tidak ditemukan." };
    const m = this.matchAktif();
    if (m && m.pemain.includes(pid) && ["hitung", "main"].includes(m.status))
      return { ok: false, alasan: "Pemain sedang bertanding. Akhiri game dulu." };
    p.dikeluarkan = true;
    p.terhubung = false;
    p.kamera = "mati";
    this.kameraMinta.delete(pid);
    this.log.add("lr.kick", "host", { pid });
    this.emit({ k: "pemain", pid }, "lr:dikeluarkan", {});
    this.dirty();
    return { ok: true };
  }
  private pub(p: Pemain): PemainPublik {
    return { id: p.id, nama: p.nama, absen: p.absen, terhubung: p.terhubung, kamera: p.kamera, mikrofon: p.mikrofon };
  }
  getPemain(pid: string): Pemain | undefined {
    return this.pemain.get(pid);
  }
  pemainAktif(): Pemain[] {
    return [...this.pemain.values()].filter((p) => !p.dikeluarkan);
  }

  // ------------------------------------------------------------ pertandingan
  private matchAktif(): MatchInt | undefined {
    return this.matches.find((m) => ["siap", "hitung", "main", "rehat"].includes(m.status));
  }
  private sedangDalamMatch(pid: string): boolean {
    return this.matches.some((m) => m.pemain.includes(pid) && !["selesai", "batal"].includes(m.status));
  }
  private matchById(id: string): MatchInt | undefined {
    return this.matches.find((m) => m.id === id);
  }
  buatMatch(pids: string[], babak = this.babak || 1): Hasil<{ matchId: string }> {
    const ids = dedup(pids);
    if (this.massal) {
      if (ids.length < 4 || ids.length > UKURAN_MASSAL_MAKS)
        return { ok: false, alasan: `Format massal butuh 4 sampai ${UKURAN_MASSAL_MAKS} pemain.` };
    } else if (ids.length < 2 || ids.length > 3)
      return { ok: false, alasan: "Satu pertandingan butuh 2 atau 3 pemain." };
    for (const id of ids) {
      const p = this.pemain.get(id);
      if (!p || p.dikeluarkan) return { ok: false, alasan: "Ada pemain yang tidak ditemukan." };
      if (this.sedangDalamMatch(id))
        return { ok: false, alasan: `${p.nama} sudah ada di pertandingan lain yang belum selesai.` };
    }
    if (this.babak === 0) this.babak = 1;
    const m: MatchInt = {
      id: "m" + ++this.seqMatch,
      babak,
      nomor: this.matches.filter((x) => x.babak === babak).length + 1,
      pemain: ids,
      status: "antre",
      siap: Object.fromEntries(ids.map((i) => [i, false])),
      games: [],
      game: null,
      pemenang: null,
      seri: false,
      jeda: false,
      gameTambahan: 0,
      rehatTimer: null,
      rehatSisaMs: null,
      rehatMulai: null,
    };
    this.matches.push(m);
    this.log.add("lr.match_dibuat", "host", { id: m.id, pemain: ids, babak });
    this.dirty();
    return { ok: true, matchId: m.id };
  }
  /** Antrean otomatis untuk babak berjalan: semua pemain yang belum punya pertandingan belum selesai. */
  buatAntrean(ukuran = this.settings.ukuranPertandingan): Hasil<{ jumlah: number }> {
    const bebas = this.pemainAktif()
      .filter((p) => !this.sedangDalamMatch(p.id))
      .map((p) => p.id);
    if (this.babak > 0 && this.matches.some((m) => m.babak === this.babak))
      return {
        ok: false,
        alasan: "Babak ini sudah punya pertandingan. Pakai “Babak berikutnya” setelah semuanya selesai.",
      };
    if (this.massal) {
      if (bebas.length < 4) return { ok: false, alasan: "Format massal butuh minimal 4 pemain." };
      this.babak = 1;
      this.buatMatch(bebas.slice(0, UKURAN_MASSAL_MAKS), 1);
      return { ok: true, jumlah: 1 };
    }
    if (bebas.length < 2) return { ok: false, alasan: "Butuh minimal 2 pemain untuk membuat pertandingan." };
    this.babak = 1;
    const gs = buatKelompok(bebas, ukuran, `${this.seed}|b1`);
    gs.forEach((g) => this.buatMatch(g, 1));
    return { ok: true, jumlah: gs.length };
  }
  /** Format massal: semua pemain bermain bersama dalam satu arena. */
  get massal(): boolean {
    return this.settings.format === "massal";
  }
  babakBerikut(): Hasil<{ jumlah: number; juara?: string | null }> {
    if (this.massal) {
      const m = this.matches.at(-1);
      if (m?.status === "selesai") return { ok: true, jumlah: 0, juara: m.pemenang };
      return { ok: false, alasan: "Format massal tidak punya babak. Selesaikan arena dulu." };
    }
    const cur = this.matches.filter((m) => m.babak === this.babak);
    if (!cur.length) return { ok: false, alasan: "Belum ada babak. Buat antrean dulu." };
    if (cur.some((m) => !["selesai", "batal"].includes(m.status)))
      return { ok: false, alasan: "Masih ada pertandingan yang belum selesai." };
    const maju = pemajuBabak(
      cur.filter((m) => m.status === "selesai").map((m) => ({ pemain: m.pemain, pemenang: m.pemenang, seri: m.seri })),
    );
    if (maju.length === 1) {
      this.log.add("lr.juara", "host", { pid: maju[0] });
      return { ok: true, jumlah: 0, juara: maju[0] };
    }
    if (cur.length === 1 && cur[0].pemenang) return { ok: true, jumlah: 0, juara: cur[0].pemenang };
    if (maju.length < 2) return { ok: false, alasan: "Tidak ada pemain yang bisa maju." };
    this.babak += 1;
    const gs = buatKelompok(maju, this.settings.ukuranPertandingan, `${this.seed}|b${this.babak}`);
    gs.forEach((g) => this.buatMatch(g, this.babak));
    return { ok: true, jumlah: gs.length };
  }
  batalMatch(mid: string): Hasil {
    const m = this.matchById(mid);
    if (!m) return { ok: false, alasan: "Pertandingan tidak ditemukan." };
    if (m.status === "selesai") return { ok: false, alasan: "Pertandingan sudah selesai." };
    this.hentikanTimer(m);
    m.status = "batal";
    m.game = null;
    this.log.add("lr.match_batal", "host", { id: mid });
    this.emit({ k: "sesi" }, "lr:match-batal", { matchId: mid });
    this.dirty();
    return { ok: true };
  }
  panggil(mid: string): Hasil {
    const m = this.matchById(mid);
    if (!m) return { ok: false, alasan: "Pertandingan tidak ditemukan." };
    if (m.status !== "antre") return { ok: false, alasan: "Pertandingan ini tidak dalam antrean." };
    if (this.matchAktif()) return { ok: false, alasan: "Masih ada pertandingan yang berjalan." };
    m.status = "siap";
    m.siap = Object.fromEntries(m.pemain.map((i) => [i, false]));
    this.status = "berjalan";
    for (const pid of m.pemain) this.emit({ k: "pemain", pid }, "lr:panggil", { matchId: m.id, pemain: m.pemain });
    this.log.add("lr.panggil", "host", { id: mid });
    this.dirty();
    return { ok: true };
  }
  siap(pid: string, mid: string, siap = true): Hasil {
    const m = this.matchById(mid);
    if (!m || m.status !== "siap" || !m.pemain.includes(pid)) return { ok: false, alasan: "Belum waktunya." };
    m.siap[pid] = siap;
    this.dirty();
    return { ok: true };
  }
  mulai(mid: string, paksa = false): Hasil {
    const m = this.matchById(mid);
    if (!m) return { ok: false, alasan: "Pertandingan tidak ditemukan." };
    if (m.status !== "siap") return { ok: false, alasan: "Panggil pemain dulu." };
    if (!paksa && !m.pemain.every((p) => m.siap[p])) return { ok: false, alasan: "Belum semua pemain siap." };
    if (m.pemain.some((p) => !this.pemain.get(p)?.terhubung) && !paksa)
      return { ok: false, alasan: "Ada pemain yang terputus." };
    return this.mulaiHitung(m);
  }
  /** Lanjut ke game berikutnya segera (melewati rehat). */
  lanjut(mid: string): Hasil {
    const m = this.matchById(mid);
    if (!m || m.status !== "rehat") return { ok: false, alasan: "Tidak sedang rehat." };
    this.clock.clearTimeout(m.rehatTimer);
    m.rehatTimer = null;
    return this.mulaiHitung(m);
  }
  gameTambahan(mid: string): Hasil {
    const m = this.matchById(mid);
    if (!m || m.status !== "selesai" || !m.seri)
      return { ok: false, alasan: "Hanya pertandingan seri yang bisa menambah game." };
    if (this.matchAktif()) return { ok: false, alasan: "Masih ada pertandingan yang berjalan." };
    m.gameTambahan += 1;
    m.status = "siap";
    m.seri = false;
    m.pemenang = null;
    m.siap = Object.fromEntries(m.pemain.map((i) => [i, false]));
    for (const pid of m.pemain) this.emit({ k: "pemain", pid }, "lr:panggil", { matchId: m.id, pemain: m.pemain });
    this.log.add("lr.game_tambahan", "host", { id: mid });
    this.dirty();
    return { ok: true };
  }
  jeda(on: boolean): Hasil {
    const m = this.matchAktif();
    if (!m) return { ok: false, alasan: "Tidak ada pertandingan berjalan." };
    if (m.jeda === on) return { ok: true };
    const now = this.clock.now();
    if (on) {
      if (m.status === "main" && m.game) {
        this.clock.clearTimeout(m.game.timer);
        this.clock.clearTimeout(m.game.sorotTimer);
        m.game.timer = null;
        m.game.pauseAt = now;
      } else if (m.status === "rehat") {
        this.clock.clearTimeout(m.rehatTimer);
        m.rehatSisaMs = Math.max(0, (m.rehatMulai ?? now) + this.settings.rehatDetik * 1000 - now);
      } else return { ok: false, alasan: "Jeda hanya saat bermain atau rehat." };
      m.jeda = true;
    } else {
      m.jeda = false;
      if (m.status === "main" && m.game && m.game.pauseAt !== null) {
        const d = now - m.game.pauseAt;
        m.game.mulaiTs = (m.game.mulaiTs ?? now) + d;
        m.game.deadlineTs = (m.game.deadlineTs ?? now) + d;
        m.game.pauseAt = null;
        this.pasangDeadline(m);
        this.jadwalSorot(m);
        this.emit({ k: "sesi" }, "lr:waktu", {
          matchId: m.id,
          mulaiTs: m.game.mulaiTs,
          deadlineTs: m.game.deadlineTs,
          serverTs: now,
        });
      } else if (m.status === "rehat") {
        m.rehatMulai = now - (this.settings.rehatDetik * 1000 - (m.rehatSisaMs ?? 0));
        m.rehatTimer = this.clock.setTimeout(() => this.mulaiHitung(m), m.rehatSisaMs ?? 0);
      }
    }
    this.log.add(on ? "lr.jeda" : "lr.lanjutkan", "host", { id: m.id });
    this.dirty();
    return { ok: true };
  }
  akhiriGame(mid: string): Hasil {
    const m = this.matchById(mid);
    if (!m || m.status !== "main") return { ok: false, alasan: "Tidak sedang bermain." };
    this.selesaiGame(m, "operator");
    return { ok: true };
  }

  // ------------------------------------------------------------ alur game
  private pilihBase(stage: TahapPublik & { level: E.Level }, idx: number): Board | null {
    const key = E.poolKey(stage);
    let pool: Board[];
    try {
      pool = this.bank.pool(key);
    } catch {
      return null;
    }
    if (!pool.length) return null;
    const urut = E.pickByLevel(pool as (Board & { id: string; difficulty: number })[], stage.level, pool.length);
    const rng = E.rngFrom(`${this.seed}|base|${this.matches.length}|${idx}`);
    const bebas = urut
      .filter((b) => !this.dipakaiBoard.has(b.id as string))
      .slice(0, Math.max(3, Math.ceil(urut.length / 3)));
    const sumber = bebas.length ? bebas : urut;
    const b = sumber[Math.floor(rng() * sumber.length)];
    this.dipakaiBoard.add(b.id as string);
    return b;
  }
  private mulaiHitung(m: MatchInt): Hasil {
    const idx = m.games.length;
    const k = this.settings.papanPerGame;
    const stages = stagesForGame(this.settings, idx).map((st) => ({
      n: st.n,
      arsir: !!st.arsir,
      diagonal: !!st.diagonal,
      level: st.level,
    }));
    const rng = E.rngFrom(`${this.seed}|tf|${m.id}|${idx}`);
    // tiap pemain mendapat urutan k papan. Laga: papan dasar SAMA untuk semua, transformasi (bukan identitas) dan warna zona
    // berbeda per pemain. Massal: papan dasar BERBEDA per pemain (anti-contek), transformasi dibuat unik.
    const perPemain: Board[][] = m.pemain.map(() => []);
    const papanIds: string[][] = [];
    for (let j = 0; j < k; j++) {
      const stage = stages[j];
      const base = this.pilihBase(stage, idx * k + j);
      if (!base) {
        m.status = "antre";
        return { ok: false, alasan: `Bank papan untuk ${stage.n}×${stage.n} tidak tersedia.` };
      }
      const ks = [1, 2, 3, 4, 5, 6, 7];
      for (let a = ks.length - 1; a > 0; a--) {
        const b = Math.floor(rng() * (a + 1));
        [ks[a], ks[b]] = [ks[b], ks[a]];
      }
      const sumberMassal = this.massal
        ? E.pickByLevel(
            this.bank.pool(E.poolKey(stage)) as (Board & { id: string; difficulty: number })[],
            stage.level,
            Math.max(8, m.pemain.length),
          )
        : [];
      const offsetMassal = Math.floor(rng() * Math.max(1, sumberMassal.length));
      m.pemain.forEach((_pid, i) => {
        const dasar = this.massal ? sumberMassal[(offsetMassal + i) % sumberMassal.length] : base;
        const kk = this.massal ? 1 + ((i + Math.floor(i / sumberMassal.length)) % 7) : ks[i];
        const perm = [...Array(base.n).keys()];
        for (let a = perm.length - 1; a > 0; a--) {
          const b = Math.floor(rng() * (a + 1));
          [perm[a], perm[b]] = [perm[b], perm[a]];
        }
        perPemain[i].push(E.transformBoard(dasar, kk, perm));
      });
      papanIds.push([...new Set(perPemain.map((p) => p[j].id as string))]);
    }
    const runs = new Map<string, Run>();
    m.pemain.forEach((pid, i) => {
      const boards = perPemain[i];
      const board = boards[0];
      const view = SP.applyMsg(SP.initialView(), {
        t: "snap",
        s: 0,
        seq: idx + 1,
        board: E.publicBoard(board),
        gems: [],
        xs: [],
        locked: [],
        hints: 0,
        elapsedMs: 0,
      });
      runs.set(pid, {
        pid,
        board,
        view,
        lastS: 0,
        hintsUsed: 0,
        penaltyMs: 0,
        locked: [],
        finishMs: null,
        badFinish: 0,
        moves: [],
        baseId: board.id as string,
        boards,
        seq: 0,
        done: 0,
        boardMs: [],
        hintsTotal: 0,
      });
    });
    const prevAkhir = idx > 0 ? (m.games[idx - 1].stages.at(-1) ?? null) : null;
    const aturanBaruBoard = stages.map((st, j) => {
      const sebelum = j > 0 ? stages[j - 1] : prevAkhir;
      const rulesPrev = sebelum ? (E.rulesFor(sebelum) as string[]) : ATURAN_DASAR;
      return (E.rulesFor(st) as string[]).filter((r) => !rulesPrev.includes(r));
    });
    const aturanBaru = aturanBaruBoard[0];
    const stage = stages[0];
    const now = this.clock.now();
    const game: GameInt = {
      no: idx + 1,
      stage,
      stages,
      aturanBaruBoard,
      papanIds,
      base: perPemain[0][0],
      runs,
      hitungSampaiTs: now + this.settings.hitungMundurDetik * 1000,
      mulaiTs: null,
      deadlineTs: null,
      graceDipasang: false,
      aturanBaru,
      timer: null,
      pauseAt: null,
      sorotPid: null,
      sorotSampaiTs: null,
      sorotTimer: null,
      sorotIdx: -1,
    };
    m.game = game;
    m.status = "hitung";
    m.rehatTimer = null;
    this.log.add("lr.game_hitung", "server", {
      match: m.id,
      game: game.no,
      papan: papanIds,
      transform: m.pemain.map((p) => [p, runs.get(p)?.boards.map((b) => b.transform)]),
    });
    const info = {
      matchId: m.id,
      gameNo: game.no,
      hitungSampaiTs: game.hitungSampaiTs,
      serverTs: now,
      stage: this.tahapPub(stage),
      stages: stages.map((s) => this.tahapPub(s)),
      aturanBaru,
    };
    for (const pid of m.pemain) this.emit({ k: "pemain", pid }, "lr:hitung", info);
    this.emit({ k: "sesi" }, "lr:hitung", info);
    game.timer = this.clock.setTimeout(() => this.mulaiGame(m), this.settings.hitungMundurDetik * 1000);
    this.dirty();
    return { ok: true };
  }
  private tahapPub(s: TahapPublik): TahapPublik {
    return { n: s.n, arsir: s.arsir, diagonal: s.diagonal };
  }
  private mulaiGame(m: MatchInt): void {
    const g = m.game;
    if (!g || m.status !== "hitung") return;
    const now = this.clock.now();
    g.mulaiTs = now;
    g.deadlineTs = now + batasWaktuGameMs(this.settings, g.no - 1);
    m.status = "main";
    this.status = "berjalan";
    this.pasangDeadline(m);
    this.log.add("lr.game_mulai", "server", { match: m.id, game: g.no, deadline: g.deadlineTs });
    for (const [pid, run] of g.runs) {
      this.emit({ k: "pemain", pid }, "lr:board", this.boardKirim(m, g, run));
      if (!this.massal) this.emit({ k: "watch", pid }, "lr:sp", { pid, msg: this.snapMsg(g, run) });
    }
    if (this.massal) this.pindahSorot(m);
    this.dirty();
  }
  /** Format massal: sorotan bergilir antar pemain yang masih bermain, tiap `sorotDetik` detik. */
  private pindahSorot(m: MatchInt): void {
    const g = m.game;
    if (!g || m.status !== "main" || m.jeda) return;
    const aktif = [...g.runs.values()].filter((r) => r.finishMs === null);
    if (aktif.length === 0) {
      g.sorotPid = null;
      g.sorotSampaiTs = null;
      return;
    }
    g.sorotIdx = (g.sorotIdx + 1) % aktif.length;
    const r = aktif[g.sorotIdx];
    g.sorotPid = r.pid;
    g.sorotSampaiTs = this.clock.now() + this.settings.sorotDetik * 1000;
    this.emit({ k: "watch", pid: r.pid }, "lr:sp", { pid: r.pid, msg: this.snapMsg(g, r) });
    this.log.add("lr.sorot", "server", { match: m.id, game: g.no, pid: r.pid });
    this.jadwalSorot(m);
    this.dirty();
  }
  private jadwalSorot(m: MatchInt): void {
    const g = m.game;
    if (!g || !this.massal || m.status !== "main") return;
    this.clock.clearTimeout(g.sorotTimer);
    g.sorotTimer = this.clock.setTimeout(() => this.pindahSorot(m), this.settings.sorotDetik * 1000);
  }
  private pasangDeadline(m: MatchInt): void {
    const g = m.game;
    if (!g || g.deadlineTs === null) return;
    this.clock.clearTimeout(g.timer);
    g.timer = this.clock.setTimeout(() => this.selesaiGame(m, "waktu"), Math.max(0, g.deadlineTs - this.clock.now()));
  }
  private boardKirim(m: MatchInt, g: GameInt, run: Run): BoardKirim {
    return {
      matchId: m.id,
      gameNo: g.no,
      boardNo: run.seq + 1,
      boardTotal: run.boards.length,
      lastS: run.lastS,
      board: E.publicBoard(run.board),
      serverTs: this.clock.now(),
      hitungSampaiTs: g.hitungSampaiTs,
      mulaiTs: g.mulaiTs,
      deadlineTs: g.deadlineTs,
      aturanBaru: g.aturanBaruBoard[run.seq] ?? [],
      bantuanSisa: this.settings.bantuan.aktif ? Math.max(0, this.settings.bantuan.perPapan - run.hintsUsed) : 0,
      penaltiDetik: this.settings.bantuan.penaltiDetik,
      gems: run.view.gems,
      xs: run.view.xs,
      locked: run.view.locked,
      hintsPakai: run.hintsTotal,
    };
  }
  private snapMsg(g: GameInt, run: Run): SP.SpectateMsg {
    const v = run.view;
    return {
      t: "snap",
      s: run.lastS,
      seq: g.no,
      board: E.publicBoard(run.board),
      gems: v.gems,
      xs: v.xs,
      locked: v.locked,
      hints: run.hintsUsed,
      elapsedMs: g.mulaiTs ? this.clock.now() - g.mulaiTs : 0,
    };
  }
  /** Papan untuk pemain yang masuk ulang di tengah game (tanpa solusi). */
  boardUntuk(pid: string): BoardKirim | null {
    const m = this.matchAktif();
    if (!m?.game || m.status !== "main") return null;
    const run = m.game.runs.get(pid);
    return run ? this.boardKirim(m, m.game, run) : null;
  }
  /** Snapshot spectate semua pemain pada game berjalan (untuk penonton yang baru masuk). */
  snapsAktif(): { pid: string; msg: SP.SpectateMsg }[] {
    const m = this.matchAktif();
    if (!m?.game || m.status !== "main") return [];
    const g = m.game;
    // massal: penonton hanya mengikuti pemain yang sedang disorot
    return [...g.runs]
      .filter(([pid]) => !this.massal || pid === g.sorotPid)
      .map(([pid, run]) => ({ pid, msg: this.snapMsg(g, run) }));
  }
  pemainMatchAktif(): string[] {
    return this.matchAktif()?.pemain ?? [];
  }

  /** Pesan spectate dari ponsel pemain: divalidasi, diterapkan ke tampilan server, direlay ke penonton. */
  ingestSpectate(pid: string, raw: unknown): void {
    const m = this.matchAktif();
    if (!m?.game || m.status !== "main") return;
    const run = m.game.runs.get(pid);
    if (!run || run.finishMs !== null) return;
    const msg = SP.decode(typeof raw === "string" ? raw : JSON.stringify(raw));
    if (!msg) return;
    if (msg.t === "mv") {
      // socket.io menjaga urutan; nomor yang tidak berurutan (duplikat/lompat) diabaikan, klien menyinkron dari lr:board
      if (msg.r >= run.board.n || msg.c >= run.board.n || msg.s !== run.lastS + 1) return;
      if (run.moves.length < 5000) run.moves.push({ op: msg.op, r: msg.r, c: msg.c });
    } else if (msg.t !== "snap")
      return; // klien hanya boleh mengirim snap/mv
    else if (msg.board.n !== run.board.n || msg.board.zones.join() !== run.board.zones.join()) return; // snap harus papan miliknya
    run.view = SP.applyMsg(run.view, msg);
    run.lastS = msg.s;
    if (!this.massal || m.game.sorotPid === pid) this.emit({ k: "watch", pid }, "lr:sp", { pid, msg });
    this.dirty();
  }

  private pelanggaranDari(run: Run): number {
    const c = E.check(run.board, run.view.gems);
    return c.conflicts.length + c.cellErrors.length + (c.duplicate ? 1 : 0);
  }

  hint(
    pid: string,
    i: { matchId: string; gameNo: number; gems: Cell[] },
  ): Hasil<{ cell: Cell; penaltiMs: number; sisa: number }> {
    const m = this.matchById(i.matchId);
    if (!m?.game || m.status !== "main" || m.game.no !== i.gameNo)
      return { ok: false, alasan: "Bukan game yang sedang berjalan." };
    const run = m.game.runs.get(pid);
    if (!run) return { ok: false, alasan: "Kamu bukan peserta pertandingan ini." };
    if (run.finishMs !== null) return { ok: false, alasan: "Kamu sudah selesai." };
    const b = this.settings.bantuan;
    if (!b.aktif) return { ok: false, alasan: "Bantuan dimatikan guru." };
    if (run.hintsUsed >= b.perPapan) return { ok: false, alasan: "Bantuan di papan ini sudah habis." };
    const cell = E.hintCell(
      run.board,
      i.gems.filter((c) => c.r < run.board.n && c.c < run.board.n),
      run.locked,
    );
    if (!cell) return { ok: false, alasan: "Tidak ada bantuan yang tersisa." };
    run.hintsUsed++;
    run.hintsTotal++;
    this.bantuanLog.push({ matchId: m.id, gameNo: m.game.no, boardNo: run.seq + 1, pid });
    run.penaltyMs += b.penaltiDetik * 1000;
    run.locked.push(cell);
    const p = this.pemain.get(pid);
    if (p) p.bantuan++;
    this.log.add("lr.hint", pid, { match: m.id, game: m.game.no, cell });
    this.dirty();
    return { ok: true, cell, penaltiMs: run.penaltyMs, sisa: b.perPapan - run.hintsUsed };
  }

  /** Finish: idempoten per (match, game); diproses sinkron sehingga urutan kedatangan = urutan pemeriksaan. */
  finish(pid: string, i: { matchId: string; gameNo: number; boardNo?: number; gems: Cell[] }): FinishResult {
    const m = this.matchById(i.matchId);
    const g = m?.game;
    if (!m || !g || g.no !== i.gameNo) {
      const done = m?.games.find((x) => x.no === i.gameNo)?.hasil.find((h) => h.pid === pid);
      if (done && done.ms !== null) return { ok: true, ms: done.ms, rank: done.rank };
      return { ok: false, alasan: "bukan-game-aktif" };
    }
    const run = g.runs.get(pid);
    if (!run) return { ok: false, alasan: "bukan-peserta" };
    if (run.finishMs !== null)
      return {
        ok: true,
        ms: run.finishMs,
        rank: this.rankSekarang(g, pid),
        boardNo: run.boards.length,
        boardTotal: run.boards.length,
      };
    // kirim ulang untuk papan yang sudah tuntas (mis. jaringan putus): idempoten, tidak dihitung sebagai validasi baru
    if (i.boardNo !== undefined && i.boardNo <= run.done)
      return {
        ok: true,
        ms: run.boardMs[i.boardNo - 1] as number,
        rank: 0,
        lanjut: true,
        boardNo: run.seq + 1,
        boardTotal: run.boards.length,
      };
    if (m.status !== "main" || g.mulaiTs === null) return { ok: false, alasan: "bukan-game-aktif" };
    const gems = i.gems.filter((c) => c.r < run.board.n && c.c < run.board.n);
    const chk = E.check(run.board, gems);
    this.validasiLog.push({ matchId: m.id, gameNo: g.no, boardNo: run.seq + 1, pid, ok: chk.complete });
    if (!chk.complete) {
      run.badFinish++;
      this.log.add("lr.finish_bad", pid, { match: m.id, game: g.no, ok: chk.ok, n: gems.length });
      if (run.badFinish >= 3) this.flag(pid, "finish-salah-berulang", `${run.badFinish}×`);
      return { ok: false, alasan: "belum-lengkap" };
    }
    if (!E.matchesSolution(run.board, gems))
      this.log.add("lr.board_not_unique", pid, { board: run.board.id, game: g.no });
    const ms = this.clock.now() - g.mulaiTs + run.penaltyMs;
    const batas = CONFIG.anti_curang.finish_terlalu_cepat_ms[String(Math.min(3, g.no))] ?? 5000;
    const durasi = ms - (run.boardMs.at(-1) ?? 0);
    if (durasi < Math.min(batas, 3000) && run.hintsUsed === 0) this.flag(pid, "finish-terlalu-cepat", `${durasi} ms`);
    const boardNo = run.seq + 1;
    run.boardMs.push(ms);
    run.done++;
    this.log.add("lr.finish_ok", pid, { match: m.id, game: g.no, board: boardNo, ms });
    this.emit({ k: "sesi" }, "lr:papan-tuntas", {
      matchId: m.id,
      gameNo: g.no,
      pid,
      boardNo,
      boardTotal: run.boards.length,
      ms,
    });
    if (boardNo < run.boards.length) {
      // papan tuntas dan masih ada papan berikutnya: pemain langsung lanjut tanpa menunggu lawan
      run.seq++;
      run.board = run.boards[run.seq];
      run.hintsUsed = 0;
      run.locked = [];
      run.lastS += 1;
      run.view = SP.applyMsg(SP.initialView(), {
        t: "snap",
        s: run.lastS,
        seq: g.no,
        board: E.publicBoard(run.board),
        gems: [],
        xs: [],
        locked: [],
        hints: run.hintsTotal,
        elapsedMs: ms,
      });
      this.emit({ k: "pemain", pid }, "lr:board", this.boardKirim(m, g, run));
      if (!this.massal || g.sorotPid === pid)
        this.emit({ k: "watch", pid }, "lr:sp", { pid, msg: this.snapMsg(g, run) });
      this.dirty();
      return { ok: true, ms, rank: 0, lanjut: true, boardNo: run.seq + 1, boardTotal: run.boards.length };
    }
    run.finishMs = ms;
    const rank = this.rankSekarang(g, pid);
    this.emit({ k: "sesi" }, "lr:selesai-pemain", { matchId: m.id, gameNo: g.no, pid, ms, rank });
    // pemain pertama selesai → batas waktu sisa diperpendek (masa grasi)
    if (!g.graceDipasang && this.settings.grasiSetelahPemenangDetik > 0) {
      g.graceDipasang = true;
      const batasBaru = this.clock.now() + this.settings.grasiSetelahPemenangDetik * 1000;
      if (g.deadlineTs !== null && batasBaru < g.deadlineTs && !m.jeda) {
        g.deadlineTs = batasBaru;
        this.pasangDeadline(m);
        this.emit({ k: "sesi" }, "lr:waktu", {
          matchId: m.id,
          mulaiTs: g.mulaiTs,
          deadlineTs: g.deadlineTs,
          serverTs: this.clock.now(),
        });
      }
    }
    if ([...g.runs.values()].every((r) => r.finishMs !== null)) this.selesaiGame(m, "semua");
    else this.dirty();
    return { ok: true, ms, rank, boardNo, boardTotal: run.boards.length };
  }
  private rankSekarang(g: GameInt, pid: string): number {
    const sel = [...g.runs.values()]
      .filter((r) => r.finishMs !== null)
      .sort((a, b) => (a.finishMs as number) - (b.finishMs as number) || a.hintsTotal - b.hintsTotal);
    const me = g.runs.get(pid);
    if (!me || me.finishMs === null) return 0;
    return sel.findIndex((r) => r.finishMs === me.finishMs && r.hintsTotal === me.hintsTotal) + 1;
  }
  private hasilGame(g: GameInt): PeringkatGame[] {
    return peringkatGame(
      [...g.runs.values()].map((r) => ({
        pid: r.pid,
        ms: r.finishMs,
        gems: r.view.gems.length,
        hints: r.hintsTotal,
        done: r.done,
      })),
      this.massal ? POIN_MASSAL : undefined,
    );
  }
  private selesaiGame(m: MatchInt, alasan: string): void {
    const g = m.game;
    if (!g || m.status !== "main") return;
    this.clock.clearTimeout(g.timer);
    this.clock.clearTimeout(g.sorotTimer);
    g.timer = null;
    const hasil = this.hasilGame(g);
    const ringkas: GameSelesaiInt = {
      no: g.no,
      hasil,
      tanpaPemenang: !hasil.some((h) => h.menang),
      stage: this.tahapPub(g.stage),
      stages: g.stages.map((s) => this.tahapPub(s)),
      papanIds: g.papanIds,
      boardMs: Object.fromEntries([...g.runs].map(([pid, r]) => [pid, r.boardMs])),
    };
    m.games.push(ringkas);
    const st = statusPertandingan(
      m.pemain,
      m.games,
      this.settings.bestOf,
      g.deadlineTs && g.mulaiTs ? g.deadlineTs - g.mulaiTs : batasWaktuGameMs(this.settings, g.no - 1),
      m.gameTambahan,
      this.massal,
    );
    this.log.add("lr.game_selesai", "server", {
      match: m.id,
      game: g.no,
      alasan,
      hasil: hasil.map((h) => [h.pid, h.rank, h.ms]),
    });
    for (const pid of m.pemain) {
      const run = g.runs.get(pid);
      if (run && run.finishMs === null)
        this.emit({ k: "pemain", pid }, "lr:game-akhir", { matchId: m.id, gameNo: g.no, alasan });
    }
    this.emit({ k: "sesi" }, "lr:game-akhir", {
      matchId: m.id,
      gameNo: g.no,
      alasan,
      hasil,
      tanpaPemenang: ringkas.tanpaPemenang,
      serverTs: this.clock.now(),
    });
    if (st.selesai) {
      m.status = "selesai";
      m.pemenang = st.pemenang;
      m.seri = st.seri;
      m.game = null;
      this.log.add("lr.match_selesai", "server", {
        match: m.id,
        pemenang: st.pemenang,
        seri: st.seri,
        menang: st.menang,
      });
      this.emit({ k: "sesi" }, "lr:match-selesai", {
        matchId: m.id,
        pemenang: st.pemenang,
        seri: st.seri,
        menang: st.menang,
      });
      if (!this.matches.some((x) => !["selesai", "batal"].includes(x.status))) this.status = "lobi";
    } else {
      m.status = "rehat";
      m.game = null;
      m.rehatMulai = this.clock.now();
      m.rehatTimer = this.clock.setTimeout(() => this.mulaiHitung(m), this.settings.rehatDetik * 1000);
    }
    this.dirty();
  }
  selesaikanSesi(): void {
    for (const m of this.matches) if (["siap", "hitung", "main", "rehat"].includes(m.status)) this.batalMatch(m.id);
    this.status = "selesai";
    this.log.add("lr.sesi_selesai", "host", {});
    this.emit({ k: "sesi" }, "lr:sesi-selesai", {});
    this.dirty();
  }
  private hentikanTimer(m: MatchInt): void {
    this.clock.clearTimeout(m.rehatTimer);
    if (m.game) {
      this.clock.clearTimeout(m.game.timer);
      this.clock.clearTimeout(m.game.sorotTimer);
    }
  }

  // ------------------------------------------------------------ anti-curang & bendera
  flag(pid: string, tipe: string, detail?: string): void {
    this.flags.push({ pid, tipe, ts: this.clock.now(), ...(detail ? { detail } : {}) });
    this.log.add("lr.flag", pid, { tipe, detail });
    this.dirty();
  }
  fokusHilang(pid: string, ms: number): void {
    const p = this.pemain.get(pid);
    const m = this.matchAktif();
    if (!p || !m || m.status !== "main" || ms < CONFIG.anti_curang.fokus_hilang_toleransi_ms) return;
    p.fokusHilang++;
    if (p.fokusHilang === CONFIG.anti_curang.fokus_hilang_bendera) this.flag(pid, "fokus-hilang", `${p.fokusHilang}×`);
  }

  // ------------------------------------------------------------ kamera (persetujuan & status; server tak pernah memegang media)
  mintaKamera(pid: string): Hasil<{ status: KameraStatus }> {
    const p = this.pemain.get(pid);
    const k = this.settings.kamera;
    if (!p || p.dikeluarkan) return { ok: false, alasan: "Pemain tidak ditemukan." };
    if (this.massal || k.mode === "mati" || !k.izinOrtuDikonfirmasi)
      return { ok: false, alasan: "Kamera tidak diaktifkan oleh guru." };
    if (p.kamera === "diizinkan" || p.kamera === "menyala") return { ok: true, status: p.kamera };
    if (k.persetujuanGuru) {
      p.kamera = "meminta";
      this.kameraMinta.add(pid);
    } else p.kamera = "diizinkan";
    this.log.add("lr.kamera_minta", pid, { status: p.kamera });
    this.dirty();
    return { ok: true, status: p.kamera };
  }
  izinKamera(pid: string, izin: boolean): Hasil {
    const p = this.pemain.get(pid);
    if (!p) return { ok: false, alasan: "Pemain tidak ditemukan." };
    this.kameraMinta.delete(pid);
    p.kamera = izin ? "diizinkan" : "mati";
    if (!izin) p.mikrofon = false;
    this.log.add("lr.kamera_izin", "host", { pid, izin });
    this.emit({ k: "pemain", pid }, "lr:kamera-izin", { izin });
    this.dirty();
    return { ok: true };
  }
  /** Pemain melaporkan kamera sudah menyala/mati (setelah ia menekan tombolnya sendiri). */
  kameraMenyala(pid: string, on: boolean, mikrofon = false): Hasil {
    const p = this.pemain.get(pid);
    if (!p) return { ok: false, alasan: "Pemain tidak ditemukan." };
    if (on && p.kamera !== "diizinkan" && p.kamera !== "menyala")
      return { ok: false, alasan: "Kamera belum diizinkan guru." };
    p.kamera = on ? "menyala" : p.kamera === "menyala" ? "diizinkan" : p.kamera;
    p.mikrofon = on && mikrofon && this.settings.kamera.mikrofon;
    this.log.add("lr.kamera_status", pid, { on, mik: p.mikrofon });
    this.emit({ k: "watch", pid }, "rtc:kamera", { pid, on, mikrofon: p.mikrofon });
    this.dirty();
    return { ok: true };
  }
  /** Siapa yang boleh menonton VIDEO pemain. host selalu; obs hanya dengan kunci; penonton biasa hanya bila diizinkan guru. */
  boleLihatVideo(peran: "host" | "obs" | "penonton", obsBerkunci: boolean): boolean {
    if (this.massal || this.settings.kamera.mode === "mati") return false;
    if (peran === "host") return true;
    if (peran === "obs") return obsBerkunci;
    return this.settings.kamera.siapaBolehLihat === "semua";
  }
  tambahPenontonVideo(pid: string, viewerId: string): boolean {
    const set = this.videoViewers.get(pid) ?? new Set<string>();
    if (!set.has(viewerId) && set.size >= CONFIG.webrtc.maks_penonton_p2p_per_pemain) return false;
    set.add(viewerId);
    this.videoViewers.set(pid, set);
    this.log.add("rtc.spectate_start", viewerId, { pid });
    this.dirty();
    return true;
  }
  hapusPenontonVideo(viewerId: string, hanyaPid?: string): void {
    for (const [pid, set] of this.videoViewers)
      if ((hanyaPid === undefined || hanyaPid === pid) && set.delete(viewerId)) {
        this.log.add("rtc.spectate_end", viewerId, { pid });
        this.emit({ k: "pemain", pid }, "rtc:viewer-gone", { viewerId });
      }
    this.dirty();
  }
  jumlahPenontonVideo(pid: string): number {
    return this.videoViewers.get(pid)?.size ?? 0;
  }
  catatFallbackRelay(viewerId: string, pid: string): void {
    this.log.add("rtc.fallback_relay", viewerId, { pid });
  }

  // ------------------------------------------------------------ tampilan
  private dirty(): void {
    if (this.dirtyTimer !== null) return;
    this.dirtyTimer = this.clock.setTimeout(() => {
      this.dirtyTimer = null;
      this.flushState();
    }, 100);
  }
  flushState(): void {
    this.emit({ k: "sesi" }, "lr:state", this.statePublik());
    this.emit({ k: "host" }, "lr:host-extra", this.hostExtra());
  }
  private matchPub(m: MatchInt): MatchPublik {
    const st = statusPertandingan(m.pemain, m.games, this.settings.bestOf, 60_000, m.gameTambahan, this.massal);
    let game: GameLive | null = null;
    const g = m.game;
    if (g) {
      game = {
        no: g.no,
        stage: this.tahapPub(g.stage),
        stages: g.stages.map((s) => this.tahapPub(s)),
        aturanBaru: g.aturanBaru,
        hitungSampaiTs: m.status === "hitung" ? g.hitungSampaiTs : null,
        mulaiTs: g.mulaiTs,
        deadlineTs: g.deadlineTs,
        sorotPid: g.sorotPid,
        sorotSampaiTs: g.sorotSampaiTs,
        pemain: Object.fromEntries(
          [...g.runs].map(([pid, r]) => [
            pid,
            {
              papanSelesai: r.done,
              papanTotal: r.boards.length,
              gems: r.view.gems.length,
              hints: r.hintsTotal,
              selesaiMs: r.finishMs,
              pelanggaran: this.pelanggaranDari(r),
            },
          ]),
        ),
      };
    }
    return {
      id: m.id,
      babak: m.babak,
      nomor: m.nomor,
      pemain: m.pemain,
      bestOf: this.settings.bestOf,
      status: m.status,
      siap: m.siap,
      menang: st.menang,
      perluMenang: st.perluMenang,
      games: m.games.map((x) => ({
        no: x.no,
        stage: x.stage,
        stages: x.stages,
        hasil: x.hasil,
        tanpaPemenang: x.tanpaPemenang,
      })),
      game,
      pemenang: m.pemenang,
      seri: m.seri,
      jeda: m.jeda,
      massal: this.massal,
    };
  }
  private skorSemua(): SkorPublik[] {
    const selesai = this.matches.filter((m) => m.games.length > 0);
    return this.pemainAktif()
      .map((p) => {
        const ikut = selesai.filter((m) => m.pemain.includes(p.id));
        return {
          pid: p.id,
          skor: skorPemain(
            p.id,
            ikut.map((m) => ({ pemain: m.pemain, games: m.games, pemenang: m.pemenang })),
          ),
          pertandinganMenang: ikut.filter((m) => m.pemenang === p.id).length,
          pertandingan: ikut.filter((m) => m.status === "selesai").length,
          gameMenang: ikut.reduce(
            (a, m) => a + m.games.filter((gm) => gm.hasil.some((h) => h.pid === p.id && h.menang)).length,
            0,
          ),
          gameMain: ikut.reduce((a, m) => a + m.games.filter((gm) => gm.hasil.some((h) => h.pid === p.id)).length, 0),
          kalah: ikut.filter((m) => m.status === "selesai" && m.pemenang !== null && m.pemenang !== p.id).length,
        };
      })
      .sort((a, b) => b.skor - a.skor || b.pertandinganMenang - a.pertandinganMenang || b.gameMenang - a.gameMenang);
  }
  statePublik(): StatePublik {
    const { kamera, ...rest } = this.settings;
    return {
      v: 1,
      serverTs: this.clock.now(),
      sesi: {
        id: this.id,
        nama: this.settings.nama,
        status: this.status,
        babak: this.babak,
        adaDaftarHadir: this.roster.length > 0,
      },
      settings: {
        ...rest,
        kamera: { mode: kamera.mode, mikrofon: kamera.mikrofon, siapaBolehLihat: kamera.siapaBolehLihat },
      },
      pemain: this.pemainAktif().map((p) => this.pub(p)),
      matches: this.matches.map((m) => this.matchPub(m)),
      aktif: this.matchAktif()?.id ?? null,
      skor: this.skorSemua(),
    };
  }
  hostExtra(): HostExtra {
    return {
      pin: this.pin,
      obsKey: this.obsKey,
      kameraMinta: [...this.kameraMinta],
      flags: this.flags.slice(-50),
      penontonVideo: Object.fromEntries([...this.videoViewers].map(([k, v]) => [k, v.size])),
    };
  }
  rosterPublik(): { siswaId: string | number; nama: string; absen: number | null; dipakai: boolean }[] {
    const pakai = new Set(this.pemainAktif().map((p) => String(p.siswaId)));
    return this.roster.map((r) => ({
      siswaId: r.siswaId,
      nama: r.nama,
      absen: r.absen ?? null,
      dipakai: pakai.has(String(r.siswaId)),
    }));
  }

  // ------------------------------------------------------------ statistik hasil
  /** Jumlah validasi (percobaan finish) keseluruhan dan per papan, plus waktu menjawab per papan. */
  statistik(): Statistik {
    const median = (a: number[]): number | null => {
      if (!a.length) return null;
      const s = a.slice().sort((x, y) => x - y);
      const h = s.length >> 1;
      return s.length % 2 ? s[h] : Math.round((s[h - 1] + s[h]) / 2);
    };
    const papan: Statistik["papan"] = [];
    for (const m of this.matches)
      for (const gm of m.games)
        gm.stages.forEach((stg, j) => {
          const v = this.validasiLog.filter((x) => x.matchId === m.id && x.gameNo === gm.no && x.boardNo === j + 1);
          // pemain "sampai" di papan ini bila papan sebelumnya tuntas; durasi = selisih waktu kumulatif
          const sampai = gm.hasil.filter((h) => (gm.boardMs[h.pid]?.length ?? 0) >= j);
          const tuntas = gm.hasil.filter((h) => (gm.boardMs[h.pid]?.length ?? 0) > j);
          const durasi = tuntas.map(
            (h) => (gm.boardMs[h.pid][j] as number) - (j > 0 ? (gm.boardMs[h.pid][j - 1] as number) : 0),
          );
          papan.push({
            boardNo: j + 1,
            matchId: m.id,
            babak: m.babak,
            laga: m.nomor,
            gameNo: gm.no,
            papan: gm.papanIds[j] ?? [],
            n: stg.n,
            arsir: stg.arsir,
            diagonal: stg.diagonal,
            pemain: sampai.length,
            selesai: tuntas.length,
            validasi: v.length,
            benar: v.filter((x) => x.ok).length,
            salah: v.filter((x) => !x.ok).length,
            waktuMedianMs: median(durasi),
            waktuTercepatMs: durasi.length ? Math.min(...durasi) : null,
            bantuan: this.bantuanLog.filter((x) => x.matchId === m.id && x.gameNo === gm.no && x.boardNo === j + 1)
              .length,
            tanpaPemenang: gm.tanpaPemenang,
          });
        });
    const pemain: Statistik["pemain"] = this.pemainAktif()
      .map((p) => {
        const v = this.validasiLog.filter((x) => x.pid === p.id);
        const hasil = this.matches.flatMap((m) => m.games.flatMap((gm) => gm.hasil.filter((h) => h.pid === p.id)));
        return {
          pid: p.id,
          nama: p.nama,
          validasi: v.length,
          benar: v.filter((x) => x.ok).length,
          salah: v.filter((x) => !x.ok).length,
          game: hasil.length,
          selesai: hasil.reduce((a, h) => a + (h.done ?? 0), 0),
        };
      })
      .filter((p) => p.game > 0 || p.validasi > 0);
    return {
      validasi: {
        total: this.validasiLog.length,
        benar: this.validasiLog.filter((x) => x.ok).length,
        salah: this.validasiLog.filter((x) => !x.ok).length,
      },
      papan,
      pemain,
    };
  }

  // ------------------------------------------------------------ ringkasan (Hall of Fame SIMPETERI)
  ringkasan(): RingkasanLogicRush {
    const skor = this.skorSemua();
    const siswa: RingkasanSiswa[] = [];
    for (const s of skor) {
      const p = this.pemain.get(s.pid);
      if (!p) continue;
      const ikut = this.matches.filter((m) => m.games.length > 0 && m.pemain.includes(p.id));
      if (!ikut.length) continue;
      let waktu = 0;
      let main = 0;
      for (const m of ikut)
        for (const gm of m.games) {
          const h = gm.hasil.find((x) => x.pid === p.id);
          if (h) {
            main++;
            waktu += h.ms ?? 0;
          }
        }
      siswa.push({
        siswaId: p.siswaId,
        nama: p.nama,
        absen: p.absen,
        skor: s.skor,
        peringkat: 0,
        pertandingan: s.pertandingan,
        pertandinganMenang: s.pertandinganMenang,
        gameMenang: s.gameMenang,
        gameMain: main,
        bantuan: p.bantuan,
        waktuMs: waktu,
      });
    }
    siswa.sort(
      (a, b) =>
        b.skor - a.skor ||
        b.pertandinganMenang - a.pertandinganMenang ||
        b.gameMenang - a.gameMenang ||
        a.waktuMs - b.waktuMs,
    );
    let pos = 0;
    let prev = "";
    siswa.forEach((s, i) => {
      const key = [s.skor, s.pertandinganMenang, s.gameMenang].join("|");
      if (key !== prev) {
        pos = i + 1;
        prev = key;
      }
      s.peringkat = pos;
    });
    return {
      game: "logic-rush",
      versi: 1,
      sesiId: this.id,
      nama: this.settings.nama,
      selesai: this.status === "selesai",
      dibuat: this.dibuat,
      siswa,
    };
  }
  /** Untuk tes dan replay operator: langkah pemain pada game berjalan. */
  langkah(pid: string): E.Move[] {
    return this.matchAktif()?.game?.runs.get(pid)?.moves.slice() ?? [];
  }
  /** Hanya untuk tes: apakah papan lengkap pemain berisi solusi (server). */
  _papanLengkap(pid: string): Board | undefined {
    return this.matchAktif()?.game?.runs.get(pid)?.board;
  }
}

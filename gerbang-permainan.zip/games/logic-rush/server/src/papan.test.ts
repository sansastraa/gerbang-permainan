// Beberapa papan dalam satu game: selesai satu papan, pemain langsung lanjut ke papan berikutnya tanpa menunggu lawan.
import { describe, expect, it } from "vitest";
import { batasWaktuGameMs, defaultSettings, stagesForGame } from "@logic-rush/shared";
import { bikinSesi, jawabanBenar } from "./harness";
import type { Sesi } from "./session";
import type { FakeClock } from "./util";

const siapkan = (k = 2, over = {}) => {
  const h = bikinSesi({ papanPerGame: k, bestOf: 1, batasWaktuDetik: 300, ...over });
  const [a, b] = ["Ayu", "Beni"].map((n) => (h.sesi.join({ nama: n }) as { pid: string }).pid);
  const mid = (h.sesi.buatMatch([a, b]) as { matchId: string }).matchId;
  h.sesi.panggil(mid);
  h.sesi.siap(a, mid);
  h.sesi.siap(b, mid);
  h.sesi.mulai(mid);
  h.clock.advance(3000);
  return { ...h, a, b, mid };
};
const selesaikan = (s: Sesi, _c: FakeClock, pid: string, mid: string, gameNo = 1, boardNo?: number) =>
  s.finish(pid, { matchId: mid, gameNo, ...(boardNo ? { boardNo } : {}), gems: jawabanBenar(s, pid) });

describe("lanjut ke papan berikutnya", () => {
  it("selesai papan 1 → pemain itu langsung dapat papan 2 (tahap berikutnya), lawan tidak terpengaruh", () => {
    const { sesi, clock, rekam, a, b, mid } = siapkan(2);
    clock.advance(4000);
    const r = selesaikan(sesi, clock, a, mid);
    expect(r).toMatchObject({ ok: true, ms: 4000, lanjut: true, boardNo: 2, boardTotal: 2 });
    const kirim = rekam.filter((x) => x.ev === "lr:board" && x.t.k === "pemain" && x.t.pid === a);
    expect(kirim.length).toBe(2);
    const papan2 = kirim[1].payload as {
      boardNo: number;
      boardTotal: number;
      board: { n: number; zones: string[] };
      lastS: number;
    };
    expect(papan2).toMatchObject({ boardNo: 2, boardTotal: 2 });
    expect(papan2.board.n).toBe(5); // tahap ke-2: 5×5 + arsir
    expect(papan2.board.zones.join("")).toContain("#");
    expect(rekam.filter((x) => x.ev === "lr:board" && x.t.k === "pemain" && x.t.pid === b).length).toBe(1);
    expect(sesi._papanLengkap(a)!.n).toBe(5);
    expect(sesi._papanLengkap(b)!.n).toBe(4);
    const live = sesi.statePublik().matches[0].game!.pemain;
    expect(live[a]).toMatchObject({ papanSelesai: 1, papanTotal: 2, gems: 0 });
    expect(live[b]).toMatchObject({ papanSelesai: 0, papanTotal: 2 });
    expect(sesi.statePublik().matches[0].status).toBe("main");
    // peristiwa animasi "papan tuntas" untuk semua layar
    const ev = rekam.find((x) => x.ev === "lr:papan-tuntas")!.payload as { pid: string; boardNo: number };
    expect(ev).toMatchObject({ pid: a, boardNo: 1 });
  });

  it("penonton menerima snapshot papan baru; lompatan nomor urut tetap berurutan", () => {
    const { sesi, clock, rekam, a, mid } = siapkan(2);
    clock.advance(2000);
    selesaikan(sesi, clock, a, mid);
    const sp = rekam
      .filter((x) => x.ev === "lr:sp")
      .map((x) => x.payload as { pid: string; msg: { t: string; s: number; board: { n: number } } });
    const terakhir = sp.at(-1)!;
    expect(terakhir.pid).toBe(a);
    expect(terakhir.msg).toMatchObject({ t: "snap", s: 1 });
    expect(terakhir.msg.board.n).toBe(5);
    // klien melanjutkan dari nomor urut yang diberi server
    sesi.ingestSpectate(a, { t: "mv", s: 2, op: "gem", r: 0, c: 1, at: 0 });
    expect(sesi.statePublik().matches[0].game!.pemain[a].gems).toBe(1);
  });

  it("game selesai hanya setelah semua papan tuntas; peringkat menurut waktu papan terakhir", () => {
    const { sesi, clock, a, b, mid } = siapkan(2);
    clock.advance(3000);
    selesaikan(sesi, clock, a, mid); // a papan 1 @3 dtk
    clock.advance(1000);
    selesaikan(sesi, clock, b, mid); // b papan 1 @4 dtk
    clock.advance(2000);
    expect(selesaikan(sesi, clock, a, mid)).toMatchObject({ ok: true, ms: 6000, rank: 1, boardNo: 2 }); // a selesai semua @6
    expect(sesi.statePublik().matches[0].status).toBe("main");
    clock.advance(1000);
    expect(selesaikan(sesi, clock, b, mid)).toMatchObject({ ok: true, ms: 7000, rank: 2 });
    const m = sesi.statePublik().matches[0];
    expect(m.status).toBe("selesai");
    expect(m.pemenang).toBe(a);
    expect(m.games[0].stages.length).toBe(2);
    expect(m.games[0].hasil.map((h) => [h.pid, h.ms])).toEqual([
      [a, 6000],
      [b, 7000],
    ]);
  });

  it("kirim ulang papan yang sudah tuntas (boardNo) idempoten dan tidak menambah validasi", () => {
    const { sesi, clock, a, mid } = siapkan(2);
    clock.advance(2000);
    const gems1 = jawabanBenar(sesi, a);
    expect(sesi.finish(a, { matchId: mid, gameNo: 1, boardNo: 1, gems: gems1 }).ok).toBe(true);
    const n = sesi.statistik().validasi.total;
    const ulang = sesi.finish(a, { matchId: mid, gameNo: 1, boardNo: 1, gems: gems1 });
    expect(ulang).toMatchObject({ ok: true, lanjut: true, boardNo: 2, ms: 2000 });
    expect(sesi.statistik().validasi.total).toBe(n);
    // tanpa boardNo, solusi papan 1 untuk papan 2 ditolak dan dicatat sebagai validasi salah pada papan 2
    expect(sesi.finish(a, { matchId: mid, gameNo: 1, gems: gems1 }).ok).toBe(false);
    expect(sesi.statistik().validasi).toMatchObject({ total: n + 1, salah: 1 });
  });

  it("bantuan per papan: jatah baru di papan berikutnya, penalti terus terhitung di waktu efektif", () => {
    const { sesi, clock, a, mid } = siapkan(2);
    clock.advance(1000);
    const h1 = sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] });
    expect(h1.ok).toBe(true);
    expect(sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] }).ok).toBe(false); // jatah papan 1 habis
    clock.advance(1000);
    const r = selesaikan(sesi, clock, a, mid);
    expect(r).toMatchObject({ ok: true, ms: 2000 + 30_000, lanjut: true });
    expect(sesi.hint(a, { matchId: mid, gameNo: 1, gems: [] }).ok).toBe(true); // jatah papan 2
    expect(sesi.statePublik().matches[0].game!.pemain[a].hints).toBe(2);
  });

  it("waktu habis: yang menuntaskan lebih banyak papan peringkatnya lebih tinggi, walau permata papan lain lebih banyak", () => {
    const { sesi, clock, a, b, mid } = siapkan(2, { batasWaktuDetik: 60 });
    clock.advance(5000);
    selesaikan(sesi, clock, a, mid); // a: 1 papan
    sesi.ingestSpectate(b, { t: "mv", s: 1, op: "gem", r: 0, c: 0, at: 0 });
    sesi.ingestSpectate(b, { t: "mv", s: 2, op: "gem", r: 1, c: 2, at: 0 });
    sesi.ingestSpectate(b, { t: "mv", s: 3, op: "gem", r: 2, c: 1, at: 0 });
    clock.advance(70_000);
    const m = sesi.statePublik().matches[0];
    expect(m.status).toBe("selesai");
    const urut = m.games[0].hasil;
    expect(urut[0].pid).toBe(a);
    expect(urut[0]).toMatchObject({ ms: null, rank: 1 });
    expect(urut[0].menang).toBe(false); // belum menuntaskan semua papan = bukan pemenang game
  });

  it("statistik per papan: satu baris tiap papan dalam game, median durasi per papan", () => {
    const { sesi, clock, a, b, mid } = siapkan(2);
    clock.advance(3000);
    selesaikan(sesi, clock, a, mid);
    clock.advance(1000);
    selesaikan(sesi, clock, b, mid);
    clock.advance(4000);
    selesaikan(sesi, clock, a, mid);
    clock.advance(2000);
    selesaikan(sesi, clock, b, mid);
    const st = sesi.statistik();
    expect(st.papan.map((p) => [p.boardNo, p.n, p.pemain, p.selesai, p.validasi])).toEqual([
      [1, 4, 2, 2, 2],
      [2, 5, 2, 2, 2],
    ]);
    expect(st.papan[0].waktuMedianMs).toBe(3500); // 3000 dan 4000
    expect(st.papan[1].waktuTercepatMs).toBe(5000); // a: 8000-3000; b: 10000-4000 = 6000
    expect(st.pemain.find((p) => p.pid === a)).toMatchObject({ validasi: 2, selesai: 2 });
  });

  it("batas waktu otomatis bertambah menurut jumlah papan; tahap berulang menurut urutan", () => {
    const s = defaultSettings();
    expect(s.papanPerGame).toBe(3);
    const satu = batasWaktuGameMs({ ...s, papanPerGame: 1 }, 0);
    const tiga = batasWaktuGameMs({ ...s, papanPerGame: 3 }, 0);
    expect(tiga).toBeGreaterThan(satu * 2);
    expect(stagesForGame({ ...s, papanPerGame: 3 }, 0).map((t) => t.n)).toEqual([4, 5, 6]);
    expect(stagesForGame({ ...s, papanPerGame: 2 }, 1).map((t) => t.n)).toEqual([6, 4]);
  });
});

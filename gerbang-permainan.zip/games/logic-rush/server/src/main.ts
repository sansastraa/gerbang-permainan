// Titik masuk server. Variabel lingkungan:
//   PORT (3090) · HOST (0.0.0.0) · HOST_PIN (PIN guru; bila kosong dibuat acak & disimpan di var/host-token.txt)
//   ALLOWED_ORIGINS (asal SIMPETERI/situs lain, dipisah koma; kosong = semua asal, hanya untuk LAN/pengembangan)
//   STUN_URLS · TURN_URL · TURN_USERNAME · TURN_CREDENTIAL  (ICE untuk WebRTC; kosong = LAN tanpa internet)
//   STATIC_DIR (bawaan ../client/dist) · DATA_DIR (bawaan ./var)
import crypto from "node:crypto";
import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { buatApp, normalisasiBasePath } from "./app";

const here = path.dirname(fileURLToPath(import.meta.url));
const dataDir = process.env.DATA_DIR ?? path.join(here, "..", "var");
fs.mkdirSync(dataDir, { recursive: true });

function hostPin(): string {
  if (process.env.HOST_PIN && process.env.HOST_PIN.length >= 4) return process.env.HOST_PIN;
  const f = path.join(dataDir, "host-token.txt");
  if (fs.existsSync(f)) return fs.readFileSync(f, "utf8").trim();
  const pin = String(crypto.randomInt(100000, 999999));
  fs.writeFileSync(f, pin);
  return pin;
}
function iceServers(): unknown[] {
  const out: unknown[] = [];
  const stun = (process.env.STUN_URLS ?? "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
  if (stun.length) out.push({ urls: stun });
  if (process.env.TURN_URL)
    out.push({
      urls: process.env.TURN_URL,
      username: process.env.TURN_USERNAME ?? "",
      credential: process.env.TURN_CREDENTIAL ?? "",
    });
  return out;
}

const port = Number(process.env.PORT ?? 3090);
const host = process.env.HOST ?? "0.0.0.0";
const pin = hostPin();
const staticDir = process.env.STATIC_DIR ?? path.join(here, "..", "..", "client", "dist");
const origins = (process.env.ALLOWED_ORIGINS ?? "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
// BASE_PATH: awalan jalur di belakang gerbang SIMPETERI, mis. /games/logic-rush (kosong = di akar). TRUST_PROXY=1: percayai X-Forwarded-For.
const basePath = normalisasiBasePath(process.env.BASE_PATH);
const trustProxy = process.env.TRUST_PROXY === "1";
const app = buatApp({
  hostPin: pin,
  allowedOrigins: origins,
  staticDir,
  dataDir,
  iceServers: iceServers(),
  basePath,
  trustProxy,
});

void app.listen(port, host).then(async (p) => {
  const lan = Object.values(os.networkInterfaces())
    .flat()
    .filter((i) => i && i.family === "IPv4" && !i.internal)
    .map((i) => (i as os.NetworkInterfaceInfo).address);
  console.log(`\nLOGIC RUSH berjalan di port ${p}`);
  console.log(`  Guru     : http://localhost:${p}${basePath}/host   (PIN guru: ${pin})`);
  for (const ip of lan) console.log(`  Murid    : http://${ip}:${p}${basePath}/`);
  console.log(`  Penonton : ${basePath}/watch   ·   OBS: ${basePath}/obs?pin=<PIN sesi>&key=<kunci OBS>`);
  if (lan[0]) {
    try {
      const qr = (await import("qrcode-terminal")) as {
        default?: { generate: (t: string, o: { small: boolean }) => void };
      };
      qr.default?.generate(`http://${lan[0]}:${p}${basePath}/`, { small: true });
    } catch {
      /* QR terminal opsional */
    }
  }
});

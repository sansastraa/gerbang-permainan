import type { RingkasanLogicRush } from "@logic-rush/shared";

const sel = (v: unknown): string => {
  const s = v === null || v === undefined ? "" : String(v);
  // cegah injeksi rumus spreadsheet pada nama yang diawali = + - @
  const aman = /^[=+\-@]/.test(s) ? "'" + s : s;
  return /[",\n]/.test(aman) ? `"${aman.replace(/"/g, '""')}"` : aman;
};

export function csvHasil(r: RingkasanLogicRush): string {
  const kepala = [
    "peringkat",
    "absen",
    "nama",
    "siswa_id",
    "skor",
    "pertandingan",
    "pertandingan_menang",
    "game_menang",
    "game_main",
    "bantuan",
    "waktu_detik",
  ];
  const baris = r.siswa.map((s) => [
    s.peringkat,
    s.absen,
    s.nama,
    s.siswaId,
    s.skor,
    s.pertandingan,
    s.pertandinganMenang,
    s.gameMenang,
    s.gameMain,
    s.bantuan,
    Math.round(s.waktuMs / 100) / 10,
  ]);
  return "﻿" + [kepala, ...baris].map((b) => b.map(sel).join(",")).join("\n") + "\n";
}

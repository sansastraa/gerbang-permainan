import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { io as ioc } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { defaultSettings, settingsSchema, spectate as SP } from "@logic-rush/shared";
import { buatApp } from "./app";
import type { App } from "./app";

const HOST_PIN = "guru-rahasia";
let app: App;
let base = "";
const sockets: Socket[] = [];

const kons = (auth: Record<string, unknown>): Promise<Socket> =>
  new Promise((resolve, reject) => {
    const s = ioc(base, { auth, transports: ["websocket"], forceNew: true, reconnection: false });
    sockets.push(s);
    s.on("connect", () => resolve(s));
    s.on("connect_error", (e) => reject(e));
  });
const tanya = <T = Record<string, unknown>>(s: Socket, ev: string, p?: unknown): Promise<T> =>
  new Promise((r) => s.emit(ev, p, (x: T) => r(x)));
const tunggu = <T = unknown>(s: Socket, ev: string, pred: (p: T) => boolean = () => true, ms = 4000): Promise<T> =>
  new Promise((resolve, reject) => {
    const t = setTimeout(() => reject(new Error("timeout menunggu " + ev)), ms);
    const h = (p: T) => {
      if (pred(p)) {
        clearTimeout(t);
        s.off(ev, h);
        resolve(p);
      }
    };
    s.on(ev, h);
  });
const post = (path: string, body: unknown, headers: Record<string, string> = {}) =>
  fetch(base + path, {
    method: "POST",
    headers: { "content-type": "application/json", ...headers },
    body: JSON.stringify(body),
  });

beforeAll(async () => {
  app = buatApp({ hostPin: HOST_PIN, allowedOrigins: ["https://simpeteri.example"] });
  const port = await app.listen(0, "127.0.0.1");
  base = `http://127.0.0.1:${port}`;
});
afterAll(async () => {
  sockets.forEach((s) => s.close());
  await app.tutup();
});

const buatSesi = async (over: Record<string, unknown> = {}) => {
  const settings = settingsSchema.parse({
    ...defaultSettings(),
    tahap: [{ n: 4, arsir: false, diagonal: false, level: "mudah" }],
    bestOf: 1,
    papanPerGame: 1,
    hitungMundurDetik: 0,
    batasWaktuDetik: 120,
    kamera: {
      mode: "opsional",
      persetujuanGuru: false,
      izinOrtuDikonfirmasi: true,
      mikrofon: false,
      siapaBolehLihat: "operator-obs",
    },
    ...over,
  });
  const r = await post("/api/sessions", { settings }, { "x-host-token": HOST_PIN });
  expect(r.status).toBe(201);
  return (await r.json()) as { id: string; pin: string; obsKey: string };
};

describe("HTTP", () => {
  it("membuat sesi butuh PIN guru; pengaturan tak sah ditolak oleh server", async () => {
    expect((await post("/api/sessions", { settings: defaultSettings() })).status).toBe(401);
    const buruk = await post(
      "/api/sessions",
      { settings: { ...defaultSettings(), tahap: [{ n: 12, arsir: false, diagonal: false, level: "sedang" }] } },
      { "x-host-token": HOST_PIN },
    );
    expect(buruk.status).toBe(400);
    const diag3 = await post(
      "/api/sessions",
      { settings: { ...defaultSettings(), tahap: [{ n: 3, arsir: false, diagonal: true, level: "sedang" }] } },
      { "x-host-token": HOST_PIN },
    );
    expect(diag3.status).toBe(400);
    const kam = await post(
      "/api/sessions",
      { settings: { ...defaultSettings(), kamera: { mode: "opsional" } } },
      { "x-host-token": HOST_PIN },
    );
    expect(kam.status).toBe(400);
  });
  it("presets terbuka; lookup PIN; salah 10× dalam semenit → terkunci", async () => {
    const p = (await (await fetch(base + "/api/presets")).json()) as {
      bawaan: string;
      preset: Record<string, unknown>;
    };
    expect(p.bawaan).toBe("SD_STANDAR");
    expect(Object.keys(p.preset).length).toBe(4);
    const { pin } = await buatSesi();
    const ok = await post("/api/lookup", { pin });
    expect(ok.status).toBe(200);
    expect(JSON.stringify(await ok.json())).not.toMatch(/solution|pin/);
    // penjaga PIN dicoba di server terpisah agar IP uji tidak terkunci untuk tes lain
    const lain = buatApp({ hostPin: HOST_PIN });
    const port2 = await lain.listen(0, "127.0.0.1");
    const u = `http://127.0.0.1:${port2}`;
    const sesLain = lain.reg.buat(settingsSchema.parse({ ...defaultSettings() }));
    let status = 0;
    for (let i = 0; i < 11; i++)
      status = (
        await fetch(u + "/api/lookup", {
          method: "POST",
          headers: { "content-type": "application/json" },
          body: JSON.stringify({ pin: "000000" }),
        })
      ).status;
    expect(status).toBe(429);
    const benar = await fetch(u + "/api/lookup", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ pin: sesLain.pin }),
    });
    expect(benar.status).toBe(429); // terkunci juga untuk PIN benar
    await lain.tutup();
  });
  it("CORS hanya untuk asal yang diizinkan", async () => {
    const a = await fetch(base + "/health", { headers: { origin: "https://simpeteri.example" } });
    expect(a.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example");
    const b = await fetch(base + "/health", { headers: { origin: "https://jahat.example" } });
    expect(b.headers.get("access-control-allow-origin")).toBeNull();
  });
});

describe("pertandingan lewat Socket.IO", () => {
  it("alur lengkap: papan tanpa solusi, finish, ringkasan hanya setelah sesi selesai dan dengan token guru", async () => {
    const ses = await buatSesi();
    const host = await kons({ peran: "host", hostToken: HOST_PIN, sesiId: ses.id });
    const a = await kons({ peran: "pemain", pin: ses.pin });
    const b = await kons({ peran: "pemain", pin: ses.pin });
    const penonton = await kons({ peran: "penonton", pin: ses.pin });
    const ja = await tanya<{ ok: boolean; pid: string }>(a, "lr:join", { nama: "Ayu" });
    const jb = await tanya<{ ok: boolean; pid: string }>(b, "lr:join", { nama: "Beni" });
    expect([ja.ok, jb.ok]).toEqual([true, true]);
    await tanya(penonton, "lr:tonton");

    const mm = await tanya<{ ok: boolean; matchId: string }>(host, "host:match-buat", { pids: [ja.pid, jb.pid] });
    expect(mm.ok).toBe(true);
    expect((await tanya<{ ok: boolean }>(host, "host:panggil", { mid: mm.matchId })).ok).toBe(true);
    await tanya(a, "lr:siap", { matchId: mm.matchId });
    await tanya(b, "lr:siap", { matchId: mm.matchId });
    const boardA = tunggu<{ matchId: string; gameNo: number; board: Record<string, unknown> }>(a, "lr:board");
    const boardB = tunggu<{ board: Record<string, unknown> }>(b, "lr:board");
    expect((await tanya<{ ok: boolean }>(host, "host:mulai", { mid: mm.matchId })).ok).toBe(true);
    const [ba, bb] = [await boardA, await boardB];
    expect(Object.keys(ba.board).sort()).toEqual(["id", "n", "rules", "zones"]);
    expect(JSON.stringify([ba, bb])).not.toMatch(/solution/);
    expect((ba.board as { id: string }).id).toBe((bb.board as { id: string }).id); // papan dasar sama

    // langkah Ayu direlay ke penonton
    const sp = tunggu<{ pid: string; msg: { t: string; r: number } }>(penonton, "lr:sp", (p) => p.msg.t === "mv");
    const tx = SP.makeSender();
    tx.next({ t: "ping" });
    a.emit("lr:sp", tx.next({ t: "mv", op: "gem", r: 0, c: 0, at: 1 }));
    expect((await sp).pid).toBe(ja.pid);

    // finish: papan lengkap diambil dari server (hanya tes) — klien sungguhan tak pernah memegangnya
    const sesi = app.reg.get(ses.id)!;
    const sol = (pid: string) => sesi._papanLengkap(pid)!.solution!.map((c, r) => ({ r, c }));
    const buruk = await tanya<{ ok: boolean; alasan: string }>(a, "lr:finish", {
      matchId: mm.matchId,
      gameNo: 1,
      gems: [{ r: 0, c: 0 }],
    });
    expect(buruk).toEqual({ ok: false, alasan: "belum-lengkap" });
    const r1 = await tanya<{ ok: boolean; rank: number }>(a, "lr:finish", {
      matchId: mm.matchId,
      gameNo: 1,
      gems: sol(ja.pid),
    });
    const r1b = await tanya(a, "lr:finish", { matchId: mm.matchId, gameNo: 1, gems: sol(ja.pid) });
    expect(r1.ok).toBe(true);
    expect(r1b).toEqual(r1);
    const selesai = tunggu<{ pemenang: string }>(host, "lr:match-selesai");
    await tanya(b, "lr:finish", { matchId: mm.matchId, gameNo: 1, gems: sol(jb.pid) });
    expect((await selesai).pemenang).toBe(ja.pid);
    // payload tak sah ditolak
    expect((await tanya<{ ok: boolean }>(a, "lr:finish", { matchId: 5, gameNo: "x" })).ok).toBe(false);

    // ringkasan
    const url = `${base}/api/sessions/${ses.id}/summary.json`;
    expect((await fetch(url)).status).toBe(401);
    expect((await fetch(url, { headers: { "x-host-token": HOST_PIN } })).status).toBe(403);
    await tanya(host, "host:selesai-sesi");
    const sum = await fetch(url, { headers: { "x-host-token": HOST_PIN, origin: "https://simpeteri.example" } });
    expect(sum.status).toBe(200);
    expect(sum.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example");
    const j = (await sum.json()) as { game: string; siswa: { nama: string; peringkat: number }[] };
    expect(j.game).toBe("logic-rush");
    expect(j.siswa.find((s) => s.nama === "Ayu")!.peringkat).toBe(1);
    expect(JSON.stringify(j)).not.toMatch(/solution/);
    const csv = await (
      await fetch(`${base}/api/sessions/${ses.id}/results.csv`, { headers: { "x-host-token": HOST_PIN } })
    ).text();
    expect(csv).toContain("Ayu");
  });

  it("pemain tidak bisa memakai aksi guru; penonton tak bisa mengirim langkah", async () => {
    const ses = await buatSesi();
    const a = await kons({ peran: "pemain", pin: ses.pin });
    const w = await kons({ peran: "penonton", pin: ses.pin });
    const ja = await tanya<{ ok: boolean; pid: string }>(a, "lr:join", { nama: "Ayu" });
    expect(await tanya(a, "host:antrean", {})).toEqual({ ok: false, alasan: "Khusus guru." });
    expect(await tanya(w, "lr:finish", { matchId: "m1", gameNo: 1, gems: [] })).toEqual({
      ok: false,
      alasan: "Masuk dulu.",
    });
    expect(ja.ok).toBe(true);
    await expect(kons({ peran: "host", hostToken: "salah", sesiId: ses.id })).rejects.toThrow();
    await expect(kons({ peran: "pemain", pin: "000000" })).rejects.toThrow();
  });

  it("masuk ulang dengan token + id sesi (tanpa PIN) memulihkan papan aktif", async () => {
    const ses = await buatSesi();
    const host = await kons({ peran: "host", hostToken: HOST_PIN, sesiId: ses.id });
    const a = await kons({ peran: "pemain", pin: ses.pin });
    const b = await kons({ peran: "pemain", pin: ses.pin });
    const ja = await tanya<{ pid: string; token: string }>(a, "lr:join", { nama: "Ayu" });
    const jb = await tanya<{ pid: string }>(b, "lr:join", { nama: "Beni" });
    const mm = await tanya<{ matchId: string }>(host, "host:match-buat", { pids: [ja.pid, jb.pid] });
    await tanya(host, "host:panggil", { mid: mm.matchId });
    await tanya(a, "lr:siap", { matchId: mm.matchId });
    await tanya(b, "lr:siap", { matchId: mm.matchId });
    const bd = tunggu(a, "lr:board");
    await tanya(host, "host:mulai", { mid: mm.matchId });
    await bd;
    a.close();
    const a2 = await kons({ peran: "pemain", sesiId: ses.id, token: ja.token });
    const lagi = tunggu<{ gameNo: number; board: unknown }>(a2, "lr:board");
    const j2 = await tanya<{ ok: boolean; pid: string }>(a2, "lr:join", { token: ja.token });
    expect(j2.pid).toBe(ja.pid);
    expect((await lagi).gameNo).toBe(1);
  });
});

describe("WebRTC: hanya sinyal", () => {
  it("kamera diizinkan guru → OBS berkunci & operator boleh video; OBS tanpa kunci dan penonton biasa tidak; kuota 3; SDP/ICE diteruskan", async () => {
    const ses = await buatSesi({
      kamera: {
        mode: "opsional",
        persetujuanGuru: true,
        izinOrtuDikonfirmasi: true,
        mikrofon: false,
        siapaBolehLihat: "operator-obs",
      },
    });
    const host = await kons({ peran: "host", hostToken: HOST_PIN, sesiId: ses.id });
    const a = await kons({ peran: "pemain", pin: ses.pin });
    const ja = await tanya<{ pid: string }>(a, "lr:join", { nama: "Ayu" });
    const obsKunci = await kons({ peran: "obs", pin: ses.pin, obsKey: ses.obsKey });
    const obsTanpa = await kons({ peran: "obs", pin: ses.pin });
    const biasa = await kons({ peran: "penonton", pin: ses.pin });

    // kamera belum menyala → tidak ada video
    expect(await tanya(obsKunci, "rtc:watch", { pid: ja.pid, wantVideo: true })).toMatchObject({
      ok: true,
      video: false,
      alasan: "kamera-mati",
    });
    // alur persetujuan
    expect(await tanya(a, "kamera:minta")).toMatchObject({ ok: true, status: "meminta" });
    expect(await tanya(a, "kamera:status", { on: true })).toMatchObject({ ok: false }); // belum disetujui
    await tanya(host, "host:kamera-izin", { pid: ja.pid, izin: true });
    expect(await tanya(a, "kamera:status", { on: true })).toMatchObject({ ok: true });

    expect(await tanya(obsTanpa, "rtc:watch", { pid: ja.pid, wantVideo: true })).toMatchObject({
      video: false,
      alasan: "tidak-diizinkan",
    });
    expect(await tanya(biasa, "rtc:watch", { pid: ja.pid, wantVideo: true })).toMatchObject({
      video: false,
      alasan: "tidak-diizinkan",
    });

    const req = tunggu<{ viewerId: string; peran: string }>(a, "rtc:viewer-request");
    expect(await tanya(obsKunci, "rtc:watch", { pid: ja.pid, wantVideo: true })).toMatchObject({
      ok: true,
      video: true,
    });
    const { viewerId, peran } = await req;
    expect(peran).toBe("obs");
    const sdp = { type: "offer" as const, sdp: "v=0 contoh" };
    const offer = tunggu<{ pid: string; sdp: typeof sdp }>(obsKunci, "rtc:offer");
    a.emit("rtc:offer", { viewerId, sdp });
    expect((await offer).pid).toBe(ja.pid);
    const answer = tunggu<{ viewerId: string; sdp: { type: string } }>(a, "rtc:answer");
    obsKunci.emit("rtc:answer", { pid: ja.pid, sdp: { type: "answer", sdp: "v=0 jawab" } });
    expect((await answer).viewerId).toBe(viewerId);
    const iceV = tunggu<{ candidate: { candidate: string } }>(obsKunci, "rtc:ice");
    a.emit("rtc:ice", { viewerId, candidate: { candidate: "candidate:1 1 udp 1 10.0.0.1 5000 typ host" } });
    expect((await iceV).candidate.candidate).toContain("candidate:1");
    const iceP = tunggu<{ viewerId: string }>(a, "rtc:ice");
    obsKunci.emit("rtc:ice", { pid: ja.pid, candidate: { candidate: "candidate:2" } });
    expect((await iceP).viewerId).toBe(viewerId);

    // operator + penonton ke-3 masih muat; ke-4 ditolak kuota
    const h2 = await kons({ peran: "host", hostToken: HOST_PIN, sesiId: ses.id });
    const o2 = await kons({ peran: "obs", pin: ses.pin, obsKey: ses.obsKey });
    const o3 = await kons({ peran: "obs", pin: ses.pin, obsKey: ses.obsKey });
    expect(await tanya(host, "rtc:watch", { pid: ja.pid })).toMatchObject({ video: true });
    expect(await tanya(h2, "rtc:watch", { pid: ja.pid })).toMatchObject({ video: true });
    expect(await tanya(o2, "rtc:watch", { pid: ja.pid })).toMatchObject({ video: false, alasan: "kuota" });
    // satu penonton pergi → kuota kembali, pemain diberi tahu
    const gone = tunggu(a, "rtc:viewer-gone");
    obsKunci.close();
    await gone;
    expect(await tanya(o3, "rtc:watch", { pid: ja.pid })).toMatchObject({ video: true });
    // log kejadian berantai mencatat penonton
    const log = app.reg.get(ses.id)!.log.rows.map((r) => r.tipe);
    expect(log).toContain("rtc.spectate_start");
    expect(log).toContain("rtc.spectate_end");
  });

  it("kamera mati total bila guru tidak mengaktifkannya", async () => {
    const ses = await buatSesi({
      kamera: {
        mode: "mati",
        persetujuanGuru: true,
        izinOrtuDikonfirmasi: false,
        mikrofon: false,
        siapaBolehLihat: "operator-obs",
      },
    });
    const a = await kons({ peran: "pemain", pin: ses.pin });
    await tanya(a, "lr:join", { nama: "Ayu" });
    expect(await tanya(a, "kamera:minta")).toMatchObject({ ok: false });
  });
});

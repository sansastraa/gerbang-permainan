// Alat kecil server: jam yang bisa disuntik (tes memakai jam terkendali), log kejadian berantai hash, penjaga PIN, bank.
import crypto from "node:crypto";
import fs from "node:fs";
import path from "node:path";
import { CONFIG } from "@logic-rush/shared";
import { loadPool } from "@logic-rush/shared/src/bank-node";
import type { Board } from "@logic-rush/shared";

export interface Clock {
  now(): number;
  setTimeout(fn: () => void, ms: number): unknown;
  clearTimeout(h: unknown): void;
}
export const realClock: Clock = {
  now: () => Date.now(),
  setTimeout: (fn, ms) => setTimeout(fn, ms),
  clearTimeout: (h) => clearTimeout(h as NodeJS.Timeout),
};

/** Jam palsu untuk tes: waktu maju hanya lewat advance(); pewaktu berjalan menurut urutan waktu. */
export class FakeClock implements Clock {
  t: number;
  private seq = 0;
  private timers = new Map<number, { at: number; fn: () => void }>();
  constructor(start = 1_800_000_000_000) {
    this.t = start;
  }
  now(): number {
    return this.t;
  }
  setTimeout(fn: () => void, ms: number): unknown {
    const id = ++this.seq;
    this.timers.set(id, { at: this.t + ms, fn });
    return id;
  }
  clearTimeout(h: unknown): void {
    this.timers.delete(h as number);
  }
  advance(ms: number): void {
    const target = this.t + ms;
    for (;;) {
      let next: [number, { at: number; fn: () => void }] | null = null;
      for (const e of this.timers)
        if (e[1].at <= target && (!next || e[1].at < next[1].at || (e[1].at === next[1].at && e[0] < next[0])))
          next = e;
      if (!next) break;
      this.timers.delete(next[0]);
      this.t = Math.max(this.t, next[1].at);
      next[1].fn();
    }
    this.t = target;
  }
  get pending(): number {
    return this.timers.size;
  }
}

// ---------------------------------------------------------------- log kejadian berantai hash
export interface LogRow {
  seq: number;
  ts: number;
  tipe: string;
  aktor: string;
  data: unknown;
  prev: string;
  hash: string;
}
export class EventLog {
  rows: LogRow[] = [];
  constructor(
    private clock: Clock,
    private file?: string,
  ) {
    if (file) fs.mkdirSync(path.dirname(file), { recursive: true });
  }
  add(tipe: string, aktor: string, data: unknown = {}): LogRow {
    const prev = this.rows.at(-1)?.hash ?? "0".repeat(64);
    const base = { seq: this.rows.length + 1, ts: this.clock.now(), tipe, aktor, data, prev };
    const hash = crypto.createHash("sha256").update(JSON.stringify(base)).digest("hex");
    const row: LogRow = { ...base, hash };
    this.rows.push(row);
    if (this.file) {
      try {
        fs.appendFileSync(this.file, JSON.stringify(row) + "\n");
      } catch {
        /* log gagal tidak boleh menghentikan permainan */
      }
    }
    return row;
  }
  static verify(rows: LogRow[]): boolean {
    let prev = "0".repeat(64);
    for (const r of rows) {
      const { hash, ...base } = r;
      if (base.prev !== prev) return false;
      if (crypto.createHash("sha256").update(JSON.stringify(base)).digest("hex") !== hash) return false;
      prev = hash;
    }
    return true;
  }
}

// ---------------------------------------------------------------- penjaga percobaan PIN
export class PinGuard {
  private fails = new Map<string, number[]>();
  private locked = new Map<string, number>();
  constructor(
    private clock: Clock,
    private maks = CONFIG.pin.percobaan_salah_maks_per_menit,
    private kunciMs = 60_000,
  ) {}
  /** Sisa detik terkunci, atau 0 bila boleh mencoba. */
  terkunci(key: string): number {
    const until = this.locked.get(key) ?? 0;
    return until > this.clock.now() ? Math.ceil((until - this.clock.now()) / 1000) : 0;
  }
  gagal(key: string): void {
    const now = this.clock.now();
    const arr = (this.fails.get(key) ?? []).filter((t) => now - t < 60_000);
    arr.push(now);
    this.fails.set(key, arr);
    if (arr.length >= this.maks) {
      this.locked.set(key, now + this.kunciMs);
      this.fails.delete(key);
    }
  }
  berhasil(key: string): void {
    this.fails.delete(key);
  }
}

// ---------------------------------------------------------------- bank (hanya server)
export class Bank {
  private cache = new Map<string, Board[]>();
  constructor(private dir?: string) {}
  pool(key: string): Board[] {
    let p = this.cache.get(key);
    if (!p) {
      p = loadPool(key, this.dir);
      this.cache.set(key, p);
    }
    return p;
  }
  /** Papan lengkap (dengan solusi) menurut id; id berbentuk `LR5a-012`. */
  byId(id: string): Board | undefined {
    const key = id.split("-")[0];
    return this.pool(key).find((b) => b.id === id);
  }
}

export const sha256 = (s: string): string => crypto.createHash("sha256").update(s).digest("hex");
export const randomToken = (): string => crypto.randomBytes(16).toString("hex");

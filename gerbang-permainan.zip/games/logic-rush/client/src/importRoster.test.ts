import { describe, expect, it } from "vitest";
import { ROSTER_MESSAGE, buildKembaliUrl, parseImportMessage, parseKembaliUrl, parseManualNames } from "./importRoster";

const ok = {
  type: ROSTER_MESSAGE,
  kelas: "6A",
  roster: [
    { id: "s1", name: "Rina", absen: 1 },
    { id: "s2", name: "Budi" },
  ],
};

describe("pesan roster dari SIMPETERI", () => {
  it("menerima pesan sah beserta pin, kembali, multiSesi", () => {
    const r = parseImportMessage({
      ...ok,
      pin: "1234",
      kembali: "https://simpeteri.example/multi-permainan?x=1",
      multiSesi: "ms-1",
    });
    expect(r?.roster.length).toBe(2);
    expect(r?.pin).toBe("1234");
    expect(r?.multiSesi).toBe("ms-1");
  });
  it("menolak bentuk salah, id kembar, lebih dari 40 siswa, kembali bukan http(s)", () => {
    expect(parseImportMessage(null)).toBeNull();
    expect(parseImportMessage({ ...ok, type: "claim80:roster" })).toBeNull();
    expect(
      parseImportMessage({
        ...ok,
        roster: [
          { id: "a", name: "A" },
          { id: "a", name: "B" },
        ],
      }),
    ).toBeNull();
    expect(
      parseImportMessage({ ...ok, roster: Array.from({ length: 41 }, (_, i) => ({ id: "s" + i, name: "N" + i })) }),
    ).toBeNull();
    expect(parseImportMessage({ ...ok, kembali: "javascript:alert(1)" })).toBeNull();
    expect(parseImportMessage({ ...ok, pin: "12" })).toBeNull();
    expect(parseImportMessage({ ...ok, roster: [{ id: "a", name: "A", absen: 0 }] })).toBeNull();
  });
  it("URL kembali hanya bila satu origin dengan pengirim", () => {
    expect(buildKembaliUrl("https://s.example/multi?a=1", "https://s.example", "lr-1")).toBe(
      "https://s.example/multi?a=1&selesai=1&gameSesi=lr-1",
    );
    expect(buildKembaliUrl("https://s.example/multi", "https://jahat.example", "lr-1")).toBeNull();
    expect(parseKembaliUrl("/relatif")).toBeNull();
  });
  it("impor manual satu nama per baris", () => {
    expect(parseManualNames("Rina\n\n  Budi  \n").map((x) => x.name)).toEqual(["Rina", "Budi"]);
  });
});

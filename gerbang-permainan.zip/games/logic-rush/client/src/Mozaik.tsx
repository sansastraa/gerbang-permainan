// Mozaik tontonan: SISI KAMERA + SISI PERMAINAN per pemain. Dipakai /watch, /obs, dan panel operator.
import { useEffect, useMemo, useRef, useState } from "react";
import type { Socket } from "socket.io-client";
import type { MatchPublik, PemainPublik, StatePublik } from "@logic-rush/shared";
import { Board } from "./Board";
import { fmtMs, fmtWaktu, sekarang, tanya, useLive } from "./net";
import { Arena } from "./Peringkat";
import { RtcViewer, ambilIce } from "./rtc";

export function useNow(interval = 250): number {
  const [t, setT] = useState(() => sekarang());
  useEffect(() => {
    const id = setInterval(() => setT(sekarang()), interval);
    return () => clearInterval(id);
  }, [interval]);
  return t;
}

/** Pertandingan yang ditampilkan: yang aktif, kalau tidak ada yang terakhir selesai/antre. */
export function pilihMatch(st: StatePublik | null): MatchPublik | null {
  if (!st) return null;
  const aktif = st.matches.find((m) => m.id === st.aktif);
  if (aktif) return aktif;
  const selesai = st.matches.filter((m) => m.status === "selesai");
  return selesai.at(-1) ?? st.matches.find((m) => m.status === "antre") ?? null;
}

/** Mengelola sambungan WebRTC penonton untuk pemain di pertandingan yang tampil. */
export function useTonton(
  sock: Socket | null,
  match: MatchPublik | null,
  pemain: PemainPublik[],
  pakaiVideo: boolean,
): RtcViewer | null {
  const viewer = useRef<RtcViewer | null>(null);
  const dipantau = useRef(new Map<string, string>());
  const [siap, setSiap] = useState(false);
  useEffect(() => {
    if (!sock) return;
    let batal = false;
    void ambilIce().then((ice) => {
      if (batal) return;
      viewer.current = new RtcViewer(sock, ice);
      setSiap(true);
    });
    return () => {
      batal = true;
      viewer.current?.stopAll();
    };
  }, [sock]);
  const kunci = match
    ? match.pemain.map((p) => p + ":" + (pemain.find((x) => x.id === p)?.kamera ?? "")).join("|")
    : "";
  useEffect(() => {
    if (!siap || !viewer.current || !match) return;
    for (const pid of match.pemain) {
      const kam = pemain.find((x) => x.id === pid)?.kamera ?? "mati";
      const sebelum = dipantau.current.get(pid);
      if (sebelum === kam) continue;
      dipantau.current.set(pid, kam);
      if (kam === "menyala" && pakaiVideo) void viewer.current.watch(pid, true);
      else viewer.current.stop(pid);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [siap, kunci, pakaiVideo]);
  return viewer.current;
}

function Video({ stream, suara }: { stream: MediaStream; suara: boolean }) {
  const ref = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (ref.current) ref.current.srcObject = stream;
  }, [stream]);
  return <video ref={ref} autoPlay playsInline muted={!suara} />;
}

export interface MozaikProps {
  sock: Socket | null;
  layout?: "auto" | "duel" | "trio";
  cam?: boolean;
  suara?: boolean;
  /** gaya adegan OBS: tanpa kontrol, kamera dan papan lebih besar */
  obs?: boolean;
  skor?: boolean;
}

export function Mozaik({ sock, layout = "auto", cam = true, suara = false, obs = false, skor = true }: MozaikProps) {
  const st = useLive((s) => s.state);
  const tayang = useLive((s) => s.tayang);
  const streams = useLive((s) => s.streams);
  const jalur = useLive((s) => s.jalur);
  const [besar, setBesar] = useState<string | null>(null);
  const now = useNow();
  const peristiwa = useLive((s) => s.peristiwa);
  const m = pilihMatch(st);
  useTonton(sock, m, st?.pemain ?? [], cam && !m?.massal);
  const nama = useMemo(() => new Map((st?.pemain ?? []).map((p) => [p.id, p])), [st?.pemain]);

  if (!st || !m)
    return (
      <div className="mozaik-kosong">
        <p className="kosong-judul">Belum ada pertandingan</p>
        <p>Papan dan kamera pemain muncul di sini begitu guru memulai.</p>
      </div>
    );
  const kolom = layout === "duel" ? 2 : layout === "trio" ? 3 : m.pemain.length;
  const g = m.game;
  const sisa = g?.deadlineTs ? g.deadlineTs - now : null;
  const hitung = g?.hitungSampaiTs ? Math.max(0, Math.ceil((g.hitungSampaiTs - now) / 1000)) : null;
  return (
    <div className={`mozaik${obs ? " obs" : ""}`} data-kolom={kolom}>
      <header className="mz-atas">
        <div className="mz-judul">
          <span className="mz-babak">
            {m.massal
              ? `Arena massal · game ${m.games.length + (m.game ? 1 : 0)} dari ${m.bestOf}`
              : `Babak ${m.babak} · Laga ${m.nomor}`}
          </span>
          <strong>
            {m.massal ? `${m.pemain.length} pemain` : m.pemain.map((p) => nama.get(p)?.nama ?? "?").join("  ×  ")}
          </strong>
        </div>
        <div className="mz-info">
          {g && (
            <span className="mz-papan">
              Game {g.no} · {g.stages.length > 1 ? `${g.stages.length} papan` : `${g.stage.n}×${g.stage.n}`}
              {g.stage.arsir ? " · arsir" : ""}
              {g.stage.diagonal ? " · miring" : ""}
            </span>
          )}
          {m.status === "main" && sisa !== null && (
            <span className={`mz-jam${sisa < 15000 ? " mepet" : ""}`}>{fmtWaktu(sisa)}</span>
          )}
          {m.status === "hitung" && hitung !== null && (
            <span className="mz-jam hitung">{hitung > 0 ? hitung : "Mulai!"}</span>
          )}
          {m.status === "rehat" && <span className="mz-jam rehat">rehat</span>}
          {m.status === "selesai" && (
            <span className="mz-jam rehat">
              {m.seri ? "seri" : `${nama.get(m.pemenang ?? "")?.nama ?? "?"} menang`}
            </span>
          )}
          {m.jeda && <span className="mz-jeda">dijeda</span>}
        </div>
      </header>
      {m.massal ? (
        <Arena match={m} state={st} now={now} />
      ) : (
        <div className="mz-isi" style={{ gridTemplateColumns: besar ? "1fr" : `repeat(${kolom}, minmax(0, 1fr))` }}>
          {m.pemain
            .filter((p) => !besar || p === besar)
            .map((pid) => {
              const p = nama.get(pid);
              const t = tayang[pid];
              const live = g?.pemain[pid];
              const stream = streams[pid];
              const hasil = m.games.at(-1)?.hasil.find((h) => h.pid === pid);
              const menangMatch = m.menang[pid] ?? 0;
              return (
                <section
                  key={pid}
                  className={`pnl${(live?.selesaiMs ?? null) !== null ? " tamat" : ""}${live && live.pelanggaran > 0 ? " melanggar" : ""}`}
                >
                  {(() => {
                    const e = [...peristiwa]
                      .reverse()
                      .find((x) => x.jenis === "papan-tuntas" && x.data["pid"] === pid && Date.now() - x.t < 2600);
                    return e ? (
                      <div key={e.id} className="badge-tuntas" aria-live="polite">
                        Papan {String(e.data["boardNo"])} tuntas!
                      </div>
                    ) : null;
                  })()}
                  <div className="pnl-nama">
                    <span className="pnl-n">{p?.nama ?? "?"}</span>
                    <span className="pnl-skor" aria-label={`${menangMatch} dari ${m.perluMenang} kemenangan`}>
                      {Array.from({ length: m.perluMenang }, (_, i) => (
                        <i key={i} className={i < menangMatch ? "isi" : ""} />
                      ))}
                    </span>
                  </div>
                  {cam && (
                    <button
                      type="button"
                      className={`pnl-kamera${stream ? " hidup" : ""}`}
                      onClick={() => setBesar(besar ? null : pid)}
                      title={besar ? "Kecilkan" : "Perbesar kamera"}
                    >
                      {stream ? (
                        <Video stream={stream} suara={suara} />
                      ) : (
                        <span className="tanpa-kamera">
                          <b>{(p?.nama ?? "?").slice(0, 1).toUpperCase()}</b>
                          <small>{p?.kamera === "menyala" ? "menyambung…" : "tanpa kamera"}</small>
                        </span>
                      )}
                      {stream && (
                        <span className="lampu-langsung">LANGSUNG · {jalur[pid] === "p2p" ? "P2P" : "relay"}</span>
                      )}
                    </button>
                  )}
                  <div className="pnl-papan">
                    {t?.view.board ? (
                      <Board
                        board={t.view.board}
                        gems={t.view.gems}
                        xs={t.view.xs}
                        locked={t.view.locked}
                        last={t.last && sekarang() - t.lastAt < 2500 ? t.last : null}
                        trail={t.trail}
                        mini
                      />
                    ) : (
                      <div className="papan-menunggu">menunggu papan…</div>
                    )}
                  </div>
                  <div className="pnl-kaki">
                    <span>
                      {live && live.papanTotal > 1 && (
                        <b style={{ marginRight: ".5rem" }}>
                          Papan {Math.min(live.papanSelesai + 1, live.papanTotal)}/{live.papanTotal}
                        </b>
                      )}
                      <b>{live ? live.gems : (t?.view.gems.length ?? 0)}</b>/{t?.view.board?.n ?? g?.stage.n ?? "?"}{" "}
                      permata
                    </span>
                    {live && live.pelanggaran > 0 && <span className="pel">{live.pelanggaran} bentrok</span>}
                    {(live?.hints ?? 0) > 0 && <span className="bantu">bantuan ×{live?.hints}</span>}
                    {live && live.selesaiMs !== null && (
                      <span className="selesai">selesai {fmtMs(live.selesaiMs)}</span>
                    )}
                    {!live && hasil && (
                      <span className="selesai">
                        {hasil.ms !== null ? `#${hasil.rank} · ${fmtMs(hasil.ms)}` : "tidak selesai"}
                      </span>
                    )}
                    {skor && <span className="total">{st.skor.find((x) => x.pid === pid)?.skor ?? 0} poin</span>}
                  </div>
                </section>
              );
            })}
        </div>
      )}
    </div>
  );
}

export async function mulaiTonton(sock: Socket): Promise<void> {
  await tanya(sock, "lr:tonton");
}

/**
 * Awalan jalur (BASE_PATH), mis. "/games/logic-rush" bila game diakses lewat gerbang SIMPETERI. Kosong = di akar.
 * Nilainya datang dari `base` Vite saat build (`BASE_PATH=/games/logic-rush npm run build`).
 */
export const normalisasiBase = (b?: string | null): string => {
  let s = (b ?? "").trim();
  if (!s || s === "/") return "";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "");
};

export const BASE: string = normalisasiBase(import.meta.env.BASE_URL);

/** Gabungkan awalan dengan jalur internal. */
export const gabungJalur = (base: string, p: string): string =>
  normalisasiBase(base) + (p.startsWith("/") ? p : "/" + p);

/** Jalur internal untuk fetch, socket.io, dan tautan (selalu lewat sini, jangan menulis "/api/..." langsung). */
export const url = (p: string): string => gabungJalur(BASE, p);

/** Alamat mutlak untuk ditampilkan atau dibagikan ke murid (QR, tautan /watch dan /obs). */
export const alamatMutlak = (p = "/"): string => location.origin + url(p);

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import type { Socket } from "socket.io-client";
import { CONFIG, RULE_TEXT, check, peringkatLangsung, spectate as SP } from "@logic-rush/shared";
import type { BoardKirim, Cell, FinishResult, MatchPublik, Rule } from "@logic-rush/shared";
import { Board, Permata } from "./Board";
import { Mozaik, useNow } from "./Mozaik";
import { Klasemen, barisUntuk } from "./Peringkat";
import { fmtMs, fmtWaktu, sambung, sekarang, tanya, useLive } from "./net";
import { pengirimUntuk } from "./rtc";
import { url } from "./url";
import type { RtcSender } from "./rtc";

interface Simpan {
  sesiId: string;
  token: string;
  pid: string;
  nama: string;
}
const KUNCI = "logicrush.pemain";
const baca = (): Simpan | null => {
  try {
    return JSON.parse(localStorage.getItem(KUNCI) ?? "null") as Simpan | null;
  } catch {
    return null;
  }
};

type Lookup = {
  id: string;
  nama: string;
  roster: { siswaId: string | number; nama: string; absen: number | null; dipakai: boolean }[];
  kamera: string;
};

export function Play() {
  const params = new URLSearchParams(location.search);
  const [pin, setPin] = useState(params.get("pin") ?? "");
  const [info, setInfo] = useState<Lookup | null>(null);
  const [nama, setNama] = useState("");
  const [galat, setGalat] = useState("");
  const [sock, setSock] = useState<Socket | null>(null);
  const [saya, setSaya] = useState<Simpan | null>(null);
  const [sibuk, setSibuk] = useState(false);

  // masuk ulang otomatis bila token tersimpan
  useEffect(() => {
    const s = baca();
    if (!s) return;
    setSibuk(true);
    void sambung({ peran: "pemain", sesiId: s.sesiId, token: s.token })
      .then(async (k) => {
        const r = await tanya<{ ok: boolean; pid: string }>(k, "lr:join", { token: s.token });
        if (r.ok) {
          setSock(k);
          setSaya({ ...s, pid: r.pid });
        } else {
          localStorage.removeItem(KUNCI);
          k.close();
        }
      })
      .catch(() => localStorage.removeItem(KUNCI))
      .finally(() => setSibuk(false));
  }, []);

  const cekPin = async () => {
    setGalat("");
    setSibuk(true);
    try {
      const r = await fetch(url("/api/lookup"), {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ pin }),
      });
      const j = (await r.json()) as Lookup & { error?: string };
      if (!r.ok) setGalat(j.error ?? "PIN tidak ditemukan.");
      else setInfo(j);
    } catch {
      setGalat("Tidak bisa terhubung ke server. Cek Wi-Fi.");
    }
    setSibuk(false);
  };
  const masuk = async (siswaId?: string | number) => {
    setGalat("");
    setSibuk(true);
    try {
      const k = await sambung({ peran: "pemain", pin });
      const r = await tanya<{
        ok: boolean;
        alasan?: string;
        pid: string;
        token: string;
        pemain: { nama: string };
        sesiId: string;
      }>(k, "lr:join", {
        ...(siswaId !== undefined ? { siswaId } : { nama }),
      });
      if (!r.ok) {
        setGalat(r.alasan ?? "Gagal masuk.");
        k.close();
      } else {
        const s = { sesiId: r.sesiId, token: r.token, pid: r.pid, nama: r.pemain.nama };
        localStorage.setItem(KUNCI, JSON.stringify(s));
        setSock(k);
        setSaya(s);
      }
    } catch (e) {
      setGalat(
        String(e instanceof Error ? e.message : e).includes("terkunci")
          ? "Terlalu banyak percobaan. Tunggu semenit."
          : "PIN salah atau server tidak terjangkau.",
      );
    }
    setSibuk(false);
  };

  if (sock && saya)
    return <Ruang sock={sock} saya={saya} keluar={() => (localStorage.removeItem(KUNCI), location.reload())} />;
  return (
    <main className="gerbang">
      <div className="gerbang-kiri">
        <Permata />
        <h1>Logic Rush</h1>
        <p className="lead">Taruh permata di papan. Satu per baris, satu per kolom, satu per warna.</p>
      </div>
      <div className="gerbang-kanan">
        {!info ? (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void cekPin();
            }}
          >
            <label htmlFor="pin">PIN dari guru</label>
            <input
              id="pin"
              inputMode="numeric"
              autoComplete="off"
              maxLength={6}
              value={pin}
              onChange={(e) => setPin(e.target.value.replace(/\D/g, ""))}
              className="pin-input"
              placeholder="••••••"
              autoFocus
            />
            <button className="tombol utama" disabled={pin.length !== 6 || sibuk}>
              {sibuk ? "Memeriksa…" : "Cari kelas"}
            </button>
          </form>
        ) : (
          <div>
            <p className="kecil">Kelas</p>
            <h2>{info.nama}</h2>
            {info.roster.length ? (
              <>
                <label>Pilih namamu</label>
                <ul className="daftar-nama">
                  {info.roster.map((r) => (
                    <li key={String(r.siswaId)}>
                      <button className="tombol" disabled={r.dipakai || sibuk} onClick={() => void masuk(r.siswaId)}>
                        {r.absen ? <i>{r.absen}</i> : null}
                        {r.nama}
                        {r.dipakai ? <small> sudah masuk</small> : null}
                      </button>
                    </li>
                  ))}
                </ul>
              </>
            ) : (
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  void masuk();
                }}
              >
                <label htmlFor="nama">Namamu</label>
                <input
                  id="nama"
                  maxLength={CONFIG.pin.nama_maks_karakter}
                  value={nama}
                  onChange={(e) => setNama(e.target.value)}
                  placeholder="mis. Rina"
                  autoFocus
                />
                <button className="tombol utama" disabled={!nama.trim() || sibuk}>
                  Masuk
                </button>
              </form>
            )}
            <button className="tautan" onClick={() => setInfo(null)}>
              ganti PIN
            </button>
          </div>
        )}
        {galat && (
          <p className="galat" role="alert">
            {galat}
          </p>
        )}
      </div>
    </main>
  );
}

function Ruang({ sock, saya, keluar }: { sock: Socket; saya: Simpan; keluar: () => void }) {
  const st = useLive((s) => s.state);
  const terhubung = useLive((s) => s.terhubung);
  const now = useNow();
  const [dikeluarkan, setDikeluarkan] = useState(false);
  const [bd, setBd] = useState<BoardKirim | null>(null);
  const [panggil, setPanggil] = useState(false);
  const [tuntas, setTuntas] = useState<{ k: number; no: number; total: number; ms: number } | null>(null);

  useEffect(() => {
    const onB = (b: BoardKirim) => setBd(b);
    // animasi "papan tuntas" untuk papan milik sendiri; layar langsung memuat papan berikutnya di baliknya
    let tunda: ReturnType<typeof setTimeout> | undefined;
    const onT = (e: { pid: string; boardNo: number; boardTotal: number; ms: number }) => {
      if (e.pid !== saya.pid) return;
      setTuntas({ k: Date.now(), no: e.boardNo, total: e.boardTotal, ms: e.ms });
      clearTimeout(tunda);
      tunda = setTimeout(() => setTuntas(null), 1700);
    };
    sock.on("lr:papan-tuntas", onT);
    const onK = () => setDikeluarkan(true);
    const onW = (w: { matchId: string; mulaiTs: number; deadlineTs: number }) =>
      setBd((x) => (x && x.matchId === w.matchId ? { ...x, mulaiTs: w.mulaiTs, deadlineTs: w.deadlineTs } : x));
    sock.on("lr:board", onB);
    sock.on("lr:dikeluarkan", onK);
    sock.on("lr:waktu", onW);
    void tanya(sock, "lr:tonton");
    return () => {
      clearTimeout(tunda);
      sock.off("lr:papan-tuntas", onT);
      sock.off("lr:board", onB);
      sock.off("lr:dikeluarkan", onK);
      sock.off("lr:waktu", onW);
    };
  }, [sock, saya.pid]);
  // fokus hilang → bendera ringan untuk guru
  useEffect(() => {
    let hilang = 0;
    const f = () => {
      if (document.hidden) hilang = Date.now();
      else if (hilang) {
        sock.emit("lr:fokus", { ms: Date.now() - hilang });
        hilang = 0;
      }
    };
    document.addEventListener("visibilitychange", f);
    return () => document.removeEventListener("visibilitychange", f);
  }, [sock]);

  const saatIni: MatchPublik | undefined = useMemo(() => {
    const ms = (st?.matches ?? []).filter((m) => m.pemain.includes(saya.pid));
    return ms.find((m) => !["selesai", "batal"].includes(m.status)) ?? ms.filter((m) => m.status === "selesai").at(-1);
  }, [st, saya.pid]);

  useEffect(() => {
    if (saatIni?.status === "siap") setPanggil(true);
  }, [saatIni?.status, saatIni?.id]);

  if (dikeluarkan)
    return (
      <main className="tengah">
        <h1>Kamu keluar dari sesi</h1>
        <p>Guru mengeluarkanmu. Tanya gurumu kalau ini keliru.</p>
        <button className="tombol" onClick={keluar}>
          Mulai lagi
        </button>
      </main>
    );
  const namaDari = (id: string) => st?.pemain.find((p) => p.id === id)?.nama ?? "?";
  const skorku = st?.skor.find((s) => s.pid === saya.pid);

  const sedangBermain = saatIni && ["hitung", "main"].includes(saatIni.status);
  return (
    <div className="ruang">
      <header className="bilah">
        <span className="bilah-nama">{saya.nama}</span>
        <span className={`sinyal${terhubung ? "" : " putus"}`}>
          {terhubung ? `${skorku?.skor ?? 0} poin` : "terputus, menyambung…"}
        </span>
        {!sedangBermain && (
          <button className="tautan" onClick={keluar}>
            keluar
          </button>
        )}
      </header>
      {saatIni?.status === "main" && bd && bd.matchId === saatIni.id ? (
        <Papan key={`${bd.matchId}-${bd.gameNo}-${bd.boardNo}`} sock={sock} bd={bd} match={saatIni} />
      ) : saatIni?.status === "hitung" ? (
        <Hitung match={saatIni} now={now} />
      ) : saatIni?.status === "siap" ? (
        <Siap sock={sock} match={saatIni} saya={saya.pid} namaDari={namaDari} tampil={panggil} />
      ) : saatIni?.status === "rehat" ? (
        <Rehat match={saatIni} saya={saya.pid} namaDari={namaDari} />
      ) : saatIni?.status === "selesai" ? (
        <Akhir match={saatIni} saya={saya.pid} namaDari={namaDari} />
      ) : (
        <Tunggu sock={sock} ada={!!saatIni} />
      )}
      {!sedangBermain && st?.settings.kamera.mode === "opsional" && <KameraPanel sock={sock} saya={saya.pid} />}
      {tuntas && <Tuntas key={tuntas.k} no={tuntas.no} total={tuntas.total} ms={tuntas.ms} />}
    </div>
  );
}

function Tunggu({ sock, ada }: { sock: Socket; ada: boolean }) {
  return (
    <section className="tunggu">
      <h2>{ada ? "Sebentar lagi giliranmu" : "Kamu sudah masuk"}</h2>
      <p>Guru akan memanggil namamu ke papan. Sambil menunggu, lihat teman yang sedang bertanding.</p>
      <div className="tunggu-tonton">
        <Mozaik sock={sock} cam={false} />
      </div>
    </section>
  );
}

function Siap({
  sock,
  match,
  saya,
  namaDari,
  tampil,
}: {
  sock: Socket;
  match: MatchPublik;
  saya: string;
  namaDari: (id: string) => string;
  tampil: boolean;
}) {
  const siap = match.siap[saya];
  return (
    <section className="siap">
      <p className="kecil">Kamu dipanggil</p>
      <h2>
        {match.pemain
          .filter((p) => p !== saya)
          .map(namaDari)
          .join(" & ")}{" "}
        sudah menunggu
      </h2>
      <p>
        Terbaik dari {match.bestOf} game. Papan dasarnya sama untuk semua, tapi letak dan warnanya diputar-putar, jadi
        jangan lirik layar teman.
      </p>
      <ul className="siap-daftar">
        {match.pemain.map((p) => (
          <li key={p} className={match.siap[p] ? "ok" : ""}>
            {namaDari(p)} <span>{match.siap[p] ? "siap" : "belum"}</span>
          </li>
        ))}
      </ul>
      <button
        className={`tombol utama besar`}
        disabled={!tampil}
        onClick={() => void tanya(sock, "lr:siap", { matchId: match.id, siap: !siap })}
      >
        {siap ? "Batal siap" : "Aku siap"}
      </button>
    </section>
  );
}

function Hitung({ match, now }: { match: MatchPublik; now: number }) {
  const g = match.game;
  const d = g?.hitungSampaiTs ? Math.max(0, Math.ceil((g.hitungSampaiTs - now) / 1000)) : 0;
  return (
    <section className="hitung">
      <p className="kecil">
        Game {g?.no} ·{" "}
        {g && g.stages.length > 1
          ? `${g.stages.length} papan, mulai ${g.stage.n}×${g.stage.n}`
          : `papan ${g?.stage.n}×${g?.stage.n}`}
      </p>
      <div className="angka-besar" key={d}>
        {d > 0 ? d : "Mulai!"}
      </div>
      {g && g.aturanBaru.length > 0 && (
        <p className="aturan-baru">Aturan baru: {g.aturanBaru.map((a) => RULE_TEXT[a as Rule]).join(", ")}</p>
      )}
    </section>
  );
}

function Rehat({ match, saya, namaDari }: { match: MatchPublik; saya: string; namaDari: (id: string) => string }) {
  const g = match.games.at(-1);
  const sayaH = g?.hasil.find((h) => h.pid === saya);
  return (
    <section className="rehat">
      <p className="kecil">Game {g?.no} selesai</p>
      <h2>
        {sayaH?.menang
          ? "Kamu menang game ini!"
          : sayaH && sayaH.ms !== null
            ? `Kamu peringkat ${sayaH.rank}`
            : "Waktu habis, tidak apa-apa"}
      </h2>
      <ol className="hasil">
        {(match.massal
          ? [...(g?.hasil.slice(0, 8) ?? []), ...(g?.hasil.slice(8).filter((x) => x.pid === saya) ?? [])]
          : (g?.hasil ?? [])
        ).map((h) => (
          <li key={h.pid} className={h.pid === saya ? "aku" : ""}>
            {match.massal && <span>#{h.rank}</span>}
            <span>{namaDari(h.pid)}</span>
            <b>{h.ms !== null ? fmtMs(h.ms) : "tidak selesai"}</b>
            <i>+{h.poin}</i>
          </li>
        ))}
      </ol>
      <p>
        Skor game: {match.pemain.map((p) => `${namaDari(p)} ${match.menang[p] ?? 0}`).join("  ·  ")}. Game berikutnya
        dimulai sebentar lagi.
      </p>
    </section>
  );
}

function Akhir({ match, saya, namaDari }: { match: MatchPublik; saya: string; namaDari: (id: string) => string }) {
  const st = useLive((s) => s.state);
  const menang = match.pemenang === saya;
  return (
    <section className="rehat">
      <p className="kecil">Pertandingan selesai</p>
      <h2>
        {match.seri
          ? "Hasil seri"
          : menang
            ? "Kamu juara pertandingan ini!"
            : `${namaDari(match.pemenang ?? "")} menang kali ini`}
      </h2>
      <p>
        {match.massal ? "Arena selesai. Ini klasemen akhirnya." : "Menunggu guru menyusun pertandingan berikutnya."}
      </p>
      {match.massal && st && <Klasemen state={st} />}
    </section>
  );
}

// ------------------------------------------------------------------ papan permainan
function Papan({ sock, bd, match }: { sock: Socket; bd: BoardKirim; match: MatchPublik }) {
  const n = bd.board.n;
  const now = useNow(200);
  const [gems, setGems] = useState<Cell[]>(bd.gems);
  const [xs, setXs] = useState<Cell[]>(bd.xs);
  const [locked, setLocked] = useState<string[]>(bd.locked);
  const [mode, setMode] = useState<"gem" | "x">("gem");
  const [sisa, setSisa] = useState(bd.bantuanSisa);
  const [hasil, setHasil] = useState<"" | "cek" | "ok" | "tunggu">("");
  const [pesan, setPesan] = useState("");
  const [lebar, setLebar] = useState(320);
  const tinggi = useRef(480);
  const wrap = useRef<HTMLDivElement>(null);
  const tx = useRef(SP.makeSender());
  const rtc = useRef<RtcSender | null>(null);
  const mulaiRef = useRef(bd.mulaiTs ?? sekarang());
  const riwayat = useRef<{ op: "gem" | "clear" | "x" | "unx"; r: number; c: number }[]>([]);
  const kirimSelesai = useRef(false);

  useEffect(() => {
    for (let i = 0; i <= bd.lastS; i++) tx.current.next({ t: "ping" });
    const el = wrap.current;
    if (!el) return;
    const ro = new ResizeObserver(() => {
      setLebar(el.clientWidth);
      tinggi.current = el.clientHeight;
    });
    ro.observe(el);
    setLebar(el.clientWidth);
    return () => ro.disconnect();
  }, [bd.lastS]);

  const kirimMsg = useCallback(
    (body: Record<string, unknown> & { t: string }) => {
      const m = tx.current.next(body);
      sock.emit("lr:sp", m);
      rtc.current?.kirim(m);
    },
    [sock],
  );
  const op = useCallback(
    (o: "gem" | "clear" | "x" | "unx" | "hint", r: number, c: number) => {
      kirimMsg({ t: "mv", op: o, r, c, at: Math.max(0, sekarang() - mulaiRef.current) });
    },
    [kirimMsg],
  );

  const periksa = useCallback(
    async (g: Cell[]) => {
      if (g.length !== n || kirimSelesai.current) return;
      if (!check(bd.board, g).ok) return;
      kirimSelesai.current = true;
      setHasil("cek");
      const r = await tanya<FinishResult>(sock, "lr:finish", {
        matchId: bd.matchId,
        gameNo: bd.gameNo,
        boardNo: bd.boardNo,
        gems: g,
      });
      if (r.ok) setHasil(r.lanjut ? "cek" : "ok");
      else {
        kirimSelesai.current = false;
        setHasil("");
        setPesan("Hampir! Periksa lagi susunanmu.");
      }
    },
    [bd, n, sock],
  );

  const tap = (r: number, c: number) => {
    if (hasil) return;
    setPesan("");
    const k = `${r},${c}`;
    const ada = gems.some((g) => g.r === r && g.c === c);
    if (mode === "gem") {
      if (ada) {
        if (locked.includes(k)) return;
        setGems(gems.filter((g) => !(g.r === r && g.c === c)));
        op("clear", r, c);
        riwayat.current.push({ op: "clear", r, c });
      } else {
        const baru = [...gems, { r, c }];
        setGems(baru);
        setXs(xs.filter((x) => !(x.r === r && x.c === c)));
        op("gem", r, c);
        riwayat.current.push({ op: "gem", r, c });
        void periksa(baru);
      }
    } else if (!ada) {
      const ax = xs.some((x) => x.r === r && x.c === c);
      setXs(ax ? xs.filter((x) => !(x.r === r && x.c === c)) : [...xs, { r, c }]);
      op(ax ? "unx" : "x", r, c);
      riwayat.current.push({ op: ax ? "unx" : "x", r, c });
    }
    navigator.vibrate?.(8);
  };
  const batal = () => {
    const l = riwayat.current.pop();
    if (!l || hasil) return;
    const balik = { gem: "clear", clear: "gem", x: "unx", unx: "x" } as const;
    const o = balik[l.op];
    if (o === "gem") setGems((g) => [...g, { r: l.r, c: l.c }]);
    if (o === "clear") setGems((g) => g.filter((x) => !(x.r === l.r && x.c === l.c)));
    if (o === "x") setXs((x) => [...x, { r: l.r, c: l.c }]);
    if (o === "unx") setXs((x) => x.filter((y) => !(y.r === l.r && y.c === l.c)));
    op(o, l.r, l.c);
  };
  const bantuan = async () => {
    const r = await tanya<{ ok: boolean; alasan?: string; cell?: Cell; sisa?: number }>(sock, "lr:hint", {
      matchId: bd.matchId,
      gameNo: bd.gameNo,
      gems,
    });
    if (!r.ok || !r.cell) return setPesan(r.alasan ?? "Bantuan tidak tersedia.");
    const { r: rr, c: cc } = r.cell;
    setGems((g) => [...g.filter((x) => !(x.r === rr && x.c === cc)), r.cell as Cell]);
    setLocked((l) => [...l, `${rr},${cc}`]);
    setSisa(r.sisa ?? 0);
    op("hint", rr, cc);
    void periksa([...gems.filter((x) => !(x.r === rr && x.c === cc)), r.cell]);
  };

  const stNow = useLive((s) => s.state);
  const posisiKu = (() => {
    if (!match.massal) return null;
    const live = stNow?.matches.find((x) => x.id === match.id) ?? match;
    const { baris } = barisUntuk(live);
    const r = peringkatLangsung(baris);
    const me = r.find((x) => x.pid === (baca()?.pid ?? ""));
    return me ? { no: me.rank, dari: r.length } : null;
  })();
  const sisaMs = bd.deadlineTs ? bd.deadlineTs - now : 0;
  const sisi = Math.max(
    30,
    Math.floor(Math.min(lebar, Math.max(260, (typeof window !== "undefined" ? window.innerHeight : 640) * 0.5)) / n),
  );
  const zoom = sisi < 36;
  const sisiPakai = zoom ? 36 : sisi;
  const aturanBaru = bd.aturanBaru.length > 0 && now - (bd.mulaiTs ?? 0) < CONFIG.kartu_aturan_baru_detik * 1000;
  const lawan = match.pemain.length - 1;
  void lawan;
  return (
    <section className="papan-layar">
      <div className="papan-atas">
        <span>
          Game {bd.gameNo} · {bd.boardTotal > 1 ? `Papan ${bd.boardNo}/${bd.boardTotal} · ` : ""}
          {n}×{n}
        </span>
        <span className={`jam${sisaMs < 15000 ? " mepet" : ""}`}>{fmtWaktu(sisaMs)}</span>
        {posisiKu && (
          <span className="chip-posisi">
            #{posisiKu.no} dari {posisiKu.dari}
          </span>
        )}
        <span>
          <b>{gems.length}</b>/{n}
        </span>
      </div>
      {aturanBaru && (
        <div className="kartu-aturan">Aturan baru: {bd.aturanBaru.map((a) => RULE_TEXT[a as Rule]).join(", ")}</div>
      )}
      <div className={`papan-bungkus${zoom ? " zoom" : ""}`} ref={wrap}>
        <Board board={bd.board} gems={gems} xs={xs} locked={locked} onTap={tap} sisi={sisiPakai} />
        {hasil === "ok" && <div className="tirai">Benar! Menunggu lawan…</div>}
        {hasil === "cek" && <div className="tirai">Memeriksa…</div>}
      </div>
      {zoom && <p className="kecil">Papan besar: geser untuk melihat semua kotak.</p>}
      {pesan && <p className="galat">{pesan}</p>}
      <div className="alat">
        <button className="tombol" onClick={batal} disabled={!!hasil}>
          Batal
        </button>
        <button
          className={`tombol${mode === "x" ? " utama" : ""}`}
          onClick={() => setMode(mode === "x" ? "gem" : "x")}
          aria-pressed={mode === "x"}
          disabled={!!hasil}
        >
          {mode === "x" ? "Mode ✕ nyala" : "Tanda ✕"}
        </button>
        {bd.bantuanSisa > 0 || sisa > 0 ? (
          <button className="tombol" onClick={() => void bantuan()} disabled={!!hasil || sisa <= 0}>
            Bantuan ({sisa}) +{bd.penaltiDetik}s
          </button>
        ) : null}
      </div>
      <KameraKecil
        sock={sock}
        rtc={rtc}
        getSnap={() => ({
          t: "snap",
          s: tx.current.s,
          seq: bd.gameNo,
          board: bd.board,
          gems,
          xs,
          locked,
          hints: 0,
          elapsedMs: 0,
        })}
      />
    </section>
  );
}

// ------------------------------------------------------------------ kamera (persetujuan eksplisit, indikator jelas, bisa dimatikan)
function useSender(sock: Socket): RtcSender | null {
  const [sender, setSender] = useState<RtcSender | null>(null);
  useEffect(() => {
    let batal = false;
    void pengirimUntuk(sock).then((s) => !batal && setSender(s));
    return () => {
      batal = true;
    };
  }, [sock]);
  return sender;
}
function KameraPanel({ sock, saya }: { sock: Socket; saya: string }) {
  const st = useLive((s) => s.state);
  const me = st?.pemain.find((p) => p.id === saya);
  const [galat, setGalat] = useState("");
  const [lihat, setLihat] = useState(0);
  const [tahu, setTahu] = useState(false);
  const sender = useSender(sock);
  const vid = useRef<HTMLVideoElement>(null);
  useEffect(() => {
    if (sender) sender.onJumlah = setLihat;
  }, [sender]);
  const mik = st?.settings.kamera.mikrofon ?? false;
  const minta = async () => {
    setGalat("");
    const r = await tanya<{ ok: boolean; alasan?: string }>(sock, "kamera:minta");
    if (!r.ok) setGalat(r.alasan ?? "Gagal.");
  };
  const nyalakan = async () => {
    setGalat("");
    try {
      await sender?.nyalakan(false);
      const r = await tanya<{ ok: boolean; alasan?: string }>(sock, "kamera:status", { on: true, mikrofon: false });
      if (!r.ok) {
        sender?.matikan();
        return setGalat(r.alasan ?? "Belum diizinkan guru.");
      }
      if (vid.current && sender?.stream) vid.current.srcObject = sender.stream;
    } catch {
      setGalat("Kamera tidak bisa dibuka. Kamu tetap bisa bermain tanpa kamera.");
    }
  };
  const matikan = () => {
    sender?.matikan();
    void tanya(sock, "kamera:status", { on: false });
  };
  if (!me) return null;
  return (
    <aside className="kamera-panel">
      <h3>Kamera (boleh tidak)</h3>
      {me.kamera === "menyala" ? (
        <div className="kamera-nyala">
          <video ref={vid} autoPlay muted playsInline />
          <p className="indikator">
            <i /> KAMERA MENYALA · {lihat > 0 ? `${lihat} orang menonton` : "belum ada yang menonton"}
          </p>
          <button className="tombol" onClick={matikan}>
            Matikan kamera
          </button>
        </div>
      ) : me.kamera === "meminta" ? (
        <p>Menunggu izin dari gurumu…</p>
      ) : me.kamera === "diizinkan" ? (
        <>
          <p>Guru sudah mengizinkan. Kameramu hanya dilihat gurumu dan layar siaran, tidak direkam oleh game ini.</p>
          <button className="tombol utama" onClick={() => void nyalakan()}>
            Nyalakan kamera
          </button>
        </>
      ) : (
        <>
          {!tahu ? (
            <>
              <p>
                Kalau kamu mau, gambar kameramu bisa ditonton gurumu dan layar siaran selama pertandingan.{" "}
                {mik ? "" : "Suara tidak ikut."} Tidak ada rekaman yang disimpan di server. Kamu boleh menolak, tidak
                ada pengaruh ke skor.
              </p>
              <button className="tombol" onClick={() => setTahu(true)}>
                Saya mengerti
              </button>
            </>
          ) : (
            <button className="tombol utama" onClick={() => void minta()}>
              Minta izin guru
            </button>
          )}
        </>
      )}
      {galat && <p className="galat">{galat}</p>}
    </aside>
  );
}

/** Saat bermain: hanya pengingat kecil + penyalur DataChannel; tanpa tombol baru agar tidak mengganggu. */
function KameraKecil({
  sock,
  rtc,
  getSnap,
}: {
  sock: Socket;
  rtc: React.MutableRefObject<RtcSender | null>;
  getSnap: () => SP.SpectateMsg | null;
}) {
  const me = useLive((s) => s.state?.pemain.find((p) => p.id === (baca()?.pid ?? "")));
  const sender = useSender(sock);
  useEffect(() => {
    if (!sender) return;
    sender.snapshot = getSnap;
    rtc.current = sender;
  });
  if (me?.kamera !== "menyala") return null;
  return (
    <p className="indikator tetap">
      <i /> KAMERA MENYALA
      <button
        className="tautan"
        onClick={() => {
          sender?.matikan();
          void tanya(sock, "kamera:status", { on: false });
        }}
      >
        matikan
      </button>
    </p>
  );
}

/** Animasi papan tuntas: kartu memantul, permata berputar, percikan warna; lalu papan berikutnya sudah siap di baliknya. */
function Tuntas({ no, total, ms }: { no: number; total: number; ms: number }) {
  const akhir = no >= total;
  return (
    <div className="tuntas-overlay" role="status" aria-live="assertive">
      <div className="tuntas-kartu">
        <div className="tuntas-permata" aria-hidden="true">
          <Permata />
          {Array.from({ length: 10 }, (_, i) => (
            <i
              key={i}
              className="percik"
              style={{
                ["--a" as string]: `${i * 36}deg`,
                ["--w" as string]: ["#ffc933", "#ff5a5f", "#43d98f", "#ff9cc8", "#fff06b"][i % 5],
              }}
            />
          ))}
        </div>
        <b>{akhir ? "Semua papan tuntas!" : `Papan ${no} tuntas!`}</b>
        <span>
          {fmtMs(ms)}
          {akhir ? "" : ` · lanjut ke papan ${no + 1} dari ${total}`}
        </span>
      </div>
    </div>
  );
}

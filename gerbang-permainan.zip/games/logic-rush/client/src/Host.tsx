// Konsol guru (/host, juga /operator): halaman terpisah dari layar murid dan penonton, dengan menu samping.
import { useEffect, useMemo, useState } from "react";
import type { Socket } from "socket.io-client";
import QRCode from "qrcode";
import { TARGET_MENIT, defaultSettings, suggestMinutes, validateSettings } from "@logic-rush/shared";
import type { MatchPublik, SesiSettingsInput, Statistik } from "@logic-rush/shared";
import { Permata } from "./Board";
import { Mozaik, pilihMatch } from "./Mozaik";
import { Klasemen, LiveRank } from "./Peringkat";
import { sambung, tanya, useLive } from "./net";
import { BASE, url } from "./url";
import { READY_MESSAGE, buildKembaliUrl, parseImportMessage, parseManualNames } from "./importRoster";
import type { ImportedRoster, ImportedStudent } from "./importRoster";

interface Presets {
  bawaan: string;
  preset: Record<string, { label: string; tahap: SesiSettingsInput["tahap"] }>;
}
interface Konteks {
  pin: string;
  asal: string | null;
  roster: ImportedStudent[];
  kelas: string;
  kembali?: string;
  multiSesi?: string;
}
const SS = "logicrush.host";

export function Host() {
  const [konteks, setKonteks] = useState<Konteks>(() => ({
    pin: sessionStorage.getItem(SS + ".pin") ?? "",
    asal: null,
    roster: [],
    kelas: "",
  }));
  const [sesi, setSesi] = useState<{ id: string; pin: string; obsKey: string } | null>(() => {
    try {
      return JSON.parse(sessionStorage.getItem(SS + ".sesi") ?? "null");
    } catch {
      return null;
    }
  });
  const [sock, setSock] = useState<Socket | null>(null);
  const [galat, setGalat] = useState("");

  // SIMPETERI: umumkan siap ke jendela pembuka dan terima daftar siswa (SIMPETERI memeriksa origin; di sini hanya pesan dari opener yang diterima)
  useEffect(() => {
    const onMsg = (e: MessageEvent) => {
      if (e.source !== window.opener) return;
      const r: ImportedRoster | null = parseImportMessage(e.data);
      if (!r) return;
      sessionStorage.setItem(SS + ".pin", r.pin ?? "");
      setKonteks({
        pin: r.pin ?? "",
        asal: e.origin,
        roster: r.roster,
        kelas: r.kelas,
        ...(r.kembali ? { kembali: r.kembali } : {}),
        ...(r.multiSesi ? { multiSesi: r.multiSesi } : {}),
      });
    };
    window.addEventListener("message", onMsg);
    window.opener?.postMessage({ type: READY_MESSAGE }, "*");
    return () => window.removeEventListener("message", onMsg);
  }, []);

  useEffect(() => {
    if (!sesi || !konteks.pin || sock) return;
    void sambung({ peran: "host", hostToken: konteks.pin, sesiId: sesi.id })
      .then(setSock)
      .catch(() => {
        sessionStorage.removeItem(SS + ".sesi");
        setSesi(null);
      });
  }, [sesi, konteks.pin, sock]);

  if (!sesi || !sock)
    return (
      <Siapkan
        konteks={konteks}
        setKonteks={setKonteks}
        galat={galat}
        setGalat={setGalat}
        onSesi={(s) => (sessionStorage.setItem(SS + ".sesi", JSON.stringify(s)), setSesi(s))}
      />
    );
  return <Konsol sock={sock} sesi={sesi} konteks={konteks} />;
}

// ------------------------------------------------------------------ pengaturan sebelum sesi (panel Atur Papan)
function Siapkan({
  konteks,
  setKonteks,
  galat,
  setGalat,
  onSesi,
}: {
  konteks: Konteks;
  setKonteks: (k: Konteks) => void;
  galat: string;
  setGalat: (s: string) => void;
  onSesi: (s: { id: string; pin: string; obsKey: string }) => void;
}) {
  const [presets, setPresets] = useState<Presets | null>(null);
  const [s, setS] = useState<SesiSettingsInput>(() => defaultSettings());
  const [teks, setTeks] = useState("");
  const [sibuk, setSibuk] = useState(false);
  useEffect(() => {
    void fetch(url("/api/presets"))
      .then((r) => r.json())
      .then((p: Presets) => setPresets(p));
  }, []);
  const tahap = s.tahap;
  const massal = s.format === "massal";
  const v = useMemo(() => validateSettings(s), [s]);
  const usulan = suggestMinutes(tahap.map((t) => ({ n: t.n, diagonal: !!t.diagonal })));
  const ubahTahap = (i: number, p: Partial<(typeof tahap)[number]>) =>
    setS({
      ...s,
      tahap: tahap.map((t, j) =>
        j === i ? { ...t, ...p, ...(p.n !== undefined && p.n < 4 ? { diagonal: false } : {}) } : t,
      ),
    });
  const kam = s.kamera ?? {};
  const roster = konteks.roster.length ? konteks.roster : parseManualNames(teks);

  const buat = async () => {
    setGalat("");
    setSibuk(true);
    try {
      const r = await fetch(url("/api/sessions"), {
        method: "POST",
        headers: { "content-type": "application/json", "x-host-token": konteks.pin },
        body: JSON.stringify({
          settings: s,
          roster: roster.map((x) => ({ siswaId: x.id, nama: x.name, absen: x.absen ?? null })),
        }),
      });
      const j = (await r.json()) as { id: string; pin: string; obsKey: string; error?: string };
      if (!r.ok) setGalat(r.status === 401 ? "PIN guru salah." : (j.error ?? "Gagal membuat sesi."));
      else {
        sessionStorage.setItem(SS + ".pin", konteks.pin);
        onSesi(j);
      }
    } catch {
      setGalat("Server tidak terjangkau.");
    }
    setSibuk(false);
  };
  return (
    <main className="siapkan">
      <header className="siapkan-kepala">
        <h1>Logic Rush · Konsol Guru</h1>
        <p>Atur papan dan aturan pertandingan, lalu bagikan PIN ke murid.</p>
      </header>
      <section className="blok">
        <h2>1 · PIN guru</h2>
        <input
          type="password"
          value={konteks.pin}
          placeholder="PIN guru dari server (atau dari SIMPETERI)"
          onChange={(e) => setKonteks({ ...konteks, pin: e.target.value })}
        />
        {konteks.asal && (
          <p className="kecil">
            Terhubung ke SIMPETERI ({konteks.asal}). Kelas {konteks.kelas || "-"}: {konteks.roster.length} siswa.
          </p>
        )}
      </section>
      <section className="blok hijau">
        <h2>2 · Format</h2>
        <div className="pilihan-format">
          <button type="button" aria-pressed={!massal} onClick={() => setS({ ...s, format: "laga" })}>
            <b>Laga 2–3 pemain</b>
            Papan sama untuk semua, terbaik dari N game. Boleh pakai kamera (RTC) dan OBS.
          </button>
          <button
            type="button"
            aria-pressed={massal}
            onClick={() =>
              setS({
                ...s,
                format: "massal",
                kamera: { ...kam, mode: "mati", izinOrtuDikonfirmasi: false, mikrofon: false },
              })
            }
          >
            <b>Massal, di atas 3 pemain</b>
            Sampai 40 murid sekaligus. Tanpa kamera: papan peringkat naik-turun langsung dan sorotan bergilir.
          </button>
        </div>
      </section>
      <section className="blok jeruk">
        <h2>3 · Atur Papan</h2>
        <div className="baris">
          <label>Preset</label>
          <select
            onChange={(e) => {
              const p = presets?.preset[e.target.value];
              if (p) setS({ ...s, tahap: p.tahap });
            }}
            defaultValue=""
          >
            <option value="" disabled>
              pilih preset…
            </option>
            {presets &&
              Object.entries(presets.preset).map(([k, p]) => (
                <option key={k} value={k}>
                  {p.label}
                </option>
              ))}
          </select>
        </div>
        <ol className="tahap-daftar">
          {tahap.map((t, i) => (
            <li key={i}>
              <b>Papan {i + 1}</b>
              <select value={t.n} onChange={(e) => ubahTahap(i, { n: Number(e.target.value) })} aria-label="Ukuran">
                {[3, 4, 5, 6, 7, 8, 9, 10].map((n) => (
                  <option key={n} value={n}>
                    {n}×{n}
                  </option>
                ))}
              </select>
              <label>
                <input
                  type="checkbox"
                  checked={!!t.arsir}
                  onChange={(e) => ubahTahap(i, { arsir: e.target.checked })}
                />{" "}
                arsir
              </label>
              <label>
                <input
                  type="checkbox"
                  checked={!!t.diagonal}
                  disabled={t.n < 4}
                  onChange={(e) => ubahTahap(i, { diagonal: e.target.checked })}
                />{" "}
                miring
              </label>
              <select
                value={t.level ?? "sedang"}
                onChange={(e) => ubahTahap(i, { level: e.target.value as "mudah" | "sedang" | "sulit" })}
                aria-label="Level"
              >
                <option>mudah</option>
                <option>sedang</option>
                <option>sulit</option>
              </select>
              <button
                className="tautan"
                disabled={tahap.length <= 1}
                onClick={() => setS({ ...s, tahap: tahap.filter((_, j) => j !== i) })}
              >
                hapus
              </button>
            </li>
          ))}
        </ol>
        <button
          className="tombol"
          disabled={tahap.length >= 6}
          onClick={() => setS({ ...s, tahap: [...tahap, { n: 5, arsir: false, diagonal: false, level: "sedang" }] })}
        >
          + Tambah papan
        </button>
        <p className="kecil" style={{ marginTop: ".6rem" }}>
          Game ke-1 memakai papan 1, game ke-2 papan 2, dst; bila game lebih banyak dari papan, urutannya mengulang.
          Usulan waktu satu set: {usulan} menit ({tahap.map((t) => TARGET_MENIT[t.n]).join(" + ")} mnt). Angka ini
          usulan dan belum dikalibrasi dengan anak.
        </p>
        {tahap.some((t) => t.n >= 9) && (
          <p className="peringatan">Papan 9×9 ke atas lebih nyaman di tablet atau Chromebook.</p>
        )}
      </section>
      <section className="blok pink">
        <h2>4 · {massal ? "Arena" : "Pertandingan"}</h2>
        {!massal && (
          <div className="baris">
            <label>Pemain per laga</label>
            {[2, 3].map((n) => (
              <label key={n} className="pilih">
                <input
                  type="radio"
                  name="uk"
                  checked={s.ukuranPertandingan === n}
                  onChange={() => setS({ ...s, ukuranPertandingan: n })}
                />{" "}
                {n} pemain
              </label>
            ))}
          </div>
        )}
        <div className="baris">
          <label>{massal ? "Jumlah game (semua dimainkan)" : "Format"}</label>
          {[1, 3, 5].map((n) => (
            <label key={n} className="pilih">
              <input
                type="radio"
                name="bo"
                checked={s.bestOf === n}
                onChange={() => setS({ ...s, bestOf: n as 1 | 3 | 5 })}
              />{" "}
              {massal ? `${n} game` : n === 1 ? "1 game" : `terbaik dari ${n}`}
            </label>
          ))}
        </div>
        <div className="baris">
          <label htmlFor="ppg">Papan per game</label>
          <select
            id="ppg"
            aria-label="Papan per game"
            value={s.papanPerGame ?? 3}
            onChange={(e) => setS({ ...s, papanPerGame: Number(e.target.value) })}
          >
            {[1, 2, 3, 4, 5, 6].map((n) => (
              <option key={n} value={n}>
                {n} papan
              </option>
            ))}
          </select>
          <span className="kecil">
            Selesai satu papan, pemain langsung lanjut ke papan berikutnya tanpa menunggu lawan.
          </span>
        </div>
        {massal && (
          <div className="baris">
            <label>Sorotan bergilir tiap</label>
            <select value={s.sorotDetik ?? 5} onChange={(e) => setS({ ...s, sorotDetik: Number(e.target.value) })}>
              {[3, 5, 8, 10, 15].map((d) => (
                <option key={d} value={d}>
                  {d} detik
                </option>
              ))}
            </select>
          </div>
        )}
        <div className="baris">
          <label>Batas waktu per game</label>
          <select
            value={s.batasWaktuDetik ?? 0}
            onChange={(e) => setS({ ...s, batasWaktuDetik: Number(e.target.value) || null })}
          >
            <option value={0}>otomatis (usulan × 1,5)</option>
            {[60, 120, 180, 300, 600, 900].map((d) => (
              <option key={d} value={d}>
                {d / 60} menit
              </option>
            ))}
          </select>
        </div>
        <div className="baris">
          <label>Bantuan</label>
          <label className="pilih">
            <input
              type="checkbox"
              checked={s.bantuan?.aktif ?? true}
              onChange={(e) => setS({ ...s, bantuan: { ...(s.bantuan ?? {}), aktif: e.target.checked } })}
            />{" "}
            aktif (1 per papan, penalti 30 detik)
          </label>
        </div>
      </section>
      {!massal && (
        <section className="blok">
          <h2>5 · Kamera dan penonton</h2>
          <p className="kecil">
            Kamera pemain bisa ditonton di layar siaran dan OBS. Gambar tidak direkam atau disimpan server; hanya
            diteruskan langsung dari HP pemain (WebRTC). Bawaan: kamera mati.
          </p>
          <div className="baris">
            <label>Kamera</label>
            <label className="pilih">
              <input
                type="radio"
                name="kam"
                checked={kam.mode !== "opsional"}
                onChange={() => setS({ ...s, kamera: { ...kam, mode: "mati" } })}
              />{" "}
              mati
            </label>
            <label className="pilih">
              <input
                type="radio"
                name="kam"
                checked={kam.mode === "opsional"}
                onChange={() => setS({ ...s, kamera: { ...kam, mode: "opsional" } })}
              />{" "}
              opsional (pemain memilih sendiri)
            </label>
          </div>
          {kam.mode === "opsional" && (
            <>
              <label className="pilih blok-cek">
                <input
                  type="checkbox"
                  checked={!!kam.izinOrtuDikonfirmasi}
                  onChange={(e) => setS({ ...s, kamera: { ...kam, izinOrtuDikonfirmasi: e.target.checked } })}
                />{" "}
                Saya menyatakan izin orang tua/wali murid untuk kamera sudah ada.
              </label>
              <label className="pilih blok-cek">
                <input
                  type="checkbox"
                  checked={kam.persetujuanGuru !== false}
                  onChange={(e) => setS({ ...s, kamera: { ...kam, persetujuanGuru: e.target.checked } })}
                />{" "}
                Guru menyetujui kamera tiap murid satu per satu
              </label>
              <label className="pilih blok-cek">
                <input
                  type="checkbox"
                  checked={!!kam.mikrofon}
                  onChange={(e) => setS({ ...s, kamera: { ...kam, mikrofon: e.target.checked } })}
                />{" "}
                Izinkan mikrofon (tetap mati kecuali murid menyalakan)
              </label>
              <div className="baris">
                <label>Siapa boleh melihat kamera</label>
                <select
                  value={kam.siapaBolehLihat ?? "operator-obs"}
                  onChange={(e) =>
                    setS({ ...s, kamera: { ...kam, siapaBolehLihat: e.target.value as "operator-obs" | "semua" } })
                  }
                >
                  <option value="operator-obs">hanya guru dan layar OBS</option>
                  <option value="semua">semua penonton /watch</option>
                </select>
              </div>
            </>
          )}
        </section>
      )}
      <section className="blok hijau">
        <h2>{massal ? "5" : "6"} · Daftar murid</h2>
        {konteks.roster.length ? (
          <p>{konteks.roster.length} murid dari SIMPETERI. Murid memilih namanya sendiri dari daftar.</p>
        ) : (
          <>
            <textarea
              rows={5}
              value={teks}
              onChange={(e) => setTeks(e.target.value)}
              placeholder="Opsional. Satu nama per baris. Kosongkan bila murid boleh mengetik namanya sendiri."
            />
            <p className="kecil">
              {roster.length ? `${roster.length} nama.` : "Tanpa daftar: murid mengetik nama sendiri."}
            </p>
          </>
        )}
      </section>
      {!v.ok && (
        <ul className="galat-daftar">
          {v.errors.map((e) => (
            <li key={e}>{e}</li>
          ))}
        </ul>
      )}
      {galat && (
        <p className="galat" role="alert">
          {galat}
        </p>
      )}
      <button
        className="tombol utama besar"
        disabled={!v.ok || sibuk || konteks.pin.length < 4}
        onClick={() => void buat()}
      >
        {sibuk ? "Membuat…" : "Buat sesi dan tampilkan PIN"}
      </button>
    </main>
  );
}

// ------------------------------------------------------------------ konsol dengan menu samping
type Menu = "beranda" | "murid" | "laga" | "peringkat" | "hasil" | "siaran";
const MENU: { k: Menu; nama: string; ikon: string; warna: string }[] = [
  { k: "beranda", nama: "Beranda", ikon: "◆", warna: "" },
  { k: "murid", nama: "Murid", ikon: "☻", warna: "a" },
  { k: "laga", nama: "Pertandingan", ikon: "⚔", warna: "b" },
  { k: "peringkat", nama: "Peringkat", ikon: "▲", warna: "c" },
  { k: "hasil", nama: "Hasil", ikon: "✓", warna: "d" },
  { k: "siaran", nama: "Siaran", ikon: "●", warna: "a" },
];

type Aksi = (
  ev: string,
  p?: Record<string, unknown>,
) => Promise<{ ok: boolean; alasan?: string } & Record<string, unknown>>;

function Konsol({
  sock,
  sesi,
  konteks,
}: {
  sock: Socket;
  sesi: { id: string; pin: string; obsKey: string };
  konteks: Konteks;
}) {
  const st = useLive((s) => s.state);
  const ex = useLive((s) => s.extra);
  const [menu, setMenu] = useState<Menu>("beranda");
  const [pesan, setPesan] = useState("");
  const [stat, setStat] = useState<Statistik | null>(null);
  useEffect(() => {
    void tanya(sock, "lr:tonton");
  }, [sock]);
  // statistik diperbarui tiap 3 detik selama sesi terbuka (murah: dihitung dari log memori)
  useEffect(() => {
    let batal = false;
    const ambil = () =>
      void tanya<{ ok: boolean; statistik: Statistik }>(sock, "host:statistik").then(
        (r) => !batal && r.ok && setStat(r.statistik),
      );
    ambil();
    const id = setInterval(ambil, 3000);
    return () => {
      batal = true;
      clearInterval(id);
    };
  }, [sock]);
  const aksi: Aksi = async (ev, p = {}) => {
    const r = await tanya<{ ok: boolean; alasan?: string } & Record<string, unknown>>(sock, ev, p);
    setPesan(r.ok ? "" : (r.alasan ?? "Gagal."));
    return r;
  };
  if (!st)
    return (
      <main className="tengah">
        <p>Memuat sesi…</p>
      </main>
    );
  const massal = st.settings.format === "massal";
  const menit = pilihMatch(st);
  return (
    <div className="host">
      <nav className="host-menu" aria-label="Menu guru">
        <div className="host-merek">
          <Permata /> Logic Rush
        </div>
        {MENU.map((m) => (
          <button
            key={m.k}
            className="item"
            aria-current={menu === m.k ? "page" : undefined}
            onClick={() => setMenu(m.k)}
          >
            <span className={`ikon ${m.warna}`} aria-hidden="true">
              {m.ikon}
            </span>
            {m.nama}
            {m.k === "murid" && <span className="lencana">{st.pemain.length}</span>}
            {m.k === "siaran" && ex && ex.kameraMinta.length > 0 && (
              <span className="lencana koral">{ex.kameraMinta.length}</span>
            )}
          </button>
        ))}
        <div className="spasi" />
        <div className="host-pinkecil">
          PIN kelas<b>{sesi.pin}</b>
        </div>
      </nav>
      <main className="host-isi" key={menu}>
        {pesan && (
          <p className="galat" role="alert">
            {pesan}
          </p>
        )}
        {menu === "beranda" && (
          <Beranda sock={sock} sesi={sesi} konteks={konteks} stat={stat} aksi={aksi} setMenu={setMenu} />
        )}
        {menu === "murid" && <Murid massal={massal} aksi={aksi} />}
        {menu === "laga" && <Laga aksi={aksi} />}
        {menu === "peringkat" && (
          <>
            <h1>Peringkat</h1>
            <div className="dua-kolom">
              <section className="blok">
                <h2>Papan peringkat langsung</h2>
                {menit ? (
                  <LiveRank match={menit} state={st} maksTinggi={massal ? 620 : undefined} tinggi={massal ? 40 : 46} />
                ) : (
                  <p className="kosong">Belum ada pertandingan. Peringkat langsung muncul begitu game dimulai.</p>
                )}
              </section>
              <section className="blok hijau">
                <h2>Klasemen sementara</h2>
                <Klasemen state={st} />
              </section>
            </div>
          </>
        )}
        {menu === "hasil" && <Hasil stat={stat} sesi={sesi} pin={konteks.pin} />}
        {menu === "siaran" && <Siaran sock={sock} sesi={sesi} aksi={aksi} />}
      </main>
    </div>
  );
}

function Beranda({
  sock: _sock,
  sesi,
  konteks,
  stat,
  aksi,
  setMenu,
}: {
  sock: Socket;
  sesi: { id: string; pin: string; obsKey: string };
  konteks: Konteks;
  stat: Statistik | null;
  aksi: Aksi;
  setMenu: (m: Menu) => void;
}) {
  const st = useLive((s) => s.state);
  const [qr, setQr] = useState("");
  const asal = location.origin + BASE;
  const urlMurid = `${asal}/?pin=${sesi.pin}`;
  useEffect(() => {
    void QRCode.toDataURL(urlMurid, { margin: 1, width: 200, color: { dark: "#2b1d12", light: "#fff6dc" } }).then(
      setQr,
    );
  }, [urlMurid]);
  if (!st) return null;
  const selesaiLaga = st.matches.filter((m) => m.status === "selesai").length;
  const aktif = st.matches.find((m) => m.id === st.aktif);
  const kembaliUrl = konteks.kembali && konteks.asal ? buildKembaliUrl(konteks.kembali, konteks.asal, sesi.id) : null;
  return (
    <>
      <h1>Beranda</h1>
      <section className="kartu-pin">
        <div>
          <p className="kecil" style={{ color: "var(--tinta)" }}>
            PIN kelas — {st.settings.nama}
          </p>
          <div className="pin-besar" aria-label={`PIN ${sesi.pin.split("").join(" ")}`}>
            {sesi.pin}
          </div>
          <p style={{ marginTop: ".6rem", fontWeight: 600 }}>
            Murid buka alamat server ini lalu ketik PIN, atau pindai QR.
          </p>
        </div>
        {qr && <img src={qr} alt="QR gabung" width={130} height={130} />}
        <div className="tautan-blok">
          <a className="tombol" href={url(`/watch?pin=${sesi.pin}`)} target="_blank" rel="noreferrer">
            Buka layar /watch
          </a>
          <input
            readOnly
            aria-label="Alamat OBS Browser Source"
            data-testid="url-obs"
            className="url-obs"
            value={`${asal}/obs?pin=${sesi.pin}&key=${sesi.obsKey}&layout=duel&cam=on`}
            onFocus={(e) => e.currentTarget.select()}
          />
        </div>
      </section>
      <div className="ubin-ringkas">
        <div className="angka matahari">
          <b>{st.pemain.length}</b>
          <span>murid masuk</span>
        </div>
        <div className="angka mint">
          <b>{st.pemain.filter((p) => p.terhubung).length}</b>
          <span>terhubung</span>
        </div>
        <div className="angka pink">
          <b>{selesaiLaga}</b>
          <span>{st.settings.format === "massal" ? "arena selesai" : "laga selesai"}</span>
        </div>
        <div className="angka">
          <b>{stat?.validasi.total ?? 0}</b>
          <span>validasi jawaban</span>
        </div>
      </div>
      <section className="blok jeruk">
        <h2>Sedang berlangsung</h2>
        {aktif ? (
          <>
            <p>
              <b>
                {aktif.massal
                  ? `Arena massal (${aktif.pemain.length} pemain)`
                  : `Babak ${aktif.babak} · Laga ${aktif.nomor}`}
              </b>{" "}
              · {aktif.status}
              {aktif.game ? ` · game ${aktif.game.no}` : ""}
            </p>
            <LiveRank
              match={aktif}
              state={st}
              tinggi={aktif.massal ? 36 : 46}
              maksTinggi={aktif.massal ? 320 : undefined}
            />
          </>
        ) : (
          <p className="kosong">
            Belum ada yang bermain. Langkah berikutnya:{" "}
            <button className="tautan" onClick={() => setMenu("murid")}>
              pilih murid
            </button>{" "}
            lalu{" "}
            <button className="tautan" onClick={() => setMenu("laga")}>
              panggil pertandingan
            </button>
            .
          </p>
        )}
      </section>
      <div className="konsol-kaki">
        <button
          className="tombol utama"
          onClick={() =>
            confirm("Akhiri sesi? Pertandingan yang berjalan dibatalkan.") && void aksi("host:selesai-sesi")
          }
          disabled={st.sesi.status === "selesai"}
        >
          Akhiri sesi
        </button>
        {st.sesi.status === "selesai" && kembaliUrl && (
          <a className="tombol mint" href={kembaliUrl}>
            Kembali ke SIMPETERI dan impor hasil
          </a>
        )}
        {st.sesi.status === "selesai" && !kembaliUrl && (
          <span className="kecil">Sesi selesai. Ringkasan: /api/sessions/{sesi.id}/summary.json</span>
        )}
      </div>
    </>
  );
}

function Murid({ massal, aksi }: { massal: boolean; aksi: Aksi }) {
  const st = useLive((s) => s.state);
  const ex = useLive((s) => s.extra);
  const [pilih, setPilih] = useState<string[]>([]);
  if (!st) return null;
  const tersedia = st.pemain.filter(
    (p) => !st.matches.some((m) => m.pemain.includes(p.id) && !["selesai", "batal"].includes(m.status)),
  );
  return (
    <>
      <h1>Murid ({st.pemain.length})</h1>
      <section className="blok">
        <h2>Daftar</h2>
        {st.pemain.length === 0 && <p className="kosong">Belum ada yang masuk. Bagikan PIN dari Beranda.</p>}
        <ul className="murid">
          {st.pemain.map((p) => {
            const minta = ex?.kameraMinta.includes(p.id);
            const dalam = !tersedia.includes(p);
            return (
              <li key={p.id} className={p.terhubung ? "" : "putus"}>
                <label className="pilih">
                  <input
                    type="checkbox"
                    disabled={dalam || massal}
                    checked={pilih.includes(p.id)}
                    onChange={(e) =>
                      setPilih(e.target.checked ? [...pilih, p.id].slice(-3) : pilih.filter((x) => x !== p.id))
                    }
                  />
                  <span>
                    {p.absen ? `${p.absen}. ` : ""}
                    {p.nama}
                  </span>
                </label>
                <span className="status-kecil">
                  {p.terhubung ? "" : "terputus"}
                  {p.kamera === "menyala" ? " · kamera" : ""}
                </span>
                {minta && (
                  <span className="minta-izin">
                    minta kamera
                    <button className="tautan" onClick={() => void aksi("host:kamera-izin", { pid: p.id, izin: true })}>
                      izinkan
                    </button>
                    <button
                      className="tautan"
                      onClick={() => void aksi("host:kamera-izin", { pid: p.id, izin: false })}
                    >
                      tolak
                    </button>
                  </span>
                )}
                <button
                  className="tautan"
                  onClick={() => confirm(`Keluarkan ${p.nama}?`) && void aksi("host:kick", { pid: p.id })}
                >
                  keluarkan
                </button>
              </li>
            );
          })}
        </ul>
        {massal ? (
          <div className="aksi-baris">
            <button className="tombol utama" disabled={tersedia.length < 4} onClick={() => void aksi("host:antrean")}>
              Siapkan arena massal ({tersedia.length} pemain)
            </button>
            {tersedia.length < 4 && <span className="kecil">Butuh minimal 4 pemain.</span>}
          </div>
        ) : (
          <div className="aksi-baris">
            <button
              className="tombol"
              disabled={pilih.length < 2}
              onClick={() => void aksi("host:match-buat", { pids: pilih }).then((r) => r.ok && setPilih([]))}
            >
              Buat pertandingan dari yang dicentang
            </button>
            <button
              className="tombol matahari"
              disabled={tersedia.length < 2}
              onClick={() => void aksi("host:antrean")}
            >
              Antrean otomatis ({st.settings.ukuranPertandingan} per laga)
            </button>
          </div>
        )}
      </section>
    </>
  );
}

function Laga({ aksi }: { aksi: Aksi }) {
  const st = useLive((s) => s.state);
  if (!st) return null;
  const nama = (id: string) => st.pemain.find((p) => p.id === id)?.nama ?? "?";
  const adaAktif = !!st.aktif;
  const selesaiSemua = st.matches.length > 0 && st.matches.every((m) => ["selesai", "batal"].includes(m.status));
  const massal = st.settings.format === "massal";
  return (
    <>
      <h1>{massal ? "Arena" : "Pertandingan"}</h1>
      <section className="blok">
        <h2>{massal ? "Arena massal" : "Antrean dan babak"}</h2>
        {st.matches.length === 0 && (
          <p className="kosong">
            {massal
              ? "Belum ada arena. Buka menu Murid lalu siapkan arena massal."
              : "Belum ada pertandingan. Centang 2–3 murid di menu Murid, atau pakai antrean otomatis."}
          </p>
        )}
        <ul className="laga">
          {st.matches.map((m) => (
            <BarisLaga key={m.id} m={m} nama={nama} aksi={aksi} adaAktif={adaAktif} />
          ))}
        </ul>
        <div className="aksi-baris">
          {!massal && (
            <button
              className="tombol"
              disabled={!selesaiSemua}
              onClick={() =>
                void aksi("host:babak-berikut").then((r) => {
                  if (typeof r.juara === "string") alert(`Juara kelas: ${nama(r.juara)}`);
                })
              }
            >
              Babak berikutnya
            </button>
          )}
          <button
            className="tombol"
            disabled={!adaAktif}
            onClick={() => void aksi("host:jeda", { on: !st.matches.find((m) => m.id === st.aktif)?.jeda })}
          >
            Jeda / lanjutkan
          </button>
        </div>
      </section>
    </>
  );
}

function BarisLaga({
  m,
  nama,
  aksi,
  adaAktif,
}: {
  m: MatchPublik;
  nama: (id: string) => string;
  aksi: Aksi;
  adaAktif: boolean;
}) {
  const label: Record<string, string> = {
    antre: "antre",
    siap: "menunggu siap",
    hitung: "hitung mundur",
    main: "bermain",
    rehat: "rehat",
    selesai: "selesai",
    batal: "dibatalkan",
  };
  const judul = m.massal ? `Arena massal · ${m.pemain.length} pemain` : `Babak ${m.babak} · Laga ${m.nomor}`;
  return (
    <li className={`laga-${m.status}`}>
      <div>
        <b>{judul}</b> {m.massal ? "" : m.pemain.map(nama).join(" × ")}
        <small>
          {" "}
          {label[m.status]}
          {m.game ? ` · game ${m.game.no}` : ""}
          {m.massal
            ? ` · ${m.games.length}/${m.bestOf} game`
            : ` · ${m.pemain.map((p) => `${m.menang[p] ?? 0}`).join("-")} (perlu ${m.perluMenang})`}
        </small>
        {m.status === "siap" && (
          <small>
            {" "}
            · siap: {m.pemain.filter((p) => m.siap[p]).length}/{m.pemain.length}
          </small>
        )}
        {m.status === "selesai" && <small> · {m.seri ? "seri" : `menang: ${nama(m.pemenang ?? "")}`}</small>}
      </div>
      <div className="aksi-baris">
        {m.status === "antre" && (
          <button
            className="tombol matahari"
            disabled={adaAktif}
            onClick={() => void aksi("host:panggil", { mid: m.id })}
          >
            Panggil
          </button>
        )}
        {m.status === "siap" && (
          <>
            <button className="tombol utama" onClick={() => void aksi("host:mulai", { mid: m.id })}>
              Mulai
            </button>
            <button
              className="tautan"
              onClick={() =>
                confirm("Mulai walau belum semua siap?") && void aksi("host:mulai", { mid: m.id, paksa: true })
              }
            >
              paksa
            </button>
          </>
        )}
        {m.status === "main" && (
          <button className="tombol" onClick={() => void aksi("host:akhiri-game", { mid: m.id })}>
            Akhiri game
          </button>
        )}
        {m.status === "rehat" && (
          <button className="tombol" onClick={() => void aksi("host:lanjut", { mid: m.id })}>
            Lanjut sekarang
          </button>
        )}
        {m.status === "selesai" && m.seri && (
          <button className="tombol" onClick={() => void aksi("host:game-tambahan", { mid: m.id })}>
            Game tambahan
          </button>
        )}
        {!["selesai", "batal"].includes(m.status) && (
          <button className="tautan" onClick={() => confirm("Batalkan ini?") && void aksi("host:batal", { mid: m.id })}>
            batal
          </button>
        )}
      </div>
    </li>
  );
}

const fmtDtk = (ms: number | null): string => (ms === null ? "-" : `${(ms / 1000).toFixed(1)} dtk`);

function Hasil({ stat, sesi, pin }: { stat: Statistik | null; sesi: { id: string }; pin: string }) {
  const st = useLive((s) => s.state);
  const unduh = async (jalur: string, nama: string) => {
    const r = await fetch(url(`/api/sessions/${sesi.id}/${jalur}`), { headers: { "x-host-token": pin } });
    const b = await r.blob();
    const a = document.createElement("a");
    a.href = URL.createObjectURL(b);
    a.download = nama;
    a.click();
  };
  if (!st) return null;
  const v = stat?.validasi ?? { total: 0, benar: 0, salah: 0 };
  const akurasi = v.total ? Math.round((v.benar / v.total) * 100) : 0;
  return (
    <>
      <h1>Hasil</h1>
      <div className="ubin-ringkas">
        <div className="angka matahari">
          <b>{v.total}</b>
          <span>validasi keseluruhan</span>
        </div>
        <div className="angka mint">
          <b>{v.benar}</b>
          <span>validasi benar</span>
        </div>
        <div className="angka koral">
          <b>{v.salah}</b>
          <span>validasi salah</span>
        </div>
        <div className="angka pink">
          <b>{akurasi}%</b>
          <span>ketepatan</span>
        </div>
      </div>
      <section className="blok jeruk">
        <h2>Validasi dan jawaban per papan</h2>
        {!stat || stat.papan.length === 0 ? (
          <p className="kosong">Belum ada papan yang selesai dimainkan. Statistik terisi setelah satu game berakhir.</p>
        ) : (
          <div className="gulir-x">
            <table className="tabel-stat">
              <thead>
                <tr>
                  <th>Papan</th>
                  <th>Ukuran</th>
                  <th>Pemain</th>
                  <th>Selesai</th>
                  <th>Validasi</th>
                  <th>Benar</th>
                  <th>Salah</th>
                  <th>Ketepatan</th>
                  <th>Median</th>
                  <th>Tercepat</th>
                  <th>Bantuan</th>
                </tr>
              </thead>
              <tbody>
                {stat.papan.map((p) => {
                  const pct = p.validasi ? Math.round((p.benar / p.validasi) * 100) : 0;
                  return (
                    <tr key={`${p.matchId}-${p.gameNo}`}>
                      <td>
                        {p.matchId === ""
                          ? ""
                          : `${st.matches.find((m) => m.id === p.matchId)?.massal ? "Arena" : `B${p.babak}·L${p.laga}`} · game ${p.gameNo} · papan ${p.boardNo}`}
                        <br />
                        <small>{p.papan.length > 2 ? `${p.papan.length} papan dasar` : p.papan.join(", ")}</small>
                      </td>
                      <td>
                        {p.n}×{p.n}
                        {p.arsir ? " · arsir" : ""}
                        {p.diagonal ? " · miring" : ""}
                      </td>
                      <td className="angka-k">{p.pemain}</td>
                      <td className="angka-k">{p.selesai}</td>
                      <td className="angka-k">{p.validasi}</td>
                      <td className="angka-k">{p.benar}</td>
                      <td className="angka-k">{p.salah}</td>
                      <td>
                        <span className="batang" title={`${pct}%`}>
                          <i style={{ width: `${pct}%` }} />
                        </span>{" "}
                        {pct}%
                      </td>
                      <td className="angka-k">{fmtDtk(p.waktuMedianMs)}</td>
                      <td className="angka-k">{fmtDtk(p.waktuTercepatMs)}</td>
                      <td className="angka-k">{p.bantuan}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>
      <div className="dua-kolom">
        <section className="blok pink">
          <h2>Statistik menjawab per murid</h2>
          {!stat || stat.pemain.length === 0 ? (
            <p className="kosong">Belum ada murid yang menjawab.</p>
          ) : (
            <div className="gulir-x">
              <table className="tabel-stat">
                <thead>
                  <tr>
                    <th>Murid</th>
                    <th>Game</th>
                    <th>Selesai</th>
                    <th>Validasi</th>
                    <th>Benar</th>
                    <th>Salah</th>
                  </tr>
                </thead>
                <tbody>
                  {stat.pemain.map((p) => (
                    <tr key={p.pid}>
                      <td>{p.nama}</td>
                      <td className="angka-k">{p.game}</td>
                      <td className="angka-k">{p.selesai}</td>
                      <td className="angka-k">{p.validasi}</td>
                      <td className="angka-k">{p.benar}</td>
                      <td className="angka-k">{p.salah}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </section>
        <section className="blok hijau">
          <h2>Klasemen akhir</h2>
          <Klasemen state={st} />
        </section>
      </div>
      <div className="aksi-baris">
        <button className="tombol" onClick={() => void unduh("results.csv", `logic-rush-${sesi.id}.csv`)}>
          Unduh hasil (CSV)
        </button>
        <button className="tombol" onClick={() => void unduh("statistik.json", `logic-rush-${sesi.id}-statistik.json`)}>
          Unduh statistik (JSON)
        </button>
        <button
          className="tombol"
          onClick={() => void unduh("summary.json?includeTest=1", `logic-rush-${sesi.id}-summary.json`)}
        >
          Unduh ringkasan Hall of Fame (JSON)
        </button>
      </div>
    </>
  );
}

function Siaran({ sock, sesi, aksi }: { sock: Socket; sesi: { pin: string; obsKey: string }; aksi: Aksi }) {
  const st = useLive((s) => s.state);
  const ex = useLive((s) => s.extra);
  if (!st) return null;
  const asal = location.origin + BASE;
  const massal = st.settings.format === "massal";
  const urlObs = (layout: string) =>
    `${asal}/obs?pin=${sesi.pin}&key=${sesi.obsKey}&layout=${layout}&cam=${massal ? "off" : "on"}`;
  const salin = (u: string) => void navigator.clipboard.writeText(u);
  return (
    <>
      <h1>Siaran</h1>
      <div className="dua-kolom">
        <section className="blok pink">
          <h2>Tautan siaran</h2>
          <div className="aksi-baris">
            <button className="tombol" onClick={() => salin(`${asal}/watch?pin=${sesi.pin}`)}>
              Salin /watch
            </button>
            {massal ? (
              <button className="tombol" onClick={() => salin(urlObs("auto"))}>
                Salin OBS (arena)
              </button>
            ) : (
              <>
                <button className="tombol" onClick={() => salin(urlObs("duel"))}>
                  Salin OBS (duel)
                </button>
                <button className="tombol" onClick={() => salin(urlObs("trio"))}>
                  Salin OBS (trio)
                </button>
              </>
            )}
          </div>
          <p className="kecil" style={{ marginTop: ".6rem" }}>
            Di OBS Studio: Sumber → Browser → tempel tautan, lebar 1920, tinggi 1080. Latar transparan; tambahkan{" "}
            <code>&chroma=00ff00</code> untuk latar hijau. Tautan memuat kunci OBS, jangan dibagikan ke murid.
          </p>
        </section>
        <section className="blok">
          <h2>Kamera</h2>
          {massal ? (
            <p>
              Format massal tidak memakai kamera atau RTC. Penonton melihat papan peringkat langsung dan sorotan
              bergilir.
            </p>
          ) : st.settings.kamera.mode === "mati" ? (
            <p>Kamera dimatikan untuk sesi ini.</p>
          ) : (
            <ul className="murid">
              {st.pemain.map((p) => (
                <li key={p.id}>
                  <span className="pilih">
                    <span>{p.nama}</span>
                  </span>
                  <span className="status-kecil">
                    {p.kamera}
                    {ex && ex.penontonVideo[p.id] ? ` · ${ex.penontonVideo[p.id]} penonton` : ""}
                  </span>
                  {p.kamera === "meminta" && (
                    <button className="tautan" onClick={() => void aksi("host:kamera-izin", { pid: p.id, izin: true })}>
                      izinkan
                    </button>
                  )}
                  {(p.kamera === "diizinkan" || p.kamera === "menyala") && (
                    <button
                      className="tautan"
                      onClick={() => void aksi("host:kamera-izin", { pid: p.id, izin: false })}
                    >
                      cabut
                    </button>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>
      <section className="blok jeruk">
        <h2>Pratinjau siaran</h2>
        <Mozaik sock={sock} cam={!massal} />
      </section>
    </>
  );
}

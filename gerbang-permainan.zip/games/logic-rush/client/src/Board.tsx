import { useMemo } from "react";
import type { CSSProperties } from "react";
import { check } from "@logic-rush/shared";
import type { Cell, PublicBoard } from "@logic-rush/shared";

/** 10 zona: Okabe–Ito + 2 tambahan, dipasangkan dengan huruf A–J dan arsir miring (tak bergantung warna saja). */
export const ZONA: [bg: string, fg: string][] = [
  ["#ffb703", "#2b1d12"],
  ["#7fd6e8", "#2b1d12"],
  ["#52d681", "#2b1d12"],
  ["#fff06b", "#2b1d12"],
  ["#ff8a5b", "#2b1d12"],
  ["#ff7aa8", "#2b1d12"],
  ["#c8e36b", "#2b1d12"],
  ["#ffd2a1", "#2b1d12"],
  ["#3fd0c9", "#2b1d12"],
  ["#e6d9c3", "#2b1d12"],
];
export const HURUF = "ABCDEFGHIJ";

export function Permata({ kecil = false }: { kecil?: boolean }) {
  return (
    <svg viewBox="0 0 32 32" className={kecil ? "permata kecil" : "permata"} aria-hidden="true">
      <path d="M16 3 27 11 16 29 5 11Z" fill="#fffdf6" stroke="#2b1d12" strokeWidth="1.8" strokeLinejoin="round" />
      <path
        d="M5 11h22M11 11 16 3l5 8M11 11l5 18 5-18"
        fill="none"
        stroke="#2b1d12"
        strokeWidth="1.1"
        strokeLinejoin="round"
      />
      <path d="M16 3 11 11h10Z" fill="#ffd0e4" />
    </svg>
  );
}

export interface BoardProps {
  board: PublicBoard;
  gems: Cell[];
  xs?: Cell[];
  locked?: string[];
  /** kotak yang baru ditaruh (disorot) */
  last?: Cell | null;
  trail?: Cell[];
  onTap?: (r: number, c: number) => void;
  /** sisi satu kotak (px); bila kosong ukuran mengikuti lebar induk */
  sisi?: number;
  /** tampilkan garis/kotak pelanggaran */
  tunjukkanPelanggaran?: boolean;
  nama?: string;
  mini?: boolean;
}

export function Board({
  board,
  gems,
  xs = [],
  locked = [],
  last,
  trail = [],
  onTap,
  sisi,
  tunjukkanPelanggaran = true,
  mini,
}: BoardProps) {
  const n = board.n;
  const gemSet = useMemo(() => new Set(gems.map((g) => `${g.r},${g.c}`)), [gems]);
  const xSet = useMemo(() => new Set(xs.map((g) => `${g.r},${g.c}`)), [xs]);
  const lockSet = useMemo(() => new Set(locked), [locked]);
  const chk = useMemo(() => check(board, gems), [board, gems]);
  const salah = useMemo(() => {
    const s = new Map<string, string[]>();
    if (!tunjukkanPelanggaran) return s;
    for (const c of chk.conflicts)
      for (const g of [c.a, c.b]) s.set(`${g.r},${g.c}`, [...(s.get(`${g.r},${g.c}`) ?? []), ...c.rules]);
    for (const e of chk.cellErrors) s.set(`${e.r},${e.c}`, ["blocked"]);
    return s;
  }, [chk, tunjukkanPelanggaran]);
  const trailIdx = new Map(trail.map((t, i) => [`${t.r},${t.c}`, i]));
  const style = { "--n": n, ...(sisi ? { width: n * sisi, "--sisi": `${sisi}px` } : {}) } as CSSProperties;
  return (
    <div
      className={`papan${mini ? " mini" : ""}${onTap ? " bisa" : ""}`}
      style={style}
      role="grid"
      aria-label={`Papan ${n} kali ${n}`}
    >
      {board.zones.flatMap((row, r) =>
        row.split("").map((ch, c) => {
          const k = `${r},${c}`;
          const arsir = ch === "#";
          const z = arsir ? -1 : parseInt(ch, 36);
          const [bg, fg] = arsir ? ["#f3e7cc", "#7b705a"] : (ZONA[z] ?? ZONA[7]);
          const ada = gemSet.has(k);
          const kunci = lockSet.has(k);
          const baru = last && last.r === r && last.c === c;
          const t = trailIdx.get(k);
          const pel = salah.get(k);
          const cls = [
            "ubin",
            arsir ? "arsir" : "",
            ada ? "ada" : "",
            baru ? "baru" : "",
            pel ? "salah" : "",
            kunci ? "kunci" : "",
            t !== undefined && !baru ? "jejak" : "",
          ]
            .filter(Boolean)
            .join(" ");
          const isi = (
            <>
              {!arsir && <span className="huruf">{HURUF[z]}</span>}
              {xSet.has(k) && !ada && <span className="silang" aria-label="tanda kosong" />}
              {ada && <Permata kecil={mini} />}
              {kunci && <span className="gembok" aria-label="terkunci" />}
              {t !== undefined && !baru && !ada && <span className="titik" style={{ opacity: 0.25 + t * 0.15 }} />}
            </>
          );
          const st = { background: bg, color: fg } as CSSProperties;
          return onTap ? (
            <button
              key={k}
              type="button"
              className={cls}
              style={st}
              disabled={arsir}
              aria-label={`Baris ${r + 1} kolom ${c + 1}${arsir ? ", arsir" : ""}${ada ? ", ada permata" : ""}`}
              onClick={() => onTap(r, c)}
            >
              {isi}
            </button>
          ) : (
            <div key={k} role="gridcell" className={cls} style={st}>
              {isi}
            </div>
          );
        }),
      )}
    </div>
  );
}

// Papan peringkat langsung (naik-turun), klasemen sementara, dan arena massal (sorotan bergilir).
import { useEffect, useMemo, useRef, useState } from "react";
import { peringkatLangsung } from "@logic-rush/shared";
import type { BarisLangsung, MatchPublik, StatePublik } from "@logic-rush/shared";
import { Board } from "./Board";
import { fmtMs, sekarang, useLive } from "./net";

/** Baris papan peringkat untuk satu pertandingan: game berjalan (langsung), atau game terakhir yang selesai. */
export function barisUntuk(match: MatchPublik): { baris: BarisLangsung[]; n: number } {
  if (match.game) {
    return {
      n: match.game.stage.n,
      baris: match.pemain.map((pid) => {
        const l = match.game?.pemain[pid];
        return {
          pid,
          done: l?.papanSelesai ?? 0,
          total: l?.papanTotal ?? 1,
          n: match.game?.stages[Math.min(l?.papanSelesai ?? 0, (match.game?.stages.length ?? 1) - 1)]?.n,
          gems: l?.gems ?? 0,
          selesaiMs: l?.selesaiMs ?? null,
          hints: l?.hints ?? 0,
          pelanggaran: l?.pelanggaran ?? 0,
        };
      }),
    };
  }
  const g = match.games.at(-1);
  return {
    n: g?.stage.n ?? 4,
    baris: match.pemain.map((pid) => {
      const h = g?.hasil.find((x) => x.pid === pid);
      return {
        pid,
        done: h?.done ?? 0,
        total: g?.stages.length ?? 1,
        gems: h?.gems ?? 0,
        selesaiMs: h?.ms ?? null,
        hints: h?.hints ?? 0,
        pelanggaran: 0,
      };
    }),
  };
}

export function LiveRank({
  match,
  state,
  tinggi = 46,
  maksTinggi,
}: {
  match: MatchPublik;
  state: StatePublik;
  tinggi?: number;
  maksTinggi?: number;
}) {
  const { baris, n } = useMemo(() => barisUntuk(match), [match]);
  const urut = useMemo(() => peringkatLangsung(baris), [baris]);
  const posisi = new Map(urut.map((r, i) => [r.pid, i]));
  const nama = new Map(state.pemain.map((p) => [p.id, p.nama]));
  const sebelum = useRef(new Map<string, number>());
  const [ubah, setUbah] = useState<Record<string, { arah: "naik" | "turun"; k: number }>>({});
  const sig = urut.map((r) => `${r.pid}:${r.rank}`).join("|");
  useEffect(() => {
    const baru: Record<string, { arah: "naik" | "turun"; k: number }> = {};
    for (const r of urut) {
      const lama = sebelum.current.get(r.pid);
      if (lama !== undefined && lama !== r.rank)
        baru[r.pid] = { arah: r.rank < lama ? "naik" : "turun", k: Date.now() };
      sebelum.current.set(r.pid, r.rank);
    }
    if (Object.keys(baru).length) setUbah((x) => ({ ...x, ...baru }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sig]);
  const sorot = match.game?.sorotPid ?? null;
  const urutStabil = baris.slice().sort((a, b) => a.pid.localeCompare(b.pid));
  const kotak = (
    <div className="rank" style={{ height: baris.length * (tinggi + 6) }} aria-label="Papan peringkat langsung">
      {urutStabil.map((b) => {
        const r = urut[posisi.get(b.pid) ?? 0];
        const i = posisi.get(b.pid) ?? 0;
        const u = ubah[b.pid];
        const pct =
          b.selesaiMs !== null ? 100 : Math.round(((b.done + b.gems / (b.n ?? n)) / Math.max(1, b.total)) * 100);
        return (
          <div
            key={b.pid}
            className={`rank-baris${r.rank === 1 ? " top1" : r.rank === 2 ? " top2" : r.rank === 3 ? " top3" : ""}${b.selesaiMs !== null ? " tamat" : ""}${sorot === b.pid ? " sorot" : ""}`}
            style={{ height: tinggi, transform: `translateY(${i * (tinggi + 6)}px)` }}
          >
            <span className="rank-no">{r.rank}</span>
            <span className="rank-nama">
              <b>{nama.get(b.pid) ?? "?"}</b>
              <span className="rank-bar" aria-label={`${pct}%`}>
                <i style={{ width: `${pct}%` }} />
              </span>
            </span>
            <span className="rank-info">
              {u && Date.now() - u.k < 2000 && (
                <span key={u.k} className={u.arah === "naik" ? "rank-naik" : "rank-turun"}>
                  {u.arah === "naik" ? "▲ " : "▼ "}
                </span>
              )}
              {b.selesaiMs !== null
                ? fmtMs(b.selesaiMs)
                : b.total > 1
                  ? `P${Math.min(b.done + 1, b.total)}/${b.total} · ${b.gems}/${b.n ?? n}`
                  : `${b.gems}/${n}`}
              {b.pelanggaran > 0 && b.selesaiMs === null ? ` · ${b.pelanggaran}!` : ""}
            </span>
          </div>
        );
      })}
    </div>
  );
  return maksTinggi ? (
    <div className="rank-gulir" style={{ maxHeight: maksTinggi }}>
      {kotak}
    </div>
  ) : (
    kotak
  );
}

/** Klasemen sementara: semua pemain, urut menurut poin. */
export function Klasemen({ state }: { state: StatePublik }) {
  const nama = new Map(state.pemain.map((p) => [p.id, p.nama]));
  const baris = state.skor.length
    ? state.skor
    : state.pemain.map((p) => ({
        pid: p.id,
        skor: 0,
        pertandinganMenang: 0,
        pertandingan: 0,
        gameMenang: 0,
        gameMain: 0,
        kalah: 0,
      }));
  if (!baris.length) return <p className="kosong">Belum ada pemain.</p>;
  return (
    <table className="klasemen">
      <thead>
        <tr>
          <th>#</th>
          <th>Nama</th>
          <th className="num" title="Pertandingan selesai">
            Main
          </th>
          <th className="num" title="Menang pertandingan">
            M
          </th>
          <th className="num" title="Kalah pertandingan">
            K
          </th>
          <th className="num" title="Game dimenangkan">
            Game
          </th>
          <th style={{ textAlign: "right" }}>Poin</th>
        </tr>
      </thead>
      <tbody>
        {baris.map((b, i) => (
          <tr key={b.pid} className={i === 0 ? "p1" : i === 1 ? "p2" : i === 2 ? "p3" : ""}>
            <td>{i + 1}</td>
            <td className="nama">{nama.get(b.pid) ?? "?"}</td>
            <td className="num">{b.pertandingan}</td>
            <td className="num">{b.pertandinganMenang}</td>
            <td className="num">{b.kalah}</td>
            <td className="num">{b.gameMenang}</td>
            <td>{b.skor}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

/** Format massal (di atas 3 pemain): tanpa kamera/RTC. Satu pemain disorot bergantian + papan peringkat langsung. */
export function Arena({ match, state, now }: { match: MatchPublik; state: StatePublik; now: number }) {
  const tayang = useLive((s) => s.tayang);
  const g = match.game;
  const sorot = g?.sorotPid ?? null;
  const t = sorot ? tayang[sorot] : undefined;
  const nama = state.pemain.find((p) => p.id === sorot)?.nama ?? "";
  const dur = state.settings.sorotDetik * 1000;
  const sisa = g?.sorotSampaiTs ? Math.max(0, g.sorotSampaiTs - now) : 0;
  const live = sorot ? g?.pemain[sorot] : undefined;
  const aktif = match.status === "main";
  return (
    <div className="arena">
      <section className="sorot" aria-live="polite">
        <div className="sorot-kepala">
          <span className="lencana koral langsung">SOROTAN</span>
          <span className="kecil">ganti tiap {state.settings.sorotDetik} detik</span>
        </div>
        {aktif && sorot ? (
          <>
            <div key={sorot} className="sorot-nama">
              {nama}
            </div>
            <div className="sorot-waktu" aria-hidden="true">
              <i style={{ width: `${Math.min(100, (sisa / dur) * 100)}%` }} />
            </div>
            {t?.view.board ? (
              <Board
                board={t.view.board}
                gems={t.view.gems}
                xs={t.view.xs}
                locked={t.view.locked}
                last={t.last && sekarang() - t.lastAt < 2500 ? t.last : null}
                trail={t.trail}
                mini
              />
            ) : (
              <div className="papan-menunggu">menunggu papan…</div>
            )}
            <div className="sorot-kaki">
              <span>
                <b>{live?.gems ?? 0}</b>/{g?.stage.n} permata
              </span>
              {(live?.pelanggaran ?? 0) > 0 && (
                <span style={{ color: "var(--aksen-tua)" }}>{live?.pelanggaran} bentrok</span>
              )}
              {(live?.hints ?? 0) > 0 && <span>bantuan ×{live?.hints}</span>}
            </div>
          </>
        ) : (
          <div className="sorot-kosong">
            {match.status === "selesai"
              ? "Arena selesai. Lihat papan peringkat."
              : aktif
                ? "Semua pemain sudah selesai."
                : "Sorotan mulai setelah hitung mundur."}
          </div>
        )}
      </section>
      <section>
        <LiveRank match={match} state={state} tinggi={40} maksTinggi={640} />
      </section>
    </div>
  );
}

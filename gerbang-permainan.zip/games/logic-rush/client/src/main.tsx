import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Host } from "./Host";
import { BASE } from "./url";
import { Play } from "./Play";
import { Obs, Watch } from "./Siaran";
import "./styles.css";

createRoot(document.getElementById("root") as HTMLElement).render(
  <StrictMode>
    <BrowserRouter basename={BASE || undefined}>
      <Routes>
        <Route path="/" element={<Play />} />
        <Route path="/host" element={<Host />} />
        <Route path="/operator" element={<Host />} />
        <Route path="/watch" element={<Watch />} />
        <Route path="/obs" element={<Obs />} />
        <Route path="*" element={<Play />} />
      </Routes>
    </BrowserRouter>
  </StrictMode>,
);

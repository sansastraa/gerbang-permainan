import { describe, expect, it } from "vitest";
import { gabungJalur, normalisasiBase } from "./url";

describe("penyusun URL dengan awalan jalur", () => {
  it("normalisasi awalan", () => {
    expect(normalisasiBase("/")).toBe("");
    expect(normalisasiBase("")).toBe("");
    expect(normalisasiBase(undefined)).toBe("");
    expect(normalisasiBase("/games/logic-rush/")).toBe("/games/logic-rush");
    expect(normalisasiBase("games/logic-rush")).toBe("/games/logic-rush");
  });
  it("gabungJalur untuk api, socket.io, dan halaman", () => {
    expect(gabungJalur("/games/logic-rush", "/api/lookup")).toBe("/games/logic-rush/api/lookup");
    expect(gabungJalur("/games/logic-rush/", "socket.io")).toBe("/games/logic-rush/socket.io");
    expect(gabungJalur("", "/watch?pin=123456")).toBe("/watch?pin=123456");
    expect(gabungJalur("/", "/obs")).toBe("/obs");
  });
});

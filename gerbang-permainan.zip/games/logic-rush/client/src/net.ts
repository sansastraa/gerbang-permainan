// Lapisan jaringan klien: satu socket per halaman + penyimpanan tampilan langsung (zustand).
import { io } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { create } from "zustand";
import { url } from "./url";
import { spectate as SP } from "@logic-rush/shared";
import type { Cell, HostExtra, StatePublik } from "@logic-rush/shared";

export interface Tayang {
  view: SP.SpectateView;
  /** kotak yang baru saja ditaruh (disorot beberapa detik) */
  last: Cell | null;
  lastAt: number;
  /** jejak langkah terakhir (paling baru di belakang) */
  trail: Cell[];
}
export interface Peristiwa {
  id: number;
  jenis: "selesai-pemain" | "game-akhir" | "match-selesai" | "papan-tuntas";
  t: number;
  data: Record<string, unknown>;
}
interface Live {
  state: StatePublik | null;
  extra: HostExtra | null;
  /** selisih jam server − jam lokal (ms) */
  offset: number;
  tayang: Record<string, Tayang>;
  streams: Record<string, MediaStream>;
  jalur: Record<string, "p2p" | "relay">;
  peristiwa: Peristiwa[];
  terhubung: boolean;
  setStream: (pid: string, s: MediaStream | null) => void;
  setJalur: (pid: string, j: "p2p" | "relay") => void;
  feed: (pid: string, msg: SP.SpectateMsg | null) => void;
}

let seqP = 0;
export const useLive = create<Live>((set, get) => ({
  state: null,
  extra: null,
  offset: 0,
  tayang: {},
  streams: {},
  jalur: {},
  peristiwa: [],
  terhubung: false,
  setStream: (pid, s) =>
    set((x) => {
      const streams = { ...x.streams };
      if (s) streams[pid] = s;
      else delete streams[pid];
      return { streams };
    }),
  setJalur: (pid, j) => set((x) => ({ jalur: { ...x.jalur, [pid]: j } })),
  feed: (pid, msg) => {
    if (!msg) return;
    const cur = get().tayang[pid] ?? { view: SP.initialView(), last: null, lastAt: 0, trail: [] };
    const view = SP.applyMsg(cur.view, msg);
    if (view === cur.view) return;
    let { last, lastAt, trail } = cur;
    if (msg.t === "mv" && (msg.op === "gem" || msg.op === "hint")) {
      last = { r: msg.r, c: msg.c };
      lastAt = Date.now();
      trail = [...trail, last].slice(-5);
    }
    if (msg.t === "snap" || msg.t === "stage") {
      last = null;
      trail = [];
    }
    set((x) => ({ tayang: { ...x.tayang, [pid]: { view, last, lastAt, trail } } }));
  },
}));

export const tambahPeristiwa = (jenis: Peristiwa["jenis"], data: Record<string, unknown>): void =>
  useLive.setState((x) => ({ peristiwa: [...x.peristiwa.slice(-30), { id: ++seqP, jenis, data, t: Date.now() }] }));

export function sambung(auth: Record<string, unknown>): Promise<Socket> {
  return new Promise((resolve, reject) => {
    const s = io({ path: url("/socket.io"), auth, transports: ["websocket", "polling"], reconnectionDelay: 800 });
    const sync = (t: number): void => useLive.setState({ offset: t - Date.now() });
    s.on("connect", () => useLive.setState({ terhubung: true }));
    s.on("disconnect", () => useLive.setState({ terhubung: false }));
    s.on("lr:state", (st: StatePublik) => {
      sync(st.serverTs);
      useLive.setState({ state: st });
    });
    s.on("lr:host-extra", (e: HostExtra) => useLive.setState({ extra: e }));
    s.on("lr:sp", (p: { pid: string; msg: SP.SpectateMsg }) => useLive.getState().feed(p.pid, p.msg));
    s.on("lr:selesai-pemain", (d: Record<string, unknown>) => tambahPeristiwa("selesai-pemain", d));
    s.on("lr:papan-tuntas", (d: Record<string, unknown>) => tambahPeristiwa("papan-tuntas", d));
    s.on("lr:game-akhir", (d: Record<string, unknown>) => tambahPeristiwa("game-akhir", d));
    s.on("lr:match-selesai", (d: Record<string, unknown>) => tambahPeristiwa("match-selesai", d));
    s.once("connect", () => resolve(s));
    s.once("connect_error", (e) => reject(e));
  });
}

export const tanya = <T = Record<string, unknown>>(s: Socket, ev: string, p?: unknown): Promise<T> =>
  new Promise((r) => s.emit(ev, p, (x: T) => r(x)));

/** Waktu server saat ini menurut jam lokal + selisih. */
export const sekarang = (): number => Date.now() + useLive.getState().offset;

export const fmtWaktu = (ms: number): string => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
};
export const fmtMs = (ms: number): string => `${(ms / 1000).toFixed(1)} dtk`;

// /watch (penonton kelas) dan /obs (Browser Source OBS Studio).
import { useEffect, useState } from "react";
import type { Socket } from "socket.io-client";
import { Mozaik, mulaiTonton } from "./Mozaik";
import { Klasemen } from "./Peringkat";
import { sambung, useLive } from "./net";

function useSambungan(peran: "penonton" | "obs", pin: string, obsKey?: string): { sock: Socket | null; galat: string } {
  const [sock, setSock] = useState<Socket | null>(null);
  const [galat, setGalat] = useState("");
  useEffect(() => {
    if (!/^\d{6}$/.test(pin)) return;
    let s: Socket | null = null;
    let batal = false;
    sambung({ peran, pin, ...(obsKey ? { obsKey } : {}) })
      .then(async (k) => {
        s = k;
        if (batal) return k.close();
        await mulaiTonton(k);
        setSock(k);
        // setelah sambung ulang otomatis, minta snapshot papan lagi
        k.on("connect", () => void mulaiTonton(k));
      })
      .catch((e: Error) =>
        setGalat(
          e.message.includes("terkunci")
            ? "Terlalu banyak percobaan. Tunggu semenit."
            : "PIN tidak ditemukan atau penonton tidak diizinkan.",
        ),
      );
    return () => {
      batal = true;
      s?.close();
    };
  }, [peran, pin, obsKey]);
  return { sock, galat };
}

export function Watch() {
  const q = new URLSearchParams(location.search);
  const [pinIsi, setPinIsi] = useState(q.get("pin") ?? "");
  const [pin, setPin] = useState(q.get("pin") ?? "");
  const [suara, setSuara] = useState(false);
  const [cam, setCam] = useState(true);
  const { sock, galat } = useSambungan("penonton", pin);
  const st = useLive((s) => s.state);
  if (!sock)
    return (
      <main className="gerbang">
        <div className="gerbang-kiri">
          <h1>Tonton</h1>
          <p className="lead">Lihat papan dan kamera para pemain secara langsung.</p>
        </div>
        <div className="gerbang-kanan">
          <form onSubmit={(e) => (e.preventDefault(), setPin(pinIsi))}>
            <label htmlFor="pin">PIN kelas</label>
            <input
              id="pin"
              className="pin-input"
              inputMode="numeric"
              maxLength={6}
              value={pinIsi}
              onChange={(e) => setPinIsi(e.target.value.replace(/\D/g, ""))}
              placeholder="••••••"
            />
            <button className="tombol utama" disabled={pinIsi.length !== 6}>
              Tonton
            </button>
          </form>
          {galat && <p className="galat">{galat}</p>}
        </div>
      </main>
    );
  return (
    <div className="watch">
      <div className="watch-alat">
        <span>{st?.sesi.nama ?? "Logic Rush"}</span>
        {st?.settings.format !== "massal" && (
          <>
            <label className="pilih">
              <input type="checkbox" checked={cam} onChange={(e) => setCam(e.target.checked)} /> kamera
            </label>
            <label className="pilih">
              <input type="checkbox" checked={suara} onChange={(e) => setSuara(e.target.checked)} /> suara
            </label>
          </>
        )}
      </div>
      <Mozaik sock={sock} cam={cam} suara={suara} />
      {st && (
        <div className="watch-bawah">
          <section className="blok hijau" style={{ marginTop: "1.8rem" }}>
            <h2>Klasemen sementara</h2>
            <Klasemen state={st} />
          </section>
        </div>
      )}
    </div>
  );
}

/** Adegan OBS 16:9 tetap (1920×1080) yang diskalakan memenuhi jendela. Parameter: pin, key, layout=duel|trio|auto, cam=on|off, chroma=#rrggbb, skor=on|off, suara=on|off. */
export function Obs() {
  const q = new URLSearchParams(location.search);
  const pin = q.get("pin") ?? "";
  const layout = (["duel", "trio"].includes(q.get("layout") ?? "") ? q.get("layout") : "auto") as
    "auto" | "duel" | "trio";
  const cam = q.get("cam") !== "off";
  const skor = q.get("skor") !== "off";
  const suara = q.get("suara") === "on";
  const chroma = q.get("chroma");
  const { sock, galat } = useSambungan("obs", pin, q.get("key") ?? undefined);
  const [skala, setSkala] = useState(1);
  useEffect(() => {
    document.body.classList.add("obs-badan");
    document.body.style.background =
      chroma && /^#?[0-9a-f]{6}$/i.test(chroma) ? (chroma.startsWith("#") ? chroma : "#" + chroma) : "transparent";
    const f = () => setSkala(Math.min(innerWidth / 1920, innerHeight / 1080));
    f();
    addEventListener("resize", f);
    return () => removeEventListener("resize", f);
  }, [chroma]);
  if (!/^\d{6}$/.test(pin)) return <div className="obs-pesan">Tambahkan ?pin=PIN6DIGIT pada alamat ini.</div>;
  if (galat) return <div className="obs-pesan">{galat}</div>;
  return (
    <div className="obs-kanvas" style={{ transform: `scale(${skala})` }}>
      {sock ? (
        <Mozaik sock={sock} layout={layout} cam={cam} suara={suara} obs skor={skor} />
      ) : (
        <div className="obs-pesan">menyambung…</div>
      )}
    </div>
  );
}

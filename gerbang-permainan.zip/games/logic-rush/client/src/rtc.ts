// WebRTC langsung (P2P): ponsel pemain → penonton. Sinyal lewat Socket.IO; server tidak pernah memegang media.
// Video + DataChannel "lr-spectate". Bila P2P gagal dalam 5 detik, penonton tetap mendapat papan lewat relay WebSocket.
import type { Socket } from "socket.io-client";
import { CONFIG, spectate as SP } from "@logic-rush/shared";
import { tanya, useLive } from "./net";
import { url } from "./url";

export async function ambilIce(): Promise<RTCIceServer[]> {
  try {
    const r = await fetch(url("/api/ice"));
    return ((await r.json()) as { iceServers: RTCIceServer[] }).iceServers ?? [];
  } catch {
    return [];
  }
}

const BATAS_ICE_MS = CONFIG.webrtc.batas_waktu_ice_detik * 1000;

const tunggal = new WeakMap<Socket, RtcSender>();
/** Satu pengirim per socket (agar penanganan sinyal tidak ganda). */
export async function pengirimUntuk(sock: Socket): Promise<RtcSender> {
  let s = tunggal.get(sock);
  if (!s) {
    s = new RtcSender(sock, await ambilIce(), () => null);
    tunggal.set(sock, s);
  }
  return s;
}

/** Sisi ponsel pemain. Kamera hanya menyala setelah pemain menekan tombolnya sendiri dan guru mengizinkan. */
export class RtcSender {
  stream: MediaStream | null = null;
  private pcs = new Map<string, { pc: RTCPeerConnection; dc: RTCDataChannel }>();
  private pending = new Map<string, RTCIceCandidateInit[]>();
  onJumlah: (n: number) => void = () => {};
  constructor(
    private sock: Socket,
    private ice: RTCIceServer[],
    public snapshot: () => SP.SpectateMsg | null,
  ) {
    sock.on("rtc:viewer-request", (p: { viewerId: string }) => void this.buka(p.viewerId));
    sock.on(
      "rtc:answer",
      (p: { viewerId: string; sdp: RTCSessionDescriptionInit }) => void this.jawab(p.viewerId, p.sdp),
    );
    sock.on(
      "rtc:ice",
      (p: { viewerId: string; candidate: RTCIceCandidateInit }) => void this.terimaIce(p.viewerId, p.candidate),
    );
    sock.on("rtc:viewer-gone", (p: { viewerId: string }) => this.tutup(p.viewerId));
  }
  async nyalakan(mikrofon: boolean): Promise<void> {
    this.stream = await navigator.mediaDevices.getUserMedia({
      video: { width: { ideal: 640 }, height: { ideal: 360 }, frameRate: { ideal: 15, max: 24 }, facingMode: "user" },
      audio: mikrofon ? { echoCancellation: true, noiseSuppression: true } : false,
    });
  }
  matikan(): void {
    this.stream?.getTracks().forEach((t) => t.stop());
    this.stream = null;
    for (const id of [...this.pcs.keys()]) this.tutup(id);
  }
  jumlah(): number {
    return [...this.pcs.values()].filter((x) => x.dc.readyState === "open").length;
  }
  /** Kirim pesan spectate ke semua penonton P2P yang terbuka. */
  kirim(msg: SP.SpectateMsg): void {
    const raw = SP.encode(msg);
    for (const { dc } of this.pcs.values()) if (dc.readyState === "open") dc.send(raw);
  }
  private async buka(viewerId: string): Promise<void> {
    this.tutup(viewerId);
    const pc = new RTCPeerConnection({ iceServers: this.ice });
    const dc = pc.createDataChannel("lr-spectate", { ordered: true });
    this.pcs.set(viewerId, { pc, dc });
    this.stream?.getTracks().forEach((t) => pc.addTrack(t, this.stream as MediaStream));
    dc.onopen = () => {
      const s = this.snapshot();
      if (s) dc.send(SP.encode(s));
      this.onJumlah(this.jumlah());
    };
    dc.onclose = () => this.onJumlah(this.jumlah());
    pc.onicecandidate = (e) => e.candidate && this.sock.emit("rtc:ice", { viewerId, candidate: e.candidate.toJSON() });
    const offer = await pc.createOffer();
    await pc.setLocalDescription(offer);
    this.sock.emit("rtc:offer", { viewerId, sdp: { type: "offer", sdp: offer.sdp } });
  }
  private async jawab(viewerId: string, sdp: RTCSessionDescriptionInit): Promise<void> {
    const e = this.pcs.get(viewerId);
    if (!e) return;
    await e.pc.setRemoteDescription(sdp);
    for (const c of this.pending.get(viewerId) ?? []) await e.pc.addIceCandidate(c);
    this.pending.delete(viewerId);
  }
  private async terimaIce(viewerId: string, c: RTCIceCandidateInit): Promise<void> {
    const e = this.pcs.get(viewerId);
    if (e?.pc.remoteDescription) await e.pc.addIceCandidate(c).catch(() => {});
    else this.pending.set(viewerId, [...(this.pending.get(viewerId) ?? []), c]);
  }
  private tutup(viewerId: string): void {
    const e = this.pcs.get(viewerId);
    if (!e) return;
    e.dc.close();
    e.pc.close();
    this.pcs.delete(viewerId);
    this.onJumlah(this.jumlah());
  }
}

/** Sisi penonton (operator, /watch, /obs): menerima video + papan P2P; jatuh ke relay bila gagal. */
export class RtcViewer {
  private pcs = new Map<string, RTCPeerConnection>();
  private timers = new Map<string, ReturnType<typeof setTimeout>>();
  private pending = new Map<string, RTCIceCandidateInit[]>();
  constructor(
    private sock: Socket,
    private ice: RTCIceServer[],
  ) {
    sock.on("rtc:offer", (p: { pid: string; sdp: RTCSessionDescriptionInit }) => void this.terimaOffer(p.pid, p.sdp));
    sock.on("rtc:ice", (p: { pid: string; candidate: RTCIceCandidateInit }) => void this.terimaIce(p.pid, p.candidate));
  }
  async watch(pid: string, wantVideo = true): Promise<{ video: boolean; alasan?: string }> {
    this.stop(pid);
    const r = await tanya<{ ok: boolean; video: boolean; alasan?: string }>(this.sock, "rtc:watch", { pid, wantVideo });
    if (!r.ok || !r.video) {
      useLive.getState().setJalur(pid, "relay");
      return { video: false, ...(r.alasan ? { alasan: r.alasan } : {}) };
    }
    // jika tidak tersambung dalam 5 detik: catat, tutup, dan andalkan relay
    this.timers.set(
      pid,
      setTimeout(() => {
        if (!useLive.getState().streams[pid]) {
          this.sock.emit("rtc:fallback", { pid });
          useLive.getState().setJalur(pid, "relay");
          this.stop(pid);
        }
      }, BATAS_ICE_MS),
    );
    return { video: true };
  }
  stop(pid: string): void {
    clearTimeout(this.timers.get(pid));
    this.timers.delete(pid);
    const pc = this.pcs.get(pid);
    if (pc) {
      pc.close();
      this.pcs.delete(pid);
      useLive.getState().setStream(pid, null);
      this.sock.emit("rtc:unwatch", { pid });
    }
  }
  stopAll(): void {
    for (const pid of [...this.pcs.keys()]) this.stop(pid);
  }
  private async terimaOffer(pid: string, sdp: RTCSessionDescriptionInit): Promise<void> {
    this.pcs.get(pid)?.close();
    const pc = new RTCPeerConnection({ iceServers: this.ice });
    this.pcs.set(pid, pc);
    pc.ondatachannel = (ev) => {
      const dc = ev.channel;
      dc.onopen = () => useLive.getState().setJalur(pid, "p2p");
      dc.onmessage = (m) => useLive.getState().feed(pid, SP.decode(String(m.data)));
    };
    pc.ontrack = (ev) => {
      const s = ev.streams[0] ?? new MediaStream([ev.track]);
      useLive.getState().setStream(pid, s);
      clearTimeout(this.timers.get(pid));
    };
    pc.onicecandidate = (e) => e.candidate && this.sock.emit("rtc:ice", { pid, candidate: e.candidate.toJSON() });
    await pc.setRemoteDescription(sdp);
    for (const c of this.pending.get(pid) ?? []) await pc.addIceCandidate(c);
    this.pending.delete(pid);
    const ans = await pc.createAnswer();
    await pc.setLocalDescription(ans);
    this.sock.emit("rtc:answer", { pid, sdp: { type: "answer", sdp: ans.sdp } });
  }
  private async terimaIce(pid: string, c: RTCIceCandidateInit): Promise<void> {
    const pc = this.pcs.get(pid);
    if (pc?.remoteDescription) await pc.addIceCandidate(c).catch(() => {});
    else this.pending.set(pid, [...(this.pending.get(pid) ?? []), c]);
  }
}

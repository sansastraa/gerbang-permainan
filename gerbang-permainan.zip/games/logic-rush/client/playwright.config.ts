﻿import { defineConfig } from "@playwright/test";
export default defineConfig({ testDir: "e2e", use: { channel: "msedge", headless: true }, timeout: 60000 });

import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

const basePath = (() => {
  let s = (process.env.BASE_PATH ?? "").trim();
  if (!s || s === "/") return "/";
  if (!s.startsWith("/")) s = "/" + s;
  return s.replace(/\/+$/, "") + "/";
})();

export default defineConfig({
  base: basePath,
  plugins: [react()],
  server: {
    port: 5190,
    proxy: {
      "/socket.io": { target: "http://localhost:3090", ws: true },
      "/api": "http://localhost:3090",
      "/health": "http://localhost:3090",
    },
  },
  build: { outDir: "dist", sourcemap: false },
  test: { environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"] },
});

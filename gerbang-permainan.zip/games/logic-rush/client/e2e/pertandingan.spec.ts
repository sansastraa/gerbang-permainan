// E2E dengan Edge sistem: operator + 2 pemain + /watch + /obs pada server sungguhan (HOST_PIN=guru-123, port 3090).
// Jalankan: (server berjalan) npx playwright test
import { expect, test } from "@playwright/test";
import type { Page } from "@playwright/test";
import { solutions } from "../../shared/src/engine.ts";
import type { Rule } from "../../shared/src/engine.ts";

const BASE = process.env.LR_BASE ?? "http://localhost:3090";

async function bacaPapan(p: Page) {
  const ubin = p.locator(".papan.bisa .ubin");
  await expect(ubin.first()).toBeVisible();
  const n = Math.round(Math.sqrt(await ubin.count()));
  const zones: string[] = [];
  const rules: Rule[] = ["row", "col", "zone"];
  for (let r = 0; r < n; r++) {
    let row = "";
    for (let c = 0; c < n; c++) {
      const t = ubin.nth(r * n + c);
      const arsir = (await t.getAttribute("class"))?.includes("arsir");
      row += arsir ? "#" : String("ABCDEFGHIJ".indexOf((await t.locator(".huruf").innerText()).trim()));
    }
    zones.push(row);
  }
  if (zones.some((z) => z.includes("#"))) rules.push("blocked");
  return { n, zones, rules };
}

test("operator membuat sesi, dua pemain bertanding, penonton dan OBS melihatnya", async ({ browser }) => {
  const ctxOp = await browser.newContext({ viewport: { width: 1280, height: 900 } });
  const op = await ctxOp.newPage();
  await op.goto(`${BASE}/host`);
  await op.getByPlaceholder(/PIN guru/).fill("guru-123");
  // pengaturan dipendekkan: 1 game, tanpa hitung mundur panjang
  await op.getByLabel("1 game").check();
  await op.getByLabel("Papan per game").selectOption("1");
  await op.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await op.locator(".pin-besar").innerText()).trim();
  expect(pin).toMatch(/^\d{6}$/);
  const urlObs = await op.getByTestId("url-obs").inputValue();
  expect(urlObs).toContain(`pin=${pin}`);

  const pemain: Page[] = [];
  for (const nama of ["Ayu", "Beni"]) {
    const c = await browser.newContext({ viewport: { width: 390, height: 780 }, hasTouch: true });
    const p = await c.newPage();
    await p.goto(`${BASE}/`);
    await p.getByLabel("PIN dari guru").fill(pin);
    await p.getByRole("button", { name: "Cari kelas" }).click();
    await p.getByLabel("Namamu").fill(nama);
    await p.getByRole("button", { name: "Masuk" }).click();
    await expect(p.getByText(/Kamu sudah masuk/)).toBeVisible();
    pemain.push(p);
  }
  await op.locator(".host-menu .item", { hasText: "Murid" }).click();
  await expect(op.getByRole("heading", { name: "Murid (2)" })).toBeVisible();
  await op.locator(".murid input[type=checkbox]").nth(0).check();
  await op.locator(".murid input[type=checkbox]").nth(1).check();
  await op.getByRole("button", { name: /Buat pertandingan dari yang dicentang/ }).click();
  await op.locator(".host-menu .item", { hasText: "Pertandingan" }).click();
  await op.getByRole("button", { name: "Panggil" }).click();
  for (const p of pemain) await p.getByRole("button", { name: "Aku siap" }).click();
  await op.getByRole("button", { name: "Mulai", exact: true }).click();

  // penonton + OBS
  const watch = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  await watch.goto(`${BASE}/watch?pin=${pin}`);
  const obs = await (await browser.newContext({ viewport: { width: 1280, height: 720 } })).newPage();
  await obs.goto(urlObs.replace("localhost", "localhost"));

  for (const p of pemain) await expect(p.locator(".papan.bisa")).toBeVisible({ timeout: 15000 });
  await expect(watch.locator(".pnl")).toHaveCount(2, { timeout: 10000 });
  await expect(obs.locator(".obs-kanvas .pnl")).toHaveCount(2, { timeout: 10000 });

  // pemain pertama menyelesaikan papan memakai solver dari papan publik
  const a = pemain[0];
  const { n, zones, rules } = await bacaPapan(a);
  const sol = solutions({ n, zones, rules }, 1)[0];
  for (let r = 0; r < n; r++)
    await a
      .locator(".papan.bisa .ubin")
      .nth(r * n + sol[r])
      .click();
  await expect(a.getByText(/Benar|Memeriksa/)).toBeVisible();

  // penonton melihat permata Ayu dan sorotan langkah
  await expect(watch.locator(".pnl").first().locator(".permata")).toHaveCount(n, { timeout: 8000 });
  await watch.screenshot({ path: "test-results/watch-mozaik.png" });
  await obs.screenshot({ path: "test-results/obs-adegan.png" });
  await a.screenshot({ path: "test-results/pemain-menang.png" });

  // pemain kedua juga selesai → pertandingan selesai, pemenang Ayu
  const b = pemain[1];
  const pb = await bacaPapan(b);
  const solB = solutions({ n: pb.n, zones: pb.zones, rules: pb.rules }, 1)[0];
  for (let r = 0; r < pb.n; r++)
    await b
      .locator(".papan.bisa .ubin")
      .nth(r * pb.n + solB[r])
      .click();
  await expect(op.locator(".laga-selesai")).toContainText("menang: Ayu", { timeout: 15000 });
  await op.screenshot({ path: "test-results/konsol-laga.png", fullPage: true });
  // peringkat: papan peringkat langsung + klasemen sementara
  await op.locator(".host-menu .item", { hasText: "Peringkat" }).click();
  await expect(op.locator(".rank-baris")).toHaveCount(2);
  await expect(op.locator(".klasemen tbody tr")).toHaveCount(2);
  await op.screenshot({ path: "test-results/konsol-peringkat.png", fullPage: true });
  // hasil: validasi keseluruhan dan per papan
  await op.locator(".host-menu .item", { hasText: "Hasil" }).click();
  await expect(op.getByText("validasi keseluruhan")).toBeVisible();
  await expect(op.locator(".tabel-stat").first().locator("tbody tr")).toHaveCount(1, { timeout: 8000 });
  await op.screenshot({ path: "test-results/konsol-hasil.png", fullPage: true });
});

test("format massal: 4 murid, tanpa kamera, sorotan bergilir dan papan peringkat naik-turun", async ({ browser }) => {
  const op = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  await op.goto(`${BASE}/host`);
  await op.getByPlaceholder(/PIN guru/).fill("guru-123");
  await op.getByRole("button", { name: /Massal, di atas 3 pemain/ }).click();
  await op.getByLabel("1 game").check();
  await op.getByLabel("Papan per game").selectOption("1");
  await op.getByRole("combobox").filter({ hasText: "3 detik" }).selectOption("3");
  await op.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await op.locator(".pin-besar").innerText()).trim();
  const pemain: Page[] = [];
  for (const nama of ["Ani", "Budi", "Cici", "Dedi"]) {
    const p = await (await browser.newContext({ viewport: { width: 390, height: 780 }, hasTouch: true })).newPage();
    await p.goto(`${BASE}/?pin=${pin}`);
    await p.getByRole("button", { name: "Cari kelas" }).click();
    await p.getByLabel("Namamu").fill(nama);
    await p.getByRole("button", { name: "Masuk" }).click();
    await expect(p.getByText(/Kamu sudah masuk/)).toBeVisible();
    pemain.push(p);
  }
  await op.locator(".host-menu .item", { hasText: "Murid" }).click();
  await op.getByRole("button", { name: /Siapkan arena massal \(4 pemain\)/ }).click();
  await op.locator(".host-menu .item", { hasText: "Pertandingan" }).click();
  await op.getByRole("button", { name: "Panggil" }).click();
  for (const p of pemain) await p.getByRole("button", { name: "Aku siap" }).click();
  await op.getByRole("button", { name: "Mulai", exact: true }).click();
  const watch = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  await watch.goto(`${BASE}/watch?pin=${pin}`);
  for (const p of pemain) await expect(p.locator(".papan.bisa")).toBeVisible({ timeout: 15000 });
  await expect(watch.locator(".arena .rank-baris")).toHaveCount(4, { timeout: 10000 });
  await expect(watch.locator(".pnl-kamera")).toHaveCount(0); // massal: tanpa panel kamera
  // sorotan berganti dalam ±3 detik
  const nama1 = await watch.locator(".sorot-nama").innerText();
  await expect(watch.locator(".sorot-nama")).not.toHaveText(nama1, { timeout: 9000 });
  // papan peringkat langsung naik: satu murid memasang permata
  const a = pemain[2];
  const { n, zones, rules } = await bacaPapan(a);
  const sol = solutions({ n, zones, rules }, 1)[0];
  for (let r = 0; r < n; r++)
    await a
      .locator(".papan.bisa .ubin")
      .nth(r * n + sol[r])
      .click();
  await expect(a.getByText(/Benar|Memeriksa/)).toBeVisible();

  const pertama = watch.locator(".rank-baris").filter({ hasText: "Cici" });
  await expect(pertama.locator(".rank-no")).toHaveText("1", { timeout: 6000 });
  await watch.screenshot({ path: "test-results/massal-watch.png" });
  // selesai semuanya → hasil
  for (const [i, p] of pemain.entries()) {
    if (i === 2) continue;
    const b = await bacaPapan(p);
    const s = solutions({ n: b.n, zones: b.zones, rules: b.rules }, 1)[0];
    for (let r = 0; r < b.n; r++)
      await p
        .locator(".papan.bisa .ubin")
        .nth(r * b.n + s[r])
        .click();
  }
  await op.locator(".host-menu .item", { hasText: "Hasil" }).click();
  await expect(op.locator(".tabel-stat").first().locator("tbody tr")).toHaveCount(1, { timeout: 12000 });
  await op.locator(".host-menu .item", { hasText: "Peringkat" }).click();
  await expect(op.locator(".klasemen tbody tr")).toHaveCount(4);
  await op.screenshot({ path: "test-results/massal-host.png", fullPage: true });
});

test("laga 2 papan: selesai papan 1 langsung lanjut ke papan 2 dengan animasi tuntas; penonton melihat lencana", async ({
  browser,
}) => {
  const op = await (await browser.newContext({ viewport: { width: 1280, height: 900 } })).newPage();
  await op.goto(`${BASE}/host`);
  await op.getByPlaceholder(/PIN guru/).fill("guru-123");
  await op.getByLabel("1 game").check();
  await op.getByLabel("Papan per game").selectOption("2");
  await op.getByRole("button", { name: /Buat sesi/ }).click();
  const pin = (await op.locator(".pin-besar").innerText()).trim();
  const pemain: Page[] = [];
  for (const nama of ["Ayu", "Beni"]) {
    const p = await (await browser.newContext({ viewport: { width: 390, height: 780 }, hasTouch: true })).newPage();
    await p.goto(`${BASE}/?pin=${pin}`);
    await p.getByRole("button", { name: "Cari kelas" }).click();
    await p.getByLabel("Namamu").fill(nama);
    await p.getByRole("button", { name: "Masuk" }).click();
    await expect(p.getByText(/Kamu sudah masuk/)).toBeVisible();
    pemain.push(p);
  }
  await op.locator(".host-menu .item", { hasText: "Murid" }).click();
  await op.locator(".murid input[type=checkbox]").nth(0).check();
  await op.locator(".murid input[type=checkbox]").nth(1).check();
  await op.getByRole("button", { name: /Buat pertandingan dari yang dicentang/ }).click();
  await op.locator(".host-menu .item", { hasText: "Pertandingan" }).click();
  await op.getByRole("button", { name: "Panggil" }).click();
  for (const p of pemain) await p.getByRole("button", { name: "Aku siap" }).click();
  await op.getByRole("button", { name: "Mulai", exact: true }).click();
  const watch = await (await browser.newContext({ viewport: { width: 1280, height: 800 } })).newPage();
  await watch.goto(`${BASE}/watch?pin=${pin}`);
  const [a, b] = pemain;
  await expect(a.locator(".papan.bisa")).toBeVisible({ timeout: 15000 });
  await expect(a.getByText(/Papan 1\/2/)).toBeVisible();

  const selesaikanPapan = async (p: Page) => {
    const x = await bacaPapan(p);
    const s = solutions({ n: x.n, zones: x.zones, rules: x.rules }, 1)[0];
    for (let r = 0; r < x.n; r++)
      await p
        .locator(".papan.bisa .ubin")
        .nth(r * x.n + s[r])
        .click();
    return x.n;
  };
  const n1 = await selesaikanPapan(a);
  // animasi tuntas di layar Ayu, lalu papan 2 (ukuran berbeda) tanpa menunggu Beni
  await expect(a.locator(".tuntas-overlay")).toContainText("Papan 1 tuntas!");
  await a.screenshot({ path: "test-results/papan-tuntas.png" });
  await expect(a.getByText(/Papan 2\/2/)).toBeVisible({ timeout: 4000 });
  await expect(a.locator(".tuntas-overlay")).toHaveCount(0, { timeout: 4000 });
  await expect(b.getByText(/Papan 1\/2/)).toBeVisible();
  // penonton: lencana "Papan 1 tuntas!" pada panel Ayu dan progres papan
  await expect(watch.locator(".badge-tuntas").first()).toContainText("Papan 1 tuntas!", { timeout: 4000 });
  await expect(watch.getByText(/Papan 2\/2/).first()).toBeVisible();
  const n2 = await selesaikanPapan(a);
  expect(n2).toBeGreaterThanOrEqual(n1);
  await expect(a.locator(".tuntas-overlay")).toContainText("Semua papan tuntas!");
  // Beni menuntaskan keduanya → laga selesai; statistik punya 2 baris papan
  await selesaikanPapan(b);
  await expect(b.getByText(/Papan 2\/2/)).toBeVisible({ timeout: 4000 });
  await selesaikanPapan(b);
  await op.locator(".host-menu .item", { hasText: "Hasil" }).click();
  await expect(op.locator(".tabel-stat").first().locator("tbody tr")).toHaveCount(2, { timeout: 12000 });
  await op.screenshot({ path: "test-results/konsol-hasil-2papan.png", fullPage: true });
});

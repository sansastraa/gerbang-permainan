# CLAUDE.md — Logic Rush mandiri (laga 2–3 pemain, massal sampai 40, kamera/RTC opsional)

Baca `README.md` dan `docs/PROGRESS.md`. `docs/SPEC-asli-draf3.md` dan `docs/CLAUDE-asli.md` adalah paket spesifikasi awal; **bagian yang bertentangan digantikan** oleh perubahan pengguna berikut:

- Format kompetisi: laga maks 3 / min 2 pemain, papan dasar sama + transformasi dan warna zona berbeda per pemain, terbaik dari N game, beberapa papan per game (selesai satu langsung lanjut), antrean/bracket. Format massal (di atas 3 pemain): tanpa kamera/RTC, papan peringkat langsung + sorotan bergilir.
- Kamera/mikrofon kini boleh **hanya** untuk peserta laga, P2P (sinyal lewat Socket.IO), TURN dari env, jatuh ke tanpa kamera bila gagal; DataChannel membawa status papan, relay WebSocket sebagai cadangan; izin guru/orang tua wajib; server tak pernah merekam.
- Server wasit tetap: `solution` tidak pernah dikirim; `validateStage`/`validateSettings` di UI dan server.

Aturan kerja: engine di `shared/src/engine.ts` jangan diubah perilakunya (tes paritas dengan `shared/reference/*.cjs`). Semua waktu lewat `Clock` yang disuntik (tes memakai `FakeClock`). Muatan keluar server tak boleh memuat `"solution"` (harness tes melempar bila bocor). UI bahasa Indonesia ramah anak, palet cerah, tanpa suara peramban. Per milestone: tes hijau, `npm run lint` bersih, catatan di `docs/PROGRESS.md`.

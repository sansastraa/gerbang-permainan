# Logic Rush (mandiri)

Game logika permata dan zona untuk murid SD. Server sendiri (Node + Socket.IO), PIN sendiri, log kejadian sendiri; tidak bergantung pada SIMPETERI atau MinX Arena. Di SIMPETERI ia muncul sebagai menu **Logic Rush** (Clash of Git) dan hasilnya ikut Hall of Fame di **Buat Multi Permainan**.

## Aturan singkat

Papan N×N (3–10). Taruh **N permata**: satu per baris (R1), satu per kolom (R2), satu per zona warna (R3); kotak arsir terlarang (R4, opsional); tidak boleh sejajar miring (R5, opsional, mulai 4×4). Warna dibantu huruf zona A–J dan arsir miring, jadi aman untuk buta warna.

## Format

| Format     | Pemain | Intinya                                                                                                                                                                                                                                                                                                                                                                              |
| ---------- | ------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Laga**   | 2–3    | Papan dasar **sama** untuk semua dalam satu laga, tetapi diputar/dicermin dan warna zonanya diacak per pemain. Terbaik dari 1/3/5 game. Satu game bisa berisi **beberapa papan**: selesai satu papan, pemain langsung lanjut ke papan berikutnya tanpa menunggu lawan (ada animasi "Papan tuntas!"). Antrean otomatis dan babak berikutnya (bracket sederhana). Kamera/RTC opsional. |
| **Massal** | 4–40   | Arena tunggal. Papan dasar **berbeda** per pemain (anti-contek). **Tanpa kamera dan tanpa RTC.** Papan peringkat naik-turun secara langsung dan **sorotan bergilir** (mis. siswa J detik 1–5, siswa X detik 6–10) tiap beberapa detik.                                                                                                                                               |

Poin game laga: peringkat 5/3/1 (hanya yang menuntaskan semua papan); massal 10/8/6/5/4/3/2/1. Bonus 5 poin untuk pemenang laga. Waktu efektif = waktu server + penalti bantuan (30 detik, 1 per papan).

## Halaman

| Alamat                                                                                        | Untuk                                                                                                                                                                                                       |
| --------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `/`                                                                                           | Murid: PIN, nama (atau pilih dari daftar hadir), bermain                                                                                                                                                    |
| `/host` (juga `/operator`)                                                                    | Guru, **terpisah** dari layar murid: menu Beranda, Murid, Pertandingan, Peringkat (peringkat langsung + klasemen sementara), Hasil (validasi keseluruhan dan per papan, statistik menjawab, ekspor), Siaran |
| `/watch?pin=`                                                                                 | Penonton kelas: mozaik kamera + papan tiap pemain (laga) atau arena massal; klasemen sementara                                                                                                              |
| `/obs?pin=&key=&layout=duel\|trio\|auto&cam=on\|off&chroma=00ff00&skor=on\|off&suara=on\|off` | Browser Source OBS Studio, kanvas tetap 1920×1080 (skala otomatis), latar transparan atau `chroma`                                                                                                          |

OBS Studio: Sumber → Browser → tempel tautan dari konsol (menu Siaran), lebar 1920, tinggi 1080. Tautan memuat `key` yang membuka kamera di adegan; jangan dibagikan ke murid.

## Menjalankan

```bash
npm run lr:install     # dari akar SIMPETERI (atau npm install di folder ini)
npm run lr:dev         # server :3090 + client :5190
npm run lr:build && npm run lr:start   # produksi: mencetak PIN guru, URL LAN dan QR
npm run lr:test        # engine (342k+ pemeriksaan, paritas dengan JS asli), server, klien
npm run lr:sim -- --bots 9 --watchers 4            # simulasi bot laga
npm run lr:sim -- --bots 12 --watchers 3 --massal  # simulasi bot massal
npm run lr:e2e         # Playwright (Edge sistem); butuh server berjalan di :3090 dengan HOST_PIN=guru-123
```

Variabel lingkungan: lihat `.env.example` (`HOST_PIN`, `ALLOWED_ORIGINS`, `STUN_URLS`, `TURN_*`). Docker: `Dockerfile`. Online (Lovable tidak dapat menjalankan Socket.IO): jalankan server ini terpisah, isi `VITE_LOGIC_RUSH_URL` pada build SIMPETERI, pakai HTTPS, dan beri TURN bila ingin kamera lintas jaringan.

## Integrasi SIMPETERI

`/logic-rush` memilih kelas lalu membuka `{server}/host` dan mengirim daftar siswa lewat `postMessage` (`logicrush:host-ready` ↔ `logicrush:roster`; id = `siswa.id`, maks 40; origin diperiksa di kedua arah). Menu Buat Multi Permainan menarik `GET /api/sessions/:id/summary.json` (header `x-host-token` = PIN guru; 403 sebelum sesi diakhiri, 401 PIN salah, CORS dibatasi `ALLOWED_ORIGINS`). Bentuk: `{ game:"logic-rush", versi:1, sesiId, siswa:[{ siswaId, nama, absen, skor, peringkat, pertandingan, pertandinganMenang, gameMenang, gameMain, bantuan, waktuMs }] }`. Tersedia juga `results.csv`, `statistik.json`, `log.jsonl` (log berantai hash).

## Keamanan dan privasi anak

- **Server wasit.** `solution` hanya ada di server; tes memeriksa setiap muatan keluar. `finish` dicek `check()` + `matchesSolution()`, idempoten per papan, diproses sinkron.
- PIN 6 digit, batas 10 percobaan salah per menit per IP, token pemain 128-bit, satu nama satu perangkat, maks 40 pemain, nama disaring.
- **Kamera mati secara bawaan.** Agar menyala: guru menyatakan izin orang tua/wali sudah ada, guru menyetujui tiap murid, murid menekan tombolnya sendiri. Indikator merah "KAMERA MENYALA" selalu terlihat dan bisa dimatikan murid. Video langsung P2P (WebRTC); server hanya meneruskan SDP/ICE dan **tidak pernah menerima, merekam, atau menyimpan media**. Kunci OBS dan pengaturan guru menentukan siapa boleh melihat video; kuota 3 penonton per pemain. Format massal tidak memakai kamera sama sekali. Perekaman oleh OBS adalah tanggung jawab penyelenggara.

## Font

Plus Jakarta Sans (OFL). Product Sans disalin dari Route Rush; **lisensinya belum jelas** (lihat `client/public/fonts/README.md`).

## Struktur

`shared/` engine TS (port tanpa perubahan perilaku dari paket spesifikasi; asli di `shared/reference/` sebagai oracle), pengaturan, kompetisi, protokol · `server/` Express + Socket.IO + sesi/wasit · `client/` Vite + React · `data/bank/` 31 kolam, 1.287 papan (berisi solusi, hanya server) · `tools/lr-gen.cjs` pembangkit bank · `docs/` SPEC asli (Draf 3), PROGRESS, LAMA.

## Di belakang gerbang SIMPETERI (BASE_PATH)

Agar semua game diakses satu pintu (mis. `http://<host>/games/logic-rush`), server dan klien mendukung awalan jalur:

```bash
# build klien dengan awalan (Vite base)
BASE_PATH=/games/logic-rush npm run build            # PowerShell: $env:BASE_PATH='/games/logic-rush'; npm run build
# jalankan server dengan awalan yang sama; gerbang meneruskan /games/logic-rush/** apa adanya (tanpa memotong awalan)
BASE_PATH=/games/logic-rush TRUST_PROXY=1 HOST_PIN=<pin> npm run start
```

- `BASE_PATH`: diawali `/`, tanpa `/` akhir (dinormalisasi); kosong = perilaku biasa di akar. Server menyajikan klien statis, fallback SPA (`/host`, `/watch`, `/obs`, ...), `/health`, `/api/**`, dan socket.io (`path: BASE_PATH + "/socket.io"`) di bawah awalan itu; di akar tidak melayani apa pun.
- Klien memakai `client/src/url.ts` (`url()`, `alamatMutlak()`): semua `fetch /api`, socket.io (termasuk sinyal WebRTC), router (`basename`), tautan `/watch` dan `/obs`, serta URL/QR murid memuat awalan. Jangan menulis `"/api/..."` langsung.
- `TRUST_PROXY=1`: batas percobaan PIN per IP memakai `X-Forwarded-For` (hanya bila gerbang tepercaya menulis ulang dan membuang kiriman klien). Tanpa itu header diabaikan.
- Tes: `server/src/basepath.test.ts` (health, api, statis, SPA, socket.io, XFF) dan `client/src/url.test.ts`. E2E di bawah awalan: `LR_BASE=http://localhost:3090/games/logic-rush npx playwright test`.

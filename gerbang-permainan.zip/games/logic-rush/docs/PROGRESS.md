# PROGRESS — Logic Rush mandiri

Lingkungan pengembangan: Windows, Node 24, tanpa Docker, panel Browser bawaan tanpa kamera. Catatan jalur panjang: di folder kerja yang sangat dalam, `esbuild.exe` gagal diluncurkan (batas 260 karakter). Solusi lokal: `node_modules` dijadikan _junction_ ke `C:\lrnm\node_modules`. Di folder biasa hal ini tidak muncul.

## M0 — Port engine (selesai)

- `shared/src/engine.ts` dan `spectate.ts`: port TypeScript dari `lr-engine.js` dan `spectate-protocol.js` **tanpa mengubah perilaku**; berkas asli disimpan di `shared/reference/*.cjs`.
- Tes: port vitest dari tes asli (setara 342.575 pemeriksaan, seluruh 1.287 papan unik/solvable/tak kembar, 8 simetri, pembagian 40 pemain, level, peringkat, protokol penonton) + **tes paritas** (papan hasil `generateBoard`, `check`, `solutions`, `logicSolve`, `transformBoard`, `hintCell`, `assignBoards`, `rank`, protokol identik dengan JS asli).

## M1/M2 — Sesi, PIN, wasit (selesai)

Sesi, PIN 6 digit + QR, token pemain, daftar hadir, batas 40, penjaga percobaan PIN, `validateSettings` (zod + `validateStage`) di UI dan server, panel Atur Papan (preset, 1–6 tahap, ukuran 3–10, arsir, diagonal, level, waktu otomatis × 1,5), `finish` dua lapis idempoten, bantuan + penalti, jeda yang menggeser jam, log berantai hash.

## Perubahan pengguna (a)(b)(c) (selesai)

- (a) Laga 2–3 pemain, papan dasar sama + transformasi/warna zona berbeda, terbaik dari 1/3/5, antrean otomatis, babak berikut, game tambahan bila seri, skor (poin game + bonus menang laga).
- (b) Kamera/mikrofon P2P: persetujuan guru, konfirmasi izin orang tua, tombol matikan, indikator, opsi tanpa kamera, kuota 3 penonton/pemain, kunci OBS, cadangan relay WebSocket (5 detik), `/watch`, `/obs`.
- (c) Keamanan wasit: tes bahwa tak satu muatan keluar memuat `solution`.
- Tambahan permintaan lanjutan: format **massal** (>3 pemain; tanpa RTC; peringkat langsung; sorotan bergilir), **beberapa papan per game** dengan animasi tuntas, **konsol host terpisah** dengan menu, klasemen sementara, statistik validasi keseluruhan dan per papan, UI dirancang ulang (cerah, bukan gelap/biru).

## Hasil uji

- `shared`: 18 tes (engine, paritas, spectate, kompetisi/pengaturan). `server`: 47 tes (sesi dengan jam palsu, 3 pemain, bracket, massal 40 pemain, multi-papan, statistik, Socket.IO nyata termasuk sinyal WebRTC, CORS, kunci PIN). `client`: 4 tes kontrak pesan roster.
- E2E Playwright dengan Edge sistem, 3 skenario lulus: laga 1 papan (operator + 2 pemain + `/watch` + `/obs`), laga 2 papan (animasi tuntas, lencana penonton), massal 4 murid (sorotan bergilir, peringkat naik).
- Simulasi bot: `sim --bots 9 --watchers 4` (laga, 2 babak) dan `sim --bots 12 --watchers 3 --massal` lulus; tidak ada kebocoran solusi, rantai hash utuh.
- SIMPETERI: `src/test/logic-rush.test.ts` menjalankan sesi asli lalu membaca `summary.json` dengan `bacaRingkasanLogicRush`.

## Belum diuji / batas yang jujur

1. **Kamera dan WebRTC di perangkat nyata dan jaringan sekolah.** Panel Browser bawaan tak punya kamera; yang diuji: persetujuan, kuota, relai sinyal SDP/ICE (tes Socket.IO), dan jatuh ke relay. `RTCPeerConnection`/`getUserMedia` di klien belum dijalankan di HP nyata. TURN belum diuji.
2. **OBS Studio sungguhan.** `/obs` diuji sebagai halaman di Edge (1920×1080 berskala, transparan); belum dimuat di Browser Source OBS.
3. **Kalibrasi waktu dengan anak.** Batas waktu otomatis memakai usulan `TARGET_MENIT` × 1,5; belum diuji anak. Papan 9×9–10×10 di HP 360 px belum diuji (Mode Zoom sederhana: papan digeser, tanpa kaca pembesar).
4. **Server restart** menghapus sesi aktif (log JSONL tersisa untuk audit); pemulihan sesi dari disk belum dibuat.
5. Satu pertandingan aktif pada satu waktu per sesi (yang lain mengantre).
6. Lisensi Product Sans belum jelas (lihat `client/public/fonts/README.md`).
7. Deploy: `Dockerfile` ditulis tetapi **belum dibangun** (Docker tak tersedia di mesin ini).

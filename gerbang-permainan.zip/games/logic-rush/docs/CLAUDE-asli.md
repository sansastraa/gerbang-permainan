# CLAUDE.md — Logic Rush SD (game mandiri, 1–40 pemain, PIN, papan 3×3–10×10, penonton WebRTC)

Kamu membangun **Logic Rush**, game logika permata-dan-zona untuk murid SD. Satu kelas sampai **40 pemain** masuk dengan **PIN 6 digit**. **Guru mengatur papan**: 1–6 tahap, ukuran **3×3 sampai 10×10**, aturan arsir (R4) dan diagonal (R5) per tahap, level mudah/sedang/sulit, atau memakai preset (bawaan: SD Standar 4×4 → 5×5 → 6×6). Guru dapat **menonton satu murid secara langsung lewat WebRTC DataChannel**. Mode: RUSH (bawaan), MARATON, DUEL (kompatibel Grand Final).

## Baca dulu

1. `docs/SPEC.md` — rancang bangun lengkap (Draf 3). §1a = parameter guru, §6 = bank, §11 = WebRTC.
2. `engine/lr-engine.js` + tes — aturan, pembangkit (dengan perbaikan zona), solver logika, transformasi, bantuan, replay, `assignBoards`, `pickByLevel`, `validateStage`, `suggestMinutes`, `marathonPoints`, peringkat. **Sudah diuji: 342.575 pemeriksaan.**
3. `engine/spectate-protocol.js` + tes — pesan penonton dan reducer tampilan (11 pemeriksaan).
4. `config/logic-rush.config.json` — semua angka, batas ukuran, dan preset. Jangan hardcode.
5. `data/bank/` — 31 kolam, 1.287 papan terverifikasi (berisi solusi, **hanya server**). `node tools/lr-gen.js` untuk menambah atau mengganti kolam.

## Aturan kerja

- pnpm monorepo, TypeScript strict. Port kedua file engine ke `packages/lr-engine` **tanpa mengubah perilaku**, beserta seluruh tesnya. Server dan browser mengimpor paket yang sama.
- **Server adalah wasit.** `lr:board` memakai `publicBoard()` (tanpa `solution`); tulis tes yang membuktikannya. Finish idempoten per seq dan diproses berurutan.
- Parameter papan selalu divalidasi dengan `validateStage` di UI **dan** server (3–10; diagonal hanya ≥ 4).
- Papan adaptif: kotak = ⌊min(lebar, tinggi × 0,72) ÷ N⌋, minimal 30 px; di bawah 36 px aktifkan Mode Zoom + kaca pembesar. Palet 10 warna aman buta warna + huruf zona A–J + arsir.
- WebRTC hanya DataChannel (tanpa kamera/mikrofon). Sinyal lewat Socket.IO. Maks 2 P2P per murid; selebihnya dan saat ICE gagal 5 detik → relay WebSocket dengan protokol yang sama.
- Berjalan offline di LAN (laptop guru + hotspot) dan online (Docker + TURN dari env). Teks UI Bahasa Indonesia ramah anak.
- Setiap milestone: tes hijau + lint bersih + catatan di `docs/PROGRESS.md`. **Berhenti dan laporkan setelah setiap milestone.**

## Perintah (buat di M0)

`pnpm dev` · `pnpm test` · `pnpm sim` (40 bot + 4 penonton) · `pnpm build && pnpm start` (cetak URL LAN + QR + PIN) · `docker build .`

## Milestone

M0 port engine → M1 sesi, PIN & **panel Atur Papan** → M2 bank ke DB, run per pemain & wasit → M3 layar pemain adaptif 3×3–10×10 → M4 proyektor → M5 operator → **M6 WebRTC tonton 1 murid** → M7 relay, mozaik, multi-tonton, pengamat, TURN → M8 MARATON, DUEL, layar tunggal → M9 anti-curang, statistik, simulasi, Go/No-Go.
Kriteria tiap milestone ada di SPEC §17; uji Go/No-Go di SPEC §16.

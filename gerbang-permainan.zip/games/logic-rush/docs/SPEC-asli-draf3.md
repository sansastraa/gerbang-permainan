# Logic Rush SD — Game Mandiri (sampai 40 pemain, masuk dengan PIN, penonton WebRTC)

### Spesifikasi Rancang Bangun untuk Claude Code · Draf 3 · November 2026

> Dokumen ini mengubah _Rancang Bangun Grand Final: Logic Rush SD_ (Draf 1, 25 Oktober 2026) dari game final 2–3 orang menjadi **game mandiri** untuk satu kelas.
> Mesin `engine/lr-engine.js` dan `engine/spectate-protocol.js` **sudah diuji** (342.575 + 11 pemeriksaan lulus). Bank `data/bank/` berisi **1.287 papan terverifikasi dalam 31 kolam, ukuran 3×3 sampai 10×10**.
> Draf 3: ukuran papan, aturan, jumlah tahap, dan tingkat kesulitan **diatur guru** (§1a).
> Semua angka permainan ada di `config/logic-rush.config.json`.

---

## 0. Ringkasan perubahan

| Draf 1 (Grand Final)                                 | Draf 2 (mandiri)                                                                                                       |
| ---------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| 2 pemain, 2 ponsel panitia, kursi A/B                | **1–40 pemain**, perangkat masing-masing (HP, tablet, Chromebook)                                                      |
| Bergantung pada MinX Arena (PIN, event_log, matches) | **Berdiri sendiri**: server, PIN, event log, dan tabel sendiri                                                         |
| Masuk lewat `/play/final?seat=A`                     | Masuk lewat **PIN sesi 6 digit** atau QR, lalu isi nama                                                                |
| Papan B = papan A yang ditransformasi                | Setiap pemain mendapat **papan dasar berbeda** dari kolam setara + transformasi + acak warna zona                      |
| Miniatur lawan diputar 180°                          | Papan perlombaan di proyektor (posisi semua pemain) + **sorot satu murid lewat WebRTC**                                |
| Mirror lewat `match:state`                           | **WebRTC DataChannel** dari ponsel murid ke penonton; WebSocket hanya untuk sinyal dan cadangan                        |
| Masalah 3 finalis vs 2 ponsel                        | Hilang dengan sendirinya. Mode **DUEL** tetap tersedia untuk Grand Final                                               |
| Ukuran tetap 4×4 → 5×5 → 6×6                         | **Diatur guru: 3×3 sampai 10×10**, 1–6 tahap, aturan arsir/diagonal per tahap, level mudah/sedang/sulit, plus 4 preset |
| Rush Gali Batu di dokumen yang sama                  | Di luar cakupan dokumen ini (tetap di dokumen Grand Final)                                                             |

---

## 1. Aturan permainan (bahasa SD)

Papan berukuran N × N (N = 3 sampai 10, diatur guru). Setiap kotak berwarna (zona) atau berarsir. Tugas: menaruh **N permata**.

Contoh di bawah adalah preset **SD Standar** (bawaan). Guru dapat mengubahnya di §1a.

| Kode | Aturan                                                 | Papan 1 (4×4)     | Papan 2 (5×5) | Papan 3 (6×6) |
| ---- | ------------------------------------------------------ | ----------------- | ------------- | ------------- |
| R1   | Setiap baris berisi satu permata                       | ya                | ya            | ya            |
| R2   | Setiap kolom berisi satu permata                       | ya                | ya            | ya            |
| R3   | Setiap zona warna berisi satu permata                  | ya                | ya            | ya            |
| R4   | Kotak arsir tidak boleh diisi                          | (tidak ada arsir) | ya            | ya            |
| R5   | Dua permata tidak boleh sejajar miring, sejauh apa pun | tidak             | tidak         | ya            |

- Setiap kali sebuah tahap menambah aturan dibanding tahap sebelumnya, muncul **Kartu Aturan Baru** selama 4 detik (sama untuk semua pemain).
- R5 tidak tersedia untuk 3×3 (tidak ada susunan 3 ratu); `validateStage()` menolaknya.
- R5 = aturan ratu catur, sehingga papan 3 adalah susunan N ratu yang juga memenuhi zona.
- Fungsi engine: `check(board, gems)` mengembalikan pelanggaran beserta kodenya (`row`, `col`, `zone`, `blocked`, `diag`) dan `RULE_TEXT` untuk teks anak ("satu baris", "sejajar miring", …).

---

## 1a. Pengaturan papan oleh guru

Di Konsol Operator, saat membuat sesi, guru membuka panel **Atur Papan**:

| Parameter        | Pilihan                   | Catatan                                                                            |
| ---------------- | ------------------------- | ---------------------------------------------------------------------------------- |
| Jumlah tahap     | 1–6                       | Tahap dikerjakan berurutan                                                         |
| Ukuran per tahap | 3×3 sampai 10×10          | `MIN_N = 3`, `MAX_N = 10` di engine                                                |
| R4 arsir         | nyala/mati per tahap      | Jumlah arsir otomatis ⌊N/2⌋ sampai N−1                                             |
| R5 diagonal      | nyala/mati per tahap      | Hanya N ≥ 4                                                                        |
| Level            | mudah / sedang / sulit    | Memilih papan di sekitar persentil 20% / 50% / 80% kesulitan kolam (`pickByLevel`) |
| Batas waktu      | otomatis atau manual      | Otomatis = `suggestMinutes(tahap)` (usulan per ukuran, ×1,2 jika diagonal)         |
| Bantuan          | jumlah per papan, penalti | Bawaan 1 per papan, 30 detik                                                       |

**Preset** (bisa langsung dipilih lalu disunting):

| Preset                                 | Tahap                                                               | Waktu otomatis              |
| -------------------------------------- | ------------------------------------------------------------------- | --------------------------- |
| Pemanasan (kelas 1–3)                  | 3×3 → 4×4 → 5×5, tanpa arsir/diagonal, mudah                        | ±4 menit                    |
| **SD Standar** (bawaan, sesuai Draf 1) | 4×4 → 5×5 + arsir → 6×6 + arsir + diagonal                          | ±9 menit (Draf 1: 15 menit) |
| SD Lanjut (kelas 5–6)                  | 5×5 → 6×6 → 7×7 → 8×8, arsir di semua tahap, diagonal mulai tahap 2 | ±25 menit                   |
| Tantangan (SMP / juara kelas)          | 6×6 → 8×8 → 10×10, semua aturan, sulit                              | ±30 menit                   |

Usulan waktu per papan (menit): 3×3 = 0,5 · 4×4 = 1 · 5×5 = 2,5 · 6×6 = 4,5 · 7×7 = 6 · 8×8 = 8 · 9×9 = 10 · 10×10 = 12. **Angka ini usulan dan wajib dikalibrasi dengan uji anak** (§16).

Setiap tahap dipetakan ke satu kolam bank: `poolKey({n, arsir, diagonal})` → misalnya `LR8ad`. Server memilih papan dengan `pickByLevel`, lalu membaginya ke pemain dengan `assignBoards`.

Konsol menampilkan peringatan ramah, misalnya: "9×9 ke atas sebaiknya di tablet/Chromebook" atau "waktu yang dipilih lebih pendek dari usulan".

---

## 2. Mode permainan

| Mode              | Untuk                              | Aturan menang                                                                                                                                                                                                         |
| ----------------- | ---------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **RUSH** (bawaan) | Satu kelas, 1–40 pemain            | Semua tahap dari pengaturan papan, berurutan; peringkat menurut §4                                                                                                                                                    |
| **MARATON**       | Latihan/kelas dengan waktu longgar | Papan tidak terbatas selama waktu yang dipilih; urutan mengikuti tahap, lalu tetap di tahap terakhir. Poin per papan `marathonPoints(N)`: 3→5, 4→10, 5→20, 6→35, 7→55, 8→80, 9→110, 10→145, dikurangi penalti bantuan |
| **DUEL**          | Grand Final (2 pemain)             | Sama dengan Draf 1: papan dasar **sama** + transformasi berbeda, best-of-3 dipegang operator                                                                                                                          |
| Latihan           | Saat menunggu di lobi              | Papan latihan 4×4 (LRP-xxx), tidak dinilai, tidak dicatat di peringkat                                                                                                                                                |

---

## 3. Alur sesi

1. **Buat sesi** (operator): pilih mode, batas waktu, bantuan on/off, persetujuan guru on/off. Server membuat **PIN 6 digit** + QR.
2. **Masuk** (murid): buka `/` → masukkan PIN → isi nama (atau pilih dari daftar hadir jika diunggah). Server memberi **token pemain** yang disimpan di `localStorage` untuk masuk ulang.
3. **Lobi**: daftar nama muncul di proyektor. Murid boleh mengerjakan papan latihan. Operator dapat mengeluarkan atau mengganti nama pemain.
4. **Briefing**: animasi aturan R1–R3 di proyektor dan ponsel.
5. **Hitung mundur** 3-2-1 dari `server_ts`. Papan 1 muncul serentak (`deadline_ts` dari server).
6. **Bermain**: saat permata = N dan tidak ada pelanggaran, ponsel otomatis mengirim `lr:finish`. Jika server menyatakan benar, papan berikutnya langsung muncul.
7. **Selesai** saat semua pemain menyelesaikan 3 papan, waktu habis, atau operator mengakhiri.
8. **Ungkap & penghargaan**: proyektor menampilkan podium, Rising Star, dan pembahasan satu papan pilihan operator.

---

## 4. Peringkat dan bantuan

Urutan penentuan (`rank(runs)` di engine, sudah diuji):

1. Papan selesai terbanyak.
2. Waktu efektif papan terakhir yang selesai paling kecil (waktu nyata + penalti bantuan).
3. Bantuan paling sedikit.
4. Jika masih sama: peringkat sama (tidak ada papan tambahan di mode RUSH; di mode DUEL berlaku papan tambahan 4×4 seperti Draf 1).

**Bantuan**: 1 kali per papan; server membuka satu permata benar yang terkunci (`hintCell`, memilih zona terkecil yang belum benar) dan menambah **penalti 30 detik**. Bisa dimatikan.

**Finish salah**: hanya terjadi jika ponsel dimodifikasi atau ada bug. Server menolak, mencatat `bad_finish_count`, dan tanpa penalti bawaan.

---

## 5. Keadilan untuk 40 pemain

Karena 40 murid duduk berdekatan, papan yang sama mudah dicontek. Solusinya tiga lapis:

1. **Papan dasar berbeda**: kolam 3×3–8×8 berisi 48 papan (3×3 tanpa arsir hanya 15, karena kemungkinannya memang terbatas), dan kolam 9×9–10×10 berisi 32 papan. Jika kolam lebih kecil dari jumlah pemain, papan dasar yang sama dipakai ulang dengan **simetri yang pasti berbeda** (maks 7 kali). Uji: 40 pemain di kolam 32 → semua pasangan (papan, simetri) unik.
2. **Transformasi**: satu dari 7 simetri non-identitas (putar/cermin).
3. **Acak warna dan huruf zona**.

Akibatnya, sorot satu murid di proyektor tidak membocorkan jawaban murid lain. Di mode DUEL, papan dasar sama (sesuai Draf 1), sehingga sorot proyektor ditunda sampai papan itu selesai.

---

## 6. Bank papan (alat offline)

### 6.1 Representasi

```
data/bank/index.json        daftar kolam: key, n, aturan, jumlah, rentang kesulitan, tier
data/bank/LR8ad.json        satu kolam: { key, n, set, aturan, opsi, papan: [...] }

papan: { id: "LR8ad-014", n: 8, rules: ["row","col","zone","blocked","diag"],
         zones: ["00011122", ...],   // '0'–'9' nomor zona, '#' arsir (dibaca basis-36)
         solution: [3,6,0,7,4,1,5,2],  // HANYA server
         tier: "T2", difficulty: 17, approved: false }
```

Kunci kolam: `LR{n}{set}` dengan set `x` (R1–R3), `a` (+ arsir), `d` (+ diagonal), `ad` (+ arsir + diagonal). Papan latihan ada di kolam `LRP`.

### 6.2 Langkah pembangkitan (`generateBoard`)

1. Solusi acak dengan backtracking (menolak diagonal jika R5 aktif).
2. Zona tumbuh dari N kotak solusi secara acak → setiap zona terhubung dan berisi tepat satu kotak solusi.
3. Kotak arsir: ⌊N/2⌋ sampai N−1 kotak non-solusi; ditolak jika memutus zona.
4. **Perbaikan zona (`repairUnique`)**, baru di Draf 3. Mulai 7×7, zona acak hampir selalu punya banyak jawaban. Selama solver menemukan jawaban kedua:
   - ambil satu kotak x milik jawaban kedua (bukan milik jawaban asli);
   - jika x di tepi zona → pindahkan ke zona tetangga; jika di tengah → zona tetangga **menggali jalur terpendek** ke x tanpa menyentuh kotak jawaban asli;
   - bagian zona asal yang terputus diserap zona tetangga (`absorbFragments`), sehingga semua zona tetap terhubung dan tetap berisi tepat satu kotak jawaban asli;
   - dengan R4 aktif, x juga boleh diarsir.
     Akibatnya jawaban kedua pasti patah, sementara jawaban asli tetap sah.
5. Hitung solusi (`solutions`) → hanya dipakai jika **tepat satu**.
6. Solver logika (`logicSolve`) → dibuang jika butuh menebak atau di luar tingkat yang diizinkan.
7. Buang kembaran, termasuk hasil putar/cermin (`canonical`).

### 6.3 Tingkat dan kesulitan

| Tingkat | Teknik                                                         |
| ------- | -------------------------------------------------------------- |
| T1      | Kandidat tunggal di baris/kolom/zona + coret akibat penempatan |
| T2      | Zona terkurung dalam satu garis (dan sebaliknya)               |
| T3      | k zona terkurung dalam k garis                                 |

`difficulty = langkah T1 + 3 × langkah T2 + 6 × langkah T3`. Tingkat maksimum: **T2 untuk 3×3–8×8**, **T3 untuk 9×9–10×10** (papan besar memang untuk tantangan).

| Ukuran  | Kolam       | Papan per kolam | Rentang kesulitan | Waktu bangkit (laptop biasa) |
| ------- | ----------- | --------------- | ----------------- | ---------------------------- |
| 3×3     | x, a        | 15 / 48         | 3                 | < 1 detik                    |
| 4×4–8×8 | x, a, d, ad | 48              | 4–29              | < 1 detik per kolam          |
| 9×9     | x, a, d, ad | 32              | 9–39              | 1–10 detik per kolam         |
| 10×10   | x, a, d, ad | 32              | 10–43             | 5–50 detik per kolam         |
| Latihan | LRP (4×4)   | 8               | 4                 | < 1 detik                    |

`node tools/lr-gen.js` membangkitkan kolam yang belum ada (`--sizes 7-8 --sets ad --force` untuk mengganti), dan `data/lembar_kunci_3-6.txt` berisi kunci 3×3–6×6 untuk mode kertas. Papan ditandai `approved: true` setelah dicoba manusia. Operator **diperingatkan** jika memakai kolam yang belum punya papan approved (bisa dilewati di mode uji). Untuk ukuran besar cukup menyetujui contoh beberapa papan per kolam.

---

## 7. Arsitektur

```
                 +--------------------------------------------------+
                 |  SERVER Logic Rush (laptop guru atau server)      |
                 |  Node 20 · Fastify · Socket.IO · SQLite           |
                 |  lr-engine (wasit)  ·  sinyal WebRTC  ·  relay    |
                 +------+------------------+------------------+------+
                        | WebSocket         | WebSocket        | WebSocket
          +-------------+--+   +-----------+----+   +---------+-------+
          | 40 × /play     |   | /display        |   | /operator       |
          | ponsel murid   |   | proyektor       |   | laptop guru     |
          +-------+--------+   +--------+--------+   +--------+--------+
                  |  WebRTC DataChannel (langsung, P2P)        |
                  +---------------> sorot 1 murid <------------+
```

| Lapisan              | Pilihan                                                                                                   |
| -------------------- | --------------------------------------------------------------------------------------------------------- |
| Monorepo             | pnpm workspaces, TypeScript strict                                                                        |
| `packages/lr-engine` | Port TS dari `engine/lr-engine.js` + `spectate-protocol.js` beserta semua tesnya (perilaku harus identik) |
| `apps/server`        | Node 20, Fastify, Socket.IO, better-sqlite3, zod, pino                                                    |
| `apps/web`           | Vite + React + TypeScript; papan = CSS Grid; Zustand                                                      |
| Transport pemain     | `SocketTransport` (normal) dan `LocalTransport` (cadangan layar tunggal seperti Draf 1 §12)               |
| WebRTC               | API browser bawaan (`RTCPeerConnection`, DataChannel); tanpa media                                        |

Prinsip dari Draf 1 tetap berlaku: engine murni dipakai bersama, papan dibuat sebelum acara, dan **server adalah wasit**.

---

## 8. PIN, identitas, dan sesi

| Hal                         | Aturan                                                                                                                |
| --------------------------- | --------------------------------------------------------------------------------------------------------------------- |
| PIN sesi                    | 6 digit acak, unik di antara sesi aktif, kedaluwarsa 180 menit                                                        |
| Brute force                 | Maks 10 percobaan salah per menit per IP/perangkat, lalu jeda 60 detik                                                |
| Nama                        | Maks 16 karakter, disaring kata kasar sederhana; nama kembar diberi akhiran (Rina, Rina 2)                            |
| Daftar hadir (opsional)     | Operator unggah CSV; murid memilih namanya, bukan mengetik                                                            |
| Persetujuan guru (opsional) | Pemain menunggu di "ruang tunggu" sampai disetujui                                                                    |
| Token pemain                | Acak 128-bit, disimpan di `localStorage`, dipakai untuk masuk ulang ke sesi yang sama                                 |
| Satu pemain satu perangkat  | Login kedua dengan token sama memutus perangkat lama dan dicatat                                                      |
| Batas                       | Ke-41 ditolak dengan pesan "Sesi penuh"                                                                               |
| PIN pengamat                | PIN kedua (opsional) untuk penonton non-operator, mis. guru lain atau orang tua di acara terbuka; hanya bisa menonton |

---

## 9. Model data (SQLite)

| Tabel            | Kolom penting                                                                                                                     |
| ---------------- | --------------------------------------------------------------------------------------------------------------------------------- |
| `sessions`       | id, pin, pin_pengamat, mode, status, config_json, seed, dibuat, mulai_ts, deadline_ts                                             |
| `players`        | id, session_id, nama, token_hash, device_id, status (lobby/playing/done/kicked), terhubung                                        |
| `boards`         | id, pool_key, n, rules, zones, solution, tier, difficulty, approved (diimpor dari `data/bank/`)                                   |
| `session_stages` | session_id, urutan, n, arsir, diagonal, level, pool_key                                                                           |
| `runs`           | id, session_id, player_id, seq, board_id, transform, zone_perm, started_at, finished_at, hints_used, penalty_ms, bad_finish_count |
| `moves`          | run_id, ts, r, c, op (gem/clear/x/unx/hint), dikirim berkelompok tiap 1 detik                                                     |
| `spectate_log`   | id, session_id, target_player_id, penonton (operator/display/pengamat), jalur (webrtc/relay), mulai, selesai                      |
| `flags`          | id, session_id, player_id, tipe, detail_json, status                                                                              |
| `event_log`      | seq, ts, tipe, aktor, payload_json, prev_hash, hash                                                                               |

Kejadian `event_log`: `lr.join`, `lr.board_sent`, `lr.hint`, `lr.finish_ok`, `lr.finish_bad`, `lr.board_not_unique`, `lr.end`, `rtc.spectate_start`, `rtc.spectate_end`, `rtc.fallback_relay`.

---

## 10. API dan event

### 10.1 REST (operator)

| Endpoint                                                       | Fungsi                                             |
| -------------------------------------------------------------- | -------------------------------------------------- |
| `POST /api/sessions`                                           | Buat sesi (mode, waktu, bantuan) → PIN + QR        |
| `POST /api/sessions/:id/roster`                                | Unggah daftar hadir (opsional)                     |
| `POST /api/sessions/:id/start` · `/pause` · `/resume` · `/end` | Kendali jalannya game (jeda membekukan jam server) |
| `POST /api/sessions/:id/players/:pid/kick`                     | Keluarkan pemain                                   |
| `GET /api/sessions/:id/results.csv`                            | Ekspor hasil                                       |
| `GET /api/sessions/:id/replay/:pid`                            | Langkah pemain untuk diputar ulang                 |
| `GET /api/boards`                                              | Bank papan (operator boleh melihat solusi)         |

### 10.2 WebSocket

| Event         | Arah                        | Isi                                                                           |
| ------------- | --------------------------- | ----------------------------------------------------------------------------- |
| `lr:join`     | pemain → server             | PIN, nama atau token                                                          |
| `lr:joined`   | server → pemain             | id, token, status sesi                                                        |
| `lr:board`    | server → satu pemain        | seq, papan **publik** (tanpa solusi, sudah ditransformasi), deadline_ts       |
| `lr:place`    | pemain → server             | langkah berkelompok tiap 1 detik (untuk replay)                               |
| `lr:progress` | pemain → server             | jumlah permata saat ini (maks 2×/detik)                                       |
| `lr:finish`   | pemain → server             | seq + daftar kotak permata                                                    |
| `lr:result`   | server → pemain             | ok + papan berikutnya, atau alasan ditolak                                    |
| `lr:hint`     | pemain ↔ server             | minta bantuan → satu kotak terkunci + penalti baru                            |
| `lr:race`     | server → proyektor/operator | ringkasan semua pemain: tahap, permata, bantuan, waktu efektif (tiap 1 detik) |
| `lr:end`      | server → semua              | peringkat akhir                                                               |
| `rtc:*`       | lihat §11                   | sinyal WebRTC                                                                 |

### 10.3 Pemeriksaan `lr:finish` di server

1. Aturan: permata = N dan `check()` lulus.
2. Solusi: `matchesSolution()` dengan solusi yang sudah ditransformasi.

Jika lapis 1 lulus tetapi lapis 2 gagal, server **tetap menerima** dan mencatat `lr.board_not_unique` (anak tidak dirugikan oleh bug papan). Finish untuk seq yang bukan papan aktif ditolak; pengiriman ganda diabaikan (idempoten per seq). Server memproses finish satu per satu dalam antrean per sesi; waktu `finished_at` diambil dari jam server.

---

## 11. Penonton per murid lewat WebRTC

### 11.1 Tujuan

Guru (atau proyektor, atau pengamat) bisa **menonton papan satu murid secara langsung**, langkah demi langkah, tanpa membebani server dan Wi-Fi sekolah. Pemakaiannya: memantau murid yang buntu, menayangkan "sorot" ke kelas, atau menilai cara berpikir untuk statistik.

### 11.2 Kenapa WebRTC

- Dengan 40 pemain, mengalirkan setiap ketukan semua murid lewat server tidak perlu. Biasanya hanya 1–4 murid yang sedang ditonton.
- DataChannel P2P memberi latensi paling rendah (umumnya < 50 ms di LAN) dan tidak menambah beban server.
- Yang dikirim adalah **keadaan permainan** (±100–600 byte), bukan video. Penonton menggambar ulang papan dengan komponen `BoardGrid` yang sama, sehingga hasilnya tajam di proyektor dan hemat baterai.
- **Tanpa kamera dan mikrofon**: aman untuk privasi anak; browser tidak meminta izin apa pun.

### 11.3 Topologi

```
Ponsel murid (pengirim) ──DataChannel "lr-spectate"──▶ Operator (/operator)
                        ──DataChannel "lr-spectate"──▶ Proyektor (/display, panel Sorot)
Maks 2 sambungan P2P per murid. Penonton ke-3 dan seterusnya → relay WebSocket.
Mozaik "Tonton Semua" (thumbnail 40 murid) → relay server tiap 2 detik, bukan WebRTC.
```

### 11.4 Alur sinyal (lewat Socket.IO yang sudah ada)

```
Penonton                      Server                         Ponsel murid
   | rtc:watch {pid}  ───────▶ | cek hak (operator/display/   |
   |                           |  PIN pengamat), cek kuota ─▶ | rtc:viewer-request {vid}
   |                           |                              | buat RTCPeerConnection,
   |                           | ◀──────────── rtc:offer {sdp}| createDataChannel
   | ◀────── rtc:offer {sdp}   |                              |
   | rtc:answer {sdp} ───────▶ | ───────────── rtc:answer ──▶ |
   | rtc:ice ⇄ (dua arah) ⇄    | ⇄ rtc:ice ⇄                  |
   | ◀═══════════ DataChannel terbuka ═════════════════════▶ |
   | ◀═══ snap, lalu mv/stage/done (spectate-protocol) ═════ |
   | rtc:unwatch {pid} ──────▶ | ───────── rtc:viewer-gone ─▶ | tutup koneksi
```

- DataChannel: `ordered: true`, reliable. Satu channel per penonton.
- Pengirim mengirim `snap` saat channel terbuka, lalu `mv` setiap ketukan, `stage` saat papan berganti, `done` saat selesai, dan `ping` tiap 5 detik.
- Penonton memakai `applyMsg()`. Jika nomor urut melompat, penonton mengirim `need-snap` dan pengirim membalas snapshot baru (diuji).
- Pesan divalidasi `decode()` (bentuk dan ukuran ≤ 2 KB); pesan rusak diabaikan.

### 11.5 Jaringan

| Mode                       | ICE                                                                                                                                                      | Catatan                                                                                                                                    |
| -------------------------- | -------------------------------------------------------------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------ |
| LAN/hotspot tanpa internet | `iceServers: []` (kandidat host)                                                                                                                         | Berhasil jika perangkat satu subnet. Beberapa hotspot memblok komunikasi antar-klien (_client isolation_); saat itu dipakai relay otomatis |
| Online/dari rumah          | STUN + **TURN** (coturn) dari variabel lingkungan                                                                                                        | Tanpa TURN, sebagian jaringan seluler gagal P2P                                                                                            |
| Cadangan                   | Jika ICE belum terhubung dalam **5 detik**, penonton beralih ke `spectate:relay`: server meneruskan pesan protokol yang sama dari ponsel lewat WebSocket | Dicatat `rtc.fallback_relay`                                                                                                               |

### 11.6 Aturan privasi & keadilan

- Ponsel murid menampilkan ikon **👁 sedang ditonton** selama ada penonton (bisa dimatikan guru, bawaan menyala).
- Semua sesi menonton dicatat di `spectate_log`.
- Proyektor hanya boleh menyorot ketika `papan_dasar_berbeda_per_pemain = true` (mode RUSH/MARATON). Di mode DUEL, sorot proyektor baru tampil setelah papan itu selesai.
- Data yang dikirim ponsel hanya untuk ditampilkan. Keadaan resmi tetap di server (`moves` + `lr:finish`). Jika ponsel dimodifikasi untuk mengirim tampilan palsu, hasil lomba tidak berubah.

---

## 12. Front end

### 12.1 Layar pemain `/play` (mobile-first)

```
+--------------------------------+
| Rina      Papan 2/3   👁  09:41 |
| Kartu Aturan Baru: kotak arsir  |  <- 4 detik saat ganti papan
+--------------------------------+
|                                |
|    PAPAN N × N  (kotak ≥ 44 px) |
|    warna zona + huruf + arsir   |
|                                |
+--------------------------------+
| [Batal] [✕ Tanda] [💡 Bantuan] |
+--------------------------------+
```

- Ketuk kotak = permata; ketuk lagi = angkat. Mode ✕ menandai kotak yang pasti kosong.
- **Ukuran kotak adaptif**: `sisi = ⌊min(lebar, tinggi × 0,72) ÷ N⌋`, minimal 30 px. Di HP 360 px: 3×3–6×6 ≥ 52 px, 8×8 ±42 px, 10×10 ±33 px. Jika sisi < 36 px, **Mode Zoom** aktif: cubit/geser untuk memperbesar, dan ketukan di area padat menampilkan kaca pembesar 3×3 kotak agar tidak salah ketuk. Untuk 9×9 ke atas, layar menyarankan posisi lanskap.
- Hingga 10 zona: palet 10 warna aman untuk buta warna (Okabe–Ito 8 + 2 tambahan) **ditambah** huruf zona A–J di sudut kotak dan arsir garis miring, sehingga tidak bergantung pada warna saja.
- Sorotan pelanggaran memakai `check()`, berupa garis merah dan teks "satu baris" / "sejajar miring", tanpa membocorkan solusi.
- Warna palet Okabe–Ito + huruf zona di sudut + arsir garis miring, sehingga tetap terbaca oleh murid buta warna.
- Selesai otomatis: "memeriksa…", lalu animasi singkat dan papan berikutnya.
- Timer dari `deadline_ts` server.
- Komponen: `BoardGrid`, `Cell`, `ZoneLegend`, `RuleCard`, `Timer`, `HintButton`, `ConflictOverlay`, `WatchBadge`, `RtcSender`.

### 12.2 Proyektor `/display`

- **Papan Perlombaan**: 40 avatar di lintasan Start → Papan 1 → Papan 2 → Papan 3 → Finis, ditambah jumlah murid di setiap tahap.
- **Top 10** berdasarkan `rank()`. Peringkat bawah tidak ditampilkan.
- **Panel Sorot**: papan langsung satu murid lewat WebRTC (nama, tahap, waktu), dengan bingkai "LANGSUNG".
- Timer besar, PIN dan QR selama lobi, lalu podium di akhir.

### 12.3 Operator `/operator`

- Buat sesi, tampilkan PIN, setujui/keluarkan pemain, mulai/jeda/akhiri.
- Tabel 40 pemain: tahap, permata, bantuan, waktu efektif, koneksi, RTT, bendera.
- Tombol **👁 Tonton** per baris (WebRTC), **Sorot ke proyektor**, dan **Tonton Semua** (mozaik relay 0,5 Hz).
- Panel **Multi-tonton 2×2**: empat murid sekaligus lewat WebRTC.
- Replay pemain setelah game (dari `moves`) dan ekspor CSV.

### 12.4 Pengamat `/watch`

Masuk dengan PIN pengamat, hanya bisa memilih satu murid untuk ditonton (jika diizinkan), tanpa akses kendali.

---

## 13. Ketahanan

| Risiko                        | Penanganan                                                                                                                                                   |
| ----------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| Ponsel putus                  | Klien menyimpan token, seq, dan susunan permata. Saat tersambung kembali, server mengirim snapshot dari `moves`. Jam tidak berhenti kecuali operator menjeda |
| Penonton putus                | WebRTC ditutup; penonton membuka ulang otomatis sekali, lalu beralih ke relay                                                                                |
| 40 perangkat di Wi-Fi sekolah | Pesan pemain kecil dan jarang (progres 2×/detik, langkah per detik). Gunakan router/hotspot sendiri bila memungkinkan                                        |
| Server restart                | Status dibangun ulang dari `runs`, `moves`, dan `event_log`                                                                                                  |
| Papan cacat                   | `lr.board_not_unique` dicatat; operator dapat menukar papan sebelum mulai                                                                                    |
| Semua jaringan mati           | Mode **layar tunggal** (`LocalTransport`) dan **mode kertas** dari `data/lembar_kunci_3-6.txt` (Draf 1 §12)                                                  |

---

## 14. Anti-curang

| Lapis     | Mekanisme                                                                                                                                    |
| --------- | -------------------------------------------------------------------------------------------------------------------------------------------- |
| Soal      | Papan dasar berbeda + simetri + acak zona untuk setiap pemain                                                                                |
| Protokol  | Solusi tidak pernah dikirim (kecuali satu kotak bantuan); server wasit; idempoten per seq                                                    |
| Identitas | PIN + token + satu perangkat aktif; batas percobaan PIN                                                                                      |
| Deteksi   | Fokus hilang > 1,5 detik (3× → bendera); finish lebih cepat dari ambang per tahap (5/10/15 detik) → bendera; finish salah berulang → bendera |
| Tayangan  | Proyektor hanya menampilkan ringkasan, kecuali panel Sorot yang aman karena papan setiap pemain berbeda                                      |
| Audit     | `event_log` berantai hash, `moves` untuk replay, `spectate_log`                                                                              |

---

## 15. Statistik

Per murid: waktu per papan, bantuan, finish salah, jumlah ketukan, **efisiensi** = N ÷ permata yang pernah ditaruh, pemakaian ✕, dan jenis pelanggaran yang paling sering dibuat (baris/kolom/zona/arsir/diagonal).
Per papan dasar: median waktu kelas dan persentase yang memakai bantuan. Papan yang jauh lebih lambat dari papan lain dalam pitanya ditandai untuk dibuang dari bank, sehingga keadilan antar-pemain terjaga dari sesi ke sesi.

---

## 16. Rencana uji & Go/No-Go

Otomatis (wajib hijau sebelum acara):

- `node engine/lr-engine.test.js` (342.575 pemeriksaan, ±3 detik): pemeriksa R1–R5, **seluruh 1.287 papan** unik dan bisa diselesaikan dengan logika, setiap kombinasi ukuran × aturan tersedia, 8 simetri × acak zona, 1.000 papan acak 4×4–8×8 + papan acak 3×3 dan 9×9–10×10, bantuan, replay, pembagian 40 pemain (termasuk kolam lebih kecil dari pemain), validasi parameter guru, level mudah ≤ sedang ≤ sulit, peringkat.
- `node engine/spectate-protocol.test.js`: validasi pesan (koordinat 0–9), snapshot 10×10 penuh < 2 KB, tampilan penonton = keadaan pemain, deteksi pesan hilang, duplikat, pergantian papan.
- Uji server: payload `lr:board` tanpa `solution`; finish idempoten; antrean finish urut.
- `pnpm sim`: 40 bot bermain RUSH penuh (dipercepat), 4 penonton WebRTC aktif.

| Uji Go/No-Go                            | Lulus jika                                                                          |
| --------------------------------------- | ----------------------------------------------------------------------------------- |
| 40 pemain nyata atau bot di Wi-Fi acara | Tidak ada desinkronisasi; median `lr:finish` → papan berikutnya < 100 ms            |
| Putus Wi-Fi satu ponsel 10 detik        | Permata dan papan aktif pulih                                                       |
| WebRTC di hotspot tanpa internet        | Sorot tersambung < 3 detik, atau beralih ke relay < 6 detik                         |
| Multi-tonton 2×2 di laptop operator     | 4 papan bergerak lancar, CPU laptop < 50%                                           |
| Papan terpilih dicoba anak seusia       | Waktu nyata mendekati usulan §1a (perbarui `TARGET_MENIT` di engine dari hasil uji) |
| Papan 10×10 di HP 360 px                | Tidak ada salah ketuk berulang dengan Mode Zoom                                     |

---

## 17. Milestone (untuk Claude Code)

| Kode | Pekerjaan                                                                                                                                                                        | Selesai jika                                                               |
| ---- | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------- |
| M0   | Monorepo; port `lr-engine` + `spectate-protocol` ke TS beserta tes                                                                                                               | Semua tes engine lulus                                                     |
| M1   | Sesi, PIN 6 digit, QR, join nama/daftar hadir, token, batas 40, brute-force guard; **panel Atur Papan** (preset, 1–6 tahap, ukuran 3–10, arsir, diagonal, level, waktu otomatis) | 40 bot bisa masuk; ke-41 ditolak; `validateStage` dipakai di UI dan server |
| M2   | Muat `data/bank/` ke tabel `boards`; run per pemain: `pickByLevel` + `assignBoards`, `lr:board`, `lr:finish` (dua lapis), bantuan, deadline, jeda                                | Uji server lulus; payload tanpa solusi                                     |
| M3   | Layar pemain: papan adaptif 3×3–10×10 + Mode Zoom, ketuk, ✕, Batal, sorotan, kartu aturan baru, selesai otomatis                                                                 | 3×3–8×8 nyaman di HP 360 px; 10×10 dapat dimainkan dengan zoom             |
| M4   | Proyektor: lobi PIN/QR, papan perlombaan, top 10, podium                                                                                                                         | Terbaca dari 8 m                                                           |
| M5   | Operator: tabel 40 pemain, kendali sesi, kick, replay, ekspor CSV                                                                                                                | Semua tombol §12.3 berfungsi kecuali tonton                                |
| M6   | **WebRTC**: sinyal `rtc:*`, `RtcSender` di ponsel, `RtcViewer` di operator/proyektor, `spectate-protocol`, kuota 2 P2P, ikon 👁, log                                              | Tonton satu murid di LAN tanpa internet                                    |
| M7   | Cadangan relay WebSocket, mozaik Tonton Semua, multi-tonton 2×2, PIN pengamat `/watch`, TURN untuk mode online                                                                   | Lulus baris WebRTC Go/No-Go                                                |
| M8   | Mode MARATON dan DUEL; layar tunggal `LocalTransport`                                                                                                                            | Ketiga mode dapat dimainkan                                                |
| M9   | Anti-curang, `event_log` berantai hash, statistik, `pnpm sim` 40 bot + 4 penonton                                                                                                | Semua tabel Go/No-Go lulus                                                 |

Jika waktu mepet, pangkas dengan urutan: mozaik Tonton Semua → PIN pengamat → mode MARATON → mode ✕. **Jangan pangkas** uji keunikan papan, uji transformasi, server sebagai wasit, dan uji manusia.

---

## Lampiran A — Pertanyaan terbuka dari Draf 1 yang terjawab

1. _Tiga finalis, dua ponsel_: tidak relevan untuk game mandiri; mode DUEL tetap tersedia untuk Grand Final dan setiap finalis bisa memakai perangkat sendiri.
2. _"Tiga kali"_: tetap tiga papan berurutan dengan aturan bertambah (mode RUSH).
3. _Bantuan_: aktif, 1 per papan, penalti 30 detik (bisa dimatikan).
4. _Skrip pembangkit dan bank papan_: sudah dibuat (`tools/lr-gen.js`, `data/bank/`), 3×3–10×10, tinggal persetujuan manusia (`approved`).

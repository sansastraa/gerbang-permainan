#!/usr/bin/env node
// Alat offline: bangkitkan bank papan Logic Rush untuk ukuran 3–10 dan 4 kombinasi aturan (3×3 tanpa diagonal).
//   node tools/lr-gen.js                         → semua kolam yang belum ada
//   node tools/lr-gen.js --sizes 9-10 --sets x,ad --force
//   node tools/lr-gen.js --index                 → hanya membangun ulang index + lembar kunci
// Kombinasi aturan: x = R1–R3, a = + arsir (R4), d = + diagonal (R5), ad = + arsir + diagonal
// Setiap papan: jawaban tunggal, bisa diselesaikan solver logika tanpa menebak, tidak kembar (termasuk putar/cermin).
const E = require("../shared/reference/lr-engine.cjs");
const fs = require("fs"),
  path = require("path");
const args = process.argv.slice(2),
  arg = (k, d) => {
    const i = args.indexOf(k);
    return i >= 0 ? args[i + 1] : d;
  };
const DIR = path.join(__dirname, "..", "data", "bank");
fs.mkdirSync(DIR, { recursive: true });
const SEED = arg("--seed", "LR-BANK-2026");
const [s0, s1] = arg("--sizes", `${E.MIN_N}-${E.MAX_N}`).split("-").map(Number);
const SETS = arg("--sets", "x,a,d,ad").split(",");
const FORCE = args.includes("--force");
const COUNT = (n) => +arg("--count", n <= 8 ? 48 : 32);
const MAX_TIER = (n) => (n <= 8 ? 2 : 3);
const SET_LABEL = { x: "R1–R3", a: "R1–R4 (+ arsir)", d: "R1–R3 + R5 (diagonal)", ad: "R1–R5 (+ arsir + diagonal)" };

function buildPool(n, set) {
  const stage = { n, arsir: set.includes("a"), diagonal: set.includes("d") };
  const key = E.poolKey(stage),
    file = path.join(DIR, key + ".json");
  if (stage.diagonal && n < 4) return; // tidak ada susunan 3 ratu
  if (fs.existsSync(file) && !FORCE) return;
  const opt = {
    n,
    rules: E.rulesFor(stage),
    blocked: [Math.floor(n / 2), n - 1],
    maxTier: MAX_TIER(n),
    minTier: 1,
    maxAttempts: 400,
  };
  const want = COUNT(n),
    seen = new Set(),
    list = [];
  let i = 0;
  const t0 = Date.now();
  while (list.length < want && i <= want * 50) {
    let b;
    try {
      b = E.generateBoard(`${SEED}|${key}|${i++}`, { ...opt, maxAttempts: n === 3 ? 30 : opt.maxAttempts });
    } catch (e) {
      continue;
    }
    const c = E.canonical(b);
    if (seen.has(c)) continue;
    seen.add(c);
    list.push({
      id: `${key}-${String(list.length + 1).padStart(3, "0")}`,
      n,
      rules: b.rules,
      zones: b.zones,
      solution: b.solution,
      tier: b.tier,
      difficulty: b.difficulty,
      approved: false,
    });
  }
  if (!list.length) throw new Error("Kolam " + key + " kosong");
  fs.writeFileSync(file, JSON.stringify({ key, n, set, aturan: SET_LABEL[set], opsi: opt, papan: list }));
  const d = list.map((b) => b.difficulty);
  console.log(
    `${key.padEnd(7)} ${SET_LABEL[set].padEnd(28)} ${list.length} papan, kesulitan ${Math.min(...d)}–${Math.max(...d)}, ${((Date.now() - t0) / 1000).toFixed(1)} dtk`,
  );
}

if (!args.includes("--index")) {
  for (let n = s0; n <= s1; n++) for (const set of SETS) buildPool(n, set);
  const lp = path.join(DIR, "LRP.json");
  if (!fs.existsSync(lp) || FORCE) {
    const list = [];
    for (let i = 0; list.length < 8; i++) {
      const b = E.generateBoard(`${SEED}|LRP|${i}`, { n: 4, rules: ["row", "col", "zone"], maxTier: 1 });
      list.push({
        id: `LRP-${String(list.length + 1).padStart(3, "0")}`,
        n: 4,
        rules: b.rules,
        zones: b.zones,
        solution: b.solution,
        tier: b.tier,
        difficulty: b.difficulty,
        approved: false,
      });
    }
    fs.writeFileSync(
      lp,
      JSON.stringify({ key: "LRP", n: 4, set: "x", aturan: "Latihan (tidak dinilai)", papan: list }),
    );
  }
}

// index + lembar kunci (lembar kunci teks hanya untuk ukuran ≤ 6 dan latihan; mode kertas papan besar dicetak dari aplikasi)
const files = fs
  .readdirSync(DIR)
  .filter((f) => /^LR.*\.json$/.test(f))
  .sort((a, b) => a.localeCompare(b, "en", { numeric: true }));
const index = {
  meta: {
    nama: "Logic Rush — Indeks Bank Papan",
    seed: SEED,
    ukuran: `${E.MIN_N}–${E.MAX_N}`,
    catatan: "RAHASIA SERVER: setiap kolam berisi solusi.",
  },
  kolam: [],
};
const sheet = ["LOGIC RUSH — LEMBAR KUNCI (RAHASIA)", ""];
for (const f of files) {
  const p = JSON.parse(fs.readFileSync(path.join(DIR, f), "utf8")),
    d = p.papan.map((b) => b.difficulty);
  index.kolam.push({
    key: p.key,
    file: f,
    n: p.n,
    set: p.set,
    aturan: p.aturan,
    jumlah: p.papan.length,
    kesulitan: [Math.min(...d), Math.max(...d)],
    tier: [...new Set(p.papan.map((b) => b.tier))].sort(),
  });
  if (p.n <= 6 || p.key === "LRP") {
    sheet.push(`== ${p.key} — ${p.aturan} ==`);
    for (const b of p.papan) {
      sheet.push(`${b.id}  ${b.tier}  kesulitan ${b.difficulty}`);
      b.zones.forEach((row, r) =>
        sheet.push(
          "  " +
            row
              .split("")
              .map((ch, c) => (b.solution[r] === c ? "[" + ch + "]" : " " + ch + " "))
              .join(""),
        ),
      );
      sheet.push("");
    }
  }
}
fs.writeFileSync(path.join(DIR, "index.json"), JSON.stringify(index, null, 1));
fs.writeFileSync(path.join(__dirname, "..", "data", "lembar_kunci_3-6.txt"), sheet.join("\n"));
console.log(`index: ${index.kolam.length} kolam, ${index.kolam.reduce((a, k) => a + k.jumlah, 0)} papan`);

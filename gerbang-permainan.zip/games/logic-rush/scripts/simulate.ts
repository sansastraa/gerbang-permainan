// Simulasi bot: kelas penuh bermain turnamen 2–3 pemain dengan penonton. Jalankan: npm run sim -- --bots 9 --watchers 4
// Bot menyelesaikan papan dengan solver engine dari papan PUBLIK (seperti anak yang bernalar), mengirim langkah lewat lr:sp.
import { io as ioc } from "socket.io-client";
import type { Socket } from "socket.io-client";
import { EventLog } from "../server/src/util";
import { buatApp } from "../server/src/app";
import { defaultSettings, settingsSchema, solutions, spectate as SP, check } from "@logic-rush/shared";
import type { BoardKirim, Rule } from "@logic-rush/shared";

const arg = (k: string, d: number): number => {
  const i = process.argv.indexOf("--" + k);
  return i >= 0 ? Number(process.argv[i + 1]) : d;
};
const BOTS = arg("bots", 9);
const WATCHERS = arg("watchers", 4);
const UKURAN = arg("size", 3);
const MASSAL = process.argv.includes("--massal");
const HOST_PIN = "sim-pin-guru";

const tidur = (ms: number) => new Promise((r) => setTimeout(r, ms));
const tanya = <T = Record<string, unknown>>(s: Socket, ev: string, p?: unknown): Promise<T> =>
  new Promise((r) => s.emit(ev, p, (x: T) => r(x)));
const kons = (base: string, auth: Record<string, unknown>): Promise<Socket> =>
  new Promise((res, rej) => {
    const s = ioc(base, { auth, transports: ["websocket"], forceNew: true, reconnection: false });
    s.on("connect", () => res(s));
    s.on("connect_error", rej);
  });

let bocor = 0;
const gagal: string[] = [];
const cek = (c: unknown, m: string) => {
  if (!c) gagal.push(m);
};

async function main() {
  const t0 = Date.now();
  const app = buatApp({ hostPin: HOST_PIN });
  const port = await app.listen(0, "127.0.0.1");
  const base = `http://127.0.0.1:${port}`;
  const settings = settingsSchema.parse({
    ...defaultSettings(),
    tahap: [
      { n: 4, arsir: false, diagonal: false, level: "mudah" },
      { n: 5, arsir: true, diagonal: false, level: "sedang" },
    ],
    format: MASSAL ? "massal" : "laga",
    sorotDetik: 3,
    papanPerGame: 2,
    ukuranPertandingan: Math.min(3, UKURAN),
    bestOf: MASSAL ? 1 : 3,
    hitungMundurDetik: 0,
    rehatDetik: 3,
    batasWaktuDetik: 60,
    grasiSetelahPemenangDetik: 10,
  });
  const r = await fetch(base + "/api/sessions", {
    method: "POST",
    headers: { "content-type": "application/json", "x-host-token": HOST_PIN },
    body: JSON.stringify({ settings }),
  });
  const ses = (await r.json()) as { id: string; pin: string };
  const host = await kons(base, { peran: "host", hostToken: HOST_PIN, sesiId: ses.id });

  // penonton: hitung pesan & periksa kebocoran solusi di semua kejadian
  const penonton: Socket[] = [];
  const hitung = { sp: 0 };
  const sorotPid = new Set<string>();
  for (let i = 0; i < WATCHERS; i++) {
    const w = await kons(base, { peran: i === 0 ? "obs" : "penonton", pin: ses.pin });
    w.onAny((_ev, p) => {
      if (/"solution"/.test(JSON.stringify(p ?? null))) bocor++;
    });
    w.on("lr:sp", (p: { pid: string }) => (hitung.sp++, sorotPid.add(p.pid)));
    await tanya(w, "lr:tonton");
    penonton.push(w);
  }

  // bot pemain
  type Bot = { sock: Socket; pid: string; nama: string; kerja: boolean };
  const bots: Bot[] = [];
  for (let i = 1; i <= BOTS; i++) {
    const sock = await kons(base, { peran: "pemain", pin: ses.pin });
    const j = await tanya<{ ok: boolean; pid: string }>(sock, "lr:join", { nama: "Bot" + i });
    cek(j.ok, "bot " + i + " masuk");
    const bot: Bot = { sock, pid: j.pid, nama: "Bot" + i, kerja: false };
    sock.on("lr:panggil", (p: { matchId: string }) => void tanya(sock, "lr:siap", { matchId: p.matchId }));
    sock.on("lr:board", (b: BoardKirim) => {
      if (/"solution"/.test(JSON.stringify(b))) bocor++;
      void mainkan(bot, b);
    });
    bots.push(bot);
  }
  // pemain ke-(maks+1) ditolak? uji batas 40 dilakukan di tes unit; di sini cukup kapasitas
  async function mainkan(bot: Bot, b: BoardKirim) {
    const sol = solutions({ n: b.board.n, rules: b.board.rules as Rule[], zones: b.board.zones }, 1)[0];
    const tx = SP.makeSender();
    for (let i = 0; i <= b.lastS; i++) tx.next({ t: "ping" });
    const gems = sol.map((c, r) => ({ r, c }));
    const kecepatan = (MASSAL ? 700 : 80) + (Number(bot.nama.slice(3)) % 5) * 40;
    for (const g of gems) {
      await tidur(kecepatan);
      bot.sock.emit("lr:sp", tx.next({ t: "mv", op: "gem", r: g.r, c: g.c, at: 0 }));
    }
    cek(check({ n: b.board.n, rules: b.board.rules as Rule[], zones: b.board.zones }, gems).complete, "solusi bot sah");
    const res = await tanya<{ ok: boolean }>(bot.sock, "lr:finish", { matchId: b.matchId, gameNo: b.gameNo, gems });
    cek(res.ok, `finish ${bot.nama} game ${b.gameNo}`);
  }

  const antre = await tanya<{ ok: boolean; jumlah: number }>(host, "host:antrean", {});
  cek(antre.ok, "antrean dibuat");
  let babak = 1;
  let pertandingan = 0;
  for (;;) {
    const state = app.reg.get(ses.id)!.statePublik();
    const belum = state.matches.filter((m) => m.babak === babak && m.status === "antre");
    for (const m of belum) {
      cek((await tanya<{ ok: boolean }>(host, "host:panggil", { mid: m.id })).ok, "panggil " + m.id);
      await tidur(100);
      cek((await tanya<{ ok: boolean }>(host, "host:mulai", { mid: m.id })).ok, "mulai " + m.id);
      for (let w = 0; w < 600; w++) {
        await tidur(100);
        const st = app.reg
          .get(ses.id)!
          .statePublik()
          .matches.find((x) => x.id === m.id)!;
        if (st.status === "selesai") break;
      }
      const hasil = app.reg
        .get(ses.id)!
        .statePublik()
        .matches.find((x) => x.id === m.id)!;
      cek(hasil.status === "selesai", "pertandingan selesai " + m.id);
      cek(
        MASSAL ? hasil.pemain.length === BOTS : hasil.pemain.length >= 2 && hasil.pemain.length <= UKURAN,
        "ukuran pertandingan",
      );
      pertandingan++;
    }
    const bb = await tanya<{ ok: boolean; jumlah: number; juara?: string | null }>(host, "host:babak-berikut", {});
    if (!bb.ok) {
      gagal.push("babak berikut: " + JSON.stringify(bb));
      break;
    }
    if (bb.juara !== undefined) {
      console.log(`  Juara: ${app.reg.get(ses.id)!.getPemain(bb.juara as string)?.nama}`);
      break;
    }
    babak++;
  }
  await tanya(host, "host:selesai-sesi");
  const ring = app.reg.get(ses.id)!.ringkasan();
  cek(ring.selesai && ring.siswa.length === BOTS, "ringkasan memuat semua bot");
  cek(EventLog.verify(app.reg.get(ses.id)!.log.rows), "rantai hash log utuh");
  cek(bocor === 0, `tidak ada kebocoran solusi (bocor: ${bocor})`);
  cek(hitung.sp > 0, "penonton menerima langkah");
  const stat = app.reg.get(ses.id)!.statistik();
  cek(stat.validasi.total >= BOTS && stat.validasi.salah === 0, "statistik validasi tercatat");
  if (MASSAL) cek(sorotPid.size >= 2, `sorotan bergilir (pemain tersorot: ${sorotPid.size})`);
  console.log(
    `  validasi: ${stat.validasi.total} (benar ${stat.validasi.benar}, salah ${stat.validasi.salah}) · papan terstatistik: ${stat.papan.length}`,
  );

  console.log(
    `\nSIMULASI: ${BOTS} bot, ${WATCHERS} penonton, ${pertandingan} pertandingan, ${babak} babak, ${((Date.now() - t0) / 1000).toFixed(1)} dtk`,
  );
  console.log(
    `  pesan spectate diterima penonton: ${hitung.sp}   ·   kejadian log: ${app.reg.get(ses.id)!.log.rows.length}`,
  );
  console.log(
    "  Papan skor:",
    ring.siswa
      .slice(0, 3)
      .map((s) => `${s.peringkat}. ${s.nama} (${s.skor})`)
      .join("  "),
  );
  [host, ...penonton, ...bots.map((b) => b.sock)].forEach((s) => s.close());
  await app.tutup();
  if (gagal.length) {
    console.error("\nGAGAL:\n - " + gagal.join("\n - "));
    process.exit(1);
  }
  console.log("\nSEMUA LULUS");
  process.exit(0);
}
void main();

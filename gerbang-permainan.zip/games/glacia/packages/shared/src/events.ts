import { z } from 'zod';

/** Client → server payload schemas (namespace /game). Clients never send trusted time. */
export const JoinSchema = z.object({
  pin: z.string().regex(/^\d{6}$/),
  deviceToken: z.string().min(8).max(100),
});
export const PickNameSchema = z.object({ studentId: z.string().min(1).max(100) });
export const HostAuthSchema = z.object({ token: z.string().min(1).max(2000), roomId: z.string().min(1).max(100) });
export const DisplayJoinSchema = z.object({ pin: z.string().regex(/^\d{6}$/) });
export const CategoryPickSchema = z.object({ categoryId: z.number().int().min(1).max(15) });
export const CardAnswerSchema = z.object({ cardId: z.string().uuid(), hidden: z.boolean().optional() });
export const VisibilitySchema = z.object({ hidden: z.boolean() });
export const HostKickSchema = z.object({ playerId: z.string().min(1) });
export const EmptySchema = z.object({}).passthrough();

export const DISPLAY_MODES = ['NAME', 'INITIALS', 'COUNT_ONLY'] as const;
export type DisplayMode = (typeof DISPLAY_MODES)[number];

export type RoomStatus =
  | 'CREATED'
  | 'LOBBY'
  | 'SPIN'
  | 'PICK'
  | 'COUNTDOWN'
  | 'RUNNING'
  | 'ROUND_RESULT'
  | 'FINAL'
  | 'DONE'
  | 'PAUSED';

export type CheatFlagType =
  | 'TAB_BLUR'
  | 'ANSWER_WHILE_HIDDEN'
  | 'BLUR_STREAK_DQ'
  | 'TOO_FAST'
  | 'UNIFORM_TIMING'
  | 'MULTI_DEVICE'
  | 'BURST';

/** Field names that must never appear in a message sent to a client while a round is running. */
export const FORBIDDEN_KEYS = ['isCorrect', 'questionId', 'unitDigit', 'parity', 'result', 'explanation'] as const;
/** Extra names forbidden in messages visible to other players/displays (no evidence about a cheater). */
export const EVIDENCE_KEYS = ['streak', 'armedUntil', 'evidence', 'hiddenMs'] as const;

/** Recursively collects forbidden key paths in any JSON-like value. */
export function findForbiddenKeys(value: unknown, keys: readonly string[] = FORBIDDEN_KEYS, path = '$'): string[] {
  const found: string[] = [];
  if (Array.isArray(value)) {
    value.forEach((v, i) => found.push(...findForbiddenKeys(v, keys, `${path}[${i}]`)));
  } else if (value && typeof value === 'object') {
    for (const [k, v] of Object.entries(value as Record<string, unknown>)) {
      if (keys.includes(k)) found.push(`${path}.${k}`);
      found.push(...findForbiddenKeys(v, keys, `${path}.${k}`));
    }
  }
  return found;
}

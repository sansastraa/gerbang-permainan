import { createRng, randomSeed } from './rng';

export interface WheelPlayer {
  playerId: string;
  name: string;
  online: boolean;
  hasPicked: boolean;
  disqualified: boolean;
  blacklisted?: boolean;
}

export interface Wheel {
  segments: { playerId: string; name: string }[];
  /** true when everybody active had already picked, so a new cycle began */
  cycleReset: boolean;
}

/** Blueprint 7.6: the wheel has exactly one segment per eligible player. */
export function buildWheel(players: readonly WheelPlayer[]): Wheel {
  const active = players.filter((p) => p.online && !p.disqualified && !p.blacklisted);
  const eligible = active.filter((p) => !p.hasPicked);
  const useAll = eligible.length === 0;
  const list = useAll ? active : eligible;
  return {
    segments: list.map((p) => ({ playerId: p.playerId, name: p.name })),
    cycleReset: useAll && active.length > 0,
  };
}

export interface SpinOutcome {
  pickedPlayerId: string;
  rngSeed: string;
  animSeed: string;
}

/** Winner is decided by the server RNG first; animation only follows. */
export function drawSpin(segments: readonly { playerId: string }[], rngSeed: string = randomSeed()): SpinOutcome {
  if (segments.length === 0) throw new Error('empty wheel');
  const rng = createRng(rngSeed);
  const picked = rng.pick(segments);
  return { pickedPlayerId: picked.playerId, rngSeed, animSeed: `${rngSeed}:anim` };
}

/** Category offer: up to `count` options from allowed minus already used ones, never repeating within a game. */
export function categoryOptions(allowed: readonly number[], used: readonly number[], seed: string, count = 5): number[] {
  const usedSet = new Set(used);
  const remaining = allowed.filter((c) => !usedSet.has(c));
  return createRng(seed).shuffle(remaining).slice(0, count);
}

export function initials(name: string): string {
  const parts = name.trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return '?';
  return parts.map((p) => p[0]!.toUpperCase() + '.').join('');
}

/** Deterministic, auditable randomness. Every shuffle/spin/board draw uses this with a stored seed. */

/** FNV-1a 32-bit hash of a string. */
export function hashString(input: string): number {
  let h = 0x811c9dc5;
  for (let i = 0; i < input.length; i++) {
    h ^= input.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return h >>> 0;
}

export interface Rng {
  /** float in [0, 1) */
  next(): number;
  /** integer in [min, max] inclusive */
  int(min: number, max: number): number;
  pick<T>(items: readonly T[]): T;
  shuffle<T>(items: readonly T[]): T[];
}

export function mulberry32(seed: number): () => number {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function createRng(seed: string | number): Rng {
  const base = mulberry32(typeof seed === 'number' ? seed : hashString(seed));
  const rng: Rng = {
    next: base,
    int(min, max) {
      if (max < min) throw new RangeError('max < min');
      return min + Math.floor(base() * (max - min + 1));
    },
    pick(items) {
      if (items.length === 0) throw new RangeError('empty list');
      return items[Math.floor(base() * items.length)] as never;
    },
    shuffle(items) {
      const out = items.slice();
      for (let i = out.length - 1; i > 0; i--) {
        const j = Math.floor(base() * (i + 1));
        const tmp = out[i] as never;
        out[i] = out[j] as never;
        out[j] = tmp;
      }
      return out;
    },
  };
  return rng;
}

/** Fisher-Yates with a string seed. Same seed → same order. */
export function seededShuffle<T>(items: readonly T[], seed: string): T[] {
  return createRng(seed).shuffle(items);
}

/** Per-player card order (blueprint 7.4). */
export function playerOrder<T>(slots: readonly T[], roundSeed: string, playerId: string): T[] {
  return seededShuffle(slots, `${roundSeed}:${hashString(playerId)}`);
}

export function randomSeed(): string {
  return Math.floor(Math.random() * 2 ** 32).toString(36) + Math.floor(Math.random() * 2 ** 32).toString(36);
}

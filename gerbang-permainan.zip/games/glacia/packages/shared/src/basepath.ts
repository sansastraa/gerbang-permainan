/**
 * BASE_PATH: the URL prefix GLACIA is served under when it sits behind a gateway (e.g. SIMPETERI's /games/glacia).
 * Empty string = served at the root. One normaliser for the server, the Vite build and the browser, so they can never disagree.
 */
export function normalizeBasePath(raw: string | undefined | null): string {
  const t = (raw ?? '').trim();
  if (t === '' || t === '/') return '';
  const clean = (t.startsWith('/') ? t : `/${t}`).replace(/\/{2,}/g, '/').replace(/\/+$/, '');
  if (!/^(\/[A-Za-z0-9._~-]+)+$/.test(clean) || clean.split('/').some((s) => s === '.' || s === '..')) {
    throw new Error(`BASE_PATH must be a plain path prefix like /games/glacia (got "${raw}")`);
  }
  return clean;
}

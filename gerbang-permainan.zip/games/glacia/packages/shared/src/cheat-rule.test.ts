import { describe, expect, it } from 'vitest';
import { initialCheatState, onAnswer, onVisibility, type CheatCfg, type CheatState } from './cheat-rule';

const cfg: CheatCfg = { minBlurMs: 2000, blurArmWindowSec: 90, streakThreshold: 4 };

/** blur for `ms` starting at t0, returns state once the tab is visible again. */
function blur(st: CheatState, t0: number, ms: number, active = true, c = cfg) {
  const hidden = onVisibility(st, true, t0, active, c);
  return onVisibility(hidden.state, false, t0 + ms, active, c);
}

function answers(st: CheatState, list: boolean[], t0: number, c = cfg) {
  let s = st;
  let dqAt = -1;
  list.forEach((ok, i) => {
    const r = onAnswer(s, ok, t0 + i * 1000, false, c);
    s = r.state;
    if (r.disqualify && dqAt < 0) dqAt = i + 1;
  });
  return { s, dqAt };
}

describe('cheat rule 7.7', () => {
  it('blur 3s → 4 correct streak disqualifies exactly on the 4th answer', () => {
    const r = blur(initialCheatState(), 1000, 3000);
    expect(r.flag).toBe('TAB_BLUR');
    expect(r.hiddenMs).toBe(3000);
    const a = answers(r.state, [true, true, true, true, true], 10_000);
    expect(a.dqAt).toBe(4);
  });

  it('blur 1s (< minBlurMs) does not arm: 10 correct never trigger', () => {
    const r = blur(initialCheatState(), 1000, 1000);
    expect(r.flag).toBeUndefined();
    expect(r.state.armedUntil).toBeNull();
    expect(answers(r.state, Array(10).fill(true), 5000).dqAt).toBe(-1);
  });

  it('blur → 3 correct → 1 wrong → 3 correct does not disqualify', () => {
    const r = blur(initialCheatState(), 0, 3000);
    const a = answers(r.state, [true, true, true, false, true, true, true], 4000);
    expect(a.dqAt).toBe(-1);
  });

  it('answering after the window (100s > 90s) does not disqualify and streak is 0', () => {
    const r = blur(initialCheatState(), 0, 3000); // armed until 93_000
    const late = onAnswer(r.state, true, 3000 + 100_000, false, cfg);
    expect(late.disqualify).toBeUndefined();
    expect(late.state.streak).toBe(0);
    expect(late.state.armedUntil).toBeNull();
  });

  it('threshold 5: 4th is safe, 5th triggers', () => {
    const c5 = { ...cfg, streakThreshold: 5 };
    const r = blur(initialCheatState(), 0, 3000, true, c5);
    const a4 = answers(r.state, [true, true, true, true], 4000, c5);
    expect(a4.dqAt).toBe(-1);
    expect(answers(r.state, Array(5).fill(true), 4000, c5).dqAt).toBe(5);
  });

  it.each(['LOBBY', 'SPIN', 'PICK', 'COUNTDOWN', 'ROUND_RESULT', 'PAUSED'])(
    'blur while status %s is ignored',
    () => {
      const r = blur(initialCheatState(), 0, 5000, false);
      expect(r.flag).toBeUndefined();
      expect(r.state.armedUntil).toBeNull();
    },
  );

  it('ANSWER_WHILE_HIDDEN arms monitoring like a blur', () => {
    let s = initialCheatState();
    const first = onAnswer(s, true, 1000, true, cfg);
    expect(first.flag).toBe('ANSWER_WHILE_HIDDEN');
    expect(first.state.armedUntil).toBe(91_000);
    s = first.state;
    // the hidden answer itself counted as streak 1; three more reach 4
    expect(answers(s, [true, true, true], 2000).dqAt).toBe(3);
  });

  it('a second blur extends the window without resetting the streak', () => {
    const r = blur(initialCheatState(), 0, 3000);
    const a = answers(r.state, [true, true], 4000);
    const r2 = blur(a.s, 10_000, 3000);
    expect(r2.state.streak).toBe(2);
    expect(r2.state.armedUntil).toBe(13_000 + 90_000);
    expect(answers(r2.state, [true, true], 14_000).dqAt).toBe(2);
  });

  it('a new round resets the state', () => {
    const r = blur(initialCheatState(), 0, 3000);
    const a = answers(r.state, [true, true, true], 4000);
    expect(a.s.streak).toBe(3);
    const fresh = initialCheatState();
    expect(answers(fresh, [true, true, true, true], 9000).dqAt).toBe(-1);
  });

  it('keeps hiddenSince on repeated hidden events and ignores visible when never hidden', () => {
    const h1 = onVisibility(initialCheatState(), true, 100, true, cfg);
    const h2 = onVisibility(h1.state, true, 900, true, cfg);
    expect(h2.state.hiddenSince).toBe(100);
    const v = onVisibility(initialCheatState(), false, 500, true, cfg);
    expect(v.flag).toBeUndefined();
  });

  it('wrong answers outside monitoring are harmless', () => {
    const r = onAnswer(initialCheatState(), false, 100, false, cfg);
    expect(r.state.streak).toBe(0);
    expect(r.disqualify).toBeUndefined();
  });
});

import { describe, expect, it } from 'vitest';
import {
  DEFAULT_TIER_WEIGHTS,
  FORBIDDEN_KEYS,
  buildWheel,
  categoryOptions,
  createRng,
  drawSpin,
  findForbiddenKeys,
  firstBloodBonus,
  hashString,
  initials,
  isBurst,
  isPerfectRound,
  isTooFast,
  isUniformTiming,
  parseSettings,
  planRefresh,
  playerOrder,
  pointsForCorrect,
  randomSeed,
  rankStandings,
  roundScore,
  sampleBoard,
  seededShuffle,
  splitByWeights,
  stddev,
  type PoolQuestion,
  type RefreshCard,
  type Tier,
} from './index';

function makePool(): PoolQuestion[] {
  const tiers: Tier[] = ['EASY', 'MEDIUM', 'HARD'];
  const pool: PoolQuestion[] = [];
  const mk = (isCorrect: boolean, n: number) => {
    for (let i = 0; i < n; i++) {
      const r = i / n;
      const tier = r < 0.3 ? tiers[0]! : r < 0.75 ? tiers[1]! : tiers[2]!;
      pool.push({ id: `${isCorrect ? 'P' : 'N'}${i}`, isCorrect, tier });
    }
  };
  mk(true, 225);
  mk(false, 275);
  return pool;
}

describe('scoring', () => {
  it('pointsForCorrect', () => {
    expect(pointsForCorrect(0)).toBe(1000);
    expect(pointsForCorrect(8000)).toBe(920);
    expect(pointsForCorrect(8999)).toBe(920);
    expect(pointsForCorrect(90_000)).toBe(100);
    expect(pointsForCorrect(200_000)).toBe(100);
    expect(pointsForCorrect(-5)).toBe(1000);
  });
  it('firstBloodBonus', () => {
    expect([1, 2, 3, 4, 0].map((r) => firstBloodBonus(r))).toEqual([300, 200, 100, 0, 0]);
  });
  it('roundScore never negative; perfect round', () => {
    expect(roundScore([1000, -250, -250])).toBe(500);
    expect(roundScore([-250, -250])).toBe(0);
    expect(isPerfectRound(28, 28, 0)).toBe(true);
    expect(isPerfectRound(28, 28, 1)).toBe(false);
    expect(isPerfectRound(27, 28, 0)).toBe(false);
    expect(isPerfectRound(0, 0, 0)).toBe(false);
  });
  it('rankStandings: score → correct → fewer wrong → avg think; excludes disqualified', () => {
    const s = (playerId: string, totalScore: number, correct: number, wrong: number, avgThinkMs: number, disqualified = false) => ({
      playerId, totalScore, correct, wrong, avgThinkMs, disqualified,
    });
    const r = rankStandings([
      s('d', 9999, 50, 0, 1, true),
      s('a', 100, 5, 1, 900),
      s('b', 100, 5, 1, 800),
      s('c', 100, 5, 0, 5000),
      s('e', 100, 6, 9, 5000),
      s('f', 200, 1, 1, 1),
    ]);
    expect(r.map((x) => x.playerId)).toEqual(['f', 'e', 'c', 'b', 'a']);
  });
});

describe('rng', () => {
  it('is deterministic per seed and differs for different seeds', () => {
    const a = createRng('x');
    const b = createRng('x');
    expect([a.next(), a.next()]).toEqual([b.next(), b.next()]);
    expect(createRng('x').next()).not.toBe(createRng('y').next());
    expect(createRng(5).next()).toBe(createRng(5).next());
  });
  it('int/pick/shuffle', () => {
    const r = createRng('s');
    for (let i = 0; i < 200; i++) {
      const v = r.int(3, 5);
      expect(v >= 3 && v <= 5).toBe(true);
    }
    expect(() => r.int(5, 3)).toThrow();
    expect(() => r.pick([])).toThrow();
    const list = [1, 2, 3, 4, 5, 6];
    const sh = r.shuffle(list);
    expect(sh.slice().sort()).toEqual(list);
    expect(list).toEqual([1, 2, 3, 4, 5, 6]);
  });
  it('seededShuffle deterministic; playerOrder differs by player', () => {
    const slots = Array.from({ length: 64 }, (_, i) => i);
    expect(seededShuffle(slots, 's')).toEqual(seededShuffle(slots, 's'));
    expect(playerOrder(slots, 'round1', 'p1')).not.toEqual(playerOrder(slots, 'round1', 'p2'));
    expect(playerOrder(slots, 'round1', 'p1')).toEqual(playerOrder(slots, 'round1', 'p1'));
    expect(hashString('a')).not.toBe(hashString('b'));
    expect(randomSeed()).not.toBe(randomSeed());
  });
});

describe('sampleBoard', () => {
  const pool = makePool();
  it('splitByWeights always sums to n', () => {
    for (let n = 0; n < 70; n++) {
      const s = splitByWeights(n, DEFAULT_TIER_WEIGHTS);
      expect(s.EASY + s.MEDIUM + s.HARD).toBe(n);
    }
  });
  it('1000 boards: 64 unique, 26..32 correct, tier mix within ±5%', () => {
    const tier: Record<Tier, number> = { EASY: 0, MEDIUM: 0, HARD: 0 };
    for (let i = 0; i < 1000; i++) {
      const b = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: `b${i}` });
      expect(b.cards).toHaveLength(64);
      expect(new Set(b.cards.map((c) => c.id)).size).toBe(64);
      expect(b.correctCount).toBeGreaterThanOrEqual(26);
      expect(b.correctCount).toBeLessThanOrEqual(32);
      for (const c of b.cards) tier[c.tier]++;
    }
    const total = 64000;
    expect(Math.abs(tier.EASY / total - 0.3)).toBeLessThan(0.05);
    expect(Math.abs(tier.MEDIUM / total - 0.45)).toBeLessThan(0.05);
    expect(Math.abs(tier.HARD / total - 0.25)).toBeLessThan(0.05);
  });
  it('respects excludeQuestionIds, falls back when the pool is exhausted', () => {
    const ex = new Set(pool.slice(0, 100).map((q) => q.id));
    const b = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: 'e', excludeQuestionIds: ex });
    expect(b.cards.some((c) => ex.has(c.id))).toBe(false);
    const all = new Set(pool.map((q) => q.id));
    const b2 = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: 'e', excludeQuestionIds: all });
    expect(b2.cards).toHaveLength(64);
    expect(new Set(b2.cards.map((c) => c.id)).size).toBe(64);
  });
  it('is deterministic per seed', () => {
    const a = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: 'same' });
    const b = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: 'same' });
    expect(a.cards.map((c) => c.id)).toEqual(b.cards.map((c) => c.id));
  });
});

describe('planRefresh', () => {
  const pool = makePool();
  it('keeps correct count and leaves answered cards untouched', () => {
    for (let i = 0; i < 50; i++) {
      const b = sampleBoard(pool, { ratioMin: 0.4, ratioMax: 0.5, seed: `r${i}` });
      const cards: RefreshCard[] = b.cards.map((q, slot) => ({
        slot, questionId: q.id, isCorrect: q.isCorrect, tier: q.tier, answered: slot % 5 === 0,
      }));
      const used = new Set(b.cards.map((c) => c.id));
      const plan = planRefresh(cards, pool, used, `rs${i}`);
      const bySlot = new Map(plan.map((p) => [p.slot, p]));
      const byId = new Map(pool.map((q) => [q.id, q]));
      let correct = 0;
      cards.forEach((c) => {
        const rep = bySlot.get(c.slot);
        if (c.answered) expect(rep).toBeUndefined();
        const id = rep ? rep.newQuestionId : c.questionId;
        if (byId.get(id)!.isCorrect) correct++;
        if (rep) expect(used.has(rep.newQuestionId)).toBe(false);
      });
      expect(correct).toBe(b.correctCount);
      expect(correct).toBeGreaterThanOrEqual(26);
      expect(correct).toBeLessThanOrEqual(32);
      expect(new Set(plan.map((p) => p.newQuestionId)).size).toBe(plan.length);
    }
  });
  it('keeps the old card when nothing is left', () => {
    const tiny: PoolQuestion[] = [{ id: 'A', isCorrect: true, tier: 'EASY' }];
    const plan = planRefresh([{ slot: 0, questionId: 'A', isCorrect: true, tier: 'EASY', answered: false }], tiny, new Set(['A']), 's');
    expect(plan).toEqual([]);
  });
  it('falls back to another tier when the tier is exhausted', () => {
    const p: PoolQuestion[] = [
      { id: 'A', isCorrect: true, tier: 'EASY' },
      { id: 'B', isCorrect: true, tier: 'HARD' },
    ];
    const plan = planRefresh([{ slot: 0, questionId: 'A', isCorrect: true, tier: 'EASY', answered: false }], p, new Set(['A']), 's');
    expect(plan[0]?.newQuestionId).toBe('B');
  });
});

describe('spin & wheel', () => {
  const P = (id: string, o: Partial<{ online: boolean; hasPicked: boolean; disqualified: boolean; blacklisted: boolean }> = {}) => ({
    playerId: id, name: id.toUpperCase(), online: true, hasPicked: false, disqualified: false, ...o,
  });
  it('wheel has exactly the eligible players', () => {
    const w = buildWheel([P('a'), P('b', { hasPicked: true }), P('c', { online: false }), P('d', { disqualified: true }), P('e', { blacklisted: true }), P('f')]);
    expect(w.segments.map((s) => s.playerId)).toEqual(['a', 'f']);
    expect(w.cycleReset).toBe(false);
  });
  it('resets the cycle when all active already picked', () => {
    const w = buildWheel([P('a', { hasPicked: true }), P('b', { hasPicked: true }), P('c', { disqualified: true })]);
    expect(w.segments.map((s) => s.playerId)).toEqual(['a', 'b']);
    expect(w.cycleReset).toBe(true);
    expect(buildWheel([]).cycleReset).toBe(false);
  });
  it('drawSpin picks from segments deterministically', () => {
    const segs = [{ playerId: 'a' }, { playerId: 'b' }, { playerId: 'c' }];
    const r = drawSpin(segs, 'seed');
    expect(drawSpin(segs, 'seed').pickedPlayerId).toBe(r.pickedPlayerId);
    expect(['a', 'b', 'c']).toContain(drawSpin(segs).pickedPlayerId);
    expect(() => drawSpin([])).toThrow();
  });
  it('categoryOptions never repeats used categories', () => {
    const all = Array.from({ length: 15 }, (_, i) => i + 1);
    const o = categoryOptions(all, [1, 2, 3], 's');
    expect(o).toHaveLength(5);
    expect(o.some((c) => [1, 2, 3].includes(c))).toBe(false);
    expect(categoryOptions([1, 2, 3, 4, 5], [1, 2, 3, 4], 's')).toEqual([5]);
  });
  it('initials', () => {
    expect(initials('Budi Santoso')).toBe('B.S.');
    expect(initials('  ')).toBe('?');
  });
});

describe('settings', () => {
  it('applies defaults and bounds', () => {
    const s = parseSettings({ classId: 'c1' });
    expect(s).toMatchObject({ rounds: 5, roundSeconds: 120, boardSize: 64, cheatStreakThreshold: 4, minBlurMs: 2000, blurArmWindowSec: 90 });
    expect(s.allowedCategoryIds).toHaveLength(15);
    expect(() => parseSettings({ classId: 'c1', roundSeconds: 10 })).toThrow();
    expect(() => parseSettings({ classId: 'c1', cheatStreakThreshold: 6 })).toThrow();
    expect(() => parseSettings({ classId: 'c1', allowedCategoryIds: [] })).toThrow();
    expect(parseSettings({ classId: 'c1', allowedCategoryIds: [7] }).allowedCategoryIds).toEqual([7]);
    expect(() => parseSettings({ classId: 'c1', correctRatioMin: 0.55, correctRatioMax: 0.4 })).toThrow();
    expect(parseSettings({ classId: 'c1', allowedCategoryIds: [5, 4, 3, 2, 1, 1] }).allowedCategoryIds).toEqual([1, 2, 3, 4, 5]);
  });
});

describe('leak detector & heuristics', () => {
  it('finds forbidden keys recursively', () => {
    const msg = { cards: [{ cardId: 'x', svg: '<svg/>', meta: { isCorrect: true } }], nested: { a: [{ result: 1 }] } };
    expect(findForbiddenKeys(msg).sort()).toEqual(['$.cards[0].meta.isCorrect', '$.nested.a[0].result']);
    expect(findForbiddenKeys({ ok: 1 }, FORBIDDEN_KEYS)).toEqual([]);
    expect(findForbiddenKeys(null)).toEqual([]);
  });
  it('TOO_FAST / UNIFORM / BURST', () => {
    expect(isTooFast([100, 200, 300])).toBe(true);
    expect(isTooFast([100, 200, 900])).toBe(false);
    expect(stddev([])).toBe(0);
    expect(isUniformTiming(Array(10).fill(2000))).toBe(true);
    expect(isUniformTiming(Array(9).fill(2000))).toBe(false);
    expect(isUniformTiming([1000, 5000, 2000, 9000, 1000, 4000, 7000, 3000, 8000, 1000])).toBe(false);
    expect(isBurst(Array.from({ length: 8 }, (_, i) => i * 1000))).toBe(true);
    expect(isBurst(Array.from({ length: 8 }, (_, i) => i * 2000))).toBe(false);
    expect(isBurst([1, 2, 3])).toBe(false);
  });
});

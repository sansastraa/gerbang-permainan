export interface ScoringConfig {
  base: number;
  decayPerSec: number;
  floor: number;
  wrongPenalty: number;
  firstBlood: readonly number[];
  perfectRoundBonus: number;
}

export const SCORING_DEFAULTS: ScoringConfig = {
  base: 1000,
  decayPerSec: 10,
  floor: 100,
  wrongPenalty: 250,
  firstBlood: [300, 200, 100],
  perfectRoundBonus: 500,
};

/** thinkMs = server receivedAt - (last correct action of the player | round start). */
export function pointsForCorrect(thinkMs: number, cfg: ScoringConfig = SCORING_DEFAULTS): number {
  const sec = Math.floor(Math.max(0, thinkMs) / 1000);
  return Math.max(cfg.floor, cfg.base - cfg.decayPerSec * sec);
}

/** rank is 1-based. */
export function firstBloodBonus(rank: number, cfg: ScoringConfig = SCORING_DEFAULTS): number {
  if (rank < 1) return 0;
  return cfg.firstBlood[rank - 1] ?? 0;
}

/** A round score never makes the total negative at round level. */
export function roundScore(parts: readonly number[]): number {
  return Math.max(
    0,
    parts.reduce((a, b) => a + b, 0),
  );
}

/** Perfect round: every correct card found and zero wrong answers. */
export function isPerfectRound(found: number, totalCorrect: number, wrong: number): boolean {
  return totalCorrect > 0 && found === totalCorrect && wrong === 0;
}

export interface Standing {
  playerId: string;
  totalScore: number;
  correct: number;
  wrong: number;
  avgThinkMs: number;
  disqualified?: boolean;
}

/** Game winner order: score → correct → fewer wrong → lower avg think time. Disqualified players are excluded. */
export function rankStandings<T extends Standing>(list: readonly T[]): T[] {
  return list
    .filter((s) => !s.disqualified)
    .slice()
    .sort(
      (a, b) =>
        b.totalScore - a.totalScore ||
        b.correct - a.correct ||
        a.wrong - b.wrong ||
        a.avgThinkMs - b.avgThinkMs ||
        a.playerId.localeCompare(b.playerId),
    );
}

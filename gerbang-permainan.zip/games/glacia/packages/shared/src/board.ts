import { createRng, type Rng } from './rng';

export type Tier = 'EASY' | 'MEDIUM' | 'HARD';
export const TIERS: Tier[] = ['EASY', 'MEDIUM', 'HARD'];
export const DEFAULT_TIER_WEIGHTS: Record<Tier, number> = { EASY: 0.3, MEDIUM: 0.45, HARD: 0.25 };

export interface PoolQuestion {
  id: string;
  isCorrect: boolean;
  tier: Tier;
}

export interface SampleOpts {
  size?: number;
  ratioMin: number;
  ratioMax: number;
  tierWeights?: Record<Tier, number>;
  excludeQuestionIds?: ReadonlySet<string>;
  seed: string;
}

/** Largest-remainder split of n by weights so counts always sum to exactly n. */
export function splitByWeights(n: number, weights: Record<Tier, number>): Record<Tier, number> {
  const total = TIERS.reduce((a, t) => a + weights[t], 0);
  const raw = TIERS.map((t) => ({ t, v: (n * weights[t]) / total }));
  const out: Record<Tier, number> = { EASY: 0, MEDIUM: 0, HARD: 0 };
  let used = 0;
  for (const r of raw) {
    out[r.t] = Math.floor(r.v);
    used += out[r.t];
  }
  raw.sort((a, b) => b.v - Math.floor(b.v) - (a.v - Math.floor(a.v)));
  for (let i = 0; used < n; i++, used++) out[raw[i % raw.length]!.t]++;
  return out;
}

function takeByTier(src: PoolQuestion[], n: number, weights: Record<Tier, number>, rng: Rng): PoolQuestion[] {
  const want = splitByWeights(n, weights);
  const out: PoolQuestion[] = [];
  const taken = new Set<string>();
  for (const t of TIERS) {
    const sub = rng.shuffle(src.filter((q) => q.tier === t));
    for (const q of sub.slice(0, want[t])) {
      out.push(q);
      taken.add(q.id);
    }
  }
  if (out.length < n) {
    const rest = rng.shuffle(src.filter((q) => !taken.has(q.id)));
    out.push(...rest.slice(0, n - out.length));
  }
  return out;
}

export interface SampledBoard {
  /** questions in canonical slot order (index = slot) */
  cards: PoolQuestion[];
  correctCount: number;
}

/** Blueprint 7.3. 64 unique cards, k correct ∈ [ceil(size*min), floor(size*max)]. */
export function sampleBoard(pool: readonly PoolQuestion[], opts: SampleOpts): SampledBoard {
  const size = opts.size ?? 64;
  const weights = opts.tierWeights ?? DEFAULT_TIER_WEIGHTS;
  const rng = createRng(opts.seed);
  const lo = Math.ceil(size * opts.ratioMin - 1e-9);
  const hi = Math.floor(size * opts.ratioMax + 1e-9);
  const k = rng.int(Math.min(lo, hi), Math.max(lo, hi));
  const ex = opts.excludeQuestionIds ?? new Set<string>();
  const fresh = pool.filter((q) => !ex.has(q.id));
  const split = (list: readonly PoolQuestion[]) => ({
    pos: list.filter((q) => q.isCorrect),
    neg: list.filter((q) => !q.isCorrect),
  });
  const f = split(fresh);
  const all = split(pool);
  const choose = (freshSrc: PoolQuestion[], allSrc: PoolQuestion[], n: number): PoolQuestion[] => {
    const first = takeByTier(freshSrc, Math.min(n, freshSrc.length), weights, rng);
    if (first.length >= n) return first;
    // pool exhausted by history: top up with already-used questions
    const ids = new Set(first.map((q) => q.id));
    const more = takeByTier(
      allSrc.filter((q) => !ids.has(q.id)),
      n - first.length,
      weights,
      rng,
    );
    return [...first, ...more];
  };
  const picked = [...choose(f.pos, all.pos, k), ...choose(f.neg, all.neg, size - k)];
  const cards = rng.shuffle(picked);
  return { cards, correctCount: cards.filter((c) => c.isCorrect).length };
}

export interface RefreshCard {
  slot: number;
  questionId: string;
  isCorrect: boolean;
  tier: Tier;
  answered: boolean; // answered by ANY player
}

export interface Replacement {
  slot: number;
  oldQuestionId: string;
  newQuestionId: string;
}

/**
 * Blueprint 7.5. Every card nobody answered is swapped for a new question of the same category with the same
 * correct/decoy flag (and same tier when possible), so the correct total stays within the original range.
 */
export function planRefresh(
  cards: readonly RefreshCard[],
  pool: readonly PoolQuestion[],
  usedQuestionIds: ReadonlySet<string>,
  seed: string,
): Replacement[] {
  const rng = createRng(seed);
  const used = new Set(usedQuestionIds);
  const out: Replacement[] = [];
  for (const c of cards) {
    if (c.answered) continue;
    const base = pool.filter((q) => q.isCorrect === c.isCorrect && !used.has(q.id));
    const sameTier = base.filter((q) => q.tier === c.tier);
    const cand = sameTier.length > 0 ? sameTier : base;
    if (cand.length === 0) continue; // nothing left: keep the old card
    const q = rng.pick(cand);
    used.add(q.id);
    out.push({ slot: c.slot, oldQuestionId: c.questionId, newQuestionId: q.id });
  }
  return out;
}

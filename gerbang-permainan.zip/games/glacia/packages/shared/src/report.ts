/** Contract objects shared by server (report, SIMPETERI port) and clients. */
export interface PerCategoryStat {
  categoryId: number;
  attempted: number;
  correct: number;
  wrong: number;
}

export interface StudentResult {
  studentId: string;
  rank: number;
  totalScore: number;
  correct: number;
  wrong: number;
  avgThinkMs: number;
  status: 'OK' | 'DISQUALIFIED';
  blacklisted: boolean;
  disqualifyReason?: string;
  perCategory: PerCategoryStat[];
}

export interface GameResultPayload {
  roomId: string;
  classId: string;
  playedAt: string;
  students: StudentResult[];
}

/** Summary JSON consumed by the SIMPETERI "Buat Multi Permainan" menu (per student, accumulable across games). */
export interface GlaciaSummary {
  game: 'glacia';
  version: 2;
  sessionId: string;
  classId: string;
  playedAt: string;
  rounds: number;
  students: {
    /** siswa.id from SIMPETERI (the roster handed over by Multi Permainan) */
    studentId: string;
    name: string;
    rank: number | null;
    /** same value as `score`; the name SIMPETERI's importer reads (like CLAIM 80) */
    points: number;
    attempts: number;
    /** knowledge index 0..100 per category name; null when fewer than 3 attempts */
    profile: Record<string, number | null>;
    score: number;
    correct: number;
    wrong: number;
    accuracy: number; // 0..1
    avgThinkMs: number;
    status: 'OK' | 'DISQUALIFIED';
    blacklisted: boolean;
    perCategory: { categoryId: number; category: string; attempted: number; correct: number; wrong: number }[];
  }[];
}

import { z } from 'zod';

export const ALL_CATEGORY_IDS = Array.from({ length: 15 }, (_, i) => i + 1);

export const RoomSettingsSchema = z
  .object({
    classId: z.string().min(1),
    maxPlayers: z.number().int().min(2).max(100).default(40),
    rounds: z.number().int().min(1).max(10).default(5),
    roundSeconds: z.number().int().min(20).max(900).default(120),
    categoryPickSeconds: z.number().int().min(5).max(60).default(15),
    boardSize: z.literal(64).default(64),
    correctRatioMin: z.number().min(0.3).max(0.6).default(0.4),
    correctRatioMax: z.number().min(0.3).max(0.6).default(0.5),
    difficulty: z.enum(['regular', 'challenge']).default('challenge'),
    wrongPenalty: z.number().int().min(0).max(2000).default(250),
    wrongCooldownMs: z.number().int().min(0).max(10000).default(2000),
    firstBlood: z.boolean().default(true),
    /** First correct answer claims the card: nobody else can press it. Replaces First Blood and the perfect-round bonus. */
    claimMode: z.boolean().default(true),
    boardRefreshOddRounds: z.boolean().default(true),
    allowedCategoryIds: z
      .array(z.number().int().min(1).max(15))
      .min(1)
      .default(ALL_CATEGORY_IDS)
      .transform((a) => [...new Set(a)].sort((x, y) => x - y)),
    autoDisqualify: z.boolean().default(true),
    cheatStreakThreshold: z.number().int().min(4).max(5).default(4),
    minBlurMs: z.number().int().min(500).max(10000).default(2000),
    blurArmWindowSec: z.number().int().min(30).max(300).default(90),
    autoBlacklist: z.boolean().default(true),
    showDisqualifiedOnDisplay: z.enum(['NAME', 'INITIALS', 'COUNT_ONLY']).default('NAME'),
  })
  .refine((s) => s.correctRatioMin <= s.correctRatioMax, { message: 'correctRatioMin > correctRatioMax' })
  .refine((s) => s.allowedCategoryIds.length >= 1, { message: 'min 1 category' });

export type RoomSettings = z.infer<typeof RoomSettingsSchema>;
export type RoomSettingsInput = z.input<typeof RoomSettingsSchema>;

export function parseSettings(input: unknown): RoomSettings {
  return RoomSettingsSchema.parse(input);
}

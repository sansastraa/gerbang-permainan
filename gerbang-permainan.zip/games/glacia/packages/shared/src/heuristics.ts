/** Soft cheat heuristics (blueprint 11): produce flags only, never disqualify. Pure. */
export const TOO_FAST_MS = 400;
export const TOO_FAST_REPEAT = 3;
export const UNIFORM_MIN_ANSWERS = 10;
export const UNIFORM_MAX_STDDEV_MS = 150;
export const BURST_CORRECT = 8;
export const BURST_WINDOW_MS = 10_000;

export function stddev(values: readonly number[]): number {
  if (values.length === 0) return 0;
  const mean = values.reduce((a, b) => a + b, 0) / values.length;
  return Math.sqrt(values.reduce((a, b) => a + (b - mean) ** 2, 0) / values.length);
}

/** thinkMs < 400 ms repeated (≥3 times in the recent history). */
export function isTooFast(recentThinkMs: readonly number[]): boolean {
  return recentThinkMs.filter((t) => t < TOO_FAST_MS).length >= TOO_FAST_REPEAT;
}

/** Very small thinkMs deviation on ≥10 answers. */
export function isUniformTiming(thinkMs: readonly number[]): boolean {
  return thinkMs.length >= UNIFORM_MIN_ANSWERS && stddev(thinkMs) < UNIFORM_MAX_STDDEV_MS;
}

/** ≥8 correct answers inside any 10-second window. */
export function isBurst(correctTimes: readonly number[]): boolean {
  const t = correctTimes.slice().sort((a, b) => a - b);
  for (let i = 0; i + BURST_CORRECT - 1 < t.length; i++) {
    if (t[i + BURST_CORRECT - 1]! - t[i]! <= BURST_WINDOW_MS) return true;
  }
  return false;
}

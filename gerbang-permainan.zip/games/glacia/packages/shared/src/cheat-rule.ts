/** Auto-disqualification rule engine (blueprint 7.7 / 11.1). Pure functions; time is always SERVER time. */
export interface CheatCfg {
  minBlurMs: number; // default 2000
  blurArmWindowSec: number; // default 90
  streakThreshold: number; // default 4 (4..5)
}

export interface CheatState {
  hiddenSince: number | null; // epoch ms server, null when the tab is visible
  armedUntil: number | null; // monitoring active until
  streak: number; // consecutive correct since armed
}

export const initialCheatState = (): CheatState => ({ hiddenSince: null, armedUntil: null, streak: 0 });

/** now = SERVER time. active = room status is RUNNING. */
export function onVisibility(
  st: CheatState,
  hidden: boolean,
  now: number,
  active: boolean,
  cfg: CheatCfg,
): { state: CheatState; flag?: 'TAB_BLUR'; hiddenMs?: number } {
  if (hidden) return { state: { ...st, hiddenSince: st.hiddenSince ?? now } };
  const hiddenMs = st.hiddenSince !== null ? now - st.hiddenSince : 0;
  const base = { ...st, hiddenSince: null };
  if (!active || hiddenMs < cfg.minBlurMs) return { state: base };
  return {
    state: { ...base, armedUntil: now + cfg.blurArmWindowSec * 1000 }, // streak is NOT reset
    flag: 'TAB_BLUR',
    hiddenMs,
  };
}

/** Called AFTER the server validated the answer. hiddenAtAnswer = client reports the tab is hidden. */
export function onAnswer(
  st: CheatState,
  correct: boolean,
  now: number,
  hiddenAtAnswer: boolean,
  cfg: CheatCfg,
): { state: CheatState; flag?: 'ANSWER_WHILE_HIDDEN'; disqualify?: boolean } {
  let s = { ...st };
  let flag: 'ANSWER_WHILE_HIDDEN' | undefined;
  if (hiddenAtAnswer) {
    flag = 'ANSWER_WHILE_HIDDEN';
    s.armedUntil = now + cfg.blurArmWindowSec * 1000;
  }
  if (s.armedUntil !== null && now > s.armedUntil) s = { ...s, armedUntil: null, streak: 0 }; // window expired
  if (s.armedUntil === null) return { state: s, flag };
  if (!correct) return { state: { ...s, streak: 0 }, flag }; // wrong → streak 0
  const streak = s.streak + 1;
  return { state: { ...s, streak }, flag, disqualify: streak >= cfg.streakThreshold };
}

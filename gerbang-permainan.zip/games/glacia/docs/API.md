# API — REST host dan kontrak SIMPETERI

Basis: `/api/...` (juga tersedia tanpa awalan `/api`). Autentikasi guru: header `Authorization: Bearer <JWT>` dari `POST /api/auth/host` (HS256, berlaku 6 jam).

## REST untuk guru

| Method | Path | Fungsi |
|---|---|---|
| GET | `/health` | `{ ok, uptime, rooms, questions }` (tanpa auth) |
| POST | `/auth/host` | `{ token }` (token SIMPETERI) → `{ jwt, host }` |
| GET | `/classes` | kelas milik guru |
| GET | `/categories` | 15 kategori beserta trik singkat |
| POST | `/rooms` | buat ruangan dari `RoomSettings` → `{ roomId, pin }`. `403 CLASS_NOT_ALLOWED`, `400 BAD_SETTINGS`, `400 EMPTY_CLASS` |
| GET | `/rooms` | ruangan aktif dan yang sudah selesai |
| GET | `/rooms/:id` | status ruangan |
| PATCH | `/rooms/:id/settings` | ubah pengaturan, hanya saat `LOBBY` (`409` bila tidak) |
| GET | `/rooms/:id/report` | laporan akhir (`payload` untuk SIMPETERI, `summary`, `finalBoard`) |
| GET | `/rooms/:id/report.csv` | unduhan CSV (UTF-8 + BOM) |
| GET | `/rooms/:id/summary.json` | ringkasan untuk menu **Buat Multi Permainan** SIMPETERI. Butuh JWT guru *atau* `?key=<exportKey>` (kunci acak per ruangan, ditampilkan di panel guru) |
| POST | `/rooms/:id/report/resend` | kirim ulang laporan ke SIMPETERI |
| GET | `/rooms/:id/cheat-flags` | semua `CheatFlag` ruangan |
| POST | `/rooms/:id/players/:playerId/disqualify` | `{ reason (wajib, ≥3 huruf), blacklist? }` |
| POST | `/rooms/:id/players/:playerId/reinstate` | batalkan diskualifikasi: skor dipulihkan, daftar hitam dicabut, tercatat di audit |
| GET | `/blacklist?classId=&active=` | daftar hitam beserta bukti |
| POST | `/blacklist/:studentId/lift` | `{ note (wajib) }`, tercatat di audit dan disinkronkan ke SIMPETERI |
| GET | `/audit` | 200 catatan audit terakhir |
| GET | `/outbox` / POST `/outbox/flush` | kiriman ke SIMPETERI yang tertunda / kirim ulang semuanya |

Kontrol permainan (mulai, jeda, akhiri ronde, akhiri permainan, kick) lewat Socket.IO: lihat `EVENTS.md`.

## SIMPETERI (Multi Permainan)

Kontrak SIMPETERI sudah diketahui dari `simpeteri13-main` (menu Multi Permainan): roster dan PIN diserahkan lewat `postMessage`, hasil ditarik dari `GET /api/sessions/:id/summary.json` dengan header `x-host-token`. Spesifikasi lengkap, bentuk JSON, dan perubahan kecil yang perlu ditambahkan di SIMPETERI ada di **`docs/SIMPETERI_INTEGRASI.md`**.

Ringkas untuk GLACIA:

- `SIMPETERI_MODE=multi` + `HOST_PIN` + `ALLOWED_ORIGINS=<asal SIMPETERI>`.
- `GET /config` → `{ mode, simpeteriOrigins }` (publik), dibaca klien web untuk tahu apakah harus menunggu roster dari SIMPETERI.
- `POST /rooms` di mode multi wajib membawa `roster:[{id,name,absen?}]` (id = `siswa.id`).
- `GET /sessions/:id/summary.json`: `404` tidak ada, `401` PIN salah, `403` belum selesai, `429` terlalu sering.
- Mode `mandiri` (bawaan): sama, tetapi daftar siswa ditempel guru di formulir (satu nama per baris; id dibuat dari nama supaya satu siswa tetap satu id lintas ruangan). Aplikasi tidak membawa daftar siswa atau akun contoh.
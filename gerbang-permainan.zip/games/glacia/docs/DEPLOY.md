# DEPLOY

## Satu server (Docker)

```bash
cp .env.example .env        # isi JWT_SECRET (acak, panjang), SIMPETERI_*, ALLOWED_ORIGINS
docker compose up -d --build
```

Image membangun web + server dan merender 7.500 soal ke SVG saat build. Klien web disajikan oleh server yang sama di port 4000 (`/api/health` untuk cek).

**HTTPS/WSS wajib** di sekolah (WebSocket lewat http biasa sering diblok jaringan). Cara tercepat:

```bash
# ganti domain di Caddyfile, arahkan DNS ke server
docker compose --profile https up -d
```

> `docker build` belum pernah dijalankan di lingkungan pengembangan ini (Docker tidak tersedia). Periksa sekali di mesin yang punya Docker sebelum dipakai.

## Yang disimpan di server

`data/runtime/state.json` (volume `glacia-runtime`): daftar hitam, jejak audit, antrean kiriman ke SIMPETERI, dan laporan ruangan yang selesai. **Cadangkan berkas ini setiap hari.** State ruangan yang sedang berjalan hanya ada di memori.

Hanya cocok untuk **satu proses server**. Untuk beberapa server, ganti `Store` dengan database dan pindahkan state ruangan ke Redis (lihat `docs/ASSUMPTIONS.md`).

## Variabel penting

Lihat `.env.example`. `HOST_PIN` (4-32 karakter tanpa spasi) dan `JWT_SECRET` WAJIB di produksi: server tidak mau start tanpanya. `SIMPETERI_MODE=mandiri` (bawaan): guru menempel nama siswa sendiri. `SIMPETERI_MODE=multi`: guru masuk dari menu Multi Permainan SIMPETERI, dengan `ALLOWED_ORIGINS` berisi asal SIMPETERI (`docs/SIMPETERI_INTEGRASI.md`). Tidak ada akun, token, atau daftar siswa bawaan di dalam aplikasi.

## Satu pintu lewat SIMPETERI (BASE_PATH)

Gerbang SIMPETERI (`games/gateway`) meneruskan `/games/glacia/**` **apa adanya, tanpa memotong awalan**, termasuk WebSocket, ke server GLACIA. Karena itu awalan harus dikenal di dua tempat: saat **build** web (Vite `base`) dan saat **menjalankan** server.

```powershell
# build: web (semua URL aset berawalan) + server
$env:BASE_PATH="/games/glacia"; npm run build
# jalankan: satu proses, satu port
$env:BASE_PATH="/games/glacia"; $env:TRUST_PROXY="1"; $env:HOST_PIN="pin-guru-anda"; $env:STATIC_DIR="apps/web/dist"; $env:SIMPETERI_MODE="multi"; node apps/server/dist/main.js
```

| Variabel | Arti |
|---|---|
| `BASE_PATH` | Awalan jalur, mis. `/games/glacia`. Kosong = seperti biasa (tidak ada yang berubah). Dinormalkan: diawali `/`, tanpa `/` di akhir; nilai yang bukan awalan jalur biasa (spasi, `?`, `#`, `..`) ditolak saat start |
| `TRUST_PROXY=1` | Percaya header `X-Forwarded-For` (entri terakhir, yang ditambahkan gerbang) untuk batas per klien: percobaan PIN guru dan `room:join`. **Hanya aktifkan di belakang gerbang yang Anda kendalikan.** Tanpa ini semua orang dihitung sebagai satu alamat (alamat gerbang) dan header dari klien diabaikan |

Yang berada di bawah awalan: klien web dan fallback SPA (`/games/glacia/host`, `/games/glacia/play`, rute hash tetap jalan), `/games/glacia/api/**`, dan socket.io di `/games/glacia/socket.io`. Di luar awalan semuanya 404, dan URL `api`/`socket.io` yang tidak dikenal dijawab JSON 404, bukan halaman HTML.

- Alamat GLACIA di SIMPETERI: `https://<host>/games/glacia`. Tombol Multi Permainan membuka `{alamat}/host` (jalur, bukan hash); klien memahami keduanya.
- Tautan gabung siswa, QR, dan layar proyektor yang ditampilkan guru selalu memuat awalan (`https://<host>/games/glacia/#/play?pin=...`).
- Di mode satu pintu semuanya same-origin, jadi `ALLOWED_ORIGINS` boleh kosong. Isi hanya bila halaman lain (mis. SIMPETERI di domain berbeda) memanggil `/api/sessions/:id/summary.json` langsung dari browser.
- `BASE_PATH` di build web dan di server **harus sama**. Bila beda, aset atau socket tidak ditemukan.
## Uji beban

```bash
# mesin server, tanpa mode watch (tsx watch memulai ulang server saat berkas berubah)
$env:DATA_DIR="data"; $env:JOIN_LIMIT_PER_MIN="1000"; npx tsx apps/server/src/main.ts
# mesin lain atau terminal lain
npx tsx tools/bots.ts --bots 100 --rounds 2 --seconds 60
```

Bot berbagi satu IP, makanya batas join per IP dinaikkan. Keluarannya: latensi `card:result`/`card:rejected` (target p95 di bawah 300 ms), dan `scoreMismatches` (harus 0: skor tiap bot di server sama dengan jumlah hasil yang diterimanya).

Catatan hasil yang sudah diukur (mesin pengembangan, bot dan server di satu mesin yang ikut menjalankan banyak proses lain) ada di bagian Performa di bawah.

## Performa

- `round:start` kini satu siaran yang sama untuk semua siswa (papan bersama), bukan satu pesan 200 KB per siswa.
- `WS_DEFLATE=0` mematikan kompresi WebSocket per soket. Matikan hanya bila CPU server jadi leher botol dan jaringan sekolah cukup lega. Kompresi menghemat sekitar 5× bandwidth untuk SVG kartu.
- Satu kelas 25 siswa sangat jauh di bawah beban uji 100 bot.

## Daftar periksa rilis

- [ ] `npm run lint && npm run typecheck && npm test` hijau
- [ ] Tes kebocoran lulus (`apps/server/test`)
- [ ] `JWT_SECRET` acak, HTTPS/WSS aktif, `ALLOWED_ORIGINS` dikunci ke domain sekolah
- [ ] `HttpSimpeteriAdapter` diisi setelah kontrak SIMPETERI dipastikan (`docs/API.md`)
- [ ] Cadangan harian `data/runtime/state.json`
- [ ] Uji coba satu kelas nyata dan kalibrasi tingkat kesulitan
- [ ] Ambang diskualifikasi tidak menghasilkan salah-deteksi pada uji coba (cek `CheatFlag`)
- [ ] Guru sudah membaca `docs/PANDUAN_GURU.md` (Pulihkan dan Cabut daftar hitam)

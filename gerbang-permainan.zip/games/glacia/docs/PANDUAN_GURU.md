# Panduan Guru: Menjalankan GLACIA di Kelas

## Sebelum kelas (5 menit)

1. Buka alamat GLACIA di laptop yang tersambung ke proyektor, pilih **Aku guru**, lalu masukkan **PIN guru** dari pengelola server. (Dari menu Multi Permainan SIMPETERI: tombol di sana membuka halaman ini dan mengirim daftar siswa serta PIN otomatis.)
2. Isi **Nama kelas** dan tempel **Daftar siswa** (satu nama per baris, boleh langsung dari Excel; tidak perlu bila dibuka dari SIMPETERI). Klik **Buka ruangan**. Semua kolom lain diisi sendiri:
   - **Jumlah ronde** (disebut "kotak"). Satu kotak berisi 64 angka. Lima kotak berarti **320 angka**.
   - **Waktu tiap ronde** adalah batas atas. Kotak ditutup lebih cepat kalau semua kartu benar sudah diklaim.
   - **Mode klaim** nyala: jawaban benar pertama mengambil kartu, teman tidak bisa menekannya lagi.
3. Pilih kategori yang boleh muncul (**minimal 1**). Setiap kartu kategori menampilkan trik yang akan dipelajari siswa. Bila hanya satu kategori yang dipilih, tidak ada giliran memilih: ronde langsung dimulai.
4. Klik **Buka ruangan**. Layar menampilkan PIN dan kode QR. Klik **Buka layar proyektor** dan seret jendela itu ke proyektor.

## Saat siswa masuk

Siswa membuka alamat yang sama, memilih **Aku siswa**, mengetik PIN, lalu mengetuk nama sendiri di daftar hadir. Satu nama hanya bisa dipakai satu perangkat. Siswa yang lupa PIN cukup melihat layar proyektor.

Mulai bila yang online sudah cukup (minimal 2). Siswa yang terlambat tidak bisa masuk setelah permainan berjalan.

## Menu guru

| Menu | Isi |
|---|---|
| **Permainan** | buat ruangan dan kendalikan permainan yang berjalan |
| **Hasil** | semua permainan yang sudah selesai. Klik satu untuk melihat papan peringkat lengkap, unduh CSV, salin tautan ringkasan, atau kirim ulang ke SIMPETERI |
| **Daftar hitam** | siswa yang diblokir, bukti, dan tombol **Cabut** |
| **Diagnostik** | server sehat atau tidak, antrean kiriman ke SIMPETERI (dengan tombol **Kirim ulang semua**), ruangan aktif, dan jejak audit |
| **Keluar** | keluar dari akun guru di perangkat ini |

## Selama permainan

| Tombol | Fungsi |
|---|---|
| **Mulai** | memutar roda: satu siswa (yang belum pernah) memilih kategori |
| **Jeda / Lanjutkan** | membekukan waktu. Jawaban ditolak selama jeda |
| **Akhiri ronde** | menutup kotak sekarang dan menghitung skornya |
| **Akhiri permainan** | menghitung kotak yang berjalan, lalu langsung menampilkan papan peringkat dan membuat laporan |
| **Keluarkan** | mengeluarkan siswa dari ruangan |
| **Diskualifikasi** | tulis alasan (wajib). Boleh sekaligus masuk daftar hitam |

Semua siswa memegang **papan yang sama** (64 kartu, urutan sama). Kartu yang sudah diklaim memperlihatkan nama pengklaimnya dan tidak bisa ditekan lagi. Bila seluruh kartu benar di satu kotak sudah diklaim, kotak berikutnya mulai otomatis. Setelah **tiap kotak** tampil **papan peringkat sementara** (siswa bisa mengetuk nama untuk melihat rincian dan mengurutkan menurut skor total atau skor kotak itu). Di proyektor, kartu yang sudah diklaim berubah menjadi **avatar pengklaimnya**. Setelah kotak terakhir, permainan **langsung berakhir** walaupun waktu masih banyak, dan papan peringkat akhir tampil di proyektor dan di HP siswa.

## Kalau ada yang didiskualifikasi

Sistem mendiskualifikasi otomatis siswa yang **pindah tab/jendela lebih dari 2 detik lalu menjawab benar 4 kali berturut-turut** (bisa dinaikkan jadi 5 di pengaturan). Yang terjadi:

- siswa itu keluar dari papan skor dan roda, skornya 0, dan masuk **daftar hitam** (berlaku di semua ruangan sampai dicabut);
- kartu yang pernah ia klaim dibuka lagi untuk siswa lain;
- layar proyektor menampilkan pemberitahuan (nama, inisial, atau hanya jumlah sesuai pengaturanmu), **tanpa bukti**;
- bukti lengkap hanya ada di panel guru dan halaman **Daftar Hitam**.

**Salah deteksi itu mungkin.** Siswa yang tidak sengaja pindah tab lalu kebetulan menjawab benar 4 kali bisa terkena. Kalau begitu:

- **Pulihkan** (di panel pemain, di ruangan yang sama): skor dikembalikan dan daftar hitam dicabut.
- **Cabut** (menu **Daftar Hitam**): wajib mengisi catatan. Siswa boleh masuk lagi di ruangan berikutnya.

Keduanya tercatat di jejak audit. Setelah uji coba pertama, lihat daftar peringatan kecurangan. Kalau banyak peringatan yang ternyata salah, naikkan ambang ke 5.

## Setelah permainan

- **Unduh laporan (CSV)** untuk Excel (hasil per siswa dan per kategori).
- **Salin tautan ringkasan** untuk menu *Buat Multi Permainan* di SIMPETERI.
- **Kirim ulang ke SIMPETERI** bila pengiriman otomatis gagal. Hasil tidak hilang, disimpan di antrean.

## Uji coba pertama (disarankan)

Mainkan satu kelas nyata (±25 siswa) di Wi-Fi sekolah dan catat:

1. Persentase jawaban benar siswa. Targetnya 50–70%. Terlalu rendah berarti soal terlalu sulit.
2. Soal yang paling sering salah (muncul di pembahasan tiap ronde).
3. Peringatan kecurangan dan apakah ada yang salah-deteksi.
4. Apakah semua HP bisa memuat papan dengan lancar. Bila ada yang lambat, matikan kompresi (lihat `docs/DEPLOY.md`).

## Kalau ada masalah

| Gejala | Tindakan |
|---|---|
| Siswa tidak melihat namanya | nama sudah dipakai perangkat lain (abu-abu). Minta guru **Keluarkan** perangkat itu, lalu pilih ulang |
| Siswa terputus | cukup buka lagi alamat dan ketik PIN. Skor dan klaimnya tetap utuh |
| Layar proyektor kosong | buka ulang layar proyektor dengan PIN yang sama |
| Server dimulai ulang | ruangan yang berjalan hilang. Buat ruangan baru (daftar hitam tetap aman) |

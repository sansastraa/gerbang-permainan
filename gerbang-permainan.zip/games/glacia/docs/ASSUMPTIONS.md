# ASSUMPTIONS

Hal yang diputuskan sendiri karena blueprint ambigu atau tidak bisa dipenuhi di lingkungan pengembangan. Ubah di sini bila ternyata salah.

## Penyimpangan dari blueprint (stack)

| Blueprint | Yang dibangun | Alasan dan akibat |
|---|---|---|
| NestJS | Express + Socket.IO biasa | Lebih sedikit lapisan untuk satu server. Struktur modul tetap sama (`room`, `gateway`, `report`, `integration`, `outbox`). |
| PostgreSQL + Prisma | `Store` berkas JSON (`data/runtime/state.json`, ditulis atomik) | Hanya untuk data yang harus bertahan lebih lama dari ruangan: daftar hitam, audit, outbox, laporan. **Hanya cocok untuk satu server.** Ganti dengan Postgres sebelum dipakai multi-server (antarmuka ada di `store.ts`). |
| Redis | Tidak ada. State ruangan aktif disimpan di memori | **Server dimulai ulang = ruangan yang sedang berjalan hilang.** Siswa harus membuat ulang. Pemulihan state ruangan belum dibuat. |
| Next.js + Tailwind + pnpm + Turborepo | Vite + React + CSS biasa, npm workspaces | Aplikasi ini murni client-side, tidak butuh SSR. |
| Docker Compose postgres+redis | `docker-compose.yml` satu layanan | Menyesuaikan di atas. |
| JWT library | HS256 buatan sendiri (`auth.ts`, `timingSafeEqual`) | Satu algoritma saja. Ganti bila SIMPETERI memakai kunci publik. |
| k6/Artillery | `tools/bots.ts` (socket.io-client) | Lebih mudah menghitung kecocokan skor langsung dari event. |

## Aturan permainan

1. **"Board ganjil ganti lagi"** diwujudkan sebagai *Board Refresh* di tengah ronde 1, 3, 5. Hanya kartu yang belum dijawab siapa pun yang diganti dan jumlah kartu benar tetap 26–32. Bila maksudnya lain, ubah `refreshBoard()` dan `boardRefreshOddRounds`.
2. Waktu berpikir dihitung dari **jeda sejak jawaban benar terakhir** pemain itu (atau awal ronde), bukan dari awal ronde.
3. **Mode klaim (permintaan guru, `claimMode`, default aktif).** Jawaban *benar* pertama mengklaim kartu dan kartu itu terkunci untuk semua pemain lain; pemain yang kalah balapan tidak kehilangan poin dan tidak kena cooldown. Konsekuensinya:
   - **First Blood dan bonus ronde sempurna tidak dipakai** pada mode klaim (balapan sudah terjadi di kartu itu sendiri). Dengan `claimMode=false` perilaku lama kembali (papan bersama).
   - Jawaban **salah tidak mengklaim apa pun**, supaya pengecoh tidak otomatis ketahuan oleh pemain lain. Teman yang menekan pengecoh yang sama tetap kena penalti.
   - Pemenang ditentukan oleh **urutan datang di server**, bukan waktu klien.
   - Pengklaim yang didiskualifikasi **kehilangan klaimnya** (`card:released`); kartunya bisa diambil lagi.
   - Jumlah kartu benar yang tersisa ditampilkan (`remaining`) tanpa menyebut kartu mana. Bila semuanya sudah diklaim, ronde berakhir otomatis 1,5 detik kemudian.
4. Tombol host **Akhiri ronde** dan **Akhiri permainan** ada di panel guru. Akhiri permainan menghitung ronde yang sedang berjalan, lalu membuat papan juara dan laporan. Jumlah ronde di laporan bisa kurang dari pengaturan.
5. Satu siswa satu perangkat. Bila siswa berbagi laptop, aturan `MULTI_DEVICE` perlu dilonggarkan. Pemilihan nama yang sama dari perangkat kedua ditolak (`NAME_TAKEN`) dan tercatat sebagai `MULTI_DEVICE`.
6. Ke-15 kategori v2 (satuan 7/3/9, ganjil, genap, kelipatan 3/4/5/6/7/9, kuadrat, prima, sisa 5 bersisa 2, hasil antara 100–200) menggantikan kategori modular versi 1. Trik tiap kategori ada di `kategori[].trik`.
7. Daftar nama di layar PIN muncul begitu 6 digit terisi. Daftar ini hanya memuat nama dan status "sudah dipakai", **tidak pernah** status daftar hitam.

8. **Papan bersama dan balapan sungguhan (permintaan guru).** Semua siswa mendapat **soal yang sama dengan urutan yang sama**: kartu dari generator diacak **sekali** per kotak (benar dan pengecoh bercampur), lalu disiarkan satu kali ke semua siswa. Efek samping baik: pesan `round:start` yang besar cukup dikirim sekali.
   - **Satu kotak = satu ronde = 64 angka.** Lima kotak = **320 angka**. Jumlah kotak diatur guru (1–10).
   - **"Kotak penuh"** diartikan: semua kartu **benar** sudah diklaim. Pengecoh tidak pernah bisa diklaim (jawaban salah tidak mengklaim apa pun), jadi tidak ikut dihitung. Bila yang dimaksud lain, ubah `endEarlyIfAllClaimed()`.
   - Kotak ditutup otomatis 1,5 detik setelah kartu benar terakhir diklaim, lalu kotak berikutnya (roda pemilih kategori, hitung mundur) berjalan. Waktu ronde hanya batas atas.
   - Setelah **kotak terakhir**, permainan **langsung berakhir** (tanpa menunggu 20 detik hasil ronde dan tanpa menunggu sisa waktu) dan papan peringkat tampil di proyektor, HP siswa, dan panel guru.
   - Konsekuensi keamanan: karena semua melihat papan yang sama, siswa bisa saling mencontek lewat layar teman. Mode klaim membuat itu kurang berguna (kartu yang sudah diambil terkunci), tapi tidak menghilangkannya.
9. **Pelonggaran batas pengaturan (permintaan guru: kolom diisi bebas).** Jumlah ronde 1–10 (sebelumnya 3–5), waktu ronde 20–900 detik (sebelumnya 60–300), waktu memilih kategori 5–60 detik, penalti salah 0–2000 poin, kunci setelah salah 0–10 detik. **Ambang anti-curang tidak dilonggarkan** (benar beruntun tetap 4–5; `minBlurMs` dan `blurArmWindowSec` tetap). Bila rondenya melebihi jumlah kategori yang dipilih, kategori boleh berulang.
11. **Tanpa data contoh (permintaan guru).** Aplikasi tidak membawa siswa, peringkat, atau akun palsu. Mode `mock` dan halaman `#/preview` dihapus; data uji tinggal di `apps/server/test`. Tanpa SIMPETERI guru menempel nama siswa sendiri (mode `mandiri`); id siswa dibuat dari namanya, jadi dua siswa sekelas dengan nama sama diberi `(2)`.
10. **Profil siswa** disimpan hanya di perangkat siswa (`localStorage`: permainan, skor terbaik, kartu diklaim, pangkat). Tidak dikirim ke server dan tidak ada akun.
## Anti-curang

- **Batas yang tidak bisa dihilangkan:** tidak ada sistem yang kebal terhadap pemotretan layar ke AI di perangkat lain. Tujuan sistem ini membuat kecurangan tidak efisien dan mudah terlihat. Tantangan terhadap AI/kalkulator **tidak** dicapai lewat soal di luar kurikulum, tetapi lewat waktu singkat, papan 64 kartu, Board Refresh, dan perebutan kartu. (Urutan acak per pemain dari blueprint 7.4 **dihapus**: kini semua siswa memegang papan yang sama, lihat butir 8.)
- **Risiko salah-deteksi.** Siswa yang tidak sengaja pindah tab ≥ 2 detik lalu menjawab benar 4 kali bisa terkena diskualifikasi otomatis dan daftar hitam. Mitigasi: `minBlurMs`, `blurArmWindowSec`, ambang 5, bukti lengkap tersimpan, tombol **Pulihkan** (reinstate) dan **Cabut** (lift) untuk guru. Pada uji coba kelas, periksa `CheatFlag` untuk melihat apakah ambang perlu dinaikkan.
- Deteksi `TOO_FAST`, `UNIFORM_TIMING`, `BURST` hanya menandai (peringatan untuk guru), tidak mendiskualifikasi.
- Pemain terdiskualifikasi dikunci per **perangkat hanya selama ruangan itu**. Daftar hitam berlaku per siswa di semua ruangan sampai dicabut.

## Data dan privasi

- Yang disimpan: `studentId`, nama tampilan, jawaban dan waktu. Tidak ada email, foto, atau lokasi.
- Log server tidak mencatat nama siswa.
- Pakai HTTPS/WSS di produksi (lihat `docs/DEPLOY.md`).

## Tampilan

- Font utama `Product Sans → Google Sans → Outfit`. Product Sans adalah font berlisensi Google dan tidak dimuat otomatis; bila tidak terpasang di perangkat, yang tampil Outfit (Google Fonts).
- Tampilan kartu soal berupa SVG hasil render MathJax (`<path>`, tanpa `<text>`) dan tidak bisa diseleksi/disalin sebagai teks.

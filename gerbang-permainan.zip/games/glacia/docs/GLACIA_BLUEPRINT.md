# GLACIA — Blueprint Implementasi untuk Claude Code

> Game kuis numerik multiplayer real-time untuk siswa **kelas 6 SD**, terintegrasi dengan **SIMPETERI**.
> Dokumen ini adalah spesifikasi kerja untuk Claude Code. Baca seluruhnya sebelum menulis kode, lalu kerjakan **per milestone (bagian 14)**. Jangan lompat milestone.

---

## 0. Cara Kerja untuk Claude Code

1. Kerjakan satu milestone sekali waktu. Di akhir tiap milestone: jalankan `pnpm lint && pnpm typecheck && pnpm test`, lalu ringkas apa yang selesai dan apa yang belum.
2. **Aturan keamanan yang tidak boleh dilanggar** (lihat bagian 11):
   - Kunci jawaban (`isCorrect`) **tidak pernah** dikirim ke klien selama ronde berjalan.
   - Server adalah satu-satunya sumber kebenaran untuk waktu, spin, skor, dan validasi jawaban.
3. Semua aturan skor/papan ada di `packages/shared` sebagai **fungsi murni** dengan unit test. Jangan menduplikasi logika di web atau server.
4. Integrasi SIMPETERI belum diketahui stack-nya: implementasikan lewat **interface + adapter mock** (bagian 9). Jangan mengarang endpoint SIMPETERI yang sebenarnya.
5. Bahasa antarmuka: **Bahasa Indonesia**, sederhana, ramah anak kelas 6 SD. Kode, nama variabel, dan komentar: **bahasa Inggris**.
6. **Aturan diskualifikasi otomatis + blacklist (bagian 11.1) wajib diimplementasikan persis**, dengan logika murni di `packages/shared` dan unit test lengkap. Jangan melonggarkan atau mengubah ambang tanpa instruksi.
7. Bila ada ambiguitas, ambil asumsi paling sederhana, catat di `docs/ASSUMPTIONS.md`, lalu lanjut. Jangan berhenti bertanya kecuali blokir total.

---

## 1. Ringkasan Produk

| Hal | Keputusan |
|---|---|
| Nama | **GLACIA — Arena Pemburu Angka** (tema es/gletser) |
| Pemain | 10–40 per room (diuji sampai 100) |
| Peran | Host (guru), Player (siswa), Display (proyektor) |
| Ronde | 5 per game |
| Papan | **64 kartu (8×8)** per ronde |
| Kartu benar per papan | **26–32 (40,6%–50%)**, jumlah diacak tiap papan |
| Durasi ronde | default 120 detik, host bisa atur 60–300 |
| Kategori | 15 kategori di bank; 5 kategori ditawarkan per game |
| Bank soal | 15 × 500 = 7.500 operasi (file `bank_soal_glacia.json` **v2, ramah SD**, sudah ada) |
| Materi soal | Hanya level SD kelas 6: + − × ÷, hitung campuran, kurung, kuadrat, pangkat tiga, akar kuadrat/akar pangkat tiga. **Dilarang**: sigma, faktorial, pangkat besar, nilai mutlak, modular/sisa bagi 9 |
| Skor | 1000 poin/kartu benar, −10 poin tiap detik berpikir |
| Roda spin | Berisi **sebanyak nama pemain yang masuk** (online, belum memilih, tidak didiskualifikasi) |
| Diskualifikasi otomatis | Setelah **Tab Blur** terdeteksi lalu menjawab **benar berturut-turut 4 kali** (bisa 4–5) → langsung didiskualifikasi dari papan (termasuk layar proyektor) **dan masuk daftar hitam** |
| Blacklist | Permanen per siswa, berlaku di semua room/ujian berikutnya, dapat dicabut hanya oleh host/admin dengan jejak audit |

### 1.1 Alur Singkat

```
Host login (SIMPETERI) → buat room + pengaturan → PIN 6 digit + QR
→ siswa input PIN → pilih nama dari roster kelas → lobi
→ host Mulai → [ulangi 5 ronde:
     SPIN pemilih (yang belum pernah) → pemilih memilih 1 dari 5 kategori
     → hitung mundur → ronde berjalan (papan 64 kartu) → hasil ronde + pembahasan ]
→ skor akhir + podium → kirim laporan ke SIMPETERI
```

### 1.2 Definisi Penting

- **Kartu**: satu operasi bilangan di papan. Pemain menekan kartu jika menurutnya hasilnya memenuhi kategori ronde.
- **Kartu benar**: kartu yang hasilnya memenuhi kategori. **Pengecoh**: sisanya.
- **Pemilih**: pemain yang berhak memilih kategori pada ronde itu (hasil spin).
- **First Blood**: bonus untuk 3 pemain tercepat yang menjawab benar pada kartu yang sama.

---

## 2. Tech Stack (final)

| Lapisan | Pilihan |
|---|---|
| Monorepo | pnpm workspaces + Turborepo |
| Bahasa | TypeScript strict di semua paket |
| Web | Next.js 14 (App Router) + React 18 + Tailwind CSS, PWA |
| Server | NestJS 10 + Socket.IO (adapter Redis) |
| DB | PostgreSQL 16 + Prisma |
| Cache/state | Redis 7 (state room aktif, pub/sub, rate limit) |
| Validasi | zod (skema dibagi di `packages/shared`) |
| Render soal | LaTeX → **SVG** lewat `mathjax-full` saat import (bukan teks) |
| Test | Vitest (unit), Supertest + socket.io-client (integrasi), k6 atau Artillery (beban) |
| Lint/format | ESLint + Prettier |
| Dev env | Docker Compose (postgres, redis) |

---

## 3. Struktur Repo

```
glacia/
├─ apps/
│  ├─ web/                    # Next.js: /host, /play, /display
│  │  ├─ app/
│  │  │  ├─ (player)/play/...        # join, pilih nama, lobi, papan, hasil
│  │  │  ├─ (host)/host/...          # dasbor, pengaturan, kontrol, laporan
│  │  │  └─ (display)/display/[pin]  # layar proyektor
│  │  ├─ components/                 # Board, Card, Timer, SpinWheel, Scoreboard, Podium
│  │  └─ lib/socket.ts, lib/clock.ts
│  └─ server/                 # NestJS
│     └─ src/
│        ├─ rooms/            # RoomService, RoomGateway, state machine
│        ├─ game/             # RoundService, BoardService, ScoringService
│        ├─ bank/             # QuestionRepository, importer
│        ├─ integration/      # SimpeteriPort + adapters (mock, http)
│        ├─ anticheat/        # CheatFlagService
│        └─ common/           # auth guards, rate limit, logger
├─ packages/
│  ├─ shared/                 # zod schemas, event types, scoring, sampler, seeded RNG
│  └─ config/                 # tsconfig, eslint presets
├─ tools/
│  ├─ glacia_generator.py     # generator soal (sudah ada)
│  ├─ import-bank.ts          # impor bank JSON → DB (+ render SVG)
│  └─ bots/                   # simulator pemain untuk uji beban
├─ data/
│  └─ bank_soal_glacia.json   # 7.500 operasi (sudah ada)
├─ docs/ (ASSUMPTIONS.md, API.md, EVENTS.md)
├─ docker-compose.yml
└─ CLAUDE.md                  # salin Bagian 0 + perintah dev
```

---

## 4. Konfigurasi & Environment

```env
# apps/server/.env
DATABASE_URL=postgresql://glacia:glacia@localhost:5432/glacia
REDIS_URL=redis://localhost:6379
JWT_SECRET=change-me
ROOM_PIN_LENGTH=6
SIMPETERI_MODE=mock            # mock | http
SIMPETERI_BASE_URL=
SIMPETERI_API_KEY=
SIMPETERI_JWT_PUBLIC_KEY=
CORS_ORIGIN=http://localhost:3000

# apps/web/.env
NEXT_PUBLIC_SERVER_URL=http://localhost:4000
```

### 4.1 Pengaturan Room (`RoomSettings`, zod di `packages/shared`)

| Field | Tipe | Default | Batas |
|---|---|---|---|
| `classId` | string | wajib | dari SIMPETERI |
| `maxPlayers` | int | jumlah siswa kelas | 2–100 |
| `rounds` | int | 5 | 3–5 |
| `roundSeconds` | int | 120 | 60–300 |
| `categoryPickSeconds` | int | 15 | 10–30 |
| `boardSize` | literal | **64** | tetap 64 |
| `correctRatioMin` / `Max` | float | 0.40 / 0.50 | 0.30–0.60 |
| `difficulty` | enum | `challenge` | `regular` \| `challenge` |
| `wrongPenalty` | int | 250 | 0–500 |
| `wrongCooldownMs` | int | 2000 | 0–5000 |
| `firstBlood` | bool | true | — |
| `boardRefreshOddRounds` | bool | true | — |
| `allowedCategoryIds` | int[] | 1–15 | min 5 |
| `autoDisqualify` | bool | true | — |
| `cheatStreakThreshold` | int | **4** | 4–5 |
| `minBlurMs` | int | 2000 | 500–10000 |
| `blurArmWindowSec` | int | 90 | 30–300 |
| `autoBlacklist` | bool | true | — |
| `showDisqualifiedOnDisplay` | enum | `NAME` | `NAME` \| `INITIALS` \| `COUNT_ONLY` |

---

## 5. Model Data (Prisma)

```prisma
model Category {
  id        Int        @id            // 1..15
  name      String
  trick     String
  active    Boolean    @default(true)
  questions Question[]
}

model Question {
  id         String   @id            // "K01-001"
  categoryId Int
  category   Category @relation(fields: [categoryId], references: [id])
  exprText   String                  // "73¹⁰⁰ + 8"
  latex      String
  svg        String                  // hasil render MathJax, tanpa teks yang bisa disalin
  tier       Tier                    // EASY | MEDIUM | HARD
  kind       String                  // "Perkalian", "Kurung dikali", "Akar kuadrat", dst.
  result      Int                    // hasil eksak (selalu bilangan bulat ≤ 1.500)
  unitDigit   Int
  parity      String
  explanation String                 // pembahasan siap pakai, hanya dikirim di round:end
  isCorrect   Boolean                // memenuhi kategori ini (KUNCI, jangan bocor)
  @@index([categoryId, isCorrect, tier])
}

model Room {
  id        String   @id @default(uuid())
  pin       String   @unique
  hostId    String                   // id guru di SIMPETERI
  classId   String
  settings  Json
  status    RoomStatus
  createdAt DateTime @default(now())
  endedAt   DateTime?
  players   RoomPlayer[]
  rounds    Round[]
  spins     Spin[]
}

model RoomPlayer {
  id           String  @id @default(uuid())
  roomId       String
  studentId    String                // id siswa di SIMPETERI
  displayName  String
  deviceToken  String?               // mengunci 1 nama = 1 perangkat
  hasPicked    Boolean @default(false)
  totalScore   Int     @default(0)
  disqualified      Boolean   @default(false)
  disqualifiedAt    DateTime?
  disqualifyReason  String?             // BLUR_STREAK | HOST_MANUAL
  rawScore          Int       @default(0)   // skor asli sebelum dibatalkan (untuk audit/pemulihan)
  @@unique([roomId, studentId])
}

model Round {
  id         String   @id @default(uuid())
  roomId     String
  number     Int                     // 1..5
  categoryId Int
  pickerId   String
  seed       String
  startedAt  DateTime?
  endsAt     DateTime?
  refreshAt  DateTime?
  cards      RoundCard[]
  answers    Answer[]
  @@unique([roomId, number])
}

model RoundCard {
  id         String  @id @default(uuid())   // ID kartu OPAQUE yang dikirim ke klien
  roundId    String
  questionId String
  slot       Int                            // posisi kanonik 0..63
  version    Int     @default(0)            // naik saat Board Refresh
  isCorrect  Boolean                        // salinan kunci (server-only)
  replacedBy String?
}

model Answer {
  id            String   @id @default(uuid())
  roundId       String
  playerId      String
  cardId        String
  correct       Boolean
  thinkMs       Int
  points        Int
  bonus         Int      @default(0)
  serverTime    DateTime
  invalidated   Boolean  @default(false)   // true bila pemain kemudian didiskualifikasi
  @@unique([roundId, playerId, cardId])
}

model Spin {
  id        String @id @default(uuid())
  roomId    String
  roundNo   Int
  eligible  Json
  pickedId  String
  rngSeed   String
}

model CheatFlag {
  id       String @id @default(uuid())
  roomId   String
  playerId String
  roundNo  Int
  type     String      // TAB_BLUR | ANSWER_WHILE_HIDDEN | BLUR_STREAK_DQ | TOO_FAST | UNIFORM_TIMING | MULTI_DEVICE | BURST
  detail   Json
  at       DateTime @default(now())
}

model Blacklist {
  id          String    @id @default(uuid())
  studentId   String                    // id siswa di SIMPETERI (kunci utama)
  reason      String                    // BLUR_STREAK | HOST_MANUAL
  roomId      String?                   // room tempat pelanggaran
  evidence    Json                      // bukti: flag blur, 5 jawaban terakhir, streak (lihat 11.1)
  createdAt   DateTime  @default(now())
  liftedAt    DateTime?                 // null = aktif
  liftedBy    String?
  liftNote    String?
  syncedToSimpeteri Boolean @default(false)
  @@index([studentId, liftedAt])
}

model AuditLog {
  id        String   @id @default(uuid())
  actorId   String                      // host/admin
  action    String                      // BLACKLIST_LIFT | REINSTATE | MANUAL_DQ | ...
  target    String
  detail    Json
  at        DateTime @default(now())
}

enum Tier { EASY MEDIUM HARD }
enum RoomStatus { CREATED LOBBY SPIN PICK COUNTDOWN RUNNING ROUND_RESULT FINAL DONE PAUSED }
```

> `RoundCard.id` adalah UUID acak, **bukan** `questionId`, supaya klien tidak bisa memetakan kartu ke soal.

---

## 6. Impor Bank Soal

File: `data/bank_soal_glacia.json` (7.500 baris soal). Struktur tiap soal:

```json
{
  "id": "K01-001", "kategori_id": 1, "kategori": "Memiliki satuan 7",
  "ekspresi": "(2 + 11)² − 22", "latex": "(2+11)^2-22", "tingkat": "Menantang",
  "jenis": "Kuadrat dikurangi", "hasil": "147", "satuan": 7,
  "paritas": "Ganjil", "memenuhi": true,
  "pembahasan": "Hasil = 147. Satuannya 7. Memenuhi."
}
```

**Tugas `tools/import-bank.ts`:**

1. Upsert 15 kategori (nama + `trik` dari objek `kategori` di JSON).
2. Untuk tiap soal: render `latex` → SVG dengan `mathjax-full` (tex2svg), simpan di `svg`. Hapus atribut yang membuat teks bisa dipilih; pakai `<path>` glyph (fontCache none) bukan `<text>`.
3. Map `tingkat`: Mudah→EASY, Sedang→MEDIUM, Menantang→HARD. `memenuhi`→`isCorrect`, `hasil`→`result` (int), `pembahasan`→`explanation`.
4. Idempoten (aman dijalankan ulang). Cetak ringkasan: per kategori 225 benar + 275 pengecoh, total 7.500.
5. Test: setelah impor, `count == 7500` dan tiap kategori punya tepat 225 `isCorrect=true`.

### 6.1 Daftar Kategori v2 (ramah SD kelas 6)

| No | Kategori | Trik untuk siswa |
|---|---|---|
| 1 | Memiliki satuan 7 | Hitung hasilnya, lihat angka satuan |
| 2 | Memiliki satuan 3 | idem |
| 3 | Memiliki satuan 9 | idem |
| 4 | Bilangan ganjil | Satuan 1, 3, 5, 7, 9 |
| 5 | Bilangan genap | Satuan 0, 2, 4, 6, 8 |
| 6 | Kelipatan 3 | Jumlah angka habis dibagi 3 |
| 7 | Kelipatan 4 | Dua angka terakhir habis dibagi 4 |
| 8 | Kelipatan 5 | Satuan 0 atau 5 |
| 9 | Kelipatan 6 | Genap dan jumlah angka habis dibagi 3 |
| 10 | Kelipatan 9 | Jumlah angka habis dibagi 9 |
| 11 | Kelipatan 7 | Bagi 7, tidak bersisa |
| 12 | Bilangan kuadrat | Hasil kali bilangan dengan dirinya sendiri (maks 900) |
| 13 | Bilangan prima | Hanya faktor 1 dan dirinya sendiri (maks 199) |
| 14 | Jika dibagi 5 bersisa 2 | Satuan 2 atau 7 |
| 15 | Hasilnya antara 100 dan 200 | Hitung lalu bandingkan |

Tingkat soal: **Mudah** = 1–2 langkah (mis. `616 ÷ 8`), **Sedang** = 2–3 langkah, kurung, kuadrat (mis. `7 × 43 + 2 × 8`, `8³ − 3`, `√36 + 51`), **Menantang** = 3–4 langkah (mis. `(2 + 11)² − 22`, `√144 × 5 + 7`). Semua hasil bilangan bulat ≤ 1.500.

---

## 7. Logika Inti (`packages/shared`, fungsi murni + unit test)

### 7.1 Seeded RNG

Pakai `mulberry32` atau `xoshiro128**` dengan seed string → angka. Semua pengacakan yang butuh bisa diaudit (spin, papan, permutasi pemain) memakai RNG ini dan menyimpan seed-nya.

### 7.2 Skor

```ts
export const SCORING_DEFAULTS = {
  base: 1000, decayPerSec: 10, floor: 100,
  wrongPenalty: 250,
  firstBlood: [300, 200, 100],
  perfectRoundBonus: 500,
};

/** thinkMs = server receivedAt - (waktu aksi benar terakhir pemain | startedAt ronde) */
export function pointsForCorrect(thinkMs: number, cfg = SCORING_DEFAULTS): number {
  const sec = Math.floor(thinkMs / 1000);
  return Math.max(cfg.floor, cfg.base - cfg.decayPerSec * sec);
}

export function firstBloodBonus(rank: number /*1-based*/, cfg = SCORING_DEFAULTS): number {
  return cfg.firstBlood[rank - 1] ?? 0;
}
```

Aturan:

- Jawaban **salah** tidak mereset penghitung waktu berpikir; kena `-wrongPenalty` dan kartu terkunci cooldown `wrongCooldownMs`.
- Satu pemain hanya boleh menjawab satu kartu **satu kali** (`@@unique` di Answer).
- Bonus ronde sempurna: semua kartu benar ditemukan **dan** nol jawaban salah.
- Skor ronde tidak boleh membuat total negatif di level ronde: `roundScore = max(0, sum)`.
- Penentu pemenang game: total skor → total benar → paling sedikit salah → rata-rata `thinkMs` terendah.

### 7.3 Sampler Papan

```ts
export interface SampleOpts {
  categoryId: number; size: 64;
  ratioMin: number; ratioMax: number;   // 0.40–0.50
  tierWeights: {EASY: .30, MEDIUM: .45, HARD: .25};
  excludeQuestionIds: Set<string>;
  seed: string;
}
// k = randInt(ceil(size*ratioMin), floor(size*ratioMax))  // 64 → 26..32
// ambil k dari isCorrect=true dan (64-k) dari isCorrect=false,
// masing-masing mengikuti tierWeights, lalu acak urutan slot.
```

Syarat yang harus lolos test:

- Selalu tepat 64 kartu unik; jumlah benar ∈ [26, 32].
- Komposisi tier dalam ±5% dari bobot pada rata-rata 1.000 papan.
- Tidak memakai soal di `excludeQuestionIds` (riwayat room), kecuali pool habis.

### 7.4 Permutasi per pemain

`playerOrder = seededShuffle(slots, hash(roundSeed + playerId))`. Server mengirim ke tiap pemain daftar kartu dalam urutan permutasinya; Display memakai urutan kanonik.

### 7.5 Board Refresh (ronde ganjil: 1, 3, 5)

Pada `refreshAt = startedAt + roundSeconds / 2`:

- Kartu yang **belum dijawab oleh pemain mana pun** diganti dengan soal baru dari kategori yang sama.
- Pertahankan jumlah benar/pengecoh tiap tier agar total benar papan tetap di 26–32.
- Kartu yang sudah pernah dijawab siapa pun tidak diganti.
- `RoundCard.version++`, simpan `replacedBy`. Broadcast `board:refresh` berisi hanya kartu baru (tanpa kunci).

### 7.6 Roda Spin = Sebanyak Nama yang Masuk

- Segmen roda **persis** sejumlah pemain *eligible*: `online && !hasPicked && !disqualified && !blacklisted`.
- Saat semua pemain eligible sudah pernah memilih, siklus di-reset: roda berisi semua pemain aktif lagi.
- Server menentukan pemenang lebih dulu (RNG ber-seed, disimpan di `Spin`), animasi hanya menyesuaikan jumlah segmen.
- Selama status SPIN/PICK, jika ada pemain keluar, masuk, atau didiskualifikasi, server mengirim `spin:wheel` baru. Jika pemain terpilih adalah yang baru didiskualifikasi/keluar, lakukan **spin ulang otomatis**.
- Tampilan: ≤ 12 nama → nama penuh di segmen; 13–40 nama → segmen memuat inisial dan nama-nama bergulir di sisi roda; hasil selalu menampilkan **nama lengkap** besar-besar.

### 7.7 Mesin Aturan Diskualifikasi (fungsi murni, `packages/shared/cheat-rule.ts`)

```ts
export interface CheatCfg {
  minBlurMs: number;          // default 2000
  blurArmWindowSec: number;   // default 90
  streakThreshold: number;    // default 4 (4..5)
}
export interface CheatState {
  hiddenSince: number | null; // epoch ms server, null bila tab terlihat
  armedUntil: number | null;  // pemantauan aktif sampai kapan
  streak: number;             // benar berturut-turut sejak di-arm
}
export const initialCheatState = (): CheatState => ({ hiddenSince: null, armedUntil: null, streak: 0 });

/** now = waktu SERVER. active = status room RUNNING. */
export function onVisibility(st: CheatState, hidden: boolean, now: number, active: boolean, cfg: CheatCfg):
  { state: CheatState; flag?: 'TAB_BLUR'; hiddenMs?: number } {
  if (hidden) return { state: { ...st, hiddenSince: st.hiddenSince ?? now } };
  const hiddenMs = st.hiddenSince !== null ? now - st.hiddenSince : 0;
  const base = { ...st, hiddenSince: null };
  if (!active || hiddenMs < cfg.minBlurMs) return { state: base };
  return {
    state: { ...base, armedUntil: now + cfg.blurArmWindowSec * 1000 },  // streak TIDAK direset
    flag: 'TAB_BLUR', hiddenMs,
  };
}

/** Dipanggil SETELAH server memvalidasi jawaban. hiddenAtAnswer = klien melaporkan tab sedang tersembunyi. */
export function onAnswer(st: CheatState, correct: boolean, now: number, hiddenAtAnswer: boolean, cfg: CheatCfg):
  { state: CheatState; flag?: 'ANSWER_WHILE_HIDDEN'; disqualify?: boolean } {
  let s = { ...st };
  let flag: 'ANSWER_WHILE_HIDDEN' | undefined;
  if (hiddenAtAnswer) { flag = 'ANSWER_WHILE_HIDDEN'; s.armedUntil = now + cfg.blurArmWindowSec * 1000; }
  if (s.armedUntil !== null && now > s.armedUntil) s = { ...s, armedUntil: null, streak: 0 };   // jendela habis
  if (s.armedUntil === null) return { state: s, flag };
  if (!correct) return { state: { ...s, streak: 0 }, flag };                                    // salah → streak 0
  const streak = s.streak + 1;
  return { state: { ...s, streak }, flag, disqualify: streak >= cfg.streakThreshold };
}
```

Aturan tambahan:

- Status ronde selain `RUNNING` (lobi, spin, pilih kategori, countdown, hasil ronde, PAUSED) **tidak** memicu arm.
- State di-reset saat ronde berganti (streak tidak dibawa ke ronde lain).
- Pemain yang sudah didiskualifikasi dikecualikan dari: roda spin, papan skor live, podium, papan akhir, dan perhitungan bonus ronde sempurna. Jawaban lamanya ditandai `invalidated=true` dan **tidak** dihitung untuk rank First Blood pada jawaban berikutnya; bonus First Blood yang sudah diterima pemain lain **tidak ditarik**.
- Penentu pemenang game hanya memakai pemain `disqualified=false`.

---

## 8. Mesin Status Room

```
CREATED → LOBBY → SPIN → PICK → COUNTDOWN → RUNNING → ROUND_RESULT
                    ↑___________________________________|   (jika ronde < total)
                                                      ROUND_RESULT → FINAL → DONE
PAUSED dapat dimasuki dari SPIN/PICK/RUNNING oleh host dan kembali ke status sebelumnya.
```

| Transisi | Pemicu | Syarat/efek |
|---|---|---|
| LOBBY→SPIN | host `game:start` | ≥2 pemain online; kunci pendaftaran |
| SPIN→PICK | server | `eligible` = online & `hasPicked=false` (jika kosong, reset semua); hasil spin dari RNG server, simpan di `Spin` |
| PICK→COUNTDOWN | pemilih `category:pick` atau timeout | timeout → pilih acak; `hasPicked=true`; bangun papan |
| COUNTDOWN→RUNNING | timer 3 detik | set `startedAt`, `endsAt`, `refreshAt` |
| RUNNING→ROUND_RESULT | `endsAt` terlewat | tutup jawaban; hitung bonus; kirim kunci + pembahasan |
| ROUND_RESULT→SPIN/FINAL | host `round:next` atau auto 20 detik | kirim laporan bila FINAL |

**Diskualifikasi dapat terjadi di status RUNNING saja** (aturan 11.1), tetapi dampaknya (roda, papan, podium) berlaku di semua status berikutnya. Bila pemain yang didiskualifikasi sedang menjadi pemilih (status PICK), lakukan auto-pick atau spin ulang (7.6).

Timer dijalankan di server (BullMQ delayed job atau `setTimeout` + penyimpanan `endsAt` di Redis agar tahan restart). Klien hanya menampilkan.

---

## 9. Integrasi SIMPETERI (Port & Adapter)

```ts
// apps/server/src/integration/simpeteri.port.ts
export interface SimpeteriPort {
  verifyHostToken(token: string): Promise<{ hostId: string; name: string; classIds: string[] }>;
  listClasses(hostId: string): Promise<{ id: string; name: string }[]>;
  listStudents(classId: string): Promise<{ studentId: string; name: string }[]>;
  submitResults(payload: GameResultPayload): Promise<void>;
  /** Blacklist GLOBAL per siswa. Wajib dipanggil saat diskualifikasi otomatis; retry via outbox. */
  blacklistStudent(studentId: string, reason: string, evidence: unknown, roomId: string): Promise<void>;
  isBlacklisted(studentId: string): Promise<boolean>;
  liftBlacklist(studentId: string, actorId: string, note: string): Promise<void>;
}

export interface GameResultPayload {
  roomId: string; classId: string; playedAt: string;
  students: {
    studentId: string; rank: number; totalScore: number;
    correct: number; wrong: number; avgThinkMs: number;
    status: 'OK' | 'DISQUALIFIED'; blacklisted: boolean; disqualifyReason?: string;
    perCategory: { categoryId: number; attempted: number; correct: number; wrong: number }[];
  }[];
}
```

- Implementasikan `MockSimpeteriAdapter` (roster 30 siswa palsu, token host dev) dan kerangka `HttpSimpeteriAdapter` yang membaca `SIMPETERI_BASE_URL`. Pilih lewat `SIMPETERI_MODE`.
- Siswa **tidak membuat akun**: setelah PIN valid, mereka memilih nama dari `listStudents`. Satu nama hanya bisa dikunci satu perangkat (`deviceToken`); nama yang sudah terambil tampil abu-abu.
- Pengiriman hasil: retry eksponensial 3×, lalu simpan ke tabel outbox agar bisa dikirim ulang dari dasbor host.
- Dokumentasikan kontrak yang dibutuhkan di `docs/API.md` supaya pemilik SIMPETERI bisa menyesuaikan sisi mereka.

---

## 10. Kontrak API & Event

### 10.1 REST (host)

| Method | Path | Fungsi |
|---|---|---|
| POST | `/auth/host` | tukar token SIMPETERI → JWT host |
| GET | `/classes` | daftar kelas host |
| POST | `/rooms` | buat room (`RoomSettings`) → `{ roomId, pin }` |
| GET | `/rooms/:id` | status room |
| PATCH | `/rooms/:id/settings` | ubah pengaturan (hanya status LOBBY) |
| GET | `/rooms/:id/report` | laporan akhir |
| POST | `/rooms/:id/report/resend` | kirim ulang ke SIMPETERI |
| GET | `/rooms/:id/cheat-flags` | daftar `CheatFlag` room (untuk panel host) |
| POST | `/rooms/:id/players/:playerId/disqualify` | diskualifikasi manual oleh host (alasan wajib) |
| POST | `/rooms/:id/players/:playerId/reinstate` | batalkan diskualifikasi (pulihkan skor dari `rawScore`, cabut blacklist) — hanya host/admin, tercatat di `AuditLog` |
| GET | `/blacklist` | daftar siswa yang masuk daftar hitam (filter kelas/aktif) beserta bukti |
| POST | `/blacklist/:studentId/lift` | cabut blacklist (body: `note`) — host/admin, tercatat di `AuditLog` |
| GET | `/health` | health check |

### 10.2 Socket.IO (namespace `/game`)

Semua payload divalidasi zod di server. Klien tidak mengirim waktu yang dipercaya: server memakai `receivedAt`.

| Event | Arah | Payload |
|---|---|---|
| `room:join` | C→S | `{ pin, deviceToken }` |
| `room:pickName` | C→S | `{ studentId }` |
| `room:state` | S→All | `{ status, players[], settings, roundNo, serverNow }` |
| `game:start` | Host→S | `{}` |
| `spin:result` | S→All | `{ eligible[], pickedPlayerId, animSeed }` |
| `category:options` | S→Picker | `{ categories[5], expiresAt }` |
| `category:pick` | Picker→S | `{ categoryId }` |
| `round:countdown` | S→All | `{ startsAt }` |
| `round:start` | S→All | `{ roundNo, category, endsAt, refreshAt?, cards: [{cardId, svg}] }` |
| `card:answer` | P→S | `{ cardId }` |
| `card:result` | S→P | `{ cardId, correct, points, bonus, cooldownUntil? }` |
| `scoreboard:live` | S→All | `{ top5: [{name, score}] }` (maks 1×/detik) |
| `board:refresh` | S→All | `{ replaced: [{oldCardId, cardId, svg}] }` |
| `round:end` | S→All | `{ roundScores[], keyReveal[], explanations[3] }` |
| `game:end` | S→All | `{ finalBoard[], podium[3] }` |
| `host:pause` / `host:resume` / `host:kick` | Host→S | `{ playerId? }` |
| `client:visibility` | P→S | `{ hidden: boolean }` (kirim tiap `visibilitychange` & `blur/focus`; server memakai waktunya sendiri) |
| `spin:wheel` | S→All | `{ segments: [{playerId, name}], count }` (diperbarui bila ada yang keluar/masuk/didiskualifikasi) |
| `cheat:flag` | S→Host | `{ playerId, name, type, detail, streak?, armedUntil? }` |
| `player:disqualified` | S→All | `{ playerId, displayName, mode: 'NAME'\|'INITIALS'\|'COUNT_ONLY', reason, at, totalDisqualified }` — tanpa bukti detail |
| `you:disqualified` | S→Player | `{ message, blacklisted: true }` lalu server memutus soket setelah 5 detik |
| `player:reinstated` | S→All | `{ playerId }` |
| `blacklist:rejected` | S→Player | `{ message }` — dikirim saat `room:join`/`room:pickName` oleh siswa yang diblacklist |

**Larangan payload:** `round:start`, `board:refresh`, dan `card:*` **tidak boleh** memuat `isCorrect`, `questionId`, `unitDigit`, `parity`, `result`, atau `explanation`. Tulis test yang memeriksa ini secara rekursif pada semua pesan ke klien.

---

## 11. Anti-Curang & Keamanan

| Lapisan | Implementasi |
|---|---|
| Kunci jawaban | Hanya di server (`RoundCard.isCorrect`). Kunci dikirim hanya pada `round:end` |
| ID opaque | `cardId` UUID acak per ronde |
| Waktu | Semua perhitungan memakai `serverNow`; `endsAt` absolut; klien menghitung offset jam |
| Tampilan soal | SVG path (bukan teks); `user-select: none`; matikan klik kanan di papan |
| Acak | Urutan kartu berbeda tiap pemain; urutan kategori diacak |
| Pindah tab | `client:visibility` → `CheatFlag TAB_BLUR` (hitung durasi). Dengan 4–5 jawaban benar beruntun sesudahnya → **diskualifikasi otomatis + blacklist** (11.1) |
| Jawaban terlalu cepat | thinkMs < 400 ms berulang → `TOO_FAST` |
| Pola waktu seragam | simpangan baku thinkMs sangat kecil pada ≥10 jawaban → `UNIFORM_TIMING` |
| Lonjakan benar | ≥8 benar dalam 10 detik → `BURST` |
| Multi-perangkat | satu `studentId` dari dua `deviceToken` → `MULTI_DEVICE`, tolak yang kedua |
| Rate limit | `card:answer` maks 5/detik per pemain; `room:join` maks 10/menit per IP |
| Dasbor host | tampilkan flag real-time; host bisa memperingatkan atau diskualifikasi ronde pemain |
| Data anak | simpan hanya `studentId` + nama tampilan; HTTPS/WSS; JWT berumur pendek |

> Tidak ada sistem yang kebal terhadap pemotretan layar ke AI. Tujuannya membuat kecurangan tidak efisien dan mudah terlihat; sebutkan batasan ini di `docs/ASSUMPTIONS.md`.

### 11.1 Aturan Diskualifikasi Otomatis & Blacklist (WAJIB)

**Tujuan:** siswa yang berpindah tab/jendela lalu langsung menjawab benar beruntun dianggap mencari jawaban dari luar (mis. AI). Sistem mendiskualifikasi langsung dan memasukkannya ke daftar hitam.

**Pemicu (default; semua angka dari `RoomSettings`):**

1. **Arm.** Saat `client:visibility {hidden:false}` diterima, status room `RUNNING`, dan durasi tersembunyi ≥ `minBlurMs` (2 detik) → simpan `CheatFlag TAB_BLUR` dan aktifkan pemantauan selama `blurArmWindowSec` (90 detik). Jawaban yang dikirim saat klien melaporkan tab tersembunyi → `ANSWER_WHILE_HIDDEN` dan ikut mengaktifkan pemantauan.
2. **Hitung.** Selama pemantauan aktif, tiap jawaban **benar** (divalidasi server) menambah `streak`. Jawaban **salah** mengembalikan `streak` ke 0 (pemantauan tetap berjalan sampai jendela habis). Blur baru memperpanjang jendela tanpa mengosongkan `streak`.
3. **Eksekusi.** `streak ≥ cheatStreakThreshold` (default **4**, boleh 5) → panggil `disqualify(player, 'BLUR_STREAK')`.
4. Blur di luar status `RUNNING` diabaikan; state di-reset tiap ronde (lihat 7.7).

**Efek `disqualify` (satu transaksi, idempoten):**

1. `RoomPlayer`: `disqualified=true`, `disqualifiedAt`, `disqualifyReason`; simpan `rawScore = totalScore` lalu `totalScore = 0`; tandai semua `Answer` pemain `invalidated=true`.
2. **Papan:** keluarkan dari papan skor live, papan hasil ronde, podium, dan papan akhir; keluarkan dari roda spin. Bila ia sedang menjadi pemilih kategori → auto-pick atau spin ulang.
3. **Layar proyektor:** broadcast `player:disqualified` (lihat bagian 12 untuk tampilan). Event ini **tidak** memuat bukti.
4. **Pemain:** kirim `you:disqualified`, kunci input (server menolak semua `card:answer` berikutnya dengan kode `DISQUALIFIED`), putus soket setelah 5 detik. Pesan netral: *"Kamu didiskualifikasi karena terdeteksi kecurangan. Silakan temui gurumu."*
5. **Blacklist** (jika `autoBlacklist`): buat baris `Blacklist` (aktif), panggil `SimpeteriPort.blacklistStudent` (retry via outbox, tandai `syncedToSimpeteri`).
6. **Bukti** (`Blacklist.evidence`): semua `CheatFlag` pemain pada room (waktu + durasi blur), 8 jawaban terakhir (`cardId`, `correct`, `thinkMs`, `serverTime`), nilai `streak`, parameter aturan saat itu.
7. Kirim `cheat:flag` + notifikasi ke dasbor host; tulis `AuditLog`.

**Penegakan blacklist:**

- Dicek di `room:join` dan `room:pickName`: `Blacklist` lokal aktif **atau** `SimpeteriPort.isBlacklisted` → balas `blacklist:rejected`, jangan kunci nama.
- Berlaku **global** per `studentId`, di semua room/ujian berikutnya, sampai dicabut.
- Di room yang sama, `deviceToken` pemain yang didiskualifikasi dikunci agar tidak bisa memakai nama teman. Pembatasan perangkat **hanya selama room itu**, bukan global (laptop sekolah dipakai bergantian).
- Pencabutan: hanya host/admin lewat `POST /blacklist/:studentId/lift` (wajib `note`), tercatat di `AuditLog` dan disinkronkan ke SIMPETERI.
- **Pemulihan (`reinstate`)**: host dapat membatalkan diskualifikasi di room yang sama bila terbukti salah deteksi (mis. siswa tidak sengaja pindah tab). Skor dipulihkan dari `rawScore`, blacklist dicabut, `player:reinstated` dikirim.

**Laporan SIMPETERI:** pemain terdiskualifikasi dikirim dengan `status: 'DISQUALIFIED'`, `blacklisted: true`, skor 0 di peringkat; data mentah tetap disimpan untuk audit.

> **Risiko salah-deteksi.** Siswa yang kebetulan pindah tab lalu menjawab benar 4 kali (mis. soal mudah) bisa terkena. Mitigasi bawaan: ambang `blurArmWindowSec`, `minBlurMs`, ambang streak yang bisa dinaikkan ke 5, bukti lengkap tersimpan, serta tombol `reinstate` dan `lift` untuk host. Catat di `docs/ASSUMPTIONS.md`.

---

## 12. UI/UX (kelas 6 SD)

**Prinsip:** tombol besar, 1 kalimat instruksi per layar, kontras tinggi, ikon + warna (ramah buta warna), animasi singkat, suara efek ringan (bisa dimatikan).

**Layar pemain**
1. Gabung: input PIN 6 digit (keypad besar).
2. Pilih nama: grid nama kelas, yang terpakai abu-abu.
3. Lobi: "Menunggu guru memulai…", daftar teman online.
4. Spin: roda animasi; hasil ditentukan server (`animSeed` hanya untuk animasi).
5. Pilih kategori (khusus pemilih): 5 kartu kategori, hitung mundur 15 detik.
6. Papan: grid 8×8, timer besar (merah di 15 detik terakhir), skor pribadi, tombol kartu minimal 48 px. Di layar sempit: grid 4 kolom bisa digulir.
7. Hasil ronde: skor ronde, peringkat, 3 kartu paling sering salah + **Trik Singkat** kategori.
8. Skor akhir: podium + peringkat pribadi.

**Kartu:** benar → hijau berkilau + ikon centang + suara; salah → merah retak + ikon silang + getar; kartu terjawab jadi tak bisa ditekan.

**Layar host:** PIN + QR, daftar pemain online (kick), pengaturan, tombol Mulai/Jeda/Lanjut, panel `CheatFlag` real-time (nama, jenis flag, `streak` berjalan, hitung mundur jendela pemantauan), tombol unduh laporan, serta halaman **Daftar Hitam** (alasan, bukti, tanggal, tombol *Cabut Blacklist*, dan *Pulihkan* untuk diskualifikasi di room aktif). Setiap tindakan meminta konfirmasi dan mencatat `AuditLog`.

**Layar Display (proyektor):** PIN besar di lobi, roda spin (berisi sebanyak nama pemain eligible, lihat 7.6), nama kategori, top-5 live, podium. Tidak pernah menampilkan jawaban benar saat ronde berjalan.

**Tampilan diskualifikasi di Display (event `player:disqualified`):**

1. **Banner peringatan** selama 5 detik, es retak merah + suara: `⛔ {NAMA} DIDISKUALIFIKASI — terdeteksi kecurangan`. Isi nama mengikuti `showDisqualifiedOnDisplay`: `NAME` (nama lengkap, default), `INITIALS` (mis. *"B.S."*), atau `COUNT_ONLY` (*"1 pemain didiskualifikasi"*). Tidak menampilkan bukti, durasi blur, atau kata "blacklist".
2. Baris pemain **hilang dengan animasi** dari papan skor live (top-5 dihitung ulang tanpa dia).
3. **Chip tetap** di pojok layar: `Diskualifikasi: n` selama ronde berjalan.
4. Roda spin berikutnya tidak memuat nama itu; hitungan nama pada roda ikut berkurang.
5. Di **layar akhir**, podium dan papan hanya berisi pemain sah; bagian kecil di bawah menampilkan *Daftar Diskualifikasi* (sesuai mode tampilan).
6. Bila host menjalankan `reinstate`, tampilkan banner singkat `✅ {NAMA} dipulihkan` dan masukkan lagi ke papan.

**Layar pemain terdiskualifikasi:** layar penuh dengan pesan netral dan tombol keluar; tidak ada tombol lanjut. Saat mencoba masuk lagi dengan nama yang di-blacklist: *"Akunmu sedang tidak bisa mengikuti permainan. Silakan temui gurumu."*

**Tema visual:** gletser/es biru gelap (mengikuti smartboard), font display tebal, ikon kristal untuk kartu.

---

## 13. Strategi Pengujian

**Unit (`packages/shared`)**
- `pointsForCorrect`: 0 s→1000, 8 s→920, 90 s→100, 200 s→100 (lantai).
- `firstBloodBonus`: rank 1..4.
- `sampleBoard`: 1.000 papan acak per kategori → 64 kartu unik, benar ∈ [26,32], komposisi tier ±5%.
- `seededShuffle`: deterministik untuk seed sama, berbeda untuk pemain berbeda.
- Board Refresh: jumlah benar tetap dalam rentang, kartu terjawab tidak berubah.

**Integrasi (server + socket.io-client)**
- Alur penuh dengan 30 bot: join → pilih nama → mulai → 5 ronde → final → laporan terkirim ke mock.
- Spin tidak pernah memilih pemain yang sudah memilih; pemilih timeout → kategori acak.
- Jawaban ganda pada kartu yang sama ditolak; jawaban setelah `endsAt` ditolak.
- Reconnect: pemain putus lalu `room:join` ulang melanjutkan ronde dengan skor utuh.
- **Test kebocoran**: telusuri semua pesan ke klien, pastikan tidak ada field kunci (lihat bagian 10.2).
- Rate limit dan deteksi `MULTI_DEVICE` bekerja.

**Unit — aturan diskualifikasi (`cheat-rule.ts`, wajib semua lulus)**
- Blur 3 s → 4 benar beruntun (threshold 4) → `disqualify` tepat di jawaban ke-4, bukan sebelumnya.
- Blur 1 s (< `minBlurMs`) → tidak arm, 10 benar beruntun tidak memicu apa pun.
- Blur → 3 benar → 1 salah → 3 benar → **tidak** didiskualifikasi (streak reset).
- Blur → menjawab setelah 100 s (> jendela 90 s) → tidak diskualifikasi; streak 0.
- Threshold 5: jawaban ke-4 aman, ke-5 memicu.
- Blur saat status bukan `RUNNING` (lobi, spin, countdown, hasil, PAUSED) → diabaikan.
- `ANSWER_WHILE_HIDDEN` mengaktifkan pemantauan seperti blur.
- Blur kedua memperpanjang jendela tanpa mereset streak; ronde baru mereset state.

**Integrasi — diskualifikasi & blacklist**
- Bot "curang" (blur lalu 4 jawaban benar cepat) → `player:disqualified` terkirim ke Display, host, dan semua pemain; `you:disqualified` ke bot, soket diputus.
- Setelah DQ: bot ditolak menjawab (`DISQUALIFIED`); hilang dari `scoreboard:live`, `round:end`, `game:end`, podium, dan roda spin; skor di laporan 0 dengan `status: DISQUALIFIED`.
- Roda spin berisi tepat sejumlah pemain eligible; berkurang 1 setelah DQ; spin ulang otomatis bila pemilih terkena DQ.
- Room baru: siswa yang di-blacklist ditolak di `room:join` dan `room:pickName` (`blacklist:rejected`); baris `Blacklist` aktif dan `blacklistStudent` terpanggil (cek outbox bila SIMPETERI mock gagal).
- Device yang sama tidak bisa memilih nama lain di room yang sama setelah DQ.
- `lift` memperbolehkan masuk lagi; `reinstate` memulihkan skor `rawScore`; keduanya tercatat di `AuditLog`.
- Test kebocoran: `player:disqualified` dan semua event ke Display/pemain lain tidak memuat bukti, `streak`, atau `armedUntil`.

**Beban (`tools/bots`)**
- 100 bot, 1 room, 5 ronde, tiap bot menjawab 1–3 kartu/detik. Target: p95 latensi `card:result` < 300 ms, tanpa kesalahan skor (total skor tiap bot = jumlah `Answer.points`).

**Manual**
- Uji coba 1 kelas (~25 siswa) di Wi-Fi sekolah; ukur rata-rata kebenaran (target 50–70%) dan catat soal yang terlalu mudah/sulit.

---

## 14. Rencana Milestone

Setiap milestone punya **Definition of Done (DoD)**; jangan lanjut sebelum semuanya hijau.

### M0 — Fondasi
- Inisialisasi monorepo, TS strict, ESLint/Prettier, Turborepo, Docker Compose (postgres+redis), `CLAUDE.md`.
- **DoD:** `pnpm dev` menjalankan web (3000) dan server (4000); `/health` OK; CI lokal `lint+typecheck+test` hijau.

### M1 — Shared core
- Skema zod (settings, event), seeded RNG, skor, sampler, permutasi, logika refresh.
- **DoD:** seluruh unit test bagian 13 hijau; cakupan paket `shared` ≥ 90%.

### M2 — Bank soal
- Prisma schema + migrasi, `import-bank.ts` dengan render SVG, `QuestionRepository`.
- **DoD:** impor idempoten; 7.500 soal, 15 × 225 benar; sampel SVG tidak mengandung elemen `<text>`.

### M3 — Room & lobi
- Auth host (mock), buat room + PIN + QR, join PIN, pilih nama dari roster mock, kunci 1 nama = 1 perangkat, lobi real-time, kuota, kick.
- Tabel `Blacklist` + pengecekan `isBlacklisted` di `room:join`/`room:pickName` (sudah aktif sejak M3 walau pengisian baru di M7).
- **DoD:** 30 bot bergabung; nama ganda ditolak; kuota ditegakkan; siswa blacklist (di-seed manual) ditolak dengan `blacklist:rejected`.

### M4 — Spin & pemilihan kategori
- Mesin status, spin server-side dengan log `Spin`, penawaran 5 kategori (tidak mengulang), timeout auto-pick, ronde berulang sampai 5.
- Roda spin = jumlah pemain eligible (7.6), event `spin:wheel`, spin ulang otomatis bila pemilih keluar/didiskualifikasi.
- **DoD:** tak ada pemain terpilih dua kali dalam satu siklus; kategori tidak pernah berulang dalam satu game; jumlah segmen roda selalu sama dengan pemain eligible.

### M5 — Ronde & skor
- Bangun papan 64 kartu (26–32 benar), permutasi per pemain, `card:answer`, validasi + skor + First Blood + cooldown, papan skor live, hasil ronde + pembahasan, Board Refresh ronde ganjil.
- **DoD:** test kebocoran lulus; skor bot sama dengan perhitungan referensi; refresh menjaga 26–32 benar.

### M6 — Klien web
- Semua layar bagian 12 (player/host/display), sinkron jam, reconnect, animasi dan suara, mode ringan untuk jaringan lemah.
- Display: banner `player:disqualified`, chip jumlah diskualifikasi, animasi penghapusan dari top-5, daftar diskualifikasi di layar akhir, mode `NAME`/`INITIALS`/`COUNT_ONLY`. Layar pemain terdiskualifikasi dan layar penolakan blacklist.
- Klien mengirim `client:visibility` dari `visibilitychange` + `blur/focus`.
- **DoD:** alur penuh bisa dimainkan manual dengan 1 host + 3 tab pemain + 1 display; menyimulasikan pindah tab + 4 jawaban benar menampilkan banner di Display.

### M7 — Anti-curang & laporan
- `CheatFlag` (blur, too fast, uniform, burst, multi-device), panel host, rate limit, outbox + pengiriman hasil ke `SimpeteriPort`, laporan unduh CSV.
- **Implementasi penuh 11.1 + 7.7:** mesin aturan murni, efek `disqualify` transaksional, blacklist lokal + `SimpeteriPort`, endpoint `disqualify` / `reinstate` / `blacklist` / `lift`, `AuditLog`, halaman Daftar Hitam di host.
- **DoD:** semua unit test aturan (bagian 13) lulus; bot "curang" memicu `player:disqualified` + blacklist; siswa yang sama ditolak di room baru; `lift`/`reinstate` bekerja dengan jejak audit; laporan berisi penguasaan per kategori dan status DISQUALIFIED.

### M8 — Uji beban & rilis
- Uji 100 bot, perbaikan bottleneck, dokumentasi (`API.md`, `EVENTS.md`, `ASSUMPTIONS.md`), skrip deploy (Docker), panduan uji coba kelas.
- **DoD:** target beban tercapai; checklist rilis di bawah selesai.

### Checklist Rilis
- [ ] Tidak ada field kunci di pesan klien (test otomatis lulus)
- [ ] Semua aturan skor lewat `packages/shared`
- [ ] `HttpSimpeteriAdapter` terisi setelah kontrak SIMPETERI dipastikan
- [ ] HTTPS/WSS, CORS terkunci, secret via env
- [ ] Backup DB harian; log tanpa data pribadi berlebih
- [ ] Uji coba satu kelas nyata dan kalibrasi tingkat kesulitan
- [ ] Aturan diskualifikasi 11.1 lulus semua tes; ambang tidak menghasilkan salah-deteksi pada uji coba kelas (cek `CheatFlag` hasil uji)
- [ ] Prosedur guru untuk `reinstate` dan `lift` blacklist sudah dijelaskan di panduan

---

## 15. Asumsi yang Perlu Dikonfirmasi (catat di `docs/ASSUMPTIONS.md`)

1. **"Board ganjil ganti lagi"** diwujudkan sebagai Board Refresh di tengah ronde pada ronde 1, 3, 5. Bila maksud sebenarnya berbeda, ubah hanya `RefreshService` dan flag `boardRefreshOddRounds`.
2. Waktu berpikir dihitung dari **jeda sejak aksi benar terakhir** (atau awal ronde), bukan dari awal ronde.
3. Satu perangkat per siswa; bila siswa berbagi laptop, aturan `MULTI_DEVICE` perlu dilonggarkan.
4. Stack dan kontrak API SIMPETERI belum diketahui; sementara dipakai mock.
5. Ke-15 kategori v2 (satuan 7/3/9, ganjil, genap, kelipatan 3/4/5/6/7/9, kuadrat, prima, sisa 5 bersisa 2, hasil antara 100–200) menggantikan kategori modular versi 1. Trik tiap kategori ada di `kategori[].trik`; ganti lewat generator bila perlu.
6. Tantangan terhadap AI/kalkulator **tidak** dicapai lewat soal di luar kurikulum, melainkan lewat waktu singkat, papan 64 kartu, urutan acak per pemain, dan Board Refresh.

---

## 16. Prompt Awal yang Disarankan untuk Claude Code

```text
Baca GLACIA_BLUEPRINT.md sampai selesai. Kerjakan M0 dan M1 saja.
Ikuti Bagian 0 (aturan kerja) dan Bagian 11 (keamanan, termasuk 11.1 diskualifikasi + blacklist).
Setelah selesai: jalankan lint, typecheck, test, lalu ringkas hasil dan
tunggu instruksi untuk M2.
```

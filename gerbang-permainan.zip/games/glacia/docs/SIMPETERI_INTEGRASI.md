# Integrasi GLACIA dengan SIMPETERI (Multi Permainan / Clash of Git)

Kontrak ini mengikuti pola yang sudah dipakai CLAIM 80 di `simpeteri13-main` (`src/lib/game-host.ts`, `src/lib/multi-permainan.ts`). SIMPETERI **bukan** server REST bagi game: ia membuka konsol guru game, menyerahkan daftar siswa lewat `postMessage`, lalu menarik hasilnya. Karena itu GLACIA punya mode `SIMPETERI_MODE=multi`, bukan klien HTTP.

## Alur

```
SIMPETERI /multi-permainan (sesi + kelas dipilih)
  1. window.open(about:blank) lalu  jendela.location = {alamat GLACIA}/host
  2. GLACIA (tab baru) → opener : { type: "glacia:host-ready" }
  3. SIMPETERI → GLACIA          : { type: "glacia:roster", kelas, roster:[{id,name,absen}], pin, kembali, multiSesi }
                                   (origin SIMPETERI diperiksa di kedua arah; PIN tidak pernah masuk URL)
  4. GLACIA masuk dengan PIN, guru mengatur ronde, ruangan dibuat dengan roster itu (id = siswa.id)
  5. Permainan selesai → tombol "Kembali ke SIMPETERI dan impor hasil" →
        {kembali}&selesai=1&gameSesi={id ruangan}
  6. SIMPETERI: GET {alamat}/api/sessions/{gameSesi}/summary.json   (header x-host-token: {PIN})
        → bacaRingkasan("glacia", json, roster) → skor masuk Hall of Fame
```

## Sisi GLACIA (sudah ada)

| Hal | Perilaku |
|---|---|
| Mode | `SIMPETERI_MODE=multi`, `HOST_PIN` (4–32 karakter tanpa spasi), `ALLOWED_ORIGINS=https://asal-simpeteri`. Tanpa SIMPETERI: `SIMPETERI_MODE=mandiri` (bawaan), guru menempel nama siswa sendiri |
| Masuk | `POST /api/auth/host {token: PIN}` → JWT. Dibatasi 20 percobaan/menit/IP |
| Roster | `POST /api/rooms` wajib memuat `roster:[{id,name,absen?}]` (1–100, id unik). Tanpa roster: `ROSTER_REQUIRED` |
| Pesan | hanya dari `window.opener` dan origin yang ada di `ALLOWED_ORIGINS`. `kembali` hanya dipakai bila satu origin dengan pengirim |
| Hasil | `GET /api/sessions/:id/summary.json` + header `x-host-token`. `404` sesi tak ada, `401` PIN salah atau kosong, `403` belum selesai, `429` terlalu banyak percobaan. CORS membolehkan header `x-host-token` untuk asal yang diizinkan |
| Isi | hanya siswa yang **ikut** (SIMPETERI memberi skor ke setiap baris yang diimpor). Siswa terdiskualifikasi ikut dengan `points: 0` dan `status: "DISQUALIFIED"` |
| Daftar hitam | tetap lokal di GLACIA (`data/runtime/state.json`), kunci `siswa.id`. SIMPETERI tidak punya endpoint untuk itu |

### Bentuk `summary.json` (versi 2)

```json
{
  "game": "glacia", "version": 2, "sessionId": "6f0c…", "classId": "6A", "playedAt": "2026-11-05T05:00:00.000Z", "rounds": 5,
  "students": [{
    "studentId": "<siswa.id>", "name": "Aisyah Putri", "rank": 1,
    "points": 38120, "score": 38120,
    "attempts": 84, "correct": 71, "wrong": 13, "accuracy": 0.845, "avgThinkMs": 5200,
    "profile": { "Memiliki satuan 7": 92, "Kelipatan 4": 61, "Bilangan prima": null },
    "status": "OK", "blacklisted": false,
    "perCategory": [{ "categoryId": 1, "category": "Memiliki satuan 7", "attempted": 12, "correct": 11, "wrong": 1 }]
  }]
}
```

`profile` = indeks ketepatan 0–100 per nama kategori (`null` bila percobaan < 3). `points` sama dengan `score`; `points` adalah nama yang dibaca importer SIMPETERI.

## Sisi SIMPETERI (sudah ditambahkan)

Sudah ada di `simpeteri13-main` (`KATALOG_GAME`, `game-host.ts`, `bacaRingkasanGlacia`, `ukuranProfil`), dan kode GLACIA sendiri kini berada di `games/glacia` (skrip `gl:*`). Daftar di bawah menjelaskan isinya, dan tes kontrak `src/test/games-satu-folder.test.ts` menjalankan `buildReport` asli GLACIA terhadapnya:

1. `KATALOG_GAME` (`src/lib/multi-permainan.ts`): `{ key: "glacia", label: "GLACIA", ringkas: "Rebutan 64 kartu per kotak, 5 kotak (320 angka); hasil dapat diimpor beserta profil ketepatan per kategori", otomatis: true }`, juga `SUMBER_IMPOR`, `SumberSkor`, dan dispatcher `bacaRingkasan`.
2. `src/lib/game-host.ts`: `KunciGame` dan `GAME_DI_FOLDER` memuat `"glacia"`; `bangunPesan`, `serahkanKeGame`, `bacaAlamatGame`, `simpanAlamatGame` memakai `READY_MESSAGE = "glacia:host-ready"` dan pesan `type: "glacia:roster"` (bentuk sama dengan `pesanRoster` CLAIM 80, maksimum 100 siswa).
3. Pembaca ringkasan, disarankan persis seperti ini:

```ts
export function bacaRingkasanGlacia(raw: unknown, roster: readonly { id: string; nama: string }[]): { skor: SkorGame[]; tidakCocok: string[] } {
  const siswa = (raw as { students?: unknown } | null)?.students;
  if (!Array.isArray(siswa)) throw new Error("Ringkasan GLACIA tidak sah");
  const byId = new Map(roster.map((r) => [r.id, r]));
  const skor: SkorGame[] = [];
  const tidakCocok: string[] = [];
  for (const s of siswa as Record<string, unknown>[]) {
    const id = typeof s.studentId === "string" ? s.studentId : "";
    const cocok = byId.get(id);
    if (!cocok) { tidakCocok.push(typeof s.name === "string" ? s.name : id || "(tanpa nama)"); continue; }
    const kategori: Record<string, number | null> = {};
    if (s.profile && typeof s.profile === "object" && !Array.isArray(s.profile))
      for (const [k, v] of Object.entries(s.profile)) kategori[k] = angka(v);
    skor.push({
      siswaId: cocok.id, nama: cocok.nama, skor: angka(s.points) ?? 0, waktuMs: null,
      profil: { kategori, akurasi: angka(s.accuracy), benar: angka(s.correct) ?? 0, percobaan: angka(s.attempts) ?? 0 },
    });
  }
  return { skor, tidakCocok };
}
```

4. `ukuranProfil("glacia", …)`: seperti cabang `claim80`, tetapi label kategori diambil langsung dari kuncinya (nama kategori sudah terbaca manusia).
5. (Opsional) halaman `/glacia` seperti `/claim-80` yang memilih kelas lalu membuka `{alamat}/host`.
6. Tes: `npm run gl:test` (di akar SIMPETERI) menjalankan tes GLACIA sendiri, termasuk `apps/server/test/simpeteri.test.ts`; `npx vitest run src/test/games-satu-folder.test.ts` menguji kontraknya dari sisi SIMPETERI.

## Keamanan dan batas

- Satu `HOST_PIN` per server game (seperti CLAIM 80): siapa pun yang tahu PIN adalah guru. Pakai PIN panjang dan HTTPS.
- `/api/sessions/:id/summary.json` memuat nama siswa. Id ruangan berupa UUID acak dan PIN guru tetap diperlukan.
- Daftar siswa diteruskan ke server GLACIA lewat browser guru, tidak lewat jaringan server ke server.
- Mode `multi` memperlakukan semua yang memegang PIN sebagai satu guru (`hostId: "guru"`): ruangan dan hasil terlihat oleh sesama pemegang PIN.

## Satu pintu: di bawah /games/glacia (BASE_PATH)

Gerbang SIMPETERI meneruskan `/games/glacia/**` tanpa memotong awalan ke server GLACIA. Jalankan dengan `BASE_PATH=/games/glacia` (build web dan server), `TRUST_PROXY=1`, dan `HOST_PIN`; alamat GLACIA di SIMPETERI menjadi `https://<host>/games/glacia`, dan `{alamat}/host` (jalur biasa, bukan hash) langsung membuka konsol guru. Klien, `/api/**`, dan socket.io (`/games/glacia/socket.io`) semuanya di bawah awalan itu, jadi tidak perlu port atau alamat terpisah. Perintah dan variabel lengkap: `docs/DEPLOY.md`, bagian "Satu pintu lewat SIMPETERI".
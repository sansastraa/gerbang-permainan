# EVENTS — Socket.IO namespace `/game`

Semua payload klien→server divalidasi zod (`packages/shared/src/events.ts`). Server tidak memercayai waktu dari klien: semua perhitungan memakai jam server, dan `endsAt`/`startsAt` bersifat absolut (klien menghitung selisih jam dari `serverNow`).

Setiap event klien→server memakai *acknowledgement*: `{ ok: true, ... }` atau `{ ok: false, code }`.

## Klien → server

| Event | Dari | Payload | Ack / catatan |
|---|---|---|---|
| `room:join` | siswa | `{ pin, deviceToken }` | `{ ok, resumed, roster[], playerId? , snapshot? }`. Perangkat yang sudah punya nama langsung dilanjutkan (`resumed: true`). Maks 10/menit per IP (`JOIN_LIMIT_PER_MIN`). |
| `room:pickName` | siswa | `{ studentId }` | `{ ok, playerId, snapshot }` atau `NAME_TAKEN`, `DEVICE_HAS_NAME`, `UNKNOWN_STUDENT`, `ROOM_FULL`, `REGISTRATION_CLOSED`, `BLACKLISTED` |
| `display:join` | proyektor | `{ pin }` | `{ ok, state }` |
| `host:auth` | guru | `{ token (JWT), roomId }` | `{ ok, state, exportKey, flags[] }` |
| `game:start` | guru | `{}` | `NOT_ENOUGH_PLAYERS` bila online < 2 |
| `host:pause` / `host:resume` | guru | `{}` | jam ronde dibekukan, `endsAt` digeser saat lanjut |
| `round:next` | guru | `{}` | hanya di `ROUND_RESULT` (kalau tidak ditekan, otomatis 20 detik) |
| `round:end-now` | guru | `{}` | **Akhiri ronde** sekarang (juga saat dijeda); skor ronde langsung dihitung |
| `game:end-now` | guru | `{}` | **Akhiri permainan**: ronde yang berjalan dihitung, lalu papan juara + laporan. Tidak bisa dari lobi |
| `host:kick` | guru | `{ playerId }` | |
| `category:pick` | pemilih | `{ categoryId }` | `NOT_PICKER`, `BAD_CATEGORY`, `BAD_STATE` |
| `card:answer` | siswa | `{ cardId, hidden? }` | `{ ok }`. `ok:false` bila kalah balapan klaim, kena cooldown, dsb. Alasannya dikirim lewat `card:rejected` |
| `client:visibility` | siswa | `{ hidden }` | dikirim tiap `visibilitychange` dan `blur/focus`; tanpa ack |

## Server → klien

| Event | Ke | Isi |
|---|---|---|
| `room:state` | semua (versi berbeda per peran) | `{ status, players[], settings, roundNo, rounds, pickerId, pickExpiresAt, startsAt, endsAt, category, pausedAt, you, serverNow }`. Host juga menerima `score`, `disqualified`, `blacklisted` per pemain |
| `spin:wheel` | semua | `{ segments[{playerId,name}], count }` — jumlah segmen = pemain *eligible* (online, belum memilih, tidak didiskualifikasi) |
| `spin:result` | semua | `{ eligible[], pickedPlayerId, pickedName, animSeed, animMs, roundNo }` (pemenang ditentukan server; klien hanya menganimasikan) |
| `category:options` | pemilih saja | `{ categories[≤5], expiresAt }. Bila guru hanya mengizinkan 1 kategori event ini tidak dikirim dan ronde langsung masuk hitung mundur.` |
| `round:countdown` | semua | `{ startsAt, roundNo, category, serverNow }` |
| `round:start` | pemain **dan proyektor**: 64 kartu, urutan sama untuk semua (proyektor yang masuk di tengah ronde menerimanya lagi beserta klaim yang sudah ada). Host: tanpa kartu | `{ roundNo, rounds, category, startedAt, endsAt, refreshAt?, wrongCooldownMs, cardCount, cards[{cardId, svg}] }` |
| `card:result` | pemain yang menjawab | `{ cardId, correct, points, bonus, score, cooldownUntil? }` |
| `card:rejected` | pemain yang menjawab | `{ cardId, code, cooldownUntil? }` — `CARD_CLAIMED` (keduluan), `COOLDOWN`, `ALREADY_ANSWERED`, `RATE_LIMITED`, `ROUND_OVER`, `PAUSED`, `DISQUALIFIED`, `CARD_GONE`, `BAD_STATE` |
| `card:claimed` | semua | `{ cardId, playerId, name }` — kartu diklaim jawaban benar pertama dan terkunci untuk yang lain |
| `card:released` | semua | `{ cardId }` — klaim dibatalkan karena pengklaim didiskualifikasi |
| `board:refresh` | semua | `{ replaced[{oldCardId, cardId, svg}] }` (pertengahan ronde 1, 3, 5; kartu yang sudah dijawab tidak diganti) |
| `scoreboard:live` | semua | `{ top5[{playerId,name,score}], claimed?, remaining? }` (maks 1×/detik). `remaining` = jumlah kartu benar yang belum diklaim, tanpa menyebut kartu mana |
| `round:end` | semua | `{ roundNo, rounds, category, trick, roundScores[], keyReveal[], explanations[≤3], nextAt, lastRound }` — di sini kunci jawaban baru dibuka |
| `game:end` | semua | `{ finalBoard[], podium[≤3], disqualified{count, mode, names[]} }` |
| `cheat:flag` | **host saja** | `{ playerId, name, type, detail, at, streak?, armedUntil? }` |
| `player:disqualified` | semua | `{ playerId? (hanya mode NAME), displayName, mode, reason, at, totalDisqualified }` — **tanpa bukti** |
| `you:disqualified` | pemain itu | `{ message, blacklisted }`; soket diputus 5 detik kemudian |
| `player:reinstated` / `you:reinstated` | semua / pemain itu | pemulihan oleh guru |
| `you:kicked` | pemain itu | |
| `blacklist:rejected` | pemain itu | `{ message }` — pesan netral: *"Akunmu sedang tidak bisa mengikuti permainan. Silakan temui gurumu."* |

## Larangan payload (diuji otomatis)

Selama ronde berjalan, tidak ada pesan ke klien yang memuat `isCorrect`, `questionId`, `unitDigit`, `parity`, `result`, atau `explanation` (`FORBIDDEN_KEYS`). Pesan ke selain host juga tidak memuat `streak`, `armedUntil`, `evidence`, `hiddenMs` (`EVIDENCE_KEYS`). Tes: `apps/server/test/game.test.ts`, `claim.test.ts`, `cheat.test.ts`, `wire.test.ts`.

> `card:claimed` menunjukkan bahwa kartu itu benar, tetapi hanya untuk kartu yang sudah tidak bisa diambil siapa pun. Kartu yang masih bebas tidak pernah ditandai.

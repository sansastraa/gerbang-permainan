## Bank_Soal_GLACIA_15x500.xlsx
- Jumlah soal terbaca: 7500
- Pemeriksaan materi SD v2: GAGAL (7015 kesalahan)
- Pola di luar materi SD: {"total":7500,"sigma":296,"faktorial":500,"deret_titik":243,"hasil_digit":1570,"hasil_gt_1500":2727,"sisa_bagi_9":0}
  - K01-001: karakter di luar materi SD: 12⁴ + 11
  - K01-002: hasil 1543747 di luar 0..1500
  - K01-003: karakter di luar materi SD: 248 − 247 + 246 − 245 + ⋯ + 2 − 1 − 28
  - K01-004: karakter di luar materi SD: 12¹²⁵ ÷ 12¹²³ + 33
  - K01-007: karakter di luar materi SD: 14⁴ − 49
  - K01-008: karakter di luar materi SD: |40 − 5³| × 6 + 47
  - K01-010: karakter di luar materi SD: (10¹² − 1) ÷ 9 + 16
  - K01-012: hasil 83739 di luar 0..1500
  - … dan 7007 kesalahan lain
  - peringatan: K01-002: tanpa pembahasan
  - peringatan: K01-005: tanpa pembahasan
  - peringatan: K01-006: tanpa pembahasan
  - peringatan: K01-009: tanpa pembahasan
  - peringatan: K01-011: tanpa pembahasan

## Bank_Soal_GLACIA_15x500 (1).xlsx
- Jumlah soal terbaca: 7500
- Pemeriksaan materi SD v2: LULUS
- Statistik: {"perCat":{"1":{"total":500,"benar":225,"pengecoh":275,"Mudah":156,"Sedang":249,"Menantang":95},"2":{"total":500,"benar":225,"pengecoh":275,"Mudah":171,"Sedang":231,"Menantang":98},"3":{"total":500,"benar":225,"pengecoh":275,"Mudah":159,"Sedang":250,"Menantang":91},"4":{"total":500,"benar":225,"pengecoh":275,"Mudah":163,"Sedang":239,"Menantang":98},"5":{"total":500,"benar":225,"pengecoh":275,"Mudah":158,"Sedang":251,"Menantang":91},"6":{"total":500,"benar":225,"pengecoh":275,"Mudah":166,"Sedang":222,"Menantang":112},"7":{"total":500,"benar":225,"pengecoh":275,"Mudah":149,"Sedang":229,"Menantang":122},"8":{"total":500,"benar":225,"pengecoh":275,"Mudah":167,"Sedang":230,"Menantang":103},"9":{"total":500,"benar":225,"pengecoh":275,"Mudah":151,"Sedang":255,"Menantang":94},"10":{"total":500,"benar":225,"pengecoh":275,"Mudah":155,"Sedang":230,"Menantang":115},"11":{"total":500,"benar":225,"pengecoh":275,"Mudah":156,"Sedang":236,"Menantang":108},"12":{"total":500,"benar":225,"pengecoh":275,"Mudah":158,"Sedang":214,"Menantang":128},"13":{"total":500,"benar":225,"pengecoh":275,"Mudah":146,"Sedang":229,"Menantang":125},"14":{"total":500,"benar":225,"pengecoh":275,"Mudah":178,"Sedang":216,"Menantang":106},"15":{"total":500,"benar":225,"pengecoh":275,"Mudah":136,"Sedang":235,"Menantang":129}},"jenis":{"Akar dan kali":23,"Akar kuadrat":74,"Akar pangkat tiga":50,"Bagi lalu tambah":178,"Dua perkalian dijumlah":460,"Hitung campuran":420,"Jumlah dikuadratkan":648,"Jumlah dua kuadrat":124,"Kali lalu bagi":282,"Kali lalu kurang":430,"Kali lalu tambah":418,"Kuadrat dan kali":271,"Kuadrat dikurangi":435,"Kuadrat ditambah":767,"Kuadrat":22,"Kurung dikali":331,"Kurung, kali, lalu tambah/kurang":120,"Pangkat tiga":428,"Pembagian":438,"Pengurangan":438,"Penjumlahan":442,"Perkalian":272,"Selisih kuadrat":429}}

## Perbandingan kedua berkas
- ID yang sama: 7500; ekspresi identik: 0; hasil identik: 6; kunci "memenuhi" identik: 3752
- Hanya di berkas 1: 0; hanya di berkas 2: 0

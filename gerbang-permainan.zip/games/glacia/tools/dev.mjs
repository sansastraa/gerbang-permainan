// `npm run dev`: starts the server (4000) and the web client (3000) together with prefixed logs.
import { spawn } from 'node:child_process';
import { existsSync } from 'node:fs';

if (!existsSync('data/questions.json')) {
  console.log('[dev] data/questions.json belum ada, mengimpor bank soal dulu (sekali saja, ±1 menit)…');
  await new Promise((resolve, reject) => {
    const p = spawn('npm', ['run', 'import-bank'], { stdio: 'inherit', shell: true });
    p.on('exit', (c) => (c === 0 ? resolve() : reject(new Error(`import-bank exit ${c}`))));
  });
}

const procs = [
  ['server', 'npm', ['run', 'dev', '-w', '@glacia/server'], '\x1b[36m'],
  ['web   ', 'npm', ['run', 'dev', '-w', '@glacia/web'], '\x1b[35m'],
].map(([name, cmd, args, color]) => {
  const p = spawn(cmd, args, { shell: true, env: { ...process.env, DATA_DIR: process.env.DATA_DIR ?? 'data' } });
  const pipe = (stream) => stream.on('data', (d) => String(d).split(/\r?\n/).filter(Boolean).forEach((l) => console.log(`${color}[${name}]\x1b[0m ${l}`)));
  pipe(p.stdout);
  pipe(p.stderr);
  p.on('exit', (code) => {
    console.log(`[${name}] keluar (${code})`);
    procs.forEach((x) => x.kill());
    process.exit(code ?? 0);
  });
  return p;
});

const stop = () => procs.forEach((p) => p.kill());
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

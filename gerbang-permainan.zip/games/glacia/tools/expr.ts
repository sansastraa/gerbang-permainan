/**
 * Independent evaluator for the display expressions used in the bank (+ − × ÷, parentheses, ², ³, √n, ∛n).
 * Written separately from the Python generator so it can cross-check the "hasil" column.
 */
type Tok = { t: 'num'; v: number } | { t: 'op'; v: string };

const SUP: Record<string, string> = { '²': '2', '³': '3' };

function tokenize(src: string): Tok[] {
  const out: Tok[] = [];
  let i = 0;
  while (i < src.length) {
    const c = src[i]!;
    if (c === ' ') {
      i++;
    } else if (/[0-9]/.test(c)) {
      let j = i;
      while (j < src.length && /[0-9]/.test(src[j]!)) j++;
      out.push({ t: 'num', v: Number(src.slice(i, j)) });
      i = j;
    } else if ('+−-×÷()√∛'.includes(c) || SUP[c]) {
      out.push({ t: 'op', v: c });
      i++;
    } else {
      throw new Error(`unexpected character "${c}" in "${src}"`);
    }
  }
  return out;
}

export const ALLOWED_CHARS = /^[0-9 +−×÷()²³√∛]+$/;

export function evalExpr(src: string): number {
  const toks = tokenize(src);
  let p = 0;
  const peek = () => toks[p];
  const isOp = (v: string) => {
    const t = peek();
    return t?.t === 'op' && t.v === v;
  };

  function primary(): number {
    const t = peek();
    if (!t) throw new Error('unexpected end');
    if (t.t === 'num') {
      p++;
      return postfix(t.v);
    }
    if (t.v === '(') {
      p++;
      const v = additive();
      if (!isOp(')')) throw new Error('missing )');
      p++;
      return postfix(v);
    }
    if (t.v === '√' || t.v === '∛') {
      p++;
      const n = peek();
      if (n?.t !== 'num') throw new Error('root needs a number');
      p++;
      const r = t.v === '√' ? Math.round(Math.sqrt(n.v)) : Math.round(Math.cbrt(n.v));
      const exact = t.v === '√' ? r * r === n.v : r * r * r === n.v;
      if (!exact) throw new Error(`root of ${n.v} is not exact`);
      return r;
    }
    throw new Error(`unexpected token ${t.v}`);
  }
  function postfix(v: number): number {
    const t = peek();
    if (t?.t === 'op' && SUP[t.v]) {
      p++;
      return v ** Number(SUP[t.v]);
    }
    return v;
  }
  function multiplicative(): number {
    let v = primary();
    for (;;) {
      if (isOp('×')) {
        p++;
        v *= primary();
      } else if (isOp('÷')) {
        p++;
        const d = primary();
        if (v % d !== 0) throw new Error('inexact division');
        v /= d;
      } else return v;
    }
  }
  function additive(): number {
    let v = multiplicative();
    for (;;) {
      if (isOp('+')) {
        p++;
        v += multiplicative();
      } else if (isOp('−') || isOp('-')) {
        p++;
        v -= multiplicative();
      } else return v;
    }
  }
  const v = additive();
  if (p !== toks.length) throw new Error('trailing tokens');
  return v;
}

export const isPrime = (n: number) => {
  if (n < 2) return false;
  for (let i = 2; i * i <= n; i++) if (n % i === 0) return false;
  return true;
};
const isSquare = (n: number) => n >= 0 && Math.round(Math.sqrt(n)) ** 2 === n;

/** Category predicates (blueprint 6.1). */
export const CATEGORY_PROPS: Record<number, (n: number) => boolean> = {
  1: (n) => n % 10 === 7,
  2: (n) => n % 10 === 3,
  3: (n) => n % 10 === 9,
  4: (n) => n % 2 === 1,
  5: (n) => n % 2 === 0,
  6: (n) => n % 3 === 0,
  7: (n) => n % 4 === 0,
  8: (n) => n % 5 === 0,
  9: (n) => n % 6 === 0,
  10: (n) => n % 9 === 0,
  11: (n) => n % 7 === 0,
  12: isSquare,
  13: isPrime,
  14: (n) => n % 5 === 2,
  15: (n) => n > 100 && n < 200,
};

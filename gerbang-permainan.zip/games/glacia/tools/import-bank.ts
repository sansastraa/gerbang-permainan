/**
 * Imports data/bank_soal_glacia.json → data/questions.json (the server's question store), rendering each LaTeX
 * expression to an SVG made of <path> glyphs (no <text>, so nothing can be selected/copied as text).
 * Idempotent: output is a pure function of the input. Usage: tsx import-bank.ts [in.json] [out.json]
 */
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { mathjax } from 'mathjax-full/js/mathjax.js';
import { TeX } from 'mathjax-full/js/input/tex.js';
import { SVG } from 'mathjax-full/js/output/svg.js';
import { liteAdaptor } from 'mathjax-full/js/adaptors/liteAdaptor.js';
import { RegisterHTMLHandler } from 'mathjax-full/js/handlers/html.js';
import { AllPackages } from 'mathjax-full/js/input/tex/AllPackages.js';
import type { Bank } from './verify-bank';

const here = path.dirname(fileURLToPath(import.meta.url));
const inFile = process.argv[2] ?? path.join(here, '..', 'data', 'bank_soal_glacia.json');
const outFile = process.argv[3] ?? path.join(here, '..', 'data', 'questions.json');

const adaptor = liteAdaptor();
RegisterHTMLHandler(adaptor);
const doc = mathjax.document('', { InputJax: new TeX({ packages: AllPackages.filter((p) => p !== 'bussproofs') }), OutputJax: new SVG({ fontCache: 'none' }) });

export function renderSvg(latex: string): string {
  const node = doc.convert(latex, { display: false });
  let svg = adaptor.innerHTML(node);
  if (svg.includes('merror') || svg.includes('<text')) throw new Error(`render failed for ${latex}`);
  svg = svg
    .replace(/ data-mml-node="[^"]*"/g, '')
    .replace(/ data-c="[^"]*"/g, '')
    .replace(/ role="img"| focusable="false"/g, '')
    .replace(/<svg /, '<svg class="gq" fill="currentColor" stroke="currentColor" ');
  return svg;
}

const TIER: Record<string, 'EASY' | 'MEDIUM' | 'HARD'> = { Mudah: 'EASY', Sedang: 'MEDIUM', Menantang: 'HARD' };

const bank = JSON.parse(fs.readFileSync(inFile, 'utf8')) as Bank;
const questions = bank.soal.map((s) => {
  const tier = TIER[s.tingkat];
  if (!tier) throw new Error(`unknown tier ${s.tingkat} (${s.id})`);
  const result = Number(s.hasil);
  if (!Number.isInteger(result)) throw new Error(`non-integer result for ${s.id}`);
  return {
    id: s.id,
    categoryId: s.kategori_id,
    exprText: s.ekspresi,
    latex: s.latex,
    svg: renderSvg(s.latex),
    tier,
    kind: s.jenis,
    result,
    unitDigit: s.satuan,
    parity: s.paritas,
    explanation: s.pembahasan,
    isCorrect: s.memenuhi,
  };
});

fs.mkdirSync(path.dirname(outFile), { recursive: true });
fs.writeFileSync(outFile, JSON.stringify({ versi: bank.versi, categories: bank.kategori.map((k) => ({ id: k.id, name: k.nama, trick: k.trik })), questions }));

let ok = true;
console.log('Kategori | benar | pengecoh');
for (let c = 1; c <= 15; c++) {
  const list = questions.filter((q) => q.categoryId === c);
  const pos = list.filter((q) => q.isCorrect).length;
  if (pos !== 225 || list.length !== 500) ok = false;
  console.log(`${String(c).padStart(2)} | ${pos} | ${list.length - pos}`);
}
const bytes = questions.reduce((a, q) => a + q.svg.length, 0);
console.log(`Total ${questions.length} soal, SVG rata-rata ${Math.round(bytes / questions.length)} byte, tanpa <text>: ${questions.every((q) => !q.svg.includes('<text'))}`);
if (questions.length !== 7500 || !ok) {
  console.error('GAGAL: harus 7.500 soal, 15 × 225 benar');
  process.exit(1);
}
console.log(`Ditulis ${outFile}`);

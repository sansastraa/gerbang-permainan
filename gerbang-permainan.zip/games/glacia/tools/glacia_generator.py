#!/usr/bin/env python3
"""
GLACIA - Generator & Verifier Bank Soal v2 (RAMAH SD KELAS 6)
--------------------------------------------------------------
Perubahan dari v1: TIDAK ada sigma, faktorial, pangkat besar, nilai mutlak, sisa bagi 9, modular.
Hanya materi SD: + - x : , hitung campuran + kurung, kuadrat (a^2), pangkat tiga (a^3),
akar kuadrat dan akar pangkat tiga dari bilangan "cantik".
Hasil akhir selalu bilangan bulat <= 1.500 (kecuali kategori kuadrat: <= 900).

Cara kerja (berbasis TARGET): pilih nilai hasil T yang memenuhi / tidak memenuhi kategori,
lalu susun ekspresi yang hasilnya tepat T. Setiap ekspresi diverifikasi ulang.

Pakai:
    python glacia_generator.py            # buat bank_soal_glacia.json
    from glacia_generator import sample_board
"""
import json, math, random
from math import isqrt

SEED = 20261105
SUP = str.maketrans("0123456789", "\u2070\u00b9\u00b2\u00b3\u2074\u2075\u2076\u2077\u2078\u2079")
POS_PER_CAT, NEG_PER_CAT = 225, 275
TIER_W = [("Mudah", 0.30), ("Sedang", 0.45), ("Menantang", 0.25)]


def is_prime(n):
    if n < 2:
        return False
    if n % 2 == 0:
        return n == 2
    i = 3
    while i * i <= n:
        if n % i == 0:
            return False
        i += 2
    return True


def is_square(n):
    return n >= 0 and isqrt(n) ** 2 == n


def digsum(n):
    return sum(int(c) for c in str(n))


def near_square(n):
    r = isqrt(n)
    return not is_square(n) and min(n - r * r, (r + 1) ** 2 - n) <= 5


# --------------------------------------------------------------- kategori
# (id, nama, properti, near-miss, trik, rentang_khusus)
def unit(k):
    return (lambda n: n % 10 == k, lambda n: ((n % 10) - k) % 10 in (1, 2, 8, 9))


def mult(m):
    return (lambda n: n % m == 0, lambda n: n % m in (1, m - 1))


CATS = [
    (1, "Memiliki satuan 7", *unit(7), "Hitung dulu hasilnya, lalu lihat angka paling kanan (satuan)."),
    (2, "Memiliki satuan 3", *unit(3), "Hitung dulu hasilnya, lalu lihat angka paling kanan (satuan)."),
    (3, "Memiliki satuan 9", *unit(9), "Hitung dulu hasilnya, lalu lihat angka paling kanan (satuan)."),
    (4, "Bilangan ganjil", lambda n: n % 2 == 1, None,
     "Lihat satuan hasilnya: 1, 3, 5, 7, 9 berarti ganjil."),
    (5, "Bilangan genap", lambda n: n % 2 == 0, None,
     "Lihat satuan hasilnya: 0, 2, 4, 6, 8 berarti genap."),
    (6, "Kelipatan 3", *mult(3), "Jumlahkan semua angkanya. Kalau jumlahnya habis dibagi 3, hasilnya kelipatan 3."),
    (7, "Kelipatan 4", *mult(4), "Lihat dua angka terakhir. Kalau habis dibagi 4, hasilnya kelipatan 4."),
    (8, "Kelipatan 5", *mult(5), "Satuannya harus 0 atau 5."),
    (9, "Kelipatan 6", *mult(6), "Harus genap DAN jumlah angkanya habis dibagi 3."),
    (10, "Kelipatan 9", *mult(9), "Jumlahkan semua angkanya. Kalau habis dibagi 9, hasilnya kelipatan 9."),
    (11, "Kelipatan 7", *mult(7), "Bagi hasilnya dengan 7. Kalau tidak bersisa, hasilnya kelipatan 7."),
    (12, "Bilangan kuadrat", is_square, near_square,
     "Bilangan kuadrat adalah hasil kali bilangan dengan dirinya sendiri, misalnya 49 = 7 \u00d7 7."),
    (13, "Bilangan prima", is_prime,
     lambda n: n >= 25 and n % 2 == 1 and n % 3 != 0 and n % 5 != 0 and not is_prime(n),
     "Bilangan prima hanya punya dua faktor: 1 dan dirinya sendiri. Coba bagi dengan 2, 3, 5, 7."),
    (14, "Jika dibagi 5 bersisa 2", lambda n: n % 5 == 2, lambda n: n % 5 in (1, 3),
     "Bagi hasilnya dengan 5. Satuan 2 atau 7 berarti sisanya 2."),
    (15, "Hasilnya antara 100 dan 200", lambda n: 100 < n < 200,
     lambda n: 85 <= n <= 95 or 205 <= n <= 215,
     "Hitung hasilnya, lalu bandingkan: lebih dari 100 dan kurang dari 200."),
]

DEFAULT_RANGE = {"Mudah": (12, 120), "Sedang": (40, 600), "Menantang": (100, 1500)}
RANGES = {
    12: {"Mudah": (16, 144), "Sedang": (100, 400), "Menantang": (225, 900)},
    13: {"Mudah": (13, 97), "Sedang": (50, 150), "Menantang": (100, 199)},
}


def explain(cid, n, ok):
    d = digsum(n)
    ds = " + ".join(str(n))
    yes = "Memenuhi." if ok else "Tidak memenuhi."
    if cid in (1, 2, 3):
        return f"Hasil = {n}. Satuannya {n % 10}. {yes}"
    if cid in (4, 5):
        return f"Hasil = {n}. Satuannya {n % 10}, jadi {'ganjil' if n % 2 else 'genap'}. {yes}"
    if cid in (6, 10):
        m = 3 if cid == 6 else 9
        return f"Hasil = {n}. Jumlah angka: {ds} = {d}; {d} {'habis' if d % m == 0 else 'tidak habis'} dibagi {m}. {yes}"
    if cid == 7:
        t = n % 100
        return f"Hasil = {n}. Dua angka terakhir {t}; {t} {'habis' if t % 4 == 0 else 'tidak habis'} dibagi 4. {yes}"
    if cid == 8:
        return f"Hasil = {n}. Satuannya {n % 10}. {yes}"
    if cid == 9:
        return (f"Hasil = {n}. {'Genap' if n % 2 == 0 else 'Ganjil'}; jumlah angka {d} "
                f"{'habis' if d % 3 == 0 else 'tidak habis'} dibagi 3. {yes}")
    if cid == 11:
        return f"Hasil = {n}. {n} \u00f7 7 = {n // 7} sisa {n % 7}. {yes}"
    if cid == 12:
        r = isqrt(n)
        if is_square(n):
            return f"Hasil = {n}. {r} \u00d7 {r} = {n}. {yes}"
        return f"Hasil = {n}. Terletak di antara {r}\u00b2 = {r * r} dan {r + 1}\u00b2 = {(r + 1) ** 2}. {yes}"
    if cid == 13:
        if is_prime(n):
            return f"Hasil = {n}. Tidak punya faktor selain 1 dan {n}. {yes}"
        p = next(i for i in range(2, n) if n % i == 0)
        return f"Hasil = {n}. {n} = {p} \u00d7 {n // p}, jadi bukan prima. {yes}"
    if cid == 14:
        return f"Hasil = {n}. {n} \u00f7 5 = {n // 5} sisa {n % 5}. {yes}"
    pos = "lebih dari 100 dan kurang dari 200" if 100 < n < 200 else ("100 atau kurang" if n <= 100 else "200 atau lebih")
    return f"Hasil = {n}, yaitu {pos}. {yes}"


# -------------------------------------------------------------- builder ekspresi
def sup(n):
    return str(n).translate(SUP)


def make_builders(rng):
    def R(txt, tex, py, jenis):
        return (txt, tex, py, jenis)

    def divisors(n, lo, hi):
        return [d for d in range(lo, hi + 1) if n % d == 0]

    # ---- MUDAH
    def b_mul(T):
        ds = [d for d in divisors(T, 2, 30) if 2 <= T // d <= 99]
        if not ds:
            return None
        a = rng.choice(ds)
        b = T // a
        if rng.random() < .5:
            a, b = b, a
        return R(f"{a} \u00d7 {b}", f"{a}\\times {b}", f"{a}*{b}", "Perkalian")

    def b_add(T):
        if T < 12:
            return None
        a = rng.randint(5, T - 5)
        b = T - a
        return R(f"{a} + {b}", f"{a}+{b}", f"{a}+{b}", "Penjumlahan")

    def b_sub(T):
        b = rng.randint(5, 99)
        a = T + b
        return R(f"{a} \u2212 {b}", f"{a}-{b}", f"{a}-{b}", "Pengurangan")

    def b_div(T):
        b = rng.randint(2, 9)
        a = T * b
        if a > 1500:
            return None
        return R(f"{a} \u00f7 {b}", f"{a}\\div {b}", f"{a}//{b}", "Pembagian")

    def b_muladd(T):
        a = rng.randint(2, 12)
        cs = [c for c in range(1, 31) if (T - c) % a == 0 and (T - c) // a >= 2]
        if not cs:
            return None
        c = rng.choice(cs)
        b = (T - c) // a
        return R(f"{a} \u00d7 {b} + {c}", f"{a}\\times {b}+{c}", f"{a}*{b}+{c}", "Kali lalu tambah")

    def b_mulsub(T):
        a = rng.randint(2, 12)
        cs = [c for c in range(1, 31) if (T + c) % a == 0 and (T + c) // a <= 150]
        if not cs:
            return None
        c = rng.choice(cs)
        b = (T + c) // a
        return R(f"{a} \u00d7 {b} \u2212 {c}", f"{a}\\times {b}-{c}", f"{a}*{b}-{c}", "Kali lalu kurang")

    def b_sqadd(T, smax=40):
        ss = [s for s in range(3, smax + 1) if 0 <= T - s * s <= 60]
        if not ss:
            return None
        s = rng.choice(ss)
        c = T - s * s
        if c == 0:
            return R(f"{s}{sup(2)}", f"{s}^2", f"{s}**2", "Kuadrat")
        return R(f"{s}{sup(2)} + {c}", f"{s}^2+{c}", f"{s}**2+{c}", "Kuadrat ditambah")

    def b_sqadd_easy(T):
        return b_sqadd(T, 12)

    # ---- SEDANG
    def b_sqsub(T):
        ss = [s for s in range(3, 41) if 1 <= s * s - T <= 60]
        if not ss:
            return None
        s = rng.choice(ss)
        c = s * s - T
        return R(f"{s}{sup(2)} \u2212 {c}", f"{s}^2-{c}", f"{s}**2-{c}", "Kuadrat dikurangi")

    def b_cube(T):
        opts = []
        for s in range(3, 14):
            diff = T - s ** 3
            if 1 <= abs(diff) <= 80:
                opts.append((s, diff))
        if not opts:
            return None
        s, diff = rng.choice(opts)
        if diff > 0:
            return R(f"{s}{sup(3)} + {diff}", f"{s}^3+{diff}", f"{s}**3+{diff}", "Pangkat tiga")
        return R(f"{s}{sup(3)} \u2212 {-diff}", f"{s}^3-{-diff}", f"{s}**3-{-diff}", "Pangkat tiga")

    def b_parenmul(T):
        cs = divisors(T, 2, 12)
        if not cs:
            return None
        c = rng.choice(cs)
        S = T // c
        if S < 4 or S > 300:
            return None
        if rng.random() < .5:
            a = rng.randint(2, S - 2)
            b = S - a
            return R(f"({a} + {b}) \u00d7 {c}", f"({a}+{b})\\times {c}", f"({a}+{b})*{c}", "Kurung dikali")
        b = rng.randint(2, 99)
        a = S + b
        return R(f"({a} \u2212 {b}) \u00d7 {c}", f"({a}-{b})\\times {c}", f"({a}-{b})*{c}", "Kurung dikali")

    def b_twoprod(T):
        for _ in range(40):
            c, d = rng.randint(2, 12), rng.randint(2, 12)
            Rm = T - c * d
            if Rm < 4:
                continue
            ds = [x for x in divisors(Rm, 2, 12) if 2 <= Rm // x <= 60]
            if not ds:
                continue
            a = rng.choice(ds)
            b = Rm // a
            return R(f"{a} \u00d7 {b} + {c} \u00d7 {d}", f"{a}\\times {b}+{c}\\times {d}",
                     f"{a}*{b}+{c}*{d}", "Dua perkalian dijumlah")
        return None

    def b_prec(T):
        b, c = rng.randint(2, 12), rng.randint(2, 12)
        if rng.random() < .5:
            a = T - b * c
            if a < 2:
                return None
            return R(f"{a} + {b} \u00d7 {c}", f"{a}+{b}\\times {c}", f"{a}+{b}*{c}", "Hitung campuran")
        a = T + b * c
        if a > 1500:
            return None
        return R(f"{a} \u2212 {b} \u00d7 {c}", f"{a}-{b}\\times {c}", f"{a}-{b}*{c}", "Hitung campuran")

    def b_divadd(T):
        c = rng.randint(5, 60)
        X = T - c
        b = rng.randint(2, 9)
        a = X * b
        if X < 2 or a > 999:
            return None
        return R(f"{a} \u00f7 {b} + {c}", f"{a}\\div {b}+{c}", f"{a}//{b}+{c}", "Bagi lalu tambah")

    def b_divchain(T):
        c = rng.randint(2, 9)
        P = T * c
        ds = [x for x in divisors(P, 2, 40) if 2 <= P // x <= 99]
        if not ds:
            return None
        ds = [x for x in ds if x != c and P // x != c]
        if not ds:
            return None
        a = rng.choice(ds)
        b = P // a
        return R(f"{a} \u00d7 {b} \u00f7 {c}", f"{a}\\times {b}\\div {c}", f"{a}*{b}//{c}", "Kali lalu bagi")

    def b_root_easy(T):
        if rng.random() < .6:
            ss = [s for s in range(3, 31) if 2 <= T - s]
            ss = [s for s in ss if T - s <= 150]
            if not ss:
                return None
            s = rng.choice(ss)
            c = T - s
            return R(f"\u221a{s * s} + {c}", f"\\sqrt{{{s * s}}}+{c}", f"isqrt({s * s})+{c}", "Akar kuadrat")
        ss = [s for s in range(2, 13) if 2 <= T - s <= 150]
        if not ss:
            return None
        s = rng.choice(ss)
        c = T - s
        return R(f"\u221b{s ** 3} + {c}", f"\\sqrt[3]{{{s ** 3}}}+{c}", f"round({s ** 3}**(1/3))+{c}", "Akar pangkat tiga")

    # ---- MENANTANG
    def b_threeop(T):
        c = rng.randint(2, 9)
        d = rng.randint(1, 30)
        if rng.random() < .5:
            val = T - d
            if val <= 0 or val % c:
                return None
            S = val // c
            sign, py_sign = "+", "+"
        else:
            val = T + d
            if val % c:
                return None
            S = val // c
            sign, py_sign = "\u2212", "-"
        if S < 4 or S > 250:
            return None
        a = rng.randint(2, S - 2)
        b = S - a
        return R(f"({a} + {b}) \u00d7 {c} {sign} {d}", f"({a}+{b})\\times {c}{py_sign}{d}",
                 f"({a}+{b})*{c}{py_sign}{d}", "Kurung, kali, lalu tambah/kurang")

    def b_sqmix(T):
        a = rng.randint(3, 25)
        Rm = T - a * a
        sign = 1
        if Rm < 4:
            Rm = a * a - T
            sign = -1
            if Rm < 4:
                return None
        ds = [x for x in divisors(Rm, 2, 12) if 2 <= Rm // x <= 60]
        if not ds:
            return None
        b = rng.choice(ds)
        c = Rm // b
        if sign == 1:
            return R(f"{a}{sup(2)} + {b} \u00d7 {c}", f"{a}^2+{b}\\times {c}", f"{a}**2+{b}*{c}", "Kuadrat dan kali")
        return R(f"{a}{sup(2)} \u2212 {b} \u00d7 {c}", f"{a}^2-{b}\\times {c}", f"{a}**2-{b}*{c}", "Kuadrat dan kali")

    def b_parensq(T):
        ss = [s for s in range(4, 31) if abs(T - s * s) <= 40]
        if not ss:
            return None
        s = rng.choice(ss)
        a = rng.randint(2, s - 2)
        b = s - a
        c = T - s * s
        if c == 0:
            return R(f"({a} + {b}){sup(2)}", f"({a}+{b})^2", f"({a}+{b})**2", "Jumlah dikuadratkan")
        if c > 0:
            return R(f"({a} + {b}){sup(2)} + {c}", f"({a}+{b})^2+{c}", f"({a}+{b})**2+{c}", "Jumlah dikuadratkan")
        return R(f"({a} + {b}){sup(2)} \u2212 {-c}", f"({a}+{b})^2-{-c}", f"({a}+{b})**2-{-c}", "Jumlah dikuadratkan")

    def b_sqdiff(T):
        pairs = []
        for p in range(1, isqrt(T) + 1):
            if T % p == 0:
                q = T // p
                if p < q and (p + q) % 2 == 0:
                    a, b = (p + q) // 2, (q - p) // 2
                    if b >= 3 and a <= 60:
                        pairs.append((a, b))
        if not pairs:
            return None
        a, b = rng.choice(pairs)
        return R(f"{a}{sup(2)} \u2212 {b}{sup(2)}", f"{a}^2-{b}^2", f"{a}**2-{b}**2", "Selisih kuadrat")

    def b_root_hard(T):
        if rng.random() < .55:
            s, a = rng.randint(3, 20), rng.randint(2, 9)
            c = T - s * a
            if c < 1 or c > 100:
                return None
            return R(f"\u221a{s * s} \u00d7 {a} + {c}", f"\\sqrt{{{s * s}}}\\times {a}+{c}",
                     f"isqrt({s * s})*{a}+{c}", "Akar dan kali")
        s, a = rng.randint(2, 12), rng.randint(2, 9)
        c = s * a - T
        if c < 1 or c > 100:
            return None
        # bentuk: akar pangkat tiga x a - c
        return R(f"\u221b{s ** 3} \u00d7 {a} \u2212 {c}", f"\\sqrt[3]{{{s ** 3}}}\\times {a}-{c}",
                 f"round({s ** 3}**(1/3))*{a}-{c}", "Akar dan kali")

    def b_sqsq(T):
        pairs = [(a, b) for a in range(2, 26) for b in range(2, a + 1) if a * a + b * b == T]
        if not pairs:
            return None
        a, b = rng.choice(pairs)
        return R(f"{a}{sup(2)} + {b}{sup(2)}", f"{a}^2+{b}^2", f"{a}**2+{b}**2", "Jumlah dua kuadrat")

    return {
        "Mudah": [b_mul, b_add, b_sub, b_div, b_muladd, b_sqadd_easy],
        "Sedang": [b_parenmul, b_twoprod, b_prec, b_divadd, b_divchain, b_sqadd, b_sqsub,
                   b_cube, b_mulsub, b_root_easy],
        "Menantang": [b_threeop, b_sqmix, b_parensq, b_sqdiff, b_root_hard, b_sqsq],
    }


# -------------------------------------------------------------------- generator
def pick_tier(rng):
    r, acc = rng.random(), 0
    for t, w in TIER_W:
        acc += w
        if r <= acc:
            return t
    return "Menantang"


def sample_target(rng, cid, tier, prop, near, want_pos):
    lo, hi = RANGES.get(cid, DEFAULT_RANGE)[tier]
    for _ in range(400):
        if cid == 15:
            T = rng.randint(105, 195) if want_pos else rng.choice(
                [rng.randint(20, 95), rng.randint(205, 320)])
        else:
            T = rng.randint(lo, hi)
        ok = prop(T)
        if want_pos and ok:
            return T
        if not want_pos and not ok:
            if cid == 15 and near is not None and rng.random() < .6:
                if not near(T):
                    continue
            elif near is not None and rng.random() < .6 and not near(T):
                continue
            if cid == 13 and T < 11:
                continue
            return T
    return None


def gen_category(cat, rng, B):
    cid, name, prop, near, trik = cat
    pos, neg, seen = [], [], set()
    guard = 0
    while len(pos) < POS_PER_CAT or len(neg) < NEG_PER_CAT:
        guard += 1
        if guard > 500000:
            raise RuntimeError(f"gagal mengisi kategori {cid}: pos={len(pos)} neg={len(neg)}")
        want_pos = len(pos) < POS_PER_CAT and (len(neg) >= NEG_PER_CAT or rng.random() < .45)
        tier = pick_tier(rng)
        T = sample_target(rng, cid, tier, prop, near, want_pos)
        if T is None:
            continue
        fns = B[tier][:]
        rng.shuffle(fns)
        res = None
        for fn in fns:
            res = fn(T)
            if res:
                break
        if not res:
            continue
        txt, tex, py, jenis = res
        if txt in seen:
            continue
        seen.add(txt)
        item = dict(txt=txt, tex=tex, py=py, val=T, jenis=jenis, tier=tier, benar=bool(prop(T)))
        (pos if want_pos else neg).append(item)
    items = pos + neg
    rng.shuffle(items)
    return items


def verify(items, prop):
    env = {"isqrt": isqrt, "round": round}
    for it in items:
        v = eval(it["py"], {"__builtins__": {}}, env)
        assert v == it["val"], (it["txt"], v, it["val"])
        assert bool(prop(v)) == it["benar"]


def main(out="bank_soal_glacia.json"):
    rng = random.Random(SEED)
    B = make_builders(rng)
    bank = []
    for cat in CATS:
        items = gen_category(cat[:5], rng, B)
        verify(items, cat[2])
        for i, it in enumerate(items, 1):
            v = it["val"]
            bank.append(dict(
                id=f"K{cat[0]:02d}-{i:03d}", kategori_id=cat[0], kategori=cat[1],
                ekspresi=it["txt"], latex=it["tex"], tingkat=it["tier"], jenis=it["jenis"],
                hasil=str(v), satuan=v % 10, paritas="Ganjil" if v % 2 else "Genap",
                memenuhi=it["benar"], pembahasan=explain(cat[0], v, it["benar"]),
            ))
    with open(out, "w", encoding="utf-8") as f:
        json.dump(dict(versi="2.0-SD", seed=SEED, jumlah=len(bank),
                       kategori=[dict(id=c[0], nama=c[1], trik=c[4]) for c in CATS], soal=bank),
                  f, ensure_ascii=False, indent=1)
    return bank


# --------------------------------------------------------------------- sampler
def sample_board(bank, kategori_id, size=64, pct_min=0.40, pct_max=0.50, rng=None, exclude_ids=()):
    """Papan `size` kartu; jumlah kartu benar acak antara pct_min..pct_max (64 -> 26..32), lalu diacak."""
    rng = rng or random.Random()
    lo, hi = math.ceil(size * pct_min), math.floor(size * pct_max)
    k = rng.randint(lo, hi)
    ex = set(exclude_ids)
    pool = [s for s in bank if s["kategori_id"] == kategori_id and s["id"] not in ex]
    pos = [s for s in pool if s["memenuhi"]]
    neg = [s for s in pool if not s["memenuhi"]]

    def pick(src, n):
        out = []
        for t, w in TIER_W:
            sub = [s for s in src if s["tingkat"] == t]
            rng.shuffle(sub)
            out += sub[:round(n * w)]
        ids = {s["id"] for s in out}
        rest = [s for s in src if s["id"] not in ids]
        rng.shuffle(rest)
        out += rest[:max(0, n - len(out))]
        return out[:n]

    board = pick(pos, k) + pick(neg, size - k)
    rng.shuffle(board)
    return board


if __name__ == "__main__":
    b = main()
    print("total soal:", len(b))

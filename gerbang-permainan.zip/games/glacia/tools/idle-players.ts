/**
 * Manual testing helper: joins N players to a room that the teacher already opened in the UI, using names from THAT room's own
 * roster (nothing is made up here), and keeps them connected so one real browser can play against them.
 * Usage: tsx tools/idle-players.ts <room PIN> [count=3] [server=http://localhost:4000]
 */
import { io } from 'socket.io-client';

const pin = process.argv[2] ?? '';
const n = Number(process.argv[3] ?? 3);
const base = process.argv[4] ?? 'http://localhost:4000';
if (!/^\d{6}$/.test(pin)) {
  console.error('Usage: tsx tools/idle-players.ts <6-digit room PIN> [count] [server]');
  process.exit(2);
}

for (let i = 0; i < n; i++) {
  const s = io(`${base}/game`, { transports: ['websocket'], reconnection: false });
  await new Promise<void>((r) => s.on('connect', () => r()));
  const join = await new Promise<{ ok: boolean; code?: string; roster?: { studentId: string; name: string; taken: boolean }[] }>((r) => s.emit('room:join', { pin, deviceToken: `idle-${pin}-${i}-${Date.now()}` }, r));
  const free = join.roster?.find((x) => !x.taken);
  if (!join.ok || !free) {
    console.error(`player ${i + 1}: cannot join (${join.code ?? 'no free name'})`);
    process.exit(1);
  }
  const pick = await new Promise<{ ok: boolean; code?: string }>((r) => s.emit('room:pickName', { studentId: free.studentId }, r));
  console.log(`${pick.ok ? 'joined' : 'failed ' + pick.code}: ${free.name}`);
}
console.log('players stay connected; press Ctrl+C to leave');
setInterval(() => {}, 60_000);

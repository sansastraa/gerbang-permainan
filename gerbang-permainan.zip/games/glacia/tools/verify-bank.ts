/**
 * Verifies the question-bank Excel files (or a generator JSON) independently of glacia_generator.py.
 * Usage: tsx verify-bank.ts <xlsx-or-json> [<other xlsx>] [--write-json <out.json>] [--report <out.md>]
 */
import fs from 'node:fs';
import ExcelJS from 'exceljs';
import { ALLOWED_CHARS, CATEGORY_PROPS, evalExpr } from './expr';

export interface BankItem {
  id: string;
  kategori_id: number;
  kategori: string;
  ekspresi: string;
  latex: string;
  tingkat: string;
  jenis: string;
  hasil: string;
  satuan: number;
  paritas: string;
  memenuhi: boolean;
  pembahasan: string;
}
export interface Bank {
  versi: string;
  seed?: number;
  jumlah: number;
  kategori: { id: number; nama: string; trik: string }[];
  soal: BankItem[];
}

const cellText = (v: unknown): string => {
  if (v == null) return '';
  if (typeof v === 'object') {
    const o = v as { richText?: { text: string }[]; result?: unknown; text?: string };
    if (o.richText) return o.richText.map((r) => r.text).join('');
    if (o.result !== undefined) return String(o.result);
    if (o.text) return o.text;
  }
  return String(v);
};

export async function readXlsx(file: string): Promise<{ bank: Bank; hasPembahasan: boolean }> {
  const wb = new ExcelJS.Workbook();
  await wb.xlsx.readFile(file);
  const kategori: Bank['kategori'] = [];
  const summary = wb.getWorksheet('Ringkasan');
  if (summary) {
    for (let r = 5; r <= summary.rowCount; r++) {
      const row = summary.getRow(r);
      const id = Number(cellText(row.getCell(1).value));
      if (id >= 1 && id <= 15) {
        kategori.push({ id, nama: cellText(row.getCell(2).value), trik: cellText(row.getCell(3).value) });
      }
    }
  }
  const soal: BankItem[] = [];
  let hasPembahasan = false;
  for (const ws of wb.worksheets) {
    const m = /^K(\d\d)$/.exec(ws.name);
    if (!m) continue;
    const cid = Number(m[1]);
    const head = (ws.getRow(1).values as unknown[]).slice(1).map(cellText);
    const col = (name: string) => head.indexOf(name) + 1;
    const cPemb = col('Pembahasan');
    if (cPemb > 0) hasPembahasan = true;
    for (let r = 2; r <= ws.rowCount; r++) {
      const row = ws.getRow(r);
      const id = cellText(row.getCell(col('ID')).value);
      if (!id) continue;
      const hasil = cellText(row.getCell(col('Hasil')).value);
      soal.push({
        id,
        kategori_id: cid,
        kategori: kategori.find((k) => k.id === cid)?.nama ?? '',
        ekspresi: cellText(row.getCell(col('Ekspresi')).value),
        latex: cellText(row.getCell(col('LaTeX')).value),
        tingkat: cellText(row.getCell(col('Tingkat')).value),
        jenis: cellText(row.getCell(col('Jenis')).value),
        hasil,
        satuan: Number(cellText(row.getCell(col('Satuan')).value)),
        paritas: cellText(row.getCell(col('Ganjil/Genap')).value),
        memenuhi: cellText(row.getCell(col('Memenuhi kategori')).value) === 'Ya',
        pembahasan: cPemb > 0 ? cellText(row.getCell(cPemb).value) : '',
      });
    }
  }
  return { bank: { versi: 'xlsx', jumlah: soal.length, kategori, soal }, hasPembahasan };
}

export interface Finding {
  level: 'ERROR' | 'WARN';
  msg: string;
}

const FORBIDDEN_V1 = [/∑/, /!/, /⋯|\.\.\./, /\|/, /mod/i, /≡/];

export function verifyV2(bank: Bank): { findings: Finding[]; stats: Record<string, unknown> } {
  const f: Finding[] = [];
  const err = (msg: string) => f.push({ level: 'ERROR', msg });
  const warn = (msg: string) => f.push({ level: 'WARN', msg });
  const byCat = new Map<number, BankItem[]>();
  for (const q of bank.soal) byCat.set(q.kategori_id, [...(byCat.get(q.kategori_id) ?? []), q]);
  if (bank.soal.length !== 7500) err(`total soal ${bank.soal.length} ≠ 7500`);
  const ids = new Set<string>();
  const kinds = new Map<string, number>();
  const perCat: Record<number, unknown> = {};
  for (let cid = 1; cid <= 15; cid++) {
    const list = byCat.get(cid) ?? [];
    const pos = list.filter((q) => q.memenuhi).length;
    const tiers: Record<string, number> = { Mudah: 0, Sedang: 0, Menantang: 0 };
    const seen = new Set<string>();
    list.forEach((q, i) => {
      if (ids.has(q.id)) err(`ID ganda ${q.id}`);
      ids.add(q.id);
      if (q.id !== `K${String(cid).padStart(2, '0')}-${String(i + 1).padStart(3, '0')}`) err(`ID tidak berurutan: ${q.id} pada baris ${i + 1} kategori ${cid}`);
      tiers[q.tingkat] = (tiers[q.tingkat] ?? 0) + 1;
      kinds.set(q.jenis, (kinds.get(q.jenis) ?? 0) + 1);
      if (seen.has(q.ekspresi)) err(`ekspresi ganda di kategori ${cid}: ${q.ekspresi}`);
      seen.add(q.ekspresi);
      if (!ALLOWED_CHARS.test(q.ekspresi)) {
        err(`${q.id}: karakter di luar materi SD: ${q.ekspresi}`);
        return;
      }
      if (FORBIDDEN_V1.some((re) => re.test(q.ekspresi) || re.test(q.latex))) err(`${q.id}: operator terlarang: ${q.ekspresi}`);
      let v: number;
      try {
        v = evalExpr(q.ekspresi);
      } catch (e) {
        err(`${q.id}: ekspresi tidak bisa dihitung (${(e as Error).message}): ${q.ekspresi}`);
        return;
      }
      if (String(v) !== q.hasil) err(`${q.id}: hasil ${q.hasil} ≠ hitung ulang ${v} (${q.ekspresi})`);
      const cap = cid === 12 ? 900 : cid === 13 ? 199 : 1500;
      if (v > 1500 || v < 0) err(`${q.id}: hasil ${v} di luar 0..1500`);
      else if (v > cap && cid === 12) warn(`${q.id}: kuadrat > 900 (${v}) — blueprint menyebut maks 900`);
      else if (v > cap && cid === 13) warn(`${q.id}: prima > 199 (${v})`);
      if (v % 10 !== q.satuan) err(`${q.id}: satuan ${q.satuan} ≠ ${v % 10}`);
      if ((v % 2 ? 'Ganjil' : 'Genap') !== q.paritas) err(`${q.id}: paritas salah`);
      if (CATEGORY_PROPS[cid]!(v) !== q.memenuhi) err(`${q.id}: kolom "Memenuhi" salah untuk hasil ${v} (kategori ${cid})`);
      if (q.pembahasan) {
        if (!q.pembahasan.startsWith(`Hasil = ${v}`)) err(`${q.id}: pembahasan tidak memuat hasil yang benar`);
        const tail = q.memenuhi ? 'Memenuhi.' : 'Tidak memenuhi.';
        if (!q.pembahasan.endsWith(tail)) err(`${q.id}: pembahasan bertentangan dengan kunci`);
      } else warn(`${q.id}: tanpa pembahasan`);
      if (!q.latex) err(`${q.id}: LaTeX kosong`);
    });
    if (list.length !== 500) err(`kategori ${cid}: ${list.length} soal (harus 500)`);
    if (pos !== 225) err(`kategori ${cid}: ${pos} benar (harus 225)`);
    perCat[cid] = { total: list.length, benar: pos, pengecoh: list.length - pos, ...tiers };
  }
  return { findings: f, stats: { perCat, jenis: Object.fromEntries([...kinds.entries()].sort()) } };
}

/** How badly a (v1-style) bank breaks the SD-level rules; used only to describe a non-compliant file. */
export function describeNonCompliance(bank: Bank): Record<string, number> {
  const c: Record<string, number> = { total: bank.soal.length, sigma: 0, faktorial: 0, deret_titik: 0, hasil_digit: 0, hasil_gt_1500: 0, sisa_bagi_9: 0 };
  for (const q of bank.soal) {
    if (q.ekspresi.includes('∑')) c.sigma!++;
    if (q.ekspresi.includes('!')) c.faktorial!++;
    if (q.ekspresi.includes('⋯')) c.deret_titik!++;
    if (q.hasil.startsWith('±')) c.hasil_digit!++;
    else if (Number(q.hasil) > 1500) c.hasil_gt_1500!++;
  }
  return c;
}

export function compareBanks(a: Bank, b: Bank): { sameId: number; sameExpr: number; sameHasil: number; sameKey: number; onlyA: number; onlyB: number } {
  const mb = new Map(b.soal.map((q) => [q.id, q]));
  let sameId = 0, sameExpr = 0, sameHasil = 0, sameKey = 0, onlyA = 0;
  for (const q of a.soal) {
    const o = mb.get(q.id);
    if (!o) { onlyA++; continue; }
    sameId++;
    if (o.ekspresi === q.ekspresi) sameExpr++;
    if (o.hasil === q.hasil) sameHasil++;
    if (o.memenuhi === q.memenuhi) sameKey++;
  }
  return { sameId, sameExpr, sameHasil, sameKey, onlyA, onlyB: b.soal.length - sameId };
}

async function main() {
  const args = process.argv.slice(2);
  const opt = (name: string) => {
    const i = args.indexOf(name);
    return i >= 0 ? args[i + 1] : undefined;
  };
  const files = args.filter((a, i) => !a.startsWith('--') && !(i > 0 && args[i - 1]!.startsWith('--')));
  const writeJson = opt('--write-json');
  const reportPath = opt('--report');
  const lines: string[] = [];
  const out = (s = '') => {
    console.log(s);
    lines.push(s);
  };
  const loaded: { file: string; bank: Bank; ok: boolean }[] = [];
  for (const file of files) {
    out(`## ${file.split(/[\\/]/).pop()}`);
    let bank: Bank;
    if (file.endsWith('.json')) {
      const j = JSON.parse(fs.readFileSync(file, 'utf8')) as Bank;
      bank = { ...j, jumlah: j.soal.length };
    } else bank = (await readXlsx(file)).bank;
    const { findings, stats } = verifyV2(bank);
    const errors = findings.filter((x) => x.level === 'ERROR');
    out(`- Jumlah soal terbaca: ${bank.soal.length}`);
    out(`- Pemeriksaan materi SD v2: ${errors.length === 0 ? 'LULUS' : `GAGAL (${errors.length} kesalahan)`}`);
    if (errors.length) {
      const nc = describeNonCompliance(bank);
      out(`- Pola di luar materi SD: ${JSON.stringify(nc)}`);
      for (const e of errors.slice(0, 8)) out(`  - ${e.msg}`);
      if (errors.length > 8) out(`  - … dan ${errors.length - 8} kesalahan lain`);
    }
    for (const w of findings.filter((x) => x.level === 'WARN').slice(0, 5)) out(`  - peringatan: ${w.msg}`);
    if (errors.length === 0) out(`- Statistik: ${JSON.stringify(stats)}`);
    out();
    loaded.push({ file, bank, ok: errors.length === 0 });
  }
  if (loaded.length === 2) {
    const c = compareBanks(loaded[0]!.bank, loaded[1]!.bank);
    out(`## Perbandingan kedua berkas`);
    out(`- ID yang sama: ${c.sameId}; ekspresi identik: ${c.sameExpr}; hasil identik: ${c.sameHasil}; kunci "memenuhi" identik: ${c.sameKey}`);
    out(`- Hanya di berkas 1: ${c.onlyA}; hanya di berkas 2: ${c.onlyB}`);
  }
  const good = loaded.find((l) => l.ok);
  if (writeJson && good) {
    const b = good.bank;
    const json: Bank = {
      versi: '2.0-SD',
      seed: 20261105,
      jumlah: b.soal.length,
      kategori: b.kategori,
      soal: b.soal,
    };
    fs.writeFileSync(writeJson, JSON.stringify(json, null, 1), 'utf8');
    out(`Ditulis: ${writeJson} (dari ${good.file.split(/[\\/]/).pop()})`);
  }
  if (reportPath) fs.writeFileSync(reportPath, lines.join('\n') + '\n', 'utf8');
  process.exitCode = loaded.some((l) => !l.ok) && !good ? 1 : 0;
}

if (process.argv[1] && /verify-bank/.test(process.argv[1])) await main();

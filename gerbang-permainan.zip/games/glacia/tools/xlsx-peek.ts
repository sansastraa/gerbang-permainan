import ExcelJS from 'exceljs';

const file = process.argv[2]!;
const wb = new ExcelJS.Workbook();
await wb.xlsx.readFile(file);
for (const ws of wb.worksheets) {
  console.log(`# ${ws.name}: rows=${ws.rowCount} cols=${ws.columnCount}`);
  for (let r = 1; r <= Math.min(4, ws.rowCount); r++) {
    console.log(JSON.stringify((ws.getRow(r).values as unknown[]).slice(1).map((v) => (typeof v === 'object' && v ? JSON.stringify(v) : v))));
  }
}

/**
 * Load test (blueprint 13, "Beban"): N bots in one room play real rounds against a running server.
 * Usage: tsx tools/bots.ts [--bots 100] [--rounds 3] [--seconds 60] [--server http://localhost:4000] [--rate 1,3]
 * Targets: p95 latency of card:result/card:rejected < 300 ms, and every bot's final score equals the sum of its own results.
 * Set HOST_PIN to the server's teacher PIN (dev default guru1234). The roster is synthetic (Bot 001...) and only lives in this test.
 * Bots cannot know the key; they tap random free cards, so about half of their taps are wrong (like real students).
 */
import { io, type Socket } from 'socket.io-client';

const arg = (name: string, d: string) => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? (process.argv[i + 1] as string) : d;
};
const N = Number(arg('bots', '100'));
const ROUNDS = Number(arg('rounds', '3'));
const SECONDS = Number(arg('seconds', '60'));
const SERVER = arg('server', 'http://localhost:4000');
const [RATE_MIN, RATE_MAX] = arg('rate', '1,3').split(',').map(Number) as [number, number];

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
const rest = async (p: string, jwt: string | null, body?: unknown) =>
  (await (await fetch(`${SERVER}/api${p}`, { method: body === undefined ? 'GET' : 'POST', headers: { 'Content-Type': 'application/json', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) }, body: body === undefined ? undefined : JSON.stringify(body) })).json()) as Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

interface Bot {
  i: number;
  s: Socket;
  playerId: string;
  studentId: string;
  cards: string[];
  claimed: Set<string>;
  answered: Set<string>;
  pending: Map<string, number>;
  cooldownUntil: number;
  running: boolean;
  roundSum: number;
  total: number;
  lat: number[];
  results: number;
  rejects: number;
  timer?: NodeJS.Timeout;
}

const bots: Bot[] = [];
const latencies: number[] = [];
const early: number[] = [];
const late: number[] = [];
let roundStartAt = 0;
let errors = 0;
let events = 0;
const rounds: { no: number; at: number }[] = [];

const auth = await rest('/auth/host', null, { token: process.env.HOST_PIN ?? 'guru1234' });
const jwt = auth.jwt as string;
const cats = (await rest('/categories', jwt)).categories as { id: number }[];
const room = await rest('/rooms', jwt, { classId: 'Uji beban', maxPlayers: 100, roster: Array.from({ length: N }, (_, i) => ({ id: `bot-${i + 1}`, name: `Bot ${String(i + 1).padStart(3, '0')}` })), rounds: ROUNDS, roundSeconds: SECONDS, allowedCategoryIds: cats.map((c) => c.id) });
if (!room.ok) throw new Error(`cannot create room: ${JSON.stringify(room)}`);
const { roomId, pin } = room as { roomId: string; pin: string };
console.log(`room ${roomId} pin ${pin}; ${N} bots, ${ROUNDS} rounds x ${SECONDS}s`);

async function spawn(i: number): Promise<Bot> {
  const s = io(`${SERVER}/game`, { transports: ['websocket'], reconnection: false });
  await new Promise<void>((res, rej) => {
    s.on('connect', () => res());
    s.on('connect_error', rej);
  });
  const b: Bot = { i, s, playerId: '', studentId: '', cards: [], claimed: new Set(), answered: new Set(), pending: new Map(), cooldownUntil: 0, running: false, roundSum: 0, total: 0, lat: [], results: 0, rejects: 0 };
  s.onAny(() => events++);
  s.on('round:start', (m: { cards: { cardId: string }[] }) => {
    if (b.i === 0) roundStartAt = performance.now();
    b.cards = m.cards.map((c) => c.cardId);
    b.claimed.clear();
    b.answered.clear();
    b.cooldownUntil = 0;
    b.roundSum = 0;
    b.running = true;
    loop(b);
  });
  s.on('board:refresh', (m: { replaced: { oldCardId: string; cardId: string }[] }) => {
    const map = new Map(m.replaced.map((r) => [r.oldCardId, r.cardId]));
    b.cards = b.cards.map((c) => map.get(c) ?? c);
  });
  s.on('card:claimed', (m: { cardId: string }) => b.claimed.add(m.cardId));
  s.on('card:released', (m: { cardId: string }) => b.claimed.delete(m.cardId));
  const answerDone = (cardId: string) => {
    const t0 = b.pending.get(cardId);
    if (t0 !== undefined) {
      const ms = performance.now() - t0;
      b.lat.push(ms);
      latencies.push(ms);
      (performance.now() - roundStartAt < 8000 ? early : late).push(ms);
      b.pending.delete(cardId);
    }
  };
  s.on('card:result', (m: { cardId: string; points: number; bonus: number; cooldownUntil?: number }) => {
    answerDone(m.cardId);
    b.results++;
    b.roundSum += m.points + m.bonus;
    if (m.cooldownUntil) b.cooldownUntil = m.cooldownUntil;
  });
  s.on('card:rejected', (m: { cardId: string; code: string; cooldownUntil?: number }) => {
    answerDone(m.cardId);
    b.rejects++;
    if (m.code === 'CARD_CLAIMED') b.claimed.add(m.cardId);
    if (m.cooldownUntil) b.cooldownUntil = m.cooldownUntil;
  });
  s.on('round:end', (m: { roundNo: number }) => {
    b.running = false;
    b.total += Math.max(0, b.roundSum);
    if (b.i === 0) rounds.push({ no: m.roundNo, at: Date.now() });
  });
  s.on('category:options', (o: { categories: { id: number }[] }) => {
    setTimeout(() => s.emit('category:pick', { categoryId: o.categories[0]!.id }), 200 + Math.random() * 500);
  });
  return b;
}

function loop(b: Bot) {
  if (!b.running) return;
  const rate = RATE_MIN + Math.random() * (RATE_MAX - RATE_MIN);
  b.timer = setTimeout(() => {
    if (!b.running) return;
    if (Date.now() >= b.cooldownUntil) {
      const free = b.cards.filter((c) => !b.claimed.has(c) && !b.answered.has(c));
      if (free.length) {
        const c = free[Math.floor(Math.random() * free.length)]!;
        b.answered.add(c);
        b.pending.set(c, performance.now());
        b.s.emit('card:answer', { cardId: c, hidden: false }, (ack: { ok: boolean }) => {
          if (!ack) errors++;
        });
      }
    }
    loop(b);
  }, 1000 / rate);
}

// all bots share one IP: start the server with JOIN_LIMIT_PER_MIN=1000 for this test
for (let i = 0; i < N; i++) {
  const b = await spawn(i);
  const roomN = pin;
  const j = (await new Promise((r) => b.s.emit('room:join', { pin: roomN, deviceToken: `load-${pin}-${i}-xxxxxxxx` }, r))) as { ok: boolean; code?: string };
  if (!j.ok) {
    console.error(`bot ${i} join failed: ${j.code} (raise JOIN limit: set the server to allow ${N} joins/min for this IP)`);
    process.exit(2);
  }
  const roster = (j as unknown as { roster: { studentId: string; taken: boolean }[] }).roster;
  const free = roster.find((r) => !r.taken);
  if (!free) {
    console.error(`no free name for bot ${i}: the room roster has ${roster.length} students`);
    process.exit(2);
  }
  const p = (await new Promise((r) => b.s.emit('room:pickName', { studentId: free.studentId }, r))) as { ok: boolean; playerId: string; code?: string };
  if (!p.ok) {
    console.error(`bot ${i} pickName failed: ${p.code}`);
    process.exit(2);
  }
  b.playerId = p.playerId;
  b.studentId = free.studentId;
  bots.push(b);
}
console.log(`${bots.length} bots in the lobby`);

const host = io(`${SERVER}/game`, { transports: ['websocket'], reconnection: false });
await new Promise<void>((r) => host.on('connect', () => r()));
const hostAck = (await new Promise((r) => host.emit('host:auth', { token: jwt, roomId }, r))) as { ok: boolean };
if (!hostAck.ok) throw new Error('host auth failed');
let finished = false;
host.on('game:end', () => (finished = true));
host.on('round:end', () => setTimeout(() => host.emit('round:next', {}, () => {}), 500)); // do not wait the 20 s auto-advance
const t0 = Date.now();
const started = (await new Promise((r) => host.emit('game:start', {}, r))) as { ok: boolean; code?: string };
if (!started.ok) throw new Error(`start failed ${started.code}`);

const timeout = Date.now() + (ROUNDS * (SECONDS + 40) + 60) * 1000;
while (!finished && Date.now() < timeout) await sleep(500);
if (!finished) {
  console.error('game did not finish in time');
  process.exit(3);
}
await sleep(1500); // let the report be built and the last events flush

const summary = (await (await fetch(`${SERVER}/api/rooms/${roomId}/report`, { headers: { Authorization: `Bearer ${jwt}` } })).json()) as { payload: { students: { studentId: string; totalScore: number; correct: number; wrong: number; status: string }[] } };
const byStudent = new Map(summary.payload.students.map((s) => [s.studentId, s]));
let mismatches = 0;
let answersSent = 0;
for (const b of bots) {
  const s = byStudent.get(b.studentId);
  answersSent += b.results;
  if (!s || s.status !== 'OK' || s.totalScore !== b.total || s.correct + s.wrong !== b.results) {
    mismatches++;
    if (mismatches <= 5) console.error(`mismatch bot ${b.i}: client total ${b.total}/${b.results} results vs server ${JSON.stringify(s)}`);
  }
}
latencies.sort((a, b) => a - b);
const q = (p: number) => Math.round(latencies[Math.min(latencies.length - 1, Math.floor(latencies.length * p))] ?? 0);
const pct = (a: number[], p: number) => { const s = [...a].sort((x, y) => x - y); return Math.round(s[Math.min(s.length - 1, Math.floor(s.length * p))] ?? 0); };
const secs = (Date.now() - t0) / 1000;
const out = {
  bots: bots.length,
  rounds: rounds.length,
  seconds: Math.round(secs),
  answers: answersSent,
  rejectedAfterRace: bots.reduce((a, b) => a + b.rejects, 0),
  p95FirstEightSecondsOfRound: pct(early, 0.95),
  p95RestOfRound: pct(late, 0.95),
  latencyMs: { p50: q(0.5), p95: q(0.95), p99: q(0.99), max: Math.round(latencies.at(-1) ?? 0) },
  eventsPerSecondAllClients: Math.round(events / secs),
  ackErrors: errors,
  scoreMismatches: mismatches,
  pass: q(0.95) < 300 && mismatches === 0 && errors === 0,
};
console.log(JSON.stringify(out, null, 2));
bots.forEach((b) => b.s.disconnect());
host.disconnect();
process.exit(out.pass ? 0 : 1);

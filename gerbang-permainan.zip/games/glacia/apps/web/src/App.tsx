import { useEffect, useState } from 'react';
import Display from './Display';
import Host from './Host';
import Player from './Player';
import Profile from './Profile';
import { BASE_PATH, loadProfile, rankOf } from './lib';
import { routeFrom } from './urls';
import { Avatar, Logo } from './ui';

function useRoute(): { path: string; query: URLSearchParams } {
  // hash routes (#/host) and plain paths (/host, as SIMPETERI opens the console) both work, under any BASE_PATH
  const read = () => routeFrom(window.location.pathname, window.location.hash, window.location.search, BASE_PATH);
  const [r, setR] = useState(read);
  useEffect(() => {
    const f = () => setR(read());
    window.addEventListener('hashchange', f);
    return () => window.removeEventListener('hashchange', f);
  }, []);
  return r;
}

export default function App() {
  const { path, query } = useRoute();
  if (path.startsWith('/display/')) return <Display pin={path.split('/')[2] ?? ''} />;
  if (path.startsWith('/host')) return <Host />;
  if (path.startsWith('/profil')) return <Profile />;
  if (path.startsWith('/play')) return <Player initialPin={query.get('pin') ?? ''} />;
  return <Home />;
}

const DEMO_CARDS = [
  '14 × 6 − 9', '7² + 12', '84 ÷ 4 + 3', '9 × 9 − 4', '(8 + 5)²', '63 − 28',
  '12 × 12', '√169 + 8', '5³ − 40', '96 ÷ 6', '23 + 49', '(30 − 6) × 3',
  '17² − 8', '45 × 2', '∛216 + 11', '88 − 19', '6 × 15 + 2', '(4 + 9)² − 1',
  '250 ÷ 5', '31 + 37', '8² − 15', '120 − 47', '13 × 7', '72 ÷ 8 + 6',
  '19 × 3', '11² + 9', '300 − 126', '(25 − 9)²', '54 + 28', '99 ÷ 9 × 4',
];
// which illustration cards get a claim stamp (a letter, not a person) and in what order (CSS animation delay)
const DEMO_CLAIMS: Record<number, [string, number]> = { 2: ['A', 0], 7: ['B', 1], 11: ['C', 2], 13: ['D', 3], 20: ['E', 4], 25: ['F', 5], 28: ['G', 6] };

function Home() {
  const [pin, setPin] = useState('');
  const profile = loadProfile();
  const rank = rankOf(profile?.claims ?? 0);
  return (
    <main className="home2">
      <header className="home-top">
        <Logo />
        <a className="top-link" href="#/profil">{profile ? <><Avatar name={profile.name} size={26} /><span>{profile.name.split(' ')[0]} · {rank.title}</span></> : 'Profilku'}</a>
      </header>

      <section className="stage">
        <div className="stage-copy">
          <p className="kicker">Permainan hitung kelas 6 · 3 sampai 5 ronde</p>
          <h1 className="wordmark" aria-label="GLACIA">GLA<span>CIA</span></h1>
          <p className="lede">64 kartu hitungan di papan. Separuhnya hasilnya cocok dengan kategori, separuhnya jebakan. <b>Jawaban benar pertama mengklaim kartu</b>, dan kartu itu hilang dari papan teman-temanmu.</p>
        </div>
        <div className="stage-board" aria-hidden="true">
          {DEMO_CARDS.map((c, i) => {
            const claim = DEMO_CLAIMS[i];
            return (
              <div key={i} className={`mini${claim ? ' claimed' : ''}`} style={claim ? ({ ['--d' as string]: `${claim[1] * 0.9 + 0.6}s` } as React.CSSProperties) : undefined}>
                <span>{c}</span>
                {claim && <em>{claim[0]}</em>}
              </div>
            );
          })}
        </div>
      </section>

      <nav className="roles" aria-label="Pilih peranmu">
        <a className="role" href="#/play">
          <span className="idx">01</span>
          <b>Aku siswa</b>
          <small>Ketik PIN dari layar guru, daftar kelas langsung muncul, ketuk namamu.</small>
          <i aria-hidden>→</i>
        </a>
        <a className="role" href="#/host">
          <span className="idx">02</span>
          <b>Aku guru</b>
          <small>Buka ruangan, bagikan PIN atau QR, atur ronde, pantau kecurangan, akhiri kapan saja.</small>
          <i aria-hidden>→</i>
        </a>
        <a className="role" href="#/profil">
          <span className="idx">03</span>
          <b>Profilku</b>
          <small>{profile ? `${profile.claims} kartu diklaim, pangkat ${rank.title}.` : 'Pangkat, skor terbaik, dan kartu yang pernah kamu klaim.'}</small>
          <i aria-hidden>→</i>
        </a>
      </nav>

      <footer className="home-foot">
        <form className="projector" onSubmit={(e) => { e.preventDefault(); if (pin.length === 6) window.location.hash = `#/display/${pin}`; }}>
          <label htmlFor="proj">Layar proyektor</label>
          <input id="proj" inputMode="numeric" maxLength={6} placeholder="PIN 6 angka" value={pin} onChange={(e) => setPin(e.target.value.replace(/\D/g, ''))} />
          <button disabled={pin.length !== 6}>Buka</button>
        </form>
        <ul className="facts" aria-label="Isi permainan">
          <li><b>15</b> kategori</li>
          <li><b>7.500</b> operasi hitung</li>
          <li><b>64</b> kartu per ronde</li>
          <li><b>100</b> pemain per ruangan</li>
        </ul>
      </footer>
    </main>
  );
}

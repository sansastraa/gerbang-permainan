import { useCallback, useEffect, useRef, useState } from 'react';
import { beep, deviceToken, emitAck, loadProfile, rankOf, recordGame, store, useGameSocket, type GameView } from './lib';
import { Leaderboard, rowsFromRound } from './Leaderboard';
import { Avatar, Board, ClaimMeter, Toast, Countdown, Logo, Panel, SoundToggle, Timer, Wheel, useSecondsLeft } from './ui';

interface RosterItem { studentId: string; name: string; taken: boolean }
type Phase = 'pin' | 'in';

const [getPin, setPinStore] = store<string>('glacia.pin', '');
const [, setSidStore] = store<string>('glacia.sid', '');

export default function Player({ initialPin = '' }: { initialPin?: string }) {
  const { socket, view } = useGameSocket();
  const [phase, setPhase] = useState<Phase>('pin');
  const [pin, setPin] = useState(initialPin);
  const [roster, setRoster] = useState<RosterItem[]>([]);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const token = useRef(deviceToken());

  const join = useCallback(
    async (p: string) => {
      setBusy(true);
      setError('');
      const res = await emitAck<{ resumed?: boolean; roster?: RosterItem[]; message?: string }>(socket, 'room:join', { pin: p, deviceToken: token.current });
      setBusy(false);
      if (!res.ok) {
        setRoster([]);
        setError(res.code === 'NO_ROOM' ? 'PIN ini belum ada ruangannya. Cek angkanya di layar guru.' : res.code === 'RATE_LIMITED' ? 'Terlalu sering mencoba. Tunggu semenit.' : (res.message ?? 'Tidak bisa masuk. Tanya gurumu.'));
        return;
      }
      setPinStore(p);
      if (res.resumed) setPhase('in');
      else setRoster(res.roster ?? []);
    },
    [socket],
  );

  // names appear the moment the sixth digit is typed; editing the PIN clears them again
  useEffect(() => {
    if (phase !== 'pin') return;
    if (pin.length === 6) {
      if (socket.connected) void join(pin);
      else socket.once('connect', () => void join(pin));
    } else {
      setRoster([]);
      setError('');
    }
  }, [pin, phase, socket, join]);

  // physical keyboard: digits and backspace
  useEffect(() => {
    if (phase !== 'pin') return;
    const k = (e: KeyboardEvent) => {
      if (e.target instanceof HTMLInputElement) return;
      if (/^\d$/.test(e.key)) setPin((p) => (p + e.key).slice(0, 6));
      else if (e.key === 'Backspace') setPin((p) => p.slice(0, -1));
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [phase]);

  // reconnect after a network drop: join again with the same device and continue the round
  useEffect(() => {
    const re = () => { if (phase === 'in') void join(getPin()); };
    socket.on('connect', re);
    return () => { socket.off('connect', re); };
  }, [socket, phase, join]);

  // report tab visibility to the server (server uses its own clock)
  useEffect(() => {
    if (phase !== 'in') return;
    const send = (hidden: boolean) => socket.emit('client:visibility', { hidden });
    const vis = () => send(document.hidden);
    const blur = () => send(true);
    const focus = () => send(document.hidden);
    document.addEventListener('visibilitychange', vis);
    window.addEventListener('blur', blur);
    window.addEventListener('focus', focus);
    return () => {
      document.removeEventListener('visibilitychange', vis);
      window.removeEventListener('blur', blur);
      window.removeEventListener('focus', focus);
    };
  }, [socket, phase]);

  const pickName = async (studentId: string) => {
    setBusy(true);
    const res = await emitAck<{ message?: string }>(socket, 'room:pickName', { studentId });
    setBusy(false);
    if (res.ok) {
      setSidStore(studentId);
      setPhase('in');
    } else {
      setError(res.code === 'NAME_TAKEN' ? 'Nama ini sudah dipakai temanmu.' : res.code === 'REGISTRATION_CLOSED' ? 'Permainan sudah dimulai.' : res.code === 'ROOM_FULL' ? 'Ruangan penuh.' : (res.message ?? 'Tidak bisa memilih nama.'));
    }
  };

  if (view.kicked) return <Shell><Panel><h1>Kamu dikeluarkan</h1><p>Silakan temui gurumu.</p></Panel></Shell>;
  if (view.rejected && phase !== 'in') return <Shell><Panel className="narrow"><h1>Belum bisa masuk</h1><p>{view.rejected}</p></Panel></Shell>;

  return (
    <Shell>
      {phase === 'pin' && <Entry pin={pin} setPin={setPin} roster={roster} loading={busy && roster.length === 0} onPick={(id) => void pickName(id)} busy={busy} error={error} />}
      {phase === 'in' && <InGame socket={socket} view={view} />}
    </Shell>
  );
}

function Shell({ children }: { children: React.ReactNode }) {
  return (
    <main className="app player">
      <header className="topbar"><Logo small /><SoundToggle /></header>
      {children}
    </main>
  );
}

function Entry({ pin, setPin, roster, loading, onPick, busy, error }: { pin: string; setPin: (p: string) => void; roster: RosterItem[]; loading: boolean; onPick: (id: string) => void; busy: boolean; error: string }) {
  const [q, setQ] = useState('');
  const press = (d: string) => setPin((pin + d).slice(0, 6));
  const ready = roster.length > 0;
  const list = roster.filter((r) => r.name.toLowerCase().includes(q.toLowerCase()));
  const free = roster.filter((r) => !r.taken).length;
  return (
    <div className="entry2">
      <section className="ticket" aria-label="PIN ruangan">
        <p className="tk-label">Karcis masuk</p>
        <h1>Ketik PIN dari layar guru</h1>
        <div className={`pin-dots${ready ? ' ok' : ''}`} aria-label={`PIN ${pin.length} dari 6 angka`}>
          {Array.from({ length: 6 }, (_, i) => <span key={i} className={pin[i] ? 'on' : ''}>{pin[i] ?? ''}</span>)}
        </div>
        <div className="keypad">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => <button key={d} className="key" onClick={() => press(d)}>{d}</button>)}
          <button className="key alt" onClick={() => setPin('')} aria-label="Kosongkan PIN">C</button>
          <button className="key" onClick={() => press('0')}>0</button>
          <button className="key alt" onClick={() => setPin(pin.slice(0, -1))} aria-label="Hapus satu angka">⌫</button>
        </div>
        {error ? <p className="err" role="alert">{error}</p> : <p className="tk-foot">{ready ? 'Ruangan ditemukan. Pilih namamu di daftar hadir.' : `${pin.length} dari 6 angka`}</p>}
      </section>

      <section className="hadir" aria-live="polite">
        <header className="hadir-head">
          <p className="tk-label" style={{ marginBottom: 2 }}>Daftar hadir</p>
          <h2>{ready ? `${roster.length} siswa di kelas ini` : 'Menunggu PIN…'}</h2>
          {ready && <span>{free} nama masih bebas. Ketuk namamu sendiri.</span>}
        </header>
        {!ready && !loading && (
          <div className="hadir-empty">
            <b>Nama kelasmu muncul di sini.</b>
            Begitu angka PIN yang keenam masuk, seluruh daftar siswa tampil dan kamu tinggal mengetuk namamu.
          </div>
        )}
        {loading && Array.from({ length: 6 }, (_, i) => <div key={i} className="skel" />)}
        {ready && (
          <>
            {roster.length > 12 && <input className="field" style={{ marginBottom: 10 }} placeholder="Cari namamu…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Cari nama" />}
            <div className="hadir-grid">
              {list.map((r, i) => (
                <button key={r.studentId} className="nm-chip" style={{ ['--i' as string]: i }} disabled={r.taken || busy} onClick={() => onPick(r.studentId)}>
                  <Avatar name={r.name} size={34} />
                  <span><span className="nm">{r.name}</span>{r.taken && <small>sudah hadir</small>}</span>
                </button>
              ))}
              {list.length === 0 && <p className="muted">Tidak ada nama yang cocok dengan “{q}”.</p>}
            </div>
          </>
        )}
      </section>
    </div>
  );
}

function InGame({ socket, view }: { socket: ReturnType<typeof useGameSocket>['socket']; view: GameView }) {
  const st = view.state;
  const prevOk = useRef<string | null>(null);
  useEffect(() => {
    if (!view.lastFlash || prevOk.current === `${view.lastFlash.cardId}${view.lastFlash.at}`) return;
    prevOk.current = `${view.lastFlash.cardId}${view.lastFlash.at}`;
    beep(view.lastFlash.correct ? 'ok' : 'bad');
    if (!view.lastFlash.correct) navigator.vibrate?.(120);
  }, [view.lastFlash]);

  // write this game into the local profile once, when the final board arrives
  const savedGame = useRef(false);
  useEffect(() => {
    if (!view.gameEnd || savedGame.current || view.dq || !st?.you) return;
    savedGame.current = true;
    const mine = view.gameEnd.finalBoard.find((r) => r.playerId === st.you!.playerId);
    recordGame({ name: st.you.name, score: mine?.score ?? 0, rank: mine?.rank ?? null, correct: view.tally.correct, wrong: view.tally.wrong });
  }, [view.gameEnd, view.dq, view.tally, st]);

  if (view.dq) {
    return (
      <Panel className="narrow center dq-screen">
        <div className="crack-big" aria-hidden />
        <h1>Kamu didiskualifikasi</h1>
        <p>{view.dq.message}</p>
        <button className="btn" onClick={() => { socket.disconnect(); window.location.hash = '#/'; }}>Keluar</button>
      </Panel>
    );
  }
  if (!st) return <Panel className="narrow center"><p>Menyambungkan…</p></Panel>;
  const me = st.you;

  const header = (
    <div className="hud">
      <a className="who" href="#/profil" title="Profilku">{me && <Avatar name={me.name} size={30} />}<span><b>{me?.name ?? ''}</b><small>{rankOf(loadProfile()?.claims ?? 0).title}</small></span></a>
      <span className="chip score">Skor <b>{(view.score || 0).toLocaleString('id-ID')}</b></span>
      {!view.connected && <span className="chip warn">Menyambung ulang…</span>}
    </div>
  );

  if (view.gameEnd) {
    return (
      <div className="stack wide-lb">
        {header}
        <Leaderboard rows={view.gameEnd.finalBoard} meId={me?.playerId} variant="phone" title="Papan peringkat" />
        <p className="lb-foot"><a className="btn ghost sm" href="#/profil">Lihat profilku</a></p>
      </div>
    );
  }
  if (view.roundEnd) {
    const r = view.roundEnd;
    const mine = r.roundScores.find((x) => x.playerId === me?.playerId);
    return (
      <div className="stack wide-lb">
        {header}
        <Leaderboard rows={rowsFromRound(r, view.prevRank)} meId={me?.playerId} variant="phone" interim kicker={`Peringkat sementara · kotak ${r.roundNo} dari ${r.rounds}`} title="Papan peringkat sementara" />
        <Panel title={`Kotak ${r.roundNo}: ${r.category.name}`}>
          <p className="big-note">{mine ? `Skor kotakmu ${mine.roundScore.toLocaleString('id-ID')} · peringkat ${mine.rank}` : 'Kotak selesai.'}</p>
          <p className="trick"><b>Trik singkat:</b> {r.trick}</p>
          <h3 className="sub">Kartu yang paling sering salah</h3>
          <div className="expl">
            {r.explanations.map((e) => (
              <div key={e.cardId} className="ex-row">
                <span className="expr" dangerouslySetInnerHTML={{ __html: e.svg }} />
                <p>{e.explanation}</p>
              </div>
            ))}
          </div>
        </Panel>
      </div>
    );
  }
  if (st.status === 'LOBBY' || st.status === 'CREATED') {
    return (
      <div className="stack">
        {header}
        <Panel title="Menunggu guru memulai…" className="center">
          <p className="muted">{st.players.length} teman sudah masuk</p>
          <ul className="friends">{st.players.map((p) => <li key={p.playerId} className={p.online ? '' : 'off'}>{p.name}</li>)}</ul>
        </Panel>
      </div>
    );
  }

  if (st.status === 'SPIN' || (st.status === 'PAUSED' && st.prevStatus === 'SPIN')) {
    return (
      <div className="stack">
        {header}
        <Panel title="Roda pemilih kategori" className="center">
          <Wheel segments={view.wheel} pickedId={view.spin?.pickedPlayerId} animMs={view.spin?.animMs ?? 5000} size={260} />
          <p className="muted">{view.spin ? 'Siapa yang terpilih?' : 'Roda berputar…'}</p>
        </Panel>
      </div>
    );
  }

  if (st.status === 'PICK') {
    const mePicker = st.pickerId === me?.playerId && view.options;
    return (
      <div className="stack">
        {header}
        {mePicker ? <CategoryPicker socket={socket} view={view} /> : (
          <Panel className="center" title="Pemilih kategori">
            <p className="who-pick">{st.pickerName}</p>
            <p className="muted">sedang memilih kategori…</p>
          </Panel>
        )}
      </div>
    );
  }

  if (st.status === 'COUNTDOWN' && view.countdown) {
    return (
      <div className="stack">
        {header}
        <Panel className="center">
          <p className="muted">Kategori ronde ini</p>
          <h1 className="cat-name">{view.countdown.category.name}</h1>
          <Countdown startsAt={view.countdown.startsAt} />
        </Panel>
      </div>
    );
  }

  if ((st.status === 'RUNNING' || st.status === 'PAUSED') && view.round) {
    return (
      <div className="stack play">
        {header}
        <div className="round-bar">
          <div><small>Kotak {view.round.roundNo}/{view.round.rounds}{view.round.numbersTotal ? ' · ' + view.round.numbersTotal + ' angka' : ''}</small><b className="cat-pill">{view.round.category.name}</b></div>
          <Timer endsAt={view.round.endsAt + (st.pausedAt ? 0 : 0)} />
        </div>
        {st.status === 'PAUSED' && <div className="pause-note">Permainan dijeda oleh guru</div>}
        <ClaimMeter progress={view.progress} />
        <p className="hint">Tekan kartu yang hasilnya memenuhi kategori. Jawaban benar pertama mengklaim kartunya, yang lain tidak bisa menekannya lagi.</p>
        <Toast toast={view.toast} />
        <Board cards={view.cards} results={view.results} claims={view.claims} flash={view.lastFlash} cooldownUntil={view.cooldownUntil} disabled={st.status === 'PAUSED'} onPick={(id) => socket.emit('card:answer', { cardId: id, hidden: document.hidden })} />
      </div>
    );
  }

  return <Panel className="narrow center"><p>Tunggu sebentar…</p></Panel>;
}

function CategoryPicker({ socket, view }: { socket: ReturnType<typeof useGameSocket>['socket']; view: GameView }) {
  const o = view.options!;
  const left = useSecondsLeft(o.expiresAt);
  return (
    <Panel title="Kamu terpilih! Pilih satu kategori" className="wide">
      <p className="muted">Sisa waktu {left} detik. Kalau terlambat, kategori dipilih acak.</p>
      <div className="cats">
        {o.categories.map((c, i) => (
          <button key={c.id} className="cat" style={{ ['--i' as string]: i }} onClick={() => socket.emit('category:pick', { categoryId: c.id })}>
            <span className="cat-no">{i + 1}</span>
            {c.name}
          </button>
        ))}
      </div>
    </Panel>
  );
}

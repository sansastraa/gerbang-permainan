import { useState } from 'react';
import { clearProfile, loadProfile, RANKS, rankOf } from './lib';
import { Avatar, Logo } from './ui';

export default function Profile() {
  const [p, setP] = useState(loadProfile());
  const tries = p ? p.claims + p.wrong : 0;
  const acc = tries ? Math.round((p!.claims / tries) * 100) : 0;
  const rank = rankOf(p?.claims ?? 0);
  return (
    <main className="app profil">
      <header className="topbar"><a href="#/" className="back" aria-label="Kembali ke beranda"><Logo small /></a><a className="btn ghost sm" href="#/">Beranda</a></header>

      {!p ? (
        <section className="profil-empty">
          <p className="kicker">Profilku</p>
          <h1>Belum ada permainan di perangkat ini.</h1>
          <p>Mainkan satu ronde. Setelah permainan selesai, pangkat, skor terbaik, dan jumlah kartu yang kamu klaim tercatat di sini.</p>
          <a className="btn" href="#/play">Aku siswa, mulai main</a>
        </section>
      ) : (
        <section className="profil-grid">
          <div className="id-card">
            <Avatar name={p.name} size={112} />
            <h1>{p.name}</h1>
            <p className="rank-title">{rank.title}</p>
            <div className="rank-bar" aria-label={`Menuju pangkat berikutnya ${rank.pct}%`}><i style={{ width: `${rank.pct}%` }} /></div>
            <p className="muted small">{rank.next ? `${rank.toNext} kartu lagi menuju ${rank.next.title}` : 'Pangkat tertinggi.'}</p>
          </div>

          <dl className="stats">
            <div><dt>Permainan</dt><dd>{p.games}</dd></div>
            <div><dt>Skor terbaik</dt><dd>{p.best.toLocaleString('id-ID')}</dd></div>
            <div className="hot"><dt>Kartu diklaim</dt><dd>{p.claims}</dd></div>
            <div><dt>Ketepatan</dt><dd>{acc}<small>%</small></dd></div>
            <div><dt>Juara 1</dt><dd>{p.wins}</dd></div>
            <div><dt>Masuk podium</dt><dd>{p.podiums}</dd></div>
          </dl>

          <ol className="ladder" aria-label="Tangga pangkat">
            {RANKS.map((r, i) => (
              <li key={r.title} className={i < rank.index ? 'done' : i === rank.index ? 'now' : ''}>
                <span>{r.title}</span><em>{r.min}+ kartu</em>
              </li>
            ))}
          </ol>

          <p className="muted small keep">Data ini hanya tersimpan di perangkat ini, tidak dikirim ke server.{' '}
            <button className="link" onClick={() => window.confirm('Hapus profil di perangkat ini?') && (clearProfile(), setP(null))}>Hapus profil</button>
          </p>
        </section>
      )}
    </main>
  );
}

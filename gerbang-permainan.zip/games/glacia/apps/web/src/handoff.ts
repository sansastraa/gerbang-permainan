/**
 * SIMPETERI "Buat Multi Permainan" handoff, teacher side (the same pattern CLAIM 80 uses):
 * SIMPETERI opens this app's /host in a new tab; we tell the opener `glacia:host-ready`; it answers with
 * `glacia:roster` carrying the class list (ids are siswa.id), the teacher PIN and the URL to return to.
 * The PIN travels only in this message, never in a URL. See docs/SIMPETERI_INTEGRASI.md.
 */
export const READY_MESSAGE = 'glacia:host-ready';
export const ROSTER_MESSAGE = 'glacia:roster';

export interface Handoff {
  kelas: string;
  roster: { id: string; name: string; absen?: number }[];
  pin: string;
  /** SIMPETERI's Multi Permainan page; empty when it was missing or not on the sender's origin */
  kembali: string;
  multiSesi: string;
}

const KEY = 'glacia.handoff';

export function loadHandoff(): Handoff | null {
  try {
    const raw = sessionStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Handoff) : null;
  } catch {
    return null;
  }
}
export function saveHandoff(h: Handoff | null): void {
  try {
    if (h) sessionStorage.setItem(KEY, JSON.stringify(h));
    else sessionStorage.removeItem(KEY);
  } catch {
    /* storage blocked: the handoff lives only in memory for this tab */
  }
}

/** Validates the untrusted message. `origin` is the sender's origin as reported by the browser. */
export function parseRosterMessage(data: unknown, origin: string): Handoff | null {
  const d = data as { type?: unknown; kelas?: unknown; roster?: unknown; pin?: unknown; kembali?: unknown; multiSesi?: unknown } | null;
  if (!d || d.type !== ROSTER_MESSAGE) return null;
  if (typeof d.pin !== 'string' || !/^\S{4,32}$/.test(d.pin)) return null;
  if (!Array.isArray(d.roster) || d.roster.length === 0 || d.roster.length > 100) return null;
  const roster: Handoff['roster'] = [];
  const seen = new Set<string>();
  for (const r of d.roster as { id?: unknown; name?: unknown; absen?: unknown }[]) {
    if (typeof r?.id !== 'string' || typeof r?.name !== 'string' || !r.id.trim() || !r.name.trim() || seen.has(r.id)) return null;
    seen.add(r.id);
    roster.push({ id: r.id, name: r.name.trim().slice(0, 80), ...(typeof r.absen === 'number' ? { absen: r.absen } : {}) });
  }
  let kembali = '';
  if (typeof d.kembali === 'string') {
    try {
      const u = new URL(d.kembali);
      if (u.origin === origin) kembali = u.toString(); // only ever return to the page that sent us here
    } catch {
      /* ignore a malformed URL */
    }
  }
  return { kelas: typeof d.kelas === 'string' && d.kelas.trim() ? d.kelas.trim().slice(0, 60) : 'Kelas', roster, pin: d.pin, kembali, multiSesi: typeof d.multiSesi === 'string' ? d.multiSesi.slice(0, 64) : '' };
}

/** `{kembali}&selesai=1&gameSesi=<room id>`: what SIMPETERI's Multi Permainan reads to pull the results. */
export function returnUrl(h: Handoff | null, roomId: string): string | null {
  if (!h?.kembali) return null;
  try {
    const u = new URL(h.kembali);
    u.searchParams.set('selesai', '1');
    u.searchParams.set('gameSesi', roomId);
    return u.toString();
  } catch {
    return null;
  }
}

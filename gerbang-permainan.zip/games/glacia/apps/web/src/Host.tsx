import { useCallback, useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { api, apiUrl, emitAck, BASE_PATH, store, useGameSocket, useNow, type FlagMsg, type RoomState } from './lib';
import { Avatar, Logo, Panel, SoundToggle, TopList } from './ui';
import { Leaderboard, type BoardRow } from './Leaderboard';
import { pageUrlFor } from './urls';
import { loadHandoff, parseRosterMessage, returnUrl, saveHandoff, type Handoff } from './handoff';

const [getJwt, setJwt] = store<string | null>('glacia.jwt', null);
const [getRoom, setRoomStore] = store<string | null>('glacia.hostRoom', null);

interface Cat { id: number; name: string; trick?: string }
interface BlRow { studentId: string; studentName: string; classId: string; reason: string; createdAt: number; liftedAt: number | null; evidence: { flags?: { type: string; at: number; detail: { hiddenMs?: number } }[]; lastAnswers?: unknown[]; streak?: number } }

type Tab = 'room' | 'results' | 'blacklist' | 'diag';
const TABS: [Tab, string][] = [['room', 'Permainan'], ['results', 'Hasil'], ['blacklist', 'Daftar hitam'], ['diag', 'Diagnostik']];

export default function Host() {
  const [jwt, setJwtState] = useState<string | null>(getJwt());
  const [roomId, setRoomId] = useState<string | null>(getRoom());
  const [tab, setTab] = useState<Tab>('room');
  const [cfg, setCfg] = useState<{ mode: 'multi' | 'mandiri'; simpeteriOrigins: string[] } | null>(null);
  const [handoff, setHandoff] = useState<Handoff | null>(loadHandoff());

  const login = (j: string) => { setJwt(j); setJwtState(j); };
  const logout = () => { setJwt(null); setJwtState(null); setRoomStore(null); setRoomId(null); saveHandoff(null); setHandoff(null); };
  const openRoom = (id: string) => { setRoomStore(id); setRoomId(id); setTab('room'); };

  useEffect(() => {
    void api<{ mode: 'multi' | 'mandiri'; simpeteriOrigins: string[] }>('/config', null).then((r) => { if (r.ok) setCfg({ mode: r.mode, simpeteriOrigins: r.simpeteriOrigins }); });
  }, []);

  // Behind SIMPETERI's Multi Permainan: announce ourselves to the opener, then accept the roster + PIN (origin-checked) and sign in with that PIN.
  useEffect(() => {
    if (cfg?.mode !== 'multi') return;
    const onMessage = (e: MessageEvent) => {
      if (!window.opener || e.source !== window.opener) return;
      if (cfg.simpeteriOrigins.length > 0 && !cfg.simpeteriOrigins.includes(e.origin)) return;
      const h = parseRosterMessage(e.data, e.origin);
      if (!h) return;
      saveHandoff(h);
      setHandoff(h);
      void api<{ jwt: string }>('/auth/host', null, { method: 'POST', body: { token: h.pin } }).then((r) => { if (r.ok) login(r.jwt); });
    };
    window.addEventListener('message', onMessage);
    window.opener?.postMessage({ type: 'glacia:host-ready' }, '*');
    return () => window.removeEventListener('message', onMessage);
  }, [cfg]);

  if (!jwt) return <Shell>{cfg?.mode === 'multi' && !handoff ? <WaitSimpeteri /> : <Login onLogin={login} />}</Shell>;
  return (
    <Shell tab={tab} setTab={setTab} onLogout={logout}>
      {tab === 'blacklist' && <Blacklist jwt={jwt} />}
      {tab === 'results' && <Results jwt={jwt} onOpen={openRoom} />}
      {tab === 'diag' && <Diagnostics jwt={jwt} onOpen={openRoom} />}
      {tab === 'room' && (roomId ? <Control jwt={jwt} roomId={roomId} onClose={() => { setRoomStore(null); setRoomId(null); }} /> : <Create jwt={jwt} onCreated={openRoom} handoff={handoff} />)}
    </Shell>
  );
}

function Shell({ children, tab, setTab, onLogout }: { children: React.ReactNode; tab?: Tab; setTab?: (t: Tab) => void; onLogout?: () => void }) {
  return (
    <main className="app host">
      <header className="hostbar">
        <a href="#/" className="back" aria-label="Beranda"><Logo small /></a>
        {tab && setTab && (
          <nav className="tabs" role="tablist" aria-label="Menu guru">
            {TABS.map(([k, label]) => (
              <button key={k} role="tab" aria-selected={tab === k} className={tab === k ? 'on' : ''} onClick={() => setTab(k)}>{label}</button>
            ))}
          </nav>
        )}
        <div className="hb-right">
          <SoundToggle />
          {onLogout && <button className="logout" onClick={() => window.confirm('Keluar dari akun guru di perangkat ini?') && onLogout()}>Keluar</button>}
        </div>
      </header>
      {children}
    </main>
  );
}

/** Shown when the server runs behind SIMPETERI and nobody has sent the class list yet. */
function WaitSimpeteri() {
  return (
    <div className="login">
      <section className="login-copy">
        <p className="kicker">Multi Permainan SIMPETERI</p>
        <h1>Buka GLACIA dari <em>SIMPETERI</em>.</h1>
        <ul>
          <li><b>1</b><span>Di SIMPETERI buka menu <b style={{ all: 'unset', fontWeight: 700 }}>Multi Permainan</b>, pilih sesi dan kelas.</span></li>
          <li><b>2</b><span>Isi alamat server ini dan PIN guru, lalu tekan tombol untuk membuka konsol GLACIA.</span></li>
          <li><b>3</b><span>Daftar siswa kelas itu dikirim otomatis ke halaman ini. Setelah selesai, hasilnya diambil kembali ke SIMPETERI.</span></li>
        </ul>
      </section>
      <div className="login-card">
        <h2>Menunggu daftar siswa…</h2>
        <p className="muted">Halaman ini harus dibuka dari tombol di SIMPETERI supaya daftar siswa dan PIN ikut terkirim. PIN tidak pernah ditulis di alamat.</p>
        <div className="skel" />
      </div>
    </div>
  );
}

function Login({ onLogin }: { onLogin: (jwt: string) => void }) {
  const [token, setToken] = useState('');
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);
  const go = async (t: string) => {
    if (!t.trim()) { setErr('Isi PIN guru dulu.'); return; }
    setBusy(true);
    setErr('');
    const r = await api<{ jwt: string }>('/auth/host', null, { method: 'POST', body: { token: t.trim() } });
    setBusy(false);
    if (r.ok) onLogin(r.jwt);
    else if (r.code === 'RATE_LIMITED') setErr('Terlalu banyak percobaan. Tunggu semenit lalu coba lagi.');
    else setErr('PIN itu tidak cocok. Tanyakan PIN guru yang benar kepada pengelola server.');
  };
  return (
    <div className="login">
      <section className="login-copy">
        <p className="kicker">Ruang guru</p>
        <h1>Buka ruangan, bagikan PIN, lalu <em>mulai</em>.</h1>
        <ul>
          <li><b>1</b><span>Tempel nama siswa kelasmu, atur ronde dan waktu sesukamu.</span></li>
          <li><b>2</b><span>Siswa masuk dengan PIN ruangan, daftar kelas langsung muncul di layar mereka.</span></li>
          <li><b>3</b><span>Pantau kecurangan langsung, akhiri ronde atau permainan kapan saja.</span></li>
        </ul>
      </section>
      <form className="login-card" onSubmit={(e) => { e.preventDefault(); void go(token); }}>
        <h2>Masuk sebagai guru</h2>
        <label className="fld">
          <span>PIN guru</span>
          <input type="password" autoComplete="current-password" value={token} onChange={(e) => setToken(e.target.value)} placeholder="PIN dari pengelola server" aria-invalid={!!err} />
          <em>PIN ini berbeda dari PIN ruangan. Ditetapkan oleh pengelola server (HOST_PIN).</em>
        </label>
        {err && <p className="login-err" role="alert">{err}</p>}
        <button className="btn" disabled={busy}>{busy ? 'Memeriksa…' : 'Masuk'}</button>
      </form>
    </div>
  );
}

const ROSTER_KEY = 'glacia.rosters';
const slug = (s: string) => s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'siswa';

/** One name per line (pasted from Excel or an attendance list). Numbering is stripped; the id comes from the name so the same student keeps one id (and one blacklist entry) across rooms. */
export function parseNames(text: string): { id: string; name: string }[] {
  const seen = new Map<string, number>();
  const out: { id: string; name: string }[] = [];
  for (const raw of text.split(/\r?\n/)) {
    const name = raw.replace(/^\s*\d+\s*[.)\t-]\s*/, '').replace(/\s+/g, ' ').trim().slice(0, 80);
    if (!name) continue;
    const base = slug(name);
    const n = (seen.get(base) ?? 0) + 1;
    seen.set(base, n);
    out.push({ id: n === 1 ? `n-${base}` : `n-${base}-${n}`, name: n === 1 ? name : `${name} (${n})` });
    if (out.length >= 100) break;
  }
  return out;
}
const loadRosters = (): Record<string, string> => { try { return JSON.parse(localStorage.getItem(ROSTER_KEY) ?? '{}') as Record<string, string>; } catch { return {}; } };
function saveRoster(kelas: string, names: string): Record<string, string> {
  const all = { ...loadRosters(), [kelas]: names };
  try { localStorage.setItem(ROSTER_KEY, JSON.stringify(all)); } catch { /* storage blocked: the list is just not remembered */ }
  return all;
}

/** Free-typing numeric field: keeps the raw text, validates a range, never a dropdown. */
function NumField({ label, value, set, min, max, hint, unit }: { label: string; value: string; set: (v: string) => void; min: number; max: number; hint: string; unit?: string }) {
  const n = Number(value);
  const bad = value.trim() === '' || !Number.isInteger(n) || n < min || n > max;
  return (
    <label className={`fld${bad ? ' bad' : ''}`}>
      <span>{label}</span>
      <div className="unit">
        <input type="text" inputMode="numeric" value={value} onChange={(e) => set(e.target.value.replace(/[^\d]/g, ''))} aria-invalid={bad} />
        {unit && <b>{unit}</b>}
      </div>
      <em>{bad ? `Isi angka ${min} sampai ${max}` : hint}</em>
    </label>
  );
}

function Switch({ checked, set, title, note }: { checked: boolean; set: (v: boolean) => void; title: string; note: string }) {
  return (
    <label className="sw">
      <input type="checkbox" checked={checked} onChange={(e) => set(e.target.checked)} />
      <span className="knob" aria-hidden />
      <b>{title}</b>
      <small>{note}</small>
    </label>
  );
}

/** Pick which of the 15 categories may come up. Tiles show the trick students will learn, so the teacher knows what each round teaches. */
function CategoryPicker({ cats, allowed, set }: { cats: Cat[]; allowed: number[]; set: (ids: number[]) => void }) {
  const [q, setQ] = useState('');
  const on = new Set(allowed);
  const toggle = (id: number) => set(on.has(id) ? allowed.filter((x) => x !== id) : [...allowed, id].sort((a, b) => a - b));
  const shown = cats.filter((c) => `${c.name} ${c.trick ?? ''}`.toLowerCase().includes(q.trim().toLowerCase()));
  const groups: { label: string; ids: number[] }[] = [
    { label: 'Satuan', ids: cats.filter((c) => /satuan/i.test(c.name)).map((c) => c.id) },
    { label: 'Kelipatan', ids: cats.filter((c) => /kelipatan/i.test(c.name)).map((c) => c.id) },
    { label: 'Ganjil / genap', ids: cats.filter((c) => /ganjil|genap/i.test(c.name)).map((c) => c.id) },
  ].filter((g) => g.ids.length > 0);
  const shuffle5 = () => set([...cats].sort(() => Math.random() - 0.5).slice(0, 5).map((c) => c.id).sort((a, b) => a - b));
  const need = Math.max(0, 1 - allowed.length);
  return (
    <div className="cat-picker">
      <div className="cat-tools">
        <input className="cat-search" type="text" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari kategori atau triknya…" aria-label="Cari kategori" />
        <div className="cat-presets" role="group" aria-label="Pilih cepat">
          <button type="button" onClick={() => set(cats.map((c) => c.id))}>Semua</button>
          <button type="button" onClick={() => set([])}>Kosongkan</button>
          <button type="button" onClick={shuffle5}>Acak 5</button>
          {groups.map((g) => <button key={g.label} type="button" onClick={() => set(g.ids)}>Hanya {g.label}</button>)}
        </div>
      </div>
      <div className="cat-meter" role="status">
        <div className="cat-bar"><i style={{ width: `${cats.length ? (allowed.length / cats.length) * 100 : 0}%` }} /></div>
        <span><b>{allowed.length}</b> dari {cats.length} dipilih{need > 0 ? <em> · pilih minimal 1 kategori</em> : null}</span>
      </div>
      <div className="cat-grid">
        {shown.map((c) => {
          const sel = on.has(c.id);
          return (
            <button key={c.id} type="button" className={`cat-tile${sel ? ' sel' : ''}`} aria-pressed={sel} onClick={() => toggle(c.id)}>
              <span className="ct-no">{String(c.id).padStart(2, '0')}</span>
              <span className="ct-box" aria-hidden>{sel ? '✓' : ''}</span>
              <b>{c.name}</b>
              {c.trick && <small>{c.trick}</small>}
            </button>
          );
        })}
        {shown.length === 0 && <p className="muted">Tidak ada kategori yang cocok dengan “{q}”.</p>}
      </div>
    </div>
  );
}

function Create({ jwt, onCreated, handoff }: { jwt: string; onCreated: (id: string) => void; handoff: Handoff | null }) {
  const [cats, setCats] = useState<Cat[]>([]);
  const [classId, setClassId] = useState(handoff?.kelas ?? '');
  const [names, setNames] = useState('');
  const [saved, setSaved] = useState<Record<string, string>>(() => loadRosters());
  const roster = useMemo(() => parseNames(names), [names]);
  const [rounds, setRounds] = useState('5');
  const [secs, setSecs] = useState('120');
  const [pickSecs, setPickSecs] = useState('15');
  const [maxPlayers, setMaxPlayers] = useState('40');
  const [penalty, setPenalty] = useState('250');
  const [cooldown, setCooldown] = useState('2');
  const [streak, setStreak] = useState('4');
  const [mode, setMode] = useState<'NAME' | 'INITIALS' | 'COUNT_ONLY'>('NAME');
  const [claim, setClaim] = useState(true);
  const [refresh, setRefresh] = useState(true);
  const [autoDq, setAutoDq] = useState(true);
  const [autoBl, setAutoBl] = useState(true);
  const [allowed, setAllowed] = useState<number[]>([]);
  const [issues, setIssues] = useState<string[]>([]);
  useEffect(() => {
    void api<{ categories: Cat[] }>('/categories', jwt).then((r) => { if (r.ok) { setCats(r.categories); setAllowed(r.categories.map((c) => c.id)); } });
  }, [jwt]);

  const inRange = (v: string, a: number, b: number) => v.trim() !== '' && Number.isInteger(Number(v)) && Number(v) >= a && Number(v) <= b;
  const valid = classId.trim() !== '' && (!!handoff || roster.length >= 1) && allowed.length >= 1 && inRange(rounds, 1, 10) && inRange(secs, 20, 900) && inRange(pickSecs, 5, 60) && inRange(maxPlayers, 2, 100) && inRange(penalty, 0, 2000) && inRange(cooldown, 0, 10) && inRange(streak, 4, 5);

  const create = async () => {
    setIssues([]);
    const r = await api<{ roomId: string; issues?: { path: (string | number)[]; message: string }[] }>('/rooms', jwt, {
      method: 'POST',
      body: {
        classId: classId.trim(), roster: handoff ? handoff.roster : roster, rounds: +rounds, roundSeconds: +secs, categoryPickSeconds: +pickSecs, maxPlayers: +maxPlayers,
        wrongPenalty: +penalty, wrongCooldownMs: +cooldown * 1000, cheatStreakThreshold: +streak, showDisqualifiedOnDisplay: mode,
        claimMode: claim, boardRefreshOddRounds: refresh, autoDisqualify: autoDq, autoBlacklist: autoBl, allowedCategoryIds: allowed,
      },
    });
    if (r.ok) {
      if (!handoff) setSaved(saveRoster(classId.trim(), names));
      onCreated(r.roomId);
    }
    else if (r.code === 'BAD_ROSTER' || r.code === 'ROSTER_REQUIRED') setIssues(['Daftar siswa belum sah. Isi sedikitnya satu nama.']);
    else if (r.code === 'EMPTY_CLASS') setIssues(['Kelas itu belum punya daftar siswa.']);
    else if (r.code === 'BAD_SETTINGS') setIssues((r.issues ?? []).map((i) => `${i.path.join('.')}: ${i.message}`));
    else setIssues([`Gagal membuat ruangan (${r.code ?? 'tidak diketahui'}).`]);
  };

  return (
    <div className="sheet">
      <header className="sheet-head">
        <p className="kicker">Ruang guru</p>
        <h1>Buka ruangan baru</h1>
        <p>Semua kolom diisi sendiri, tidak ada pilihan yang dibatasi dropdown. Angka yang di luar batas ditandai merah sebelum ruangan dibuat.</p>
      </header>

      <section className="sheet-sec">
        <h2>Kelas dan irama permainan</h2>
        <div className="fields">
          {handoff ? (
            <div className="fld wide">
              <span>Kelas dari SIMPETERI</span>
              <input type="text" value={classId} disabled />
              <em>{handoff.roster.length} siswa dikirim dari menu Multi Permainan SIMPETERI.</em>
            </div>
          ) : (
            <>
              <label className="fld wide">
                <span>Nama kelas</span>
                <input type="text" value={classId} onChange={(e) => setClassId(e.target.value)} placeholder="mis. 6A" maxLength={60} />
                {Object.keys(saved).length > 0 && (
                  <div className="suggest">
                    {Object.keys(saved).map((k) => <button key={k} type="button" onClick={() => { setClassId(k); setNames(saved[k] ?? ''); }}>Pakai daftar {k}</button>)}
                  </div>
                )}
              </label>
              <label className={`fld wide${names.trim() !== '' && roster.length === 0 ? ' bad' : ''}`}>
                <span>Daftar siswa</span>
                <textarea className="roster-box" value={names} onChange={(e) => setNames(e.target.value)} rows={7} placeholder={'Satu nama per baris.\nBoleh tempel langsung dari Excel atau absen.'} spellCheck={false} />
                <em>{roster.length === 0 ? 'Belum ada nama.' : `${roster.length} siswa terbaca${names.split(/\r?\n/).filter((l) => l.trim()).length > 100 ? ' (maksimal 100, sisanya diabaikan)' : ''}. Nomor urut di depan nama dibuang otomatis; nama yang sama diberi (2), (3).`}</em>
              </label>
            </>
          )}
          <NumField label="Jumlah ronde" value={rounds} set={setRounds} min={1} max={10} hint="1 sampai 10 ronde" />
          <NumField label="Waktu tiap ronde" value={secs} set={setSecs} min={20} max={900} unit="detik" hint="Standar 120 detik" />
          <NumField label="Waktu memilih kategori" value={pickSecs} set={setPickSecs} min={5} max={60} unit="detik" hint="Lewat waktu, dipilih acak" />
          <NumField label="Maksimal pemain" value={maxPlayers} set={setMaxPlayers} min={2} max={100} hint="Diuji sampai 100" />
        </div>
      </section>

      <section className="sheet-sec">
        <h2>Skor dan hukuman</h2>
        <div className="fields">
          <NumField label="Poin dikurangi saat salah" value={penalty} set={setPenalty} min={0} max={2000} unit="poin" hint="Standar 250" />
          <NumField label="Kartu terkunci setelah salah" value={cooldown} set={setCooldown} min={0} max={10} unit="detik" hint="Standar 2 detik" />
        </div>
        <div className="switches" style={{ marginTop: 14 }}>
          <Switch checked={claim} set={setClaim} title="Mode klaim" note="Jawaban benar pertama mengambil kartu. Teman tidak bisa menekannya lagi." />
          <Switch checked={refresh} set={setRefresh} title="Papan berganti di tengah ronde" note="Berlaku ronde 1, 3, 5. Kartu yang sudah dijawab tidak diganti." />
        </div>
      </section>

      <section className="sheet-sec">
        <h2>Anti-curang</h2>
        <div className="fields">
          <NumField label="Diskualifikasi setelah benar beruntun" value={streak} set={setStreak} min={4} max={5} unit="kali" hint="Dihitung sesudah siswa pindah tab" />
          <div className="fld">
            <span>Nama di layar proyektor</span>
            <div className="seg" role="radiogroup" aria-label="Nama di layar proyektor">
              {([['NAME', 'Lengkap'], ['INITIALS', 'Inisial'], ['COUNT_ONLY', 'Jumlah saja']] as const).map(([v, l]) => (
                <label key={v}><input type="radio" name="mode" checked={mode === v} onChange={() => setMode(v)} /><span>{l}</span></label>
              ))}
            </div>
            <em>Untuk siswa yang didiskualifikasi</em>
          </div>
        </div>
        <div className="switches" style={{ marginTop: 14 }}>
          <Switch checked={autoDq} set={setAutoDq} title="Diskualifikasi otomatis" note="Pindah tab lalu menjawab benar beruntun." />
          <Switch checked={autoBl} set={setAutoBl} title="Masukkan ke daftar hitam" note="Berlaku di semua ruangan sampai guru mencabutnya." />
        </div>
      </section>

      <section className="sheet-sec">
        <h2>Kategori yang boleh muncul</h2>
        <CategoryPicker cats={cats} allowed={allowed} set={setAllowed} />
      </section>

<div className="sheet-actions">
        <button className="btn" disabled={!valid} onClick={() => void create()}>Buka ruangan</button>
        {!valid && <span className="muted small">Lengkapi kolom yang bertanda merah dulu.</span>}
        {issues.map((i) => <span key={i} className="issues">{i}</span>)}
      </div>
    </div>
  );
}

function Control({ jwt, roomId, onClose }: { jwt: string; roomId: string; onClose: () => void }) {
  const { socket, view } = useGameSocket();
  const [auth, setAuth] = useState<boolean | null>(null);
  const [exportKey, setExportKey] = useState('');
  const back = returnUrl(loadHandoff(), roomId);
  const [qr, setQr] = useState('');
  const [msg, setMsg] = useState('');
  const [initialFlags, setInitialFlags] = useState<FlagMsg[]>([]);
  const now = useNow(500);

  useEffect(() => {
    const login = () => {
      void emitAck<{ exportKey: string; flags: { playerId: string; name: string; type: string; detail: Record<string, unknown>; at: number }[] }>(socket, 'host:auth', { token: jwt, roomId }).then((r) => {
        setAuth(r.ok);
        if (r.ok) { setExportKey(r.exportKey); setInitialFlags(r.flags as FlagMsg[]); }
      });
    };
    socket.on('connect', login);
    if (socket.connected) login();
    return () => { socket.off('connect', login); };
  }, [socket, jwt, roomId]);

  const st: RoomState | null = view.state;
  const joinUrl = st ? pageUrlFor(window.location.origin, BASE_PATH, `/play?pin=${st.pin}`) : '';
  useEffect(() => {
    if (joinUrl) void QRCode.toDataURL(joinUrl, { margin: 1, width: 220, color: { dark: '#0d1b24', light: '#ffffff' } }).then(setQr);
  }, [joinUrl]);

  const act = async (event: string, payload: unknown = {}) => {
    const r = await emitAck(socket, event, payload);
    setMsg(r.ok ? '' : r.code === 'NOT_ENOUGH_PLAYERS' ? 'Butuh minimal 2 pemain online.' : `Tidak bisa: ${r.code}`);
  };
  const rest = async (path: string, body?: unknown) => {
    const r = await api(path, jwt, { method: 'POST', body });
    setMsg(r.ok ? 'Berhasil.' : `Gagal: ${r.code ?? ''}`);
  };

  if (auth === false) return <Panel className="narrow"><p>Ruangan tidak ditemukan atau sesi habis.</p><button className="btn" onClick={onClose}>Kembali</button></Panel>;
  if (!st) return <Panel className="narrow center"><p>Menyambungkan…</p></Panel>;

  const flags = [...initialFlags, ...view.flags].filter((f, i, a) => a.findIndex((x) => x.at === f.at && x.playerId === f.playerId && x.type === f.type) === i).slice(-30).reverse();
  const online = st.players.filter((p) => p.online && !p.disqualified);
  const dq = st.players.filter((p) => p.disqualified);
  const status = st.status;
  const displayUrl = pageUrlFor(window.location.origin, BASE_PATH, `/display/${st.pin}`);

  return (
    <div className="host-grid">
      <Panel className="join-card">
        <p className="muted">PIN ruangan</p>
        <div className="pin-big">{st.pin}</div>
        {qr && <img className="qr" src={qr} alt={`Kode QR untuk bergabung dengan PIN ${st.pin}`} width={150} height={150} />}
        <a className="btn ghost sm" href={displayUrl} target="_blank" rel="noreferrer">Buka layar proyektor</a>
        <p className="muted small">Tahap: <b>{statusLabel(status)}</b>{st.roundNo > 0 ? ` · ronde ${st.roundNo}/${st.rounds}` : ''}</p>
        <div className="ctrl">
          {status === 'LOBBY' && <button className="btn go" disabled={online.length < 2} onClick={() => void act('game:start')}>Mulai ({online.length} online)</button>}
          {['SPIN', 'PICK', 'RUNNING', 'COUNTDOWN'].includes(status) && <button className="btn warn" onClick={() => void act('host:pause')}>Jeda</button>}
          {status === 'PAUSED' && <button className="btn" onClick={() => void act('host:resume')}>Lanjutkan</button>}
          {status === 'ROUND_RESULT' && <button className="btn" onClick={() => void act('round:next')}>{st.roundNo >= st.rounds ? 'Lihat juara' : 'Ronde berikutnya'}</button>}
          {(status === 'RUNNING' || (status === 'PAUSED' && st.prevStatus === 'RUNNING')) && <button className="btn ghost" onClick={() => window.confirm('Akhiri ronde sekarang? Skor ronde ini langsung dihitung.') && void act('round:end-now')}>Akhiri ronde</button>}
          {['SPIN', 'PICK', 'COUNTDOWN', 'RUNNING', 'ROUND_RESULT', 'PAUSED'].includes(status) && <button className="btn ghost danger" onClick={() => window.confirm('Akhiri seluruh permainan sekarang? Ronde yang sedang berjalan dihitung, lalu papan juara dan laporan langsung dibuat.') && void act('game:end-now')}>Akhiri permainan</button>}
        </div>
        {msg && <p className="note">{msg}</p>}
        {(status === 'DONE' || status === 'FINAL') && (
          <div className="col">
            {back && <a className="btn go" href={back}>Kembali ke SIMPETERI dan impor hasil</a>}
            <button className="btn ghost sm" onClick={() => void download(`/rooms/${roomId}/report.csv`, jwt, 'glacia-laporan.csv')}>Unduh laporan (CSV)</button>
            <button className="btn ghost sm" onClick={() => void navigator.clipboard?.writeText(apiUrl(`/rooms/${roomId}/summary.json?key=${exportKey}`)).then(() => setMsg('Tautan ringkasan disalin untuk Multi Permainan SIMPETERI.'))}>Salin tautan ringkasan (Multi Permainan)</button>
            <button className="btn ghost sm" onClick={() => void rest(`/rooms/${roomId}/report/resend`)}>Kirim ulang ke SIMPETERI</button>
          </div>
        )}
        <button className="btn ghost sm" onClick={onClose}>Tutup panel</button>
      </Panel>

      <Panel title={`Pemain (${online.length} online / ${st.players.length})`} className="players-card">
        <ul className="plist">
          {st.players.map((p) => (
            <li key={p.playerId} className={`${p.online ? '' : 'off'}${p.disqualified ? ' dqd' : ''}`}>
              <Avatar name={p.name} size={28} />
              <span className="nm">{p.name}</span>
              <b>{(p.score ?? 0).toLocaleString('id-ID')}</b>
              {p.disqualified ? (
                <button className="btn ghost sm" onClick={() => window.confirm(`Pulihkan ${p.name}? Skor dikembalikan dan daftar hitam dicabut.`) && void rest(`/rooms/${roomId}/players/${p.playerId}/reinstate`)}>Pulihkan</button>
              ) : (
                <>
                  <button className="btn ghost sm" onClick={() => { const reason = window.prompt(`Alasan mendiskualifikasi ${p.name}?`); if (reason && reason.trim().length >= 3) void rest(`/rooms/${roomId}/players/${p.playerId}/disqualify`, { reason }); }} disabled={status === 'LOBBY'}>Diskualifikasi</button>
                  <button className="btn ghost sm" onClick={() => window.confirm(`Keluarkan ${p.name}?`) && void act('host:kick', { playerId: p.playerId })}>Keluarkan</button>
                </>
              )}
            </li>
          ))}
          {st.players.length === 0 && <li className="empty">Belum ada pemain. Bagikan PIN atau QR.</li>}
        </ul>
      </Panel>

      {view.gameEnd && (
        <div className="lb-host" style={{ gridColumn: '1 / -1' }}><Leaderboard rows={view.gameEnd.finalBoard} variant="host" title="Papan peringkat akhir" /></div>
      )}
      <Panel title="Peringatan kecurangan" className="flags-card">
        {dq.length > 0 && <p className="note">{dq.length} pemain didiskualifikasi.</p>}
        <ul className="flags">
          {flags.map((f, i) => (
            <li key={`${f.at}-${i}`} className={f.type === 'BLUR_STREAK_DQ' ? 'bad' : ''}>
              <b>{f.name}</b> <span className="tag">{flagLabel(f.type)}</span>
              {f.type === 'TAB_BLUR' && <small> pindah tab {(((f.detail.hiddenMs as number) ?? 0) / 1000).toFixed(1)} dtk</small>}
              {typeof f.streak === 'number' && f.streak > 0 && f.type !== 'BLUR_STREAK_DQ' && <small> · beruntun {f.streak}</small>}
              {f.armedUntil && f.armedUntil > now && <small> · dipantau {Math.ceil((f.armedUntil - now) / 1000)} dtk</small>}
            </li>
          ))}
          {flags.length === 0 && <li className="empty">Belum ada peringatan.</li>}
        </ul>
        {view.top5.length > 0 && <><h3 className="sub">Skor langsung</h3><TopList rows={view.top5} /></>}
      </Panel>
    </div>
  );
}

function Blacklist({ jwt }: { jwt: string }) {
  const [rows, setRows] = useState<BlRow[]>([]);
  const [msg, setMsg] = useState('');
  const load = useCallback(() => { void api<{ rows: BlRow[] }>('/blacklist', jwt).then((r) => r.ok && setRows(r.rows)); }, [jwt]);
  useEffect(load, [load]);
  const lift = async (s: BlRow) => {
    const note = window.prompt(`Catatan pencabutan untuk ${s.studentName} (wajib):`);
    if (!note || note.trim().length < 3) return;
    const r = await api(`/blacklist/${s.studentId}/lift`, jwt, { method: 'POST', body: { note } });
    setMsg(r.ok ? `${s.studentName} dicabut dari daftar hitam.` : 'Gagal mencabut.');
    load();
  };
  return (
    <Panel className="wide" title="Daftar Hitam">
      {msg && <p className="note">{msg}</p>}
      <table className="tbl">
        <thead><tr><th>Siswa</th><th>Alasan</th><th>Tanggal</th><th>Bukti</th><th /></tr></thead>
        <tbody>
          {rows.map((b) => (
            <tr key={b.studentId + b.createdAt} className={b.liftedAt ? 'lifted' : ''}>
              <td>{b.studentName}</td>
              <td>{b.reason === 'BLUR_STREAK' ? 'Pindah tab + benar beruntun' : 'Guru'}</td>
              <td>{new Date(b.createdAt).toLocaleString('id-ID')}</td>
              <td className="small">{b.evidence.flags?.length ?? 0} peringatan · beruntun {b.evidence.streak ?? '-'} · {b.evidence.lastAnswers?.length ?? 0} jawaban terakhir</td>
              <td>{b.liftedAt ? <small>dicabut</small> : <button className="btn ghost sm" onClick={() => void lift(b)}>Cabut</button>}</td>
            </tr>
          ))}
          {rows.length === 0 && <tr><td colSpan={5} className="empty">Daftar hitam kosong.</td></tr>}
        </tbody>
      </table>
    </Panel>
  );
}

interface DoneRoom { roomId: string; classId: string; playedAt: number; students: number; rounds: number; winner: string | null; topScore: number; exportKey?: string }
interface LiveRoom { roomId: string; pin: string; status: string; classId: string; createdAt: number }
interface SummaryStudent { studentId: string; name: string; rank: number | null; score: number; correct: number; wrong: number; status: string }

const dateTime = (ms: number) => new Date(ms).toLocaleString('id-ID', { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });

/** Finished games: pick one to see its full ranking, download the CSV, or copy the SIMPETERI summary link. */
function Results({ jwt, onOpen }: { jwt: string; onOpen: (id: string) => void }) {
  const [done, setDone] = useState<DoneRoom[] | null>(null);
  const [live, setLive] = useState<LiveRoom[]>([]);
  const [pick, setPick] = useState<string | null>(null);
  const [rows, setRows] = useState<BoardRow[] | null>(null);
  const [msg, setMsg] = useState('');
  useEffect(() => {
    void api<{ done: DoneRoom[]; live: LiveRoom[] }>('/rooms', jwt).then((r) => { if (r.ok) { setDone(r.done); setLive(r.live); } else setDone([]); });
  }, [jwt]);
  useEffect(() => {
    if (!pick) { setRows(null); return; }
    setRows(null);
    void api<{ summary: { students: SummaryStudent[] } }>(`/rooms/${pick}/report`, jwt).then((r) => {
      if (!r.ok) { setRows([]); return; }
      setRows(r.summary.students.filter((s) => s.status === 'OK' && s.rank !== null).map((s) => ({ playerId: s.studentId, name: s.name, score: s.score, correct: s.correct, wrong: s.wrong, rank: s.rank as number })));
    });
  }, [pick, jwt]);
  const cur = done?.find((d) => d.roomId === pick);
  return (
    <div className="page">
      <header className="page-head"><p className="kicker">Hasil permainan</p><h1>Hasil</h1></header>
      {live.length > 0 && (
        <section className="sheet-sec">
          <h2>Sedang berjalan</h2>
          <ul className="roomlist">
            {live.map((r) => (
              <li key={r.roomId}><b className="pinchip">{r.pin}</b><span>{r.classId}</span><em>{r.status}</em><button className="btn sm" onClick={() => onOpen(r.roomId)}>Buka panel</button></li>
            ))}
          </ul>
        </section>
      )}
      <section className="sheet-sec">
        <h2>Sudah selesai</h2>
        {done === null && <div className="skel" />}
        {done?.length === 0 && <div className="hadir-empty"><b>Belum ada permainan yang selesai.</b>Setelah satu permainan berakhir, hasilnya tersimpan di sini dan bisa dibuka kembali kapan saja.</div>}
        <div className="resgrid">
          {done?.map((d) => (
            <button key={d.roomId} className={`rescard${pick === d.roomId ? ' on' : ''}`} onClick={() => setPick(pick === d.roomId ? null : d.roomId)} aria-pressed={pick === d.roomId}>
              <small>{dateTime(d.playedAt)}</small>
              <b>{d.classId}</b>
              <span>{d.students} siswa · {d.rounds} kotak</span>
              {d.winner && <span className="winner-line"><Avatar name={d.winner} size={22} />{d.winner} <em>{d.topScore.toLocaleString('id-ID')}</em></span>}
            </button>
          ))}
        </div>
      </section>
      {pick && (
        <section className="res-detail">
          <div className="res-actions">
            <button className="btn ghost sm" onClick={() => void download(`/rooms/${pick}/report.csv`, jwt, 'glacia-laporan.csv')}>Unduh laporan (CSV)</button>
            {cur?.exportKey && <button className="btn ghost sm" onClick={() => void navigator.clipboard?.writeText(apiUrl(`/rooms/${pick}/summary.json?key=${cur.exportKey}`)).then(() => setMsg('Tautan ringkasan disalin.'))}>Salin tautan ringkasan</button>}
            <button className="btn ghost sm" onClick={() => void api(`/rooms/${pick}/report/resend`, jwt, { method: 'POST' }).then((r) => setMsg(r.ok ? 'Terkirim ulang ke SIMPETERI.' : 'Gagal mengirim. Coba lagi dari menu Diagnostik.'))}>Kirim ulang ke SIMPETERI</button>
            {msg && <span className="note" style={{ margin: 0 }}>{msg}</span>}
          </div>
          {rows === null ? <div className="skel" /> : <Leaderboard key={pick} rows={rows} variant="host" title="Papan peringkat akhir" kicker={cur ? `${cur.classId} · ${dateTime(cur.playedAt)}` : 'Hasil'} />}
        </section>
      )}
    </div>
  );
}

interface OutboxRowT { id: string; type: string; attempts: number; lastError: string | null; createdAt: number }
interface AuditRowT { id: string; actorId: string; action: string; target: string; at: number }
const ACTION_LABEL: Record<string, string> = { AUTO_DQ: 'Diskualifikasi otomatis', MANUAL_DQ: 'Diskualifikasi guru', REINSTATE: 'Dipulihkan', BLACKLIST_LIFT: 'Daftar hitam dicabut', KICK: 'Dikeluarkan', END_GAME: 'Permainan diakhiri' };

/** Is everything healthy, what is waiting to be sent to SIMPETERI, and who did what. Refreshes by itself. */
function Diagnostics({ jwt, onOpen }: { jwt: string; onOpen: (id: string) => void }) {
  const [health, setHealth] = useState<{ ok: boolean; uptime: number; rooms: number; questions: number; ms: number } | null>(null);
  const [outbox, setOutbox] = useState<OutboxRowT[]>([]);
  const [audit, setAudit] = useState<AuditRowT[]>([]);
  const [live, setLive] = useState<LiveRoom[]>([]);
  const [msg, setMsg] = useState('');
  const [down, setDown] = useState(false);
  const load = useCallback(async () => {
    try {
      const t0 = performance.now();
      const h = await api<{ uptime: number; rooms: number; questions: number }>('/health', null);
      setHealth({ ok: h.ok, uptime: h.uptime ?? 0, rooms: h.rooms ?? 0, questions: h.questions ?? 0, ms: Math.round(performance.now() - t0) });
      setDown(false);
      const [o, a, r] = await Promise.all([api<{ rows: OutboxRowT[] }>('/outbox', jwt), api<{ rows: AuditRowT[] }>('/audit', jwt), api<{ live: LiveRoom[] }>('/rooms', jwt)]);
      if (o.ok) setOutbox(o.rows);
      if (a.ok) setAudit([...a.rows].reverse());
      if (r.ok) setLive(r.live);
    } catch {
      setDown(true);
    }
  }, [jwt]);
  useEffect(() => { void load(); const h = setInterval(() => void load(), 5000); return () => clearInterval(h); }, [load]);
  const uptime = health ? (health.uptime >= 3600 ? `${Math.floor(health.uptime / 3600)} jam ${Math.floor((health.uptime % 3600) / 60)} menit` : `${Math.floor(health.uptime / 60)} menit`) : '–';
  return (
    <div className="page">
      <header className="page-head"><p className="kicker">Kesehatan sistem, diperbarui tiap 5 detik</p><h1>Diagnostik</h1></header>
      {down && <p className="note">Server tidak menjawab. Periksa koneksi atau tunggu sebentar.</p>}
      <dl className="diag-cards">
        <div className={health?.ok ? 'ok' : 'bad'}><dt>Server</dt><dd>{health ? (health.ok ? 'Sehat' : 'Bermasalah') : '…'}</dd><small>aktif {uptime}</small></div>
        <div><dt>Waktu jawab</dt><dd>{health ? health.ms : '–'}<small> ms</small></dd><small>dari perangkat ini ke server</small></div>
        <div><dt>Ruangan aktif</dt><dd>{health?.rooms ?? '–'}</dd><small>di memori server</small></div>
        <div><dt>Bank soal</dt><dd>{health ? health.questions.toLocaleString('id-ID') : '–'}</dd><small>operasi hitung dimuat</small></div>
        <div className={outbox.length ? 'warn' : 'ok'}><dt>Antrean SIMPETERI</dt><dd>{outbox.length}</dd><small>{outbox.length ? 'belum terkirim' : 'semua terkirim'}</small></div>
      </dl>

      <section className="sheet-sec">
        <h2>Antrean pengiriman ke SIMPETERI</h2>
        {outbox.length === 0 ? <p className="muted">Tidak ada yang tertunda.</p> : (
          <>
            <table className="tbl">
              <thead><tr><th>Jenis</th><th>Percobaan</th><th>Kesalahan terakhir</th><th>Sejak</th></tr></thead>
              <tbody>{outbox.map((o) => <tr key={o.id}><td>{({ RESULT: 'Hasil permainan', BLACKLIST: 'Daftar hitam', LIFT: 'Pencabutan' } as Record<string, string>)[o.type] ?? o.type}</td><td>{o.attempts}</td><td className="small">{o.lastError ?? '-'}</td><td>{dateTime(o.createdAt)}</td></tr>)}</tbody>
            </table>
            <button className="btn" style={{ marginTop: 12 }} onClick={() => void api<{ sent: number; failed: number }>('/outbox/flush', jwt, { method: 'POST' }).then((r) => { setMsg(`Terkirim ${r.sent ?? 0}, gagal ${r.failed ?? 0}.`); void load(); })}>Kirim ulang semua</button>
            {msg && <span className="note" style={{ marginLeft: 10 }}>{msg}</span>}
          </>
        )}
      </section>

      <section className="sheet-sec">
        <h2>Ruangan yang sedang berjalan</h2>
        {live.length === 0 ? <p className="muted">Tidak ada ruangan aktif.</p> : (
          <ul className="roomlist">{live.map((r) => <li key={r.roomId}><b className="pinchip">{r.pin}</b><span>{r.classId}</span><em>{r.status}</em><button className="btn sm" onClick={() => onOpen(r.roomId)}>Buka panel</button></li>)}</ul>
        )}
      </section>

      <section className="sheet-sec">
        <h2>Jejak audit (200 terakhir)</h2>
        {audit.length === 0 ? <p className="muted">Belum ada catatan.</p> : (
          <table className="tbl">
            <thead><tr><th>Waktu</th><th>Kejadian</th><th>Siswa / ruangan</th><th>Oleh</th></tr></thead>
            <tbody>{audit.slice(0, 60).map((a) => <tr key={a.id}><td>{dateTime(a.at)}</td><td>{ACTION_LABEL[a.action] ?? a.action}</td><td className="small">{a.target}</td><td className="small">{a.actorId}</td></tr>)}</tbody>
          </table>
        )}
      </section>
    </div>
  );
}

async function download(path: string, jwt: string, name: string) {
  const res = await fetch(apiUrl(path), { headers: { Authorization: `Bearer ${jwt}` } });
  const blob = await res.blob();
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = name;
  a.click();
  URL.revokeObjectURL(a.href);
}

const statusLabel = (s: string) =>
  ({ CREATED: 'Dibuat', LOBBY: 'Lobi', SPIN: 'Memutar roda', PICK: 'Memilih kategori', COUNTDOWN: 'Hitung mundur', RUNNING: 'Ronde berjalan', ROUND_RESULT: 'Hasil ronde', FINAL: 'Akhir', DONE: 'Selesai', PAUSED: 'Dijeda' })[s] ?? s;
const flagLabel = (t: string) =>
  ({ TAB_BLUR: 'pindah tab', ANSWER_WHILE_HIDDEN: 'menjawab saat tab tersembunyi', BLUR_STREAK_DQ: 'DIDISKUALIFIKASI', TOO_FAST: 'terlalu cepat', UNIFORM_TIMING: 'waktu seragam', MULTI_DEVICE: 'dua perangkat', BURST: 'lonjakan benar' })[t] ?? t;

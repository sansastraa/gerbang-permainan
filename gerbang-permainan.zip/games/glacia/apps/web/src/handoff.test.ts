import { describe, expect, it } from 'vitest';
import { parseRosterMessage, returnUrl, ROSTER_MESSAGE } from './handoff';

const ORIGIN = 'https://simpeteri.example.sch.id';
const good = () => ({
  type: ROSTER_MESSAGE,
  kelas: '6A',
  pin: 'pin-guru-4711',
  kembali: `${ORIGIN}/multi-permainan?sesi=s1&game=glacia`,
  multiSesi: 's1',
  roster: [
    { id: 'uuid-1', name: 'Aisyah Putri', absen: 1 },
    { id: 'uuid-2', name: '  Bagas   Pratama ', absen: 2 },
  ],
});

describe('SIMPETERI roster message (client side of the handoff)', () => {
  it('accepts the message SIMPETERI sends and keeps siswa.id', () => {
    const h = parseRosterMessage(good(), ORIGIN)!;
    expect(h.kelas).toBe('6A');
    expect(h.pin).toBe('pin-guru-4711');
    expect(h.roster.map((r) => r.id)).toEqual(['uuid-1', 'uuid-2']);
    expect(h.roster[1]!.name).toBe('Bagas   Pratama'); // trimmed, inner spacing is the name's business
    expect(h.multiSesi).toBe('s1');
  });

  it('ignores anything that is not the roster message', () => {
    expect(parseRosterMessage(null, ORIGIN)).toBeNull();
    expect(parseRosterMessage('hai', ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), type: 'claim80:roster' }, ORIGIN)).toBeNull();
  });

  it('rejects a PIN that is too short, too long or contains spaces', () => {
    for (const pin of ['abc', 'a'.repeat(33), 'ada spasi', '', 123 as unknown as string]) expect(parseRosterMessage({ ...good(), pin }, ORIGIN)).toBeNull();
  });

  it('rejects an empty, oversized, duplicated or malformed roster', () => {
    expect(parseRosterMessage({ ...good(), roster: [] }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: 'x' }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: Array.from({ length: 101 }, (_, i) => ({ id: `u${i}`, name: `N${i}` })) }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: [{ id: 'a', name: 'A' }, { id: 'a', name: 'B' }] }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: [{ id: 'a', name: '' }] }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: [{ id: 5, name: 'A' }] }, ORIGIN)).toBeNull();
    expect(parseRosterMessage({ ...good(), roster: [null] }, ORIGIN)).toBeNull();
  });

  it('accepts exactly 100 students', () => {
    const roster = Array.from({ length: 100 }, (_, i) => ({ id: `u${i}`, name: `Nama ${i}` }));
    expect(parseRosterMessage({ ...good(), roster }, ORIGIN)?.roster).toHaveLength(100);
  });

  it('only returns to the page that sent us: a "kembali" on another origin is dropped', () => {
    expect(parseRosterMessage({ ...good(), kembali: 'https://evil.example/phish' }, ORIGIN)!.kembali).toBe('');
    expect(parseRosterMessage({ ...good(), kembali: 'bukan url' }, ORIGIN)!.kembali).toBe('');
    expect(parseRosterMessage({ ...good(), kembali: undefined }, ORIGIN)!.kembali).toBe('');
    expect(parseRosterMessage({ ...good(), kembali: 'javascript:alert(1)' }, ORIGIN)!.kembali).toBe('');
  });

  it('falls back to a neutral class name', () => {
    expect(parseRosterMessage({ ...good(), kelas: '   ' }, ORIGIN)!.kelas).toBe('Kelas');
  });
});

describe('returnUrl', () => {
  it('adds selesai=1 and the room id to the Multi Permainan URL, keeping its own query', () => {
    const h = parseRosterMessage(good(), ORIGIN)!;
    const u = new URL(returnUrl(h, '6f0c9d2e-aaaa-4bbb-8ccc-123456789abc')!);
    expect(u.origin).toBe(ORIGIN);
    expect(u.pathname).toBe('/multi-permainan');
    expect(u.searchParams.get('sesi')).toBe('s1');
    expect(u.searchParams.get('game')).toBe('glacia');
    expect(u.searchParams.get('selesai')).toBe('1');
    // SIMPETERI only accepts ids matching /^[A-Za-z0-9_-]{1,64}$/ — a room UUID does
    expect(u.searchParams.get('gameSesi')).toMatch(/^[A-Za-z0-9_-]{1,64}$/);
  });

  it('gives nothing when there is nowhere to return to', () => {
    expect(returnUrl(null, 'x')).toBeNull();
    expect(returnUrl({ ...parseRosterMessage(good(), ORIGIN)!, kembali: '' }, 'x')).toBeNull();
  });
});

import { describe, expect, it } from 'vitest';
import { apiUrlFor, basePathOf, pageUrlFor, routeFrom, socketPathFor } from './urls';

const ORIGIN = 'https://sekolah.example.sch.id';

describe('URLs behind a path prefix', () => {
  it('turns Vite BASE_URL into the prefix', () => {
    expect(basePathOf('/')).toBe('');
    expect(basePathOf('/games/glacia/')).toBe('/games/glacia');
  });

  it('API, socket.io and page URLs all carry the prefix; at the root they are unchanged', () => {
    expect(apiUrlFor(ORIGIN, '/games/glacia', '/rooms/x/summary.json?key=k')).toBe(`${ORIGIN}/games/glacia/api/rooms/x/summary.json?key=k`);
    expect(apiUrlFor(ORIGIN, '', '/rooms')).toBe(`${ORIGIN}/api/rooms`);
    expect(socketPathFor('/games/glacia')).toBe('/games/glacia/socket.io');
    expect(socketPathFor('')).toBe('/socket.io');
  });

  it('the join link and QR a teacher shows include the prefix, whatever page the teacher is on', () => {
    expect(pageUrlFor(ORIGIN, '/games/glacia', '/play?pin=123456')).toBe(`${ORIGIN}/games/glacia/#/play?pin=123456`);
    expect(pageUrlFor(ORIGIN, '', '/display/123456')).toBe(`${ORIGIN}/#/display/123456`);
  });
});

describe('routeFrom: hash routes and plain paths', () => {
  it('hash wins and keeps its query', () => {
    const r = routeFrom('/games/glacia/', '#/play?pin=654321', '', '/games/glacia');
    expect(r.path).toBe('/play');
    expect(r.query.get('pin')).toBe('654321');
    expect(routeFrom('/', '#/host', '', '').path).toBe('/host');
    expect(routeFrom('/anything', '#/', '', '').path).toBe('/'); // an explicit "#/" is Home, even on /host
  });

  it('SIMPETERI opens {alamat}/host: the path under the prefix picks the screen', () => {
    expect(routeFrom('/games/glacia/host', '', '', '/games/glacia').path).toBe('/host');
    expect(routeFrom('/host', '', '', '').path).toBe('/host');
    expect(routeFrom('/games/glacia/display/123456', '', '', '/games/glacia').path).toBe('/display/123456');
    expect(routeFrom('/games/glacia/host/', '', '', '/games/glacia').path).toBe('/host');
  });

  it('the bare prefix and the root are Home; an empty or lone # counts as no hash', () => {
    for (const p of ['/games/glacia', '/games/glacia/']) expect(routeFrom(p, '', '', '/games/glacia').path).toBe('/');
    expect(routeFrom('/', '', '', '').path).toBe('/');
    expect(routeFrom('/games/glacia/host', '#', '', '/games/glacia').path).toBe('/host');
  });

  it('a path query is passed on (e.g. /host?token=...)', () => {
    expect(routeFrom('/games/glacia/host', '', '?token=abc', '/games/glacia').query.get('token')).toBe('abc');
  });

  it('only strips the prefix at a path boundary', () => {
    expect(routeFrom('/games/glaciaX/host', '', '', '/games/glacia').path).toBe('/games/glaciaX/host');
  });
});

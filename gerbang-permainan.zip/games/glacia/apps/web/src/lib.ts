import { useEffect, useMemo, useRef, useState } from 'react';
import { io, type Socket } from 'socket.io-client';
import { apiUrlFor, basePathOf, socketPathFor } from './urls';

export const SERVER_URL: string =
  (import.meta.env.VITE_SERVER_URL as string | undefined) || (import.meta.env.PROD ? window.location.origin : `http://${window.location.hostname}:4000`);

/** '' normally; '/games/glacia' when the build sits behind SIMPETERI's gateway (Vite base). */
export const BASE_PATH: string = basePathOf(import.meta.env.BASE_URL);
export const apiUrl = (path: string): string => apiUrlFor(SERVER_URL, BASE_PATH, path);

export function deviceToken(): string {
  try {
    let t = localStorage.getItem('glacia.device');
    if (!t) {
      t = crypto.randomUUID();
      localStorage.setItem('glacia.device', t);
    }
    return t;
  } catch {
    return crypto.randomUUID();
  }
}

export function store<T>(key: string, fallback: T): [() => T, (v: T) => void] {
  return [
    () => {
      try {
        const v = localStorage.getItem(key);
        return v === null ? fallback : (JSON.parse(v) as T);
      } catch {
        return fallback;
      }
    },
    (v) => {
      try {
        localStorage.setItem(key, JSON.stringify(v));
      } catch {
        /* storage may be blocked */
      }
    },
  ];
}

// ---------------------------------------------------------------- REST
export async function api<T = Record<string, unknown>>(path: string, jwt: string | null, init: { method?: string; body?: unknown } = {}): Promise<T & { ok: boolean; code?: string }> {
  const res = await fetch(apiUrl(path), {
    method: init.method ?? 'GET',
    headers: { 'Content-Type': 'application/json', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) },
    body: init.body === undefined ? undefined : JSON.stringify(init.body),
  });
  const ct = res.headers.get('content-type') ?? '';
  if (!ct.includes('json')) return { ok: res.ok } as T & { ok: boolean };
  return (await res.json()) as T & { ok: boolean; code?: string };
}

// ---------------------------------------------------------------- server clock
let offset = 0;
export const syncClock = (serverNow: number | undefined) => {
  if (typeof serverNow === 'number') offset = serverNow - Date.now();
};
export const serverTime = () => Date.now() + offset;

export function useNow(intervalMs = 250): number {
  const [n, setN] = useState(serverTime());
  useEffect(() => {
    const h = setInterval(() => setN(serverTime()), intervalMs);
    return () => clearInterval(h);
  }, [intervalMs]);
  return n;
}

// ---------------------------------------------------------------- game types (client view)
export interface PublicPlayer {
  playerId: string;
  name: string;
  online: boolean;
  hasPicked: boolean;
  disqualified?: boolean;
  blacklisted?: boolean;
  score?: number;
}
export interface RoomState {
  roomId: string;
  pin: string;
  status: string;
  prevStatus: string | null;
  roundNo: number;
  rounds: number;
  players: PublicPlayer[];
  disqualifiedCount: number;
  settings: { roundSeconds: number; rounds: number; maxPlayers: number; categoryPickSeconds: number; showDisqualifiedOnDisplay: 'NAME' | 'INITIALS' | 'COUNT_ONLY'; wrongCooldownMs: number };
  pickerId: string | null;
  pickerName: string | null;
  pickExpiresAt: number | null;
  startsAt: number | null;
  endsAt: number | null;
  category: { id: number; name: string } | null;
  pausedAt: number | null;
  you: { playerId: string; name: string; score: number; disqualified: boolean } | null;
  serverNow: number;
}
export interface Card {
  cardId: string;
  svg: string;
}
export interface Top5 {
  playerId: string;
  name: string;
  score: number;
}
export interface DqBanner {
  kind: 'dq' | 'back';
  text: string;
  at: number;
}
export interface RoundEnd {
  roundNo: number;
  rounds: number;
  category: { id: number; name: string };
  trick: string;
  roundScores: { playerId: string; name: string; roundScore: number; total: number; correct: number; wrong: number; perfect: boolean; rank: number }[];
  keyReveal: { cardId: string; isCorrect: boolean; result: number }[];
  explanations: { cardId: string; svg: string; result: number; isCorrect: boolean; explanation: string; wrongCount: number; solvedCount: number }[];
  nextAt: number;
  lastRound: boolean;
}
export interface GameEnd {
  finalBoard: { rank: number; playerId: string; name: string; score: number; correct: number; wrong: number }[];
  podium: { rank: number; playerId: string; name: string; score: number }[];
  disqualified: { count: number; mode: string; names: string[] };
}
export interface FlagMsg {
  playerId: string;
  name: string;
  type: string;
  detail: Record<string, unknown>;
  at: number;
  streak?: number;
  armedUntil?: number | null;
}

export interface GameView {
  connected: boolean;
  state: RoomState | null;
  wheel: { playerId: string; name: string }[];
  spin: { pickedPlayerId: string; pickedName: string; animSeed: string; animMs: number; at: number } | null;
  options: { categories: { id: number; name: string }[]; expiresAt: number } | null;
  countdown: { startsAt: number; category: { id: number; name: string } } | null;
  round: { roundNo: number; rounds: number; category: { id: number; name: string }; endsAt: number; cardCount: number; numbersTotal?: number; numbersBefore?: number } | null;
  cards: Card[];
  results: Record<string, boolean>;
  /** cards taken by the first correct answer: cardId → claimer */
  claims: Record<string, { playerId: string; name: string }>;
  progress: { claimed: number; remaining: number } | null;
  toast: { text: string; at: number } | null;
  /** rank per player after the latest board, and after the one before it (for the movement arrows) */
  ranks: Record<string, number>;
  prevRank: Record<string, number>;
  /** this player's own answers in the current game (for the local profile) */
  tally: { correct: number; wrong: number };
  cooldownUntil: number;
  score: number;
  top5: Top5[];
  roundEnd: RoundEnd | null;
  gameEnd: GameEnd | null;
  banner: DqBanner | null;
  dq: { message: string } | null;
  rejected: string | null;
  flags: FlagMsg[];
  kicked: boolean;
  lastFlash: { cardId: string; correct: boolean; at: number } | null;
}

const empty: GameView = {
  connected: false, state: null, wheel: [], spin: null, options: null, countdown: null, round: null, cards: [], results: {}, claims: {}, progress: null, toast: null, tally: { correct: 0, wrong: 0 }, ranks: {}, prevRank: {}, cooldownUntil: 0, score: 0,
  top5: [], roundEnd: null, gameEnd: null, banner: null, dq: null, rejected: null, flags: [], kicked: false, lastFlash: null,
};

export function useGameSocket(): { socket: Socket; view: GameView; reset: () => void } {
  const socket = useMemo(() => io(`${SERVER_URL}/game`, { path: socketPathFor(BASE_PATH), transports: ['websocket', 'polling'], autoConnect: true, reconnection: true, reconnectionDelay: 500, reconnectionDelayMax: 3000 }), []);
  const [view, setView] = useState<GameView>(empty);
  const ref = useRef(view);
  ref.current = view;
  const patch = (p: Partial<GameView> | ((v: GameView) => Partial<GameView>)) => setView((v) => ({ ...v, ...(typeof p === 'function' ? p(v) : p) }));

  useEffect(() => {
    const modeName = (n: string | null, mode: string, total: number) => (mode === 'COUNT_ONLY' || n === null ? `${total} pemain` : n);
    socket.connect(); // StrictMode re-runs this effect after cleanup disconnected the socket
    const on = (ev: string, fn: (...a: never[]) => void) => socket.on(ev, fn as never);
    on('connect', () => patch({ connected: true }));
    on('disconnect', () => patch({ connected: false }));
    on('room:state', (s: RoomState) => {
      syncClock(s.serverNow);
      patch((v) => ({ state: s, score: s.you ? s.you.score : v.score, dq: s.you?.disqualified ? (v.dq ?? { message: 'Kamu didiskualifikasi karena terdeteksi kecurangan. Silakan temui gurumu.' }) : v.dq }));
    });
    on('spin:wheel', (w: { segments: { playerId: string; name: string }[] }) => patch({ wheel: w.segments }));
    on('spin:result', (s: { pickedPlayerId: string; pickedName: string; animSeed: string; animMs: number; eligible: { playerId: string; name: string }[] }) =>
      patch({ spin: { ...s, at: serverTime() }, wheel: s.eligible, options: null, countdown: null, round: null, roundEnd: null }));
    on('category:options', (o: { categories: { id: number; name: string }[]; expiresAt: number }) => patch({ options: o }));
    on('round:countdown', (c: { startsAt: number; category: { id: number; name: string }; serverNow: number }) => {
      syncClock(c.serverNow);
      patch({ countdown: c, options: null, cards: [], results: {}, claims: {}, progress: null, toast: null, top5: [] });
    });
    on('round:start', (r: { roundNo: number; rounds: number; category: { id: number; name: string }; endsAt: number; cardCount: number; cards: Card[]; serverNow: number }) => {
      syncClock(r.serverNow);
      patch({ round: r, cards: r.cards, results: {}, claims: {}, countdown: null, roundEnd: null, cooldownUntil: 0 });
    });
    on('card:result', (m: { cardId: string; correct: boolean; score: number; cooldownUntil?: number }) =>
      patch((v) => ({ tally: { correct: v.tally.correct + (m.correct ? 1 : 0), wrong: v.tally.wrong + (m.correct ? 0 : 1) }, results: { ...v.results, [m.cardId]: m.correct }, score: m.score, cooldownUntil: m.cooldownUntil ?? v.cooldownUntil, lastFlash: { cardId: m.cardId, correct: m.correct, at: Date.now() } })));
    on('card:rejected', (m: { code: string; cooldownUntil?: number }) =>
      patch((v) => ({ cooldownUntil: m.cooldownUntil ?? v.cooldownUntil, rejected: m.code, toast: m.code === 'CARD_CLAIMED' ? { text: 'Keduluan! Kartu itu sudah diklaim.', at: Date.now() } : v.toast })));
    on('card:claimed', (m: { cardId: string; playerId: string; name: string }) => patch((v) => ({ claims: { ...v.claims, [m.cardId]: { playerId: m.playerId, name: m.name } } })));
    on('card:released', (m: { cardId: string }) => patch((v) => { const c = { ...v.claims }; delete c[m.cardId]; return { claims: c }; }));
    on('board:refresh', (b: { replaced: { oldCardId: string; cardId: string; svg: string }[] }) =>
      patch((v) => {
        const map = new Map(b.replaced.map((r) => [r.oldCardId, r]));
        return { cards: v.cards.map((c) => (map.has(c.cardId) ? { cardId: map.get(c.cardId)!.cardId, svg: map.get(c.cardId)!.svg } : c)) };
      }));
    on('scoreboard:live', (s: { top5: Top5[]; claimed?: number; remaining?: number }) =>
      patch({ top5: s.top5, progress: typeof s.claimed === 'number' ? { claimed: s.claimed, remaining: s.remaining ?? 0 } : null }));
    on('round:end', (r: RoundEnd) => patch((v) => ({ roundEnd: r, round: null, prevRank: v.ranks, ranks: Object.fromEntries(r.roundScores.map((x) => [x.playerId, x.rank])) })));
    on('game:end', (g: GameEnd) => patch({ gameEnd: g }));
    on('player:disqualified', (m: { displayName: string | null; mode: string; totalDisqualified: number }) =>
      patch({ banner: { kind: 'dq', text: m.displayName === null ? `${m.totalDisqualified} pemain didiskualifikasi` : `${m.displayName} DIDISKUALIFIKASI — terdeteksi kecurangan`, at: Date.now() } }));
    on('player:reinstated', (m: { displayName: string | null; mode: string; totalDisqualified: number }) =>
      patch({ banner: { kind: 'back', text: `${modeName(m.displayName, m.mode, m.totalDisqualified)} dipulihkan`, at: Date.now() } }));
    on('you:disqualified', (m: { message: string }) => patch({ dq: m }));
    on('you:reinstated', () => patch({ dq: null }));
    on('you:kicked', () => patch({ kicked: true }));
    on('blacklist:rejected', (m: { message: string }) => patch({ rejected: m.message }));
    on('cheat:flag', (f: FlagMsg) => patch((v) => ({ flags: [...v.flags.slice(-99), f] })));
    return () => {
      socket.removeAllListeners();
      socket.disconnect();
    };
  }, [socket]);

  return { socket, view, reset: () => setView(empty) };
}

export function emitAck<T = Record<string, unknown>>(socket: Socket, event: string, payload: unknown = {}): Promise<T & { ok: boolean; code?: string }> {
  return new Promise((resolve) => {
    const t = setTimeout(() => resolve({ ok: false, code: 'TIMEOUT' } as T & { ok: boolean; code: string }), 8000);
    socket.emit(event, payload, (res: T & { ok: boolean }) => {
      clearTimeout(t);
      resolve(res);
    });
  });
}

// ---------------------------------------------------------------- sound (WebAudio only; no speech synthesis)
let audio: AudioContext | null = null;
const [getMuted, setMutedStore] = store<boolean>('glacia.muted', false);
export const isMuted = getMuted;
export const setMuted = setMutedStore;
export function beep(kind: 'ok' | 'bad' | 'tick' | 'alarm' | 'win'): void {
  if (getMuted()) return;
  try {
    audio ??= new AudioContext();
    const notes: Record<string, [number, number][]> = {
      ok: [[660, 0.07], [880, 0.1]],
      bad: [[220, 0.12], [160, 0.18]],
      tick: [[520, 0.04]],
      alarm: [[300, 0.2], [240, 0.3]],
      win: [[523, 0.1], [659, 0.1], [784, 0.2]],
    };
    let t = audio.currentTime;
    for (const [f, d] of notes[kind] ?? []) {
      const o = audio.createOscillator();
      const g = audio.createGain();
      o.frequency.value = f;
      o.type = kind === 'bad' || kind === 'alarm' ? 'sawtooth' : 'sine';
      g.gain.setValueAtTime(0.06, t);
      g.gain.exponentialRampToValueAtTime(0.0001, t + d);
      o.connect(g).connect(audio.destination);
      o.start(t);
      o.stop(t + d);
      t += d * 0.9;
    }
  } catch {
    /* audio blocked: ignore */
  }
}

export const fmtClock = (ms: number) => {
  const s = Math.max(0, Math.ceil(ms / 1000));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`;
};

// ---------------------------------------------------------------- local profile (this device only)
export interface Profile {
  name: string;
  games: number;
  best: number;
  claims: number;
  wrong: number;
  wins: number;
  podiums: number;
  lastPlayed: number;
}
const [getProfile, setProfile] = store<Profile | null>('glacia.profile', null);
export const loadProfile = getProfile;
export const clearProfile = () => setProfile(null);
export function recordGame(g: { name: string; score: number; rank: number | null; correct: number; wrong: number }): Profile {
  const p = getProfile() ?? { name: g.name, games: 0, best: 0, claims: 0, wrong: 0, wins: 0, podiums: 0, lastPlayed: 0 };
  const next: Profile = {
    name: g.name,
    games: p.games + 1,
    best: Math.max(p.best, g.score),
    claims: p.claims + g.correct,
    wrong: p.wrong + g.wrong,
    wins: p.wins + (g.rank === 1 ? 1 : 0),
    podiums: p.podiums + (g.rank !== null && g.rank <= 3 ? 1 : 0),
    lastPlayed: Date.now(),
  };
  setProfile(next);
  return next;
}
export const RANKS = [
  { min: 0, title: 'Pemula Salju' },
  { min: 10, title: 'Pencari Es' },
  { min: 50, title: 'Pemburu Retakan' },
  { min: 150, title: 'Penjelajah Gletser' },
  { min: 400, title: 'Raja Gletser' },
] as const;
export function rankOf(claims: number) {
  let i = 0;
  RANKS.forEach((r, k) => { if (claims >= r.min) i = k; });
  const cur = RANKS[i]!;
  const next = RANKS[i + 1] ?? null;
  return { index: i, title: cur.title, next, pct: next ? Math.round(((claims - cur.min) / (next.min - cur.min)) * 100) : 100, toNext: next ? next.min - claims : 0 };
}
import { useEffect, useMemo, useRef, useState } from 'react';
import type { RoundEnd } from './lib';
import { Avatar } from './ui';

export interface BoardRow {
  playerId: string;
  name: string;
  /** total score */
  score: number;
  correct: number;
  wrong: number;
  /** rank by total score */
  rank: number;
  /** score of the board that just ended (interim view) */
  roundScore?: number;
  /** rank after the previous board; undefined on the first board */
  prevRank?: number | null;
}

/** Rows for the interim ranking shown after every board. */
export function rowsFromRound(r: RoundEnd, prevRank: Record<string, number>): BoardRow[] {
  const hasPrev = Object.keys(prevRank).length > 0;
  return r.roundScores.map((x) => ({ playerId: x.playerId, name: x.name, score: x.total, correct: x.correct, wrong: x.wrong, rank: x.rank, roundScore: x.roundScore, prevRank: hasPrev ? (prevRank[x.playerId] ?? null) : undefined }));
}

/** Counts up from 0 once, easing out. Respects reduced motion. */
function useCountUp(target: number, ms = 1200, delay = 0): number {
  const [v, setV] = useState(0);
  const raf = useRef(0);
  useEffect(() => {
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) { setV(target); return; }
    let t0 = 0;
    const tick = (t: number) => {
      if (!t0) t0 = t;
      const k = Math.min(1, Math.max(0, (t - t0 - delay) / ms));
      setV(Math.round(target * (1 - Math.pow(1 - k, 3))));
      if (k < 1) raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf.current);
  }, [target, ms, delay]);
  return v;
}

const fmt = (n: number) => n.toLocaleString('id-ID');
const firstName = (n: string) => n.split(' ')[0] ?? n;
const accuracy = (r: BoardRow) => (r.correct + r.wrong > 0 ? Math.round((r.correct / (r.correct + r.wrong)) * 100) : 0);

function Crown() {
  return (
    <svg className="lb-crown" viewBox="0 0 40 26" width="38" height="25" aria-hidden>
      <path d="M2 22 5 6l9 8 6-12 6 12 9-8 3 16z" fill="#f6c945" stroke="#231f1a" strokeWidth="2" strokeLinejoin="round" />
      <circle cx="5" cy="5" r="2.2" fill="#f2542d" stroke="#231f1a" strokeWidth="1.5" /><circle cx="20" cy="2.5" r="2.2" fill="#f2542d" stroke="#231f1a" strokeWidth="1.5" /><circle cx="35" cy="5" r="2.2" fill="#f2542d" stroke="#231f1a" strokeWidth="1.5" />
    </svg>
  );
}

function Move({ row }: { row: BoardRow }) {
  if (row.prevRank === undefined) return null;
  if (row.prevRank === null) return <span className="mv new" title="Baru masuk papan">baru</span>;
  const d = row.prevRank - row.rank;
  if (d === 0) return <span className="mv same" title="Peringkat tetap">–</span>;
  return d > 0 ? <span className="mv up" title={`Naik ${d} peringkat`}>▲{d}</span> : <span className="mv down" title={`Turun ${-d} peringkat`}>▼{-d}</span>;
}

type Shown = BoardRow & { shown: number; val: number };

function PodiumStep({ row, delay, big, interim }: { row: Shown; delay: number; big: boolean; interim: boolean }) {
  const score = useCountUp(row.val, 1300, delay);
  return (
    <div className={`lb-pod p${row.shown}`} style={{ ['--d' as string]: `${delay}ms` }}>
      {row.shown === 1 && <Crown />}
      <Avatar name={row.name} size={big ? 92 : 68} />
      <b className="lb-pname">{firstName(row.name)}</b>
      <span className="lb-pfull">{row.name.split(' ').slice(1).join(' ')}</span>
      <span className="lb-pscore">{interim && row.val > 0 && row.val === (row.roundScore ?? -1) ? '+' : ''}{fmt(score)}</span>
      <div className="lb-block"><i>{row.shown}</i><small>{row.correct} benar · {accuracy(row)}%</small></div>
    </div>
  );
}

function Detail({ row, above, interim }: { row: Shown; above?: Shown; interim: boolean }) {
  const gap = above ? above.val - row.val : 0;
  return (
    <dl className="lb-detail">
      <div><dt>Skor total</dt><dd>{fmt(row.score)}</dd></div>
      {interim && <div><dt>Kotak ini</dt><dd>{(row.roundScore ?? 0) >= 0 ? '+' : ''}{fmt(row.roundScore ?? 0)}</dd></div>}
      <div><dt>Benar</dt><dd>{row.correct}</dd></div>
      <div><dt>Salah</dt><dd>{row.wrong}</dd></div>
      <div><dt>Ketepatan</dt><dd>{accuracy(row)}%</dd></div>
      <div><dt>{above ? `Ke peringkat ${above.shown}` : 'Posisi'}</dt><dd>{above ? `${fmt(gap)} lagi` : 'Terdepan'}</dd></div>
    </dl>
  );
}

function ListRow({ row, above, top, meId, i, open, onToggle, interim }: { row: Shown; above?: Shown; top: number; meId?: string | null; i: number; open: boolean; onToggle: () => void; interim: boolean }) {
  const [grown, setGrown] = useState(false);
  useEffect(() => { const h = setTimeout(() => setGrown(true), 120 + i * 35); return () => clearTimeout(h); }, [i]);
  const me = meId && row.playerId === meId;
  return (
    <li className={`lb-item${open ? ' open' : ''}`} style={{ ['--i' as string]: i }}>
      <button type="button" className={`lb-row${me ? ' me' : ''}${row.shown <= 3 ? ` top${row.shown}` : ''}`} aria-expanded={open} onClick={onToggle}>
        <span className="lb-rank">{row.shown}</span>
        <Avatar name={row.name} size={38} />
        <span className="lb-who"><b>{row.name}{me && <em>Kamu</em>}<Move row={row} /></b><small>{row.correct} benar · {row.wrong} salah · {accuracy(row)}% tepat</small></span>
        <span className="lb-bar" aria-hidden><i style={{ width: grown && top > 0 ? `${Math.max(3, (row.val / top) * 100)}%` : '0%' }} /></span>
        <span className="lb-score">{interim && row.val === (row.roundScore ?? -1) ? '+' : ''}{fmt(row.val)}</span>
        <span className="lb-chev" aria-hidden>{open ? '–' : '+'}</span>
      </button>
      {open && <Detail row={row} above={above} interim={interim} />}
    </li>
  );
}

/**
 * Ranking: podium for the top three, then a ranked list. Tap a row for details.
 * `interim` = the ranking after a board (adds the "Kotak ini" sort, +points and rank movement).
 * variant "display" = big, top 10 for the projector; "phone"/"host" = everybody, scrollable.
 */
export function Leaderboard({ rows, meId, variant = 'phone', title = 'Papan peringkat', kicker = 'Permainan selesai', interim = false }: { rows: BoardRow[]; meId?: string | null; variant?: 'display' | 'phone' | 'host'; title?: string; kicker?: string; interim?: boolean }) {
  const [sort, setSort] = useState<'total' | 'round'>('total');
  const [q, setQ] = useState('');
  const [open, setOpen] = useState<string | null>(null);
  const byRound = interim && sort === 'round';
  const ordered: Shown[] = useMemo(() => {
    const base = [...rows];
    if (byRound) base.sort((a, b) => (b.roundScore ?? 0) - (a.roundScore ?? 0) || b.score - a.score);
    else base.sort((a, b) => a.rank - b.rank);
    return base.map((r, i) => ({ ...r, shown: i + 1, val: byRound ? (r.roundScore ?? 0) : r.score }));
  }, [rows, byRound]);
  const top3 = ordered.slice(0, 3);
  const needle = q.trim().toLowerCase();
  const rest = ordered.slice(3).filter((r) => !needle || r.name.toLowerCase().includes(needle));
  const shownRest = variant === 'display' ? rest.slice(0, 7) : rest;
  const hidden = rest.length - shownRest.length;
  const leader = ordered[0]?.val ?? 0;
  const totalCorrect = rows.reduce((s, r) => s + r.correct, 0);
  const me = meId ? ordered.find((r) => r.playerId === meId) : undefined;
  const order = [top3.find((r) => r.shown === 2), top3.find((r) => r.shown === 1), top3.find((r) => r.shown === 3)];
  const interactive = variant !== 'display';
  return (
    <section className={`lb lb-${variant}`} aria-label={title}>
      <header className="lb-head">
        <div><p className="kicker">{kicker}</p><h2>{title}</h2></div>
        <ul className="lb-stats" aria-label="Ringkasan">
          <li><b>{ordered.length}</b> siswa</li>
          <li><b>{fmt(totalCorrect)}</b> kartu benar</li>
          <li><b>{fmt(ordered[0]?.score ?? 0)}</b> skor tertinggi</li>
        </ul>
      </header>

      {interim && interactive && (
        <div className="lb-tools">
          <div className="seg" role="radiogroup" aria-label="Urutkan berdasarkan">
            <label><input type="radio" name="lbsort" checked={sort === 'total'} onChange={() => setSort('total')} /><span>Skor total</span></label>
            <label><input type="radio" name="lbsort" checked={sort === 'round'} onChange={() => setSort('round')} /><span>Kotak ini</span></label>
          </div>
        </div>
      )}

      {me && me.shown > 3 && <p className="lb-me">Kamu di peringkat <b>{me.shown}</b> dengan <b>{fmt(me.val)}</b> poin{byRound ? ' di kotak ini' : ''}.</p>}
      {me && me.shown <= 3 && <p className="lb-me win">{me.shown === 1 ? 'Kamu di puncak!' : `Kamu masuk tiga besar, peringkat ${me.shown}.`}</p>}

      <div className="lb-podium">
        {order.map((r, k) => (r ? <PodiumStep key={`${r.playerId}-${byRound}`} row={r} delay={k === 1 ? 500 : k === 0 ? 250 : 0} big={r.shown === 1} interim={byRound} /> : <div key={k} className="lb-pod ghost" />))}
      </div>

      {interactive && ordered.length > 12 && (
        <input className="lb-search" type="text" value={q} onChange={(e) => setQ(e.target.value)} placeholder="Cari nama siswa…" aria-label="Cari nama siswa" />
      )}

      {shownRest.length > 0 && (
        <ol className="lb-list" start={4}>
          {shownRest.map((r, i) => (
            <ListRow key={`${r.playerId}-${byRound}`} row={r} above={ordered[r.shown - 2]} top={leader} meId={meId} i={i} open={interactive && open === r.playerId} interim={byRound} onToggle={() => interactive && setOpen((o) => (o === r.playerId ? null : r.playerId))} />
          ))}
        </ol>
      )}
      {needle && rest.length === 0 && <p className="lb-more">Tidak ada nama yang cocok dengan “{q}”.</p>}
      {hidden > 0 && <p className="lb-more">dan {hidden} siswa lainnya</p>}
      {ordered.length === 0 && <p className="lb-more">Belum ada skor yang masuk.</p>}
    </section>
  );
}

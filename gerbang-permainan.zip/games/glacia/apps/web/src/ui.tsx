import { useEffect, useRef, useState, type ReactNode } from 'react';
import { fmtClock, isMuted, serverTime, setMuted, useNow, type Card, type DqBanner, type Top5 } from './lib';

export function Logo({ small }: { small?: boolean }) {
  return (
    <div className={`logo${small ? ' small' : ''}`} aria-label="GLACIA">
      <svg viewBox="0 0 32 32" width={small ? 22 : 30} height={small ? 22 : 30} aria-hidden>
        <path d="M16 2 28 9v14L16 30 4 23V9z" fill="none" stroke="currentColor" strokeWidth="1.6" />
        <path d="M16 2v28M4 9l24 14M28 9 4 23" stroke="currentColor" strokeWidth="1" opacity=".55" />
      </svg>
      <span>GLACIA</span>
    </div>
  );
}

export function SoundToggle() {
  const [m, setM] = useState(isMuted());
  return (
    <button className="btn ghost sm" onClick={() => { setMuted(!m); setM(!m); }} aria-pressed={!m} title="Suara">
      {m ? 'Suara mati' : 'Suara nyala'}
    </button>
  );
}

export function Panel({ title, children, className = '' }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={`panel ${className}`}>
      {title && <h2 className="panel-title">{title}</h2>}
      {children}
    </section>
  );
}

export function Timer({ endsAt, urgentAt = 15000, label }: { endsAt: number; urgentAt?: number; label?: string }) {
  const now = useNow(200);
  const left = endsAt - now;
  const urgent = left <= urgentAt && left > 0;
  const prev = useRef(0);
  useEffect(() => {
    prev.current = left;
  }, [left]);
  return (
    <div className={`timer${urgent ? ' urgent' : ''}`} role="timer" aria-live="off">
      {label && <small>{label}</small>}
      <b>{fmtClock(left)}</b>
    </div>
  );
}

export function Countdown({ startsAt }: { startsAt: number }) {
  const now = useNow(100);
  const n = Math.max(0, Math.ceil((startsAt - now) / 1000));
  return (
    <div className="count" key={n} aria-live="polite">
      {n > 0 ? n : 'Mulai!'}
    </div>
  );
}

const SEG_FILLS = ['#231f1a', '#f6c945', '#231f1a', '#fffdf8'];

const truncate = (s: string, max: number) => (s.length > max ? `${s.slice(0, Math.max(1, max - 1))}…` : s);

/** Wheel with exactly one segment per eligible name. The winner is fixed by the server; this only animates. */

export function Wheel({ segments, pickedId, animMs, size = 300 }: { segments: { playerId: string; name: string }[]; pickedId?: string; animMs: number; size?: number }) {
  const n = Math.max(1, segments.length);
  const seg = 360 / n;
  const idx = Math.max(0, segments.findIndex((s) => s.playerId === pickedId));
  const target = 360 * 4 - (idx + 0.5) * seg;
  const [rot, setRot] = useState(0);
  useEffect(() => {
    setRot(0);
    const h = requestAnimationFrame(() => requestAnimationFrame(() => setRot(pickedId ? target : 0)));
    return () => cancelAnimationFrame(h);
  }, [pickedId, target]);
  const r = 100;
  const pt = (deg: number, rad: number) => [Math.sin((deg * Math.PI) / 180) * rad, -Math.cos((deg * Math.PI) / 180) * rad] as const;
  return (
    <div className="wheel" style={{ width: size, height: size }}>
      <div className="wheel-pointer" aria-hidden />
      <svg viewBox="-104 -104 208 208" style={{ transform: `rotate(${rot}deg)`, transition: rot === 0 ? 'none' : `transform ${animMs}ms cubic-bezier(.12,.7,.1,1)` }} role="img" aria-label={`Roda berisi ${n} nama`}>
        {n === 1 ? (
          <circle r={r} fill={SEG_FILLS[0]} stroke="#231f1a" strokeWidth="1" />
        ) : (
          segments.map((s, i) => {
            const a0 = i * seg;
            const a1 = (i + 1) * seg;
            const [x0, y0] = pt(a0, r);
            const [x1, y1] = pt(a1, r);
            const mid = a0 + seg / 2;
            // With an odd count the last wedge would touch the first in the same colour: give it the third tone.
            const fill = n % 2 === 1 && i === n - 1 ? '#f2542d' : SEG_FILLS[i % 2 === 0 ? 0 : 1]!;
            const dark = fill === '#231f1a' || fill === '#f2542d';
            // names run along the radius (outer rim → centre), flipped on the left half so they are never upside down
            const arc = (2 * Math.PI * r * 0.72) / n; // wedge width where the text sits
            const fs = Math.max(3.2, Math.min(8, arc * 0.5));
            const maxChars = Math.floor((r * 0.78) / (fs * 0.56));
            const label = n <= 28 ? truncate(s.name.split(' ')[0] ?? s.name, maxChars) : n <= 60 ? s.name.split(' ').map((p) => p[0]).join('').slice(0, 2) : '';
            const flip = mid > 180;
            return (
              <g key={s.playerId}>
                <path d={`M0 0 L${x0} ${y0} A${r} ${r} 0 ${seg > 180 ? 1 : 0} 1 ${x1} ${y1}Z`} fill={fill} stroke="#231f1a" strokeWidth="1" strokeLinejoin="round" />
                {label && (
                  <text
                    transform={`rotate(${flip ? mid + 90 : mid - 90})`}
                    x={flip ? -(r - 7) : r - 7}
                    y="0"
                    textAnchor={flip ? 'start' : 'end'}
                    dominantBaseline="central"
                    fontSize={fs}
                    fontWeight="700"
                    fill={dark ? '#faf6ee' : '#231f1a'}
                  >{label}</text>
                )}
              </g>
            );
          })
        )}
        <circle r="8" fill="#f2542d" stroke="#231f1a" strokeWidth="1.5" />
      </svg>
      <div className="wheel-count">{n} nama</div>
    </div>
  );
}

export function Board({ cards, results, claims, onPick, disabled, flash, cooldownUntil }: { cards: Card[]; results: Record<string, boolean>; claims: Record<string, { playerId: string; name: string }>; onPick: (id: string) => void; disabled: boolean; flash: { cardId: string; correct: boolean; at: number } | null; cooldownUntil: number }) {
  const now = useNow(150);
  const cooling = cooldownUntil > now;
  return (
    <div className="board" onContextMenu={(e) => e.preventDefault()}>
      {cards.map((c) => {
        const res = results[c.cardId];
        const done = res !== undefined;
        const claim = claims[c.cardId];
        const taken = !!claim && !done; // someone else was faster
        const fresh = flash && flash.cardId === c.cardId && Date.now() - flash.at < 900;
        return (
          <button
            key={c.cardId}
            className={`card${done ? (res ? ' ok' : ' bad') : ''}${taken ? ' taken' : ''}${fresh ? ' pop' : ''}${cooling && !done && !taken ? ' cool' : ''}`}
            disabled={disabled || done || taken || cooling}
            onClick={() => { if (!done && !taken && !disabled && !cooling) onPick(c.cardId); }}
            aria-label={done ? (res ? 'Benar, kamu yang klaim' : 'Salah') : taken ? `Sudah diklaim ${claim.name}` : 'Kartu soal'}
          >
            {done && <span className="mark" aria-hidden>{res ? '✓' : '✕'}</span>}
            {taken && <span className="claimer" aria-hidden>{claim.name.split(' ')[0]}</span>}
            <span className="expr" dangerouslySetInnerHTML={{ __html: c.svg }} />
          </button>
        );
      })}
    </div>
  );
}

export function Toast({ toast }: { toast: { text: string; at: number } | null }) {
  const now = useNow(200);
  if (!toast || Date.now() - toast.at > 1600) return <div className="toast-slot" aria-live="polite" />;
  void now;
  return <div className="toast-slot" aria-live="polite"><div className="toast">{toast.text}</div></div>;
}

export function ClaimMeter({ progress }: { progress: { claimed: number; remaining: number } | null }) {
  if (!progress) return null;
  const total = progress.claimed + progress.remaining;
  return (
    <div className="claim-meter" role="status" aria-label={`${progress.claimed} dari ${total} kartu benar sudah diklaim`}>
      <div className="claim-bar"><i style={{ width: `${total ? (progress.claimed / total) * 100 : 0}%` }} /></div>
      <span><b>{progress.remaining}</b> kartu benar tersisa</span>
    </div>
  );
}
export function TopList({ rows, big }: { rows: Top5[]; big?: boolean }) {
  return (
    <ol className={`top${big ? ' big' : ''}`}>
      {rows.map((r, i) => (
        <li key={r.playerId} style={{ ['--i' as string]: i }}>
          <span className="pos">{i + 1}</span>
          <span className="nm">{r.name}</span>
          <b>{r.score.toLocaleString('id-ID')}</b>
        </li>
      ))}
      {rows.length === 0 && <li className="empty">Belum ada skor</li>}
    </ol>
  );
}

export function Podium({ items }: { items: { name: string; score: number; rank: number }[] }) {
  const order = [items.find((i) => i.rank === 2), items.find((i) => i.rank === 1), items.find((i) => i.rank === 3)];
  return (
    <div className="podium">
      {order.map((it, k) =>
        it ? (
          <div key={it.rank} className={`step s${it.rank}`} style={{ animationDelay: `${(k === 1 ? 0.5 : k === 0 ? 0.2 : 0)}s` }}>
            <div className="who"><b>{it.name}</b><small>{it.score.toLocaleString('id-ID')} poin</small></div>
            <div className="block">{it.rank}</div>
          </div>
        ) : <div key={k} className="step ghost" />,
      )}
    </div>
  );
}

export function Banner({ banner }: { banner: DqBanner | null }) {
  const [shown, setShown] = useState<DqBanner | null>(null);
  useEffect(() => {
    if (!banner) return;
    setShown(banner);
    const h = setTimeout(() => setShown(null), 5000);
    return () => clearTimeout(h);
  }, [banner]);
  if (!shown) return null;
  return (
    <div className={`banner ${shown.kind}`} role="alert">
      <span className="crack" aria-hidden />
      <span>{shown.kind === 'dq' ? 'â›” ' : 'âœ… '}{shown.text}</span>
    </div>
  );
}

export function useSecondsLeft(until: number | null | undefined): number {
  const now = useNow(250);
  return until ? Math.max(0, Math.ceil((until - now) / 1000)) : 0;
}

export const nowServer = serverTime;

const AVATARS: [string, string][] = [['#231f1a', '#f6c945'], ['#f2542d', '#fff1e6'], ['#2e9e6b', '#e5f7ee'], ['#f6c945', '#231f1a'], ['#8c5a3c', '#fbe9d3']];
const hash = (s: string) => [...s].reduce((a, c) => (a * 31 + c.charCodeAt(0)) >>> 0, 7);

/** Deterministic ice-crystal avatar: same name, same crystal. No upload, no personal data. */
export function Avatar({ name, size = 40 }: { name: string; size?: number }) {
  const h = hash(name);
  const [bg, fg] = AVATARS[h % AVATARS.length]!;
  const cut = 5 + (h >> 3) % 7;
  const initials = name.split(' ').map((w) => w[0]).slice(0, 2).join('').toUpperCase();
  return (
    <svg className="avatar" width={size} height={size} viewBox="0 0 48 48" role="img" aria-label={`Avatar ${name}`}>
      <path d={`M24 1.5 44 12v24L24 46.5 4 36V12z`} fill={bg} />
      <path d={`M24 1.5 ${24 + cut} 24 24 46.5M24 1.5 ${24 - cut} 24 24 46.5M4 12l20 12 20-12`} fill="none" stroke={fg} strokeOpacity=".28" strokeWidth="1" />
      <text x="24" y="29.5" textAnchor="middle" fontSize="15" fontWeight="700" fill={fg} fontFamily="inherit">{initials}</text>
    </svg>
  );
}

/** The whole class board on the projector. A claimed card turns into the claimer's avatar and first name. */
export function ProjectorBoard({ cards, claims }: { cards: Card[]; claims: Record<string, { playerId: string; name: string }> }) {
  return (
    <div className="pboard" aria-label="Papan kartu kelas">
      {cards.map((c) => {
        const cl = claims[c.cardId];
        return (
          <div key={c.cardId} className={`ptile${cl ? ' taken' : ''}`}>
            <span className="expr" dangerouslySetInnerHTML={{ __html: c.svg }} />
            {cl && (
              <span className="pclaim" key={cl.playerId}>
                <Avatar name={cl.name} size={46} />
                <b>{cl.name.split(' ')[0]}</b>
              </span>
            )}
          </div>
        );
      })}
    </div>
  );
}
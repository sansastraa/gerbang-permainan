import { useEffect, useRef, useState } from 'react';
import { emitAck, useGameSocket, useNow } from './lib';
import { Avatar, Banner, ClaimMeter, Countdown, Logo, ProjectorBoard, Timer, TopList, Wheel } from './ui';
import { Leaderboard, rowsFromRound } from './Leaderboard';

export default function Display({ pin }: { pin: string }) {
  const { socket, view } = useGameSocket();
  const [ok, setOk] = useState<boolean | null>(null);
  const joined = useRef(false);

  useEffect(() => {
    const join = () => {
      void emitAck(socket, 'display:join', { pin }).then((r) => { setOk(r.ok); joined.current = r.ok; });
    };
    socket.on('connect', join);
    if (socket.connected) join();
    return () => { socket.off('connect', join); };
  }, [socket, pin]);

  const st = view.state;
  if (ok === false) return <main className="app display"><div className="panel center"><h1>PIN {pin} tidak ditemukan</h1></div></main>;
  if (!st) return <main className="app display"><div className="panel center"><p>Menyambungkan…</p></div></main>;

  const dqChip = st.disqualifiedCount > 0 && ['RUNNING', 'PAUSED', 'SPIN', 'PICK', 'COUNTDOWN', 'ROUND_RESULT'].includes(st.status);
  let body: React.ReactNode;

  if (view.gameEnd) {
    const g = view.gameEnd;
    body = (
      <div className="d-final">
        <Leaderboard rows={g.finalBoard} variant="display" title="Papan peringkat" />
        {g.disqualified.count > 0 && (
          <p className="d-dq-list">
            Didiskualifikasi: {g.disqualified.mode === 'COUNT_ONLY' ? `${g.disqualified.count} pemain` : g.disqualified.names.join(', ')}
          </p>
        )}
      </div>
    );
  } else if (st.status === 'LOBBY' || st.status === 'CREATED') {
    body = (
      <div className="d-lobby">
        <p className="muted">Buka alamat ini di perangkatmu, lalu masukkan PIN</p>
        <div className="d-pin" aria-label={`PIN ${st.pin}`}>{st.pin.split('').map((c, i) => <span key={i}>{c}</span>)}</div>
        <p className="d-count">{st.players.length} pemain sudah masuk</p>
        <ul className={`d-roster ${st.players.length > 40 ? 'dense' : st.players.length > 16 ? 'mid' : 'roomy'}`}>{st.players.map((p, i) => <li key={p.playerId} style={{ ['--i' as string]: i }}><Avatar name={p.name} size={st.players.length > 40 ? 26 : 34} /><span>{p.name}</span></li>)}</ul>
      </div>
    );
  } else if (view.roundEnd) {
    const r = view.roundEnd;
    body = (
      <div className="d-result">
        <NextIn at={r.nextAt} />
        <Leaderboard
          rows={rowsFromRound(r, view.prevRank)}
          variant="display"
          interim
          kicker={`Peringkat sementara · kotak ${r.roundNo} dari ${r.rounds} · ${r.category.name}`}
          title="Papan peringkat sementara"
        />
        <p className="trick"><b>Trik singkat:</b> {r.trick}</p>
      </div>
    );
  } else if (st.status === 'SPIN' || (st.status === 'PAUSED' && st.prevStatus === 'SPIN')) {
    body = (
      <div className="d-spin2">
        <div className="d-spin2-wheel">
          <Wheel segments={view.wheel} pickedId={view.spin?.pickedPlayerId} animMs={view.spin?.animMs ?? 5000} size={460} />
        </div>
        <div className="d-spin2-side">
          <p className="kicker">Kotak {st.roundNo} dari {st.rounds}</p>
          <h1 className="d-title">Siapa pemilih kategori?</h1>
          <p className="muted">Yang belum pernah memilih ikut berputar. Hasilnya diundi server, bukan oleh layar ini.</p>
          <SpinWinner view={view} />
        </div>
      </div>
    );
  } else if (st.status === 'PICK') {
    body = (
      <div className="d-spin2">
        <div className="d-spin2-wheel">
          <Wheel segments={view.wheel.length ? view.wheel : st.players.map((p) => ({ playerId: p.playerId, name: p.name }))} pickedId={st.pickerId ?? undefined} animMs={0} size={360} />
        </div>
        <div className="d-spin2-side">
          <p className="kicker">Kotak {st.roundNo} dari {st.rounds}</p>
          <div className="winner-card on">{st.pickerName && <Avatar name={st.pickerName} size={84} />}<div><small>Sedang memilih kategori</small><b>{st.pickerName}</b></div></div>
          <PickClock until={st.pickExpiresAt} />
        </div>
      </div>
    );
  } else if (st.status === 'COUNTDOWN' && view.countdown) {
    body = (
      <div className="d-count-screen">
        <p className="kicker">Kotak {st.roundNo} dari {st.rounds}</p>
        <h1 className="d-cat">{view.countdown.category.name}</h1>
        <div className="count-ring"><Countdown startsAt={view.countdown.startsAt} /></div>
        <p className="muted">Siapkan jarimu. Kartu terbuka saat hitungan habis.</p>
      </div>
    );
  } else if ((st.status === 'RUNNING' || st.status === 'PAUSED') && view.round) {
    body = (
      <div className="d-play">
        <ProjectorBoard cards={view.cards} claims={view.claims} />
        <aside className="d-side">
          <div className="d-run-head">
            <div><small>Kotak {view.round.roundNo} dari {view.round.rounds}{view.round.numbersTotal ? ` · ${view.round.numbersTotal} angka` : ''}</small><h1 className="d-cat sm">{view.round.category.name}</h1></div>
            <Timer endsAt={view.round.endsAt} />
          </div>
          {st.status === 'PAUSED' && <div className="pause-note">Dijeda oleh guru</div>}
          <ClaimMeter progress={view.progress} />
          <h3 className="d-side-title">Skor sementara</h3>
          <TopList big rows={view.top5} />
        </aside>
      </div>
    );
  } else {
    body = <div className="d-lobby"><p className="muted">Bersiap…</p></div>;
  }

  return (
    <main className="app display">
      <header className="topbar"><Logo /><span className="chip">PIN {st.pin}</span></header>
      <Banner banner={view.banner} />
      {body}
      {dqChip && <div className="dq-chip" role="status">Diskualifikasi: {st.disqualifiedCount}</div>}
    </main>
  );
}

function SpinWinner({ view }: { view: ReturnType<typeof useGameSocket>['view'] }) {
  const s = view.spin;
  const [show, setShow] = useState(false);
  useEffect(() => {
    setShow(false);
    if (!s) return;
    const h = setTimeout(() => setShow(true), Math.max(0, s.animMs - 300));
    return () => clearTimeout(h);
  }, [s]);
  return (
    <div className={`winner-card${show ? ' on' : ''}`} aria-live="polite">
      {show && s ? (
        <>
          <Avatar name={s.pickedName} size={84} />
          <div><small>Terpilih</small><b>{s.pickedName}</b></div>
        </>
      ) : (
        <div><small>Menunggu roda berhenti…</small><b>&nbsp;</b></div>
      )}
    </div>
  );
}

function PickClock({ until }: { until: number | null }) {
  const now = useNow(250);
  const s = until ? Math.max(0, Math.ceil((until - now) / 1000)) : 0;
  return until ? <p className="pick-clock"><b>{s}</b> detik lagi, lewat itu kategori dipilih acak</p> : null;
}

function NextIn({ at }: { at: number }) {
  const now = useNow(500);
  const s = Math.max(0, Math.ceil((at - now) / 1000));
  return <p className="d-next">Kotak berikutnya dimulai <b>{s}</b> detik lagi</p>;
}
import { normalizeBasePath } from '../../../packages/shared/src/basepath';

export { normalizeBasePath };

/** Vite's BASE_URL is '/' or '/games/glacia/'; the rest of the app wants '' or '/games/glacia'. */
export const basePathOf = (baseUrl: string): string => normalizeBasePath(baseUrl);

/** REST endpoint under the prefix: https://host/games/glacia/api/rooms */
export const apiUrlFor = (origin: string, base: string, path: string): string => `${origin}${base}/api${path}`;

/** socket.io is mounted at `<base>/socket.io` on the server. */
export const socketPathFor = (base: string): string => `${base}/socket.io`;

/** Address a student opens (and the QR encodes): the prefix is always part of it. */
export const pageUrlFor = (origin: string, base: string, hashRoute: string): string => `${origin}${base}/#${hashRoute}`;

export interface Route {
  path: string;
  query: URLSearchParams;
}

/**
 * Which screen to show. The hash wins (#/host, #/play?pin=...); with no hash the PATH under the prefix is used, because
 * that is how SIMPETERI's Multi Permainan opens the teacher console: `{alamat}/host`.
 */
export function routeFrom(pathname: string, hash: string, search: string, base: string): Route {
  const h = hash.replace(/^#/, '');
  if (hash !== '' && hash !== '#') {
    const [path = '/', qs = ''] = h.split('?');
    return { path: path || '/', query: new URLSearchParams(qs) };
  }
  let p = pathname;
  if (base && (p === base || p.startsWith(`${base}/`))) p = p.slice(base.length);
  p = p.replace(/\/+$/, '');
  return { path: p === '' ? '/' : p, query: new URLSearchParams(search) };
}

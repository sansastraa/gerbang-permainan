import react from '@vitejs/plugin-react';
import { defineConfig } from 'vite';
import { normalizeBasePath } from '../../packages/shared/src/basepath';

// BASE_PATH=/games/glacia npm run build -w apps/web  →  every asset URL carries the prefix (served behind SIMPETERI's gateway)
const base = normalizeBasePath(process.env.BASE_PATH);

export default defineConfig({
  base: base ? `${base}/` : '/',
  plugins: [react()],
  server: { port: 3000, host: true },
  build: { outDir: 'dist', sourcemap: false },
});
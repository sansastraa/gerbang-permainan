export interface TimerHandle {
  cancel(): void;
}

/** Injectable time source so the whole game can be driven by a controlled clock in tests. */
export interface Clock {
  now(): number;
  setTimeout(fn: () => void, ms: number): TimerHandle;
}

export class RealClock implements Clock {
  now(): number {
    return Date.now();
  }
  setTimeout(fn: () => void, ms: number): TimerHandle {
    const h = setTimeout(fn, Math.max(0, ms));
    return { cancel: () => clearTimeout(h) };
  }
}

interface Pending {
  at: number;
  seq: number;
  fn: () => void;
  cancelled: boolean;
}

/** Deterministic clock: time only moves through advance(). */
export class ManualClock implements Clock {
  private t: number;
  private seq = 0;
  private pending: Pending[] = [];
  constructor(start = 1_700_000_000_000) {
    this.t = start;
  }
  now(): number {
    return this.t;
  }
  setTimeout(fn: () => void, ms: number): TimerHandle {
    const p: Pending = { at: this.t + Math.max(0, ms), seq: this.seq++, fn, cancelled: false };
    this.pending.push(p);
    return {
      cancel: () => {
        p.cancelled = true;
      },
    };
  }
  /** Moves time forward, firing due timers in order (timers created while advancing also fire if due). */
  advance(ms: number): void {
    const target = this.t + ms;
    for (;;) {
      this.pending = this.pending.filter((p) => !p.cancelled);
      const due = this.pending.filter((p) => p.at <= target).sort((a, b) => a.at - b.at || a.seq - b.seq)[0];
      if (!due) break;
      this.pending = this.pending.filter((p) => p !== due);
      this.t = Math.max(this.t, due.at);
      due.fn();
    }
    this.t = target;
  }
  get pendingCount(): number {
    return this.pending.filter((p) => !p.cancelled).length;
  }
}

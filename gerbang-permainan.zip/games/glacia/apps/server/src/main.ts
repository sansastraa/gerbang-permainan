import fs from 'node:fs';
import { loadConfig } from './config';
import { loadQuestionRepository } from './bank';
import { buildServer } from './server';

const config = loadConfig();
if (!fs.existsSync(config.bankPath)) {
  console.error(`Bank soal belum diimpor: ${config.bankPath} tidak ada. Jalankan "npm run import-bank".`);
  process.exit(1);
}
const repo = loadQuestionRepository(config.bankPath);
const server = buildServer({ config, repo });
const port = await server.listen(config.port, config.host);
console.log(`GLACIA server siap di :${port} (soal: ${repo.count()}, SIMPETERI: ${config.simpeteriMode})`);
if (config.simpeteriMode === 'mandiri') console.log('Mode mandiri: guru menempel daftar siswa sendiri saat membuka ruangan');
else console.log('Mode multi: guru masuk dari menu Multi Permainan SIMPETERI (PIN guru = HOST_PIN)');
if (config.hostPinDefaulted) console.log('HOST_PIN belum diisi: PIN guru pengembangan = guru1234 (WAJIB diisi di produksi)');

const stop = () => {
  void server.close().then(() => process.exit(0));
};
process.on('SIGINT', stop);
process.on('SIGTERM', stop);

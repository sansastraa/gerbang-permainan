import { normalizeBasePath } from '@glacia/shared';
import path from 'node:path';

export interface ServerConfig {
  port: number;
  host: string;
  allowedOrigins: string[]; // empty = allow any origin (development only)
  jwtSecret: string;
  pinLength: number;
  simpeteriMode: 'multi' | 'mandiri';
  hostPin: string;
  /** true when HOST_PIN was not set (development only): the server prints the PIN it picked */
  hostPinDefaulted: boolean;
  dataDir: string;
  bankPath: string;
  staticDir: string | null;
  outboxBaseDelayMs: number;
  joinLimitPerMin: number;
  wsDeflate: boolean;
  /** URL prefix when served behind a gateway (e.g. /games/glacia); '' = at the root */
  basePath: string;
  /** believe X-Forwarded-For (last hop) for per-client limits; only enable behind a gateway you control */
  trustProxy: boolean;
}

export function loadConfig(env: NodeJS.ProcessEnv = process.env): ServerConfig {
  const dataDir = path.resolve(env.DATA_DIR ?? path.join(process.cwd(), '..', '..', 'data'));
  const origins = (env.ALLOWED_ORIGINS ?? env.CORS_ORIGIN ?? '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const secret = env.JWT_SECRET ?? 'change-me';
  const pinGiven = (env.HOST_PIN ?? '').trim();
  if (env.NODE_ENV === 'production' && !/^\S{4,32}$/.test(pinGiven)) throw new Error('HOST_PIN must be set (4-32 characters, no spaces) in production');
  const hostPin = pinGiven || 'guru1234';
  if (env.NODE_ENV === 'production' && secret === 'change-me') {
    throw new Error('JWT_SECRET must be set in production');
  }
  return {
    port: Number(env.PORT ?? 4000),
    host: env.HOST ?? '0.0.0.0',
    allowedOrigins: origins,
    jwtSecret: secret,
    pinLength: Number(env.ROOM_PIN_LENGTH ?? 6),
    simpeteriMode: env.SIMPETERI_MODE === 'multi' ? 'multi' : 'mandiri',
    hostPin,
    hostPinDefaulted: pinGiven === '',
    dataDir,
    bankPath: path.resolve(env.BANK_PATH ?? path.join(dataDir, 'questions.json')),
    staticDir: env.STATIC_DIR ? path.resolve(env.STATIC_DIR) : null,
    outboxBaseDelayMs: Number(env.OUTBOX_BASE_DELAY_MS ?? 500),
    joinLimitPerMin: Number(env.JOIN_LIMIT_PER_MIN ?? 10),
    wsDeflate: env.WS_DEFLATE !== '0',
    basePath: normalizeBasePath(env.BASE_PATH),
    trustProxy: env.TRUST_PROXY === '1',
  };
}

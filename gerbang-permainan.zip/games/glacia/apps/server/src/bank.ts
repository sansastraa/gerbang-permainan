import fs from 'node:fs';
import type { PoolQuestion, Tier } from '@glacia/shared';

export interface BankCategory {
  id: number;
  name: string;
  trick: string;
}

/** A question as stored server-side. NEVER send this object (or isCorrect/result/explanation) to a client mid-round. */
export interface StoredQuestion extends PoolQuestion {
  categoryId: number;
  exprText: string;
  svg: string;
  kind: string;
  result: number;
  unitDigit: number;
  parity: string;
  explanation: string;
}

export interface QuestionRepository {
  categories(): BankCategory[];
  category(id: number): BankCategory | undefined;
  pool(categoryId: number): StoredQuestion[];
  get(id: string): StoredQuestion | undefined;
  count(): number;
}

export class InMemoryQuestionRepository implements QuestionRepository {
  private cats: BankCategory[];
  private byCat = new Map<number, StoredQuestion[]>();
  private byId = new Map<string, StoredQuestion>();
  constructor(cats: BankCategory[], questions: StoredQuestion[]) {
    this.cats = cats;
    for (const q of questions) {
      this.byId.set(q.id, q);
      const l = this.byCat.get(q.categoryId) ?? [];
      l.push(q);
      this.byCat.set(q.categoryId, l);
    }
  }
  categories() {
    return this.cats;
  }
  category(id: number) {
    return this.cats.find((c) => c.id === id);
  }
  pool(categoryId: number) {
    return this.byCat.get(categoryId) ?? [];
  }
  get(id: string) {
    return this.byId.get(id);
  }
  count() {
    return this.byId.size;
  }
}

export interface QuestionStoreFile {
  versi: string;
  categories: BankCategory[];
  questions: StoredQuestion[];
}

export function loadQuestionRepository(file: string): QuestionRepository {
  const raw = JSON.parse(fs.readFileSync(file, 'utf8')) as QuestionStoreFile;
  return new InMemoryQuestionRepository(raw.categories, raw.questions);
}

export const TIER_FROM_ID: Record<string, Tier> = { Mudah: 'EASY', Sedang: 'MEDIUM', Menantang: 'HARD' };

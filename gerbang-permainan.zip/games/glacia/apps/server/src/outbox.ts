import type { GameResultPayload } from '@glacia/shared';
import type { SimpeteriPort } from './integration';
import type { Store } from './store';

/** Exponential retry, 3 attempts (blueprint 9). Returns the last error message when all attempts fail. */
export async function withRetry<T>(fn: () => Promise<T>, baseDelayMs: number): Promise<{ ok: true; value: T } | { ok: false; error: string }> {
  let last = '';
  for (let i = 0; i < 3; i++) {
    try {
      return { ok: true, value: await fn() };
    } catch (e) {
      last = (e as Error).message;
      if (i < 2) await new Promise((res) => setTimeout(res, baseDelayMs * 2 ** i));
    }
  }
  return { ok: false, error: last };
}

/** Re-sends every pending outbox row once. Used by the host dashboard ("kirim ulang"). */
export async function flushOutbox(store: Store, port: SimpeteriPort): Promise<{ sent: number; failed: number }> {
  let sent = 0;
  let failed = 0;
  for (const row of store.pendingOutbox()) {
    try {
      if (row.type === 'RESULT') await port.submitResults(row.payload as GameResultPayload);
      else if (row.type === 'BLACKLIST') {
        const p = row.payload as { rowId: string; studentId: string; reason: string; evidence: unknown; roomId: string };
        await port.blacklistStudent(p.studentId, p.reason, p.evidence, p.roomId);
        store.markSynced(p.rowId);
      } else {
        const p = row.payload as { studentId: string; actorId: string; note: string };
        await port.liftBlacklist(p.studentId, p.actorId, p.note);
      }
      store.updateOutbox(row.id, { done: true, attempts: row.attempts + 1, lastError: null });
      sent++;
    } catch (e) {
      store.updateOutbox(row.id, { attempts: row.attempts + 1, lastError: (e as Error).message });
      failed++;
    }
  }
  return { sent, failed };
}

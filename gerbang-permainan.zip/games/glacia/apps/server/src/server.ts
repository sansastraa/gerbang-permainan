import http from 'node:http';
import path from 'node:path';
import type { ServerConfig } from './config';
import { RealClock, type Clock } from './clock';
import { createApp } from './http';
import { attachGateway, SocketEmitter } from './gateway';
import { HandoffSimpeteriAdapter, type SimpeteriPort } from './integration';
import { RoomManager } from './manager';
import { Store } from './store';
import type { QuestionRepository } from './bank';
import type { Timings } from './room';

export interface BuildOpts {
  config: ServerConfig;
  repo: QuestionRepository;
  clock?: Clock;
  port?: SimpeteriPort;
  store?: Store;
  timings?: Partial<Timings>;
  joinLimitPerMin?: number;
}

/** Wires app + socket gateway. Used by main.ts, the integration tests and the bots. */
export function buildServer(o: BuildOpts) {
  const clock = o.clock ?? new RealClock();
  const port =
    o.port ?? new HandoffSimpeteriAdapter(o.config.hostPin);
  const store = o.store ?? new Store(path.join(o.config.dataDir, 'runtime', 'state.json'));
  const emitter = new SocketEmitter();
  const manager = new RoomManager({ clock, repo: o.repo, store, port, emitter, outboxBaseDelayMs: o.config.outboxBaseDelayMs, timings: o.timings }, o.config.pinLength);
  const app = createApp({
    manager, store, port, repo: o.repo, clock, mode: o.config.simpeteriMode, basePath: o.config.basePath, trustProxy: o.config.trustProxy,
    jwtSecret: o.config.jwtSecret, allowedOrigins: o.config.allowedOrigins, staticDir: o.config.staticDir, outboxBaseDelayMs: o.config.outboxBaseDelayMs,
  });
  const httpServer = http.createServer(app);
  const gw = attachGateway({ http: httpServer, manager, emitter, jwtSecret: o.config.jwtSecret, clock, allowedOrigins: o.config.allowedOrigins, joinLimitPerMin: o.joinLimitPerMin ?? o.config.joinLimitPerMin, deflate: o.config.wsDeflate, basePath: o.config.basePath, trustProxy: o.config.trustProxy });
  const sweeper = setInterval(() => manager.sweep(clock.now()), 10 * 60_000);
  sweeper.unref();
  return {
    app, httpServer, io: gw.io, manager, store, port, clock,
    listen: (port_: number, host = '127.0.0.1') => new Promise<number>((resolve) => httpServer.listen(port_, host, () => resolve((httpServer.address() as { port: number }).port))),
    close: async () => {
      clearInterval(sweeper);
      store.flush();
      await gw.io.close();
    },
  };
}

import fs from 'node:fs';
import path from 'node:path';
import express, { type NextFunction, type Request, type Response, type Router } from 'express';
import { z } from 'zod';
import { signHostJwt, verifyHostJwt, type HostClaims } from './auth';
import type { QuestionRepository } from './bank';
import type { Clock } from './clock';
import type { SimpeteriPort } from './integration';
import type { RoomManager } from './manager';
import { flushOutbox, withRetry } from './outbox';
import { reportCsv } from './report';
import type { Store } from './store';

export interface AppDeps {
  manager: RoomManager;
  store: Store;
  port: SimpeteriPort;
  repo: QuestionRepository;
  clock: Clock;
  jwtSecret: string;
  allowedOrigins: string[];
  staticDir: string | null;
  outboxBaseDelayMs: number;
  /** mandiri = the teacher pastes the names; multi = behind SIMPETERI Multi Permainan. The roster always arrives with POST /rooms. */
  mode: 'multi' | 'mandiri';
  /** '' or a prefix like /games/glacia: API, socket.io and the web client all live under it */
  basePath: string;
  trustProxy: boolean;
}

const RosterSchema = z.array(z.object({ id: z.string().trim().min(1).max(100), name: z.string().trim().min(1).max(80), absen: z.number().int().optional() })).min(1).max(100);

type AuthedRequest = Request & { claims: HostClaims };
const hostOf = (req: Request) => (req as AuthedRequest).claims;

export function createApp(d: AppDeps) {
  const app = express();
  app.disable('x-powered-by');
  if (d.trustProxy) app.set('trust proxy', 1); // behind our own gateway: req.ip = the client it appended to X-Forwarded-For
  app.use(express.json({ limit: '200kb' }));

  app.use((req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (d.allowedOrigins.length === 0 || d.allowedOrigins.includes(origin))) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Vary', 'Origin');
      res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type, x-host-token');
      res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,OPTIONS');
    }
    if (req.method === 'OPTIONS') return res.sendStatus(204);
    next();
  });

  /** 20 attempts per minute per IP and kind: the teacher PIN is only 4-32 characters, so it must not be guessable by hammering. */
  const hits = new Map<string, number[]>();
  const tooMany = (req: Request, kind: string) => {
    const k = `${kind}:${req.ip ?? ''}`;
    const now = d.clock.now();
    const list = (hits.get(k) ?? []).filter((t) => now - t < 60_000);
    list.push(now);
    hits.set(k, list);
    return list.length > 20;
  };

  const auth = (req: Request, res: Response, next: NextFunction) => {
    const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? '');
    const claims = m ? verifyHostJwt(m[1] as string, d.jwtSecret, d.clock.now()) : null;
    if (!claims) return res.status(401).json({ ok: false, code: 'UNAUTHORIZED' });
    (req as AuthedRequest).claims = claims;
    next();
  };
  const ownRoom = (req: Request, res: Response) => {
    const room = d.manager.get(String(req.params.id));
    if (!room || room.hostId !== hostOf(req).hostId) {
      res.status(404).json({ ok: false, code: 'NOT_FOUND' });
      return undefined;
    }
    return room;
  };

  const r: Router = express.Router();

  r.get('/health', (_req, res) => {
    res.json({ ok: true, uptime: Math.round(process.uptime()), rooms: d.manager.rooms.size, questions: d.repo.count() });
  });

  /** What the web client needs to know before login: whether it is behind SIMPETERI's Multi Permainan, and who may talk to it. */
  r.get('/config', (_req, res) => {
    res.json({ ok: true, mode: d.mode, simpeteriOrigins: d.allowedOrigins });
  });

  r.post('/auth/host', async (req, res) => {
    if (tooMany(req, 'login')) return res.status(429).json({ ok: false, code: 'RATE_LIMITED' });
    const token = z.object({ token: z.string().min(1) }).safeParse(req.body);
    if (!token.success) return res.status(400).json({ ok: false, code: 'BAD_REQUEST' });
    try {
      const who = await d.port.verifyHostToken(token.data.token);
      res.json({ ok: true, jwt: signHostJwt(who, d.jwtSecret, d.clock.now()), host: who });
    } catch {
      res.status(401).json({ ok: false, code: 'UNAUTHORIZED' });
    }
  });

  r.get('/classes', auth, async (req, res) => {
    const classes = await d.port.listClasses(hostOf(req).hostId);
    res.json({ ok: true, classes: classes.filter((c) => hostOf(req).classIds.includes(c.id)) });
  });

  r.get('/categories', auth, (_req, res) => {
    res.json({ ok: true, categories: d.repo.categories() });
  });

  r.post('/rooms', auth, async (req, res) => {
    try {
      const { roster: rawRoster, ...settingsInput } = (req.body ?? {}) as Record<string, unknown>;
      let handoff: { studentId: string; name: string }[] | undefined;
      if (rawRoster !== undefined) {
        // the class list SIMPETERI pushed (postMessage); ids are siswa.id so the results can be matched back
        const parsed = RosterSchema.safeParse(rawRoster);
        if (!parsed.success) return res.status(400).json({ ok: false, code: 'BAD_ROSTER' });
        if (new Set(parsed.data.map((s) => s.id)).size !== parsed.data.length) return res.status(400).json({ ok: false, code: 'BAD_ROSTER' });
        handoff = parsed.data.map((s) => ({ studentId: s.id, name: s.name }));
      }
      const room = await d.manager.create(hostOf(req), settingsInput as unknown as Parameters<typeof d.manager.create>[1], handoff);
      res.json({ ok: true, roomId: room.id, pin: room.pin });
    } catch (e) {
      const msg = (e as Error).message;
      if (e instanceof z.ZodError) return res.status(400).json({ ok: false, code: 'BAD_SETTINGS', issues: e.issues });
      res.status(msg === 'CLASS_NOT_ALLOWED' ? 403 : 400).json({ ok: false, code: msg });
    }
  });

  r.get('/rooms', auth, (req, res) => {
    const live = d.manager.listFor(hostOf(req).hostId).map((x) => ({ roomId: x.id, pin: x.pin, status: x.status, classId: x.settings.classId, createdAt: x.createdAt }));
    const done = d.store
      .listRooms(hostOf(req).hostId)
      .map((x) => {
        const s = x.summary as { rounds?: number; students?: { name: string; rank: number | null; score: number }[] };
        const first = s.students?.find((st) => st.rank === 1);
        return { roomId: x.roomId, classId: x.classId, playedAt: x.playedAt, finished: true, students: s.students?.length ?? 0, rounds: s.rounds ?? 0, winner: first?.name ?? null, topScore: first?.score ?? 0, exportKey: x.exportKey };
      })
      .sort((a, b) => b.playedAt - a.playedAt);
    res.json({ ok: true, live, done });
  });

  r.get('/rooms/:id', auth, (req, res) => {
    const room = ownRoom(req, res);
    if (room) res.json({ ok: true, room: room.hostView() });
  });

  r.patch('/rooms/:id/settings', auth, async (req, res) => {
    const room = ownRoom(req, res);
    if (!room) return;
    try {
      const { parseSettings } = await import('@glacia/shared');
      const result = room.updateSettings(parseSettings({ ...room.settings, ...(req.body ?? {}), classId: room.settings.classId }));
      res.status(result.ok ? 200 : 409).json(result);
    } catch (e) {
      res.status(400).json({ ok: false, code: 'BAD_SETTINGS', message: (e as Error).message });
    }
  });

  const reportFor = (id: string, hostId: string) => {
    const live = d.manager.get(id);
    if (live && live.hostId === hostId) return live.report ? { payload: live.report.payload, summary: live.report.summary, finalBoard: live.report.finalBoard } : null;
    const saved = d.store.getRoom(id);
    return saved && saved.hostId === hostId ? { payload: saved.payload, summary: saved.summary, finalBoard: [] } : null;
  };

  r.get('/rooms/:id/report', auth, (req, res) => {
    const rep = reportFor(String(req.params.id), hostOf(req).hostId);
    if (!rep) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    res.json({ ok: true, ...rep });
  });

  r.get('/rooms/:id/report.csv', auth, (req, res) => {
    const rep = reportFor(String(req.params.id), hostOf(req).hostId);
    if (!rep) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', `attachment; filename="glacia-${String(req.params.id).slice(0, 8)}.csv"`);
    res.send(reportCsv(rep.summary as never, d.repo.categories()));
  });

  /** Summary for SIMPETERI "Buat Multi Permainan": host JWT, or the room's unguessable exportKey (?key=). */
  r.get('/rooms/:id/summary.json', (req, res) => {
    const id = String(req.params.id);
    const key = String(req.query.key ?? '');
    const live = d.manager.get(id);
    const saved = d.store.getRoom(id);
    const expected = live?.exportKey ?? saved?.exportKey;
    const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? '');
    const claims = m ? verifyHostJwt(m[1] as string, d.jwtSecret, d.clock.now()) : null;
    const hostOk = !!claims && (live?.hostId === claims.hostId || saved?.hostId === claims.hostId);
    if (!expected || (!hostOk && key !== expected)) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    const summary = live?.report?.summary ?? saved?.summary;
    if (!summary) return res.status(409).json({ ok: false, code: 'NOT_FINISHED' });
    res.json(summary);
  });

  /**
   * The URL SIMPETERI's Multi Permainan menu builds itself: `{server}/api/sessions/{gameSesi}/summary.json` with the
   * teacher PIN in `x-host-token`. Status codes follow what that page explains to the teacher: 404 unknown session,
   * 401 wrong PIN, 403 not finished yet. (The host JWT and ?key= work too.)
   */
  r.get('/sessions/:id/summary.json', async (req, res) => {
    const id = String(req.params.id);
    if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    const live = d.manager.get(id);
    const saved = d.store.getRoom(id);
    if (!live && !saved) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    let allowed = false;
    const pin = String(req.headers['x-host-token'] ?? '');
    if (pin) {
      if (tooMany(req, 'pin')) return res.status(429).json({ ok: false, code: 'RATE_LIMITED' });
      allowed = await d.port.verifyHostToken(pin).then(() => true, () => false);
    }
    const m = /^Bearer (.+)$/.exec(req.headers.authorization ?? '');
    if (!allowed && m) allowed = !!verifyHostJwt(m[1] as string, d.jwtSecret, d.clock.now());
    if (!allowed && req.query.key && String(req.query.key) === (live?.exportKey ?? saved?.exportKey)) allowed = true;
    if (!allowed) return res.status(401).json({ ok: false, code: 'UNAUTHORIZED' });
    const summary = live?.report?.summary ?? saved?.summary;
    if (!summary) return res.status(403).json({ ok: false, code: 'NOT_FINISHED' });
    res.json(summary);
  });

  r.post('/rooms/:id/report/resend', auth, async (req, res) => {
    const room = ownRoom(req, res);
    if (!room) return;
    const out = await room.submitReport();
    res.status(out.ok ? 200 : 502).json(out);
  });

  r.get('/rooms/:id/cheat-flags', auth, (req, res) => {
    const room = ownRoom(req, res);
    if (room) res.json({ ok: true, flags: room.flags });
  });

  const reasonBody = z.object({ reason: z.string().trim().min(3).max(300), blacklist: z.boolean().optional() });
  r.post('/rooms/:id/players/:playerId/disqualify', auth, (req, res) => {
    const room = ownRoom(req, res);
    if (!room) return;
    const body = reasonBody.safeParse(req.body);
    if (!body.success) return res.status(400).json({ ok: false, code: 'REASON_REQUIRED' });
    const out = room.disqualify(String(req.params.playerId), 'HOST_MANUAL', { actorId: hostOf(req).hostId, blacklist: body.data.blacklist === true, note: body.data.reason });
    res.status(out.ok ? 200 : 404).json(out);
  });

  r.post('/rooms/:id/players/:playerId/reinstate', auth, (req, res) => {
    const room = ownRoom(req, res);
    if (!room) return;
    const out = room.reinstate(String(req.params.playerId), hostOf(req).hostId);
    res.status(out.ok ? 200 : 409).json(out);
  });

  r.get('/blacklist', auth, (req, res) => {
    const active = req.query.active === undefined ? undefined : req.query.active !== 'false';
    const classId = req.query.classId ? String(req.query.classId) : undefined;
    const rows = d.store.listBlacklist({ classId, active }).filter((b) => hostOf(req).classIds.includes(b.classId));
    res.json({ ok: true, rows });
  });

  r.post('/blacklist/:studentId/lift', auth, async (req, res) => {
    const body = z.object({ note: z.string().trim().min(3).max(300) }).safeParse(req.body);
    if (!body.success) return res.status(400).json({ ok: false, code: 'NOTE_REQUIRED' });
    const studentId = String(req.params.studentId);
    const active = d.store.activeBlacklist(studentId);
    if (!active || !hostOf(req).classIds.includes(active.classId)) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
    const rows = d.store.liftBlacklist(studentId, hostOf(req).hostId, body.data.note, d.clock.now());
    d.store.addAudit(hostOf(req).hostId, 'BLACKLIST_LIFT', studentId, { note: body.data.note, rows: rows.length }, d.clock.now());
    for (const room of d.manager.rooms.values()) {
      const p = room.playerByStudent(studentId);
      if (p) p.blacklisted = false;
    }
    const sync = await withRetry(() => d.port.liftBlacklist(studentId, hostOf(req).hostId, body.data.note), d.outboxBaseDelayMs);
    if (!sync.ok) d.store.addOutbox('LIFT', { studentId, actorId: hostOf(req).hostId, note: body.data.note }, sync.error, d.clock.now());
    res.json({ ok: true, syncedToSimpeteri: sync.ok });
  });

  r.get('/audit', auth, (_req, res) => {
    res.json({ ok: true, rows: d.store.listAudit().slice(-200) });
  });

  r.get('/outbox', auth, (_req, res) => {
    res.json({ ok: true, rows: d.store.pendingOutbox().map((o) => ({ id: o.id, type: o.type, attempts: o.attempts, lastError: o.lastError, createdAt: o.createdAt })) });
  });
  r.post('/outbox/flush', auth, async (_req, res) => {
    res.json({ ok: true, ...(await flushOutbox(d.store, d.port)) });
  });

  const base = d.basePath;
  app.use(`${base}/api`, r);
  if (!base) app.use('/', r); // un-prefixed routes stay for tools written before BASE_PATH existed

  if (d.staticDir && fs.existsSync(d.staticDir)) {
    const index = path.join(d.staticDir, 'index.html');
    // index.html is served by the fallback below for every page, so "/" and "/host" behave the same
    app.use(base || '/', express.static(d.staticDir, { index: false }));
    app.get(base ? [base, `${base}/*`] : '*', (req, res) => {
      const sub = req.path.slice(base.length);
      if (sub.startsWith('/api/') || sub.startsWith('/socket.io')) return res.status(404).json({ ok: false, code: 'NOT_FOUND' });
      res.sendFile(index);
    });
  }
  return app;
}
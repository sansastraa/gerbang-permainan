import { createHmac, timingSafeEqual } from 'node:crypto';

export interface HostClaims {
  hostId: string;
  name: string;
  classIds: string[];
  exp: number; // epoch ms
}

const b64 = (s: string | Buffer) => Buffer.from(s).toString('base64url');

/** Minimal HS256 JWT (no external dependency). Short-lived host sessions. */
export function signHostJwt(claims: Omit<HostClaims, 'exp'>, secret: string, now: number, ttlMs = 6 * 3600_000): string {
  const header = b64(JSON.stringify({ alg: 'HS256', typ: 'JWT' }));
  const body = b64(JSON.stringify({ ...claims, exp: now + ttlMs }));
  const sig = createHmac('sha256', secret).update(`${header}.${body}`).digest('base64url');
  return `${header}.${body}.${sig}`;
}

export function verifyHostJwt(token: string, secret: string, now: number): HostClaims | null {
  const parts = token.split('.');
  if (parts.length !== 3) return null;
  const [h, b, s] = parts as [string, string, string];
  const expected = createHmac('sha256', secret).update(`${h}.${b}`).digest();
  let given: Buffer;
  try {
    given = Buffer.from(s, 'base64url');
  } catch {
    return null;
  }
  if (given.length !== expected.length || !timingSafeEqual(given, expected)) return null;
  try {
    const claims = JSON.parse(Buffer.from(b, 'base64url').toString('utf8')) as HostClaims;
    return claims.exp > now ? claims : null;
  } catch {
    return null;
  }
}

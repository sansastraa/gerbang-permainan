import {
  rankStandings,
  type GameResultPayload,
  type GlaciaSummary,
  type PerCategoryStat,
  type StudentResult,
} from '@glacia/shared';
import type { QuestionRepository } from './bank';
import type { Room } from './room';

export interface FinalRow {
  rank: number;
  playerId: string;
  name: string;
  score: number;
  correct: number;
  wrong: number;
}

export interface Report {
  payload: GameResultPayload;
  summary: GlaciaSummary;
  finalBoard: FinalRow[];
}

/** Builds the end-of-game report from the room's raw answers. DISQUALIFIED students keep raw stats but score 0. */
export function buildReport(room: Room, repo: QuestionRepository): Report {
  const stats = [...room.players.values()].map((p) => {
    const mine = room.answers.filter((a) => a.playerId === p.id);
    const per = new Map<number, PerCategoryStat>();
    for (const a of mine) {
      const s = per.get(a.categoryId) ?? { categoryId: a.categoryId, attempted: 0, correct: 0, wrong: 0 };
      s.attempted++;
      if (a.correct) s.correct++;
      else s.wrong++;
      per.set(a.categoryId, s);
    }
    const correct = mine.filter((a) => a.correct).length;
    const think = mine.map((a) => a.thinkMs);
    return {
      p,
      correct,
      wrong: mine.length - correct,
      avgThinkMs: think.length ? Math.round(think.reduce((x, y) => x + y, 0) / think.length) : 0,
      perCategory: [...per.values()].sort((a, b) => a.categoryId - b.categoryId),
    };
  });

  const valid = rankStandings(
    stats
      .filter((s) => !s.p.removed)
      .map((s) => ({
        playerId: s.p.id,
        totalScore: s.p.totalScore,
        correct: s.correct,
        wrong: s.wrong,
        avgThinkMs: s.avgThinkMs,
        disqualified: s.p.disqualified,
      })),
  );
  const rankOf = new Map(valid.map((v, i) => [v.playerId, i + 1]));
  const rest = stats.filter((s) => !rankOf.has(s.p.id)).sort((a, b) => a.p.name.localeCompare(b.p.name));
  rest.forEach((s, i) => rankOf.set(s.p.id, valid.length + i + 1));

  const students: StudentResult[] = stats
    .map((s) => ({
      studentId: s.p.studentId,
      rank: rankOf.get(s.p.id) as number,
      totalScore: s.p.disqualified ? 0 : s.p.totalScore,
      correct: s.correct,
      wrong: s.wrong,
      avgThinkMs: s.avgThinkMs,
      status: s.p.disqualified ? ('DISQUALIFIED' as const) : ('OK' as const),
      blacklisted: s.p.blacklisted,
      ...(s.p.disqualified ? { disqualifyReason: s.p.dqReason ?? 'UNKNOWN' } : {}),
      perCategory: s.perCategory,
    }))
    .sort((a, b) => a.rank - b.rank);

  const playedAt = new Date(room.endedAt ?? Date.now()).toISOString();
  const payload: GameResultPayload = { roomId: room.id, classId: room.settings.classId, playedAt, students };
  const nameOf = new Map(stats.map((s) => [s.p.studentId, s.p.name]));
  const summary: GlaciaSummary = {
    game: 'glacia',
    version: 2,
    sessionId: room.id,
    classId: room.settings.classId,
    playedAt,
    rounds: room.roundHistory.length,
    students: students.map((s) => ({
      studentId: s.studentId,
      name: nameOf.get(s.studentId) ?? s.studentId,
      rank: s.status === 'OK' ? s.rank : null,
      points: s.totalScore,
      attempts: s.correct + s.wrong,
      profile: Object.fromEntries(s.perCategory.map((c) => [repo.category(c.categoryId)?.name ?? `Kategori ${c.categoryId}`, c.attempted >= 3 ? Math.round((c.correct / c.attempted) * 100) : null])),
      score: s.totalScore,
      correct: s.correct,
      wrong: s.wrong,
      accuracy: s.correct + s.wrong > 0 ? Math.round((s.correct / (s.correct + s.wrong)) * 1000) / 1000 : 0,
      avgThinkMs: s.avgThinkMs,
      status: s.status,
      blacklisted: s.blacklisted,
      perCategory: s.perCategory.map((c) => ({ ...c, category: repo.category(c.categoryId)?.name ?? `Kategori ${c.categoryId}` })),
    })),
  };
  const finalBoard: FinalRow[] = valid.map((v, i) => {
    const s = stats.find((x) => x.p.id === v.playerId)!;
    return { rank: i + 1, playerId: v.playerId, name: s.p.name, score: v.totalScore, correct: s.correct, wrong: s.wrong };
  });
  return { payload, summary, finalBoard };
}

const csvCell = (v: string | number | boolean | null): string => {
  const s = v === null ? '' : String(v);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};

/** CSV (UTF-8 with BOM so Excel shows Indonesian names correctly). */
export function reportCsv(summary: GlaciaSummary, categories: { id: number; name: string }[]): string {
  const head = ['Peringkat', 'Nama', 'ID Siswa', 'Skor', 'Benar', 'Salah', 'Akurasi (%)', 'Rata-rata waktu (detik)', 'Status', 'Daftar hitam', ...categories.map((c) => `K${String(c.id).padStart(2, '0')} ${c.name} (benar/dicoba)`)];
  const rows = summary.students.map((s) => [
    s.rank ?? '-',
    s.name,
    s.studentId,
    s.score,
    s.correct,
    s.wrong,
    Math.round(s.accuracy * 100),
    (s.avgThinkMs / 1000).toFixed(1),
    s.status === 'OK' ? 'OK' : 'DISKUALIFIKASI',
    s.blacklisted ? 'Ya' : 'Tidak',
    ...categories.map((c) => {
      const x = s.perCategory.find((p) => p.categoryId === c.id);
      return x ? `${x.correct}/${x.attempted}` : '';
    }),
  ]);
  return '﻿' + [head, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n') + '\r\n';
}

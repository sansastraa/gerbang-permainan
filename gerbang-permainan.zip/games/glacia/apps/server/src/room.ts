import { randomUUID } from 'node:crypto';
import {
  SCORING_DEFAULTS,
  buildWheel,
  categoryOptions,
  createRng,
  drawSpin,
  firstBloodBonus,
  initialCheatState,
  initials,
  isBurst,
  isPerfectRound,
  isTooFast,
  isUniformTiming,
  onAnswer,
  onVisibility,
  planRefresh,
  pointsForCorrect,
  randomSeed,
  roundScore,
  sampleBoard,
  type CheatCfg,
  type CheatFlagType,
  type CheatState,
  type DisplayMode,
  type RefreshCard,
  type RoomSettings,
  type RoomStatus,
  type ScoringConfig,
} from '@glacia/shared';
import type { QuestionRepository, StoredQuestion } from './bank';
import type { Clock, TimerHandle } from './clock';
import type { SimpeteriPort } from './integration';
import type { Store } from './store';
import { buildReport, type Report } from './report';
import { withRetry } from './outbox';

export type Audience =
  | { to: 'all' }
  | { to: 'players' }
  | { to: 'hosts' }
  | { to: 'displays' }
  | { to: 'player'; playerId: string };

export interface Emitter {
  emit(roomId: string, aud: Audience, event: string, payload: unknown): void;
  disconnectPlayer(roomId: string, playerId: string): void;
}

export interface Timings {
  countdownMs: number;
  spinAnimMs: number;
  autoNextMs: number;
  scoreboardMs: number;
  dqDisconnectMs: number;
  stateCoalesceMs: number;
}
export const DEFAULT_TIMINGS: Timings = {
  countdownMs: 3000,
  spinAnimMs: 6000,
  autoNextMs: 20_000,
  scoreboardMs: 1000,
  dqDisconnectMs: 5000,
  stateCoalesceMs: 500,
};

export interface RoomDeps {
  clock: Clock;
  repo: QuestionRepository;
  store: Store;
  port: SimpeteriPort;
  emitter: Emitter;
  outboxBaseDelayMs: number;
  timings?: Partial<Timings>;
}

export interface Student {
  studentId: string;
  name: string;
}

export interface AnswerRec {
  id: string;
  roundNo: number;
  categoryId: number;
  playerId: string;
  cardId: string;
  correct: boolean;
  thinkMs: number;
  points: number;
  bonus: number;
  serverTime: number;
  invalidated: boolean;
}

export interface CheatFlagRec {
  id: string;
  playerId: string;
  name: string;
  roundNo: number;
  type: CheatFlagType;
  detail: Record<string, unknown>;
  at: number;
}

interface PlayerRound {
  sum: number;
  correct: number;
  wrong: number;
  lastCorrectAt: number | null;
  cooldownUntil: number;
  answered: Set<string>;
  allTimes: number[];
  correctTimes: number[];
  thinkMs: number[];
  softFlags: Set<string>;
  recent: number[];
}

export interface Player {
  id: string;
  studentId: string;
  name: string;
  deviceToken: string;
  online: boolean;
  hasPicked: boolean;
  totalScore: number;
  rawScore: number;
  disqualified: boolean;
  dqAt: number | null;
  dqReason: string | null;
  dqSnapshot: { total: number; roundSum: number; roundNo: number } | null;
  removed: boolean;
  blacklisted: boolean;
  cheat: CheatState;
  round: PlayerRound | null;
}

interface CardRec {
  id: string;
  slot: number;
  version: number;
  q: StoredQuestion;
  replacedBy: string | null;
}

interface RoundState {
  number: number;
  categoryId: number;
  pickerId: string;
  seed: string;
  cards: CardRec[]; // index = canonical slot (current version)
  byId: Map<string, CardRec>;
  retired: CardRec[];
  startedAt: number | null;
  endsAt: number | null;
  refreshAt: number | null;
  answeredAny: Set<string>;
  refreshed: boolean;
  /** cardId → who claimed it with the first correct answer (claimMode). */
  claims: Map<string, { playerId: string; name: string; at: number }>;
}

export interface SpinRec {
  roundNo: number;
  eligible: { playerId: string; name: string }[];
  pickedId: string;
  rngSeed: string;
}

export type ErrCode =
  | 'BAD_STATE'
  | 'REGISTRATION_CLOSED'
  | 'ROOM_FULL'
  | 'NAME_TAKEN'
  | 'UNKNOWN_STUDENT'
  | 'DEVICE_HAS_NAME'
  | 'BLACKLISTED'
  | 'DISQUALIFIED'
  | 'NOT_FOUND'
  | 'NOT_PICKER'
  | 'BAD_CATEGORY'
  | 'ROUND_OVER'
  | 'PAUSED'
  | 'RATE_LIMITED'
  | 'COOLDOWN'
  | 'ALREADY_ANSWERED'
  | 'CARD_CLAIMED'
  | 'CARD_GONE'
  | 'NOT_ENOUGH_PLAYERS'
  | 'NO_NAME';

export type Result<T = object> = ({ ok: true } & T) | { ok: false; code: ErrCode; cooldownUntil?: number };
const fail = (code: ErrCode, extra: { cooldownUntil?: number } = {}): { ok: false; code: ErrCode; cooldownUntil?: number } => ({ ok: false, code, ...extra });

const BLACKLIST_MESSAGE = 'Akunmu sedang tidak bisa mengikuti permainan. Silakan temui gurumu.';
const DQ_MESSAGE = 'Kamu didiskualifikasi karena terdeteksi kecurangan. Silakan temui gurumu.';

export class Room {
  readonly id: string;
  readonly pin: string;
  readonly hostId: string;
  readonly exportKey = randomUUID().replace(/-/g, '');
  settings: RoomSettings;
  status: RoomStatus = 'LOBBY';
  prevStatus: RoomStatus | null = null;
  roundNo = 0;
  readonly createdAt: number;
  endedAt: number | null = null;
  readonly players = new Map<string, Player>();
  readonly roster: Student[];
  readonly flags: CheatFlagRec[] = [];
  readonly answers: AnswerRec[] = [];
  readonly spins: SpinRec[] = [];
  readonly usedCategories: number[] = [];
  readonly usedQuestionIds = new Set<string>();
  readonly roundHistory: { number: number; categoryId: number; pickerId: string }[] = [];
  report: Report | null = null;
  reportSent = false;

  private round: RoundState | null = null;
  private currentOptions: number[] = [];
  private pickerId: string | null = null;
  private pickExpiresAt: number | null = null;
  private countdownStartsAt: number | null = null;
  private lastSpin: { pickedId: string; animSeed: string } | null = null;
  private timers = new Map<string, { h: TimerHandle; at: number; fn: () => void }>();
  private pausedAt: number | null = null;
  private lastScoreboardAt = -Infinity;
  private stateTimer: TimerHandle | null = null;
  private dqDevices = new Set<string>();
  private readonly t: Timings;
  private readonly scoring: ScoringConfig;
  private readonly cheatCfg: CheatCfg;

  constructor(
    opts: { id: string; pin: string; hostId: string; settings: RoomSettings; roster: Student[] },
    private d: RoomDeps,
  ) {
    this.id = opts.id;
    this.pin = opts.pin;
    this.hostId = opts.hostId;
    this.settings = opts.settings;
    this.roster = opts.roster;
    this.createdAt = d.clock.now();
    this.t = { ...DEFAULT_TIMINGS, ...d.timings };
    this.scoring = { ...SCORING_DEFAULTS, wrongPenalty: opts.settings.wrongPenalty };
    this.cheatCfg = this.cheatConfig();
  }

  private cheatConfig(): CheatCfg {
    return {
      minBlurMs: this.settings.minBlurMs,
      blurArmWindowSec: this.settings.blurArmWindowSec,
      streakThreshold: this.settings.cheatStreakThreshold,
    };
  }

  // ------------------------------------------------------------------ helpers
  private now() {
    return this.d.clock.now();
  }
  private emit(aud: Audience, event: string, payload: unknown) {
    this.d.emitter.emit(this.id, aud, event, payload);
  }
  private at(name: string, ts: number, fn: () => void) {
    this.timers.get(name)?.h.cancel();
    const h = this.d.clock.setTimeout(() => {
      this.timers.delete(name);
      fn();
    }, ts - this.now());
    this.timers.set(name, { h, at: ts, fn });
  }
  private clearTimer(name: string) {
    this.timers.get(name)?.h.cancel();
    this.timers.delete(name);
  }
  private clearPhaseTimers() {
    for (const n of ['spin', 'pick', 'countdown', 'end', 'refresh', 'next']) this.clearTimer(n);
  }
  private active(p: Player) {
    return !p.disqualified && !p.removed;
  }
  private maskName(p: { name: string }, mode: DisplayMode): string | null {
    if (mode === 'NAME') return p.name;
    if (mode === 'INITIALS') return initials(p.name);
    return null;
  }
  get disqualifiedCount() {
    return [...this.players.values()].filter((p) => p.disqualified).length;
  }
  playerByDevice(deviceToken: string) {
    return [...this.players.values()].find((p) => p.deviceToken === deviceToken);
  }
  playerByStudent(studentId: string) {
    return [...this.players.values()].find((p) => p.studentId === studentId);
  }
  liveScore(p: Player): number {
    if (p.disqualified) return 0;
    const r = this.status === 'RUNNING' || this.status === 'PAUSED' ? p.round : null;
    return p.totalScore + (r ? Math.max(0, r.sum) : 0);
  }
  private audit(actor: string, action: string, target: string, detail: unknown) {
    this.d.store.addAudit(actor, action, target, { roomId: this.id, ...(detail as object) }, this.now());
  }

  // ------------------------------------------------------------------ state broadcast
  stateFor(role: 'player' | 'host' | 'display', playerId?: string) {
    const pub = [...this.players.values()]
      .filter((p) => (role === 'host' ? !p.removed : this.active(p)))
      .map((p) => ({
        playerId: p.id,
        name: p.name,
        online: p.online,
        hasPicked: p.hasPicked,
        ...(role === 'host' ? { disqualified: p.disqualified, blacklisted: p.blacklisted, score: this.liveScore(p) } : {}),
      }));
    const picker = this.pickerId ? this.players.get(this.pickerId) : undefined;
    const s = this.settings;
    return {
      roomId: this.id,
      pin: this.pin,
      status: this.status,
      prevStatus: this.prevStatus,
      roundNo: this.roundNo,
      rounds: s.rounds,
      players: pub,
      disqualifiedCount: this.disqualifiedCount,
      settings: {
        roundSeconds: s.roundSeconds,
        rounds: s.rounds,
        maxPlayers: s.maxPlayers,
        categoryPickSeconds: s.categoryPickSeconds,
        showDisqualifiedOnDisplay: s.showDisqualifiedOnDisplay,
        wrongCooldownMs: s.wrongCooldownMs,
      },
      pickerId: this.pickerId,
      pickerName: picker?.name ?? null,
      pickExpiresAt: this.pickExpiresAt,
      startsAt: this.countdownStartsAt,
      endsAt: this.round?.endsAt ?? null,
      category: this.round ? this.categoryInfo(this.round.categoryId) : null,
      pausedAt: this.pausedAt,
      you: playerId ? this.playerSelf(playerId) : null,
      serverNow: this.now(),
    };
  }
  private categoryInfo(id: number) {
    const c = this.d.repo.category(id);
    return { id, name: c?.name ?? `Kategori ${id}` };
  }
  private playerSelf(playerId: string) {
    const p = this.players.get(playerId);
    if (!p) return null;
    return { playerId: p.id, name: p.name, score: this.liveScore(p), disqualified: p.disqualified, hasPicked: p.hasPicked };
  }
  broadcastState(immediate = true) {
    if (!immediate) {
      if (this.stateTimer) return;
      this.stateTimer = this.d.clock.setTimeout(() => {
        this.stateTimer = null;
        this.broadcastState(true);
      }, this.t.stateCoalesceMs);
      return;
    }
    this.stateTimer?.cancel();
    this.stateTimer = null;
    this.emit({ to: 'hosts' }, 'room:state', this.stateFor('host'));
    this.emit({ to: 'displays' }, 'room:state', this.stateFor('display'));
    for (const p of this.players.values()) {
      if (p.online) this.emit({ to: 'player', playerId: p.id }, 'room:state', this.stateFor('player', p.id));
    }
  }
  private setStatus(s: RoomStatus) {
    this.status = s;
    this.broadcastState(true);
  }

  // ------------------------------------------------------------------ lobby
  /** Roster shown to a player who just entered the PIN: which names are taken (grey). Blacklist is NOT revealed. */
  rosterView() {
    return this.roster.map((s) => {
      const p = this.playerByStudent(s.studentId);
      return { studentId: s.studentId, name: s.name, taken: !!p && !p.removed };
    });
  }

  /** Called on room:join. Resumes a known device or reports that a name must be picked. */
  async join(deviceToken: string): Promise<Result<{ resumed: boolean; playerId?: string }>> {
    const p = this.playerByDevice(deviceToken);
    if (p) {
      if (p.removed) return fail('NOT_FOUND');
      if (p.disqualified) return fail('BLACKLISTED'); // neutral message handled by gateway
      if (await this.isBlacklisted(p.studentId)) return fail('BLACKLISTED');
      return { ok: true, resumed: true, playerId: p.id };
    }
    if (this.dqDevices.has(deviceToken)) return fail('BLACKLISTED');
    return { ok: true, resumed: false };
  }

  private async isBlacklisted(studentId: string): Promise<boolean> {
    if (this.d.store.activeBlacklist(studentId)) return true;
    try {
      return await this.d.port.isBlacklisted(studentId);
    } catch {
      return false; // SIMPETERI unreachable: local blacklist is still enforced above
    }
  }

  async pickName(deviceToken: string, studentId: string): Promise<Result<{ playerId: string }>> {
    if (this.dqDevices.has(deviceToken)) return fail('BLACKLISTED');
    const existing = this.playerByDevice(deviceToken);
    if (existing) {
      if (existing.studentId === studentId && !existing.removed && !existing.disqualified) return { ok: true, playerId: existing.id };
      return fail('DEVICE_HAS_NAME');
    }
    const s = this.roster.find((r) => r.studentId === studentId);
    if (!s) return fail('UNKNOWN_STUDENT');
    if (await this.isBlacklisted(studentId)) return fail('BLACKLISTED');
    const taken = this.playerByStudent(studentId);
    if (taken) {
      this.recordFlag(taken, 'MULTI_DEVICE', { reason: 'second device tried the same name' });
      return fail('NAME_TAKEN');
    }
    if (this.status !== 'LOBBY') return fail('REGISTRATION_CLOSED');
    if (this.players.size >= this.settings.maxPlayers) return fail('ROOM_FULL');
    const p: Player = {
      id: randomUUID(),
      studentId,
      name: s.name,
      deviceToken,
      online: true,
      hasPicked: false,
      totalScore: 0,
      rawScore: 0,
      disqualified: false,
      dqAt: null,
      dqReason: null,
      dqSnapshot: null,
      removed: false,
      blacklisted: false,
      cheat: initialCheatState(),
      round: null,
    };
    this.players.set(p.id, p);
    this.broadcastState(false);
    return { ok: true, playerId: p.id };
  }

  setConnection(playerId: string, online: boolean) {
    const p = this.players.get(playerId);
    if (!p || p.online === online) return;
    p.online = online;
    this.broadcastState(false);
    this.onRosterChanged();
  }

  updateSettings(patch: RoomSettings): Result {
    if (this.status !== 'LOBBY' && this.status !== 'CREATED') return fail('BAD_STATE');
    this.settings = patch;
    this.broadcastState(true);
    return { ok: true };
  }

  kick(playerId: string, actorId: string): Result {
    const p = this.players.get(playerId);
    if (!p) return fail('NOT_FOUND');
    this.emit({ to: 'player', playerId }, 'you:kicked', { message: 'Kamu dikeluarkan oleh guru.' });
    this.d.clock.setTimeout(() => this.d.emitter.disconnectPlayer(this.id, playerId), 500);
    if (this.status === 'LOBBY') this.players.delete(playerId);
    else {
      p.removed = true;
      p.online = false;
    }
    this.audit(actorId, 'KICK', p.studentId, { name: p.name });
    this.broadcastState(true);
    this.onRosterChanged();
    return { ok: true };
  }

  // ------------------------------------------------------------------ game flow
  startGame(): Result {
    if (this.status !== 'LOBBY') return fail('BAD_STATE');
    const online = [...this.players.values()].filter((p) => this.active(p) && p.online);
    if (online.length < 2) return fail('NOT_ENOUGH_PLAYERS');
    this.enterSpin();
    return { ok: true };
  }

  private eligiblePlayers() {
    return [...this.players.values()].map((p) => ({
      playerId: p.id,
      name: p.name,
      online: p.online && !p.removed,
      hasPicked: p.hasPicked,
      disqualified: p.disqualified || p.removed,
      blacklisted: p.blacklisted,
    }));
  }

  private enterSpin() {
    this.clearPhaseTimers();
    this.roundNo = this.roundHistory.length + 1;
    this.round = null;
    this.pickerId = null;
    this.pickExpiresAt = null;
    this.countdownStartsAt = null;
    this.status = 'SPIN';
    const wheel = buildWheel(this.eligiblePlayers());
    if (wheel.segments.length === 0) {
      void this.finishGame();
      return;
    }
    if (wheel.cycleReset) for (const p of this.players.values()) p.hasPicked = false;
    this.doSpin(wheel.segments);
    this.broadcastState(true);
  }

  private doSpin(segments: { playerId: string; name: string }[]) {
    const out = drawSpin(segments);
    this.pickerId = out.pickedPlayerId;
    this.lastSpin = { pickedId: out.pickedPlayerId, animSeed: out.animSeed };
    this.spins.push({ roundNo: this.roundNo, eligible: segments, pickedId: out.pickedPlayerId, rngSeed: out.rngSeed });
    this.emit({ to: 'all' }, 'spin:wheel', { segments, count: segments.length });
    this.emit({ to: 'all' }, 'spin:result', {
      eligible: segments,
      pickedPlayerId: out.pickedPlayerId,
      pickedName: this.players.get(out.pickedPlayerId)?.name ?? '',
      animSeed: out.animSeed,
      animMs: this.t.spinAnimMs,
      roundNo: this.roundNo,
    });
    this.at('spin', this.now() + this.t.spinAnimMs, () => this.enterPick());
  }

  /** Keep the wheel and the picker valid when someone joins, leaves, is kicked or disqualified (7.6). */
  private onRosterChanged() {
    if (this.status !== 'SPIN' && this.status !== 'PICK') return;
    const wheel = buildWheel(this.eligiblePlayers());
    if (wheel.segments.length === 0) {
      void this.finishGame();
      return;
    }
    const picker = this.pickerId ? this.players.get(this.pickerId) : undefined;
    const pickerValid = !!picker && picker.online && this.active(picker) && !picker.blacklisted;
    if (!pickerValid) {
      this.clearPhaseTimers();
      this.status = 'SPIN';
      this.pickExpiresAt = null;
      this.doSpin(wheel.segments);
      this.broadcastState(true);
    } else {
      this.emit({ to: 'all' }, 'spin:wheel', { segments: wheel.segments, count: wheel.segments.length });
    }
  }

  private enterPick() {
    if (this.status !== 'SPIN' || !this.pickerId) return;
    this.currentOptions = categoryOptions(this.settings.allowedCategoryIds, this.usedCategories, randomSeed());
    if (this.currentOptions.length === 0) this.currentOptions = this.settings.allowedCategoryIds.slice(0, 5);
    // a teacher may allow just one category: nothing to choose, go straight to the countdown
    if (this.currentOptions.length === 1) {
      this.beginCountdown(this.currentOptions[0] as number);
      return;
    }
    this.pickExpiresAt = this.now() + this.settings.categoryPickSeconds * 1000;
    this.status = 'PICK';
    const picker = this.pickerId;
    this.emit({ to: 'player', playerId: picker }, 'category:options', {
      categories: this.currentOptions.map((id) => ({ id, name: this.d.repo.category(id)?.name ?? `Kategori ${id}` })),
      expiresAt: this.pickExpiresAt,
    });
    this.broadcastState(true);
    this.at('pick', this.pickExpiresAt, () => {
      const rng = createRng(randomSeed());
      this.beginCountdown(rng.pick(this.currentOptions));
    });
  }

  pickCategory(playerId: string, categoryId: number): Result {
    if (this.status !== 'PICK') return fail('BAD_STATE');
    if (playerId !== this.pickerId) return fail('NOT_PICKER');
    if (!this.currentOptions.includes(categoryId)) return fail('BAD_CATEGORY');
    this.beginCountdown(categoryId);
    return { ok: true };
  }

  private buildBoard(categoryId: number, seed: string) {
    const pool = this.d.repo.pool(categoryId);
    const board = sampleBoard(pool, {
      ratioMin: this.settings.correctRatioMin,
      ratioMax: this.settings.correctRatioMax,
      excludeQuestionIds: this.usedQuestionIds,
      seed,
    });
    return board.cards.map((c) => this.d.repo.get(c.id) as StoredQuestion);
  }

  private beginCountdown(categoryId: number) {
    this.clearPhaseTimers();
    const picker = this.pickerId ? this.players.get(this.pickerId) : undefined;
    if (picker) picker.hasPicked = true;
    this.usedCategories.push(categoryId);
    this.pickExpiresAt = null;
    const seed = randomSeed();
    // One shared board for the whole class: the generator's cards are shuffled ONCE, so every student races for the same 64 numbers.
    const qs = createRng(`${seed}:layout`).shuffle(this.buildBoard(categoryId, seed));
    const cards: CardRec[] = qs.map((q, slot) => ({ id: randomUUID(), slot, version: 0, q, replacedBy: null }));
    for (const q of qs) this.usedQuestionIds.add(q.id);
    this.round = {
      number: this.roundNo,
      categoryId,
      pickerId: this.pickerId ?? '',
      seed,
      cards,
      byId: new Map(cards.map((c) => [c.id, c])),
      retired: [],
      startedAt: null,
      endsAt: null,
      refreshAt: null,
      answeredAny: new Set(),
      refreshed: false,
      claims: new Map(),
    };
    this.roundHistory.push({ number: this.roundNo, categoryId, pickerId: this.pickerId ?? '' });
    this.countdownStartsAt = this.now() + this.t.countdownMs;
    this.status = 'COUNTDOWN';
    this.emit({ to: 'all' }, 'round:countdown', {
      startsAt: this.countdownStartsAt,
      roundNo: this.roundNo,
      category: this.categoryInfo(categoryId),
      serverNow: this.now(),
    });
    this.broadcastState(true);
    this.at('countdown', this.countdownStartsAt, () => this.startRunning());
  }

  private cardPayload(c: CardRec) {
    return { cardId: c.id, svg: c.q.svg };
  }

  private freshRound(): PlayerRound {
    return { sum: 0, correct: 0, wrong: 0, lastCorrectAt: null, cooldownUntil: 0, answered: new Set(), allTimes: [], correctTimes: [], thinkMs: [], softFlags: new Set(), recent: [] };
  }

  private startRunning() {
    const r = this.round;
    if (!r) return;
    const now = this.now();
    r.startedAt = now;
    r.endsAt = now + this.settings.roundSeconds * 1000;
    r.refreshAt = this.settings.boardRefreshOddRounds && r.number % 2 === 1 ? now + (this.settings.roundSeconds * 1000) / 2 : null;
    this.countdownStartsAt = null;
    for (const p of this.players.values()) {
      p.round = this.freshRound();
      p.cheat = initialCheatState();
    }
    this.status = 'RUNNING';
    this.sendRoundStart();
    this.at('end', r.endsAt, () => this.endRound());
    if (r.refreshAt) this.at('refresh', r.refreshAt, () => this.refreshBoard());
    this.broadcastState(true);
    this.scoreboard(true);
  }

  private roundStartPayload(cards: { cardId: string; svg: string }[], extra: object = {}) {
    const r = this.round!;
    return {
      roundNo: r.number,
      rounds: this.settings.rounds,
      category: this.categoryInfo(r.categoryId),
      startedAt: r.startedAt,
      endsAt: r.endsAt,
      refreshAt: r.refreshAt && !r.refreshed ? r.refreshAt : undefined,
      serverNow: this.now(),
      wrongCooldownMs: this.settings.wrongCooldownMs,
      cardCount: cards.length,
      numbersTotal: this.settings.rounds * this.settings.boardSize,
      numbersBefore: (r.number - 1) * this.settings.boardSize,
      cards,
      ...extra,
    };
  }

  /** The shared board, in the one order every student sees. */
  private boardCards() {
    return this.round!.cards.map((c) => this.cardPayload(c));
  }

  private sendRoundStart() {
    // identical for everybody: one broadcast instead of one 200 KB message per student
    this.emit({ to: 'players' }, 'round:start', this.roundStartPayload(this.boardCards()));
    // the projector shows the same board (it is public to the whole room) so it can put the claimer's avatar on each card
    this.emit({ to: 'displays' }, 'round:start', this.roundStartPayload(this.boardCards()));
    this.emit({ to: 'hosts' }, 'round:start', this.roundStartPayload([], { cardCount: this.settings.boardSize }));
  }

  /** The wheel as it stands, for a screen that connects (or reconnects) during SPIN/PICK. animMs 0: it only shows the result. */
  spinSnapshot() {
    const s = this.spins.at(-1);
    if (!s || (this.status !== 'SPIN' && this.status !== 'PICK')) return null;
    return {
      wheel: { segments: s.eligible, count: s.eligible.length },
      result: { eligible: s.eligible, pickedPlayerId: s.pickedId, pickedName: this.players.get(s.pickedId)?.name ?? '', animSeed: this.lastSpin?.animSeed ?? '', animMs: 0, roundNo: s.roundNo },
    };
  }

  /** What a projector that connects mid-round needs: the board and who has claimed what. */
  boardSnapshot(): { round?: unknown; claims?: Record<string, { playerId: string; name: string }> } {
    if (!this.round || (this.status !== 'RUNNING' && this.status !== 'PAUSED')) return {};
    return {
      round: this.roundStartPayload(this.boardCards()),
      claims: Object.fromEntries([...this.round.claims].map(([id, c]) => [id, { playerId: c.playerId, name: c.name }])),
    };
  }

  /** Reconnect: everything a returning player needs to continue the current phase. */
  resumeSnapshot(playerId: string) {
    const p = this.players.get(playerId);
    const out: Record<string, unknown> = { state: this.stateFor('player', playerId) };
    if (!p || !this.round) return out;
    if (this.status === 'RUNNING' || this.status === 'PAUSED') {
      out.round = this.roundStartPayload(this.boardCards());
      const mine: Record<string, boolean> = {};
      for (const a of this.answers) if (a.playerId === playerId && a.roundNo === this.round.number) mine[a.cardId] = a.correct;
      out.myAnswers = mine;
      out.cooldownUntil = p.round?.cooldownUntil ?? 0;
      out.claims = Object.fromEntries([...this.round.claims].map(([id, c]) => [id, { playerId: c.playerId, name: c.name }]));
    }
    if (this.status === 'PICK' && this.pickerId === playerId) {
      out.options = {
        categories: this.currentOptions.map((id) => this.categoryInfo(id)),
        expiresAt: this.pickExpiresAt,
      };
    }
    if (this.lastSpin && (this.status === 'SPIN' || this.status === 'PICK')) out.spin = this.lastSpin;
    return out;
  }

  // ------------------------------------------------------------------ answers
  answer(playerId: string, cardId: string, hiddenAtAnswer = false): Result<{ correct: boolean; points: number; bonus: number }> {
    const now = this.now();
    const p = this.players.get(playerId);
    const r = this.round;
    if (!p || p.removed) return fail('NOT_FOUND');
    if (p.disqualified) return fail('DISQUALIFIED');
    if (this.status === 'PAUSED') return fail('PAUSED');
    if (this.status !== 'RUNNING' || !r || !p.round || r.endsAt === null) return fail('BAD_STATE');
    if (now >= r.endsAt) return fail('ROUND_OVER');
    const pr = p.round;
    pr.recent = pr.recent.filter((t) => now - t < 1000);
    if (pr.recent.length >= 5) return fail('RATE_LIMITED');
    pr.recent.push(now);
    if (now < pr.cooldownUntil) return fail('COOLDOWN', { cooldownUntil: pr.cooldownUntil });
    const card = r.byId.get(cardId);
    if (!card) return fail('CARD_GONE');
    if (pr.answered.has(cardId)) return fail('ALREADY_ANSWERED');
    if (r.claims.has(cardId)) return fail('CARD_CLAIMED'); // somebody was faster; the server decides by arrival order

    const correct = card.q.isCorrect;
    const baseline = pr.lastCorrectAt ?? (r.startedAt as number);
    const thinkMs = now - baseline;
    let points: number;
    let bonus = 0;
    if (correct) {
      points = pointsForCorrect(thinkMs, this.scoring);
      if (this.settings.firstBlood && !this.settings.claimMode) {
        const rank = this.answers.filter((a) => a.cardId === cardId && a.correct && !a.invalidated).length + 1;
        bonus = firstBloodBonus(rank, this.scoring);
      }
      pr.correct++;
      pr.lastCorrectAt = now;
      pr.correctTimes.push(now);
    } else {
      points = -this.settings.wrongPenalty;
      pr.wrong++;
      pr.cooldownUntil = now + this.settings.wrongCooldownMs;
    }
    pr.sum += points + bonus;
    pr.answered.add(cardId);
    pr.thinkMs.push(thinkMs);
    pr.allTimes.push(now);
    r.answeredAny.add(cardId);
    const rec: AnswerRec = { id: randomUUID(), roundNo: r.number, categoryId: r.categoryId, playerId, cardId, correct, thinkMs, points, bonus, serverTime: now, invalidated: false };
    this.answers.push(rec);

    this.emit({ to: 'player', playerId }, 'card:result', {
      cardId,
      correct,
      points,
      bonus,
      score: this.liveScore(p),
      ...(correct ? {} : { cooldownUntil: pr.cooldownUntil }),
    });

    if (correct && this.settings.claimMode) {
      r.claims.set(cardId, { playerId, name: p.name, at: now });
      this.emit({ to: 'all' }, 'card:claimed', { cardId, playerId, name: p.name });
    }

    this.checkCheat(p, rec, hiddenAtAnswer);
    this.softHeuristics(p);
    this.scoreboard(false);
    this.endEarlyIfAllClaimed();
    return { ok: true, correct, points, bonus };
  }

  private checkCheat(p: Player, rec: AnswerRec, hiddenAtAnswer: boolean) {
    if (!this.settings.autoDisqualify || p.disqualified) return;
    const res = onAnswer(p.cheat, rec.correct, rec.serverTime, hiddenAtAnswer, this.cheatCfg);
    p.cheat = res.state;
    if (res.flag) this.recordFlag(p, res.flag, { cardId: rec.cardId });
    if (res.disqualify) {
      this.disqualify(p.id, 'BLUR_STREAK', { actorId: 'system', blacklist: this.settings.autoBlacklist, streak: res.state.streak });
    }
  }

  private softHeuristics(p: Player) {
    const pr = p.round;
    if (!pr || p.disqualified) return;
    const once = (key: CheatFlagType, cond: boolean, detail: Record<string, unknown>) => {
      if (cond && !pr.softFlags.has(key)) {
        pr.softFlags.add(key);
        this.recordFlag(p, key, detail);
      }
    };
    once('TOO_FAST', isTooFast(pr.thinkMs.slice(-6)), { recentThinkMs: pr.thinkMs.slice(-6) });
    once('UNIFORM_TIMING', isUniformTiming(pr.thinkMs), { n: pr.thinkMs.length });
    once('BURST', isBurst(pr.correctTimes), { n: pr.correctTimes.length });
  }

  visibility(playerId: string, hidden: boolean) {
    const p = this.players.get(playerId);
    if (!p || p.disqualified || !this.settings.autoDisqualify) return;
    const res = onVisibility(p.cheat, hidden, this.now(), this.status === 'RUNNING', this.cheatCfg);
    p.cheat = res.state;
    if (res.flag) this.recordFlag(p, res.flag, { hiddenMs: res.hiddenMs });
  }

  private recordFlag(p: Player, type: CheatFlagType, detail: Record<string, unknown>) {
    const rec: CheatFlagRec = { id: randomUUID(), playerId: p.id, name: p.name, roundNo: this.roundNo, type, detail, at: this.now() };
    this.flags.push(rec);
    this.emit({ to: 'hosts' }, 'cheat:flag', {
      playerId: p.id,
      name: p.name,
      type,
      detail,
      at: rec.at,
      streak: p.cheat.streak,
      armedUntil: p.cheat.armedUntil,
    });
    return rec;
  }

  // ------------------------------------------------------------------ scoreboard
  private scoreboard(force: boolean) {
    const now = this.now();
    const send = () => {
      this.lastScoreboardAt = this.now();
      const top5 = [...this.players.values()]
        .filter((p) => this.active(p))
        .map((p) => ({ playerId: p.id, name: p.name, score: this.liveScore(p) }))
        .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
        .slice(0, 5);
      this.emit({ to: 'all' }, 'scoreboard:live', { top5, ...this.claimProgress() });
    };
    if (force || now - this.lastScoreboardAt >= this.t.scoreboardMs) {
      this.clearTimer('scoreboard');
      send();
    } else if (!this.timers.has('scoreboard')) {
      this.at('scoreboard', this.lastScoreboardAt + this.t.scoreboardMs, send);
    }
  }

  // ------------------------------------------------------------------ claims
  /** How many correct cards are already taken / still free. Says nothing about WHICH free cards are correct. */
  private claimProgress(): { claimed: number; remaining: number } | Record<string, never> {
    const r = this.round;
    if (!r || !this.settings.claimMode) return {};
    const correct = r.cards.filter((c) => c.q.isCorrect);
    const claimed = correct.filter((c) => r.claims.has(c.id)).length;
    return { claimed, remaining: correct.length - claimed };
  }

  /** Nothing left to fight over: close the round shortly after the last correct card is claimed. */
  private endEarlyIfAllClaimed() {
    const r = this.round;
    if (!r || this.status !== 'RUNNING' || !this.settings.claimMode) return;
    const p = this.claimProgress() as { remaining?: number };
    if (p.remaining === 0) this.at('end', this.now() + 1500, () => this.endRound());
  }

  // ------------------------------------------------------------------ host: end now
  /** Host "Akhiri ronde": scores the round immediately (works while paused too). */
  endRoundNow(): Result {
    if (this.status === 'PAUSED' && this.prevStatus === 'RUNNING') this.resume();
    if (this.status !== 'RUNNING') return fail('BAD_STATE');
    this.endRound();
    return { ok: true };
  }

  /** Host "Akhiri permainan": closes the running round (its scores count), then goes straight to the final board and report. */
  endGameNow(actorId: string): Result {
    if (this.status === 'LOBBY' || this.status === 'CREATED' || this.status === 'FINAL' || this.status === 'DONE') return fail('BAD_STATE');
    if (this.status === 'PAUSED' && this.prevStatus === 'RUNNING') this.resume();
    if (this.status === 'RUNNING') this.endRound();
    this.audit(actorId, 'END_GAME', this.id, { atRound: this.roundNo });
    void this.finishGame();
    return { ok: true };
  }

  // ------------------------------------------------------------------ board refresh
  private refreshBoard() {
    const r = this.round;
    if (!r || this.status !== 'RUNNING' || r.refreshed) return;
    r.refreshed = true;
    const cards: RefreshCard[] = r.cards.map((c) => ({ slot: c.slot, questionId: c.q.id, isCorrect: c.q.isCorrect, tier: c.q.tier, answered: r.answeredAny.has(c.id) }));
    const plan = planRefresh(cards, this.d.repo.pool(r.categoryId), this.usedQuestionIds, randomSeed());
    const replaced: { oldCardId: string; cardId: string; svg: string }[] = [];
    for (const rep of plan) {
      const old = r.cards[rep.slot] as CardRec;
      const q = this.d.repo.get(rep.newQuestionId) as StoredQuestion;
      const fresh: CardRec = { id: randomUUID(), slot: rep.slot, version: old.version + 1, q, replacedBy: null };
      old.replacedBy = fresh.id;
      r.retired.push(old);
      r.byId.delete(old.id);
      r.byId.set(fresh.id, fresh);
      r.cards[rep.slot] = fresh;
      this.usedQuestionIds.add(q.id);
      replaced.push({ oldCardId: old.id, cardId: fresh.id, svg: q.svg });
    }
    this.emit({ to: 'all' }, 'board:refresh', { replaced });
  }

  // ------------------------------------------------------------------ round end
  private endRound() {
    const r = this.round;
    if (!r || this.status !== 'RUNNING') return;
    this.clearPhaseTimers();
    this.clearTimer('scoreboard');
    const totalCorrect = r.cards.filter((c) => c.q.isCorrect).length;
    const results: { playerId: string; name: string; roundScore: number; total: number; correct: number; wrong: number; perfect: boolean }[] = [];
    for (const p of this.players.values()) {
      const pr = p.round;
      if (!pr || p.removed) continue;
      if (p.disqualified) continue;
      const perfect = !this.settings.claimMode && isPerfectRound(pr.correct, totalCorrect, pr.wrong);
      const rs = roundScore([pr.sum, perfect ? this.scoring.perfectRoundBonus : 0]);
      p.totalScore += rs;
      results.push({ playerId: p.id, name: p.name, roundScore: rs, total: p.totalScore, correct: pr.correct, wrong: pr.wrong, perfect });
    }
    results.sort((a, b) => b.total - a.total || b.roundScore - a.roundScore || a.name.localeCompare(b.name));
    const ranked = results.map((x, i) => ({ ...x, rank: i + 1 }));
    const wrongBy = new Map<string, number>();
    const solvedBy = new Map<string, number>();
    for (const a of this.answers) {
      if (a.roundNo !== r.number || a.invalidated) continue;
      (a.correct ? solvedBy : wrongBy).set(a.cardId, ((a.correct ? solvedBy : wrongBy).get(a.cardId) ?? 0) + 1);
    }
    const info = r.cards.map((c) => ({ c, wrong: wrongBy.get(c.id) ?? 0, solved: solvedBy.get(c.id) ?? 0 }));
    const hard = info
      .filter((x) => x.wrong > 0)
      .sort((a, b) => b.wrong - a.wrong || a.solved - b.solved);
    const fill = info.filter((x) => x.wrong === 0 && x.c.q.isCorrect).sort((a, b) => a.solved - b.solved);
    const explanations = [...hard, ...fill].slice(0, 3).map((x) => ({
      cardId: x.c.id,
      svg: x.c.q.svg,
      result: x.c.q.result,
      isCorrect: x.c.q.isCorrect,
      explanation: x.c.q.explanation,
      wrongCount: x.wrong,
      solvedCount: x.solved,
    }));
    const category = this.d.repo.category(r.categoryId);
    const lastRound = r.number >= this.settings.rounds;
    const payload = {
      roundNo: r.number,
      rounds: this.settings.rounds,
      category: this.categoryInfo(r.categoryId),
      trick: category?.trick ?? '',
      roundScores: ranked,
      keyReveal: r.cards.map((c) => ({ cardId: c.id, isCorrect: c.q.isCorrect, result: c.q.result })),
      explanations,
      nextAt: this.now() + this.t.autoNextMs,
      lastRound,
    };
    this.status = 'ROUND_RESULT';
    this.emit({ to: 'all' }, 'round:end', payload);
    this.broadcastState(true);
    // The last board uses up the last of the numbers: finish right now, however much time was left, and show the ranking.
    if (lastRound) void this.finishGame();
    else this.at('next', this.now() + this.t.autoNextMs, () => this.advance());
  }

  /** Host `round:next` (or the 20s timer). */
  nextRound(): Result {
    if (this.status !== 'ROUND_RESULT') return fail('BAD_STATE');
    this.advance();
    return { ok: true };
  }

  private advance() {
    if (this.status !== 'ROUND_RESULT') return;
    this.clearTimer('next');
    if (this.roundNo >= this.settings.rounds) void this.finishGame();
    else this.enterSpin();
  }

  // ------------------------------------------------------------------ pause / resume
  pause(): Result {
    if (!['SPIN', 'PICK', 'RUNNING', 'COUNTDOWN'].includes(this.status)) return fail('BAD_STATE');
    const now = this.now();
    this.prevStatus = this.status;
    this.pausedAt = now;
    for (const t of this.timers.values()) t.h.cancel();
    this.frozen = [...this.timers.entries()].map(([name, t]) => ({ name, at: t.at, fn: t.fn }));
    this.timers.clear();
    for (const p of this.players.values()) p.cheat = { ...p.cheat, hiddenSince: null };
    this.status = 'PAUSED';
    this.broadcastState(true);
    return { ok: true };
  }
  private frozen: { name: string; at: number; fn: () => void }[] = [];

  resume(): Result {
    if (this.status !== 'PAUSED' || this.pausedAt === null || !this.prevStatus) return fail('BAD_STATE');
    const shift = this.now() - this.pausedAt;
    this.status = this.prevStatus;
    this.prevStatus = null;
    this.pausedAt = null;
    const r = this.round;
    if (r?.endsAt) r.endsAt += shift;
    if (r?.refreshAt) r.refreshAt += shift;
    if (this.pickExpiresAt) this.pickExpiresAt += shift;
    if (this.countdownStartsAt) this.countdownStartsAt += shift;
    for (const f of this.frozen) this.at(f.name, f.at + shift, f.fn);
    this.frozen = [];
    this.broadcastState(true);
    return { ok: true };
  }

  // ------------------------------------------------------------------ disqualify / reinstate
  disqualify(playerId: string, reason: 'BLUR_STREAK' | 'HOST_MANUAL', opts: { actorId: string; blacklist: boolean; streak?: number; note?: string }): Result {
    const p = this.players.get(playerId);
    if (!p) return fail('NOT_FOUND');
    if (p.disqualified) return { ok: true }; // idempotent
    const now = this.now();
    const live = this.liveScore(p);
    p.dqSnapshot = { total: p.totalScore, roundSum: p.round?.sum ?? 0, roundNo: this.roundNo };
    p.rawScore = live;
    p.totalScore = 0;
    if (p.round) p.round.sum = 0;
    p.disqualified = true;
    p.dqAt = now;
    p.dqReason = reason;
    for (const a of this.answers) if (a.playerId === p.id) a.invalidated = true;
    this.dqDevices.add(p.deviceToken);
    if (this.round) {
      // a cheater's claims are void: free those cards again for everybody else
      for (const [cardId, c] of [...this.round.claims]) {
        if (c.playerId !== p.id) continue;
        this.round.claims.delete(cardId);
        this.emit({ to: 'all' }, 'card:released', { cardId });
      }
    }

    const evidence = {
      flags: this.flags.filter((f) => f.playerId === p.id).map((f) => ({ type: f.type, at: f.at, detail: f.detail, roundNo: f.roundNo })),
      lastAnswers: this.answers.filter((a) => a.playerId === p.id).slice(-8).map((a) => ({ cardId: a.cardId, correct: a.correct, thinkMs: a.thinkMs, serverTime: a.serverTime })),
      streak: opts.streak ?? p.cheat.streak,
      rule: this.cheatCfg,
      note: opts.note,
    };
    const flag = this.recordFlag(p, 'BLUR_STREAK_DQ', { reason, evidence });
    void flag;
    const mode = this.settings.showDisqualifiedOnDisplay;
    this.emit({ to: 'all' }, 'player:disqualified', {
      ...(mode === 'NAME' ? { playerId: p.id } : {}),
      displayName: this.maskName(p, mode),
      mode,
      reason: reason === 'BLUR_STREAK' ? 'CHEAT_DETECTED' : 'HOST',
      at: now,
      totalDisqualified: this.disqualifiedCount,
    });
    this.emit({ to: 'player', playerId: p.id }, 'you:disqualified', { message: DQ_MESSAGE, blacklisted: opts.blacklist });
    this.d.clock.setTimeout(() => this.d.emitter.disconnectPlayer(this.id, p.id), this.t.dqDisconnectMs);

    if (opts.blacklist) {
      p.blacklisted = true;
      const row = this.d.store.addBlacklist({ studentId: p.studentId, studentName: p.name, classId: this.settings.classId, reason, roomId: this.id, evidence }, now);
      void this.syncBlacklist(row.id, p.studentId, reason, evidence);
    }
    this.audit(opts.actorId, reason === 'BLUR_STREAK' ? 'AUTO_DQ' : 'MANUAL_DQ', p.studentId, { name: p.name, reason, blacklist: opts.blacklist, note: opts.note });
    this.broadcastState(true);
    this.scoreboard(true);
    this.onRosterChanged();
    return { ok: true };
  }

  private withRetry<T>(fn: () => Promise<T>) {
    return withRetry(fn, this.d.outboxBaseDelayMs);
  }

  private async syncBlacklist(rowId: string, studentId: string, reason: string, evidence: unknown) {
    const res = await this.withRetry(() => this.d.port.blacklistStudent(studentId, reason, evidence, this.id));
    if (res.ok) this.d.store.markSynced(rowId);
    else this.d.store.addOutbox('BLACKLIST', { rowId, studentId, reason, evidence, roomId: this.id }, res.error, this.now());
  }

  reinstate(playerId: string, actorId: string): Result {
    const p = this.players.get(playerId);
    if (!p) return fail('NOT_FOUND');
    if (!p.disqualified) return fail('BAD_STATE');
    const snap = p.dqSnapshot;
    p.disqualified = false;
    p.dqAt = null;
    p.dqReason = null;
    p.blacklisted = false;
    this.dqDevices.delete(p.deviceToken);
    if (snap && snap.roundNo === this.roundNo && this.status === 'RUNNING' && p.round) {
      p.totalScore = snap.total;
      p.round.sum = snap.roundSum;
    } else {
      p.totalScore = p.rawScore;
    }
    for (const a of this.answers) if (a.playerId === p.id) a.invalidated = false;
    p.cheat = initialCheatState();
    p.dqSnapshot = null;
    const lifted = this.d.store.liftBlacklist(p.studentId, actorId, 'Dipulihkan oleh guru (reinstate)', this.now());
    void this.withRetry(() => this.d.port.liftBlacklist(p.studentId, actorId, 'reinstate')).then((r) => {
      if (!r.ok) this.d.store.addOutbox('LIFT', { studentId: p.studentId, actorId, note: 'reinstate' }, r.error, this.now());
    });
    const mode = this.settings.showDisqualifiedOnDisplay;
    this.emit({ to: 'all' }, 'player:reinstated', { ...(mode === 'NAME' ? { playerId: p.id } : {}), displayName: this.maskName(p, mode), mode, totalDisqualified: this.disqualifiedCount });
    this.emit({ to: 'player', playerId: p.id }, 'you:reinstated', { message: 'Gurumu memulihkan kamu. Kamu boleh lanjut bermain.' });
    this.audit(actorId, 'REINSTATE', p.studentId, { name: p.name, liftedRows: lifted.length, restoredScore: p.totalScore });
    this.broadcastState(true);
    this.scoreboard(true);
    return { ok: true };
  }

  // ------------------------------------------------------------------ finish
  private async finishGame() {
    if (this.status === 'FINAL' || this.status === 'DONE') return;
    this.clearPhaseTimers();
    this.status = 'FINAL';
    this.endedAt = this.now();
    this.report = buildReport(this, this.d.repo);
    const standings = this.report.finalBoard;
    const podium = standings.slice(0, 3);
    const disq = [...this.players.values()].filter((p) => p.disqualified);
    const mode = this.settings.showDisqualifiedOnDisplay;
    this.emit({ to: 'all' }, 'game:end', {
      finalBoard: standings,
      podium,
      disqualified: { count: disq.length, mode, names: disq.map((p) => this.maskName(p, mode)).filter((n): n is string => n !== null) },
    });
    this.broadcastState(true);
    await this.submitReport();
    this.status = 'DONE';
    this.broadcastState(true);
  }

  async submitReport(): Promise<{ ok: boolean; error?: string }> {
    if (!this.report) return { ok: false, error: 'no report' };
    this.d.store.saveRoom({ roomId: this.id, classId: this.settings.classId, hostId: this.hostId, playedAt: this.endedAt ?? this.now(), payload: this.report.payload, summary: this.report.summary, exportKey: this.exportKey });
    const res = await this.withRetry(() => this.d.port.submitResults(this.report!.payload));
    if (res.ok) {
      this.reportSent = true;
      return { ok: true };
    }
    this.d.store.addOutbox('RESULT', this.report.payload, res.error, this.now());
    return { ok: false, error: res.error };
  }

  /** Host dashboard view. */
  hostView() {
    return {
      ...this.stateFor('host'),
      exportKey: this.exportKey,
      flags: this.flags.length,
      reportSent: this.reportSent,
    };
  }
  roundSummary() {
    return this.round ? { number: this.round.number, categoryId: this.round.categoryId } : null;
  }
  get blacklistMessage() {
    return BLACKLIST_MESSAGE;
  }
}

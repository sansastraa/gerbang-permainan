import type { Server as HttpServer } from 'node:http';
import { Server, type Socket, type Namespace } from 'socket.io';
import {
  CardAnswerSchema,
  CategoryPickSchema,
  DisplayJoinSchema,
  HostAuthSchema,
  HostKickSchema,
  JoinSchema,
  PickNameSchema,
  VisibilitySchema,
} from '@glacia/shared';
import type { ZodTypeAny, z } from 'zod';
import { verifyHostJwt } from './auth';
import type { Clock } from './clock';
import type { RoomManager } from './manager';
import type { Audience, Emitter, Room } from './room';

type Ack = (res: unknown) => void;

interface SocketData {
  role?: 'player' | 'host' | 'display';
  roomId?: string;
  playerId?: string;
  deviceToken?: string;
  hostId?: string;
}

export const chan = {
  players: (roomId: string) => `${roomId}:players`,
  hosts: (roomId: string) => `${roomId}:hosts`,
  displays: (roomId: string) => `${roomId}:displays`,
  player: (playerId: string) => `p:${playerId}`,
};

export class SocketEmitter implements Emitter {
  ns: Namespace | null = null;
  emit(roomId: string, aud: Audience, event: string, payload: unknown): void {
    const ns = this.ns;
    if (!ns) return;
    switch (aud.to) {
      case 'all':
        ns.to([chan.players(roomId), chan.hosts(roomId), chan.displays(roomId)]).emit(event, payload);
        break;
      case 'players':
        ns.to(chan.players(roomId)).emit(event, payload);
        break;
      case 'hosts':
        ns.to(chan.hosts(roomId)).emit(event, payload);
        break;
      case 'displays':
        ns.to(chan.displays(roomId)).emit(event, payload);
        break;
      case 'player':
        ns.to(chan.player(aud.playerId)).emit(event, payload);
        break;
    }
  }
  disconnectPlayer(_roomId: string, playerId: string): void {
    this.ns?.in(chan.player(playerId)).disconnectSockets(true);
  }
}

export interface GatewayOpts {
  http: HttpServer;
  manager: RoomManager;
  emitter: SocketEmitter;
  jwtSecret: string;
  clock: Clock;
  allowedOrigins: string[];
  joinLimitPerMin?: number;
  deflate?: boolean;
  /** mount point of socket.io: <basePath>/socket.io */
  basePath?: string;
  trustProxy?: boolean;
}

export function attachGateway(o: GatewayOpts): { io: Server; ns: Namespace } {
  const io = new Server(o.http, {
    path: `${o.basePath ?? ''}/socket.io`,
    cors: { origin: o.allowedOrigins.length ? o.allowedOrigins : true },
    perMessageDeflate: o.deflate === false ? false : { threshold: 1024 },
    maxHttpBufferSize: 100_000,
    pingInterval: 10_000,
    pingTimeout: 15_000,
  });
  const ns = io.of('/game');
  o.emitter.ns = ns;

  const sockets = new Map<string, Set<string>>(); // playerId -> socket ids
  const joinHits = new Map<string, number[]>();
  /** Behind our gateway every socket comes from the gateway's address: the real client is the last X-Forwarded-For entry. */
  const clientIp = (socket: Socket): string => {
    if (o.trustProxy) {
      const last = String(socket.handshake.headers['x-forwarded-for'] ?? '').split(',').map((s) => s.trim()).filter(Boolean).at(-1);
      if (last) return last;
    }
    return socket.handshake.address;
  };
  const limit = o.joinLimitPerMin ?? 10;

  const joinAllowed = (ip: string) => {
    const now = o.clock.now();
    const hits = (joinHits.get(ip) ?? []).filter((t) => now - t < 60_000);
    if (hits.length >= limit) {
      joinHits.set(ip, hits);
      return false;
    }
    hits.push(now);
    joinHits.set(ip, hits);
    return true;
  };

  ns.on('connection', (socket: Socket) => {
    const data = socket.data as SocketData;
    const ip = clientIp(socket);

    /** Validates a payload with zod, then runs the handler; always answers the ack. */
    function on<S extends ZodTypeAny>(event: string, schema: S | null, handler: (payload: z.infer<S>, ack: Ack) => void | Promise<void>) {
      socket.on(event, (raw: unknown, maybeAck?: unknown) => {
        const ack: Ack = typeof maybeAck === 'function' ? (maybeAck as Ack) : typeof raw === 'function' ? (raw as Ack) : () => {};
        const payload = typeof raw === 'function' ? {} : raw;
        let parsed: z.infer<S>;
        if (schema) {
          const r = schema.safeParse(payload ?? {});
          if (!r.success) return ack({ ok: false, code: 'BAD_REQUEST' });
          parsed = r.data;
        } else parsed = payload as z.infer<S>;
        Promise.resolve(handler(parsed, ack)).catch((e: Error) => ack({ ok: false, code: 'SERVER_ERROR', message: e.message }));
      });
    }

    const room = (): Room | undefined => (data.roomId ? o.manager.get(data.roomId) : undefined);
    const hostRoom = (): Room | undefined => {
      const r = room();
      return data.role === 'host' && r && r.hostId === data.hostId ? r : undefined;
    };

    const attachPlayer = (r: Room, playerId: string) => {
      data.role = 'player';
      data.roomId = r.id;
      data.playerId = playerId;
      void socket.join([chan.players(r.id), chan.player(playerId)]);
      const set = sockets.get(playerId) ?? new Set<string>();
      set.add(socket.id);
      sockets.set(playerId, set);
      r.setConnection(playerId, true);
      const snap = r.resumeSnapshot(playerId) as { state: unknown; round?: unknown; myAnswers?: Record<string, boolean>; cooldownUntil?: number };
      socket.emit('room:state', snap.state);
      const spin = r.spinSnapshot();
      if (spin) {
        socket.emit('spin:wheel', spin.wheel);
        socket.emit('spin:result', spin.result);
      }
      if (snap.round) socket.emit('round:start', snap.round);
      const claims = (snap as { claims?: Record<string, { playerId: string; name: string }> }).claims ?? {};
      for (const [cardId, c] of Object.entries(claims)) socket.emit('card:claimed', { cardId, playerId: c.playerId, name: c.name });
      for (const [cardId, correct] of Object.entries(snap.myAnswers ?? {})) socket.emit('card:result', { cardId, correct, score: (snap.state as { you?: { score: number } }).you?.score ?? 0, cooldownUntil: snap.cooldownUntil });
    };

    on('room:join', JoinSchema, async ({ pin, deviceToken }, ack) => {
      if (!joinAllowed(ip)) return ack({ ok: false, code: 'RATE_LIMITED' });
      const r = o.manager.byPin(pin);
      if (!r) return ack({ ok: false, code: 'NO_ROOM' });
      data.roomId = r.id;
      data.deviceToken = deviceToken;
      const res = await r.join(deviceToken);
      if (!res.ok) {
        const msg = r.blacklistMessage;
        socket.emit('blacklist:rejected', { message: msg });
        return ack({ ok: false, code: res.code, message: msg });
      }
      if (res.resumed && res.playerId) {
        attachPlayer(r, res.playerId);
        return ack({ ok: true, resumed: true, playerId: res.playerId, snapshot: r.resumeSnapshot(res.playerId) });
      }
      ack({ ok: true, resumed: false, roster: r.rosterView(), status: r.status, roomState: r.stateFor('display') });
    });

    on('room:pickName', PickNameSchema, async ({ studentId }, ack) => {
      const r = room();
      if (!r || !data.deviceToken) return ack({ ok: false, code: 'NO_ROOM' });
      const res = await r.pickName(data.deviceToken, studentId);
      if (!res.ok) {
        if (res.code === 'BLACKLISTED') {
          socket.emit('blacklist:rejected', { message: r.blacklistMessage });
          return ack({ ok: false, code: res.code, message: r.blacklistMessage });
        }
        return ack({ ok: false, code: res.code });
      }
      attachPlayer(r, res.playerId);
      ack({ ok: true, playerId: res.playerId, snapshot: r.resumeSnapshot(res.playerId) });
    });

    on('display:join', DisplayJoinSchema, ({ pin }, ack) => {
      const r = o.manager.byPin(pin);
      if (!r) return ack({ ok: false, code: 'NO_ROOM' });
      data.role = 'display';
      data.roomId = r.id;
      void socket.join(chan.displays(r.id));
      ack({ ok: true, state: r.stateFor('display') });
      socket.emit('room:state', r.stateFor('display'));
      const spin = r.spinSnapshot();
      if (spin) {
        socket.emit('spin:wheel', spin.wheel);
        socket.emit('spin:result', spin.result);
      }
      const board = r.boardSnapshot();
      if (board.round) socket.emit('round:start', board.round);
      for (const [cardId, c] of Object.entries(board.claims ?? {})) socket.emit('card:claimed', { cardId, playerId: c.playerId, name: c.name });
    });

    on('host:auth', HostAuthSchema, ({ token, roomId }, ack) => {
      const claims = verifyHostJwt(token, o.jwtSecret, o.clock.now());
      const r = o.manager.get(roomId);
      if (!claims || !r || r.hostId !== claims.hostId) return ack({ ok: false, code: 'UNAUTHORIZED' });
      data.role = 'host';
      data.roomId = r.id;
      data.hostId = claims.hostId;
      void socket.join(chan.hosts(r.id));
      socket.emit('room:state', r.stateFor('host'));
      ack({ ok: true, state: r.stateFor('host'), exportKey: r.exportKey, flags: r.flags.slice(-100) });
    });

    on('game:start', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.startGame() : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('host:pause', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.pause() : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('host:resume', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.resume() : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('round:next', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.nextRound() : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('round:end-now', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.endRoundNow() : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('game:end-now', null, (_p, ack) => {
      const r = hostRoom();
      ack(r ? r.endGameNow(data.hostId ?? 'host') : { ok: false, code: 'UNAUTHORIZED' });
    });
    on('host:kick', HostKickSchema, ({ playerId }, ack) => {
      const r = hostRoom();
      ack(r ? r.kick(playerId, data.hostId ?? 'host') : { ok: false, code: 'UNAUTHORIZED' });
    });

    on('category:pick', CategoryPickSchema, ({ categoryId }, ack) => {
      const r = room();
      if (!r || data.role !== 'player' || !data.playerId) return ack({ ok: false, code: 'NO_NAME' });
      ack(r.pickCategory(data.playerId, categoryId));
    });

    on('card:answer', CardAnswerSchema, ({ cardId, hidden }, ack) => {
      const r = room();
      if (!r || data.role !== 'player' || !data.playerId) return ack({ ok: false, code: 'NO_NAME' });
      const res = r.answer(data.playerId, cardId, hidden === true);
      if (!res.ok) socket.emit('card:rejected', { cardId, code: res.code, cooldownUntil: res.cooldownUntil });
      ack({ ok: res.ok });
    });

    on('client:visibility', VisibilitySchema, ({ hidden }) => {
      const r = room();
      if (r && data.role === 'player' && data.playerId) r.visibility(data.playerId, hidden);
    });

    socket.on('disconnect', () => {
      if (data.role !== 'player' || !data.playerId || !data.roomId) return;
      const set = sockets.get(data.playerId);
      set?.delete(socket.id);
      if (!set || set.size === 0) {
        sockets.delete(data.playerId);
        o.manager.get(data.roomId)?.setConnection(data.playerId, false);
      }
    });
  });

  return { io, ns };
}

import { randomInt, randomUUID } from 'node:crypto';
import { parseSettings, type RoomSettingsInput } from '@glacia/shared';
import type { HostClaims } from './auth';
import type { Room as RoomT, RoomDeps } from './room';
import { Room } from './room';

export class RoomManager {
  readonly rooms = new Map<string, RoomT>();
  private byPinMap = new Map<string, string>();

  constructor(
    private deps: RoomDeps,
    private pinLength = 6,
  ) {}

  private newPin(): string {
    for (let i = 0; i < 1000; i++) {
      const pin = String(randomInt(0, 10 ** this.pinLength)).padStart(this.pinLength, '0');
      if (!this.byPinMap.has(pin)) return pin;
    }
    throw new Error('no free PIN');
  }

  /**
   * `handoffRoster` is the class list SIMPETERI's Multi Permainan menu pushed to the teacher's browser (ids are siswa.id).
   * Without it the roster comes from the SimpeteriPort (tests only: the shipped adapter returns none, so the teacher must send one).
   */
  async create(host: HostClaims, input: RoomSettingsInput, handoffRoster?: { studentId: string; name: string }[]): Promise<RoomT> {
    const settings = parseSettings(input);
    if (!handoffRoster && host.classIds.length === 0) throw new Error('ROSTER_REQUIRED');
    if (!handoffRoster && !host.classIds.includes(settings.classId)) throw new Error('CLASS_NOT_ALLOWED');
    const roster = handoffRoster ?? (await this.deps.port.listStudents(settings.classId));
    if (roster.length === 0) throw new Error('EMPTY_CLASS');
    const maxPlayers = Math.min(settings.maxPlayers, 100);
    const room = new Room({ id: randomUUID(), pin: this.newPin(), hostId: host.hostId, settings: { ...settings, maxPlayers }, roster }, this.deps);
    this.rooms.set(room.id, room);
    this.byPinMap.set(room.pin, room.id);
    return room;
  }

  get(id: string): RoomT | undefined {
    return this.rooms.get(id);
  }
  byPin(pin: string): RoomT | undefined {
    const id = this.byPinMap.get(pin);
    return id ? this.rooms.get(id) : undefined;
  }
  listFor(hostId: string): RoomT[] {
    return [...this.rooms.values()].filter((r) => r.hostId === hostId);
  }
  /** Drops finished rooms older than ttlMs so memory stays bounded on a long-running server. */
  sweep(now: number, ttlMs = 6 * 3600_000) {
    for (const r of this.rooms.values()) {
      if ((r.status === 'DONE' || r.status === 'FINAL') && r.endedAt && now - r.endedAt > ttlMs) {
        this.rooms.delete(r.id);
        this.byPinMap.delete(r.pin);
      }
    }
  }
}

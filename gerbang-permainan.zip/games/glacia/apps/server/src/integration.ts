import { timingSafeEqual } from 'node:crypto';
import type { GameResultPayload } from '@glacia/shared';

/**
 * Port to the outside world (blueprint 9). The shipped adapter is the teacher-PIN one below: the class list comes WITH the
 * room (typed by the teacher, or pushed by SIMPETERI's Multi Permainan menu), never from a built-in list.
 * See docs/SIMPETERI_INTEGRASI.md.
 */
export interface SimpeteriPort {
  verifyHostToken(token: string): Promise<{ hostId: string; name: string; classIds: string[] }>;
  listClasses(hostId: string): Promise<{ id: string; name: string }[]>;
  listStudents(classId: string): Promise<{ studentId: string; name: string }[]>;
  submitResults(payload: GameResultPayload): Promise<void>;
  /** Global blacklist per student. Required on automatic disqualification; retried via the outbox. */
  blacklistStudent(studentId: string, reason: string, evidence: unknown, roomId: string): Promise<void>;
  isBlacklisted(studentId: string): Promise<boolean>;
  liftBlacklist(studentId: string, actorId: string, note: string): Promise<void>;
}

/**
 * One teacher PIN per game server (HOST_PIN), the same model CLAIM 80 uses.
 * - `multi`: SIMPETERI opens `{this server}/host`, hands over the class roster + PIN with an origin-checked postMessage,
 *   and later PULLS `/api/sessions/:id/summary.json` (header `x-host-token: <PIN>`), matching students by `siswa.id`.
 * - `mandiri`: no SIMPETERI; the teacher types or pastes the student names when opening the room.
 * Either way nothing is pushed anywhere: results are served, not submitted. The blacklist stays in GLACIA's own store.
 */
export class HandoffSimpeteriAdapter implements SimpeteriPort {
  constructor(private readonly hostPin: string) {
    if (!/^\S{4,32}$/.test(hostPin)) throw new Error('HOST_PIN must be 4-32 characters without spaces');
  }
  async verifyHostToken(token: string) {
    const a = Buffer.from(token);
    const b = Buffer.from(this.hostPin);
    if (a.length !== b.length || !timingSafeEqual(a, b)) throw new Error('invalid PIN');
    return { hostId: 'guru', name: 'Guru', classIds: [] as string[] };
  }
  async listClasses() {
    return [];
  }
  async listStudents(): Promise<{ studentId: string; name: string }[]> {
    return []; // the roster arrives with POST /rooms
  }
  async submitResults() {
    /* pull model: the teacher downloads the CSV or SIMPETERI reads summary.json */
  }
  async blacklistStudent() {
    /* kept locally (store.ts) */
  }
  async isBlacklisted() {
    return false;
  }
  async liftBlacklist() {
    /* local only */
  }
}

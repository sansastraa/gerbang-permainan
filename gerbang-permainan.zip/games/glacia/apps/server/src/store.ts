import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import type { GameResultPayload } from '@glacia/shared';

export interface BlacklistRow {
  id: string;
  studentId: string;
  studentName: string;
  classId: string;
  reason: string;
  roomId: string | null;
  evidence: unknown;
  createdAt: number;
  liftedAt: number | null;
  liftedBy: string | null;
  liftNote: string | null;
  syncedToSimpeteri: boolean;
}

export interface AuditRow {
  id: string;
  actorId: string;
  action: string; // BLACKLIST_LIFT | REINSTATE | MANUAL_DQ | AUTO_DQ | KICK | ...
  target: string;
  detail: unknown;
  at: number;
}

export interface OutboxRow {
  id: string;
  type: 'RESULT' | 'BLACKLIST' | 'LIFT';
  payload: unknown;
  attempts: number;
  lastError: string | null;
  createdAt: number;
  done: boolean;
}

export interface FinishedRoomRow {
  roomId: string;
  classId: string;
  hostId: string;
  playedAt: number;
  payload: GameResultPayload;
  summary: unknown;
  exportKey: string;
}

interface StoreData {
  blacklist: BlacklistRow[];
  audit: AuditRow[];
  outbox: OutboxRow[];
  rooms: FinishedRoomRow[];
}

/**
 * Durable state that must outlive a room: blacklist, audit trail, outbox, finished-room reports.
 * Development substitute for PostgreSQL (see docs/ASSUMPTIONS.md): one JSON file, written atomically.
 * Pass filePath=null for a purely in-memory store (tests).
 */
export class Store {
  private data: StoreData = { blacklist: [], audit: [], outbox: [], rooms: [] };
  private dirty = false;
  private timer: NodeJS.Timeout | null = null;

  constructor(private filePath: string | null) {
    if (filePath && fs.existsSync(filePath)) {
      this.data = { ...this.data, ...(JSON.parse(fs.readFileSync(filePath, 'utf8')) as Partial<StoreData>) };
    }
  }

  private touch() {
    if (!this.filePath) return;
    this.dirty = true;
    if (this.timer) return;
    this.timer = setTimeout(() => {
      this.timer = null;
      this.flush();
    }, 200);
    this.timer.unref?.();
  }

  flush() {
    if (!this.filePath || !this.dirty) return;
    this.dirty = false;
    fs.mkdirSync(path.dirname(this.filePath), { recursive: true });
    const tmp = `${this.filePath}.tmp`;
    fs.writeFileSync(tmp, JSON.stringify(this.data));
    fs.renameSync(tmp, this.filePath);
  }

  // ---- blacklist
  activeBlacklist(studentId: string): BlacklistRow | undefined {
    return this.data.blacklist.find((b) => b.studentId === studentId && b.liftedAt === null);
  }
  listBlacklist(filter: { classId?: string; active?: boolean } = {}): BlacklistRow[] {
    return this.data.blacklist.filter(
      (b) =>
        (filter.classId === undefined || b.classId === filter.classId) &&
        (filter.active === undefined || (b.liftedAt === null) === filter.active),
    );
  }
  addBlacklist(row: Omit<BlacklistRow, 'id' | 'createdAt' | 'liftedAt' | 'liftedBy' | 'liftNote' | 'syncedToSimpeteri'>, at: number): BlacklistRow {
    const r: BlacklistRow = { ...row, id: randomUUID(), createdAt: at, liftedAt: null, liftedBy: null, liftNote: null, syncedToSimpeteri: false };
    this.data.blacklist.push(r);
    this.touch();
    return r;
  }
  liftBlacklist(studentId: string, actorId: string, note: string, at: number): BlacklistRow[] {
    const rows = this.data.blacklist.filter((b) => b.studentId === studentId && b.liftedAt === null);
    for (const r of rows) {
      r.liftedAt = at;
      r.liftedBy = actorId;
      r.liftNote = note;
    }
    this.touch();
    return rows;
  }
  markSynced(id: string) {
    const r = this.data.blacklist.find((b) => b.id === id);
    if (r) {
      r.syncedToSimpeteri = true;
      this.touch();
    }
  }

  // ---- audit
  addAudit(actorId: string, action: string, target: string, detail: unknown, at: number): AuditRow {
    const r: AuditRow = { id: randomUUID(), actorId, action, target, detail, at };
    this.data.audit.push(r);
    this.touch();
    return r;
  }
  listAudit(): AuditRow[] {
    return this.data.audit.slice();
  }

  // ---- outbox
  addOutbox(type: OutboxRow['type'], payload: unknown, error: string, at: number): OutboxRow {
    const r: OutboxRow = { id: randomUUID(), type, payload, attempts: 3, lastError: error, createdAt: at, done: false };
    this.data.outbox.push(r);
    this.touch();
    return r;
  }
  pendingOutbox(): OutboxRow[] {
    return this.data.outbox.filter((o) => !o.done);
  }
  updateOutbox(id: string, patch: Partial<OutboxRow>) {
    const r = this.data.outbox.find((o) => o.id === id);
    if (r) {
      Object.assign(r, patch);
      this.touch();
    }
  }

  // ---- finished rooms
  saveRoom(row: FinishedRoomRow) {
    this.data.rooms = this.data.rooms.filter((r) => r.roomId !== row.roomId).concat(row);
    this.touch();
  }
  getRoom(roomId: string): FinishedRoomRow | undefined {
    return this.data.rooms.find((r) => r.roomId === roomId);
  }
  listRooms(hostId: string): FinishedRoomRow[] {
    return this.data.rooms.filter((r) => r.hostId === hostId);
  }
}

import type { GameResultPayload } from '@glacia/shared';
import type { SimpeteriPort } from '../src/integration';

/** Test-only stand-in for SIMPETERI with a made-up roster. It is NOT part of the app: nothing in src/ imports it. */
export const DEV_HOST_TOKEN = 'dev-host-token';

const FIRST = ['Budi', 'Siti', 'Andi', 'Dewi', 'Rizky', 'Putri', 'Fajar', 'Nadia', 'Bima', 'Citra', 'Dimas', 'Eka', 'Farhan', 'Gita', 'Hana', 'Indra', 'Joko', 'Kirana', 'Lukman', 'Maya', 'Naufal', 'Olivia', 'Raka', 'Salsa', 'Tegar', 'Umar', 'Vina', 'Wahyu', 'Yuni', 'Zaki'];
const LAST = ['Santoso', 'Lestari', 'Pratama', 'Wulandari', 'Hidayat', 'Kusuma', 'Ramadhan', 'Safitri', 'Nugroho', 'Maharani'];

export function mockRoster(classId: string, n = 30): { studentId: string; name: string }[] {
  return Array.from({ length: n }, (_, i) => ({
    studentId: `${classId}-S${String(i + 1).padStart(2, '0')}`,
    name: `${FIRST[i % FIRST.length]} ${LAST[Math.floor(i / FIRST.length + i) % LAST.length]}`,
  }));
}

export class MockSimpeteriAdapter implements SimpeteriPort {
  readonly submitted: GameResultPayload[] = [];
  readonly blacklisted = new Map<string, { reason: string; roomId: string; evidence: unknown }>();
  readonly lifted: { studentId: string; actorId: string; note: string }[] = [];
  /** make the next N calls to submitResults/blacklistStudent fail */
  failNext = 0;

  async verifyHostToken(token: string) {
    if (token !== DEV_HOST_TOKEN) throw new Error('invalid host token');
    return { hostId: 'guru-dev', name: 'Bu Guru (uji)', classIds: ['kelas-6a', 'kelas-6b', 'kelas-beban'] };
  }
  async listClasses() {
    return [
      { id: 'kelas-6a', name: 'Kelas 6A' },
      { id: 'kelas-6b', name: 'Kelas 6B' },
      { id: 'kelas-beban', name: 'Kelas Uji Beban (100 siswa)' },
    ];
  }
  async listStudents(classId: string) {
    return mockRoster(classId, classId === 'kelas-beban' ? 100 : 30);
  }
  private maybeFail() {
    if (this.failNext > 0) {
      this.failNext--;
      throw new Error('mock SIMPETERI unavailable');
    }
  }
  async submitResults(payload: GameResultPayload) {
    this.maybeFail();
    this.submitted.push(payload);
  }
  async blacklistStudent(studentId: string, reason: string, evidence: unknown, roomId: string) {
    this.maybeFail();
    this.blacklisted.set(studentId, { reason, roomId, evidence });
  }
  async isBlacklisted(studentId: string) {
    return this.blacklisted.has(studentId);
  }
  async liftBlacklist(studentId: string, actorId: string, note: string) {
    this.blacklisted.delete(studentId);
    this.lifted.push({ studentId, actorId, note });
  }
}

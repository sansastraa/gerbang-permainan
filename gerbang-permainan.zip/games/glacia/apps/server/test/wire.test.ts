import path from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { io, type Socket } from 'socket.io-client';
import { FORBIDDEN_KEYS, findForbiddenKeys } from '@glacia/shared';
import { loadConfig } from '../src/config';
import { ManualClock } from '../src/clock';
import { MockSimpeteriAdapter, DEV_HOST_TOKEN } from './mock-simpeteri';
import { buildServer } from '../src/server';
import { Store } from '../src/store';
import { correctCards, internals, repo } from './harness';

const config = loadConfig({ DATA_DIR: path.resolve(__dirname, '../../../data'), JWT_SECRET: 'test-secret', OUTBOX_BASE_DELAY_MS: '1' } as NodeJS.ProcessEnv);
const clock = new ManualClock();
const store = new Store(null);
const port = new MockSimpeteriAdapter();
const srv = buildServer({ config, repo, clock, store, port, joinLimitPerMin: 1000 });
let base = '';
const sockets: Socket[] = [];

beforeAll(async () => {
  const p = await srv.listen(0);
  base = `http://127.0.0.1:${p}`;
});
afterAll(async () => {
  sockets.forEach((s) => s.disconnect());
  await srv.close();
  srv.httpServer.close();
});

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function until(cond: () => boolean, ms = 3000, what = 'condition') {
  const t0 = Date.now();
  while (!cond()) {
    if (Date.now() - t0 > ms) throw new Error(`timeout waiting for ${what}`);
    await sleep(5);
  }
}
const rest = async (p: string, jwt?: string, init: { method?: string; body?: unknown } = {}) => {
  const res = await fetch(`${base}/api${p}`, { method: init.method ?? 'GET', headers: { 'Content-Type': 'application/json', ...(jwt ? { Authorization: `Bearer ${jwt}` } : {}) }, body: init.body === undefined ? undefined : JSON.stringify(init.body) });
  const ct = res.headers.get('content-type') ?? '';
  return { status: res.status, body: ct.includes('json') ? ((await res.json()) as Record<string, any>) : await res.text() }; // eslint-disable-line @typescript-eslint/no-explicit-any
};

interface Client {
  s: Socket;
  log: { event: string; payload: unknown }[];
  last(event: string): any; // eslint-disable-line @typescript-eslint/no-explicit-any
  emit(event: string, payload?: unknown): Promise<any>; // eslint-disable-line @typescript-eslint/no-explicit-any
}
async function connect(): Promise<Client> {
  const s = io(`${base}/game`, { transports: ['websocket'], reconnection: false });
  sockets.push(s);
  const log: Client['log'] = [];
  s.onAny((event, payload) => log.push({ event, payload }));
  await new Promise<void>((r) => s.on('connect', () => r()));
  return {
    s,
    log,
    last: (e) => [...log].reverse().find((m) => m.event === e)?.payload,
    emit: (event, payload = {}) => new Promise((r) => s.emit(event, payload, r)),
  };
}

async function newRoom(extra: Record<string, unknown> = {}) {
  const a = await rest('/auth/host', undefined, { method: 'POST', body: { token: DEV_HOST_TOKEN } });
  const jwt = a.body.jwt as string;
  const r = await rest('/rooms', jwt, { method: 'POST', body: { classId: 'kelas-6a', rounds: 3, roundSeconds: 60, ...extra } });
  return { jwt, roomId: r.body.roomId as string, pin: r.body.pin as string };
}

async function joinBots(pin: string, n: number, offset = 0) {
  const bots: (Client & { playerId: string })[] = [];
  for (let i = 0; i < n; i++) {
    const c = await connect();
    const j = await c.emit('room:join', { pin, deviceToken: `wire-device-${pin}-${i + offset}-abcdef` });
    expect(j.ok).toBe(true);
    const pick = await c.emit('room:pickName', { studentId: `kelas-6a-S${String(i + 1 + offset).padStart(2, '0')}` });
    expect(pick.ok, JSON.stringify(pick)).toBe(true);
    bots.push(Object.assign(c, { playerId: pick.playerId as string }));
  }
  return bots;
}

async function hostFor(jwt: string, roomId: string) {
  const h = await connect();
  const ack = await h.emit('host:auth', { token: jwt, roomId });
  expect(ack.ok).toBe(true);
  return h;
}

async function toRunning(host: Client, bots: Client[], roomId: string) {
  const start = await host.emit('game:start');
  expect(start).toMatchObject({ ok: true });
  clock.advance(6000);
  const room = srv.manager.get(roomId)!;
  const picker = bots.find((b) => (b as unknown as { playerId: string }).playerId === internals(room).pickerId)!;
  await until(() => !!picker.last('category:options'), 2000, 'category options');
  const opts = picker.last('category:options').categories as { id: number }[];
  expect(opts).toHaveLength(5);
  expect(await picker.emit('category:pick', { categoryId: opts[0]!.id })).toMatchObject({ ok: true });
  clock.advance(3000);
  await until(() => bots.every((b) => !!b.last('round:start')), 3000, 'round:start');
}

describe('REST', () => {
  it('health, auth, class guard, validation and settings lock', async () => {
    expect((await rest('/health')).body).toMatchObject({ ok: true, questions: 7500 });
    expect((await rest('/auth/host', undefined, { method: 'POST', body: { token: 'wrong' } })).status).toBe(401);
    expect((await rest('/rooms', undefined, { method: 'POST', body: {} })).status).toBe(401);
    const { jwt, roomId } = await newRoom();
    expect((await rest('/classes', jwt)).body.classes).toHaveLength(3);
    expect((await rest('/rooms', jwt, { method: 'POST', body: { classId: 'kelas-lain' } })).status).toBe(403);
    expect((await rest('/rooms', jwt, { method: 'POST', body: { classId: 'kelas-6a', allowedCategoryIds: [] } })).status).toBe(400);
    expect((await rest(`/rooms/${roomId}`, jwt)).body.room.status).toBe('LOBBY');
    expect((await rest(`/rooms/${roomId}/settings`, jwt, { method: 'PATCH', body: { rounds: 4 } })).status).toBe(200);
    expect((await rest(`/rooms/${roomId}`, jwt)).body.room.settings.rounds).toBe(4);
    expect((await rest(`/rooms/nope`, jwt)).status).toBe(404);
    const other = (await rest('/auth/host', undefined, { method: 'POST', body: { token: DEV_HOST_TOKEN } })).body.jwt as string;
    expect(other).toBeTruthy();
  });

  it('rejects an expired or tampered JWT', async () => {
    const { jwt } = await newRoom();
    expect((await rest('/classes', jwt + 'x')).status).toBe(401);
    clock.advance(7 * 3600_000);
    expect((await rest('/classes', jwt)).status).toBe(401);
  });
});

describe('sockets', () => {
  it('30 bots join, duplicate names and late joiners are rejected, wrong PIN is refused', async () => {
    const { jwt, roomId, pin } = await newRoom({ maxPlayers: 30 });
    const bots = await joinBots(pin, 30);
    expect(new Set(bots.map((b) => b.playerId)).size).toBe(30);
    const c = await connect();
    expect(await c.emit('room:join', { pin: '000000', deviceToken: 'whatever-device-1' })).toMatchObject({ ok: false, code: 'NO_ROOM' });
    expect(await c.emit('room:join', { pin: 'abc', deviceToken: 'whatever-device-1' })).toMatchObject({ ok: false, code: 'BAD_REQUEST' });
    const j = await c.emit('room:join', { pin, deviceToken: 'whatever-device-2' });
    expect(j.roster.filter((r: { taken: boolean }) => r.taken)).toHaveLength(30);
    expect(await c.emit('room:pickName', { studentId: 'kelas-6a-S01' })).toMatchObject({ ok: false, code: 'NAME_TAKEN' });
    const host = await hostFor(jwt, roomId);
    await until(() => (host.last('room:state')?.players?.length ?? 0) === 30, 2000, 'host sees 30 players');
    expect(srv.manager.get(roomId)!.players.size).toBe(30);
  });

  it('players cannot use host commands; a host cannot touch another room', async () => {
    const { roomId, pin } = await newRoom();
    const [bot] = await joinBots(pin, 2);
    expect(await bot!.emit('game:start')).toMatchObject({ ok: false, code: 'UNAUTHORIZED' });
    expect(await bot!.emit('game:end-now')).toMatchObject({ ok: false, code: 'UNAUTHORIZED' });
    const c = await connect();
    expect(await c.emit('host:auth', { token: 'bad.token.value', roomId })).toMatchObject({ ok: false });
    const stranger = await connect();
    expect(await stranger.emit('card:answer', { cardId: crypto.randomUUID() })).toMatchObject({ ok: false });
  });

  it('blacklisted student gets blacklist:rejected and the name stays free', async () => {
    store.addBlacklist({ studentId: 'kelas-6a-S20', studentName: 'Siswa 20', classId: 'kelas-6a', reason: 'BLUR_STREAK', roomId: 'old', evidence: {} }, 1);
    const { pin } = await newRoom();
    const c = await connect();
    await c.emit('room:join', { pin, deviceToken: 'bl-device-xxxxxx' });
    const res = await c.emit('room:pickName', { studentId: 'kelas-6a-S20' });
    expect(res).toMatchObject({ ok: false, code: 'BLACKLISTED' });
    await until(() => !!c.last('blacklist:rejected'), 1000, 'blacklist:rejected');
    expect(c.last('blacklist:rejected').message).toContain('temui gurumu');
    const j = await (await connect()).emit('room:join', { pin, deviceToken: 'other-device-xxxxx' });
    expect(j.roster.find((r: { studentId: string }) => r.studentId === 'kelas-6a-S20').taken).toBe(false);
  });

  it('claim race over the wire: exactly one winner, everyone sees the claim, no key leaks', async () => {
    const { jwt, roomId, pin } = await newRoom();
    const bots = await joinBots(pin, 6);
    const host = await hostFor(jwt, roomId);
    const display = await connect();
    await display.emit('display:join', { pin });
    await toRunning(host, bots, roomId);
    const room = srv.manager.get(roomId)!;
    const card = correctCards(room)[0]!;
    clock.advance(4000);
    const results = await Promise.all(bots.slice(0, 4).map((b) => b.emit('card:answer', { cardId: card.id })));
    expect(results.filter((r) => r.ok)).toHaveLength(1); // the ack already tells each presser whether it won
    await until(() => bots.every((b) => !!b.last('card:claimed')), 2000, 'card:claimed everywhere');
    await until(() => !!display.last('card:claimed'), 1000, 'display sees claim');
    const winners = bots.filter((b) => b.log.some((m) => m.event === 'card:result' && (m.payload as { cardId: string }).cardId === card.id));
    const losers = bots.slice(0, 4).filter((b) => b.log.some((m) => m.event === 'card:rejected' && (m.payload as { code: string }).code === 'CARD_CLAIMED'));
    expect(winners).toHaveLength(1);
    expect(losers).toHaveLength(3);
    expect(room.answers.filter((a) => a.cardId === card.id)).toHaveLength(1);
    // nothing sent to any client so far carries a key field
    for (const c of [...bots, display]) for (const m of c.log) expect(findForbiddenKeys(m.payload, FORBIDDEN_KEYS), `${m.event}`).toEqual([]);
    // every bot got the same board, in the same order
    const orders = bots.map((b) => (b.last('round:start').cards as { cardId: string }[]).map((x) => x.cardId).join());
    expect(new Set(orders).size).toBe(1);
    // host ends the round, then the whole game
    expect(await host.emit('round:end-now')).toMatchObject({ ok: true });
    await until(() => bots.every((b) => !!b.last('round:end')), 2000, 'round:end');
    expect((bots[0]!.last('round:end').keyReveal as unknown[]).length).toBe(64);
    expect(await host.emit('game:end-now')).toMatchObject({ ok: true });
    await until(() => bots.every((b) => !!b.last('game:end')), 3000, 'game:end');
    await until(() => port.submitted.some((p) => p.roomId === roomId), 3000, 'report submitted');
  });

  it('reconnecting with the same device resumes the round with claims and score', async () => {
    const { jwt, roomId, pin } = await newRoom();
    const bots = await joinBots(pin, 3);
    const host = await hostFor(jwt, roomId);
    await toRunning(host, bots, roomId);
    const room = srv.manager.get(roomId)!;
    clock.advance(3000);
    const cards = correctCards(room);
    await bots[0]!.emit('card:answer', { cardId: cards[0]!.id });
    await bots[1]!.emit('card:answer', { cardId: cards[1]!.id });
    await until(() => room.answers.length === 2, 1000, 'two answers');
    bots[0]!.s.disconnect();
    await until(() => !room.players.get(bots[0]!.playerId)!.online, 1000, 'offline');
    const back = await connect();
    const res = await back.emit('room:join', { pin, deviceToken: `wire-device-${pin}-0-abcdef` });
    expect(res).toMatchObject({ ok: true, resumed: true });
    await until(() => !!back.last('round:start'), 1000, 'round restored');
    await until(() => !!back.last('card:claimed'), 1000, 'claims restored');
    expect(back.log.filter((m) => m.event === 'card:claimed')).toHaveLength(2);
    expect(back.last('room:state').you.score).toBeGreaterThan(0);
  });

  it('summary.json needs the host JWT or the room key; CSV needs the JWT', async () => {
    const { jwt, roomId, pin } = await newRoom();
    const bots = await joinBots(pin, 3);
    const host = await hostFor(jwt, roomId);
    await toRunning(host, bots, roomId);
    await host.emit('game:end-now');
    await until(() => srv.manager.get(roomId)!.status === 'DONE', 3000, 'DONE');
    const key = srv.manager.get(roomId)!.exportKey;
    expect((await rest(`/rooms/${roomId}/summary.json`)).status).toBe(404);
    expect((await rest(`/rooms/${roomId}/summary.json?key=wrong`)).status).toBe(404);
    const ok = await rest(`/rooms/${roomId}/summary.json?key=${key}`);
    expect(ok.status).toBe(200);
    expect(ok.body).toMatchObject({ game: 'glacia', sessionId: roomId });
    expect(ok.body.students).toHaveLength(3);
    expect((await rest(`/rooms/${roomId}/report.csv`)).status).toBe(401);
    const csv = await rest(`/rooms/${roomId}/report.csv`, jwt);
    expect(String(csv.body)).toContain('Peringkat');
    expect((await rest(`/rooms/${roomId}/report/resend`, jwt, { method: 'POST' })).status).toBe(200);
  });

  it('REST disqualify / reinstate / blacklist / lift with audit trail', async () => {
    const { jwt, roomId, pin } = await newRoom();
    const bots = await joinBots(pin, 4);
    const host = await hostFor(jwt, roomId);
    await toRunning(host, bots, roomId);
    const target = bots[1]!;
    expect((await rest(`/rooms/${roomId}/players/${target.playerId}/disqualify`, jwt, { method: 'POST', body: { reason: '' } })).status).toBe(400);
    const dq = await rest(`/rooms/${roomId}/players/${target.playerId}/disqualify`, jwt, { method: 'POST', body: { reason: 'melihat HP teman', blacklist: true } });
    expect(dq.status).toBe(200);
    await until(() => !!target.last('you:disqualified'), 1000, 'you:disqualified');
    const bl = await rest('/blacklist?active=true', jwt);
    const row = bl.body.rows.find((r: { studentId: string }) => r.studentId === 'kelas-6a-S02');
    expect(row).toBeTruthy();
    expect((await rest('/blacklist/kelas-6a-S02/lift', jwt, { method: 'POST', body: { note: '' } })).status).toBe(400);
    const lift = await rest('/blacklist/kelas-6a-S02/lift', jwt, { method: 'POST', body: { note: 'salah deteksi, sudah dicek guru' } });
    expect(lift.body).toMatchObject({ ok: true, syncedToSimpeteri: true });
    expect((await rest('/blacklist/kelas-6a-S02/lift', jwt, { method: 'POST', body: { note: 'sekali lagi' } })).status).toBe(404);
    const re = await rest(`/rooms/${roomId}/players/${target.playerId}/reinstate`, jwt, { method: 'POST' });
    expect(re.status).toBe(200);
    const audit = (await rest('/audit', jwt)).body.rows.map((a: { action: string }) => a.action);
    expect(audit).toEqual(expect.arrayContaining(['MANUAL_DQ', 'BLACKLIST_LIFT', 'REINSTATE']));
  });

  it('rate-limits room:join per IP', async () => {
    const limited = buildServer({ config, repo, clock: new ManualClock(), store: new Store(null), port: new MockSimpeteriAdapter(), joinLimitPerMin: 3 });
    const p = await limited.listen(0);
    const c = io(`http://127.0.0.1:${p}/game`, { transports: ['websocket'], reconnection: false });
    await new Promise<void>((r) => c.on('connect', () => r()));
    const codes: string[] = [];
    for (let i = 0; i < 5; i++) codes.push(((await new Promise((r) => c.emit('room:join', { pin: '111111', deviceToken: `rl-device-${i}-xxxx` }, r))) as { code: string }).code);
    expect(codes.filter((x) => x === 'RATE_LIMITED').length).toBe(2);
    c.disconnect();
    await limited.close();
    limited.httpServer.close();
  });
});

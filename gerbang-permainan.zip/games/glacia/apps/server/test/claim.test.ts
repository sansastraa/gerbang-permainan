import { describe, expect, it } from 'vitest';
import { FORBIDDEN_KEYS, findForbiddenKeys, pointsForCorrect } from '@glacia/shared';
import { answerCorrect, blur, correctCards, internals, keyCards, makeWorld, toRunning, wrongCards } from './harness';

describe('claim mode: first correct answer takes the card', () => {
  it('locks the card for everyone else and broadcasts who claimed it', async () => {
    const w = await makeWorld({ players: 4 });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    const card = correctCards(w.room)[0]!;
    w.clock.advance(4000);
    expect(w.room.answer(a, card.id)).toMatchObject({ ok: true, correct: true, points: pointsForCorrect(4000), bonus: 0 });
    const ev = w.emitter.of('card:claimed');
    expect(ev).toHaveLength(1);
    expect(ev[0]!.aud).toEqual({ to: 'all' });
    expect(ev[0]!.payload).toMatchObject({ cardId: card.id, playerId: a });
    w.clock.advance(50);
    expect(w.room.answer(b, card.id)).toMatchObject({ ok: false, code: 'CARD_CLAIMED' });
    // the rejected player is not penalised and not on cooldown
    expect(w.room.liveScore(w.room.players.get(b)!)).toBe(0);
    const other = correctCards(w.room)[1]!;
    expect(w.room.answer(b, other.id)).toMatchObject({ ok: true });
  });

  it('is decided by arrival order when two players press the same card in the same instant', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    const card = correctCards(w.room)[0]!;
    w.clock.advance(3000);
    const first = w.room.answer(b, card.id);
    const second = w.room.answer(a, card.id);
    expect(first.ok).toBe(true);
    expect(second).toMatchObject({ ok: false, code: 'CARD_CLAIMED' });
  });

  it('a wrong answer does not claim anything: decoys stay private to the one who tapped them', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    const decoy = wrongCards(w.room)[0]!;
    w.clock.advance(3000);
    expect(w.room.answer(a, decoy.id)).toMatchObject({ ok: true, correct: false });
    expect(w.emitter.of('card:claimed')).toHaveLength(0);
    expect(w.room.answer(b, decoy.id)).toMatchObject({ ok: true, correct: false }); // b still pays for it
  });

  it('does not leak which free cards are correct (progress only counts)', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    answerCorrect(w, w.ids[0]!, 3);
    for (const m of w.emitter.msgs) expect(findForbiddenKeys(m.payload, FORBIDDEN_KEYS), m.event).toEqual([]);
    const sb = w.emitter.of('scoreboard:live').at(-1)!.payload as { claimed: number; remaining: number };
    expect(sb.claimed).toBe(3);
    expect(sb.claimed + sb.remaining).toBe(correctCards(w.room).length);
  });

  it('reconnect restores the claims', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    answerCorrect(w, w.ids[0]!, 2);
    const snap = w.room.resumeSnapshot(w.ids[1]!) as { claims: Record<string, { playerId: string }> };
    expect(Object.keys(snap.claims)).toHaveLength(2);
    expect(Object.values(snap.claims).every((c) => c.playerId === w.ids[0])).toBe(true);
  });

  it('a disqualified player\'s claims are released for everybody', async () => {
    const w = await makeWorld({ players: 4 });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    blur(w, a, 3000);
    answerCorrect(w, a, 4);
    expect(w.room.players.get(a)!.disqualified).toBe(true);
    expect(w.emitter.of('card:released')).toHaveLength(4);
    expect((internals(w.room).round.claims as Map<string, unknown>).size).toBe(0);
    const freed = w.emitter.of('card:released')[0]!.payload as { cardId: string };
    w.clock.advance(1500);
    expect(w.room.answer(b, freed.cardId)).toMatchObject({ ok: true, correct: true });
  });

  it('ends the round by itself shortly after the last correct card is claimed', async () => {
    const w = await makeWorld({ players: 3, settings: { roundSeconds: 300 } });
    toRunning(w);
    const cards = correctCards(w.room);
    const ids = w.ids;
    cards.forEach((c, i) => {
      w.clock.advance(1100);
      expect(w.room.answer(ids[i % 3]!, c.id).ok).toBe(true);
    });
    expect(w.room.status).toBe('RUNNING'); // 1.5 s grace
    w.clock.advance(1600);
    expect(w.room.status).toBe('ROUND_RESULT');
    const end = w.emitter.of('round:end')[0]!.payload as { roundScores: { perfect: boolean }[] };
    expect(end.roundScores.every((r) => !r.perfect)).toBe(true); // no perfect-round bonus when cards are contested
  });

  it('claimMode=false keeps the old shared-board behaviour', async () => {
    const w = await makeWorld({ players: 3, settings: { claimMode: false } });
    toRunning(w);
    const card = correctCards(w.room)[0]!;
    w.clock.advance(3000);
    expect(w.room.answer(w.ids[0]!, card.id).ok).toBe(true);
    expect(w.room.answer(w.ids[1]!, card.id)).toMatchObject({ ok: true, bonus: 200 });
    expect(w.emitter.of('card:claimed')).toHaveLength(0);
  });
});

describe('host: end round / end game', () => {
  it('"Akhiri ronde" scores the round immediately, also while paused', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    answerCorrect(w, w.ids[0]!, 2);
    expect(w.room.endRoundNow()).toMatchObject({ ok: true });
    expect(w.room.status).toBe('ROUND_RESULT');
    expect(w.emitter.of('round:end')).toHaveLength(1);
    expect(w.room.players.get(w.ids[0]!)!.totalScore).toBeGreaterThan(0);
    expect(w.room.endRoundNow()).toMatchObject({ ok: false, code: 'BAD_STATE' });

    const p = await makeWorld({ players: 3 });
    toRunning(p);
    p.room.pause();
    expect(p.room.endRoundNow()).toMatchObject({ ok: true });
    expect(p.room.status).toBe('ROUND_RESULT');
  });

  it('"Akhiri permainan" counts the running round, builds the final board and submits the report', async () => {
    const w = await makeWorld({ players: 4, settings: { rounds: 5 } });
    toRunning(w);
    answerCorrect(w, w.ids[1]!, 3);
    expect(w.room.endGameNow('guru-dev')).toMatchObject({ ok: true });
    for (let i = 0; i < 100 && w.room.status !== 'DONE'; i++) await new Promise((r) => setTimeout(r, 10));
    expect(w.room.status).toBe('DONE');
    const end = w.emitter.of('game:end')[0]!.payload as { finalBoard: { playerId: string; score: number }[] };
    expect(end.finalBoard[0]).toMatchObject({ playerId: w.ids[1], });
    expect(end.finalBoard[0]!.score).toBeGreaterThan(0);
    expect(w.port.submitted).toHaveLength(1);
    expect(w.store.listAudit().some((a) => a.action === 'END_GAME')).toBe(true);
    expect(keyCards(w.room)).toHaveLength(64);
  });

  it('can end the game from every in-game phase but not from the lobby', async () => {
    const lobby = await makeWorld({ players: 3 });
    expect(lobby.room.endGameNow('g')).toMatchObject({ ok: false, code: 'BAD_STATE' });
    const spin = await makeWorld({ players: 3 });
    spin.room.startGame();
    expect(spin.room.endGameNow('g')).toMatchObject({ ok: true });
    await new Promise((r) => setTimeout(r, 30));
    expect(spin.room.status).toBe('DONE');
    const result = await makeWorld({ players: 3 });
    toRunning(result);
    result.room.endRoundNow();
    expect(result.room.endGameNow('g')).toMatchObject({ ok: true });
    await new Promise((r) => setTimeout(r, 30));
    expect(result.room.status).toBe('DONE');
    expect(result.room.endGameNow('g')).toMatchObject({ ok: false });
  });
});

describe('shared board and finishing early', () => {
  it('every student gets the same cards in the same order; the layout differs between boards', async () => {
    const w = await makeWorld({ players: 5, settings: { rounds: 2 } });
    toRunning(w);
    const starts = w.emitter.of('round:start').filter((m) => m.aud.to === 'players');
    expect(starts).toHaveLength(1); // one broadcast, not one message per student
    const first = (starts[0]!.payload as { cards: { cardId: string }[] }).cards.map((c) => c.cardId);
    expect(first).toHaveLength(64);
    const snaps = w.ids.map((id) => (w.room.resumeSnapshot(id) as { round: { cards: { cardId: string }[] } }).round.cards.map((c) => c.cardId));
    snaps.forEach((s) => expect(s).toEqual(first));
    expect(first).not.toEqual(keyCards(w.room).map((c) => c.id).slice().sort()); // shuffled, not grouped
    const tiers = (internals(w.room).round.cards as { q: { isCorrect: boolean } }[]).map((c) => c.q.isCorrect);
    expect(tiers.slice(0, 20).some((x) => x) && tiers.slice(0, 20).some((x) => !x)).toBe(true); // correct and decoys are mixed
  });

  it('after the last board the game ends at once, with time to spare, and the ranking goes out', async () => {
    const w = await makeWorld({ players: 4, settings: { rounds: 2, roundSeconds: 600 } });
    toRunning(w);
    // board 1: claim every correct card
    for (const [i, c] of correctCards(w.room).entries()) {
      w.clock.advance(1100);
      expect(w.room.answer(w.ids[i % 4]!, c.id).ok).toBe(true);
    }
    w.clock.advance(1600);
    expect(w.room.status).toBe('ROUND_RESULT');
    w.room.nextRound();
    toRunning(w);
    expect(w.room.roundNo).toBe(2);
    for (const [i, c] of correctCards(w.room).entries()) {
      w.clock.advance(1100);
      w.room.answer(w.ids[(i + 1) % 4]!, c.id);
    }
    w.clock.advance(1600); // the 'end early' grace; the 600 s timer is nowhere near
    for (let i = 0; i < 100 && w.room.status !== 'DONE'; i++) await new Promise((r) => setTimeout(r, 10));
    expect(w.room.status).toBe('DONE');
    expect(w.clock.now() - (internals(w.room).round.startedAt as number)).toBeLessThan(600_000 / 4);
    const end = w.emitter.of('game:end')[0]!.payload as { finalBoard: { rank: number; score: number }[]; podium: unknown[] };
    expect(end.finalBoard).toHaveLength(4);
    expect(end.finalBoard.map((r) => r.rank)).toEqual([1, 2, 3, 4]);
    expect(end.finalBoard[0]!.score).toBeGreaterThanOrEqual(end.finalBoard[3]!.score);
    expect(w.port.submitted).toHaveLength(1);
  });

  it('a 5-board game covers 5 x 64 = 320 numbers', async () => {
    const w = await makeWorld({ players: 4, settings: { rounds: 5, roundSeconds: 600 } });
    toRunning(w);
    const start = w.emitter.of('round:start').find((m) => m.aud.to === 'players')!.payload as { numbersTotal: number; numbersBefore: number };
    expect(start.numbersTotal).toBe(320);
    expect(start.numbersBefore).toBe(0);
  });
});

describe('one category, and the projector board', () => {
  it('with a single allowed category nobody has to pick: straight to the countdown', async () => {
    const w = await makeWorld({ players: 4, settings: { allowedCategoryIds: [3] } });
    w.room.startGame();
    w.clock.advance(6000);
    expect(w.room.status).toBe('COUNTDOWN');
    expect(w.room.usedCategories).toEqual([3]);
    expect(w.emitter.of('category:options')).toHaveLength(0);
    w.clock.advance(3000);
    expect(w.room.status).toBe('RUNNING');
  });

  it('two allowed categories are both offered', async () => {
    const w = await makeWorld({ players: 4, settings: { allowedCategoryIds: [3, 9] } });
    w.room.startGame();
    w.clock.advance(6000);
    const o = w.emitter.of('category:options')[0]!.payload as { categories: { id: number }[] };
    expect(o.categories.map((c) => c.id).sort()).toEqual([3, 9]);
  });

  it('the projector gets the full board and, when it joins late, the claims so far; hosts get the light version', async () => {
    const w = await makeWorld({ players: 4 });
    toRunning(w);
    const forDisplay = w.emitter.msgs.find((m) => m.event === 'round:start' && m.aud.to === 'displays')!.payload as { cards: unknown[] };
    const forHost = w.emitter.msgs.find((m) => m.event === 'round:start' && m.aud.to === 'hosts')!.payload as { cards: unknown[] };
    expect(forDisplay.cards).toHaveLength(64);
    expect(forHost.cards).toHaveLength(0);
    answerCorrect(w, w.ids[0]!, 2);
    const snap = w.room.boardSnapshot() as { round: { cards: unknown[] }; claims: Record<string, { playerId: string }> };
    expect(snap.round.cards).toHaveLength(64);
    expect(Object.keys(snap.claims)).toHaveLength(2);
    // nothing in the projector's payload names the answer key
    for (const m of w.emitter.msgs) expect(findForbiddenKeys(m.payload, FORBIDDEN_KEYS), m.event).toEqual([]);
  });
});
import { describe, expect, it } from 'vitest';
import { EVIDENCE_KEYS, findForbiddenKeys } from '@glacia/shared';
import { MockSimpeteriAdapter } from './mock-simpeteri';
import { flushOutbox } from '../src/outbox';
import { reportCsv } from '../src/report';
import { answerCorrect, blur, correctCards, internals, makeWorld, playThrough, repo, toRunning, wrongCards } from './harness';

const dq = (w: Awaited<ReturnType<typeof makeWorld>>, id: string) => w.room.players.get(id)!.disqualified;

describe('M7 auto-disqualification (server integration of the rule)', () => {
  it('blur 3 s then 4 fast correct answers: disqualified exactly on the 4th', async () => {
    const w = await makeWorld({ players: 5 });
    toRunning(w);
    const a = w.ids[0]!;
    blur(w, a, 3000);
    expect(w.emitter.of('cheat:flag').some((m) => (m.payload as { type: string }).type === 'TAB_BLUR')).toBe(true);
    const r = answerCorrect(w, a, 4);
    expect(r.every((x) => x.ok)).toBe(true);
    expect(dq(w, a)).toBe(true);
    expect(w.room.players.get(a)!.dqReason).toBe('BLUR_STREAK');
    // not before
    const w2 = await makeWorld({ players: 5 });
    toRunning(w2);
    blur(w2, w2.ids[0]!, 3000);
    answerCorrect(w2, w2.ids[0]!, 3);
    expect(dq(w2, w2.ids[0]!)).toBe(false);
  });

  it('blur 1 s does not arm; ten correct answers trigger nothing', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    blur(w, w.ids[0]!, 1000);
    answerCorrect(w, w.ids[0]!, 10, 1200);
    expect(dq(w, w.ids[0]!)).toBe(false);
    expect(w.room.flags.filter((f) => f.type === 'TAB_BLUR')).toHaveLength(0);
  });

  it('a wrong answer resets the streak: 3 correct, 1 wrong, 3 correct is safe', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const a = w.ids[0]!;
    blur(w, a, 3000);
    answerCorrect(w, a, 3);
    w.clock.advance(1000);
    expect(w.room.answer(a, wrongCards(w.room)[0]!.id)).toMatchObject({ ok: true, correct: false });
    w.clock.advance(2100);
    answerCorrect(w, a, 3);
    expect(dq(w, a)).toBe(false);
  });

  it('monitoring expires after 90 s', async () => {
    const w = await makeWorld({ players: 3, settings: { roundSeconds: 300 } });
    toRunning(w);
    const a = w.ids[0]!;
    blur(w, a, 3000);
    w.clock.advance(100_000);
    answerCorrect(w, a, 5);
    expect(dq(w, a)).toBe(false);
  });

  it('threshold 5 needs the fifth correct answer', async () => {
    const w = await makeWorld({ players: 3, settings: { cheatStreakThreshold: 5 } });
    toRunning(w);
    const a = w.ids[0]!;
    blur(w, a, 3000);
    answerCorrect(w, a, 4);
    expect(dq(w, a)).toBe(false);
    answerCorrect(w, a, 1);
    expect(dq(w, a)).toBe(true);
  });

  it('ignores blur outside RUNNING', async () => {
    const w = await makeWorld({ players: 3 });
    const a = w.ids[0]!;
    w.room.visibility(a, true); // lobby
    w.clock.advance(5000);
    w.room.visibility(a, false);
    w.room.startGame();
    w.clock.advance(6000);
    w.room.visibility(a, true); // PICK
    w.clock.advance(5000);
    w.room.visibility(a, false);
    expect(w.room.flags.filter((f) => f.type === 'TAB_BLUR')).toHaveLength(0);
  });

  it('ANSWER_WHILE_HIDDEN arms monitoring like a blur', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const a = w.ids[0]!;
    answerCorrect(w, a, 4, 1500, true);
    expect(w.room.flags.some((f) => f.type === 'ANSWER_WHILE_HIDDEN')).toBe(true);
    expect(dq(w, a)).toBe(true);
  });

  it('autoDisqualify=false keeps flagging off', async () => {
    const w = await makeWorld({ players: 3, settings: { autoDisqualify: false } });
    toRunning(w);
    blur(w, w.ids[0]!, 3000);
    answerCorrect(w, w.ids[0]!, 6);
    expect(dq(w, w.ids[0]!)).toBe(false);
  });
});

describe('M7 effects of a disqualification', () => {
  async function cheater() {
    const w = await makeWorld({ players: 6 });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    answerCorrect(w, b, 2); // an honest player with points
    answerCorrect(w, a, 1);
    const before = w.room.liveScore(w.room.players.get(a)!);
    blur(w, a, 3000);
    answerCorrect(w, a, 4);
    await new Promise((r) => setTimeout(r, 30));
    return { w, a, b, before };
  }

  it('notifies everyone, locks input, disconnects after 5 s, hides evidence from others', async () => {
    const { w, a } = await cheater();
    expect(dq(w, a)).toBe(true);
    const pub = w.emitter.of('player:disqualified');
    expect(pub).toHaveLength(1);
    expect(pub[0]!.aud).toEqual({ to: 'all' });
    expect(findForbiddenKeys(pub[0]!.payload, EVIDENCE_KEYS)).toEqual([]);
    expect((pub[0]!.payload as { totalDisqualified: number }).totalDisqualified).toBe(1);
    const mine = w.emitter.of('you:disqualified');
    expect(mine).toHaveLength(1);
    expect(mine[0]!.aud).toEqual({ to: 'player', playerId: a });
    expect(w.room.answer(a, correctCards(w.room)[10]!.id)).toMatchObject({ ok: false, code: 'DISQUALIFIED' });
    expect(w.emitter.disconnected).not.toContain(a);
    w.clock.advance(5000);
    expect(w.emitter.disconnected).toContain(a);
    // evidence-bearing keys only ever go to hosts
    for (const m of w.emitter.msgs) {
      if (m.aud.to === 'hosts') continue;
      expect(findForbiddenKeys(m.payload, ['evidence', 'streak', 'armedUntil', 'hiddenMs']), `${m.event}`).toEqual([]);
    }
    expect(w.emitter.of('cheat:flag').every((m) => m.aud.to === 'hosts')).toBe(true);
  });

  it('removes the cheater from scoreboard, results, wheel and final standings', async () => {
    const { w, a } = await cheater();
    const lastBoard = w.emitter.of('scoreboard:live').at(-1)!.payload as { top5: { playerId: string }[] };
    expect(lastBoard.top5.some((r) => r.playerId === a)).toBe(false);
    w.clock.advance(w.room.settings.roundSeconds * 1000);
    const end = w.emitter.of('round:end')[0]!.payload as { roundScores: { playerId: string }[] };
    expect(end.roundScores.some((r) => r.playerId === a)).toBe(false);
    w.room.nextRound();
    expect(w.room.spins.at(-1)!.eligible.some((e) => e.playerId === a)).toBe(false);
    // 6 players − the cheater − the round-1 picker (already picked this cycle), unless they are the same person
    const picker = w.room.spins[0]!.pickedId;
    expect(w.room.spins.at(-1)!.eligible).toHaveLength(picker === a ? 5 : 4);
  });

  it('creates an active blacklist row with evidence, calls SIMPETERI and writes an audit entry', async () => {
    const { w, a } = await cheater();
    const sid = w.room.players.get(a)!.studentId;
    const row = w.store.activeBlacklist(sid)!;
    expect(row).toBeTruthy();
    const ev = row.evidence as { flags: { type: string }[]; lastAnswers: unknown[]; streak: number; rule: { streakThreshold: number } };
    expect(ev.flags.some((f) => f.type === 'TAB_BLUR')).toBe(true);
    expect(ev.lastAnswers.length).toBeLessThanOrEqual(8);
    expect(ev.streak).toBe(4);
    expect(ev.rule.streakThreshold).toBe(4);
    expect(w.port.blacklisted.has(sid)).toBe(true);
    expect(row.syncedToSimpeteri).toBe(true);
    expect(w.store.listAudit().some((x) => x.action === 'AUTO_DQ' && x.target === sid)).toBe(true);
  });

  it('the same student is rejected in a new room; the same device cannot take a friend\'s name in this room', async () => {
    const { w, a } = await cheater();
    const sid = w.room.players.get(a)!.studentId;
    const next = await makeWorld({ players: 0, store: w.store, port: w.port });
    expect(await next.room.pickName('fresh-device-xyz', sid)).toMatchObject({ ok: false, code: 'BLACKLISTED' });
    expect(await w.room.pickName(w.devices.get(a)!, 'kelas-6a-S30')).toMatchObject({ ok: false });
    expect(await w.room.join(w.devices.get(a)!)).toMatchObject({ ok: false, code: 'BLACKLISTED' });
  });

  it('queues blacklist sync in the outbox when SIMPETERI is down and flush delivers it', async () => {
    const port = new MockSimpeteriAdapter();
    port.failNext = 3;
    const w = await makeWorld({ players: 4, port });
    toRunning(w);
    blur(w, w.ids[0]!, 3000);
    answerCorrect(w, w.ids[0]!, 4);
    for (let i = 0; i < 100 && w.store.pendingOutbox().length === 0; i++) await new Promise((r) => setTimeout(r, 5));
    const pending = w.store.pendingOutbox();
    expect(pending).toHaveLength(1);
    expect(pending[0]!.type).toBe('BLACKLIST');
    expect(w.store.activeBlacklist(w.room.players.get(w.ids[0]!)!.studentId)!.syncedToSimpeteri).toBe(false);
    expect(await flushOutbox(w.store, port)).toEqual({ sent: 1, failed: 0 });
    expect(port.blacklisted.size).toBe(1);
    expect(w.store.pendingOutbox()).toHaveLength(0);
  });

  it('reinstate restores the raw score, lifts the blacklist and is audited', async () => {
    const { w, a, before } = await cheater();
    const sid = w.room.players.get(a)!.studentId;
    expect(w.room.liveScore(w.room.players.get(a)!)).toBe(0);
    expect(w.room.reinstate(a, 'guru-dev')).toMatchObject({ ok: true });
    const p = w.room.players.get(a)!;
    expect(p.disqualified).toBe(false);
    expect(w.room.liveScore(p)).toBeGreaterThan(before - 1);
    expect(w.store.activeBlacklist(sid)).toBeUndefined();
    expect(w.emitter.of('player:reinstated')).toHaveLength(1);
    expect(w.store.listAudit().some((x) => x.action === 'REINSTATE')).toBe(true);
    expect(w.room.answer(a, correctCards(w.room)[20]!.id).ok).toBe(true);
    await new Promise((r) => setTimeout(r, 20));
    expect(w.port.lifted.some((l) => l.studentId === sid)).toBe(true);
  });

  it('manual disqualification needs no blur and can skip the blacklist', async () => {
    const w = await makeWorld({ players: 4 });
    toRunning(w);
    expect(w.room.disqualify(w.ids[1]!, 'HOST_MANUAL', { actorId: 'guru', blacklist: false, note: 'menyontek' })).toMatchObject({ ok: true });
    expect(w.store.activeBlacklist(w.room.players.get(w.ids[1]!)!.studentId)).toBeUndefined();
    expect(w.room.disqualify(w.ids[1]!, 'HOST_MANUAL', { actorId: 'guru', blacklist: false })).toMatchObject({ ok: true }); // idempotent
    expect(w.emitter.of('player:disqualified')).toHaveLength(1);
  });

  it('display modes: INITIALS and COUNT_ONLY never reveal the full name', async () => {
    for (const [mode, expectName] of [['INITIALS', true], ['COUNT_ONLY', false]] as const) {
      const w = await makeWorld({ players: 4, settings: { showDisqualifiedOnDisplay: mode } });
      toRunning(w);
      w.room.disqualify(w.ids[0]!, 'HOST_MANUAL', { actorId: 'g', blacklist: false });
      const m = w.emitter.of('player:disqualified')[0]!.payload as { displayName: string | null; playerId?: string };
      const full = w.room.players.get(w.ids[0]!)!.name;
      expect(m.playerId).toBeUndefined();
      expect(m.displayName === full).toBe(false);
      expect(typeof m.displayName === 'string').toBe(expectName);
    }
  });
});

describe('M7 soft heuristics and report', () => {
  it('flags TOO_FAST / BURST without disqualifying', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const a = w.ids[0]!;
    const good = correctCards(w.room);
    for (let i = 0; i < 12; i++) {
      w.clock.advance(300 + (i % 2) * 50);
      w.room.answer(a, good[i]!.id);
    }
    const types = new Set(w.room.flags.filter((f) => f.playerId === a).map((f) => f.type));
    expect(types.has('TOO_FAST')).toBe(true);
    expect(dq(w, a)).toBe(false);
  });

  it('final report: ranks, DISQUALIFIED status with score 0, per-category stats, submitted once', async () => {
    const w = await makeWorld({ players: 5, settings: { rounds: 3 } });
    let cheat = '';
    await playThrough(w, (n) => {
      answerCorrect(w, w.ids[1]!, 2 + n);
      w.clock.advance(1000);
      if (n === 2) {
        cheat = w.ids[0]!;
        blur(w, cheat, 3000);
        answerCorrect(w, cheat, 4);
      }
    });
    expect(w.room.status).toBe('DONE');
    expect(w.port.submitted).toHaveLength(1);
    const payload = w.port.submitted[0]!;
    expect(payload.students).toHaveLength(5);
    const bad = payload.students.find((s) => s.studentId === w.room.players.get(cheat)!.studentId)!;
    expect(bad).toMatchObject({ status: 'DISQUALIFIED', totalScore: 0, blacklisted: true, disqualifyReason: 'BLUR_STREAK' });
    expect(bad.rank).toBe(5);
    const best = payload.students[0]!;
    expect(best.status).toBe('OK');
    expect(best.perCategory.length).toBeGreaterThan(0);
    expect(best.perCategory.reduce((s, c) => s + c.attempted, 0)).toBe(best.correct + best.wrong);
    const end = w.emitter.of('game:end')[0]!.payload as { finalBoard: { playerId: string }[]; podium: unknown[]; disqualified: { count: number } };
    expect(end.finalBoard.some((r) => r.playerId === cheat)).toBe(false);
    expect(end.podium.length).toBeLessThanOrEqual(3);
    expect(end.disqualified.count).toBe(1);
    // total of the player's score equals the sum of answer points (minus invalidated ones) clamped by round floors
    const sum = w.room.answers.filter((x) => x.playerId === w.ids[1]! && !x.invalidated).reduce((s, x) => s + x.points + x.bonus, 0);
    expect(w.room.players.get(w.ids[1]!)!.totalScore).toBeLessThanOrEqual(sum + 3 * 500);
    expect(w.room.players.get(w.ids[1]!)!.totalScore).toBeGreaterThan(0);
    const csv = reportCsv(w.room.report!.summary, repo.categories());
    expect(csv.startsWith('﻿Peringkat')).toBe(true);
    expect(csv.split('\r\n').filter(Boolean)).toHaveLength(6);
    expect(csv).toContain('DISKUALIFIKASI');
    expect(w.store.getRoom(w.room.id)).toBeTruthy();
  });

  it('keeps the report in the outbox when SIMPETERI is down, and flush resends', async () => {
    const port = new MockSimpeteriAdapter();
    port.failNext = 999;
    const w = await makeWorld({ players: 3, port });
    await playThrough(w);
    expect(w.room.status).toBe('DONE');
    expect(w.store.pendingOutbox().map((o) => o.type)).toEqual(['RESULT']);
    port.failNext = 0;
    expect(await flushOutbox(w.store, port)).toEqual({ sent: 1, failed: 0 });
    expect(port.submitted).toHaveLength(1);
    const again = await w.room.submitReport();
    expect(again.ok).toBe(true);
    expect(internals(w.room).reportSent).toBe(true);
  });
});

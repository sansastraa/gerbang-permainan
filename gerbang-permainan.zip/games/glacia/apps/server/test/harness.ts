import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { parseSettings, type RoomSettingsInput } from '@glacia/shared';
import { loadQuestionRepository } from '../src/bank';
import { ManualClock } from '../src/clock';
import { MockSimpeteriAdapter, mockRoster } from './mock-simpeteri';
import { Room, type Audience, type Emitter, type Timings } from '../src/room';
import { Store } from '../src/store';

const here = path.dirname(fileURLToPath(import.meta.url));
export const repo = loadQuestionRepository(path.resolve(here, '../../../data/questions.json'));

export interface Msg {
  roomId: string;
  aud: Audience;
  event: string;
  payload: unknown;
}

export class RecordingEmitter implements Emitter {
  msgs: Msg[] = [];
  disconnected: string[] = [];
  emit(roomId: string, aud: Audience, event: string, payload: unknown) {
    // round-trip through JSON: what a socket would actually carry
    this.msgs.push({ roomId, aud, event, payload: JSON.parse(JSON.stringify(payload ?? null)) });
  }
  disconnectPlayer(_roomId: string, playerId: string) {
    this.disconnected.push(playerId);
  }
  of(event: string) {
    return this.msgs.filter((m) => m.event === event);
  }
  clear() {
    this.msgs = [];
  }
}

export interface World {
  clock: ManualClock;
  emitter: RecordingEmitter;
  port: MockSimpeteriAdapter;
  store: Store;
  room: Room;
  ids: string[];
  /** deviceToken per player id */
  devices: Map<string, string>;
}

export async function makeWorld(opts: { players?: number; settings?: Partial<RoomSettingsInput>; timings?: Partial<Timings>; store?: Store; port?: MockSimpeteriAdapter; classId?: string } = {}): Promise<World> {
  const clock = new ManualClock();
  const emitter = new RecordingEmitter();
  const port = opts.port ?? new MockSimpeteriAdapter();
  const store = opts.store ?? new Store(null);
  const classId = opts.classId ?? 'kelas-6a';
  const settings = parseSettings({ classId, rounds: 3, roundSeconds: 60, ...opts.settings });
  const room = new Room({ id: `room-${Math.random().toString(36).slice(2, 8)}`, pin: '123456', hostId: 'guru-dev', settings, roster: mockRoster(classId, 40) }, {
    clock, repo, store, port, emitter, outboxBaseDelayMs: 1, timings: opts.timings,
  });
  const ids: string[] = [];
  const devices = new Map<string, string>();
  const n = opts.players ?? 6;
  for (let i = 0; i < n; i++) {
    const dev = `device-${i}-xxxxxxxx`;
    const r = await room.pickName(dev, `${classId}-S${String(i + 1).padStart(2, '0')}`);
    if (!r.ok) throw new Error(`pickName failed ${r.code}`);
    ids.push(r.playerId);
    devices.set(r.playerId, dev);
  }
  return { clock, emitter, port, store, room, ids, devices };
}

/* eslint-disable @typescript-eslint/no-explicit-any */
export const internals = (room: Room) => room as any;

export const T = { spin: 6000, countdown: 3000 };

/** LOBBY → SPIN → PICK → COUNTDOWN → RUNNING. Returns the picker id. */
export function toRunning(w: World): string {
  if (w.room.status === 'LOBBY') {
    const r = w.room.startGame();
    if (!r.ok) throw new Error(`startGame ${r.code}`);
  }
  w.clock.advance(T.spin); // spin animation → PICK
  const room = internals(w.room);
  const picker = room.pickerId as string;
  const options = room.currentOptions as number[];
  const pick = w.room.pickCategory(picker, options[0]!);
  if (!pick.ok) throw new Error(`pick ${pick.code}`);
  w.clock.advance(T.countdown); // → RUNNING
  if (w.room.status !== 'RUNNING') throw new Error(`expected RUNNING got ${w.room.status}`);
  return picker;
}

export interface KeyCard {
  id: string;
  isCorrect: boolean;
  slot: number;
}
export function keyCards(room: Room): KeyCard[] {
  return (internals(room).round.cards as { id: string; slot: number; q: { isCorrect: boolean } }[]).map((c) => ({ id: c.id, slot: c.slot, isCorrect: c.q.isCorrect }));
}
export const correctCards = (room: Room) => keyCards(room).filter((c) => c.isCorrect);
export const wrongCards = (room: Room) => keyCards(room).filter((c) => !c.isCorrect);

/** Plays rounds until FINAL/DONE with every player idle. */
export async function playThrough(w: World, onRunning?: (roundNo: number) => void) {
  toRunning(w);
  onRunning?.(w.room.roundNo);
  for (let guard = 0; guard < 30 && w.room.status !== 'DONE' && w.room.status !== 'FINAL'; guard++) {
    if (w.room.status === 'RUNNING') w.clock.advance(w.room.settings.roundSeconds * 1000 + 10);
    else if (w.room.status === 'ROUND_RESULT') {
      w.room.nextRound();
      if (w.room.status === 'SPIN') {
        toRunning(w);
        onRunning?.(w.room.roundNo);
      }
    } else w.clock.advance(1000);
  }
  for (let i = 0; i < 100 && w.room.status !== 'DONE'; i++) await new Promise((r) => setTimeout(r, 10));
}

/** Answers `n` correct cards for a player, 1.5 s apart (never trips TOO_FAST / rate limits). */
export function answerCorrect(w: World, playerId: string, n: number, gapMs = 1500, hidden = false) {
  const res = [];
  const cards = correctCards(w.room);
  // skip cards this player already answered AND cards somebody else already claimed
  const answered = new Set<string>([
    ...w.room.answers.filter((a) => a.playerId === playerId && a.roundNo === w.room.roundNo).map((a) => a.cardId),
    ...(internals(w.room).round.claims as Map<string, unknown>).keys(),
  ]);
  const fresh = cards.filter((c) => !answered.has(c.id));
  for (let i = 0; i < n; i++) {
    w.clock.advance(gapMs);
    res.push(w.room.answer(playerId, fresh[i]!.id, hidden));
  }
  return res;
}

export function blur(w: World, playerId: string, ms: number) {
  w.room.visibility(playerId, true);
  w.clock.advance(ms);
  w.room.visibility(playerId, false);
}

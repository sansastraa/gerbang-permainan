import path from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { io, type Socket } from 'socket.io-client';
import { loadConfig } from '../src/config';
import { ManualClock } from '../src/clock';
import { HandoffSimpeteriAdapter } from '../src/integration';
import { buildServer } from '../src/server';
import { Store } from '../src/store';
import { correctCards, internals, repo } from './harness';

/** The server as SIMPETERI's Multi Permainan menu sees it: SIMPETERI_MODE=multi, teacher PIN = HOST_PIN. */
const PIN = 'guru-pin-4711';
const ORIGIN = 'https://simpeteri.example.sch.id';
const config = loadConfig({ DATA_DIR: path.resolve(__dirname, '../../../data'), JWT_SECRET: 'test-secret', SIMPETERI_MODE: 'multi', HOST_PIN: PIN, ALLOWED_ORIGINS: ORIGIN, OUTBOX_BASE_DELAY_MS: '1' } as NodeJS.ProcessEnv);
const clock = new ManualClock();
const srv = buildServer({ config, repo, clock, store: new Store(null), port: new HandoffSimpeteriAdapter(PIN), joinLimitPerMin: 1000 });
let base = '';
const sockets: Socket[] = [];
beforeAll(async () => { base = `http://127.0.0.1:${await srv.listen(0)}`; });
afterAll(async () => { sockets.forEach((s) => s.disconnect()); await srv.close(); srv.httpServer.close(); });

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms));
async function until(cond: () => boolean, ms = 3000) { const t0 = Date.now(); while (!cond()) { if (Date.now() - t0 > ms) throw new Error('timeout'); await sleep(5); } }
type J = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any
const call = async (p: string, init: { method?: string; body?: unknown; headers?: Record<string, string> } = {}) => {
  const res = await fetch(`${base}/api${p}`, { method: init.method ?? 'GET', headers: { 'Content-Type': 'application/json', ...(init.headers ?? {}) }, body: init.body === undefined ? undefined : JSON.stringify(init.body) });
  return { status: res.status, headers: res.headers, body: (res.headers.get('content-type') ?? '').includes('json') ? ((await res.json()) as J) : await res.text() };
};
async function connect() {
  const s = io(`${base}/game`, { transports: ['websocket'], reconnection: false });
  sockets.push(s);
  await new Promise<void>((r) => s.on('connect', () => r()));
  return { s, emit: (e: string, p: unknown = {}) => new Promise<J>((r) => s.emit(e, p, r)), got: (e: string) => { let last: unknown; s.on(e, (x) => (last = x)); return () => last; } };
}

// a class as SIMPETERI would send it: ids are siswa.id (UUID-like), names as in the database
const ROSTER = Array.from({ length: 6 }, (_, i) => ({ id: `c2f1a9e0-0000-4000-8000-00000000000${i}`, name: ['Aisyah Putri', 'Bagas Pratama', 'Citra Dewi', 'Dimas Saputra', 'Eka Lestari', 'Fajar Nugroho'][i]!, absen: i + 1 }));

describe('Multi Permainan handoff (SIMPETERI_MODE=multi)', () => {
  it('advertises the mode and the origins that may talk to it', async () => {
    const r = await call('/config');
    expect(r.body).toMatchObject({ ok: true, mode: 'multi', simpeteriOrigins: [ORIGIN] });
  });

  it('signs in with the teacher PIN only, and slows down guessing', async () => {
    expect((await call('/auth/host', { method: 'POST', body: { token: 'salah-pin' } })).status).toBe(401);
    const ok = await call('/auth/host', { method: 'POST', body: { token: PIN } });
    expect(ok.status).toBe(200);
    expect(ok.body.jwt).toBeTruthy();
    let last = 0;
    for (let i = 0; i < 25; i++) last = (await call('/auth/host', { method: 'POST', body: { token: `tebak-${i}-xx` } })).status;
    expect(last).toBe(429);
    clock.advance(61_000); // the limiter window is one minute
  });

  it('login attempts are counted per client and per kind: guessing the PIN does not lock the real teacher out', async () => {
    // a different client address must not share the bucket (X-Forwarded-For is ignored: express "trust proxy" is off, so ip is the socket address)
    for (let i = 0; i < 25; i++) await call('/auth/host', { method: 'POST', body: { token: `salah-${i}-pin` } });
    expect((await call('/auth/host', { method: 'POST', body: { token: PIN } })).status).toBe(429);
    clock.advance(61_000);
    expect((await call('/auth/host', { method: 'POST', body: { token: PIN } })).status).toBe(200);
    clock.advance(61_000);
  });
  it('refuses the PIN when HOST_PIN is malformed, and the adapter never echoes it', async () => {
    expect(() => new HandoffSimpeteriAdapter('abc')).toThrow();
    expect(() => new HandoffSimpeteriAdapter('ada spasi')).toThrow();
  });

  it('needs the roster from SIMPETERI to open a room; ids stay siswa.id', async () => {
    const jwt = (await call('/auth/host', { method: 'POST', body: { token: PIN } })).body.jwt as string;
    const auth = { Authorization: `Bearer ${jwt}` };
    const settings = { classId: '6A', rounds: 1, roundSeconds: 60, allowedCategoryIds: [3] };
    expect((await call('/rooms', { method: 'POST', headers: auth, body: settings })).body).toMatchObject({ ok: false, code: 'ROSTER_REQUIRED' });
    expect((await call('/rooms', { method: 'POST', headers: auth, body: { ...settings, roster: [] } })).body).toMatchObject({ ok: false, code: 'BAD_ROSTER' });
    expect((await call('/rooms', { method: 'POST', headers: auth, body: { ...settings, roster: [ROSTER[0], ROSTER[0]] } })).body).toMatchObject({ ok: false, code: 'BAD_ROSTER' });
    const made = await call('/rooms', { method: 'POST', headers: auth, body: { ...settings, roster: ROSTER } });
    expect(made.body.ok).toBe(true);
    const room = srv.manager.get(made.body.roomId as string)!;
    expect(room.rosterView().map((r) => r.studentId)).toEqual(ROSTER.map((r) => r.id));
    expect(room.settings.classId).toBe('6A');
  });

  it('full game: results are pulled from /api/sessions/:id/summary.json with x-host-token, matched by siswa.id', async () => {
    const jwt = (await call('/auth/host', { method: 'POST', body: { token: PIN } })).body.jwt as string;
    const auth = { Authorization: `Bearer ${jwt}` };
    const made = await call('/rooms', { method: 'POST', headers: auth, body: { classId: '6A', rounds: 1, roundSeconds: 60, allowedCategoryIds: [3], roster: ROSTER } });
    const { roomId, pin } = made.body as { roomId: string; pin: string };
    const room = srv.manager.get(roomId)!;
    const pull = (headers: Record<string, string> = { 'x-host-token': PIN }, id = roomId) => call(`/sessions/${id}/summary.json`, { headers });

    // before the game ends: 403 (what the SIMPETERI page tells the teacher: "baru memberi hasil setelah selesai")
    expect((await pull()).status).toBe(403);
    expect((await pull({ 'x-host-token': 'salah-pin' })).status).toBe(401);
    expect((await pull({})).status).toBe(401);
    expect((await pull(undefined, 'tidak-ada')).status).toBe(404);

    // students join through the PIN and pick names from the SIMPETERI roster
    const bots = [];
    for (let i = 0; i < 4; i++) {
      const c = await connect();
      await c.emit('room:join', { pin, deviceToken: `siswa-device-${i}-abcdefgh` });
      const pick = await c.emit('room:pickName', { studentId: ROSTER[i]!.id });
      expect(pick.ok).toBe(true);
      bots.push({ ...c, playerId: pick.playerId as string, result: c.got('card:result') });
    }
    const host = await connect();
    expect((await host.emit('host:auth', { token: jwt, roomId })).ok).toBe(true);
    expect(await host.emit('game:start')).toMatchObject({ ok: true });
    clock.advance(6000); // spin; one allowed category → straight to the countdown
    clock.advance(3000);
    await until(() => room.status === 'RUNNING');

    // two students claim cards, one answers wrong
    const good = correctCards(room);
    clock.advance(4000);
    await bots[0]!.emit('card:answer', { cardId: good[0]!.id });
    clock.advance(1500);
    await bots[0]!.emit('card:answer', { cardId: good[1]!.id });
    clock.advance(1500);
    await bots[1]!.emit('card:answer', { cardId: good[2]!.id });
    await until(() => room.answers.length === 3);
    expect((await pull()).status).toBe(403); // still running

    expect(await host.emit('game:end-now')).toMatchObject({ ok: true });
    await until(() => room.status === 'DONE', 5000);

    const res = await pull();
    expect(res.status).toBe(200);
    const s = res.body as J;
    expect(s).toMatchObject({ game: 'glacia', version: 2, sessionId: roomId, classId: '6A' });
    expect(s.students).toHaveLength(4); // only students who joined: SIMPETERI scores every row it imports, so absentees must not appear
    const top = s.students.find((x: J) => x.studentId === ROSTER[0]!.id);
    expect(top).toMatchObject({ name: 'Aisyah Putri', status: 'OK', rank: 1 });
    expect(top.points).toBe(top.score);
    expect(top.points).toBeGreaterThan(0);
    expect(top.attempts).toBe(top.correct + top.wrong);
    expect(typeof top.profile).toBe('object');
    expect(s.students.some((x: J) => x.studentId === ROSTER[5]!.id)).toBe(false);
    const quiet = s.students.find((x: J) => x.studentId === ROSTER[3]!.id);
    expect(quiet).toMatchObject({ points: 0, attempts: 0, status: 'OK' });
    // every studentId is a roster siswa.id, nothing else leaks in
    for (const st of s.students) expect(ROSTER.map((r) => r.id)).toContain(st.studentId);
    // the room is dropped from memory after a while but the summary stays available (it was saved)
    srv.manager.sweep(clock.now() + 7 * 3600_000);
    expect((await pull()).status).toBe(200);
  });

  it('CORS: the SIMPETERI origin may send x-host-token; other origins get no CORS headers', async () => {
    const pre = await fetch(`${base}/api/sessions/x/summary.json`, { method: 'OPTIONS', headers: { Origin: ORIGIN, 'Access-Control-Request-Headers': 'x-host-token' } });
    expect(pre.status).toBe(204);
    expect(pre.headers.get('access-control-allow-origin')).toBe(ORIGIN);
    expect(pre.headers.get('access-control-allow-headers')?.toLowerCase()).toContain('x-host-token');
    const other = await fetch(`${base}/api/sessions/x/summary.json`, { method: 'OPTIONS', headers: { Origin: 'https://evil.example' } });
    expect(other.headers.get('access-control-allow-origin')).toBeNull();
  });

  it('keeps the blacklist locally: a disqualified student stays blocked in the next room, no SIMPETERI call needed', async () => {
    const jwt = (await call('/auth/host', { method: 'POST', body: { token: PIN } })).body.jwt as string;
    const auth = { Authorization: `Bearer ${jwt}` };
    const a = (await call('/rooms', { method: 'POST', headers: auth, body: { classId: '6A', roster: ROSTER, allowedCategoryIds: [3] } })).body;
    const room = srv.manager.get(a.roomId as string)!;
    const c = await connect();
    await c.emit('room:join', { pin: a.pin, deviceToken: 'blok-device-abcdefgh' });
    const pick = await c.emit('room:pickName', { studentId: ROSTER[2]!.id });
    srv.store.addBlacklist({ studentId: ROSTER[2]!.id, studentName: 'Citra Dewi', classId: '6A', reason: 'BLUR_STREAK', roomId: room.id, evidence: {} }, clock.now());
    expect(pick.ok).toBe(true);
    const b = (await call('/rooms', { method: 'POST', headers: auth, body: { classId: '6A', roster: ROSTER, allowedCategoryIds: [3] } })).body;
    const c2 = await connect();
    await c2.emit('room:join', { pin: b.pin, deviceToken: 'blok-device-zzzzzzzz' });
    expect(await c2.emit('room:pickName', { studentId: ROSTER[2]!.id })).toMatchObject({ ok: false, code: 'BLACKLISTED' });
    void internals;
  });
});

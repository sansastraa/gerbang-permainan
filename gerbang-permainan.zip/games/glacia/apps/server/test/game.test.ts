import { describe, expect, it } from 'vitest';
import { FORBIDDEN_KEYS, findForbiddenKeys, pointsForCorrect } from '@glacia/shared';
import { Store } from '../src/store';
import { MockSimpeteriAdapter } from './mock-simpeteri';
import { answerCorrect, correctCards, internals, keyCards, makeWorld, playThrough, repo, T, toRunning, wrongCards } from './harness';

describe('M3 lobby', () => {
  it('locks one name to one device, rejects duplicates and unknown students', async () => {
    const w = await makeWorld({ players: 2 });
    expect(await w.room.pickName('another-device-1', 'kelas-6a-S01')).toMatchObject({ ok: false, code: 'NAME_TAKEN' });
    expect(await w.room.pickName('device-0-xxxxxxxx', 'kelas-6a-S05')).toMatchObject({ ok: false, code: 'DEVICE_HAS_NAME' });
    expect(await w.room.pickName('another-device-2', 'nope')).toMatchObject({ ok: false, code: 'UNKNOWN_STUDENT' });
    const taken = w.room.rosterView().filter((r) => r.taken).map((r) => r.studentId);
    expect(taken).toEqual(['kelas-6a-S01', 'kelas-6a-S02']);
  });

  it('flags MULTI_DEVICE when a second device tries a taken name', async () => {
    const w = await makeWorld({ players: 1 });
    await w.room.pickName('sneaky-device-1', 'kelas-6a-S01');
    expect(w.room.flags.map((f) => f.type)).toContain('MULTI_DEVICE');
  });

  it('enforces the quota and closes registration after start', async () => {
    const w = await makeWorld({ players: 2, settings: { maxPlayers: 3 } });
    expect(await w.room.pickName('dev-3-xxxxxxxx', 'kelas-6a-S03')).toMatchObject({ ok: true });
    expect(await w.room.pickName('dev-4-xxxxxxxx', 'kelas-6a-S04')).toMatchObject({ ok: false, code: 'ROOM_FULL' });
    const w2 = await makeWorld({ players: 3 });
    w2.room.startGame();
    expect(await w2.room.pickName('late-device-1', 'kelas-6a-S10')).toMatchObject({ ok: false, code: 'REGISTRATION_CLOSED' });
  });

  it('needs at least two online players to start', async () => {
    const w = await makeWorld({ players: 1 });
    expect(w.room.startGame()).toMatchObject({ ok: false, code: 'NOT_ENOUGH_PLAYERS' });
  });

  it('30 players can join', async () => {
    const w = await makeWorld({ players: 30, settings: { maxPlayers: 40 } });
    expect(w.room.players.size).toBe(30);
  });

  it('rejects a blacklisted student (join resume and pickName) without locking the name', async () => {
    const store = new Store(null);
    store.addBlacklist({ studentId: 'kelas-6a-S09', studentName: 'X', classId: 'kelas-6a', reason: 'BLUR_STREAK', roomId: 'old', evidence: {} }, 1);
    const w = await makeWorld({ players: 2, store });
    expect(await w.room.pickName('dev-bl-xxxxxxxx', 'kelas-6a-S09')).toMatchObject({ ok: false, code: 'BLACKLISTED' });
    expect(w.room.rosterView().find((r) => r.studentId === 'kelas-6a-S09')?.taken).toBe(false);
  });

  it('rejects when SIMPETERI says the student is blacklisted', async () => {
    const port = new MockSimpeteriAdapter();
    await port.blacklistStudent('kelas-6a-S07', 'x', {}, 'r');
    const w = await makeWorld({ players: 2, port });
    expect(await w.room.pickName('dev-sp-xxxxxxxx', 'kelas-6a-S07')).toMatchObject({ ok: false, code: 'BLACKLISTED' });
  });

  it('resumes a known device and kicks remove a player', async () => {
    const w = await makeWorld({ players: 3 });
    const id = w.ids[0]!;
    expect(await w.room.join(w.devices.get(id)!)).toMatchObject({ ok: true, resumed: true, playerId: id });
    expect(await w.room.join('brand-new-device')).toMatchObject({ ok: true, resumed: false });
    expect(w.room.kick(w.ids[2]!, 'guru-dev')).toMatchObject({ ok: true });
    expect(w.room.players.size).toBe(2);
    expect(w.store.listAudit().some((a) => a.action === 'KICK')).toBe(true);
  });
});

describe('M4 spin & category', () => {
  it('nobody is picked twice in a cycle, wheel size = eligible players, categories never repeat', async () => {
    const w = await makeWorld({ players: 6, settings: { rounds: 5 } });
    await playThrough(w);
    const picked = w.room.spins.map((s) => s.pickedId);
    expect(picked).toHaveLength(5);
    expect(new Set(picked).size).toBe(5);
    expect(w.room.spins.map((s) => s.eligible.length)).toEqual([6, 5, 4, 3, 2]);
    expect(new Set(w.room.usedCategories).size).toBe(5);
    expect(w.room.status).toBe('DONE');
  });

  it('starts a new cycle when everyone has picked', async () => {
    const w = await makeWorld({ players: 3, settings: { rounds: 5 } });
    await playThrough(w);
    expect(w.room.spins.map((s) => s.eligible.length)).toEqual([3, 2, 1, 3, 2]);
  });

  it('only offers the picker five fresh categories and picks randomly on timeout', async () => {
    const w = await makeWorld({ players: 4 });
    w.room.startGame();
    w.clock.advance(T.spin);
    const opts = w.emitter.of('category:options');
    expect(opts).toHaveLength(1);
    expect(opts[0]!.aud).toEqual({ to: 'player', playerId: internals(w.room).pickerId });
    expect((opts[0]!.payload as { categories: unknown[] }).categories).toHaveLength(5);
    expect(w.room.pickCategory(w.ids.find((i) => i !== internals(w.room).pickerId)!, 1)).toMatchObject({ ok: false, code: 'NOT_PICKER' });
    expect(w.room.pickCategory(internals(w.room).pickerId, 999)).toMatchObject({ ok: false, code: 'BAD_CATEGORY' });
    w.clock.advance(w.room.settings.categoryPickSeconds * 1000);
    expect(w.room.status).toBe('COUNTDOWN');
    expect(w.room.usedCategories).toHaveLength(1);
  });

  it('re-spins when the picker is disqualified or leaves, and the wheel shrinks', async () => {
    const w = await makeWorld({ players: 5 });
    w.room.startGame();
    const first = internals(w.room).pickerId as string;
    w.room.disqualify(first, 'HOST_MANUAL', { actorId: 'guru', blacklist: false, note: 'uji' });
    expect(w.room.status).toBe('SPIN');
    expect(internals(w.room).pickerId).not.toBe(first);
    expect(w.room.spins.at(-1)!.eligible).toHaveLength(4);
    expect(w.room.spins.at(-1)!.eligible.some((e) => e.playerId === first)).toBe(false);
    const second = internals(w.room).pickerId as string;
    w.room.setConnection(second, false);
    expect(internals(w.room).pickerId).not.toBe(second);
    expect(w.room.spins.at(-1)!.eligible).toHaveLength(3);
  });
});

describe('M5 round & score', () => {
  it('builds 64 cards with 26..32 correct, one shared order for everybody, and valid scoring', async () => {
    const w = await makeWorld({ players: 4 });
    toRunning(w);
    const cards = keyCards(w.room);
    expect(cards).toHaveLength(64);
    const good = cards.filter((c) => c.isCorrect).length;
    expect(good).toBeGreaterThanOrEqual(26);
    expect(good).toBeLessThanOrEqual(32);
    const orders = w.ids.map((id) => (w.room.resumeSnapshot(id) as { round: { cards: { cardId: string }[] } }).round.cards.map((c) => c.cardId).join());
    expect(new Set(orders).size).toBe(1); // the same shuffled board for the whole class
  });

  it('scores like the reference (claimMode off): time decay, first blood, penalty, cooldown', async () => {
    const w = await makeWorld({ players: 3, settings: { claimMode: false } });
    toRunning(w);
    const [a, b] = w.ids as [string, string];
    const good = correctCards(w.room);
    const bad = wrongCards(w.room);
    w.clock.advance(5500);
    const r1 = w.room.answer(a, good[0]!.id);
    expect(r1).toMatchObject({ ok: true, correct: true, points: pointsForCorrect(5500), bonus: 300 });
    w.clock.advance(1000);
    const r2 = w.room.answer(b, good[0]!.id);
    expect(r2).toMatchObject({ ok: true, correct: true, points: pointsForCorrect(6500), bonus: 200 });
    // next think time counts from the player's last correct action
    w.clock.advance(3200);
    const r3 = w.room.answer(a, good[1]!.id);
    expect(r3).toMatchObject({ points: pointsForCorrect(4200) });
    w.clock.advance(1200);
    expect(w.room.answer(a, bad[0]!.id)).toMatchObject({ ok: true, correct: false, points: -250 });
    w.clock.advance(500);
    expect(w.room.answer(a, good[2]!.id)).toMatchObject({ ok: false, code: 'COOLDOWN' });
    w.clock.advance(1600);
    expect(w.room.answer(a, good[2]!.id)).toMatchObject({ ok: true });
    // a: (950+300) + (960+300) - 250 + (970+300) — each card was a's first correct on that card, third answer thinkMs 3300
    expect(w.room.liveScore(w.room.players.get(a)!)).toBe(pointsForCorrect(5500) + 300 + pointsForCorrect(4200) + 300 - 250 + pointsForCorrect(3300) + 300);
  });

  it('rejects double answers, rate-limits to 5/s and refuses answers after the round', async () => {
    const w = await makeWorld({ players: 2 });
    toRunning(w);
    const a = w.ids[0]!;
    const good = correctCards(w.room);
    w.clock.advance(3000);
    expect(w.room.answer(a, good[0]!.id)).toMatchObject({ ok: true });
    expect(w.room.answer(a, good[0]!.id)).toMatchObject({ ok: false, code: 'ALREADY_ANSWERED' });
    const burst = [1, 2, 3, 4, 5, 6].map((i) => w.room.answer(a, good[i]!.id));
    expect(burst.filter((r) => !r.ok && r.code === 'RATE_LIMITED').length).toBeGreaterThanOrEqual(1);
    w.clock.advance(w.room.settings.roundSeconds * 1000);
    expect(w.room.answer(a, good[10]!.id).ok).toBe(false);
  });

  it('never leaks key fields in any message sent during a running round', async () => {
    const w = await makeWorld({ players: 6, settings: { rounds: 3 } });
    toRunning(w);
    answerCorrect(w, w.ids[0]!, 3);
    w.clock.advance(w.room.settings.roundSeconds * 500); // passes the board refresh point (odd round)
    expect(w.emitter.of('board:refresh')).toHaveLength(1);
    const before = w.emitter.msgs.findIndex((m) => m.event === 'round:end');
    expect(before).toBe(-1);
    for (const m of w.emitter.msgs) {
      expect(findForbiddenKeys(m.payload, FORBIDDEN_KEYS), `${m.event} leaked`).toEqual([]);
    }
    const reveal = internals(w.room).round.cards[0].q.svg as string;
    expect(JSON.stringify(w.emitter.msgs)).not.toContain('"explanation"');
    expect(reveal).not.toContain('<text');
    w.clock.advance(w.room.settings.roundSeconds * 500 + 1);
    const end = w.emitter.of('round:end')[0]!.payload as { keyReveal: unknown[]; explanations: unknown[] };
    expect(end.keyReveal).toHaveLength(64);
    expect(end.explanations.length).toBeLessThanOrEqual(3);
  });

  it('board refresh keeps 26..32 correct and leaves answered cards untouched', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const [a] = w.ids as [string];
    answerCorrect(w, a, 4);
    const answeredIds = new Set(w.room.answers.map((x) => x.cardId));
    w.clock.advance(w.room.settings.roundSeconds * 500);
    const cards = keyCards(w.room);
    const good = cards.filter((c) => c.isCorrect).length;
    expect(good).toBeGreaterThanOrEqual(26);
    expect(good).toBeLessThanOrEqual(32);
    for (const id of answeredIds) expect(cards.some((c) => c.id === id)).toBe(true);
    // a replaced card can no longer be answered
    const refresh = w.emitter.of('board:refresh')[0]!.payload as { replaced: { oldCardId: string }[] };
    expect(w.room.answer(a, refresh.replaced[0]!.oldCardId)).toMatchObject({ ok: false, code: 'CARD_GONE' });
  });

  it('no refresh on even rounds', async () => {
    const w = await makeWorld({ players: 3 });
    await playThrough(w, (n) => {
      if (n === 2) {
        w.emitter.clear();
        w.clock.advance(w.room.settings.roundSeconds * 400);
        w.clock.advance(w.room.settings.roundSeconds * 200);
        expect(w.emitter.of('board:refresh')).toHaveLength(0);
      }
    });
  });

  it('pause freezes the clock and resume shifts endsAt', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const endsAt = internals(w.room).round.endsAt as number;
    w.clock.advance(10_000);
    expect(w.room.pause()).toMatchObject({ ok: true });
    expect(w.room.answer(w.ids[0]!, correctCards(w.room)[0]!.id)).toMatchObject({ ok: false, code: 'PAUSED' });
    w.clock.advance(40_000); // would be past the end if the timer still ran
    expect(w.room.status).toBe('PAUSED');
    expect(w.room.resume()).toMatchObject({ ok: true });
    expect(internals(w.room).round.endsAt).toBe(endsAt + 40_000);
    w.clock.advance(49_000);
    expect(w.room.status).toBe('RUNNING');
    w.clock.advance(1_100);
    expect(w.room.status).toBe('ROUND_RESULT');
  });

  it('reconnect keeps score and the current round', async () => {
    const w = await makeWorld({ players: 3 });
    toRunning(w);
    const a = w.ids[0]!;
    answerCorrect(w, a, 2);
    const score = w.room.liveScore(w.room.players.get(a)!);
    w.room.setConnection(a, false);
    expect(w.room.players.get(a)!.online).toBe(false);
    expect(await w.room.join(w.devices.get(a)!)).toMatchObject({ resumed: true });
    w.room.setConnection(a, true);
    const snap = w.room.resumeSnapshot(a) as { round: { endsAt: number; cards: unknown[] }; myAnswers: Record<string, boolean>; state: { you: { score: number } } };
    expect(snap.round.cards).toHaveLength(64);
    expect(Object.keys(snap.myAnswers)).toHaveLength(2);
    expect(snap.state.you.score).toBe(score);
  });

  it('round results score perfect rounds and total accumulates (claimMode off)', async () => {
    const w = await makeWorld({ players: 3, settings: { claimMode: false } });
    toRunning(w);
    const a = w.ids[0]!;
    const good = correctCards(w.room);
    for (const c of good) {
      w.clock.advance(250);
      const r = w.room.answer(a, c.id);
      if (!r.ok && r.code === 'RATE_LIMITED') {
        w.clock.advance(1000);
        w.room.answer(a, c.id);
      }
    }
    w.clock.advance(w.room.settings.roundSeconds * 1000);
    const end = w.emitter.of('round:end')[0]!.payload as { roundScores: { playerId: string; perfect: boolean; roundScore: number; rank: number }[] };
    const mine = end.roundScores.find((x) => x.playerId === a)!;
    expect(mine.perfect).toBe(true);
    expect(mine.rank).toBe(1);
    expect(w.room.players.get(a)!.totalScore).toBe(mine.roundScore);
  });
});

describe('repository', () => {
  it('loads 7500 questions, 15 x 225 correct', () => {
    expect(repo.count()).toBe(7500);
    for (const c of repo.categories()) {
      const pool = repo.pool(c.id);
      expect(pool).toHaveLength(500);
      expect(pool.filter((q) => q.isCorrect)).toHaveLength(225);
    }
  });
});

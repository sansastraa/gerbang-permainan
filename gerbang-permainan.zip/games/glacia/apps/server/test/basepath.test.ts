import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { afterAll, beforeAll, describe, expect, it } from 'vitest';
import { io } from 'socket.io-client';
import { normalizeBasePath } from '@glacia/shared';
import { ManualClock } from '../src/clock';
import { loadConfig } from '../src/config';
import { buildServer } from '../src/server';
import { Store } from '../src/store';
import { repo } from './harness';

/** GLACIA behind SIMPETERI's gateway: everything lives under /games/glacia, one origin, no separate port. */
const PIN = 'pin-guru-4711';
const BASE = '/games/glacia';
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'glacia-static-'));
fs.mkdirSync(path.join(dir, 'assets'));
fs.writeFileSync(path.join(dir, 'index.html'), '<!doctype html><div id="root"></div><script src="/games/glacia/assets/app.js"></script>');
fs.writeFileSync(path.join(dir, 'assets', 'app.js'), 'console.log("app")');

const env = (extra: Record<string, string> = {}) =>
  ({ DATA_DIR: path.resolve(__dirname, '../../../data'), JWT_SECRET: 'test-secret', HOST_PIN: PIN, STATIC_DIR: dir, ...extra }) as NodeJS.ProcessEnv;
const make = (extra: Record<string, string> = {}, joinLimit = 1000) =>
  buildServer({ config: loadConfig(env(extra)), repo, clock: new ManualClock(), store: new Store(null), joinLimitPerMin: joinLimit });

const prefixed = make({ BASE_PATH: 'games/glacia/', TRUST_PROXY: '1' }, 2);
const plain = make({}); // no BASE_PATH: behaviour must be exactly what it was
const spoofable = make({ BASE_PATH: BASE }); // behind a prefix but NOT trusting X-Forwarded-For
let url = '';
let plainUrl = '';
let spoofUrl = '';
beforeAll(async () => {
  url = `http://127.0.0.1:${await prefixed.listen(0)}`;
  plainUrl = `http://127.0.0.1:${await plain.listen(0)}`;
  spoofUrl = `http://127.0.0.1:${await spoofable.listen(0)}`;
});
afterAll(async () => {
  for (const s of [prefixed, plain, spoofable]) {
    await s.close();
    s.httpServer.close();
  }
  fs.rmSync(dir, { recursive: true, force: true });
});

const get = async (base: string, p: string, init: RequestInit = {}) => {
  const res = await fetch(`${base}${p}`, init);
  const text = await res.text();
  return { status: res.status, type: res.headers.get('content-type') ?? '', text };
};

describe('BASE_PATH normalisation', () => {
  it('accepts the shapes people type and rejects anything that is not a plain path prefix', () => {
    expect(normalizeBasePath(undefined)).toBe('');
    expect(normalizeBasePath('')).toBe('');
    expect(normalizeBasePath('/')).toBe('');
    expect(normalizeBasePath('games/glacia')).toBe('/games/glacia');
    expect(normalizeBasePath('/games/glacia/')).toBe('/games/glacia');
    expect(normalizeBasePath(' //games//glacia// ')).toBe('/games/glacia');
    for (const bad of ['/a b', '/a?x=1', '/a#b', '/../etc', '/a/./b', 'http://x/y', '/ü']) expect(() => normalizeBasePath(bad), bad).toThrow();
  });
  it('is part of the server config', () => {
    expect(loadConfig(env({ BASE_PATH: '/games/glacia/' })).basePath).toBe(BASE);
    expect(loadConfig(env()).basePath).toBe('');
    expect(loadConfig(env({ TRUST_PROXY: '1' })).trustProxy).toBe(true);
    expect(loadConfig(env()).trustProxy).toBe(false);
    expect(() => loadConfig(env({ BASE_PATH: '/a b' }))).toThrow();
  });
});

describe('server under /games/glacia', () => {
  it('serves the API only under the prefix', async () => {
    const ok = await get(url, `${BASE}/api/health`);
    expect(ok.status).toBe(200);
    expect(JSON.parse(ok.text)).toMatchObject({ ok: true, questions: 7500 });
    expect((await get(url, `${BASE}/api/config`)).status).toBe(200);
    for (const p of ['/api/health', '/health', '/rooms']) expect((await get(url, p)).status, p).toBe(404);
  });

  it('serves the web client and the SPA fallback (/host, as SIMPETERI opens it) under the prefix', async () => {
    for (const p of [`${BASE}`, `${BASE}/`, `${BASE}/host`, `${BASE}/play`, `${BASE}/display/123456`]) {
      const r = await get(url, p);
      expect(r.status, p).toBe(200);
      expect(r.type, p).toContain('text/html');
      expect(r.text, p).toContain('id="root"');
    }
    const js = await get(url, `${BASE}/assets/app.js`);
    expect(js.status).toBe(200);
    expect(js.type).toContain('javascript');
    expect(js.text).toBe('console.log("app")');
  });

  it('unknown API and socket.io URLs are JSON 404s, never the HTML page', async () => {
    const r = await get(url, `${BASE}/api/nope`);
    expect(r.status).toBe(404);
    expect(r.type).toContain('json');
    expect(JSON.parse(r.text)).toMatchObject({ ok: false, code: 'NOT_FOUND' });
    expect((await get(url, '/socket.io/?EIO=4&transport=polling')).status).toBe(404); // the default path is not mounted
    const poll = await get(url, `${BASE}/socket.io/?EIO=4&transport=polling`);
    expect(poll.status).toBe(200);
    expect(poll.text.startsWith('0{')).toBe(true); // socket.io handshake packet
  });

  it('socket.io connects at <base>/socket.io, and not at the default path', async () => {
    const ok = io(`${url}/game`, { path: `${BASE}/socket.io`, transports: ['websocket'], reconnection: false });
    await new Promise<void>((res, rej) => { ok.on('connect', () => res()); ok.on('connect_error', rej); });
    const ack = await new Promise<{ ok: boolean; code?: string }>((r) => ok.emit('room:join', { pin: '000000', deviceToken: 'device-abcdefgh' }, r));
    expect(ack).toMatchObject({ ok: false, code: 'NO_ROOM' });
    ok.disconnect();

    const wrong = io(`${url}/game`, { transports: ['websocket'], reconnection: false, timeout: 1500 });
    const err = await new Promise<Error>((res) => { wrong.on('connect', () => res(new Error('connected'))); wrong.on('connect_error', res); });
    expect(err.message).not.toBe('connected');
    wrong.disconnect();
  });

  it('login works under the prefix', async () => {
    const r = await get(url, `${BASE}/api/auth/host`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ token: PIN }) });
    expect(r.status).toBe(200);
    expect(JSON.parse(r.text).jwt).toBeTruthy();
  });
});

describe('without BASE_PATH nothing changes', () => {
  it('API at /api and at the legacy root, client at /, fallback for /host, socket.io at /socket.io', async () => {
    expect((await get(plainUrl, '/api/health')).status).toBe(200);
    expect((await get(plainUrl, '/health')).status).toBe(200);
    expect((await get(plainUrl, '/')).text).toContain('id="root"');
    expect((await get(plainUrl, '/host')).text).toContain('id="root"');
    expect((await get(plainUrl, '/api/nope')).status).toBe(404);
    const s = io(`${plainUrl}/game`, { transports: ['websocket'], reconnection: false });
    await new Promise<void>((res, rej) => { s.on('connect', () => res()); s.on('connect_error', rej); });
    s.disconnect();
  });
});

describe('per-client limits behind a gateway (X-Forwarded-For)', () => {
  const login = (base: string, ip: string | null, n: number) =>
    Promise.all(Array.from({ length: n }, (_, i) => get(base, `${BASE}/api/auth/host`, { method: 'POST', headers: { 'Content-Type': 'application/json', ...(ip ? { 'X-Forwarded-For': ip } : {}) }, body: JSON.stringify({ token: `salah-${i}-pin` }) })));

  it('TRUST_PROXY=1: each real client has its own PIN-attempt bucket', async () => {
    const a = await login(url, '203.0.113.7', 25);
    expect(a.at(-1)!.status).toBe(429);
    const b = await get(url, `${BASE}/api/auth/host`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': '198.51.100.9' }, body: JSON.stringify({ token: 'salah-pin' }) });
    expect(b.status).toBe(401); // a different client is not punished for the first one's guessing
  });

  it('without TRUST_PROXY the header is ignored, so it cannot be used to dodge the limit', async () => {
    const rotating = await Promise.all(Array.from({ length: 25 }, (_, i) => get(spoofUrl, `${BASE}/api/auth/host`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-Forwarded-For': `10.0.0.${i}` }, body: JSON.stringify({ token: `salah-${i}-pin` }) })));
    expect(rotating.at(-1)!.status).toBe(429);
  });

  it('room:join limit is per real client behind the gateway too', async () => {
    const join = async (ip: string) => {
      const s = io(`${url}/game`, { path: `${BASE}/socket.io`, transports: ['websocket'], reconnection: false, extraHeaders: { 'X-Forwarded-For': ip } });
      await new Promise<void>((res, rej) => { s.on('connect', () => res()); s.on('connect_error', rej); });
      const codes: string[] = [];
      for (let i = 0; i < 3; i++) codes.push(((await new Promise((r) => s.emit('room:join', { pin: '000000', deviceToken: `device-${ip}-${i}-xxxx` }, r))) as { code: string }).code);
      s.disconnect();
      return codes;
    };
    expect(await join('203.0.113.50')).toEqual(['NO_ROOM', 'NO_ROOM', 'RATE_LIMITED']); // limit is 2 per minute on this server
    expect(await join('198.51.100.60')).toEqual(['NO_ROOM', 'NO_ROOM', 'RATE_LIMITED']); // its own bucket, not the first client's leftovers
  });
});

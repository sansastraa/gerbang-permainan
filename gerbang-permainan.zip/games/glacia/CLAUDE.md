# GLACIA — Arena Pemburu Angka

Permainan hitung kelas 6 SD (guru / siswa / proyektor). Blueprint lengkap: `docs/GLACIA_BLUEPRINT.md`. Keputusan yang menyimpang darinya: `docs/ASSUMPTIONS.md`.

## Aturan kerja (tidak boleh dilanggar)

1. Kunci jawaban (`isCorrect`, `questionId`, `unitDigit`, `parity`, `result`, `explanation`) **tidak pernah** dikirim ke klien selama ronde berjalan. Ada tes otomatis (`apps/server/test`).
2. Server satu-satunya sumber kebenaran untuk waktu, spin, skor, klaim kartu, dan validasi jawaban. Klien tidak mengirim waktu yang dipercaya.
3. Aturan skor/papan/anti-curang adalah fungsi murni di `packages/shared` dengan unit test. Jangan menduplikasi di web atau server.
4. Aturan diskualifikasi otomatis + blacklist (blueprint 11.1) diimplementasikan persis. Jangan melonggarkan ambang (`cheatStreakThreshold` 4–5, `minBlurMs`, `blurArmWindowSec`) tanpa instruksi.
5. SIMPETERI: lewat `SimpeteriPort` (mode `mandiri` atau `multi`, lihat `docs/SIMPETERI_INTEGRASI.md`). **Jangan mengarang endpoint SIMPETERI** dan **jangan menaruh data contoh siswa, peringkat, atau akun di aplikasi** (data uji hidup di `apps/server/test` saja).
6. UI berbahasa Indonesia yang sederhana, ramah anak kelas 6. Kode, nama variabel, komentar: bahasa Inggris.
7. Ada ambiguitas: ambil asumsi paling sederhana, catat di `docs/ASSUMPTIONS.md`, lanjut.
8. Desain: hangat dan terang (kertas krem, tinta cokelat, kuning matahari, merah tomat). Bukan biru, bukan gelap, tanpa gradien generik. Form guru tanpa dropdown.

## Perintah

```bash
npm install
npm run import-bank      # sekali: render 7.500 soal ke data/questions.json (±1 menit)
npm run dev              # web :3000 + server :4000 (PIN guru dev: guru1234, kecuali HOST_PIN diisi)
npm run lint && npm run typecheck && npm test
npx tsx tools/bots.ts --bots 100 --rounds 2 --seconds 60   # uji beban (lihat docs/DEPLOY.md)
npx tsx tools/verify-bank.ts <xlsx|json>                   # verifikasi bank soal secara independen
```

## Peta kode

- `packages/shared`: skema zod, RNG, skor, sampler papan, roda spin, aturan anti-curang, heuristik, laporan.
- `apps/server/src`: `room.ts` (mesin status + permainan), `gateway.ts` (Socket.IO), `http.ts` (REST), `integration.ts` (SIMPETERI), `store.ts` (daftar hitam/audit/outbox/laporan), `report.ts`, `outbox.ts`.
- `apps/web/src`: `App.tsx` (rute hash), `Player.tsx`, `Host.tsx`, `Display.tsx`, `Profile.tsx`, `lib.ts` (socket, jam server, profil lokal), `ui.tsx`, `styles.css`.
- `tools/`: `import-bank.ts`, `verify-bank.ts`, `bots.ts` (beban), `idle-players.ts` (pemain pendamping untuk uji manual), `glacia_generator.py`.
- Lokasi: kode ini kini berada di repo SIMPETERI di `games/glacia` (jalankan dari akar SIMPETERI dengan `npm run gl:install`, `gl:import-bank`, `gl:dev`, `gl:test`). Folder `glacia/` lama di luar repo hanya salinan; jangan diedit.`n- `docs/`: `API.md`, `EVENTS.md`, `ASSUMPTIONS.md`, `DEPLOY.md`, `PANDUAN_GURU.md`.

## Catatan

- `tsx watch` memulai ulang server saat berkas berubah dan **menghapus ruangan yang sedang berjalan**. Untuk uji beban jalankan `npx tsx apps/server/src/main.ts` (tanpa watch).
- Berkas dengan karakter non-ASCII: tulis dengan UTF-8 tanpa BOM. PowerShell 5.1 membaca UTF-8 tanpa BOM sebagai ANSI, jadi pakai `[IO.File]::ReadAllText(path, UTF8)` saat mengedit lewat skrip.

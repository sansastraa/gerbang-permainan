import type { Server, Socket } from "socket.io";
import type {
  Ack,
  HostAuth,
  HostCreateAck,
  HostCreatePayload,
  IntegrityEventPayload,
  RouteSubmitPayload,
  TutorialStepResult,
} from "@route-rush/shared";
import { tokenEquals, type FailureGuard } from "./guard";
import type { SessionRegistry } from "./registry";
import type { Emitter, GameSession } from "./session";

export const rooms = {
  host: (id: string): string => `s:${id}:host`,
  room: (id: string): string => `s:${id}:room`,
  player: (id: string, studentId: string): string => `s:${id}:p:${studentId}`,
};

/** Emitter Socket.IO: host, siswa yang sudah memilih nama, dan siswa yang baru memasukkan PIN punya ruang masing-masing. */
export function socketEmitter(io: Server, sessionId: string, claimedIds: () => string[]): Emitter {
  return {
    toHost: (event, payload) => void io.to(rooms.host(sessionId)).emit(event, payload),
    toPlayer: (studentId, event, payload) => void io.to(rooms.player(sessionId, studentId)).emit(event, payload),
    toPlayers: (event, payload) => {
      for (const id of claimedIds()) io.to(rooms.player(sessionId, id)).emit(event, payload);
    },
    toRoom: (event, payload) => void io.to(rooms.room(sessionId)).emit(event, payload),
    toAll: (event, payload) => void io.to(rooms.host(sessionId)).to(rooms.room(sessionId)).emit(event, payload),
  };
}

interface Ctx {
  sessionId?: string;
  studentId?: string;
}

type AckFn = (response: unknown) => void;

const noop: AckFn = () => undefined;

export interface SocketOptions {
  /** Pembuat bot hanya terdaftar bila true (server mode test atau simulasi). */
  allowBots: boolean;
  /** Pembatas token guru yang salah (per sesi dan alamat); tanpa ini tidak ada pembatasan. */
  guard?: FailureGuard;
}

/** Memasang semua event Socket.IO (Bagian 7). Event pembuat bot tidak terdaftar sama sekali bila `allowBots` salah. */
export function attachSocket(io: Server, registry: SessionRegistry, options: SocketOptions): void {
  io.on("connection", (socket: Socket) => {
    const ctx: Ctx = {};

    const wrap =
      <P>(handler: (payload: P, ack: AckFn) => void) =>
      (payload: P, ack?: AckFn): void => {
        const reply = typeof ack === "function" ? ack : noop;
        try {
          handler(payload, reply);
        } catch {
          reply({ ok: false, error: "INVALID_PAYLOAD" });
        }
      };

    /** Event guru: wajib membawa token guru yang diterima saat membuat sesi. */
    const asHost =
      <P extends HostAuth>(handler: (session: GameSession, payload: P) => Ack<object>) =>
      (payload: P, ack: AckFn): void => {
        const session = registry.get(payload?.sessionId);
        if (!session) return ack({ ok: false, error: "SESSION_NOT_FOUND" });
        const key = `${session.id}|${socket.handshake.address}`;
        if (options.guard?.blocked(key)) return ack({ ok: false, error: "FORBIDDEN" });
        if (typeof payload.hostToken !== "string" || !tokenEquals(payload.hostToken, session.hostToken)) {
          options.guard?.fail(key);
          return ack({ ok: false, error: "FORBIDDEN" });
        }
        options.guard?.ok(key);
        ack(handler(session, payload));
      };

    /** Event siswa: wajib sudah memilih nama (atau tersambung ulang dengan token). */
    const asPlayer =
      <P>(handler: (session: GameSession, studentId: string, payload: P) => Ack<object>) =>
      (payload: P, ack: AckFn): void => {
        const session = ctx.sessionId ? registry.get(ctx.sessionId) : undefined;
        if (!session || !ctx.studentId) return ack({ ok: false, error: "NOT_CLAIMED" });
        ack(handler(session, ctx.studentId, payload));
      };

    socket.on(
      "host:create",
      wrap<HostCreatePayload>((payload, ack) => {
        const created = registry.create(payload?.roster, payload?.settings, payload?.hostToken);
        if (!created.ok) return ack({ ok: false, error: "INVALID_SETTINGS", detail: created.errors });
        const s = created.session;
        void socket.join(rooms.host(s.id));
        ctx.sessionId = s.id;
        const response: { ok: true } & HostCreateAck = { ok: true, sessionId: s.id, code: s.code, hostToken: s.hostToken, settings: s.settings };
        ack(response);
        s.begin();
      }),
    );

    socket.on(
      "host:attach",
      wrap<HostAuth>(
        asHost((s) => {
          void socket.join(rooms.host(s.id));
          ctx.sessionId = s.id;
          return { ok: true, phase: s.phase, lobby: s.lobbyView(), settings: s.settings, code: s.phase === "LOBBY" || s.phase === "COUNTDOWN" ? s.code : null, rejected: s.rejected, phaseState: s.phaseSnapshot() ?? null };
        }),
      ),
    );
    socket.on("host:skipIntro", wrap<HostAuth>(asHost((s) => s.skipIntro())));
    socket.on("host:start", wrap<HostAuth>(asHost((s) => s.start())));
    socket.on("host:skip", wrap<HostAuth>(asHost((s) => s.skip())));
    socket.on(
      "host:end",
      wrap<HostAuth>(
        asHost((s) => {
          const r = s.end();
          if (r.ok) registry.release(s.id);
          return r;
        }),
      ),
    );
    socket.on("host:settings", wrap<HostAuth & { settings: unknown }>(asHost((s, p) => s.updateSettings(p.settings))));
    socket.on("host:seatLayout", wrap<HostAuth & { seatLayout: unknown }>(asHost((s, p) => s.updateSettings({ seatLayout: p.seatLayout }))));
    socket.on("host:clearSeat", wrap<HostAuth & { row: number; col: number }>(asHost((s, p) => s.clearSeat(p.row, p.col))));
    socket.on("host:removePlayer", wrap<HostAuth & { rosterId: string }>(asHost((s, p) => s.removePlayer(p.rosterId))));
    socket.on("host:releaseName", wrap<HostAuth & { rosterId: string }>(asHost((s, p) => s.releaseName(p.rosterId))));

    const attachPlayer = (s: GameSession, studentId: string): void => {
      ctx.sessionId = s.id;
      ctx.studentId = studentId;
      void socket.join(rooms.room(s.id));
      void socket.join(rooms.player(s.id, studentId));
    };

    socket.on(
      "player:join",
      wrap<{ code: string; studentToken?: string }>((payload, ack) => {
        const s = registry.byPin(String(payload?.code ?? ""));
        if (!s) return ack({ ok: false, error: "PIN_INVALID" });
        if (payload.studentToken) {
          const r = s.reattach(payload.studentToken, socket.id, false);
          if (r.ok && r.me) {
            attachPlayer(s, r.me.studentId);
            s.resendState(r.me.studentId);
          }
          return ack(r);
        }
        const r = s.lookup();
        if (r.ok) {
          ctx.sessionId = s.id;
          void socket.join(rooms.room(s.id));
        }
        ack(r);
      }),
    );

    socket.on(
      "player:claim",
      wrap<{ rosterId: string }>((payload, ack) => {
        const s = ctx.sessionId ? registry.get(ctx.sessionId) : undefined;
        if (!s) return ack({ ok: false, error: "NOT_OPEN" });
        const r = s.claim(String(payload?.rosterId ?? ""), socket.id);
        if (r.ok) attachPlayer(s, r.studentId);
        ack(r);
      }),
    );

    socket.on("player:seat", wrap<{ row: number; col: number }>(asPlayer((s, id, p) => s.seat(id, p.row, p.col))));
    socket.on("tutorial:step", wrap<TutorialStepResult>(asPlayer((s, id, p) => s.tutorialStep(id, p))));
    socket.on("tutorial:done", wrap<{ totalMs: number; autoDemoSteps: number[]; probeCorrect?: boolean | null }>(asPlayer((s, id, p) => s.tutorialDone(id, p))));
    socket.on("integrity:event", wrap<IntegrityEventPayload>(asPlayer((s, id, p) => s.integrityEvent(id, p))));
    socket.on("route:progress", wrap<{ roundId: number; path: string[]; tMs: number }>(asPlayer((s, id, p) => s.routeProgress(id, p))));
    socket.on("route:submit", wrap<RouteSubmitPayload>(asPlayer((s, id, p) => s.routeSubmit(id, p))));
    socket.on("probe:answer", wrap<{ roundId: number; value: number; clientElapsedMs: number }>(asPlayer((s, id, p) => s.probeAnswer(id, p))));

    if (options.allowBots) {
      // Hanya terdaftar pada server mode test/simulasi; pada produksi event ini tidak dikenal sama sekali.
      socket.on(
        "test:addBot",
        wrap<{ code: string; rosterId: string }>((payload, ack) => {
          const s = registry.byPin(String(payload?.code ?? ""));
          if (!s) return ack({ ok: false, error: "PIN_INVALID" });
          ack(s.addBot(String(payload.rosterId)));
        }),
      );
    }

    socket.on("disconnect", () => {
      if (ctx.sessionId && ctx.studentId) registry.get(ctx.sessionId)?.detach(socket.id);
    });
  });
}

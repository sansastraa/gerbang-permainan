import { randomInt, randomUUID } from "node:crypto";
import { HOST_TOKEN_MAX, HOST_TOKEN_MIN, defaultSettings, isValidHostToken, mergeSettings, type RosterEntry, type SessionSettings } from "@route-rush/shared";
import { GameSession, type Emitter, type SessionDeps } from "./session";

export type RegistryDeps = Omit<SessionDeps, "emitter"> & {
  makeEmitter: (sessionId: string) => Emitter;
  newPin?: () => string;
  newId?: () => string;
};

const defaultPin = (): string => String(randomInt(0, 1_000_000)).padStart(6, "0");
const defaultId = (): string => `rr-${randomUUID().slice(0, 8)}`;

export type CreateResult = { ok: true; session: GameSession } | { ok: false; errors: string[] };

/** Daftar sesi aktif. PIN 6 digit dibuat di dalam game dan unik di antara sesi yang aktif. */
export class SessionRegistry {
  private readonly byId = new Map<string, GameSession>();
  private readonly byCode = new Map<string, GameSession>();

  constructor(private readonly deps: RegistryDeps) {}

  /** `hostToken` opsional: PIN guru dari SIMPETERI (4–32 karakter). Tanpa itu token dibuat acak. */
  create(roster: RosterEntry[], patch: Partial<SessionSettings> | undefined, hostToken?: unknown): CreateResult {
    const errors: string[] = [];
    if (hostToken !== undefined && !isValidHostToken(hostToken)) errors.push(`PIN guru harus ${HOST_TOKEN_MIN}–${HOST_TOKEN_MAX} karakter`);
    if (!Array.isArray(roster) || roster.length === 0) errors.push("daftar siswa kosong");
    else {
      const ids = new Set<string>();
      for (const r of roster) {
        if (typeof r?.id !== "string" || r.id.length === 0 || typeof r.name !== "string" || r.name.trim().length === 0) errors.push("setiap siswa wajib punya id dan nama");
        else if (r.absen !== undefined && (!Number.isInteger(r.absen) || r.absen < 1 || r.absen > 200)) errors.push(`absen ${r.id} harus bilangan bulat 1–200`);
        else if (ids.has(r.id)) errors.push(`id siswa ganda: ${r.id}`);
        else ids.add(r.id);
      }
    }
    if (errors.length > 0) return { ok: false, errors };
    const merged = mergeSettings(defaultSettings(roster.length), patch ?? {}, roster.length);
    if (!merged.ok) return merged;

    const newPin = this.deps.newPin ?? defaultPin;
    let code = newPin();
    for (let tries = 0; this.byCode.has(code) && tries < 1000; tries++) code = newPin();
    if (this.byCode.has(code)) return { ok: false, errors: ["tidak ada PIN yang tersedia"] };
    const id = (this.deps.newId ?? defaultId)();
    const session = new GameSession(
      { id, code, hostToken: isValidHostToken(hostToken) ? hostToken : this.deps.newToken(), settings: merged.settings, roster: roster.map((r) => ({ ...r })) },
      { ...this.deps, emitter: this.deps.makeEmitter(id) },
    );
    this.byId.set(id, session);
    this.byCode.set(code, session);
    return { ok: true, session };
  }

  get(id: string): GameSession | undefined {
    return this.byId.get(id);
  }

  byPin(code: string): GameSession | undefined {
    return this.byCode.get(code);
  }

  /** Sesi yang sudah berakhir dilepas dari daftar agar PIN-nya bisa dipakai lagi. */
  release(id: string): void {
    const s = this.byId.get(id);
    if (!s) return;
    this.byId.delete(id);
    this.byCode.delete(s.code);
  }

  get size(): number {
    return this.byId.size;
  }
}

import { readFileSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parsePool, parseTutorial, type PoolDef, type TutorialMap } from "@route-rush/shared";

export interface Bank {
  pools: { A: PoolDef; B: PoolDef; T: PoolDef };
  tutorial: TutorialMap[];
}

const defaultMapsDir = resolve(dirname(fileURLToPath(import.meta.url)), "../../shared/maps");

/** Memuat bank soal dan peta tutorial dari berkas acuan (hanya dibaca, tidak pernah ditulis). */
export function loadBank(mapsDir = defaultMapsDir): Bank {
  const read = (name: string): unknown => JSON.parse(readFileSync(join(mapsDir, name), "utf8"));
  return { pools: { A: parsePool(read("poolA.json")), B: parsePool(read("poolB.json")), T: parsePool(read("poolT.json")) }, tutorial: parseTutorial(read("tutorial.json")) };
}

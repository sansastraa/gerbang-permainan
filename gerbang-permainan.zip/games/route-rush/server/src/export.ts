import type { Response, Router } from "express";
import { type SessionSettings, buildReport, itemsCsv, reportHtml, roundsCsv, studentsCsv, tutorialCsv, withBom, type IntegrityFlag, type RoundResult, type SessionExportData, type TutorialResult } from "@route-rush/shared";
import { tokenEquals, verifyToken, type FailureGuard, type TokenRecord } from "./guard";
import type { SessionRegistry } from "./registry";
import type { JsonlStore, SessionKind } from "./store";

const SAFE_ID = /^[A-Za-z0-9_-]{1,64}$/;

/** Membaca berkas JSONL sesi (LIVE dulu, lalu TEST) menjadi data ekspor. Null bila sesi tidak ada. */
export function loadSessionData(store: JsonlStore, sessionId: string): SessionExportData | null {
  let kind: SessionKind = "LIVE";
  let events = store.read("LIVE", sessionId);
  if (events.length === 0) {
    events = store.read("TEST", sessionId);
    kind = "TEST";
  }
  if (events.length === 0) return null;
  const d: SessionExportData = { sessionId, kind, form: "A", mode: "STANDARD", introMode: "FULL", createdAt: null, players: [], rounds: [], tutorials: [], integrityEvents: [], settings: null, startedAt: null, podiumAt: null, endedAt: null };
  for (const e of events) {
    const settings = e["settings"] as { pool?: "A" | "B" | "T"; mode?: "STANDARD" | "QUICK"; introMode?: "FULL" | "SHORT" } | undefined;
    if ((e.type === "session" || e.type === "settings") && settings) {
      if (settings.pool) d.form = settings.pool;
      if (settings.mode) d.mode = settings.mode;
      if (settings.introMode) d.introMode = settings.introMode;
      if (e.type === "session") d.createdAt = e.at;
      d.settings = settings as SessionSettings;
    } else if (e.type === "player") {
      const id = e["studentId"] as string;
      if (!d.players.some((p) => p.studentId === id)) d.players.push({ studentId: id, name: e["name"] as string, isBot: e["isBot"] === true });
    } else if (e.type === "round") d.rounds.push(e["result"] as RoundResult);
    else if (e.type === "tutorial") d.tutorials.push({ isBot: e["isBot"] === true, result: e["result"] as TutorialResult });
    else if (e.type === "remove") {
      const id = e["studentId"] as string;
      d.players = d.players.filter((p) => p.studentId !== id);
      d.rounds = d.rounds.filter((r) => r.studentId !== id);
      d.tutorials = d.tutorials.filter((t) => t.result.studentId !== id);
      d.integrityEvents = d.integrityEvents.filter((x) => x.studentId !== id);
    } else if (e.type === "start") d.startedAt = e.at;
    else if (e.type === "podium") d.podiumAt = e.at;
    else if (e.type === "end") d.endedAt = e.at;
    else if (e.type === "integrity") d.integrityEvents.push({ studentId: e["studentId"] as string, flag: e["flag"] as IntegrityFlag });
  }
  return d;
}

/** Jejak token guru (hash bergaram) yang dicatat saat sesi dibuat; null untuk data lama. */
function readTokenRecord(store: JsonlStore, sessionId: string): TokenRecord | null {
  for (const kind of ["LIVE", "TEST"] as const) {
    for (const e of store.read(kind, sessionId)) {
      if (e.type === "auth" && typeof e["salt"] === "string" && typeof e["hash"] === "string") return { salt: e["salt"], hash: e["hash"] };
    }
  }
  return null;
}

/** Data ringkas untuk menu Laporan di layar guru (tanpa tap log): satu baris per siswa dengan rincian per ronde. */
export function reportJson(r: ReturnType<typeof buildReport>): unknown {
  const { data } = r;
  return {
    sessionId: data.sessionId,
    kind: data.kind,
    form: data.form,
    mode: data.mode,
    createdAt: data.createdAt,
    students: r.students.map((s) => ({
      studentId: s.studentId,
      name: s.nickname,
      isBot: s.isBot,
      points: s.summary.totalPoints,
      roundsPlayed: s.summary.roundsPlayed,
      roundsMissed: s.summary.roundsMissed,
      optimal: s.rounds.filter((x) => x.roundId > 0 && x.optimalHit).length,
      meanEr: s.summary.meanEr,
      medianT: s.summary.medianT,
      // profil untuk Multi Permainan SIMPETERI (indeks 0–100 dan kuadran)
      il: s.summary.il === null ? null : Math.round(s.summary.il * 10) / 10,
      im: s.summary.im === null ? null : Math.round(s.summary.im * 10) / 10,
      is: s.summary.is === null ? null : Math.round(s.summary.is * 10) / 10,
      quadrant: s.quadrant,
      integrity: s.integrity,
      rounds: s.rounds
        .filter((x) => x.roundId > 0)
        .map((x) => ({
          roundId: x.roundId,
          nNodes: x.nNodes,
          steps: x.steps,
          optimalCost: x.optimalCost,
          playerCost: x.playerCost,
          optimalHit: x.optimalHit,
          completed: x.completed,
          timedOut: x.timedOut,
          missed: x.missed,
          er: x.er,
          tRouteMs: x.tRouteMs,
          timeLimitS: x.timeLimitS,
          points: x.racePoints + x.streakBonus + x.probePoints,
        })),
    })),
  };
}

const FILES = {
  "rounds.csv": roundsCsv,
  "tutorial.csv": tutorialCsv,
  "items.csv": itemsCsv,
} as const;

function sendCsv(res: Response, name: string, csv: string): void {
  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition", `attachment; filename="${name}"`);
  res.send(withBom(csv));
}

/**
 * Titik ekspor (Bagian 11): rounds/students/tutorial/items .csv dan report.html. Sesi TEST ditolak (403) kecuali `?includeTest=1`;
 * hasil yang gagal integritas (data/rejected/) tidak pernah ikut. Berkas CSV berawalan BOM UTF-8 agar Excel membacanya dengan benar.
 */
export function mountExport(app: Pick<Router, "get">, store: JsonlStore, registry?: SessionRegistry, guard?: FailureGuard): void {
  app.get("/api/sessions/:id/:file", (req, res) => {
    const { id, file } = req.params as { id: string; file: string };
    if (!SAFE_ID.test(id)) return void res.status(400).json({ error: "ID_INVALID" });
    const known = file === "students.csv" || file === "report.html" || file === "summary.json" || file in FILES;
    if (!known) return void res.status(404).json({ error: "NOT_FOUND" });
    // Pemilik sesi (PIN guru dari SIMPETERI atau token acak) memegang token di header x-host-token:
    //   404 sesi tidak ada; 401 token salah atau tidak ada; 403 belum selesai (sesi masih berjalan dan peminta lintas asal);
    //   429 terlalu banyak percobaan salah. Layar guru sendiri (sama asal, tanpa header Origin) boleh membaca sesi yang masih berjalan.
    // Data lama tanpa jejak token tetap terbaca seperti semula.
    const live = registry?.get(id);
    const d0 = live ? null : loadSessionData(store, id);
    if (!live && !d0) return void res.status(404).json({ error: "SESSION_NOT_FOUND" });
    const record = live ? null : readTokenRecord(store, id);
    if (live || record) {
      const key = `${id}|${req.ip ?? ""}`;
      if (guard?.blocked(key)) return void res.status(429).json({ error: "TOO_MANY_ATTEMPTS" });
      const given = req.header("x-host-token");
      const good = given !== undefined && (live ? tokenEquals(given, live.hostToken) : verifyToken(given, record as TokenRecord));
      if (!good) {
        if (given !== undefined) guard?.fail(key);
        return void res.status(401).json({ error: "PIN_SALAH" });
      }
      guard?.ok(key);
      if (live && req.headers.origin !== undefined) return void res.status(403).json({ error: "BELUM_SELESAI", message: "Sesi masih berjalan; laporan lintas asal baru tersedia setelah sesi berakhir." });
    }    const d = d0 ?? loadSessionData(store, id);
    if (!d) return void res.status(404).json({ error: "SESSION_NOT_FOUND" });
    if (d.kind === "TEST" && req.query["includeTest"] !== "1") {
      return void res.status(403).json({ error: "SESSION_TEST", message: "Sesi TEST tidak diekspor tanpa ?includeTest=1." });
    }
    const base = `route-rush-${id}`;
    if (file === "summary.json") return void res.json(reportJson(buildReport(d)));
    if (file === "report.html") {
      res.setHeader("Content-Type", "text/html; charset=utf-8");
      return void res.send(reportHtml(buildReport(d)));
    }
    if (file === "students.csv") return void sendCsv(res, `${base}-students.csv`, studentsCsv(buildReport(d)));
    sendCsv(res, `${base}-${file}`, FILES[file as keyof typeof FILES](d));
  });
}
import { createHash, randomBytes, scryptSync, timingSafeEqual } from "node:crypto";

/** Perbandingan token yang tidak bocor lewat waktu: kedua sisi di-hash dulu agar panjangnya sama. */
export function tokenEquals(a: string, b: string): boolean {
  const ha = createHash("sha256").update(a).digest();
  const hb = createHash("sha256").update(b).digest();
  return timingSafeEqual(ha, hb);
}

/** Jejak token guru yang disimpan bersama data sesi agar laporan sesi yang sudah berakhir tetap terlindungi (token asli tidak disimpan). */
export interface TokenRecord {
  salt: string;
  hash: string;
}

export function hashToken(token: string): TokenRecord {
  const salt = randomBytes(16).toString("hex");
  return { salt, hash: scryptSync(token, salt, 32).toString("hex") };
}

export function verifyToken(token: string, rec: TokenRecord): boolean {
  const expected = Buffer.from(rec.hash, "hex");
  const actual = scryptSync(token, rec.salt, expected.length);
  return actual.length === expected.length && timingSafeEqual(actual, expected);
}

/**
 * Pembatas percobaan token yang salah, per kunci (sesi + alamat peminta). PIN guru buatan manusia bisa pendek,
 * jadi setelah `max` kegagalan dalam `windowMs` kunci itu dikunci selama `lockMs`. Kunci lain (guru sungguhan) tidak terpengaruh.
 */
export class FailureGuard {
  private readonly hits = new Map<string, { fails: number; first: number; lockedUntil: number }>();

  constructor(
    private readonly max = 8,
    private readonly windowMs = 10 * 60_000,
    private readonly lockMs = 10 * 60_000,
    private readonly now: () => number = Date.now,
  ) {}

  blocked(key: string): boolean {
    const h = this.hits.get(key);
    return h !== undefined && h.lockedUntil > this.now();
  }

  fail(key: string): void {
    const t = this.now();
    if (this.hits.size > 5000) this.prune(t);
    const h = this.hits.get(key);
    if (!h || t - h.first > this.windowMs) {
      this.hits.set(key, { fails: 1, first: t, lockedUntil: 0 });
      return;
    }
    h.fails += 1;
    if (h.fails >= this.max) h.lockedUntil = t + this.lockMs;
  }

  /** Token benar: hapus catatan gagal untuk kunci itu. */
  ok(key: string): void {
    this.hits.delete(key);
  }

  private prune(t: number): void {
    for (const [k, h] of this.hits) if (h.lockedUntil <= t && t - h.first > this.windowMs) this.hits.delete(k);
  }
}

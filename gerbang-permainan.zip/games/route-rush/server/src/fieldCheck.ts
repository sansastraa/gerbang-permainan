/**
 * Pemeriksaan lapangan (Fase 9): membaca satu sesi LIVE dari data/ dan menulis docs/field-check-<sessionId>.md.
 *
 *   npm run field-check -- --session <id> [--data data] [--out docs] [--include-test]
 *
 * Sesi TEST (bot) ditolak kecuali `--include-test`, agar data uji tidak disangka bukti uji lapangan.
 */
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { fieldCheck, fieldCheckMarkdown, type FieldCheck } from "@route-rush/shared";
import { loadSessionData } from "./export";
import { JsonlStore } from "./store";

export interface FieldCheckRun {
  fc: FieldCheck;
  markdown: string;
}

/** Menjalankan pemeriksaan untuk satu sesi; melempar Error berpesan jelas bila sesi tidak ada atau berjenis TEST. */
export function runFieldCheck(dataDir: string, sessionId: string, includeTest = false): FieldCheckRun {
  if (!/^[A-Za-z0-9_-]{1,64}$/.test(sessionId)) throw new Error(`id sesi tidak sah: ${sessionId}`);
  const store = new JsonlStore(dataDir);
  const data = loadSessionData(store, sessionId);
  if (!data) throw new Error(`sesi ${sessionId} tidak ditemukan di ${dataDir}/sessions maupun ${dataDir}/test-sessions`);
  if (data.kind === "TEST" && !includeTest) throw new Error(`sesi ${sessionId} berjenis TEST (bot/simulasi). Tambahkan --include-test bila hanya ingin mencoba skrip.`);
  const rejected = store.readRejected(sessionId).length;
  const fc = fieldCheck(data, rejected);
  return { fc, markdown: fieldCheckMarkdown(fc) };
}

function main(): void {
  const arg = (name: string): string | undefined => {
    const i = process.argv.indexOf(name);
    return i >= 0 ? process.argv[i + 1] : undefined;
  };
  const session = arg("--session");
  if (!session) {
    console.error("Pemakaian: npm run field-check -- --session <id> [--data data] [--out docs] [--include-test]");
    process.exit(2);
  }
  const root = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
  const dataDir = resolve(arg("--data") ?? process.env["DATA_DIR"] ?? "data");
  const outDir = resolve(arg("--out") ?? resolve(root, "docs"));
  try {
    const { fc, markdown } = runFieldCheck(dataDir, session, process.argv.includes("--include-test"));
    mkdirSync(outDir, { recursive: true });
    const file = resolve(outDir, `field-check-${session}.md`);
    writeFileSync(file, markdown, "utf8");
    console.log(`Hasil: ${fc.verdict}. Laporan: ${file}`);
    for (const c of fc.checks) console.log(`  ${c.id.padEnd(3)} ${c.status.padEnd(13)} ${c.name}: ${c.value}`);
    process.exit(fc.verdict === "TIDAK LULUS" ? 1 : 0);
  } catch (e) {
    console.error((e as Error).message);
    process.exit(2);
  }
}

if (process.argv[1] && /fieldCheck\.(ts|js)$/.test(process.argv[1])) main();
import {
  COUNTDOWN_MS,
  GRACE_MS,
  INTRO_MS,
  LEADERBOARD_MS,
  TUTORIAL_MS,
  IntegrityError,
  assertRoundIntegrity,
  assertTutorialIntegrity,
  assignSlot,
  assignSlotNoSeat,
  assignVariant,
  assignVariantNoSeat,
  applyVariant,
  distributionParams,
  displayIndex,
  effectiveRoundConfig,
  evaluatePath,
  firstValidTapMs,
  isFinished,
  labelSeedFor,
  mergeSettings,
  optimalCost,
  nextLevel,
  type RoundSummaryItem,
  optimalRoute,
  poolItem,
  generateUniqueMap,
  mapShapeKey,
  probeOptions,
  probePoints,
  racePoints,
  settingsRoundIds,
  streakBonuses,
  type Ack,
  type ClaimAck,
  type DistributionParams,
  type IntegrityEventPayload,
  type IntegrityFlag,
  type JoinAck,
  type LobbyUpdate,
  type MapDef,
  type NodeId,
  type PhasePayload,
  type ProbeQuestion,
  type ProtocolError,
  type RosterEntry,
  type RoundConfig,
  type RoundMapPayload,
  type RoundResult,
  type RoundResultPayload,
  type RouteSubmitPayload,
  type SeatLayout,
  type SessionPhase,
  type SessionSettings,
  type TutorialResult,
  type TutorialStepResult,
} from "@route-rush/shared";
import type { Clock, TimerHandle } from "./clock";
import { hashToken } from "./guard";
import type { Bank } from "./data";
import type { JsonlStore, StoredEvent } from "./store";

export interface Emitter {
  toHost(event: string, payload: unknown): void;
  toPlayer(studentId: string, event: string, payload: unknown): void;
  /** Semua siswa yang sudah memilih nama. */
  toPlayers(event: string, payload: unknown): void;
  /** Siswa yang sudah membuka PIN tetapi belum memilih nama, ditambah siswa yang sudah memilih. */
  toRoom(event: string, payload: unknown): void;
  toAll(event: string, payload: unknown): void;
}

export interface SessionDeps {
  clock: Clock;
  store: JsonlStore;
  emitter: Emitter;
  bank: Bank;
  newToken: () => string;
  /** Pembuat bot hanya boleh aktif pada server mode test atau simulasi. */
  allowBots: boolean;
}

export interface SessionInit {
  id: string;
  code: string;
  hostToken: string;
  settings: SessionSettings;
  roster: RosterEntry[];
}

interface Seat {
  row: number;
  col: number;
}

interface Player {
  id: string;
  name: string;
  token: string;
  isBot: boolean;
  joinIndex: number;
  connKey: string | null;
  seat: Seat | null;
  flags: Set<IntegrityFlag>;
  results: RoundResult[];
  hits: boolean[];
  totalPoints: number;
  optimalCount: number;
  /** Tingkat soal adaptif (pool T), 1–10; mulai dari yang termudah. */
  level: number;
  steps: TutorialStepResult[];
  tutorialDone: { totalMs: number; autoDemoSteps: number[]; probeCorrect: boolean | null } | null;
}

interface Submission {
  path: NodeId[];
  tRouteMs: number;
  tapLog: RoundResult["tapLog"];
  invalidTaps: number;
  undo: number;
}

interface Assignment {
  slot: 0 | 1 | 2 | 3;
  variantId: number;
  item: MapDef;
  seat: Seat | null;
  seatMode: "SEATED" | "NO_SEAT";
}

interface RoundRuntime {
  index: number;
  config: RoundConfig;
  display: number;
  assign: Map<string, Assignment>;
  seen: Set<string>;
  submissions: Map<string, Submission>;
  progress: Map<string, { path: NodeId[]; tMs: number }>;
  probes: Map<string, { value: number; ms: number }>;
  probeAnswers: Map<string, number>;
  focus: Map<string, { focusLost: number; fullscreenExits: number }>;
  roundFlags: Map<string, Set<IntegrityFlag>>;
  walkStartAt: number | null;
  walkEndAt: number | null;
  walkEnded: boolean;
  finalized: boolean;
  probeStartAt: number | null;
}

const ok = <T extends object>(extra: T): { ok: true } & T => ({ ok: true, ...extra });
const fail = (error: ProtocolError, detail?: unknown): { ok: false; error: ProtocolError; detail?: unknown } =>
  detail === undefined ? { ok: false, error } : { ok: false, error, detail };

const clamp = (v: number, lo: number, hi: number): number => Math.min(hi, Math.max(lo, v));

/** Satu sesi permainan. Server adalah sumber kebenaran fase dan waktu; client hanya menampilkan dan mengirim ketukan. */
export class GameSession {
  readonly id: string;
  readonly code: string;
  readonly hostToken: string;
  readonly roster: RosterEntry[];
  settings: SessionSettings;
  phase: SessionPhase = "INTRO_IDENT";

  private readonly deps: SessionDeps;
  private readonly players = new Map<string, Player>();
  private readonly dist: DistributionParams;
  private plan: number[] = [];
  private timer: TimerHandle | null = null;
  private onPhaseEnd: (() => void) | null = null;
  private lastPhase: PhasePayload | null = null;
  private phaseEndsAt: number | null = null;
  private seatsLocked = false;
  private round: RoundRuntime | null = null;
  private rejectedCount = 0;
  private joinCounter = 0;
  private tutorialStartedAt: number | null = null;
  private readonly allResults: RoundResult[] = [];
  private readonly allTutorials: { isBot: boolean; result: TutorialResult }[] = [];

  constructor(init: SessionInit, deps: SessionDeps) {
    this.id = init.id;
    this.code = init.code;
    this.hostToken = init.hostToken;
    this.settings = init.settings;
    this.roster = init.roster;
    this.deps = deps;
    this.dist = distributionParams(init.id);
  }

  // ------------------------------------------------------------------ pembantu umum

  private now(): number {
    return this.deps.clock.now();
  }

  private log(type: string, data: Record<string, unknown>): void {
    const event: StoredEvent = { type, game: "ROUTE_RUSH", sessionId: this.id, at: this.now(), ...data };
    this.deps.store.append(this.settings.kind, event);
  }

  private claimed(): Player[] {
    return [...this.players.values()];
  }

  private connected(): Player[] {
    return this.claimed().filter((p) => p.connKey !== null);
  }

  private player(id: string): Player | undefined {
    return this.players.get(id);
  }

  private playerByConn(connKey: string): Player | undefined {
    return this.claimed().find((p) => p.connKey === connKey);
  }

  get results(): readonly RoundResult[] {
    return this.allResults;
  }

  get tutorialResults(): readonly { isBot: boolean; result: TutorialResult }[] {
    return this.allTutorials;
  }

  get rejected(): number {
    return this.rejectedCount;
  }

  get playerList(): readonly { id: string; name: string; isBot: boolean; totalPoints: number; flags: IntegrityFlag[] }[] {
    return this.claimed().map((p) => ({ id: p.id, name: p.name, isBot: p.isBot, totalPoints: p.totalPoints, flags: [...p.flags] }));
  }

  // ------------------------------------------------------------------ fase

  private clearTimer(): void {
    if (this.timer) this.deps.clock.clearTimer(this.timer);
    this.timer = null;
    this.onPhaseEnd = null;
  }

  private enter(phase: SessionPhase, durationMs: number | null, onEnd?: () => void): void {
    this.clearTimer();
    this.phase = phase;
    const payload: PhasePayload = {
      phase,
      introMode: this.settings.introMode,
      totalRounds: this.plan.filter((id) => id > 0).length,
      durationMs,
    };
    if (this.round && ["LOOK", "WALK", "PROBE", "RESULT", "LEADERBOARD"].includes(phase)) {
      payload.roundId = this.round.config.roundId;
      payload.displayIndex = this.round.display;
      payload.condition = this.round.config.condition;
    }
    this.lastPhase = payload;
    this.phaseEndsAt = durationMs === null ? null : this.now() + durationMs;
    this.deps.emitter.toAll("phase", payload);
    if (durationMs !== null && onEnd) {
      this.onPhaseEnd = onEnd;
      this.timer = this.deps.clock.setTimer(onEnd, durationMs);
    }
  }

  /** Memulai sesi: intro (ident + trailer) lebih dulu, baru PIN dibuka di LOBBY. */
  begin(): void {
    this.log("session", { kind: this.settings.kind, settings: this.settings, rosterSize: this.roster.length, code: this.code });
    this.log("auth", { ...hashToken(this.hostToken) }); // hanya hash bergaram; dipakai ekspor sesi yang sudah berakhir
    const intro = INTRO_MS[this.settings.introMode];
    this.enter("INTRO_IDENT", intro.ident, () => this.enter("INTRO_TRAILER", intro.trailer, () => this.openLobby()));
  }

  private openLobby(): void {
    this.enter("LOBBY", null);
    this.lobbyUpdate();
  }

  /** Guru melewati intro (tahan tombol Lewati 2 detik di layar). */
  skipIntro(): Ack {
    if (this.phase !== "INTRO_IDENT" && this.phase !== "INTRO_TRAILER") return fail("WRONG_PHASE");
    this.clearTimer();
    this.openLobby();
    return ok({});
  }

  /** Lompat ke fase berikutnya (kecuali LOBBY dan PODIUM yang menunggu guru). */
  skip(): Ack {
    if (!this.onPhaseEnd) return fail("WRONG_PHASE");
    const fn = this.onPhaseEnd;
    this.clearTimer();
    fn();
    return ok({});
  }

  // ------------------------------------------------------------------ lobi: PIN, nama, kursi, kuota

  private seatsPending(): number {
    if (!this.settings.seatLayout.enabled) return 0;
    return this.connected().filter((p) => p.seat === null).length;
  }

  canStart(): Ack {
    if (this.phase !== "LOBBY") return fail("WRONG_PHASE");
    const joined = this.connected().length;
    if (joined < this.settings.quota) return fail("QUOTA_NOT_MET", { joined, quota: this.settings.quota });
    if (this.seatsPending() > 0) return fail("SEATS_PENDING", { pending: this.seatsPending() });
    return ok({});
  }

  lobbyView(): LobbyUpdate {
    const gate = this.canStart();
    return {
      players: this.claimed().map((p) => ({ id: p.id, name: p.name, seat: p.seat, connected: p.connKey !== null })),
      joined: this.connected().length,
      quota: this.settings.quota,
      seatsPending: this.seatsPending(),
      canStart: gate.ok,
    };
  }

  private lobbyUpdate(): void {
    const view = this.lobbyView();
    this.deps.emitter.toHost("lobby:update", view);
    this.deps.emitter.toRoom("roster:update", this.rosterView());
    this.deps.emitter.toRoom("seat:update", this.seatView());
  }

  private rosterView(): { id: string; name: string; taken: boolean }[] {
    return this.roster.map((r) => ({ id: r.id, name: r.name, taken: this.players.has(r.id) }));
  }

  private seatView(): { taken: { row: number; col: number; initials: string }[] } {
    const initials = (n: string): string =>
      n
        .split(/\s+/)
        .filter(Boolean)
        .slice(0, 2)
        .map((w) => (w[0] ?? "").toUpperCase())
        .join("");
    return { taken: this.claimed().flatMap((p) => (p.seat ? [{ ...p.seat, initials: initials(p.name) }] : [])) };
  }

  /** Siswa memasukkan PIN: PIN hanya bisa dipakai setelah intro (fase LOBBY). */
  lookup(): Ack<JoinAck> {
    if (this.phase === "INTRO_IDENT" || this.phase === "INTRO_TRAILER") return fail("NOT_OPEN");
    if (this.phase !== "LOBBY") return fail("SESSION_STARTED");
    return ok({ roster: this.rosterView(), seatLayout: this.settings.seatLayout, phase: this.phase });
  }

  /** Siswa memilih namanya dari daftar siswa SIMPETERI; satu nama hanya untuk satu perangkat. */
  claim(rosterId: string, connKey: string): Ack<ClaimAck> {
    if (this.phase !== "LOBBY") return fail(this.phase === "INTRO_IDENT" || this.phase === "INTRO_TRAILER" ? "NOT_OPEN" : "SESSION_STARTED");
    if (this.playerByConn(connKey)) return fail("ALREADY_CLAIMED");
    const entry = this.roster.find((r) => r.id === rosterId);
    if (!entry) return fail("NAME_UNKNOWN");
    if (this.players.has(entry.id)) return fail("NAME_TAKEN");
    const p = this.makePlayer(entry, connKey, false);
    this.log("player", { studentId: p.id, name: p.name, isBot: false });
    this.lobbyUpdate();
    return ok({ studentId: p.id, studentToken: p.token, seatLayout: this.settings.seatLayout });
  }

  private makePlayer(entry: RosterEntry, connKey: string | null, isBot: boolean): Player {
    const p: Player = {
      id: entry.id,
      name: entry.name,
      token: this.deps.newToken(),
      isBot,
      joinIndex: this.joinCounter++,
      connKey,
      seat: null,
      flags: new Set(),
      results: [],
      hits: [],
      totalPoints: 0,
      optimalCount: 0,
      level: 1,
      steps: [],
      tutorialDone: null,
    };
    this.players.set(p.id, p);
    return p;
  }

  /** Pembuat bot: hanya server mode test/simulasi dan hanya sesi TEST; sesi LIVE tidak pernah berisi bot. */
  addBot(rosterId: string): Ack<{ studentId: string; studentToken: string }> {
    if (!this.deps.allowBots || this.settings.kind !== "TEST") return fail("BOTS_DISABLED");
    if (this.phase !== "LOBBY") return fail("WRONG_PHASE");
    const entry = this.roster.find((r) => r.id === rosterId);
    if (!entry) return fail("NAME_UNKNOWN");
    if (this.players.has(entry.id)) return fail("NAME_TAKEN");
    const p = this.makePlayer(entry, null, true);
    this.log("player", { studentId: p.id, name: p.name, isBot: true });
    this.lobbyUpdate();
    return ok({ studentId: p.id, studentToken: p.token });
  }

  /** Fase sekarang beserta sisa waktunya (untuk perangkat yang baru tersambung atau tersambung ulang). */
  phaseSnapshot(): { payload: PhasePayload; remainingMs: number | null } | undefined {
    return this.lastPhase ? { payload: this.lastPhase, remainingMs: this.phaseEndsAt === null ? null : Math.max(0, this.phaseEndsAt - this.now()) } : undefined;
  }

  /** Sambung ulang dengan token. Token yang sedang dipakai perangkat lain ditolak dan dicatat SECOND_DEVICE. */
  reattach(token: string, connKey: string, resend = true): Ack<JoinAck> {
    const p = this.claimed().find((x) => x.token === token);
    if (!p) return fail("TOKEN_INVALID");
    if (p.connKey !== null && p.connKey !== connKey) {
      p.flags.add("SECOND_DEVICE");
      this.deps.emitter.toHost("integrity:alert", { studentId: p.id, name: p.name, flag: "SECOND_DEVICE" });
      this.log("integrity", { studentId: p.id, flag: "SECOND_DEVICE" });
      return fail("SECOND_DEVICE");
    }
    p.connKey = connKey;
    this.markSeen(p);
    this.lobbyUpdate();
    if (resend) this.resend(p);
    const phaseState = this.phaseSnapshot();
    return ok({
      roster: this.rosterView(),
      seatLayout: this.settings.seatLayout,
      phase: this.phase,
      me: { studentId: p.id, name: p.name, seat: p.seat },
      studentToken: p.token,
      ...(phaseState ? { phaseState } : {}),
    });
  }

  detach(connKey: string): void {
    const p = this.playerByConn(connKey);
    if (!p) return;
    p.connKey = null;
    this.lobbyUpdate();
    if (this.phase === "WALK") this.maybeEndWalk();
    if (this.phase === "TUTORIAL") this.maybeEndTutorial();
    if (this.phase === "PROBE") this.maybeEndProbe();
  }

  seat(studentId: string, row: number, col: number): Ack {
    const p = this.player(studentId);
    if (!p) return fail("NOT_CLAIMED");
    const layout = this.settings.seatLayout;
    if (!layout.enabled) return fail("SEATS_DISABLED");
    if (this.seatsLocked) return fail("SEAT_LOCKED");
    if (!Number.isInteger(row) || !Number.isInteger(col) || row < 0 || col < 0 || row >= layout.rows || col >= layout.cols) return fail("SEAT_INVALID");
    if (this.claimed().some((o) => o.id !== p.id && o.seat?.row === row && o.seat.col === col)) return fail("SEAT_TAKEN");
    if (this.phase !== "LOBBY" && this.phase !== "COUNTDOWN") return fail("SEAT_LOCKED");
    p.seat = { row, col };
    this.lobbyUpdate();
    return ok({});
  }

  /** Guru mengosongkan kursi yang salah dipilih; setelah ronde dimulai dicatat SEAT_CHANGED. */
  clearSeat(row: number, col: number): Ack {
    const p = this.claimed().find((x) => x.seat?.row === row && x.seat.col === col);
    if (!p) return fail("NOT_FOUND");
    p.seat = null;
    if (this.seatsLocked) {
      p.flags.add("SEAT_CHANGED");
      this.log("integrity", { studentId: p.id, flag: "SEAT_CHANGED" });
    }
    this.lobbyUpdate();
    return ok({});
  }

  /**
   * Guru menghapus satu siswa dari sesi (perangkat ter-reset atau error): nama, hasil ronde, dan latihannya dibuang dari peringkat dan ekspor.
   * Berlaku di fase apa pun sebelum sesi ditutup; dicatat sebagai kejadian "remove" agar muat ulang dari berkas tetap konsisten.
   */
  removePlayer(rosterId: string): Ack {
    if (this.phase === "ENDED") return fail("WRONG_PHASE");
    const p = this.player(rosterId);
    if (!p) return fail("NOT_FOUND");
    this.players.delete(rosterId);
    for (let i = this.allResults.length - 1; i >= 0; i--) if ((this.allResults[i] as RoundResult).studentId === rosterId) this.allResults.splice(i, 1);
    for (let i = this.allTutorials.length - 1; i >= 0; i--) if ((this.allTutorials[i] as { result: TutorialResult }).result.studentId === rosterId) this.allTutorials.splice(i, 1);
    const rt = this.round;
    if (rt) {
      for (const m of [rt.assign, rt.submissions, rt.progress, rt.probes, rt.probeAnswers, rt.focus, rt.roundFlags] as Map<string, unknown>[]) m.delete(rosterId);
      rt.seen.delete(rosterId);
    }
    this.log("remove", { studentId: rosterId, name: p.name });
    this.deps.emitter.toPlayer(rosterId, "player:released", {});
    this.lobbyUpdate();
    if (this.phase === "WALK") this.maybeEndWalk();
    if (this.phase === "TUTORIAL") this.maybeEndTutorial();
    if (this.phase === "PROBE") this.maybeEndProbe();
    return ok({});
  }

  releaseName(rosterId: string): Ack {
    if (this.phase !== "LOBBY") return fail("WRONG_PHASE");
    const p = this.player(rosterId);
    if (!p) return fail("NOT_FOUND");
    this.players.delete(rosterId);
    this.deps.emitter.toPlayer(rosterId, "player:released", {});
    this.lobbyUpdate();
    return ok({});
  }

  /** Menu pengaturan guru (waktu hafal, waktu jalan, ronde, kuota, denah). Hanya sebelum permainan dimulai. */
  updateSettings(patch: unknown): Ack<{ settings: SessionSettings }> {
    if (this.phase !== "LOBBY") return fail("WRONG_PHASE");
    const result = mergeSettings(this.settings, patch, this.roster.length);
    if (!result.ok) return fail("INVALID_SETTINGS", result.errors);
    const wasLayout = this.settings.seatLayout;
    this.settings = { ...result.settings, kind: this.settings.kind };
    const l: SeatLayout = this.settings.seatLayout;
    if (l.rows !== wasLayout.rows || l.cols !== wasLayout.cols || l.enabled !== wasLayout.enabled) {
      for (const p of this.claimed()) if (p.seat && (!l.enabled || p.seat.row >= l.rows || p.seat.col >= l.cols)) p.seat = null;
    }
    this.log("settings", { settings: this.settings });
    this.deps.emitter.toRoom("settings:update", { seatLayout: this.settings.seatLayout });
    this.lobbyUpdate();
    return ok({ settings: this.settings });
  }

  // ------------------------------------------------------------------ mulai

  /** Guru menekan Mulai: hanya bila semua siswa dalam kuota sudah masuk (dan semua sudah memilih kursi bila denah aktif). */
  start(): Ack {
    const gate = this.canStart();
    if (!gate.ok) return gate;
    this.plan = settingsRoundIds(this.settings);
    this.log("start", { players: this.connected().length, plan: this.plan });
    this.enter("COUNTDOWN", COUNTDOWN_MS, () => (this.settings.introMode === "FULL" ? this.startTutorial() : this.startRound(0)));
    return ok({});
  }

  // ------------------------------------------------------------------ tutorial

  private tutorialMap(step: number): MapDef | null {
    const t = this.deps.bank.tutorial[step - 1];
    if (!t) return null;
    const { golden: _golden, title: _title, condition: _condition, trap: _trap, ...rest } = t;
    const map: MapDef = { ...rest };
    delete map.probeEdgeId;
    return map;
  }

  /** Peta latihan + (langkah ingatan) soal tebakan; kunci jawaban tidak dikirim, hanya id jalan dan pilihan. */
  private tutorialPayload(step: number, studentId: string): { step: number; map: MapDef | null; probe?: ProbeQuestion } {
    const raw = this.deps.bank.tutorial[step - 1];
    const map = this.tutorialMap(step);
    const edge = raw?.probeEdgeId ? raw.edges.find((e) => e.id === raw.probeEdgeId) : undefined;
    if (!edge) return { step, map };
    return { step, map, probe: { edgeId: edge.id, options: probeOptions(edge.w, `${studentId}T${step}`) } };
  }

  private startTutorial(): void {
    this.tutorialStartedAt = this.now();
    for (const p of this.connected()) this.deps.emitter.toPlayer(p.id, "tutorial:map", this.tutorialPayload(1, p.id));
    this.enter("TUTORIAL", TUTORIAL_MS, () => this.endTutorial());
    this.tutorialStatus();
  }

  private tutorialStatus(): void {
    const total = this.connected().length;
    this.deps.emitter.toHost("tutorial:status", { ready: this.connected().filter((p) => p.tutorialDone).length, total });
  }

  tutorialStep(studentId: string, step: TutorialStepResult): Ack {
    const p = this.player(studentId);
    if (!p) return fail("NOT_CLAIMED");
    if (this.phase !== "TUTORIAL") return fail("WRONG_PHASE");
    if (!Number.isInteger(step.step) || step.step < 1 || step.step > 5) return fail("INVALID_PAYLOAD");
    p.steps = [...p.steps.filter((s) => s.step !== step.step), step].sort((a, b) => a.step - b.step);
    const next = this.tutorialMap(step.step + 1);
    if (next) this.deps.emitter.toPlayer(p.id, "tutorial:map", this.tutorialPayload(step.step + 1, p.id));
    return ok({});
  }

  tutorialDone(studentId: string, payload: { totalMs: number; autoDemoSteps: number[]; probeCorrect?: boolean | null }): Ack {
    const p = this.player(studentId);
    if (!p) return fail("NOT_CLAIMED");
    if (this.phase !== "TUTORIAL") return fail("WRONG_PHASE");
    if (typeof payload.totalMs !== "number" || !Array.isArray(payload.autoDemoSteps)) return fail("INVALID_PAYLOAD");
    p.tutorialDone = { totalMs: payload.totalMs, autoDemoSteps: payload.autoDemoSteps, probeCorrect: payload.probeCorrect ?? null };
    this.tutorialStatus();
    this.maybeEndTutorial();
    return ok({});
  }

  private maybeEndTutorial(): void {
    if (this.phase !== "TUTORIAL") return;
    const online = this.connected();
    if (online.length > 0 && online.every((p) => p.tutorialDone)) this.endTutorial();
  }

  private endTutorial(): void {
    const elapsed = Math.min(TUTORIAL_MS, this.now() - (this.tutorialStartedAt ?? this.now()));
    for (const p of this.claimed()) {
      const reported = new Map(p.steps.map((s) => [s.step, s]));
      const steps = [1, 2, 3, 4, 5].map((n) => reported.get(n) ?? { step: n, attempts: 0, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 0 });
      const missing = [1, 2, 3, 4, 5].filter((n) => !reported.has(n));
      const autoDemoSteps = [...new Set([...(p.tutorialDone?.autoDemoSteps ?? []), ...missing])].sort((a, b) => a - b);
      const sum = steps.reduce((a, s) => a + s.ms, 0);
      const result: TutorialResult = {
        sessionId: this.id,
        studentId: p.id,
        completed: p.tutorialDone !== null && autoDemoSteps.length === 0,
        totalMs: Math.max(sum, p.tutorialDone?.totalMs ?? elapsed),
        step3Attempts: reported.get(3)?.attempts ?? 0,
        hints: steps.reduce((a, s) => a + s.hintsShown, 0),
        probeCorrect: p.tutorialDone?.probeCorrect ?? null,
        autoDemoSteps,
        steps,
      };
      try {
        assertTutorialIntegrity(result);
        this.allTutorials.push({ isBot: p.isBot, result });
        this.log("tutorial", { isBot: p.isBot, result });
      } catch (e) {
        this.reject("tutorial", p, e);
      }
    }
    this.startRound(0);
  }

  // ------------------------------------------------------------------ ronde

  private reject(kind: string, p: Player, e: unknown): void {
    this.rejectedCount++;
    const reason = e instanceof IntegrityError ? e.issues : [String(e)];
    this.deps.store.reject({ type: "rejected", game: "ROUTE_RUSH", sessionId: this.id, at: this.now(), kind, studentId: p.id, reason });
    this.deps.emitter.toHost("rejected:count", { count: this.rejectedCount });
  }

  /** Pool Tantangan memilih soal menurut tingkat tiap siswa, bukan nomor ronde. */
  private adaptive(roundId: number): boolean {
    return this.settings.pool === "T" && roundId >= 1;
  }

  private assignFor(p: Player, roundId: number, hidden = false, taken: Set<string> = new Set()): Assignment {
    const layout = this.settings.seatLayout;
    const seated = layout.enabled && p.seat !== null;
    const pool = this.deps.bank.pools[this.settings.pool];
    let slot: number;
    let variantId: number;
    if (roundId === 0) {
      slot = 0;
      variantId = seated && p.seat ? assignVariant(p.seat.row, p.seat.col, 0, this.dist.offset2) : assignVariantNoSeat(p.id, 0);
    } else if (seated && p.seat) {
      slot = assignSlot(p.seat.row, p.seat.col, roundId, this.dist.perm, this.dist.offset);
      variantId = assignVariant(p.seat.row, p.seat.col, roundId, this.dist.offset2);
    } else {
      slot = assignSlotNoSeat(p.joinIndex, roundId, this.dist.offset);
      variantId = assignVariantNoSeat(p.id, roundId);
    }
    const level = this.adaptive(roundId) ? p.level : roundId;
    const canonical = poolItem(pool, level, slot);
    const item = this.settings.uniqueMaps && roundId >= 1 ? this.uniqueItem(p, roundId, level, canonical, hidden, taken) : canonical;
    return { slot: slot as 0 | 1 | 2 | 3, variantId, item, seat: seated ? p.seat : null, seatMode: seated ? "SEATED" : "NO_SEAT" };
  }

  /**
   * Peta unik untuk satu siswa pada satu ronde (soal beda tiap siswa). Bentuknya dijamin tidak sama dengan peta siswa lain di ronde
   * ini (`taken`); bila generator gagal, soal acuan bank dipakai sebagai cadangan.
   */
  private uniqueItem(p: Player, roundId: number, level: number, canonical: MapDef, hidden: boolean, taken: Set<string>): MapDef {
    for (let attempt = 0; attempt < 6; attempt++) {
      const map = generateUniqueMap({ pool: this.settings.pool, roundId, level, seed: `${this.id}|${p.id}|${roundId}|${level}|${attempt}`, reference: canonical, hidden });
      if (!map) continue;
      const key = mapShapeKey(map);
      if (taken.has(key)) continue;
      taken.add(key);
      return map;
    }
    return canonical;
  }

  /** Peta untuk perangkat siswa: sudah diberi varian, tanpa kunci jawaban (tanpa probeEdgeId, biaya optimal, atau rute optimal). */
  private mapForPlayer(p: Player, rt: RoundRuntime): MapDef {
    const a = rt.assign.get(p.id) as Assignment;
    const shown = applyVariant(a.item, a.variantId, labelSeedFor(p.id, rt.config.roundId));
    const { probeEdgeId: _probe, ...clean } = shown;
    return clean;
  }

  private markSeen(p: Player): void {
    const rt = this.round;
    if (rt && !rt.finalized && (this.phase === "LOOK" || this.phase === "WALK" || (this.phase === "PROBE" && rt.walkEnded))) rt.seen.add(p.id);
  }

  /** Mengirim ulang keadaan sekarang ke perangkat yang baru tersambung. */
  /** Dipanggil socket setelah perangkat masuk ke ruangnya, agar peta/tutorial yang dikirim ulang tidak hilang. */
  resendState(studentId: string): void {
    const p = this.player(studentId);
    if (p) this.resend(p);
  }

  private resend(p: Player): void {
    if (this.phase === "TUTORIAL" && !p.tutorialDone) {
      const next = Math.min(5, (p.steps.at(-1)?.step ?? 0) + 1);
      this.deps.emitter.toPlayer(p.id, "tutorial:map", this.tutorialPayload(next, p.id));
      return;
    }
    const rt = this.round;
    if (!rt || rt.finalized) return;
    const a = rt.assign.get(p.id);
    if (!a) return;
    if (this.phase === "LOOK" || this.phase === "WALK") {
      const payload: RoundMapPayload = { map: this.mapForPlayer(p, rt), showWeights: !(rt.config.condition === "HIDDEN" && this.phase === "WALK") };
      this.deps.emitter.toPlayer(p.id, "round:map", payload);
    }
  }

  private startRound(index: number): void {
    const roundId = this.plan[index];
    if (roundId === undefined) return this.toPodium();
    // adaptif: waktu jalan mengikuti peta tersulit yang dibagikan ronde ini
    const config = this.adaptive(roundId)
      ? { ...effectiveRoundConfig(Math.max(1, ...this.claimed().map((p) => p.level)), this.settings), roundId, condition: effectiveRoundConfig(roundId, this.settings).condition }
      : effectiveRoundConfig(roundId, this.settings);
    const rt: RoundRuntime = {
      index,
      config,
      display: displayIndex(this.settings.mode, roundId),
      assign: new Map(),
      seen: new Set(),
      submissions: new Map(),
      progress: new Map(),
      probes: new Map(),
      probeAnswers: new Map(),
      focus: new Map(),
      roundFlags: new Map(),
      walkStartAt: null,
      walkEndAt: null,
      walkEnded: false,
      finalized: false,
      probeStartAt: null,
    };
    this.round = rt;
    if (roundId >= 1) this.seatsLocked = true;
    const taken = new Set<string>();
    for (const p of this.claimed()) {
      rt.assign.set(p.id, this.assignFor(p, roundId, config.condition === "HIDDEN", taken));
      if (p.connKey !== null) rt.seen.add(p.id);
    }
    this.enter("LOOK", config.lookMs, () => this.startWalk());
    for (const p of this.connected()) {
      const payload: RoundMapPayload = { map: this.mapForPlayer(p, rt), showWeights: true };
      this.deps.emitter.toPlayer(p.id, "round:map", payload);
    }
  }

  private startWalk(): void {
    const rt = this.round as RoundRuntime;
    rt.walkStartAt = this.now();
    rt.walkEndAt = rt.walkStartAt + rt.config.walkMs;
    this.enter("WALK", rt.config.walkMs, () => this.endWalk(true));
    if (rt.config.condition === "HIDDEN") this.deps.emitter.toPlayers("round:hideWeights", {});
    this.walkStatus();
    this.maybeEndWalk();
  }

  private pendingPlayers(rt: RoundRuntime): Player[] {
    return this.connected().filter((p) => rt.assign.has(p.id) && !rt.submissions.has(p.id));
  }

  private walkStatus(): void {
    const rt = this.round;
    if (!rt) return;
    const eligible = this.connected().filter((p) => rt.assign.has(p.id));
    this.deps.emitter.toHost("walk:status", { finished: eligible.filter((p) => rt.submissions.has(p.id)).length, total: eligible.length });
  }

  private maybeEndWalk(): void {
    const rt = this.round;
    if (this.phase !== "WALK" || !rt || rt.walkEnded) return;
    if (this.pendingPlayers(rt).length === 0) this.endWalk(false);
  }

  /** Berakhir saat semua pemain terhubung selesai (`byTimer` = false) atau waktu habis. */
  private endWalk(byTimer: boolean): void {
    const rt = this.round as RoundRuntime;
    this.clearTimer();
    rt.walkEnded = true;
    const proceed = (): void => (rt.config.condition === "HIDDEN" ? this.startProbe() : this.finalizeRound());
    if (byTimer && rt.config.condition === "VISIBLE" && this.pendingPlayers(rt).length > 0) {
      // jendela toleransi jaringan: hasil yang tiba ≤ GRACE_MS setelah waktu habis masih diterima
      this.timer = this.deps.clock.setTimer(proceed, GRACE_MS);
    } else proceed();
  }

  routeProgress(studentId: string, payload: { roundId: number; path: NodeId[]; tMs: number }): Ack {
    const rt = this.round;
    if (!this.player(studentId)) return fail("NOT_CLAIMED");
    if (!rt || this.phase !== "WALK" || payload.roundId !== rt.config.roundId || !Array.isArray(payload.path)) return fail("WRONG_PHASE");
    rt.progress.set(studentId, { path: payload.path, tMs: clamp(Number(payload.tMs) || 0, 0, rt.config.walkMs) });
    return ok({});
  }

  routeSubmit(studentId: string, payload: RouteSubmitPayload): Ack {
    const rt = this.round;
    const p = this.player(studentId);
    if (!p) return fail("NOT_CLAIMED");
    if (!rt || rt.finalized || payload.roundId !== rt.config.roundId) return fail("WRONG_PHASE");
    const inWalk = this.phase === "WALK";
    const inGrace = rt.walkEnded && rt.walkEndAt !== null && this.now() <= rt.walkEndAt + GRACE_MS;
    if (!inWalk && !inGrace) return fail("WRONG_PHASE");
    if (rt.submissions.has(studentId)) return fail("INVALID_PAYLOAD");
    if (!Array.isArray(payload.path) || !Array.isArray(payload.tapLog) || typeof payload.clientElapsedMs !== "number") return fail("INVALID_PAYLOAD");
    if (payload.clientElapsedMs > rt.config.walkMs || payload.clientElapsedMs < 0) return fail("INVALID_PAYLOAD");
    rt.submissions.set(studentId, {
      path: payload.path,
      tRouteMs: clamp(payload.clientElapsedMs, 0, rt.config.walkMs),
      tapLog: payload.tapLog,
      invalidTaps: Number(payload.invalidTaps) || 0,
      undo: Number(payload.undo) || 0,
    });
    this.walkStatus();
    this.maybeEndWalk();
    if (rt.walkEnded && this.phase === "WALK") {
      // pemain terakhir yang tertunda di jendela toleransi
      if (this.pendingPlayers(rt).length === 0 && this.timer) {
        this.clearTimer();
        this.finalizeRound();
      }
    }
    return ok({});
  }

  integrityEvent(studentId: string, e: IntegrityEventPayload): Ack {
    const rt = this.round;
    if (!this.player(studentId)) return fail("NOT_CLAIMED");
    if (!rt || (this.phase !== "LOOK" && this.phase !== "WALK")) return ok({});
    const f = rt.focus.get(studentId) ?? { focusLost: 0, fullscreenExits: 0 };
    const flags = rt.roundFlags.get(studentId) ?? new Set<IntegrityFlag>();
    if (e.type === "FOCUS_LOST") {
      f.focusLost++;
      flags.add("FOCUS_LOST");
    } else if (e.type === "FULLSCREEN_EXIT") {
      f.fullscreenExits++;
      flags.add("FULLSCREEN_EXIT");
    }
    rt.focus.set(studentId, f);
    rt.roundFlags.set(studentId, flags);
    return ok({});
  }

  // ------------------------------------------------------------------ probe

  private probeCorrectValue(rt: RoundRuntime, id: string): number | null {
    const item = (rt.assign.get(id) as Assignment).item;
    const edge = item.edges.find((e) => e.id === item.probeEdgeId);
    return edge ? edge.w : null;
  }

  private startProbe(): void {
    const rt = this.round as RoundRuntime;
    rt.probeStartAt = this.now();
    this.enter("PROBE", Math.round(this.settings.probeSeconds * 1000), () => this.finalizeRound());
    for (const p of this.connected()) {
      if (!rt.assign.has(p.id)) continue;
      const w = this.probeCorrectValue(rt, p.id);
      if (w === null) continue;
      rt.seen.add(p.id);
      const item = (rt.assign.get(p.id) as Assignment).item;
      const q: ProbeQuestion = { edgeId: item.probeEdgeId as string, options: probeOptions(w, `${p.id}${rt.config.roundId}P`) };
      this.deps.emitter.toPlayer(p.id, "probe:question", q);
    }
  }

  probeAnswer(studentId: string, payload: { roundId: number; value: number; clientElapsedMs: number }): Ack {
    const rt = this.round;
    if (!this.player(studentId)) return fail("NOT_CLAIMED");
    if (!rt || this.phase !== "PROBE" || payload.roundId !== rt.config.roundId) return fail("WRONG_PHASE");
    if (rt.probes.has(studentId)) return fail("INVALID_PAYLOAD");
    const limit = Math.round(this.settings.probeSeconds * 1000);
    rt.probes.set(studentId, { value: Number(payload.value), ms: clamp(Number(payload.clientElapsedMs) || 0, 0, limit) });
    this.maybeEndProbe();
    return ok({});
  }

  private maybeEndProbe(): void {
    const rt = this.round;
    if (this.phase !== "PROBE" || !rt) return;
    const asked = this.connected().filter((p) => rt.assign.has(p.id));
    if (asked.every((p) => rt.probes.has(p.id))) this.finalizeRound();
  }

  // ------------------------------------------------------------------ hasil ronde

  private buildResult(p: Player, rt: RoundRuntime): RoundResult | null {
    const a = rt.assign.get(p.id) as Assignment;
    const item = a.item;
    const sub = rt.submissions.get(p.id);
    const prog = rt.progress.get(p.id);
    const walkMs = rt.config.walkMs;
    const seen = rt.seen.has(p.id);

    // hasil progres yang sudah lengkap tetapi pengirimannya tidak sampai tetap dihitung
    const acceptedFromProgress = !sub && prog && isFinished(item, prog.path);
    const missed = !sub && !acceptedFromProgress && !seen;
    const timedOut = !sub && !acceptedFromProgress && seen;

    const path: NodeId[] = missed ? [] : sub ? sub.path : acceptedFromProgress && prog ? prog.path : (prog?.path ?? [item.start]);
    const tRouteMs = missed ? 0 : sub ? sub.tRouteMs : timedOut ? walkMs : (prog?.tMs ?? walkMs);
    const tapLog = sub ? sub.tapLog : [];
    const ev = evaluatePath(item, path, timedOut);
    const flagsOfRound = new Set<IntegrityFlag>([...p.flags, ...(rt.roundFlags.get(p.id) ?? [])]);
    const steps = ev.steps;
    if (!missed && !timedOut && steps >= 3 && tRouteMs / steps < 400) flagsOfRound.add("TOO_FAST");

    const probe = rt.probes.get(p.id);
    const correctW = rt.config.condition === "HIDDEN" ? this.probeCorrectValue(rt, p.id) : null;
    const probeAsked = rt.config.condition === "HIDDEN" && !missed && correctW !== null;
    const probeCorrect = probeAsked ? (probe ? probe.value === correctW : false) : null;
    const probeMs = probeAsked ? (probe ? probe.ms : Math.round(this.settings.probeSeconds * 1000)) : null;

    const scored = rt.config.scored;
    const race = missed ? 0 : racePoints({ optimalHit: ev.optimalHit, completed: ev.completed, er: ev.er, tSec: tRouteMs / 1000, limitSec: walkMs / 1000 });
    const probeP = missed ? 0 : probePoints(probeCorrect, (probeMs ?? 0) / 1000);
    const hits = [...p.hits, ...(scored ? [ev.optimalHit && !missed] : [])];
    const streak = scored && !missed ? (streakBonuses(hits).at(-1) ?? 0) : 0;
    const focus = rt.focus.get(p.id) ?? { focusLost: 0, fullscreenExits: 0 };

    return {
      sessionId: this.id,
      studentId: p.id,
      nickname: p.name,
      form: this.settings.pool,
      mode: this.settings.mode,
      roundId: rt.config.roundId,
      condition: rt.config.condition,
      variantId: a.variantId,
      itemId: item.id,
      itemSlot: a.slot,
      seatMode: a.seatMode,
      seatRow: a.seat ? a.seat.row : null,
      seatCol: a.seat ? a.seat.col : null,
      focusLost: focus.focusLost,
      fullscreenExits: focus.fullscreenExits,
      integrityFlags: [...flagsOfRound],
      nNodes: item.nodes.length,
      nEdges: item.edges.length,
      nStops: item.stops.length,
      timeLimitS: walkMs / 1000,
      optimalCost: optimalCost(item),
      playerCost: missed ? null : ev.playerCost,
      playerPath: path,
      completed: missed ? false : ev.completed,
      optimalHit: missed ? false : ev.optimalHit,
      timedOut,
      missed,
      er: missed ? 0 : ev.er,
      tFirstMs: firstValidTapMs(tapLog),
      tRouteMs,
      invalidTaps: tapLog.filter((t) => !t.valid).length,
      undo: tapLog.filter((t) => t.nodeId === "UNDO").length,
      revisits: ev.revisits,
      steps,
      probeCorrect,
      probeMs,
      racePoints: race,
      streakBonus: streak,
      probePoints: probeP,
      rankAfter: 0,
      errorType: missed ? "NONE" : ev.errorType,
      tapLog,
    };
  }

  private ranking(): { id: string; name: string; points: number; optimal: number }[] {
    return this.claimed()
      .map((p) => ({ id: p.id, name: p.name, points: p.totalPoints, optimal: p.optimalCount }))
      .sort((a, b) => b.points - a.points || b.optimal - a.optimal || a.name.localeCompare(b.name));
  }

  private finalizeRound(): void {
    const rt = this.round as RoundRuntime;
    if (rt.finalized) return;
    this.clearTimer();
    rt.finalized = true;
    const accepted: { p: Player; r: RoundResult }[] = [];
    for (const p of this.claimed()) {
      if (!rt.assign.has(p.id)) continue;
      const r = this.buildResult(p, rt);
      if (!r) continue;
      const canonical = (rt.assign.get(p.id) as Assignment).item;
      try {
        assertRoundIntegrity(r, canonical);
      } catch (e) {
        this.reject("round", p, e);
        if (rt.config.scored) p.hits.push(false);
        continue;
      }
      accepted.push({ p, r });
      if (this.adaptive(rt.config.roundId)) {
        p.level = nextLevel(p.level, { missed: r.missed, timedOut: r.timedOut, completed: r.completed, optimalHit: r.optimalHit, er: r.er, tRouteMs: r.tRouteMs, limitMs: rt.config.walkMs });
      }
      if (rt.config.scored) {
        p.hits.push(r.optimalHit);
        p.totalPoints += r.racePoints + r.streakBonus + r.probePoints;
        if (r.optimalHit) p.optimalCount++;
      }
    }
    const order = this.ranking();
    for (const { p, r } of accepted) {
      r.rankAfter = order.findIndex((o) => o.id === p.id) + 1;
      p.results.push(r);
      this.allResults.push(r);
      this.log("round", { result: r });
      const payload: RoundResultPayload = {
        racePoints: rt.config.scored ? r.racePoints : 0,
        streakBonus: r.streakBonus,
        probePoints: rt.config.scored ? r.probePoints : 0,
        totalPoints: p.totalPoints,
        optimal: r.optimalHit,
        rank: r.rankAfter,
        stars: r.missed || r.timedOut || !r.completed ? 0 : r.optimalHit ? 3 : r.er >= 0.8 ? 2 : 1,
        ...(this.settings.pool === "T" ? { level: p.level } : {}),
      };
      this.deps.emitter.toPlayer(p.id, "round:result", payload);
      const a = rt.assign.get(p.id) as Assignment;
      this.deps.emitter.toPlayer(p.id, "round:reveal", { optimalPath: optimalRoute(a.item), optimalCost: r.optimalCost });
    }
    const participants = accepted.filter((x) => !x.r.missed);
    // keempat soal setara ronde ini (ronde latihan: satu soal) selalu ditampilkan, walau kelas lebih kecil dari 4 siswa
    const pool = this.deps.bank.pools[this.settings.pool];
    const statsOf = (itemId: string): { solvers: number; tried: number; fastestMs: number | null } => {
      const mine = participants.filter((x) => x.r.itemId === itemId);
      const hit = mine.filter((x) => x.r.optimalHit);
      return { solvers: hit.length, tried: mine.length, fastestMs: hit.length ? Math.min(...hit.map((x) => x.r.tRouteMs)) : null };
    };
    const describe = (slot: number, map: MapDef): RoundSummaryItem => {
      const route = optimalRoute(map);
      return { slot, map, optimalPath: route, optimalCost: optimalCost(map), steps: route.length - 1, nodes: map.nodes.length, ...statsOf(map.id) };
    };
    // adaptif: tampilkan soal yang dipakai siswa (terbanyak dulu, maksimal 4); lainnya: keempat soal setara ronde ini
    const items: RoundSummaryItem[] = this.adaptive(rt.config.roundId) || (this.settings.uniqueMaps && rt.config.roundId >= 1)
      ? [...new Set(accepted.map((x) => x.r.itemId))]
          .map((id) => accepted.find((x) => x.r.itemId === id) as { p: Player; r: RoundResult })
          .map((x, i) => describe(i, (rt.assign.get(x.p.id) as Assignment).item))
          .sort((a, b) => b.tried - a.tried || b.nodes - a.nodes)
          .slice(0, 4)
          .map((it, i) => ({ ...it, slot: i }))
      : (rt.config.roundId === 0 ? [0] : [0, 1, 2, 3]).map((slot) => describe(slot, poolItem(pool, rt.config.roundId, slot)));
    // nama siswa yang menemukan rute terhemat, tercepat dulu (hanya untuk suara pengumuman di proyektor; tidak ditampilkan di layar)
    const correct = participants
      .filter((x) => x.r.optimalHit && rt.config.scored)
      .sort((x, y) => x.r.tRouteMs - y.r.tRouteMs)
      .map((x) => ({ name: x.p.name, absen: this.roster.find((r) => r.id === x.p.id)?.absen ?? null }));
    const wrong = participants.filter((x) => !x.r.optimalHit && rt.config.scored).length;
    this.deps.emitter.toHost("round:summary", {
      correct,
      wrong,
      items,
      pctOptimal: participants.length ? Math.round((participants.filter((x) => x.r.optimalHit).length / participants.length) * 100) : 0,
    });
    this.enter("RESULT", Math.round(this.settings.resultSeconds * 1000), () => (rt.config.scored ? this.showLeaderboard() : this.nextRound()));
  }

  private showLeaderboard(): void {
    const order = this.ranking();
    this.enter("LEADERBOARD", LEADERBOARD_MS, () => this.nextRound());
    const top5 = order.slice(0, 5).map((o) => ({ nickname: o.name, points: o.points }));
    this.deps.emitter.toHost("leaderboard", { top5 });
    for (const p of this.claimed()) {
      this.deps.emitter.toPlayer(p.id, "leaderboard", { top5, myRank: order.findIndex((o) => o.id === p.id) + 1, myPoints: p.totalPoints });
    }
  }

  private nextRound(): void {
    const rt = this.round as RoundRuntime;
    if (rt.index + 1 < this.plan.length) this.startRound(rt.index + 1);
    else this.toPodium();
  }

  private toPodium(): void {
    this.enter("PODIUM", null);
    this.log("podium", {});
    const top3 = this.ranking()
      .slice(0, 3)
      .map((o) => ({ nickname: o.name, points: o.points }));
    this.deps.emitter.toAll("podium", { top3 });
  }

  /** Guru menutup sesi (dari podium, atau menghentikan lebih awal). */
  end(): Ack {
    if (this.phase === "ENDED") return fail("WRONG_PHASE");
    this.clearTimer();
    this.phase = "ENDED";
    this.log("end", { results: this.allResults.length, rejected: this.rejectedCount });
    this.deps.emitter.toAll("phase", { phase: "ENDED", introMode: this.settings.introMode, totalRounds: this.plan.filter((id) => id > 0).length, durationMs: null } satisfies PhasePayload);
    return ok({});
  }
}

/**
 * Simulasi sesi TEST dengan bot untuk keempat jenis sesi (perdana/lanjutan × Standar/Kilat), dengan jam virtual
 * sehingga satu sesi penuh selesai dalam hitungan detik. Mengukur durasi sesi virtual dan membandingkannya dengan
 * anggaran S1–S4 (shared/src/budget.ts), memeriksa ekspor, dan keluar dengan kode 1 bila ada yang melampaui anggaran.
 *
 *   npm run simulate -- --players 30 [--silent 1] [--seed 2026] [--data data]
 *
 * Sesi dibuat dengan `kind: "TEST"` dan pemain bot (`isBot: true`); disimpan di <data>/test-sessions/. Hanya server
 * dengan `simulate: true` (atau NODE_ENV=test) yang mengenal event pembuat bot.
 */
import { mkdirSync } from "node:fs";
import { resolve } from "node:path";
import { io, type Socket } from "socket.io-client";
import {
  LOBBY_MS,
  PODIUM_MS,
  allRoutes,
  buildReport,
  mulberry32,
  optimalCost,
  optimalRoute,
  parseCsv,
  parseRoundsCsv,
  roundsCsv,
  sessionBudget,
  studentsCsv,
  summarizeStudent,
  type IntroMode,
  type MapDef,
  type NodeId,
  type RosterEntry,
  type SessionMode,
} from "@route-rush/shared";
import { ManualClock } from "./clock";
import { loadSessionData } from "./export";
import { createGameServer } from "./index";
import { JsonlStore } from "./store";

const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

type Strategy = "optimal" | "detour" | "silent";

interface Bot {
  id: string;
  strategy: Strategy;
  socket: Socket;
  map: MapDef | null;
  roundId: number;
  rnd: () => number;
}

function ask<T = Record<string, unknown>>(socket: Socket, event: string, payload?: unknown): Promise<T & { ok: boolean; error?: string }> {
  return new Promise((resolveAck, reject) => socket.timeout(5000).emit(event, payload, (err: Error | null, res: T & { ok: boolean; error?: string }) => (err ? reject(err) : resolveAck(res))));
}

/** Rute yang dikirim bot: optimal, rute selesai yang tidak optimal (memutar), atau tidak mengirim apa pun. */
function routeFor(bot: Bot): NodeId[] | null {
  const map = bot.map;
  if (!map || bot.strategy === "silent") return null;
  if (bot.strategy === "optimal") return optimalRoute(map);
  const opt = optimalCost(map);
  const others = allRoutes(map).filter((r) => r.cost > opt);
  return others.length > 0 ? (others[Math.floor(bot.rnd() * others.length)] as { path: NodeId[] }).path : optimalRoute(map);
}

function wire(bot: Bot): void {
  const s = bot.socket;
  s.on("round:map", (v: { map: MapDef; showWeights: boolean }) => {
    if (v.showWeights) bot.map = v.map;
  });
  s.on("phase", (p: { phase: string; roundId?: number }) => {
    if (p.roundId !== undefined) bot.roundId = p.roundId;
    if (p.phase !== "WALK") return;
    const path = routeFor(bot);
    if (!path) return;
    const gap = 700 + Math.floor(bot.rnd() * 900);
    s.emit("route:submit", {
      roundId: bot.roundId,
      path,
      clientElapsedMs: (path.length - 1) * gap,
      tapLog: path.slice(1).map((nodeId, i) => ({ tMs: (i + 1) * gap, nodeId, valid: true })),
      invalidTaps: bot.rnd() < 0.2 ? 1 : 0,
      undo: bot.rnd() < 0.1 ? 1 : 0,
      revisits: 0,
    });
  });
  s.on("tutorial:map", (v: { step: number }) => {
    s.emit("tutorial:step", { step: v.step, attempts: 1 + (bot.rnd() < 0.15 && v.step === 3 ? 1 : 0), hintsShown: 0, invalidTaps: 0, undo: 0, ms: 4000 + Math.floor(bot.rnd() * 6000) });
    if (v.step === 5) s.emit("tutorial:done", { totalMs: 30_000, autoDemoSteps: [], probeCorrect: bot.rnd() < 0.8 });
  });
  s.on("probe:question", (q: { edgeId: string; options: number[] }) => {
    const w = bot.map?.edges.find((e) => e.id === q.edgeId)?.w;
    const wrong = q.options.find((o) => o !== w) ?? q.options[0];
    s.emit("probe:answer", { roundId: bot.roundId, value: bot.rnd() < 0.7 ? w : wrong, clientElapsedMs: 800 + Math.floor(bot.rnd() * 3000) });
  });
}

export interface SimResult {
  mode: SessionMode;
  introMode: IntroMode;
  players: number;
  sessionId: string;
  /** Durasi virtual (ms): lobi 30 dtk (asumsi anggaran) + intro..podium + podium 20 dtk. */
  totalMs: number;
  budgetMs: number;
  results: number;
  exportsOk: boolean;
  problems: string[];
}

export async function simulateOne(opts: { mode: SessionMode; introMode: IntroMode; players: number; silent: number; seed: number; dataDir: string }): Promise<SimResult> {
  const clock = new ManualClock();
  const server = createGameServer({ dataDir: opts.dataDir, simulate: true, clock });
  const port = await server.listen();
  const url = `http://127.0.0.1:${port}`;
  const sockets: Socket[] = [];
  const connect = (): Socket => {
    const s = io(url, { transports: ["websocket"], forceNew: true, reconnection: false });
    sockets.push(s);
    return s;
  };
  const rnd = mulberry32(opts.seed ^ (opts.mode === "QUICK" ? 7 : 1) ^ (opts.introMode === "SHORT" ? 11 : 3));
  const problems: string[] = [];
  try {
    const roster: RosterEntry[] = Array.from({ length: opts.players }, (_, i) => ({ id: `siswa-${i + 1}`, name: `Simulasi ${i + 1}`, kelas: "SIM" }));
    const cols = 8;
    const host = connect();
    const created = await ask<{ sessionId: string; code: string; hostToken: string }>(host, "host:create", {
      roster,
      settings: { kind: "TEST", mode: opts.mode, introMode: opts.introMode, quota: opts.players, seatLayout: { rows: Math.ceil(opts.players / cols), cols, aisleAfterCols: [4], enabled: true } },
    });
    if (!created.ok) throw new Error(`host:create gagal: ${JSON.stringify(created)}`);
    const session = server.registry.get(created.sessionId);
    if (!session) throw new Error("sesi tidak ditemukan di registri");
    const t0 = clock.now();
    const phaseOf = (): string => session.phase;
    while (phaseOf() !== "LOBBY") if (!clock.runNext()) throw new Error("jam habis sebelum LOBBY");

    const bots: Bot[] = [];
    for (let i = 0; i < opts.players; i++) {
      const strategy: Strategy = i < opts.silent ? "silent" : rnd() < 0.7 ? "optimal" : "detour";
      const socket = connect();
      const bot: Bot = { id: `siswa-${i + 1}`, strategy, socket, map: null, roundId: -1, rnd: mulberry32(opts.seed + i) };
      wire(bot);
      const made = await ask<{ studentId: string; studentToken: string }>(socket, "test:addBot", { code: created.code, rosterId: bot.id });
      if (!made.ok) throw new Error(`test:addBot gagal: ${made.error}`);
      const joined = await ask(socket, "player:join", { code: created.code, studentToken: made.studentToken });
      if (!joined.ok) throw new Error(`bot gagal bergabung: ${joined.error}`);
      const seat = await ask(socket, "player:seat", { row: Math.floor(i / cols), col: i % cols });
      if (!seat.ok) throw new Error(`bot gagal memilih kursi: ${seat.error}`);
      bots.push(bot);
    }
    const started = await ask(host, "host:start", { sessionId: created.sessionId, hostToken: created.hostToken });
    if (!started.ok) throw new Error(`host:start gagal: ${JSON.stringify(started)}`);

    for (let guard = 0; guard < 5000 && phaseOf() !== "PODIUM"; guard++) {
      const phase = phaseOf();
      if (phase === "WALK" || phase === "PROBE" || phase === "TUTORIAL") {
        const until = Date.now() + 250;
        while (phaseOf() === phase && Date.now() < until) await sleep(2);
        if (phaseOf() !== phase) continue;
      } else await sleep(1);
      if (!clock.runNext()) throw new Error(`jam habis pada fase ${phaseOf()}`);
    }
    if (phaseOf() !== "PODIUM") throw new Error(`tidak mencapai PODIUM; fase ${phaseOf()}`);

    const elapsed = clock.now() - t0;
    const totalMs = LOBBY_MS + elapsed + PODIUM_MS;
    const budgetMs = sessionBudget(opts.mode, opts.introMode).totalMs;

    // ekspor: students.csv harus dapat dihitung ulang dari rounds.csv (T26) dan jumlah baris sesuai
    const store = new JsonlStore(opts.dataDir);
    const data = loadSessionData(store, created.sessionId);
    if (!data) throw new Error("data sesi tidak terbaca dari berkas");
    if (data.players.some((p) => !p.isBot)) problems.push("sesi TEST berisi pemain non-bot");
    const report = buildReport(data);
    const rows = parseCsv(studentsCsv(report));
    const head = rows[0] as string[];
    const again = parseRoundsCsv(roundsCsv(data));
    for (const row of rows.slice(1)) {
      const id = row[head.indexOf("student_id")] as string;
      const s = summarizeStudent(id, again.filter((r) => r.studentId === id));
      if (row[head.indexOf("total_points")] !== String(s.totalPoints)) problems.push(`T26: total_points ${id} berbeda`);
    }
    if (rows.length - 1 !== opts.players) problems.push(`students.csv berisi ${rows.length - 1} siswa, seharusnya ${opts.players}`);
    return { mode: opts.mode, introMode: opts.introMode, players: opts.players, sessionId: created.sessionId, totalMs, budgetMs, results: data.rounds.length, exportsOk: problems.length === 0, problems };
  } finally {
    for (const s of sockets) s.close();
    await server.close();
  }
}

async function main(): Promise<void> {
  const arg = (name: string, def: string): string => {
    const i = process.argv.indexOf(name);
    return i >= 0 ? (process.argv[i + 1] ?? def) : def;
  };
  const players = Number(arg("--players", "30"));
  const silent = Number(arg("--silent", "1"));
  const seed = Number(arg("--seed", "2026"));
  const dataDir = resolve(arg("--data", process.env["DATA_DIR"] ?? "data"));
  if (!Number.isInteger(players) || players < 1 || players > 80) throw new RangeError("--players harus bilangan bulat 1–80");
  mkdirSync(dataDir, { recursive: true });

  const kinds: { name: string; mode: SessionMode; introMode: IntroMode }[] = [
    { name: "S1 Perdana Standar", mode: "STANDARD", introMode: "FULL" },
    { name: "S2 Perdana Kilat", mode: "QUICK", introMode: "FULL" },
    { name: "S3 Lanjutan Standar", mode: "STANDARD", introMode: "SHORT" },
    { name: "S4 Lanjutan Kilat", mode: "QUICK", introMode: "SHORT" },
  ];
  const table: Record<string, string | number>[] = [];
  let failed = false;
  for (const k of kinds) {
    const r = await simulateOne({ mode: k.mode, introMode: k.introMode, players, silent, seed, dataDir });
    const over = r.totalMs > r.budgetMs;
    if (over || !r.exportsOk) failed = true;
    table.push({ jenis: k.name, pemain: r.players, "durasi (dtk)": +(r.totalMs / 1000).toFixed(1), "anggaran (dtk)": r.budgetMs / 1000, hasil: r.results, status: over ? "MELAMPAUI" : r.exportsOk ? "lulus" : `ekspor: ${r.problems.join("; ")}` });
  }
  console.table(table);
  console.log(`Sesi TEST tersimpan di ${resolve(dataDir, "test-sessions")}. Ekspor: /api/sessions/<id>/rounds.csv?includeTest=1`);
  process.exit(failed ? 1 : 0);
}

if (process.argv[1] && /simulate\.(ts|js)$/.test(process.argv[1])) void main();

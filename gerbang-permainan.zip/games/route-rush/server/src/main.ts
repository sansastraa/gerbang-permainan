import { readEnvConfig } from "./config";
import { createGameServer } from "./index";

const env = readEnvConfig(process.env);
for (const w of env.warnings) console.warn(`PERINGATAN: ${w}`);
const server = createGameServer({
  dataDir: env.dataDir,
  port: env.port,
  host: env.host,
  allowedOrigins: env.allowedOrigins,
  trustProxy: env.trustProxy,
  basePath: env.basePath,
  nodeEnv: env.nodeEnv,
  simulate: env.simulate,
});

void server.listen().then((p) => {
  // Pola "port N" dibaca oleh client/e2e/support.ts untuk mengetahui port bebas; jangan ubah susunannya.
  console.log(`Route Rush server berjalan di port ${p} (${env.host}, ${env.nodeEnv}${env.basePath ? `, awalan ${env.basePath}` : ""}); data di ${env.dataDir}`);
});

// Platform hosting mengirim SIGTERM saat menimpa versi: tutup koneksi dengan rapi (data JSONL ditulis per peristiwa, jadi tidak ada yang tertahan).
let closing = false;
for (const signal of ["SIGTERM", "SIGINT"] as const) {
  process.on(signal, () => {
    if (closing) return;
    closing = true;
    console.log(`${signal} diterima; menutup server.`);
    const force = setTimeout(() => process.exit(0), 8000);
    force.unref();
    void server.close().then(() => process.exit(0));
  });
}
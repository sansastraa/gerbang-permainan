import { randomBytes } from "node:crypto";
import { existsSync, readdirSync } from "node:fs";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { createServer, type Server as HttpServer } from "node:http";
import type { AddressInfo } from "node:net";
import express from "express";
import { Server } from "socket.io";
import { realClock, type Clock } from "./clock";
import { loadBank, type Bank } from "./data";
import type { EnvConfig } from "./config";
import { SessionRegistry } from "./registry";
import { mountExport } from "./export";
import { FailureGuard } from "./guard";
import { attachSocket, socketEmitter } from "./socket";
import { JsonlStore } from "./store";

export interface ServerConfig {
  dataDir: string;
  port?: number;
  /** Alamat yang didengarkan (bawaan: semua antarmuka). */
  host?: string;
  /** Asal yang boleh membuka Socket.IO dari halaman lain. Bawaan: semua (uji/pengembangan); "same-origin" = hanya halaman dari server ini. */
  allowedOrigins?: EnvConfig["allowedOrigins"];
  /** Pembatas percobaan token guru yang salah; tes dapat menyuntikkan pembatas dengan jam palsu. */
  guard?: FailureGuard;
  /** Awalan jalur untuk gerbang satu pintu (mis. "/games/route-rush"): semua halaman, API, klip, dan Socket.IO hidup di bawahnya. Bawaan: "" (dari akar). */
  basePath?: string;
  /** Berapa proxy di depan server (Express `trust proxy`). */
  trustProxy?: boolean | number;
  /** "test" mengaktifkan pembuat bot; "production" tidak pernah mendaftarkannya. */
  nodeEnv?: string;
  /** Simulasi (`npm run simulate`) juga boleh memakai bot. */
  simulate?: boolean;
  clock?: Clock;
  bank?: Bank;
  newPin?: () => string;
  /** Folder hasil build client (bawaan: client/dist bila ada); disajikan sebagai meja jawab siswa di "/". */
  staticDir?: string;
  /** Folder klip suara nama (bawaan: assets/audio/names); disajikan di /clips untuk diperdengarkan dari SIMPETERI. */
  clipsDir?: string;
}

export interface GameServer {
  httpServer: HttpServer;
  io: Server;
  registry: SessionRegistry;
  store: JsonlStore;
  allowBots: boolean;
  listen(): Promise<number>;
  close(): Promise<void>;
}

/** Merakit Express + Socket.IO. Server adalah sumber kebenaran fase dan waktu sesi. */
export function createGameServer(config: ServerConfig): GameServer {
  const app = express();
  const httpServer = createServer(app);
  app.disable("x-powered-by");
  if (config.trustProxy) app.set("trust proxy", config.trustProxy);
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Referrer-Policy", "no-referrer");
    next();
  });
  const origins = config.allowedOrigins ?? "any";
  const basePath = config.basePath ?? "";
  // semua rute aplikasi dipasang pada router ini, lalu router dipasang di awalan jalur (atau akar bila kosong)
  const router = express.Router();
  const io = new Server(httpServer, { path: `${basePath}/socket.io`, cors: { origin: origins === "any" ? true : origins === "same-origin" ? false : origins } });
  const store = new JsonlStore(config.dataDir);
  const allowBots = config.nodeEnv === "test" || config.simulate === true;

  const registry: SessionRegistry = new SessionRegistry({
    clock: config.clock ?? realClock,
    store,
    bank: config.bank ?? loadBank(),
    newToken: () => randomBytes(18).toString("base64url"),
    allowBots,
    makeEmitter: (id) =>
      socketEmitter(io, id, () => {
        const s = registry.get(id);
        return s ? s.playerList.map((p) => p.id) : [];
      }),
    ...(config.newPin ? { newPin: config.newPin } : {}),
  });

  // Tanpa data siswa: boleh dibaca dari asal mana pun agar SIMPETERI dapat memeriksa apakah server Route Rush menyala.
  const open = (res: express.Response): void => void res.setHeader("Access-Control-Allow-Origin", "*");
  const health = (_req: express.Request, res: express.Response): void => {
    open(res);
    res.json({ ok: true, game: "ROUTE_RUSH", sessions: registry.size, uptimeS: Math.round(process.uptime()), storageWritable: store.writable() });
  };
  router.get("/health", health);
  if (basePath) app.get("/health", health); // pemeriksa kesehatan platform tetap bisa memanggil /health dari akar

  // Klip suara nama (01.wav … NN.wav): bukan data siswa, boleh diperdengarkan dari halaman SIMPETERI untuk memeriksa urutan absen.
  const clipsDir = config.clipsDir ?? resolve(dirname(fileURLToPath(import.meta.url)), "../../assets/audio/names");
  router.get("/clips/index.json", (_req, res) => {
    open(res);
    const clips = existsSync(clipsDir) ? readdirSync(clipsDir).filter((f) => /^\d{2}\.wav$/.test(f)).sort() : [];
    res.json({ count: clips.length, clips });
  });
  router.get("/clips/:file", (req, res) => {
    open(res);
    const file = String(req.params["file"]);
    if (!/^\d{2}\.wav$/.test(file) || !existsSync(join(clipsDir, file))) return void res.status(404).json({ error: "NOT_FOUND" });
    res.sendFile(join(clipsDir, file));
  });
  // Ekspor hasil (/api/sessions/...) memuat data siswa: CORS hanya untuk ALLOWED_ORIGINS (SIMPETERI menarik laporan dari sini),
  // dengan header x-host-token yang diizinkan. Tanpa Origin (halaman sama asal atau alat server) tidak ada header CORS.
  router.use("/api/sessions", (req, res, next) => {
    const origin = req.headers.origin;
    if (origin && (origins === "any" || (Array.isArray(origins) && origins.includes(origin)))) {
      res.setHeader("Access-Control-Allow-Origin", origin);
      res.setHeader("Vary", "Origin");
      res.setHeader("Access-Control-Allow-Headers", "x-host-token");
      res.setHeader("Access-Control-Allow-Methods", "GET, OPTIONS");
      res.setHeader("Access-Control-Expose-Headers", "Content-Disposition");
      res.setHeader("Access-Control-Max-Age", "600");
    }
    if (req.method === "OPTIONS") return void res.sendStatus(204);
    next();
  });
  const guard = config.guard ?? new FailureGuard();
  mountExport(router, store, registry, guard);
  attachSocket(io, registry, { allowBots, guard });

  const staticDir = config.staticDir ?? resolve(dirname(fileURLToPath(import.meta.url)), "../../client/dist");
  if (existsSync(join(staticDir, "index.html"))) {
    // Berkas aset ber-hash di nama (assets/*) aman di-cache lama; halaman utama tidak boleh di-cache agar versi baru langsung terpakai.
    router.use(
      express.static(staticDir, {
        setHeaders: (res, path) => {
          if (/[\\/]assets[\\/]/.test(path)) res.setHeader("Cache-Control", "public, max-age=31536000, immutable");
          else res.setHeader("Cache-Control", "no-cache");
        },
      }),
    );
    router.get(/^\/(?!socket\.io|health|api\/|clips\/)[^.]*$/, (_req, res) => {
      res.setHeader("Cache-Control", "no-cache");
      res.sendFile(join(staticDir, "index.html"));
    });
  }

  app.use(basePath || "/", router);

  return {
    httpServer,
    io,
    registry,
    store,
    allowBots,
    listen: () =>
      new Promise((resolve) => {
        const done = (): void => resolve((httpServer.address() as AddressInfo).port);
        if (config.host) httpServer.listen(config.port ?? 0, config.host, done);
        else httpServer.listen(config.port ?? 0, done);
      }),
    close: () =>
      new Promise((resolve) => {
        void io.close(() => resolve());
      }),
  };
}

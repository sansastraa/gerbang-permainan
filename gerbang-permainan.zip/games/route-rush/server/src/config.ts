import { resolve } from "node:path";

/**
 * Pengaturan server dari variabel lingkungan (untuk hosting online: Fly, Render, Railway, VPS).
 *
 *  PORT             port HTTP (bawaan 3000; platform hosting biasanya mengisinya sendiri)
 *  HOST             alamat yang didengarkan (bawaan 0.0.0.0 agar terjangkau dari luar kontainer)
 *  DATA_DIR         folder data JSONL (bawaan ./data); di hosting WAJIB diarahkan ke disk persisten
 *  NODE_ENV         "production" mematikan bot dan melarang asal lain untuk Socket.IO kecuali didaftarkan
 *  ALLOWED_ORIGINS  daftar asal yang boleh membuka Socket.IO dari halaman lain, pisah koma ("*" = semua); kosong = hanya satu asal
 *  TRUST_PROXY      "1" (jumlah proxy di depan server) atau "true"; isi bila di belakang proxy hosting
 *  SIMULATE         "1" mengizinkan bot untuk `npm run simulate`
 *  BASE_PATH        awalan jalur untuk gerbang satu pintu, mis. "/games/route-rush" (kosong = dari akar). Klien harus dibangun dengan BASE_PATH yang sama.
 */
export interface EnvConfig {
  port: number;
  host: string;
  dataDir: string;
  nodeEnv: string;
  simulate: boolean;
  /** "any" = semua asal; array = daftar asal; "same-origin" = tidak ada asal lain. */
  allowedOrigins: "any" | "same-origin" | string[];
  trustProxy: boolean | number;
  /** Awalan jalur ("" atau mis. "/games/route-rush"): diawali /, tanpa / di akhir. */
  basePath: string;
  warnings: string[];
}

type Env = Readonly<Record<string, string | undefined>>;

/**
 * Menormalkan awalan jalur: "games/route-rush/" → "/games/route-rush"; kosong atau "/" → "". Null bila memuat karakter di luar
 * huruf, angka, "-", "_", ".", "/" atau segmen "." / ".." (agar tidak bisa dipakai membelokkan jalur).
 */
export function normalizeBasePath(input: string | undefined): string | null {
  const t = (input ?? "").trim().replace(/\/+$/, "");
  if (t === "") return "";
  const withSlash = t.startsWith("/") ? t : `/${t}`;
  if (!/^[A-Za-z0-9._\-/]+$/.test(withSlash) || /\/{2,}/.test(withSlash)) return null;
  if (withSlash.split("/").some((seg) => seg === "." || seg === "..")) return null;
  return withSlash;
}

/** Menormalkan satu asal ("https://contoh.id/" → "https://contoh.id"); null bila bukan alamat http(s) yang sah. */
export function normalizeOrigin(input: string): string | null {
  try {
    const u = new URL(input.trim());
    if (u.protocol !== "http:" && u.protocol !== "https:") return null;
    return u.origin;
  } catch {
    return null;
  }
}

export function readEnvConfig(env: Env, cwd = process.cwd()): EnvConfig {
  const warnings: string[] = [];
  const nodeEnv = env["NODE_ENV"] ?? "development";
  const production = nodeEnv === "production";

  let port = 3000;
  const rawPort = env["PORT"];
  if (rawPort !== undefined && rawPort !== "") {
    const n = Number(rawPort);
    if (Number.isInteger(n) && n >= 0 && n <= 65535) port = n;
    else warnings.push(`PORT "${rawPort}" tidak sah; memakai 3000.`);
  }

  let allowedOrigins: EnvConfig["allowedOrigins"] = production ? "same-origin" : "any";
  const rawOrigins = env["ALLOWED_ORIGINS"]?.trim();
  if (rawOrigins) {
    if (rawOrigins === "*") allowedOrigins = "any";
    else {
      const list: string[] = [];
      for (const part of rawOrigins.split(",").filter((p) => p.trim() !== "")) {
        const o = normalizeOrigin(part);
        if (o) list.push(o);
        else warnings.push(`ALLOWED_ORIGINS: "${part.trim()}" bukan alamat http(s) yang sah dan dilewati.`);
      }
      allowedOrigins = list.length > 0 ? [...new Set(list)] : production ? "same-origin" : "any";
    }
  }
  if (production && allowedOrigins === "any") warnings.push("ALLOWED_ORIGINS=* di produksi: halaman mana pun boleh membuka Socket.IO ke server ini.");

  let trustProxy: boolean | number = false;
  const rawProxy = env["TRUST_PROXY"]?.trim().toLowerCase();
  if (rawProxy === "true") trustProxy = true;
  else if (rawProxy && /^\d+$/.test(rawProxy)) trustProxy = Number(rawProxy);
  else if (rawProxy && rawProxy !== "false" && rawProxy !== "0") warnings.push(`TRUST_PROXY "${rawProxy}" tidak dikenal; diabaikan.`);

  const basePath = normalizeBasePath(env["BASE_PATH"]);
  if (basePath === null) warnings.push(`BASE_PATH "${env["BASE_PATH"]}" tidak sah (hanya huruf, angka, - _ . /); diabaikan.`);

  if (production && !env["DATA_DIR"]) warnings.push("DATA_DIR belum diatur di produksi: data ditulis ke ./data yang hilang bila kontainer diganti. Arahkan ke disk persisten.");
  if (production && env["SIMULATE"] === "1") warnings.push("SIMULATE=1 diabaikan di produksi.");

  return {
    port,
    host: env["HOST"]?.trim() || "0.0.0.0",
    dataDir: resolve(cwd, env["DATA_DIR"] ?? "data"),
    nodeEnv,
    simulate: !production && env["SIMULATE"] === "1",
    allowedOrigins,
    trustProxy,
    basePath: basePath ?? "",
    warnings,
  };
}

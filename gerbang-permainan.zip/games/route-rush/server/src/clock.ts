export interface TimerHandle {
  readonly id: number;
}

/** Sumber waktu dan pewaktu; dapat diganti agar sesi bisa diuji tanpa menunggu waktu nyata. */
export interface Clock {
  now(): number;
  setTimer(fn: () => void, ms: number): TimerHandle;
  clearTimer(handle: TimerHandle): void;
}

let nextId = 1;

export const realClock: Clock = {
  now: () => Date.now(),
  setTimer(fn, ms) {
    const id = nextId++;
    const t = setTimeout(fn, ms);
    realTimers.set(id, t);
    return { id };
  },
  clearTimer(handle) {
    const t = realTimers.get(handle.id);
    if (t) clearTimeout(t);
    realTimers.delete(handle.id);
  },
};

const realTimers = new Map<number, ReturnType<typeof setTimeout>>();

interface Pending {
  id: number;
  at: number;
  fn: () => void;
}

/** Jam terkendali: waktu hanya maju bila diminta; dipakai test dan simulasi. */
export class ManualClock implements Clock {
  private t: number;
  private pending: Pending[] = [];
  private seq = 1;

  constructor(start = 1_000_000) {
    this.t = start;
  }

  now(): number {
    return this.t;
  }

  setTimer(fn: () => void, ms: number): TimerHandle {
    const id = this.seq++;
    this.pending.push({ id, at: this.t + ms, fn });
    return { id };
  }

  clearTimer(handle: TimerHandle): void {
    this.pending = this.pending.filter((p) => p.id !== handle.id);
  }

  /** Selang ke pewaktu berikutnya (ms) atau null bila tidak ada. */
  nextDueIn(): number | null {
    if (this.pending.length === 0) return null;
    return Math.max(0, Math.min(...this.pending.map((p) => p.at)) - this.t);
  }

  /** Memajukan waktu ke pewaktu terdekat dan menjalankannya; false bila tidak ada pewaktu. */
  runNext(): boolean {
    if (this.pending.length === 0) return false;
    const next = this.pending.reduce((a, b) => (b.at < a.at || (b.at === a.at && b.id < a.id) ? b : a));
    this.pending = this.pending.filter((p) => p.id !== next.id);
    this.t = Math.max(this.t, next.at);
    next.fn();
    return true;
  }

  advance(ms: number): void {
    const target = this.t + ms;
    for (;;) {
      const due = this.pending.filter((p) => p.at <= target);
      if (due.length === 0) break;
      this.runNext();
    }
    this.t = target;
  }

  get pendingCount(): number {
    return this.pending.length;
  }
}

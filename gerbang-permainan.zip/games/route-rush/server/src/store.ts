import { accessSync, appendFileSync, constants, existsSync, mkdirSync, readFileSync } from "node:fs";
import { join } from "node:path";

export type SessionKind = "LIVE" | "TEST";

export interface StoredEvent {
  type: string;
  game: "ROUTE_RUSH";
  sessionId: string;
  at: number;
  [key: string]: unknown;
}

/**
 * Penyimpanan JSONL: sesi LIVE di `sessions/`, sesi TEST di `test-sessions/`, hasil gagal integritas di `rejected/`.
 * Tiap peristiwa ditambahkan segera (append) agar sesi tahan crash dan bisa dipulihkan dari berkas.
 */
export class JsonlStore {
  constructor(private readonly baseDir: string) {}

  private dir(sub: string): string {
    const d = join(this.baseDir, sub);
    mkdirSync(d, { recursive: true });
    return d;
  }

  /** Apakah folder data bisa ditulis (untuk /health); membuat folder dasar bila belum ada, tanpa menulis data. */
  writable(): boolean {
    try {
      mkdirSync(this.baseDir, { recursive: true });
      accessSync(this.baseDir, constants.W_OK);
      return true;
    } catch {
      return false;
    }
  }

  /** Lokasi berkas; tidak membuat folder (membaca tidak boleh mengubah isi data). */
  pathFor(kind: SessionKind, sessionId: string): string {
    return join(this.baseDir, kind === "LIVE" ? "sessions" : "test-sessions", `${sessionId}.jsonl`);
  }

  rejectedPath(sessionId: string): string {
    return join(this.baseDir, "rejected", `${sessionId}.jsonl`);
  }

  append(kind: SessionKind, event: StoredEvent): void {
    this.dir(kind === "LIVE" ? "sessions" : "test-sessions");
    appendFileSync(this.pathFor(kind, event.sessionId), JSON.stringify(event) + "\n", "utf8");
  }

  reject(event: StoredEvent): void {
    this.dir("rejected");
    appendFileSync(this.rejectedPath(event.sessionId), JSON.stringify(event) + "\n", "utf8");
  }

  read(kind: SessionKind, sessionId: string): StoredEvent[] {
    return this.readFile(this.pathFor(kind, sessionId));
  }

  readRejected(sessionId: string): StoredEvent[] {
    return this.readFile(this.rejectedPath(sessionId));
  }

  private readFile(path: string): StoredEvent[] {
    if (!existsSync(path)) return [];
    return readFileSync(path, "utf8")
      .split("\n")
      .filter((l) => l.trim().length > 0)
      .map((l) => JSON.parse(l) as StoredEvent);
  }
}

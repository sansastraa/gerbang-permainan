import { spawn } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { defaultSettings } from "@route-rush/shared";
import { runFieldCheck } from "../src/fieldCheck";
import { loadSessionData } from "../src/export";
import { JsonlStore } from "../src/store";
import { addBots, ask, createSession, driveToPodium, startNet, toLobby, type NetRig, type SessionHandle } from "./netHarness";

let net: NetRig;
let h: SessionHandle;

beforeAll(async () => {
  net = await startNet();
  h = await createSession(net, 3, { introMode: "SHORT", roundIds: [1, 2] });
  toLobby(net, h);
  await addBots(net, h, ["optimal", "optimal", "silent"]);
  await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken });
  await driveToPodium(net, h);
}, 120_000);
afterAll(async () => {
  await net.stop();
});

function writeLive(id: string): void {
  mkdirSync(join(net.dataDir, "sessions"), { recursive: true });
  const ev = (at: number, o: Record<string, unknown>) => JSON.stringify({ game: "ROUTE_RUSH", sessionId: id, at, ...o });
  const round = (sid: string, hit: boolean) => ({
    sessionId: id, studentId: sid, nickname: sid, form: "A", mode: "STANDARD", roundId: 1, condition: "VISIBLE", variantId: 1, itemId: "PA-01-0", itemSlot: 0, seatMode: "SEATED", seatRow: 0, seatCol: 0,
    focusLost: 0, fullscreenExits: 0, integrityFlags: [], nNodes: 5, nEdges: 6, nStops: 0, timeLimitS: 20, optimalCost: 5, playerCost: hit ? 5 : 7, playerPath: ["n0"], completed: true, optimalHit: hit,
    timedOut: false, missed: false, er: hit ? 1 : 0.7, tFirstMs: 500, tRouteMs: 5000, invalidTaps: 0, undo: 0, revisits: 0, steps: 3, probeCorrect: null, probeMs: null, racePoints: 1, streakBonus: 0, probePoints: 0, rankAfter: 1, errorType: hit ? "NONE" : "DETOUR", tapLog: [],
  });
  const lines = [
    ev(1_760_000_000_000, { type: "session", kind: "LIVE", settings: { ...defaultSettings(3), roundIds: [1], introMode: "SHORT" } }),
    ...["a", "b", "c"].map((s) => ev(1_760_000_001_000, { type: "player", studentId: s, name: s, isBot: false })),
    ev(1_760_000_100_000, { type: "start", players: 3 }),
    ...["a", "b", "c"].map((s, i) => ev(1_760_000_120_000, { type: "round", result: round(s, i < 2) })),
    ev(1_760_000_130_000, { type: "podium" }),
    ev(1_760_000_170_000, { type: "end", results: 3, rejected: 0 }),
  ];
  writeFileSync(join(net.dataDir, "sessions", `${id}.jsonl`), lines.join("\n") + "\n");
}

describe("npm run field-check", () => {
  it("sesi nyata mencatat penanda Mulai dan podium (untuk pemeriksaan durasi)", () => {
    const d = loadSessionData(new JsonlStore(net.dataDir), h.id)!;
    expect(d.startedAt).not.toBeNull();
    expect(d.podiumAt).not.toBeNull();
    expect((d.podiumAt as number) - (d.startedAt as number)).toBeGreaterThan(0);
    expect(d.settings?.introMode).toBe("SHORT");
  });

  it("sesi TEST ditolak tanpa --include-test; dengan itu laporan bertanda data TEST/bot dan memuat 10 pemeriksaan", () => {
    expect(() => runFieldCheck(net.dataDir, h.id)).toThrow(/TEST/);
    const { fc, markdown } = runFieldCheck(net.dataDir, h.id, true);
    expect(fc.checks).toHaveLength(10);
    expect(markdown).toContain("data TEST/bot");
    expect(fc.checks.find((c) => c.id === "C7")?.status).not.toBe("DATA KURANG"); // Mulai dan podium tercatat
    expect(fc.checks.find((c) => c.id === "C2")?.status).toBe("TIDAK BERLAKU"); // intro ringkas
  });

  it("id tidak sah dan sesi tidak ada → galat yang jelas", () => {
    expect(() => runFieldCheck(net.dataDir, "../x")).toThrow(/tidak sah/);
    expect(() => runFieldCheck(net.dataDir, "tidak-ada")).toThrow(/tidak ditemukan/);
  });

  it("sesi LIVE kecil: diproses; data statistik kurang bukan kegagalan; hasil ditolak terhitung dari data/rejected", () => {
    writeLive("live-fc");
    const r1 = runFieldCheck(net.dataDir, "live-fc");
    expect(r1.fc.kind).toBe("LIVE");
    expect(r1.fc.joined).toBe(3);
    expect(r1.fc.checks.find((c) => c.id === "C1")?.status).toBe("LULUS");
    expect(r1.fc.checks.find((c) => c.id === "C7")?.value).toBe("30 dtk dari batas 34 dtk"); // Mulai → podium 30 dtk; batas = 3 + 1 ronde maksimal 31 dtk
    expect(r1.fc.checks.find((c) => c.id === "C7")?.status).toBe("LULUS");
    expect(r1.fc.verdict).toBe("BELUM LENGKAP");
    mkdirSync(join(net.dataDir, "rejected"), { recursive: true });
    writeFileSync(join(net.dataDir, "rejected", "live-fc.jsonl"), JSON.stringify({ type: "reject" }) + "\n");
    const r2 = runFieldCheck(net.dataDir, "live-fc");
    expect(r2.fc.checks.find((c) => c.id === "C4")?.status).toBe("GAGAL");
    expect(r2.fc.verdict).toBe("TIDAK LULUS");
  });

  it("CLI menulis docs/field-check-<id>.md ke folder keluaran dan kode keluar sesuai hasil", async () => {
    writeLive("live-cli");
    const out = mkdtempSync(join(tmpdir(), "rr-fc-"));
    const run = (args: string[]) =>
      new Promise<{ code: number | null; stdout: string; stderr: string }>((done) => {
        const c = spawn(process.execPath, [resolve(process.cwd(), "../node_modules/tsx/dist/cli.mjs"), resolve(process.cwd(), "src/fieldCheck.ts"), ...args], { cwd: resolve(process.cwd(), "..") });
        let stdout = "";
        let stderr = "";
        c.stdout.on("data", (d: Buffer) => (stdout += d.toString()));
        c.stderr.on("data", (d: Buffer) => (stderr += d.toString()));
        c.on("close", (code) => done({ code, stdout, stderr }));
      });
    const ok = await run(["--session", "live-cli", "--data", net.dataDir, "--out", out]);
    expect(ok.code).toBe(0);
    expect(ok.stdout).toContain("Hasil: BELUM LENGKAP");
    const file = join(out, "field-check-live-cli.md");
    expect(existsSync(file)).toBe(true);
    expect(readFileSync(file, "utf8")).toContain("# Pemeriksaan lapangan — sesi live-cli");
    expect((await run([])).code).toBe(2);
    expect((await run(["--session", h.id, "--data", net.dataDir, "--out", out])).code).toBe(2); // TEST ditolak
  }, 120_000);
});
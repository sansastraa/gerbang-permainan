import { readFileSync } from "node:fs";
import { describe, expect, it } from "vitest";
import { COUNTDOWN_MS, INTRO_MS, TUTORIAL_MS, getRoundConfig, type MapDef } from "@route-rush/shared";
import { Recorder, joinAll, makeRig, mapOf, optimalSubmit, playRound, roster, runUntil } from "./harness";

const FORBIDDEN_KEYS = ["optimalCost", "optimalPath", "optimalRoute", "probeEdgeId", "correct", "golden", "secondBestGap"];
const hasKey = (value: unknown, keys: readonly string[]): boolean => JSON.stringify(value).split('"').some((s, i) => i % 2 === 1 && keys.includes(s));

describe("alur: intro → PIN → pilih nama → menunggu → mulai", () => {
  it("PIN baru bisa dipakai setelah intro; urutan fase FULL", () => {
    const rig = makeRig();
    rig.session.begin();
    expect(rig.session.phase).toBe("INTRO_IDENT");
    expect(rig.session.lookup()).toMatchObject({ ok: false, error: "NOT_OPEN" });
    expect(rig.session.claim("siswa-1", "c1")).toMatchObject({ ok: false, error: "NOT_OPEN" });
    expect(rig.clock.nextDueIn()).toBe(INTRO_MS.FULL.ident);
    rig.clock.runNext();
    expect(rig.session.phase).toBe("INTRO_TRAILER");
    expect(rig.clock.nextDueIn()).toBe(INTRO_MS.FULL.trailer);
    rig.clock.runNext();
    expect(rig.session.phase).toBe("LOBBY");
    expect(rig.clock.nextDueIn()).toBeNull(); // lobi menunggu guru, tanpa batas waktu
    expect(rig.session.lookup()).toMatchObject({ ok: true });
  });

  it("intro ringkas dan lewati intro oleh guru", () => {
    const rig = makeRig({ settings: { introMode: "SHORT" } });
    rig.session.begin();
    expect(rig.clock.nextDueIn()).toBe(INTRO_MS.SHORT.ident);
    expect(rig.session.skipIntro()).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("LOBBY");
    expect(rig.session.skipIntro()).toMatchObject({ ok: false, error: "WRONG_PHASE" });
  });

  it("siswa memilih nama dari daftar SIMPETERI: nama tidak dikenal, sudah dipakai, dan satu perangkat satu nama", () => {
    const rig = makeRig({ n: 3 });
    rig.session.begin();
    rig.session.skipIntro();
    expect(rig.session.claim("tidak-ada", "c1")).toMatchObject({ ok: false, error: "NAME_UNKNOWN" });
    const a = rig.session.claim("siswa-1", "c1");
    expect(a).toMatchObject({ ok: true, studentId: "siswa-1" });
    expect(rig.session.claim("siswa-1", "c2")).toMatchObject({ ok: false, error: "NAME_TAKEN" });
    expect(rig.session.claim("siswa-2", "c1")).toMatchObject({ ok: false, error: "ALREADY_CLAIMED" });
    const view = rig.session.lookup();
    expect(view.ok && view.roster.filter((r) => r.taken).map((r) => r.id)).toEqual(["siswa-1"]);
    expect(rig.session.releaseName("siswa-1")).toMatchObject({ ok: true });
    expect(rig.session.claim("siswa-1", "c2")).toMatchObject({ ok: true });
  });

  it("permainan baru boleh dimulai bila kuota terpenuhi (dan semua sudah memilih kursi)", () => {
    const rig = makeRig({ n: 3 });
    rig.session.begin();
    rig.session.skipIntro();
    expect(rig.session.start()).toMatchObject({ ok: false, error: "QUOTA_NOT_MET", detail: { joined: 0, quota: 3 } });
    for (const id of rig.ids.slice(0, 2)) rig.session.claim(id, `c-${id}`);
    expect(rig.session.start()).toMatchObject({ ok: false, error: "QUOTA_NOT_MET", detail: { joined: 2, quota: 3 } });
    rig.session.claim("siswa-3", "c-siswa-3");
    expect(rig.session.start()).toMatchObject({ ok: false, error: "SEATS_PENDING" });
    expect(rig.session.lobbyView()).toMatchObject({ joined: 3, quota: 3, seatsPending: 3, canStart: false });
    rig.ids.forEach((id, i) => rig.session.seat(id, 0, i));
    expect(rig.session.lobbyView().canStart).toBe(true);
    expect(rig.session.start()).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("COUNTDOWN");
    expect(rig.clock.nextDueIn()).toBe(COUNTDOWN_MS);
  });

  it("siswa yang terputus tidak dihitung dalam kuota; guru dapat menurunkan kuota lewat pengaturan", () => {
    const rig = makeRig({ n: 3, settings: { seatLayout: { rows: 3, cols: 4, aisleAfterCols: [], enabled: false } } });
    joinAll(rig);
    rig.session.detach("conn-siswa-3");
    expect(rig.session.start()).toMatchObject({ ok: false, error: "QUOTA_NOT_MET" });
    expect(rig.session.updateSettings({ quota: 2 })).toMatchObject({ ok: true });
    expect(rig.session.start()).toMatchObject({ ok: true });
  });

  it("tanpa denah kursi (enabled=false) kuota saja yang menentukan", () => {
    const rig = makeRig({ n: 2, settings: { seatLayout: { rows: 3, cols: 4, aisleAfterCols: [], enabled: false } } });
    joinAll(rig);
    expect(rig.session.seat("siswa-1", 0, 0)).toMatchObject({ ok: false, error: "SEATS_DISABLED" });
    expect(rig.session.start()).toMatchObject({ ok: true });
  });
});

describe("menu pengaturan guru", () => {
  it("waktu menghafal, waktu jalan, waktu probe, ronde khusus, dan kuota berlaku pada fase", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT", mode: "QUICK" } });
    joinAll(rig);
    const r = rig.session.updateSettings({ lookSeconds: 12, walkSeconds: 40, probeSeconds: 4, roundIds: [1, 2], quota: 2 });
    expect(r).toMatchObject({ ok: true });
    expect(rig.session.start()).toMatchObject({ ok: true });
    runUntil(rig, "LOOK");
    expect(rig.rec.last("phase")!.payload).toMatchObject({ phase: "LOOK", roundId: 1, durationMs: 12_000 });
    runUntil(rig, "WALK");
    expect(rig.rec.last("phase")!.payload).toMatchObject({ phase: "WALK", durationMs: 40_000 });
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 1));
    runUntil(rig, "RESULT");
    runUntil(rig, "LOOK");
    runUntil(rig, "WALK");
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 2));
    expect(rig.session.phase).toBe("PROBE");
    expect(rig.rec.last("phase")!.payload).toMatchObject({ phase: "PROBE", durationMs: 4000 });
    expect(rig.rec.events("phase").some((l) => (l.payload as { roundId?: number }).roundId === 0)).toBe(false);
  });

  it("pengaturan di luar batas ditolak dan tidak mengubah apa pun; hanya boleh di LOBBY", () => {
    const rig = makeRig();
    rig.session.begin();
    expect(rig.session.updateSettings({ lookSeconds: 10 })).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    rig.session.skipIntro();
    for (const bad of [{ lookSeconds: 1 }, { lookSeconds: 61 }, { walkSeconds: 5 }, { probeSeconds: 181 }, { quota: 99 }, { quota: 0 }, { roundIds: [] }, { roundIds: [1, 1] }, { mode: "X" }, { seatLayout: { rows: 99 } }, "bukan objek"]) {
      expect(rig.session.updateSettings(bad)).toMatchObject({ ok: false, error: "INVALID_SETTINGS" });
    }
    expect(rig.session.settings.lookSeconds).toBeNull();
    expect(rig.session.updateSettings({ lookSeconds: null, quota: 2 })).toMatchObject({ ok: true });
  });

  it("mengubah denah mengosongkan kursi yang keluar batas", () => {
    const rig = makeRig({ n: 2 });
    joinAll(rig);
    rig.session.seat("siswa-2", 2, 3);
    rig.session.updateSettings({ seatLayout: { rows: 2, cols: 4 } });
    expect(rig.session.lobbyView().players.find((p) => p.id === "siswa-2")!.seat).toBeNull();
    expect(rig.session.lobbyView().players.find((p) => p.id === "siswa-1")!.seat).toEqual({ row: 0, col: 0 });
  });
});

describe("sesi FULL dan SHORT", () => {
  it("FULL: tutorial dulu, ronde 0 tidak dimainkan, dan tutorial berakhir lebih awal bila semua selesai", () => {
    const rig = makeRig({ n: 3, settings: { mode: "QUICK" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "TUTORIAL");
    expect(rig.rec.events("tutorial:map").length).toBe(3);
    const before = rig.clock.now();
    for (const id of rig.ids) {
      for (let step = 1; step <= 5; step++) rig.session.tutorialStep(id, { step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 5000 });
      expect(rig.session.tutorialDone(id, { totalMs: 25_000, autoDemoSteps: [], probeCorrect: true })).toMatchObject({ ok: true });
    }
    expect(rig.session.phase).toBe("LOOK"); // berakhir lebih awal, tanpa menunggu 90 detik
    expect(rig.clock.now() - before).toBeLessThan(TUTORIAL_MS);
    expect(rig.rec.last("phase")!.payload).toMatchObject({ roundId: 1, displayIndex: 1 });
    expect(rig.session.tutorialResults).toHaveLength(3);
    expect(rig.session.tutorialResults.every((t) => t.result.completed && t.isBot === false)).toBe(true);
  });

  it("FULL: siswa yang belum selesai saat 90 detik dicatat memakai demo otomatis dan tidak completed", () => {
    const rig = makeRig({ n: 2, settings: { mode: "QUICK" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "TUTORIAL");
    for (let step = 1; step <= 5; step++) rig.session.tutorialStep("siswa-1", { step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 4000 });
    rig.session.tutorialDone("siswa-1", { totalMs: 20_000, autoDemoSteps: [] });
    rig.session.tutorialStep("siswa-2", { step: 1, attempts: 2, hintsShown: 1, invalidTaps: 1, undo: 0, ms: 6000 });
    expect(rig.clock.nextDueIn()).toBe(TUTORIAL_MS);
    rig.clock.runNext();
    expect(rig.session.phase).toBe("LOOK");
    const t2 = rig.session.tutorialResults.find((t) => t.result.studentId === "siswa-2")!.result;
    expect(t2.completed).toBe(false);
    expect(t2.autoDemoSteps).toEqual([2, 3, 4, 5]);
    expect(t2.hints).toBe(1);
    expect(rig.session.rejected).toBe(0);
  });

  it("tahapan tutorial: peta tutorial tanpa kunci, langkah tidak valid ditolak, di luar fase ditolak", () => {
    const rig = makeRig({ n: 1 });
    joinAll(rig);
    expect(rig.session.tutorialStep("siswa-1", { step: 1, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 1 })).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    rig.session.start();
    runUntil(rig, "TUTORIAL");
    expect(rig.session.tutorialStep("siswa-1", { step: 9, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 1 })).toMatchObject({ ok: false, error: "INVALID_PAYLOAD" });
    expect(rig.session.tutorialDone("siswa-1", { totalMs: "x" as unknown as number, autoDemoSteps: [] })).toMatchObject({ ok: false, error: "INVALID_PAYLOAD" });
    expect(rig.session.tutorialStep("tidak-ada", { step: 1, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 1 })).toMatchObject({ ok: false, error: "NOT_CLAIMED" });
    for (const l of rig.rec.events("tutorial:map")) expect(hasKey(l.payload, FORBIDDEN_KEYS)).toBe(false);
    rig.session.tutorialStep("siswa-1", { step: 1, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 1000 });
    expect((rig.rec.last("tutorial:map", "siswa-1")!.payload as { step: number }).step).toBe(2);
  });

  it("SHORT: ronde latihan 0 dimainkan tanpa poin dan tanpa papan peringkat", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    expect(rig.rec.last("phase")!.payload).toMatchObject({ roundId: 0, displayIndex: 0 });
    playRound(rig);
    expect(rig.session.phase).toBe("RESULT");
    expect(rig.rec.events("leaderboard")).toHaveLength(0);
    runUntil(rig, "LOOK"); // langsung ke ronde berikutnya tanpa LEADERBOARD
    expect(rig.rec.last("phase")!.payload).toMatchObject({ roundId: 1 });
    const practice = rig.session.results.filter((r) => r.roundId === 0);
    expect(practice).toHaveLength(2);
    expect(rig.session.playerList.every((p) => p.totalPoints === 0)).toBe(true);
    const shown = rig.rec.events("round:result").map((l) => l.payload as { racePoints: number });
    expect(shown.every((p) => p.racePoints === 0)).toBe(true);
  });

  it("seluruh sesi Kilat berjalan sampai podium dan menyimpan hasil, bonus beruntun naik, peringkat konsisten", () => {
    const rig = makeRig({ n: 3, settings: { mode: "QUICK", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "TUTORIAL");
    for (const id of rig.ids) rig.session.tutorialDone(id, { totalMs: 1000, autoDemoSteps: [1, 2, 3, 4, 5] });
    for (let i = 0; i < 6; i++) {
      playRound(rig, { wrongProbe: i === 2 ? ["siswa-3"] : [] });
      runUntil(rig, "LEADERBOARD");
      if (i < 5) runUntil(rig, "LOOK");
    }
    runUntil(rig, "PODIUM");
    expect(rig.session.results).toHaveLength(18);
    expect(rig.session.rejected).toBe(0);
    const s1 = rig.session.results.filter((r) => r.studentId === "siswa-1").map((r) => r.streakBonus);
    expect(s1).toEqual([0, 100, 200, 300, 300, 300]);
    const podium = rig.rec.last("podium")!.payload as { top3: { nickname: string; points: number }[] };
    expect(podium.top3).toHaveLength(3);
    expect(podium.top3.map((p) => p.points)).toEqual([...podium.top3.map((p) => p.points)].sort((a, b) => b - a));
    expect(rig.session.end()).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("ENDED");
    expect(rig.session.end()).toMatchObject({ ok: false });
  });
});

describe("peta tanpa kunci jawaban dan anti-contek (A2, A4)", () => {
  it("A2: tidak ada biaya optimal, rute optimal, atau jawaban probe pada peta, fase, dan pertanyaan probe sebelum reveal", () => {
    const rig = makeRig({ n: 3, settings: { mode: "QUICK", introMode: "SHORT" } });
    joinAll(rig);
    rig.session.start();
    for (let i = 0; i < 3; i++) {
      playRound(rig);
      if (i < 2) runUntil(rig, "LOOK");
    }
    const beforeReveal = rig.rec.log.filter((l) => ["round:map", "round:hideWeights", "probe:question", "tutorial:map"].includes(l.event) || (l.event === "phase" && l.to === "all"));
    expect(beforeReveal.length).toBeGreaterThan(5);
    for (const l of beforeReveal) expect(hasKey(l.payload, FORBIDDEN_KEYS), `${l.event}`).toBe(false);
    const reveal = rig.rec.events("round:reveal");
    expect(reveal.length).toBeGreaterThan(0);
    expect(hasKey(reveal[0]!.payload, ["optimalPath", "optimalCost"])).toBe(true);
    // pertanyaan probe tidak menandai pilihan benar
    const probe = rig.rec.events("probe:question")[0]!.payload as { options: unknown[] };
    expect(probe.options.every((o) => typeof o === "number")).toBe(true);
  });

  it("A4: kursi bersebelahan (8 arah) mendapat soal berbeda di setiap ronde", () => {
    const rig = makeRig({ n: 6, settings: { introMode: "SHORT", seatLayout: { rows: 2, cols: 3, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    for (let round = 0; round < 4; round++) {
      playRound(rig);
      runUntil(rig, round === 0 ? "LOOK" : "LOOK");
    }
    const byRound = new Map<number, Map<string, string>>();
    for (const r of rig.session.results) {
      if (r.roundId === 0) continue;
      byRound.set(r.roundId, (byRound.get(r.roundId) ?? new Map()).set(`${r.seatRow},${r.seatCol}`, r.itemId));
    }
    expect(byRound.size).toBeGreaterThan(1);
    for (const [, seats] of byRound) {
      for (const [a, ia] of seats) {
        const [ar, ac] = a.split(",").map(Number) as [number, number];
        for (const [b, ib] of seats) {
          const [br, bc] = b.split(",").map(Number) as [number, number];
          if (a !== b && Math.abs(ar - br) <= 1 && Math.abs(ac - bc) <= 1) expect(ia, `${a} vs ${b}`).not.toBe(ib);
        }
      }
    }
  });

  it("peta siswa sudah diberi varian: id tempat sama dengan soal, koordinat dalam 0..1", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    for (const id of rig.ids) {
      const map: MapDef = mapOf(rig, id);
      expect(map.nodes.every((n) => n.x >= 0 && n.x <= 1 && n.y >= 0 && n.y <= 1)).toBe(true);
      expect(map).not.toHaveProperty("probeEdgeId");
    }
  });
});

describe("kursi dan perangkat (A6, A8)", () => {
  it("kursi sudah dipakai, di luar denah, dan terkunci setelah ronde 1 dimulai (A8)", () => {
    const rig = makeRig({ n: 3, settings: { introMode: "SHORT" } });
    joinAll(rig);
    expect(rig.session.seat("siswa-1", 0, 1)).toMatchObject({ ok: false, error: "SEAT_TAKEN" });
    expect(rig.session.seat("siswa-1", 9, 9)).toMatchObject({ ok: false, error: "SEAT_INVALID" });
    expect(rig.session.seat("tidak-ada", 0, 0)).toMatchObject({ ok: false, error: "NOT_CLAIMED" });
    expect(rig.session.seat("siswa-1", 2, 3)).toMatchObject({ ok: true });
    rig.session.start();
    runUntil(rig, "LOOK"); // ronde 0 (latihan): kursi belum terkunci
    playRound(rig);
    expect(rig.session.phase).toBe("RESULT");
    runUntil(rig, "LOOK"); // ronde 1 dimulai
    expect(rig.session.seat("siswa-1", 1, 1)).toMatchObject({ ok: false, error: "SEAT_LOCKED" });
  });

  it("guru mengosongkan kursi setelah ronde dimulai → flag SEAT_CHANGED pada siswa itu", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    expect(rig.session.clearSeat(0, 0)).toMatchObject({ ok: true });
    expect(rig.session.clearSeat(0, 0)).toMatchObject({ ok: false, error: "NOT_FOUND" });
    expect(rig.session.playerList.find((p) => p.id === "siswa-1")!.flags).toContain("SEAT_CHANGED");
    expect(rig.session.playerList.find((p) => p.id === "siswa-2")!.flags).not.toContain("SEAT_CHANGED");
  });

  it("A6: token yang sama dari perangkat lain ditolak dan dicatat SECOND_DEVICE; sambung ulang dari perangkat yang sama berhasil", () => {
    const rig = makeRig({ n: 2 });
    rig.session.begin();
    rig.session.skipIntro();
    const claim = rig.session.claim("siswa-1", "conn-a");
    const token = claim.ok ? claim.studentToken : "";
    expect(rig.session.reattach(token, "conn-b")).toMatchObject({ ok: false, error: "SECOND_DEVICE" });
    expect(rig.session.playerList.find((p) => p.id === "siswa-1")!.flags).toContain("SECOND_DEVICE");
    expect(rig.rec.events("integrity:alert").length).toBe(1);
    expect(rig.session.reattach("salah", "conn-c")).toMatchObject({ ok: false, error: "TOKEN_INVALID" });
    expect(rig.session.reattach(token, "conn-a")).toMatchObject({ ok: true });
    rig.session.detach("conn-a");
    const again = rig.session.reattach(token, "conn-b"); // perangkat lama sudah putus
    expect(again).toMatchObject({ ok: true, me: { studentId: "siswa-1" } });
  });
});

describe("hasil ronde: timeout, missed, integritas, flag", () => {
  const quick = { introMode: "SHORT" as const, mode: "QUICK" as const, seatLayout: { rows: 2, cols: 3, aisleAfterCols: [], enabled: true } };

  it("timeout: tidak mengirim rute → timedOut dengan poin 0; hasil lain tetap normal", () => {
    const rig = makeRig({ n: 3, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig); // latihan
    runUntil(rig, "LOOK");
    playRound(rig, { skip: ["siswa-3"] });
    const r = rig.session.results.filter((x) => x.roundId === 1);
    const late = r.find((x) => x.studentId === "siswa-3")!;
    expect(late).toMatchObject({ timedOut: true, missed: false, completed: false, racePoints: 0, errorType: "TIMEOUT", tRouteMs: 20_000 });
    expect(r.filter((x) => x.studentId !== "siswa-3").every((x) => x.optimalHit && !x.timedOut)).toBe(true);
  });

  it("hasil yang tiba di jendela toleransi 2 detik setelah waktu habis masih diterima; setelahnya ditolak", () => {
    const rig = makeRig({ n: 2, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "WALK");
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 0));
    runUntil(rig, "LOOK");
    runUntil(rig, "WALK");
    rig.session.routeSubmit("siswa-1", optimalSubmit(rig, "siswa-1", 1));
    rig.clock.runNext(); // waktu jalan habis, siswa-2 belum mengirim
    expect(rig.session.phase).toBe("WALK"); // jendela toleransi (VISIBLE)
    expect(rig.session.routeSubmit("siswa-2", optimalSubmit(rig, "siswa-2", 1))).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("RESULT");
    expect(rig.session.results.find((r) => r.roundId === 1 && r.studentId === "siswa-2")).toMatchObject({ timedOut: false, optimalHit: true });
    runUntil(rig, "LOOK");
    runUntil(rig, "WALK");
    rig.session.routeSubmit("siswa-1", optimalSubmit(rig, "siswa-1", 2));
    rig.clock.runNext();
    rig.clock.advance(2500);
    expect(rig.session.routeSubmit("siswa-2", optimalSubmit(rig, "siswa-2", 2))).toMatchObject({ ok: false });
  });

  it("missed: siswa yang tidak pernah tersambung selama ronde dikeluarkan dari indeks; sambung ulang memakai token", () => {
    const rig = makeRig({ n: 3, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    rig.session.detach("conn-siswa-3"); // terputus sebelum ronde 1 dimulai? (ronde sudah dimulai di LOOK, jadi sudah terlihat)
    runUntil(rig, "RESULT");
    const r1 = rig.session.results.filter((x) => x.roundId === 1 && x.studentId === "siswa-3")[0]!;
    expect(r1.missed || r1.timedOut).toBe(true);
    runUntil(rig, "LEADERBOARD");
    rig.session.detach("conn-siswa-1");
    runUntil(rig, "LOOK"); // ronde 2: siswa-3 dan siswa-1 terputus sejak awal
    runUntil(rig, "WALK");
    for (const id of ["siswa-2"]) rig.session.routeSubmit(id, optimalSubmit(rig, id, 2));
    while (rig.session.phase !== "RESULT") rig.clock.runNext();
    const r2 = rig.session.results.filter((x) => x.roundId === 2);
    expect(r2.filter((x) => x.missed).map((x) => x.studentId).sort()).toEqual(["siswa-1", "siswa-3"]);
    expect(r2.filter((x) => x.missed).every((x) => x.racePoints === 0 && x.playerCost === null && x.errorType === "NONE")).toBe(true);
  });

  it("integritas: hasil yang dimanipulasi masuk data/rejected dan tidak masuk hasil atau poin", () => {
    const rig = makeRig({ n: 2, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "WALK");
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 0));
    runUntil(rig, "LOOK");
    runUntil(rig, "WALK");
    const good = optimalSubmit(rig, "siswa-1", 1);
    rig.session.routeSubmit("siswa-1", good);
    const bad = optimalSubmit(rig, "siswa-2", 1);
    rig.session.routeSubmit("siswa-2", { ...bad, tapLog: [...bad.tapLog, { tMs: 9000, nodeId: "n0", valid: false }].slice(0, bad.tapLog.length), path: [...bad.path.slice(0, 1), "n9"] });
    runUntil(rig, "RESULT");
    expect(rig.session.rejected).toBe(1);
    expect(rig.session.results.filter((r) => r.roundId === 1).map((r) => r.studentId)).toEqual(["siswa-1"]);
    expect(rig.rec.last("rejected:count")!.payload).toEqual({ count: 1 });
    const rejectedLines = rig.store.readRejected(rig.session.id);
    expect(rejectedLines).toHaveLength(1);
    expect(rejectedLines[0]).toMatchObject({ kind: "round", studentId: "siswa-2" });
    expect(rig.session.playerList.find((p) => p.id === "siswa-2")!.totalPoints).toBe(0);
  });

  it("flag integritas dicatat tanpa mengubah poin: FOCUS_LOST, FULLSCREEN_EXIT, TOO_FAST; di luar LOOK/WALK diabaikan", () => {
    const rig = makeRig({ n: 2, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "WALK");
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 0));
    runUntil(rig, "LOOK");
    expect(rig.session.integrityEvent("siswa-1", { type: "FOCUS_LOST", phase: "LOOK", roundId: 1, tMs: 100 })).toMatchObject({ ok: true });
    runUntil(rig, "WALK");
    rig.session.integrityEvent("siswa-1", { type: "FOCUS_LOST", phase: "WALK", roundId: 1, tMs: 500 });
    rig.session.integrityEvent("siswa-1", { type: "FULLSCREEN_EXIT", phase: "WALK", roundId: 1, tMs: 700 });
    rig.session.integrityEvent("siswa-1", { type: "FOCUS_BACK", phase: "WALK", roundId: 1, tMs: 900 });
    rig.session.routeSubmit("siswa-1", optimalSubmit(rig, "siswa-1", 1, 100)); // ≥ 3 langkah dalam waktu sangat singkat
    rig.session.routeSubmit("siswa-2", optimalSubmit(rig, "siswa-2", 1, 900));
    runUntil(rig, "RESULT");
    const a = rig.session.results.find((r) => r.roundId === 1 && r.studentId === "siswa-1")!;
    const b = rig.session.results.find((r) => r.roundId === 1 && r.studentId === "siswa-2")!;
    expect(a.focusLost).toBe(2);
    expect(a.fullscreenExits).toBe(1);
    expect(a.integrityFlags).toEqual(expect.arrayContaining(["FOCUS_LOST", "FULLSCREEN_EXIT"]));
    expect(a.optimalHit).toBe(true);
    expect(b.integrityFlags).toEqual([]);
    if (a.steps >= 3) expect(a.integrityFlags).toContain("TOO_FAST");
    expect(a.racePoints).toBeGreaterThan(b.racePoints);
    expect(rig.session.integrityEvent("tidak-ada", { type: "FOCUS_LOST", phase: "LOOK", roundId: 1, tMs: 1 })).toMatchObject({ ok: false });
  });

  it("pengiriman tidak valid: ronde salah, ganda, di luar fase, dan waktu melebihi batas", () => {
    const rig = makeRig({ n: 1, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    const sub = optimalSubmit(rig, "siswa-1", 0);
    expect(rig.session.routeSubmit("siswa-1", sub)).toMatchObject({ ok: false, error: "WRONG_PHASE" }); // masih LOOK
    runUntil(rig, "WALK");
    expect(rig.session.routeSubmit("siswa-1", { ...sub, roundId: 7 })).toMatchObject({ ok: false });
    expect(rig.session.routeSubmit("siswa-1", { ...sub, clientElapsedMs: 99_999 })).toMatchObject({ ok: false, error: "INVALID_PAYLOAD" });
    expect(rig.session.routeSubmit("siswa-1", { ...sub, path: "x" as unknown as string[] })).toMatchObject({ ok: false, error: "INVALID_PAYLOAD" });
    expect(rig.session.routeProgress("siswa-1", { roundId: 0, path: ["n0"], tMs: 300 })).toMatchObject({ ok: true });
    expect(rig.session.routeSubmit("siswa-1", sub)).toMatchObject({ ok: true });
    expect(rig.session.routeSubmit("siswa-1", sub)).toMatchObject({ ok: false });
    expect(rig.session.routeSubmit("tidak-ada", sub)).toMatchObject({ ok: false, error: "NOT_CLAIMED" });
    expect(rig.session.routeProgress("tidak-ada", { roundId: 0, path: [], tMs: 1 })).toMatchObject({ ok: false });
    expect(rig.session.probeAnswer("siswa-1", { roundId: 0, value: 1, clientElapsedMs: 1 })).toMatchObject({ ok: false });
  });

  it("progres yang sudah lengkap tetapi tidak sempat dikirim tetap dihitung", () => {
    const rig = makeRig({ n: 1, settings: quick });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "WALK");
    const sub = optimalSubmit(rig, "siswa-1", 0);
    rig.session.routeProgress("siswa-1", { roundId: 0, path: sub.path, tMs: 4000 });
    runUntil(rig, "RESULT");
    const r = rig.session.results.find((x) => x.roundId === 0)!;
    expect(r).toMatchObject({ completed: true, optimalHit: true, timedOut: false, tRouteMs: 4000 });
  });

  it("ronde HIDDEN: bobot disembunyikan saat WALK; jawaban probe benar/salah/diam dinilai dan reconnect memuat ulang peta", () => {
    const rig = makeRig({ n: 3, settings: { ...quick, roundIds: [2] } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    expect(getRoundConfig(2).condition).toBe("HIDDEN");
    runUntil(rig, "WALK");
    expect(rig.rec.events("round:hideWeights")).toHaveLength(1);
    rig.session.detach("conn-siswa-3");
    const token = rig.session.reattach("token-x", "c").ok; // token palsu
    expect(token).toBe(false);
    for (const id of ["siswa-1", "siswa-2"]) rig.session.routeSubmit(id, optimalSubmit(rig, id, 2));
    expect(rig.session.phase).toBe("PROBE");
    const q1 = rig.rec.last("probe:question", "siswa-1")!.payload as { edgeId: string; options: number[] };
    const w1 = mapOf(rig, "siswa-1").edges.find((e) => e.id === q1.edgeId)!.w;
    rig.session.probeAnswer("siswa-1", { roundId: 2, value: w1, clientElapsedMs: 2000 });
    expect(rig.session.probeAnswer("siswa-1", { roundId: 2, value: w1, clientElapsedMs: 2000 })).toMatchObject({ ok: false });
    rig.session.probeAnswer("siswa-2", { roundId: 2, value: q1.options.find((o) => o !== w1)! + 100, clientElapsedMs: 1000 });
    runUntil(rig, "RESULT");
    const res = rig.session.results.filter((r) => r.roundId === 2);
    expect(res.find((r) => r.studentId === "siswa-1")).toMatchObject({ probeCorrect: true, probePoints: 160, probeMs: 2000 });
    expect(res.find((r) => r.studentId === "siswa-2")).toMatchObject({ probeCorrect: false, probePoints: 0 });
    expect(res.find((r) => r.studentId === "siswa-3")).toMatchObject({ timedOut: true });
  });
});

describe("bot, penyimpanan, dan ranking", () => {
  it("sesi LIVE tidak pernah bisa berisi bot; bot hanya pada sesi TEST di server yang mengizinkan", () => {
    const live = makeRig({ settings: { kind: "LIVE" }, allowBots: true });
    live.session.begin();
    live.session.skipIntro();
    expect(live.session.addBot("siswa-1")).toMatchObject({ ok: false, error: "BOTS_DISABLED" });
    const prod = makeRig({ allowBots: false });
    prod.session.begin();
    prod.session.skipIntro();
    expect(prod.session.addBot("siswa-1")).toMatchObject({ ok: false, error: "BOTS_DISABLED" });
    const test = makeRig({ allowBots: true });
    test.session.begin();
    expect(test.session.addBot("siswa-1")).toMatchObject({ ok: false, error: "WRONG_PHASE" });
    test.session.skipIntro();
    const bot = test.session.addBot("siswa-1");
    expect(bot).toMatchObject({ ok: true, studentId: "siswa-1" });
    expect(test.session.addBot("siswa-1")).toMatchObject({ ok: false, error: "NAME_TAKEN" });
    expect(test.session.addBot("x")).toMatchObject({ ok: false, error: "NAME_UNKNOWN" });
    expect(test.session.playerList.find((p) => p.id === "siswa-1")!.isBot).toBe(true);
    expect(live.session.playerList.some((p) => p.isBot)).toBe(false);
  });

  it("JSONL: sesi TEST ditulis ke test-sessions dan sesi LIVE ke sessions; setiap hasil satu baris", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    const events = rig.store.read("TEST", rig.session.id);
    expect(events.map((e) => e.type)).toEqual(expect.arrayContaining(["session", "player", "round"]));
    expect(events.filter((e) => e.type === "round")).toHaveLength(2);
    expect(events.every((e) => e.game === "ROUTE_RUSH" && e.sessionId === rig.session.id)).toBe(true);
    expect(rig.store.read("LIVE", rig.session.id)).toEqual([]);
    expect(readFileSync(rig.store.pathFor("TEST", rig.session.id), "utf8").trim().split("\n")).toHaveLength(events.length);
    const live = makeRig({ n: 1, settings: { kind: "LIVE" } });
    live.session.begin();
    expect(live.store.read("LIVE", live.session.id)[0]).toMatchObject({ type: "session", kind: "LIVE" });
  });

  it("ranking: poin tertinggi di atas; papan peringkat 5 besar ke host dan peringkat pribadi ke tiap siswa", () => {
    const rig = makeRig({ n: 3, settings: { introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    playRound(rig, { skip: ["siswa-2"] });
    runUntil(rig, "LEADERBOARD");
    const host = rig.rec.last("leaderboard")!;
    const mine = rig.rec.events("leaderboard").filter((l) => l.to === "player");
    expect(mine).toHaveLength(3);
    expect(mine.find((l) => l.id === "siswa-2")!.payload).toMatchObject({ myRank: 3 });
    expect(mine.find((l) => l.id === "siswa-1")!.payload).toHaveProperty("top5");
    void host;
    expect(roster(3)).toHaveLength(3);
  });

  it("host: lompat fase dan hitungan mundur", () => {
    const rig = makeRig({ n: 1, settings: { introMode: "SHORT", seatLayout: { rows: 1, cols: 1, aisleAfterCols: [], enabled: false } } });
    joinAll(rig);
    expect(rig.session.skip()).toMatchObject({ ok: false, error: "WRONG_PHASE" }); // LOBBY menunggu guru
    rig.session.start();
    expect(rig.session.skip()).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("LOOK");
    expect(rig.rec.phases().slice(0, 4)).toEqual(["INTRO_IDENT", "INTRO_TRAILER", "LOBBY", "COUNTDOWN"]);
    void Recorder;
  });
});

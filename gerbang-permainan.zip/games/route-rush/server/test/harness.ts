import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { optimalRoute, type MapDef, type RosterEntry, type RouteSubmitPayload, type SessionSettings } from "@route-rush/shared";
import { ManualClock } from "../src/clock";
import { loadBank } from "../src/data";
import { GameSession, type Emitter } from "../src/session";
import { JsonlStore } from "../src/store";

export interface Logged {
  to: "host" | "player" | "players" | "room" | "all";
  id?: string;
  event: string;
  payload: unknown;
}

/** Perekam keluaran sesi, dipakai untuk menguji sesi tanpa jaringan. */
export class Recorder implements Emitter {
  readonly log: Logged[] = [];
  toHost(event: string, payload: unknown): void {
    this.log.push({ to: "host", event, payload });
  }
  toPlayer(id: string, event: string, payload: unknown): void {
    this.log.push({ to: "player", id, event, payload });
  }
  toPlayers(event: string, payload: unknown): void {
    this.log.push({ to: "players", event, payload });
  }
  toRoom(event: string, payload: unknown): void {
    this.log.push({ to: "room", event, payload });
  }
  toAll(event: string, payload: unknown): void {
    this.log.push({ to: "all", event, payload });
  }
  events(event: string): Logged[] {
    return this.log.filter((l) => l.event === event);
  }
  last(event: string, id?: string): Logged | undefined {
    return [...this.log].reverse().find((l) => l.event === event && (id === undefined || l.id === id));
  }
  phases(): string[] {
    return this.events("phase").map((l) => (l.payload as { phase: string }).phase);
  }
}

export const roster = (n: number): RosterEntry[] => Array.from({ length: n }, (_, i) => ({ id: `siswa-${i + 1}`, name: `Siswa Uji ${i + 1}`, kelas: "6C" }));

export interface Rig {
  session: GameSession;
  clock: ManualClock;
  rec: Recorder;
  store: JsonlStore;
  dir: string;
  ids: string[];
}

let counter = 0;

export function makeRig(opts: { n?: number; settings?: Partial<SessionSettings>; allowBots?: boolean; dir?: string } = {}): Rig {
  const n = opts.n ?? 3;
  const clock = new ManualClock();
  const rec = new Recorder();
  const dir = opts.dir ?? mkdtempSync(join(tmpdir(), "rr-sesi-"));
  const store = new JsonlStore(dir);
  const settings: SessionSettings = {
    mode: "STANDARD",
    introMode: "FULL",
    pool: "A",
    lookSeconds: null,
    walkSeconds: null,
    probeSeconds: 5,
    resultSeconds: 3,
    hiddenRounds: [],
    roundIds: null,
    quota: n,
    seatLayout: { rows: 3, cols: 4, aisleAfterCols: [2], enabled: true },
    kind: "TEST",
    uniqueMaps: false,
    ...opts.settings,
  };
  const session = new GameSession(
    { id: `uji-${++counter}`, code: "123456", hostToken: "host-token", settings, roster: roster(n) },
    { clock, store, emitter: rec, bank: bankOnce(), newToken: () => `token-${++counter}`, allowBots: opts.allowBots ?? true },
  );
  return { session, clock, rec, store, dir, ids: roster(n).map((r) => r.id) };
}

let cachedBank: ReturnType<typeof loadBank> | null = null;
export function bankOnce(): ReturnType<typeof loadBank> {
  cachedBank ??= loadBank();
  return cachedBank;
}

/** Membawa sesi ke LOBBY lalu memasukkan semua siswa dengan kursi berurutan. */
export function joinAll(rig: Rig, opts: { seats?: boolean } = {}): void {
  rig.session.begin();
  while (rig.session.phase !== "LOBBY") rig.clock.runNext();
  rig.ids.forEach((id, i) => {
    const r = rig.session.claim(id, `conn-${id}`);
    if (!r.ok) throw new Error(`claim gagal: ${r.error}`);
    if (opts.seats !== false && rig.session.settings.seatLayout.enabled) {
      const layout = rig.session.settings.seatLayout;
      const s = rig.session.seat(id, Math.floor(i / layout.cols), i % layout.cols);
      if (!s.ok) throw new Error(`kursi gagal: ${s.error}`);
    }
  });
}

/** Peta terakhir yang dikirim ke siswa (tidak berisi kunci jawaban). */
export function mapOf(rig: Rig, id: string): MapDef {
  const l = rig.rec.last("round:map", id);
  if (!l) throw new Error(`belum ada peta untuk ${id}`);
  return (l.payload as { map: MapDef }).map;
}

/** Pengiriman rute optimal seperti yang dilakukan siswa yang menjawab dengan benar. */
export function optimalSubmit(rig: Rig, id: string, roundId: number, stepMs = 800): RouteSubmitPayload {
  const path = optimalRoute(mapOf(rig, id));
  return {
    roundId,
    path,
    clientElapsedMs: (path.length - 1) * stepMs,
    tapLog: path.slice(1).map((nodeId, i) => ({ tMs: (i + 1) * stepMs, nodeId, valid: true })),
    invalidTaps: 0,
    undo: 0,
    revisits: 0,
  };
}

export const currentRound = (rig: Rig): number => ((rig.rec.last("phase")?.payload as { roundId?: number } | undefined)?.roundId ?? -1);

/** Menggerakkan fase sampai fase `target` tercapai (waktu maju hanya lewat jam terkendali). */
export function runUntil(rig: Rig, target: string, guard = 500): void {
  for (let i = 0; i < guard && rig.session.phase !== target; i++) {
    if (!rig.clock.runNext()) break;
  }
  if (rig.session.phase !== target) throw new Error(`fase ${target} tidak tercapai; sekarang ${rig.session.phase}`);
}

/** Memainkan satu ronde sampai fase RESULT: semua siswa mengirim rute optimal dan menjawab probe dengan benar. */
export function playRound(rig: Rig, opts: { skip?: string[]; wrongProbe?: string[] } = {}): void {
  runUntil(rig, "WALK");
  const roundId = currentRound(rig);
  for (const id of rig.ids) {
    if (opts.skip?.includes(id)) continue;
    const r = rig.session.routeSubmit(id, optimalSubmit(rig, id, roundId));
    if (!r.ok && rig.session.phase === "WALK") throw new Error(`submit ${id} gagal: ${r.error}`);
  }
  if (rig.session.phase === "WALK") rig.clock.runNext();
  while (rig.session.phase === "WALK") rig.clock.runNext();
  if (rig.session.phase === "PROBE") {
    for (const id of rig.ids) {
      const q = rig.rec.last("probe:question", id)?.payload as { edgeId: string; options: number[] } | undefined;
      if (!q) continue;
      const map = mapOf(rig, id);
      const w = map.edges.find((e) => e.id === q.edgeId)!.w;
      const value = opts.wrongProbe?.includes(id) ? (q.options.find((o) => o !== w) as number) : w;
      rig.session.probeAnswer(id, { roundId, value, clientElapsedMs: 1500 });
    }
  }
  runUntil(rig, "RESULT");
}

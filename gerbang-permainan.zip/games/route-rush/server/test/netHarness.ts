import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { io, type Socket } from "socket.io-client";
import { optimalRoute, type MapDef, type PhasePayload, type RosterEntry } from "@route-rush/shared";
import { ManualClock } from "../src/clock";
import { createGameServer, type GameServer, type ServerConfig } from "../src/index";
import type { GameSession } from "../src/session";

export const sleep = (ms: number): Promise<void> => new Promise((r) => setTimeout(r, ms));

export async function waitFor(cond: () => boolean, ms = 3000, what = "kondisi"): Promise<void> {
  const until = Date.now() + ms;
  while (!cond()) {
    if (Date.now() > until) throw new Error(`waktu habis menunggu ${what}`);
    await sleep(3);
  }
}

export interface NetRig {
  server: GameServer;
  clock: ManualClock;
  url: string;
  dataDir: string;
  sockets: Socket[];
  connect(): Socket;
  stop(): Promise<void>;
}

export async function startNet(config: Partial<ServerConfig> = {}): Promise<NetRig> {
  const clock = new ManualClock();
  const dataDir = config.dataDir ?? mkdtempSync(join(tmpdir(), "rr-net-"));
  const server = createGameServer({ nodeEnv: "test", clock, ...config, dataDir });
  const port = await server.listen();
  const url = `http://127.0.0.1:${port}`;
  const sockets: Socket[] = [];
  return {
    server,
    clock,
    url,
    dataDir,
    sockets,
    connect() {
      const s = io(url, { transports: ["websocket"], forceNew: true, reconnection: false });
      sockets.push(s);
      return s;
    },
    async stop() {
      for (const s of sockets) s.close();
      await server.close();
    },
  };
}

export const ask = <T = Record<string, unknown>>(socket: Socket, event: string, payload?: unknown): Promise<T & { ok: boolean; error?: string }> =>
  new Promise((resolve, reject) => {
    socket.timeout(3000).emit(event, payload, (err: Error | null, res: T & { ok: boolean; error?: string }) => (err ? reject(err) : resolve(res)));
  });

export type Strategy = "optimal" | "silent";

/** Perangkat siswa tiruan untuk uji: mengikuti protokol seperti client nyata (peta, tutorial, probe). */
export class BotDevice {
  readonly socket: Socket;
  readonly received: { event: string; payload: unknown }[] = [];
  map: MapDef | null = null;
  roundId = -1;
  studentId = "";
  token = "";

  constructor(
    net: NetRig,
    private readonly strategy: Strategy = "optimal",
    private readonly row = 0,
    private readonly col = 0,
  ) {
    this.socket = net.connect();
    this.socket.onAny((event: string, payload: unknown) => {
      this.received.push({ event, payload });
      this.react(event, payload);
    });
  }

  private react(event: string, payload: unknown): void {
    if (event === "round:map") this.map = (payload as { map: MapDef }).map;
    if (event === "phase") {
      const p = payload as PhasePayload;
      if (p.roundId !== undefined) this.roundId = p.roundId;
      if (p.phase === "WALK" && this.strategy === "optimal" && this.map) {
        const path = optimalRoute(this.map);
        this.socket.emit("route:submit", {
          roundId: this.roundId,
          path,
          clientElapsedMs: (path.length - 1) * 700,
          tapLog: path.slice(1).map((nodeId, i) => ({ tMs: (i + 1) * 700, nodeId, valid: true })),
          invalidTaps: 0,
          undo: 0,
          revisits: 0,
        });
      }
    }
    if (event === "tutorial:map") {
      const { step } = payload as { step: number };
      this.socket.emit("tutorial:step", { step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 4000 });
      if (step === 5) this.socket.emit("tutorial:done", { totalMs: 20_000, autoDemoSteps: [], probeCorrect: true });
    }
    if (event === "probe:question" && this.map && this.strategy === "optimal") {
      const q = payload as { edgeId: string; options: number[] };
      const w = this.map.edges.find((e) => e.id === q.edgeId)?.w;
      this.socket.emit("probe:answer", { roundId: this.roundId, value: w, clientElapsedMs: 1200 });
    }
  }

  /** Bergabung dengan token yang dibuat lewat event bot (khusus server test), lalu memilih kursi. */
  async attach(code: string, token: string, studentId: string, withSeat = true): Promise<void> {
    this.studentId = studentId;
    this.token = token;
    const r = await ask(this.socket, "player:join", { code, studentToken: token });
    if (!r.ok) throw new Error(`bot gagal bergabung: ${r.error}`);
    if (withSeat) {
      const s = await ask(this.socket, "player:seat", { row: this.row, col: this.col });
      if (!s.ok) throw new Error(`bot gagal memilih kursi: ${s.error}`);
    }
  }

  eventsBefore(event: string): { event: string; payload: unknown }[] {
    const i = this.received.findIndex((e) => e.event === event);
    return i < 0 ? this.received : this.received.slice(0, i);
  }
}

export const rosterOf = (n: number): RosterEntry[] => Array.from({ length: n }, (_, i) => ({ id: `siswa-${i + 1}`, name: `Siswa Uji ${i + 1}`, kelas: "6C" }));

export interface SessionHandle {
  host: Socket;
  session: GameSession;
  id: string;
  code: string;
  hostToken: string;
}

export async function createSession(net: NetRig, nStudents: number, settings: Record<string, unknown> = {}): Promise<SessionHandle> {
  const host = net.connect();
  const r = await ask<{ sessionId: string; code: string; hostToken: string }>(host, "host:create", { roster: rosterOf(nStudents), settings: { kind: "TEST", ...settings } });
  if (!r.ok) throw new Error(`host:create gagal: ${JSON.stringify(r)}`);
  const session = net.server.registry.get(r.sessionId) as GameSession;
  return { host, session, id: r.sessionId, code: r.code, hostToken: r.hostToken };
}

/** Melewati intro sampai LOBBY (PIN baru terbuka di sini). */
export function toLobby(net: NetRig, h: SessionHandle): void {
  while (h.session.phase !== "LOBBY") if (!net.clock.runNext()) throw new Error("jam habis sebelum LOBBY");
}

export async function addBots(net: NetRig, h: SessionHandle, strategies: Strategy[]): Promise<BotDevice[]> {
  const bots: BotDevice[] = [];
  for (const [i, strategy] of strategies.entries()) {
    const id = `siswa-${i + 1}`;
    const bot = new BotDevice(net, strategy, 0, i);
    const made = await ask<{ studentId: string; studentToken: string }>(bot.socket, "test:addBot", { code: h.code, rosterId: id });
    if (!made.ok) throw new Error(`test:addBot gagal: ${made.error}`);
    await bot.attach(h.code, made.studentToken, made.studentId, h.session.settings.seatLayout.enabled);
    bots.push(bot);
  }
  return bots;
}

/** Menggerakkan sesi sampai PODIUM: jam maju hanya saat server menunggu pewaktu; WALK/PROBE/TUTORIAL menunggu bot lebih dulu. */
export async function driveToPodium(net: NetRig, h: SessionHandle, patienceMs = 400): Promise<void> {
  for (let guard = 0; guard < 2000 && h.session.phase !== "PODIUM"; guard++) {
    const phase = h.session.phase;
    if (phase === "WALK" || phase === "PROBE" || phase === "TUTORIAL") {
      const until = Date.now() + patienceMs;
      while (h.session.phase === phase && Date.now() < until) await sleep(2);
      if (h.session.phase !== phase) continue;
    } else await sleep(1);
    if (!net.clock.runNext()) throw new Error(`jam habis pada fase ${h.session.phase}`);
  }
  if (h.session.phase !== "PODIUM") throw new Error(`tidak mencapai PODIUM; fase ${h.session.phase}`);
}

/** Memajukan jam sampai fase tertentu tercapai (untuk fase yang hanya menunggu pewaktu). */
export function advanceTo(net: NetRig, h: SessionHandle, phase: string): void {
  while (h.session.phase !== phase) if (!net.clock.runNext()) throw new Error(`jam habis sebelum ${phase}`);
}

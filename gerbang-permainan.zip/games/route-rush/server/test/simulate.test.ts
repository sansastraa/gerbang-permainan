import { mkdtempSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { roundIdsFor, sessionBudget, type IntroMode, type SessionMode } from "@route-rush/shared";
import { simulateOne } from "../src/simulate";

const kinds: [string, SessionMode, IntroMode][] = [
  ["S1 Perdana Standar", "STANDARD", "FULL"],
  ["S2 Perdana Kilat", "QUICK", "FULL"],
  ["S3 Lanjutan Standar", "STANDARD", "SHORT"],
  ["S4 Lanjutan Kilat", "QUICK", "SHORT"],
];

describe("simulasi sesi TEST dengan bot (npm run simulate)", () => {
  const dataDir = mkdtempSync(join(tmpdir(), "rr-sim-"));
  for (const [name, mode, introMode] of kinds) {
    it(`${name}: 12 pemain (1 diam) selesai di jam virtual tanpa melewati anggaran, ekspor konsisten`, async () => {
      const r = await simulateOne({ mode, introMode, players: 12, silent: 1, seed: 2026, dataDir });
      expect(r.problems).toEqual([]);
      expect(r.totalMs).toBeLessThanOrEqual(sessionBudget(mode, introMode).totalMs);
      expect(r.budgetMs).toBe(sessionBudget(mode, introMode).totalMs);
      // satu hasil per siswa per ronde (ronde latihan 0 ikut pada sesi lanjutan)
      expect(r.results).toBe(12 * roundIdsFor(mode, introMode).length);
    }, 180_000);
  }
});
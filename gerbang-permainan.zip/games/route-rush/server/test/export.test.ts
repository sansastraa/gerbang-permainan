import { mkdirSync, writeFileSync } from "node:fs";
import { join } from "node:path";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { BOM, buildReport, parseCsv, parseRoundsCsv, studentsCsv, summarizeStudent, round1, type RoundResult } from "@route-rush/shared";
import { loadSessionData } from "../src/export";
import { JsonlStore } from "../src/store";
import { addBots, ask, createSession, driveToPodium, startNet, toLobby, type NetRig, type SessionHandle } from "./netHarness";

let net: NetRig;
let h: SessionHandle;
/** Pemegang token guru (sesi uji ini masih berjalan di podium, jadi laporannya dikunci dengan token). */
const get = (path: string) => fetch(`${net.url}${path}`, { headers: { "x-host-token": h.hostToken } });

beforeAll(async () => {
  net = await startNet();
  h = await createSession(net, 3, { introMode: "SHORT", roundIds: [1, 2] });
  toLobby(net, h);
  await addBots(net, h, ["optimal", "optimal", "silent"]);
  expect((await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).ok).toBe(true);
  await driveToPodium(net, h);
}, 120_000);
afterAll(async () => {
  await net.stop();
});

describe("ekspor lewat HTTP", () => {
  it("sesi yang masih berjalan menolak peminta tanpa token guru atau dengan token salah (401)", async () => {
    for (const f of ["rounds.csv", "students.csv", "summary.json", "report.html"]) {
      expect((await fetch(`${net.url}/api/sessions/${h.id}/${f}?includeTest=1`)).status, f).toBe(401);
      expect((await fetch(`${net.url}/api/sessions/${h.id}/${f}?includeTest=1`, { headers: { "x-host-token": "salah" } })).status, f).toBe(401);
    }
  });

  it("sesi TEST ditolak tanpa includeTest=1 (403), diizinkan dengan includeTest=1", async () => {
    for (const f of ["rounds.csv", "students.csv", "tutorial.csv", "items.csv", "report.html"]) {
      const r = await get(`/api/sessions/${h.id}/${f}`);
      expect(r.status, f).toBe(403);
      expect(((await r.json()) as { error: string }).error).toBe("SESSION_TEST");
      expect((await get(`/api/sessions/${h.id}/${f}?includeTest=1`)).status, f).toBe(200);
    }
  });

  it("CSV: UTF-8 dengan BOM, tipe dan nama berkas unduhan, kolom kind=TEST", async () => {
    const r = await get(`/api/sessions/${h.id}/rounds.csv?includeTest=1`);
    expect(r.headers.get("content-type")).toContain("text/csv");
    expect(r.headers.get("content-disposition")).toContain(`route-rush-${h.id}-rounds.csv`);
    const bytes = new Uint8Array(await r.arrayBuffer());
    expect([...bytes.slice(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
    const text = new TextDecoder("utf-8", { ignoreBOM: true }).decode(bytes);
    expect(text.startsWith(BOM)).toBe(true);
    const rows = parseCsv(text);
    const head = rows[0] as string[];
    expect(rows[1]?.[head.indexOf("kind")]).toBe("TEST");
    expect(rows[1]?.[head.indexOf("game")]).toBe("ROUTE_RUSH");
    // 3 siswa × 2 ronde (+ ronde latihan 0 pada intro ringkas yang dipilih: roundIds [1,2] membuang ronde 0)
    expect(rows.length - 1).toBe(h.session.settings.roundIds?.length ? 3 * 2 : 0);
  });

  it("T26 pada data nyata sesi: students.csv sama persis dengan hitung ulang dari rounds.csv", async () => {
    const rounds = parseRoundsCsv(await (await get(`/api/sessions/${h.id}/rounds.csv?includeTest=1`)).text());
    const students = parseCsv(await (await get(`/api/sessions/${h.id}/students.csv?includeTest=1`)).text());
    const head = students[0] as string[];
    expect(students.length - 1).toBe(3);
    for (const row of students.slice(1)) {
      const id = row[head.indexOf("student_id")] as string;
      const s = summarizeStudent(id, rounds.filter((r: RoundResult) => r.studentId === id));
      expect(row[head.indexOf("total_points")]).toBe(String(s.totalPoints));
      expect(row[head.indexOf("rounds_played")]).toBe(String(s.roundsPlayed));
      expect(row[head.indexOf("rounds_missed")]).toBe(String(s.roundsMissed));
      expect(row[head.indexOf("IL")]).toBe(s.il === null ? "" : String(round1(s.il)));
    }
    const direct = studentsCsv(buildReport(loadSessionData(new JsonlStore(net.dataDir), h.id)!));
    // fetch().text() membuang BOM; bandingkan byte mentahnya
    const raw = new TextDecoder("utf-8", { ignoreBOM: true }).decode(await (await get(`/api/sessions/${h.id}/students.csv?includeTest=1`)).arrayBuffer());
    expect(raw).toBe(BOM + direct);
  });

  it("siswa yang tidak pernah mengirim (silent) tercatat sebagai ronde terlewat/timeout, bukan hilang", async () => {
    const rows = parseCsv(await (await get(`/api/sessions/${h.id}/students.csv?includeTest=1`)).text());
    const head = rows[0] as string[];
    const silent = rows.slice(1).find((r) => r[head.indexOf("student_id")] === "siswa-3") as string[];
    expect(Number(silent[head.indexOf("rounds_played")]) + Number(silent[head.indexOf("rounds_missed")])).toBe(2);
  });

  it("report.html: kartu per siswa, tanpa poin atau peringkat", async () => {
    const html = await (await get(`/api/sessions/${h.id}/report.html?includeTest=1`)).text();
    expect(html).toContain("<!doctype html>");
    expect(html).toMatch(/<article class="card">/);
    expect(html).not.toMatch(/poin|peringkat|race_points|total_points/i);
  });

  it("kesalahan: id tidak sah 400, sesi tidak ada 404, berkas tidak dikenal 404", async () => {
    expect((await get("/api/sessions/..%2Fetc/rounds.csv")).status).toBe(400);
    expect((await get("/api/sessions/tidak-ada/rounds.csv")).status).toBe(404);
    expect((await get(`/api/sessions/${h.id}/rahasia.csv?includeTest=1`)).status).toBe(404);
    expect((await get(`/api/sessions/${h.id}/rounds.csv?includeTest=0`)).status).toBe(403);
  });

  it("sesi LIVE dapat diekspor tanpa includeTest; hasil yang gagal integritas (rejected/) tidak ikut", async () => {
    mkdirSync(join(net.dataDir, "sessions"), { recursive: true });
    mkdirSync(join(net.dataDir, "rejected"), { recursive: true });
    const ev = (o: Record<string, unknown>) => JSON.stringify({ game: "ROUTE_RUSH", sessionId: "live1", at: 1_760_000_000_000, ...o });
    writeFileSync(
      join(net.dataDir, "sessions", "live1.jsonl"),
      [ev({ type: "session", kind: "LIVE", settings: { pool: "B", mode: "QUICK", introMode: "SHORT" } }), ev({ type: "player", studentId: "a", name: "Ani", isBot: false })].join("\n") + "\n",
    );
    writeFileSync(join(net.dataDir, "rejected", "live1.jsonl"), ev({ type: "reject", why: "x" }) + "\n");
    const r = await get("/api/sessions/live1/students.csv");
    expect(r.status).toBe(200);
    const rows = parseCsv(await r.text());
    const head = rows[0] as string[];
    expect(rows[1]?.[head.indexOf("kind")]).toBe("LIVE");
    expect(rows[1]?.[head.indexOf("form")]).toBe("B");
    expect(rows[1]?.[head.indexOf("mode")]).toBe("QUICK");
    expect(rows[1]?.[head.indexOf("rounds_played")]).toBe("0");
    expect(rows[1]?.[head.indexOf("IL")]).toBe(""); // null = sel kosong, bukan angka palsu
    const html = await (await get("/api/sessions/live1/report.html")).text();
    expect(html).toContain("Ani");
  });
});
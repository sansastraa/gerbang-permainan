import { mkdirSync, mkdtempSync, rmSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { io, type Socket } from "socket.io-client";
import { afterEach, describe, expect, it } from "vitest";
import { createGameServer, type GameServer } from "../src/index";
import { ask, rosterOf } from "./netHarness";

describe("server di bawah awalan jalur (BASE_PATH)", () => {
  const dirs: string[] = [];
  const servers: GameServer[] = [];
  const sockets: Socket[] = [];
  afterEach(async () => {
    for (const s of sockets.splice(0)) s.close();
    for (const s of servers.splice(0)) await s.close();
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true });
  });

  const BASE = "/games/route-rush";

  async function start(basePath: string): Promise<string> {
    const dir = mkdtempSync(join(tmpdir(), "rr-base-"));
    dirs.push(dir);
    const dist = join(dir, "dist");
    mkdirSync(join(dist, "assets"), { recursive: true });
    writeFileSync(join(dist, "index.html"), "<!doctype html><title>RR</title><div id=root></div>");
    writeFileSync(join(dist, "assets", "app.js"), "console.log(1)");
    writeFileSync(join(dist, "manifest.webmanifest"), "{}");
    const clips = join(dir, "clips");
    mkdirSync(clips);
    writeFileSync(join(clips, "01.wav"), "RIFF");
    const server = createGameServer({ dataDir: join(dir, "data"), port: 0, host: "127.0.0.1", staticDir: dist, clipsDir: clips, basePath, nodeEnv: "test", allowedOrigins: ["https://simpeteri.example.id"] });
    servers.push(server);
    return `http://127.0.0.1:${await server.listen()}`;
  }

  it("halaman, fallback SPA, berkas statis, health, klip, dan API semuanya ada di bawah awalan", async () => {
    const base = await start(BASE);
    for (const p of ["", "/", "/host", "/host/", "/apa-saja"]) {
      const r = await fetch(`${base}${BASE}${p}`);
      expect(r.status, p).toBe(200);
      expect(await r.text()).toContain("<div id=root>");
    }
    expect((await fetch(`${base}${BASE}/assets/app.js`)).headers.get("cache-control")).toContain("immutable");
    expect((await fetch(`${base}${BASE}/manifest.webmanifest`)).status).toBe(200);
    expect((await fetch(`${base}${BASE}/assets/hilang.js`)).status).toBe(404); // berkas hilang bukan halaman
    const health = await fetch(`${base}${BASE}/health`);
    expect(health.status).toBe(200);
    expect(await health.json()).toMatchObject({ ok: true, game: "ROUTE_RUSH" });
    expect(health.headers.get("access-control-allow-origin")).toBe("*");
    expect(await (await fetch(`${base}${BASE}/clips/index.json`)).json()).toEqual({ count: 1, clips: ["01.wav"] });
    expect((await fetch(`${base}${BASE}/clips/01.wav`)).status).toBe(200);
    expect((await fetch(`${base}${BASE}/api/sessions/tidak-ada/summary.json`)).status).toBe(404);
  });

  it("di luar awalan tidak ada halaman atau API; /health tetap ada di akar untuk pemeriksa platform", async () => {
    const base = await start(BASE);
    expect((await fetch(`${base}/`)).status).toBe(404);
    expect((await fetch(`${base}/host`)).status).toBe(404);
    expect((await fetch(`${base}/api/sessions/x/summary.json`)).status).toBe(404);
    expect((await fetch(`${base}/clips/index.json`)).status).toBe(404);
    expect((await fetch(`${base}/health`)).status).toBe(200);
  });

  it("Socket.IO terhubung di jalur di bawah awalan dan host:create bekerja; jalur lama tidak", async () => {
    const base = await start(BASE);
    const host = io(base, { path: `${BASE}/socket.io`, transports: ["websocket"] });
    sockets.push(host);
    await new Promise<void>((resolve, reject) => {
      host.on("connect", () => resolve());
      host.on("connect_error", reject);
    });
    const r = await ask<{ sessionId: string }>(host, "host:create", { roster: rosterOf(2), settings: { kind: "TEST" } });
    expect(r.ok).toBe(true);
    expect((await fetch(`${base}/socket.io/?EIO=4&transport=polling`)).status).toBe(404);
    expect((await fetch(`${base}${BASE}/socket.io/?EIO=4&transport=polling`)).status).toBe(200);
  });

  it("CORS ekspor dan pembatas tetap berlaku di bawah awalan", async () => {
    const base = await start(BASE);
    const host = io(base, { path: `${BASE}/socket.io`, transports: ["websocket"] });
    sockets.push(host);
    await new Promise<void>((resolve) => host.on("connect", () => resolve()));
    const c = await ask<{ sessionId: string; hostToken: string }>(host, "host:create", { roster: rosterOf(2), settings: { kind: "TEST" }, hostToken: "guru-1234" });
    const url = `${base}${BASE}/api/sessions/${c.sessionId}/summary.json?includeTest=1`;
    const pre = await fetch(url, { method: "OPTIONS", headers: { Origin: "https://simpeteri.example.id" } });
    expect(pre.status).toBe(204);
    expect(pre.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example.id");
    expect((await fetch(url, { headers: { "x-host-token": "salah" } })).status).toBe(401);
    expect((await fetch(url, { headers: { "x-host-token": "guru-1234" } })).status).toBe(200);
  });

  it("tanpa awalan: perilaku lama (dari akar) tidak berubah", async () => {
    const base = await start("");
    expect((await fetch(`${base}/host`)).status).toBe(200);
    expect((await fetch(`${base}/health`)).status).toBe(200);
    expect((await fetch(`${base}/clips/index.json`)).status).toBe(200);
    expect((await fetch(`${base}/socket.io/?EIO=4&transport=polling`)).status).toBe(200);
    // jalur berawalan tidak dikenal sebagai API tanpa BASE_PATH: dijawab halaman SPA seperti jalur asing mana pun, bukan JSON health
    expect((await fetch(`${base}${BASE}/health`)).headers.get("content-type")).toContain("text/html");
  });
});
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { addBots, ask, driveToPodium, startNet, toLobby, type NetRig, type SessionHandle } from "./netHarness";

let net: NetRig;
beforeAll(async () => {
  net = await startNet();
});
afterAll(async () => {
  await net.stop();
});

describe("titik integrasi SIMPETERI", () => {
  it("/health dapat dibaca dari asal lain (tanpa data siswa)", async () => {
    const r = await fetch(`${net.url}/health`);
    expect(r.headers.get("access-control-allow-origin")).toBe("*");
    expect(await r.json()).toMatchObject({ ok: true, game: "ROUTE_RUSH" });
  });

  it("/clips: daftar klip, berkas WAV, 404 untuk nama tidak sah (termasuk penelusuran folder)", async () => {
    const idx = (await (await fetch(`${net.url}/clips/index.json`)).json()) as { count: number; clips: string[] };
    expect(idx.count).toBe(25);
    expect(idx.clips[0]).toBe("01.wav");
    const r = await fetch(`${net.url}/clips/07.wav`);
    expect(r.status).toBe(200);
    expect(r.headers.get("access-control-allow-origin")).toBe("*");
    expect(r.headers.get("content-type")).toContain("audio");
    expect(new TextDecoder().decode((await r.arrayBuffer()).slice(0, 4))).toBe("RIFF");
    for (const bad of ["99.wav", "abc.wav", "..%2Fnames.txt", "01.mp3", "1.wav"]) expect((await fetch(`${net.url}/clips/${bad}`)).status, bad).toBe(404);
  });

  it("daftar siswa dengan nomor absen: absen tidak sah ditolak; absen ikut ke pengumuman hasil (tercepat dulu)", async () => {
    const host = net.connect();
    const bad = await ask(host, "host:create", { roster: [{ id: "siswa-1", name: "A", absen: 0 }], settings: { kind: "TEST" } });
    expect(bad.ok).toBe(false);
    const roster = [
      { id: "siswa-1", name: "Siswa Uji 1", kelas: "6C", absen: 3 },
      { id: "siswa-2", name: "Siswa Uji 2", kelas: "6C", absen: 12 },
      { id: "siswa-3", name: "Siswa Uji 3", kelas: "6C" },
    ];
    const summary = new Promise<{ correct: { name: string; absen: number | null }[]; wrong: number }>((resolve) => host.on("round:summary", resolve));
    const created = await ask<{ sessionId: string; code: string; hostToken: string }>(host, "host:create", { roster, settings: { kind: "TEST", introMode: "SHORT", roundIds: [1] } });
    expect(created.ok).toBe(true);
    const session = net.server.registry.get(created.sessionId)!;
    const h: SessionHandle = { host, session: session as never, id: created.sessionId, code: created.code, hostToken: created.hostToken };
    toLobby(net, h);
    await addBots(net, h, ["optimal", "optimal", "optimal"]);
    expect((await ask(host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).ok).toBe(true);
    await driveToPodium(net, h);
    const s = await summary;
    expect(s.wrong).toBe(0);
    expect(s.correct).toHaveLength(3);
    expect(s.correct.map((c) => c.absen).sort((a, b) => (a ?? 99) - (b ?? 99))).toEqual([3, 12, null]);
    expect(s.correct.find((c) => c.name === "Siswa Uji 2")?.absen).toBe(12);
  }, 60_000);
});
import { describe, expect, it } from "vitest";
import type { RoundSummaryItem } from "@route-rush/shared";
import { joinAll, makeRig, mapOf, optimalSubmit, playRound, runUntil } from "./harness";

const summaryOf = (rig: ReturnType<typeof makeRig>): { items: RoundSummaryItem[]; correct: unknown[]; wrong: number } => rig.rec.last("round:summary")!.payload as { items: RoundSummaryItem[]; correct: unknown[]; wrong: number };

describe("soal adaptif (pool Tantangan)", () => {
  it("siswa yang tepat dan cepat langsung naik tingkat: peta ronde berikutnya lebih besar", () => {
    const rig = makeRig({ n: 2, settings: { pool: "T", introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 1, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK"); // ronde latihan 0: peta latihan, bukan tingkat
    expect(mapOf(rig, "siswa-1").nodes.length).toBe(4);
    playRound(rig);
    runUntil(rig, "LOOK"); // ronde 1: tingkat 1
    expect(mapOf(rig, "siswa-1").nodes.length).toBe(8);
    playRound(rig);
    runUntil(rig, "LEADERBOARD");
    const result = rig.rec.last("round:result", "siswa-1")!.payload as { level?: number; optimal: boolean };
    expect(result.optimal).toBe(true);
    expect(result.level).toBe(3);
    runUntil(rig, "LOOK"); // ronde 2: tingkat 3 (10 tempat), waktu jalan mengikuti peta tersulit
    expect(mapOf(rig, "siswa-1").nodes.length).toBe(10);
    expect((rig.rec.last("phase")!.payload as { durationMs: number }).durationMs).toBe(10_000);
  });

  it("layar hasil memuat rute termurah, langkah, dan statistik tanpa nama siswa", () => {
    const rig = makeRig({ n: 2, settings: { pool: "T", introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 1, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "RESULT");
    const { items } = summaryOf(rig);
    expect(items.length).toBeGreaterThan(0);
    const first = items[0]!;
    expect(first.steps).toBe(first.optimalPath.length - 1);
    expect(first.solvers).toBeGreaterThan(0);
    expect(first.fastestMs).not.toBeNull();
    expect(JSON.stringify(items)).not.toContain("Siswa Uji");
  });

  it("pool A tetap memakai nomor ronde: empat soal setara dengan statistik", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT", mode: "QUICK" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "RESULT");
    const { items } = summaryOf(rig);
    expect(items).toHaveLength(4);
    expect(items.every((i) => i.optimalCost > 0 && i.steps > 0)).toBe(true);
  });
});

describe("hapus siswa dari sesi", () => {
  it("nama, hasil, dan peringkat siswa dibuang; siswa menerima pemberitahuan; sesi tertutup menolak", () => {
    const rig = makeRig({ n: 3, settings: { introMode: "SHORT", mode: "QUICK" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "LOOK");
    playRound(rig);
    runUntil(rig, "RESULT");
    expect(rig.session.results.some((r) => r.studentId === "siswa-2")).toBe(true);
    expect(rig.session.removePlayer("siswa-2")).toMatchObject({ ok: true });
    expect(rig.session.results.some((r) => r.studentId === "siswa-2")).toBe(false);
    expect(rig.session.playerList.some((p) => p.id === "siswa-2")).toBe(false);
    expect(rig.rec.last("player:released", "siswa-2")).toBeDefined();
    expect(rig.session.removePlayer("siswa-2")).toMatchObject({ ok: false, error: "NOT_FOUND" });
    runUntil(rig, "LEADERBOARD");
    const top = (rig.rec.last("leaderboard")!.payload as { top5: { nickname: string }[] }).top5;
    expect(top.map((t) => t.nickname)).not.toContain("Siswa Uji 2");
    rig.session.end();
    expect(rig.session.removePlayer("siswa-1")).toMatchObject({ ok: false, error: "WRONG_PHASE" });
  });

  it("menghapus siswa yang ditunggu saat jalan: ronde berakhir bila sisanya sudah mengirim", () => {
    const rig = makeRig({ n: 2, settings: { introMode: "SHORT", mode: "QUICK" } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "WALK");
    expect(rig.session.removePlayer("siswa-2")).toMatchObject({ ok: true });
    expect(rig.session.phase).toBe("WALK");
    playRound(rig, { skip: [] });
    expect(["RESULT", "LEADERBOARD", "LOOK"]).toContain(rig.session.phase);
  });
});

describe("soal ingatan dipadukan dengan Tantangan, waktu ingatan sampai 180 detik", () => {
  it("ronde yang ditandai ingatan: angka hilang saat berjalan, lalu fase PROBE selama waktu yang diatur", () => {
    const rig = makeRig({ n: 2, settings: { pool: "T", introMode: "SHORT", mode: "QUICK", roundIds: [1, 2], hiddenRounds: [2], probeSeconds: 120, seatLayout: { rows: 1, cols: 2, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    playRound(rig); // ronde 1 (hitung) selesai dikirim
    runUntil(rig, "LOOK");
    expect((rig.rec.last("phase")!.payload as { condition?: string }).condition).toBe("HIDDEN");
    runUntil(rig, "WALK");
    expect(rig.rec.last("round:hideWeights")).toBeDefined();
    for (const id of rig.ids) rig.session.routeSubmit(id, optimalSubmit(rig, id, 2));
    while (rig.session.phase === "WALK") rig.clock.runNext();
    expect(rig.session.phase).toBe("PROBE");
    expect((rig.rec.last("phase")!.payload as { durationMs: number }).durationMs).toBe(120_000);
    // jawaban setelah 100 detik masih sah (tidak ditolak oleh pemeriksaan integritas)
    for (const id of rig.ids) {
      const q = rig.rec.last("probe:question", id)!.payload as { edgeId: string };
      const w = mapOf(rig, id).edges.find((e) => e.id === q.edgeId)!.w;
      expect(rig.session.probeAnswer(id, { roundId: 2, value: w, clientElapsedMs: 100_000 })).toMatchObject({ ok: true });
    }
    runUntil(rig, "RESULT");
    expect(rig.session.rejected).toBe(0);
    expect(rig.session.results.filter((r) => r.roundId === 2).every((r) => r.probeCorrect === true && r.probeMs === 100_000)).toBe(true);
  });
});
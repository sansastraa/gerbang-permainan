import { existsSync, readdirSync } from "node:fs";
import { join } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { io } from "socket.io-client";
import { createGameServer } from "../src/index";
import { addBots, advanceTo, ask, createSession, driveToPodium, rosterOf, startNet, toLobby, waitFor, BotDevice, type NetRig } from "./netHarness";

const FORBIDDEN_KEYS = ["optimalCost", "optimalPath", "optimalRoute", "probeEdgeId", "golden", "secondBestGap"];
const hasKey = (value: unknown, keys: readonly string[]): boolean => JSON.stringify(value).split('"').some((s, i) => i % 2 === 1 && keys.includes(s));

let net: NetRig | null = null;
afterEach(async () => {
  await net?.stop();
  net = null;
});

describe("sesi lengkap: 1 host + 3 bot (FULL/SHORT × Standar/Kilat)", () => {
  const combos = [
    { introMode: "FULL", mode: "STANDARD", scored: 10, practice: 0 },
    { introMode: "FULL", mode: "QUICK", scored: 6, practice: 0 },
    { introMode: "SHORT", mode: "STANDARD", scored: 10, practice: 1 },
    { introMode: "SHORT", mode: "QUICK", scored: 6, practice: 1 },
  ] as const;

  for (const c of combos) {
    it(`${c.introMode} ${c.mode}: intro → PIN → bot masuk → mulai → podium; hasil tersimpan sebagai sesi TEST`, async () => {
      net = await startNet();
      const h = await createSession(net, 3, { introMode: c.introMode, mode: c.mode });
      const hostSeen: string[] = [];
      h.host.onAny((e: string) => hostSeen.push(e));

      // PIN baru bisa dipakai setelah intro
      const early = net.connect();
      expect(await ask(early, "player:join", { code: h.code })).toMatchObject({ ok: false, error: "NOT_OPEN" });
      toLobby(net, h);
      const bots = await addBots(net, h, ["optimal", "optimal", "optimal"]);
      expect(h.session.lobbyView()).toMatchObject({ joined: 3, quota: 3, seatsPending: 0, canStart: true });

      expect(await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: true });
      await driveToPodium(net, h);

      const rounds = c.scored + c.practice;
      expect(h.session.results).toHaveLength(3 * rounds);
      expect(h.session.results.some((r) => r.roundId === 0)).toBe(c.practice === 1);
      expect(h.session.rejected).toBe(0);
      expect(h.session.results.every((r) => r.completed && r.optimalHit && !r.timedOut && !r.missed)).toBe(true);
      if (c.introMode === "FULL") {
        expect(h.session.tutorialResults).toHaveLength(3);
        expect(h.session.tutorialResults.every((t) => t.isBot && t.result.completed)).toBe(true);
      } else expect(h.session.tutorialResults).toHaveLength(0);
      await waitFor(() => hostSeen.includes("podium"), 2000, "podium sampai ke guru");
      expect(hostSeen).toEqual(expect.arrayContaining(["phase", "lobby:update", "walk:status", "round:summary", "leaderboard", "podium"]));

      // sesi TEST tersimpan di test-sessions, bukan sessions
      const lines = net.server.store.read("TEST", h.id);
      expect(lines.filter((e) => e.type === "round")).toHaveLength(3 * rounds);
      expect(net.server.store.read("LIVE", h.id)).toEqual([]);
      expect(existsSync(join(net.dataDir, "sessions"))).toBe(false);
      expect(readdirSync(join(net.dataDir, "test-sessions"))).toEqual([`${h.id}.jsonl`]);
      expect(lines.some((e) => e.type === "player" && e.isBot === true)).toBe(true);

      // A2: sebelum round:reveal pertama tidak ada kunci jawaban di jaringan
      for (const bot of bots) {
        const early = bot.eventsBefore("round:reveal");
        expect(early.some((e) => e.event === "round:map")).toBe(true);
        for (const e of early) expect(hasKey(e.payload, FORBIDDEN_KEYS), e.event).toBe(false);
      }
      expect(await ask(h.host, "host:end", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: true });
      expect(net.server.registry.size).toBe(0);
    }, 60000);
  }
});

describe("timeout dan missed lewat jaringan", () => {
  it("bot yang diam → timedOut di setiap ronde; bot yang terputus sebelum ronde → missed; siswa lain tidak terpengaruh", async () => {
    net = await startNet();
    const h = await createSession(net, 3, { introMode: "SHORT", mode: "QUICK", roundIds: [1, 2] });
    toLobby(net, h);
    const bots = await addBots(net, h, ["optimal", "silent", "optimal"]);
    await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken });
    advanceTo(net, h, "LOOK");
    bots[2]!.socket.close(); // terputus sebelum WALK, tetap terlihat saat ronde dimulai → timeout, bukan missed
    await driveToPodium(net, h, 250);
    const by = (id: string) => h.session.results.filter((r) => r.studentId === id);
    expect(by("siswa-1").every((r) => r.optimalHit)).toBe(true);
    expect(by("siswa-2").every((r) => r.timedOut && r.racePoints === 0)).toBe(true);
    expect(by("siswa-3").every((r) => r.timedOut || r.missed)).toBe(true);
    expect(h.session.playerList.find((p) => p.id === "siswa-1")!.totalPoints).toBeGreaterThan(0);
  }, 60000);
});

describe("alur siswa manusia: PIN → nama → kursi → menunggu", () => {
  it("PIN salah, nama sudah dipakai, kuota, kursi, lalu mulai", async () => {
    net = await startNet();
    const h = await createSession(net, 2, { introMode: "SHORT", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: true } });
    const a = net.connect();
    const b = net.connect();
    expect(await ask(a, "player:join", { code: "000000" })).toMatchObject({ ok: false, error: "PIN_INVALID" });
    toLobby(net, h);
    const join = await ask<{ roster: { id: string; taken: boolean }[] }>(a, "player:join", { code: h.code });
    expect(join).toMatchObject({ ok: true });
    expect(join.roster.map((r) => r.id)).toEqual(["siswa-1", "siswa-2"]);
    await ask(b, "player:join", { code: h.code });
    const claimA = await ask<{ studentId: string; studentToken: string }>(a, "player:claim", { rosterId: "siswa-1" });
    expect(claimA).toMatchObject({ ok: true, studentId: "siswa-1" });
    expect(await ask(b, "player:claim", { rosterId: "siswa-1" })).toMatchObject({ ok: false, error: "NAME_TAKEN" });
    expect(await ask(b, "player:claim", { rosterId: "siswa-9" })).toMatchObject({ ok: false, error: "NAME_UNKNOWN" });
    expect(await ask(b, "player:claim", { rosterId: "siswa-2" })).toMatchObject({ ok: true });

    expect(await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: false, error: "SEATS_PENDING" });
    expect(await ask(a, "player:seat", { row: 0, col: 0 })).toMatchObject({ ok: true });
    expect(await ask(b, "player:seat", { row: 0, col: 0 })).toMatchObject({ ok: false, error: "SEAT_TAKEN" });
    expect(await ask(b, "player:seat", { row: 1, col: 1 })).toMatchObject({ ok: true });
    expect(h.session.lobbyView()).toMatchObject({ joined: 2, canStart: true });
    expect(await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: true });
    // setelah mulai, PIN tidak menerima nama baru
    const late = net.connect();
    expect(await ask(late, "player:join", { code: h.code })).toMatchObject({ ok: false, error: "SESSION_STARTED" });
  }, 30000);

  it("A6: token yang sama dari perangkat kedua ditolak dan dicatat SECOND_DEVICE; guru mendapat notifikasi", async () => {
    net = await startNet();
    const h = await createSession(net, 2, { introMode: "SHORT" });
    const alerts: unknown[] = [];
    h.host.on("integrity:alert", (p: unknown) => alerts.push(p));
    toLobby(net, h);
    const first = net.connect();
    await ask(first, "player:join", { code: h.code });
    const claim = await ask<{ studentToken: string }>(first, "player:claim", { rosterId: "siswa-1" });
    const second = net.connect();
    expect(await ask(second, "player:join", { code: h.code, studentToken: claim.studentToken })).toMatchObject({ ok: false, error: "SECOND_DEVICE" });
    await waitFor(() => alerts.length === 1, 1000, "notifikasi guru");
    expect(h.session.playerList.find((p) => p.id === "siswa-1")!.flags).toContain("SECOND_DEVICE");
    first.close();
    await waitFor(() => h.session.lobbyView().players.find((p) => p.id === "siswa-1")!.connected === false, 1000, "putus");
    expect(await ask(second, "player:join", { code: h.code, studentToken: claim.studentToken })).toMatchObject({ ok: true, me: { studentId: "siswa-1" } });
  }, 30000);
});

describe("otorisasi guru dan pengaturan", () => {
  it("event guru wajib membawa token guru; siswa tidak bisa memulai atau mengubah pengaturan", async () => {
    net = await startNet();
    const h = await createSession(net, 1, { introMode: "SHORT" });
    toLobby(net, h);
    const intruder = net.connect();
    expect(await ask(intruder, "host:start", { sessionId: h.id, hostToken: "salah" })).toMatchObject({ ok: false, error: "FORBIDDEN" });
    expect(await ask(intruder, "host:settings", { sessionId: h.id, hostToken: "salah", settings: { quota: 1 } })).toMatchObject({ ok: false, error: "FORBIDDEN" });
    expect(await ask(intruder, "host:start", { sessionId: "tidak-ada", hostToken: "x" })).toMatchObject({ ok: false, error: "SESSION_NOT_FOUND" });
    expect(await ask(intruder, "host:attach", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: true, phase: "LOBBY" });
    expect(await ask(intruder, "route:submit", {})).toMatchObject({ ok: false, error: "NOT_CLAIMED" });
  }, 30000);

  it("menu pengaturan lewat socket: waktu hafal dan kuota berlaku; nilai tidak sah ditolak", async () => {
    net = await startNet();
    const h = await createSession(net, 2, { introMode: "SHORT", mode: "QUICK", seatLayout: { rows: 2, cols: 2, aisleAfterCols: [], enabled: false } });
    const phases: { phase: string; roundId?: number; durationMs: number | null }[] = [];
    h.host.on("phase", (p: { phase: string; roundId?: number; durationMs: number | null }) => phases.push(p));
    toLobby(net, h);
    const bots = await addBots(net, h, ["optimal"]);
    expect(await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: false, error: "QUOTA_NOT_MET" });
    expect(await ask(h.host, "host:settings", { sessionId: h.id, hostToken: h.hostToken, settings: { lookSeconds: 1 } })).toMatchObject({ ok: false, error: "INVALID_SETTINGS" });
    expect(await ask(h.host, "host:settings", { sessionId: h.id, hostToken: h.hostToken, settings: { lookSeconds: 15, walkSeconds: 45, quota: 1, roundIds: [1] } })).toMatchObject({ ok: true });
    expect(await ask(h.host, "host:start", { sessionId: h.id, hostToken: h.hostToken })).toMatchObject({ ok: true });
    await driveToPodium(net, h);
    expect(phases.find((p) => p.phase === "LOOK")).toMatchObject({ roundId: 1, durationMs: 15_000 });
    expect(phases.find((p) => p.phase === "WALK")).toMatchObject({ durationMs: 45_000 });
    expect(h.session.results).toHaveLength(1);
    void bots;
  }, 30000);
});

describe("T27 server produksi", () => {
  it("event pembuat bot tidak dikenal sama sekali dan tidak ada pemain baru", async () => {
    net = await startNet({ nodeEnv: "production" });
    expect(net.server.allowBots).toBe(false);
    const h = await createSession(net, 2, { introMode: "SHORT" });
    toLobby(net, h);
    const s = net.connect();
    const outcome = await new Promise<"timeout" | "dijawab">((resolve) => {
      s.timeout(400).emit("test:addBot", { code: h.code, rosterId: "siswa-1" }, (err: Error | null) => resolve(err ? "timeout" : "dijawab"));
    });
    expect(outcome).toBe("timeout"); // tidak ada penangan, jadi tidak ada jawaban
    expect(h.session.playerList).toHaveLength(0);
    expect(h.session.lobbyView().joined).toBe(0);
  }, 30000);

  it("server mode test mendaftarkan event bot; server simulasi (SIMULATE) juga", async () => {
    net = await startNet({ nodeEnv: "development", simulate: true });
    expect(net.server.allowBots).toBe(true);
    const plain = createGameServer({ dataDir: net.dataDir, nodeEnv: "development" });
    expect(plain.allowBots).toBe(false);
    await plain.close();
  }, 30000);

  it("sesi LIVE di server test tetap menolak bot dan menyimpan ke folder sessions", async () => {
    net = await startNet();
    const h = await createSession(net, 1, { introMode: "SHORT", kind: "LIVE" });
    toLobby(net, h);
    const bot = new BotDevice(net);
    expect(await ask(bot.socket, "test:addBot", { code: h.code, rosterId: "siswa-1" })).toMatchObject({ ok: false, error: "BOTS_DISABLED" });
    expect(h.session.playerList.some((p) => p.isBot)).toBe(false);
    expect(existsSync(join(net.dataDir, "sessions", `${h.id}.jsonl`))).toBe(true);
    expect(existsSync(join(net.dataDir, "test-sessions"))).toBe(false);
  }, 30000);
});

describe("pembuatan sesi", () => {
  it("daftar siswa kosong, ganda, atau tanpa nama ditolak; /health menjawab", async () => {
    net = await startNet();
    const host = net.connect();
    expect(await ask(host, "host:create", { roster: [] })).toMatchObject({ ok: false, error: "INVALID_SETTINGS" });
    expect(await ask(host, "host:create", { roster: [{ id: "a", name: "A" }, { id: "a", name: "B" }] })).toMatchObject({ ok: false });
    expect(await ask(host, "host:create", { roster: [{ id: "a", name: "" }] })).toMatchObject({ ok: false });
    expect(await ask(host, "host:create", { roster: rosterOf(2), settings: { quota: 5 } })).toMatchObject({ ok: false });
    expect(await ask(host, "host:create", {})).toMatchObject({ ok: false });
    const res = await fetch(`${net.url}/health`);
    expect(await res.json()).toMatchObject({ ok: true, game: "ROUTE_RUSH" });
    const raw = io(net.url, { transports: ["websocket"], forceNew: true });
    raw.close();
  }, 30000);

  it("PIN 6 digit dibuat di dalam game dan unik antar sesi aktif", async () => {
    net = await startNet();
    const codes = new Set<string>();
    for (let i = 0; i < 8; i++) {
      const h = await createSession(net, 1, { introMode: "SHORT" });
      expect(h.code).toMatch(/^\d{6}$/);
      codes.add(h.code);
    }
    expect(codes.size).toBe(8);
  }, 30000);
});

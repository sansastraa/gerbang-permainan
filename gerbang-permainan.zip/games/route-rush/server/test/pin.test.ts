import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { io, type Socket } from "socket.io-client";
import { afterEach, describe, expect, it } from "vitest";
import { isValidHostToken } from "@route-rush/shared";
import { FailureGuard, tokenEquals } from "../src/guard";
import { createGameServer, type GameServer } from "../src/index";
import { ask, rosterOf } from "./netHarness";

describe("PIN guru: validasi dan pembatas", () => {
  it("PIN sah 4–32 karakter tanpa karakter kontrol dan tanpa spasi di tepi", () => {
    expect(isValidHostToken("abcd")).toBe(true);
    expect(isValidHostToken("a".repeat(32))).toBe(true);
    expect(isValidHostToken("abc")).toBe(false);
    expect(isValidHostToken("a".repeat(33))).toBe(false);
    expect(isValidHostToken(" abcd")).toBe(false);
    expect(isValidHostToken("ab\ncd")).toBe(false);
    expect(isValidHostToken(123456)).toBe(false);
    expect(isValidHostToken(undefined)).toBe(false);
  });

  it("tokenEquals membandingkan nilai, bukan panjang atau awalan", () => {
    expect(tokenEquals("guru-1234", "guru-1234")).toBe(true);
    expect(tokenEquals("guru-1234", "guru-1235")).toBe(false);
    expect(tokenEquals("guru", "guru-1234")).toBe(false);
  });

  it("FailureGuard mengunci kunci yang salah berulang dan melepasnya setelah jeda; kunci lain bebas", () => {
    let t = 0;
    const g = new FailureGuard(3, 1000, 5000, () => t);
    for (let i = 0; i < 3; i++) g.fail("a");
    expect(g.blocked("a")).toBe(true);
    expect(g.blocked("b")).toBe(false);
    t = 4999;
    expect(g.blocked("a")).toBe(true);
    t = 5001;
    expect(g.blocked("a")).toBe(false);
    g.fail("c");
    g.ok("c");
    for (let i = 0; i < 2; i++) g.fail("c");
    expect(g.blocked("c")).toBe(false);
  });
});

describe("PIN guru lewat server: host:create, ekspor, CORS", () => {
  const dirs: string[] = [];
  const servers: GameServer[] = [];
  const sockets: Socket[] = [];
  afterEach(async () => {
    for (const s of sockets.splice(0)) s.close();
    for (const s of servers.splice(0)) await s.close();
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true });
  });

  async function start(allowedOrigins: "any" | "same-origin" | string[] = ["https://simpeteri.example.id"]): Promise<{ base: string; host: Socket; server: GameServer }> {
    const dir = mkdtempSync(join(tmpdir(), "rr-pin-"));
    dirs.push(dir);
    const server = createGameServer({ dataDir: join(dir, "data"), port: 0, host: "127.0.0.1", staticDir: join(dir, "kosong"), allowedOrigins, nodeEnv: "test" });
    servers.push(server);
    const base = `http://127.0.0.1:${await server.listen()}`;
    const host = io(base, { transports: ["websocket"] });
    sockets.push(host);
    await new Promise<void>((resolve) => host.on("connect", () => resolve()));
    return { base, host, server };
  }

  const create = (host: Socket, hostToken?: string) => ask<{ sessionId: string; hostToken: string }>(host, "host:create", { roster: rosterOf(2), settings: { kind: "TEST" }, ...(hostToken === undefined ? {} : { hostToken }) });

  it("host:create memakai PIN sebagai token guru; tanpa PIN token acak; PIN tidak sah ditolak", async () => {
    const { host } = await start();
    const withPin = await create(host, "guru-1234");
    expect(withPin).toMatchObject({ ok: true, hostToken: "guru-1234" });
    expect(await ask(host, "host:attach", { sessionId: withPin.sessionId, hostToken: "guru-1234" })).toMatchObject({ ok: true });
    expect(await ask(host, "host:attach", { sessionId: withPin.sessionId, hostToken: "guru-9999" })).toMatchObject({ ok: false, error: "FORBIDDEN" });
    const random = await create(host);
    expect(random.ok).toBe(true);
    expect(random.hostToken).not.toBe("guru-1234");
    expect(random.hostToken.length).toBeGreaterThan(16);
    for (const bad of ["abc", "x".repeat(33), " tepi ", "a\nb"]) {
      const r = await create(host, bad);
      expect(r).toMatchObject({ ok: false, error: "INVALID_SETTINGS" });
      expect(JSON.stringify(r)).not.toContain(bad.trim() || "zzz-tidak-ada");
    }
  });

  it("summary.json: 404 tidak ada, 401 PIN salah, 403 belum selesai (lintas asal), 200 sesudah berakhir dengan PIN benar", async () => {
    const { base, host } = await start();
    expect((await fetch(`${base}/api/sessions/rr-tidakada/summary.json?includeTest=1`, { headers: { "x-host-token": "guru-1234" } })).status).toBe(404);
    const c = await create(host, "guru-1234");
    const url = `${base}/api/sessions/${c.sessionId}/summary.json?includeTest=1`;
    // sesi berjalan
    expect((await fetch(url)).status).toBe(401);
    expect((await fetch(url, { headers: { "x-host-token": "salah" } })).status).toBe(401);
    const same = await fetch(url, { headers: { "x-host-token": "guru-1234" } }); // layar guru sendiri: sama asal, tanpa Origin
    expect(same.status).toBe(200);
    expect(await same.json()).toHaveProperty("students");
    const cross = await fetch(url, { headers: { "x-host-token": "guru-1234", Origin: "https://simpeteri.example.id" } });
    expect(cross.status).toBe(403);
    expect(await cross.json()).toMatchObject({ error: "BELUM_SELESAI" });
    // sesi berakhir: token tidak lagi di memori, tetapi hash-nya tersimpan bersama data
    expect(await ask(host, "host:skipIntro", { sessionId: c.sessionId, hostToken: "guru-1234" })).toMatchObject({ ok: true });
    expect(await ask(host, "host:end", { sessionId: c.sessionId, hostToken: "guru-1234" })).toMatchObject({ ok: true });
    expect((await fetch(url)).status).toBe(401);
    expect((await fetch(url, { headers: { "x-host-token": "salah" } })).status).toBe(401);
    const done = await fetch(url, { headers: { "x-host-token": "guru-1234", Origin: "https://simpeteri.example.id" } });
    expect(done.status).toBe(200);
    expect(await done.json()).toHaveProperty("students");
  });

  it("token guru tidak tertulis polos di berkas data sesi", async () => {
    const { host, server } = await start();
    const c = await create(host, "guru-rahasia-9");
    const raw = [...server.store.read("TEST", c.sessionId), ...server.store.read("LIVE", c.sessionId)];
    expect(raw.some((e) => e.type === "auth")).toBe(true);
    expect(JSON.stringify(raw)).not.toContain("guru-rahasia-9");
  });

  it("percobaan token salah berulang dikunci (429), termasuk untuk token benar dari alamat yang sama", async () => {
    const { base, host } = await start();
    const c = await create(host, "guru-1234");
    const url = `${base}/api/sessions/${c.sessionId}/summary.json?includeTest=1`;
    for (let i = 0; i < 8; i++) expect((await fetch(url, { headers: { "x-host-token": `salah-${i}` } })).status).toBe(401);
    expect((await fetch(url, { headers: { "x-host-token": "salah-lagi" } })).status).toBe(429);
    expect((await fetch(url, { headers: { "x-host-token": "guru-1234" } })).status).toBe(429);
  });

  it("percobaan token salah lewat socket juga dikunci", async () => {
    const { host } = await start();
    const c = await create(host, "guru-1234");
    for (let i = 0; i < 8; i++) expect(await ask(host, "host:attach", { sessionId: c.sessionId, hostToken: `salah-${i}` })).toMatchObject({ ok: false, error: "FORBIDDEN" });
    expect(await ask(host, "host:attach", { sessionId: c.sessionId, hostToken: "guru-1234" })).toMatchObject({ ok: false, error: "FORBIDDEN" });
  });

  it("CORS ekspor: asal terdaftar boleh (OPTIONS 204 dengan x-host-token), asal lain tidak", async () => {
    const { base, host } = await start(["https://simpeteri.example.id"]);
    const c = await create(host, "guru-1234");
    const url = `${base}/api/sessions/${c.sessionId}/summary.json?includeTest=1`;
    const pre = await fetch(url, { method: "OPTIONS", headers: { Origin: "https://simpeteri.example.id", "Access-Control-Request-Method": "GET", "Access-Control-Request-Headers": "x-host-token" } });
    expect(pre.status).toBe(204);
    expect(pre.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example.id");
    expect(pre.headers.get("access-control-allow-headers")).toContain("x-host-token");
    expect(pre.headers.get("vary")).toContain("Origin");
    const get = await fetch(url, { headers: { Origin: "https://simpeteri.example.id", "x-host-token": "guru-1234" } });
    expect(get.status).toBe(403); // sesi masih berjalan; yang dicek di sini hanya header CORS-nya
    expect(get.headers.get("access-control-allow-origin")).toBe("https://simpeteri.example.id");
    const other = await fetch(url, { method: "OPTIONS", headers: { Origin: "https://jahat.example" } });
    expect(other.headers.get("access-control-allow-origin")).toBeNull();
    const noOrigin = await fetch(url, { headers: { "x-host-token": "guru-1234" } });
    expect(noOrigin.headers.get("access-control-allow-origin")).toBeNull();
  });

  it("same-origin: tidak ada izin CORS ekspor dari asal mana pun", async () => {
    const { base, host } = await start("same-origin");
    const c = await create(host, "guru-1234");
    const res = await fetch(`${base}/api/sessions/${c.sessionId}/summary.json?includeTest=1`, { headers: { Origin: "https://simpeteri.example.id", "x-host-token": "guru-1234" } });
    expect(res.headers.get("access-control-allow-origin")).toBeNull();
  });
});

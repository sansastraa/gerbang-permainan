import { describe, expect, it } from "vitest";
import { mapShapeKey, optimalCost, poolItem, type RoundSummaryItem } from "@route-rush/shared";
import { bankOnce, joinAll, makeRig, mapOf, playRound, runUntil } from "./harness";

const lookMaps = (rig: ReturnType<typeof makeRig>) => rig.ids.map((id) => mapOf(rig, id));

describe("soal beda untuk tiap siswa (anti contek)", () => {
  it("bank A: tiap siswa mendapat peta berbeda yang setara tingkatnya dengan soal acuan ronde itu", () => {
    const rig = makeRig({ n: 8, settings: { introMode: "SHORT", mode: "QUICK", uniqueMaps: true, roundIds: [1, 2], seatLayout: { rows: 2, cols: 4, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    const maps = lookMaps(rig);
    expect(new Set(maps.map(mapShapeKey)).size).toBe(8);
    expect(new Set(maps.map((m) => m.id)).size).toBe(8);
    const pool = bankOnce().pools.A;
    const reference = [0, 1, 2, 3].map((slot) => poolItem(pool, 1, slot));
    for (const m of maps) {
      expect(m.nodes.length).toBe(reference[0]!.nodes.length);
      expect(m.stops.length).toBe(reference[0]!.stops.length);
      const cost = optimalCost(m);
      expect(reference.some((r) => Math.abs(optimalCost(r) - cost) <= 3)).toBe(true);
    }
  }, 120_000);

  it("rute optimal dari peta unik dinilai benar dan ringkasan ronde tetap memuat soal yang dipakai siswa", () => {
    const rig = makeRig({ n: 6, settings: { introMode: "SHORT", mode: "QUICK", uniqueMaps: true, roundIds: [1], seatLayout: { rows: 2, cols: 3, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    playRound(rig);
    expect(rig.session.results.filter((r) => r.roundId === 1)).toHaveLength(6);
    expect(rig.session.results.every((r) => r.optimalHit)).toBe(true);
    expect(rig.session.rejected).toBe(0);
    const items = (rig.rec.last("round:summary")!.payload as { items: RoundSummaryItem[] }).items;
    expect(items.length).toBeGreaterThan(0);
    expect(items.length).toBeLessThanOrEqual(4);
    expect(new Set(rig.session.results.map((r) => r.itemId)).size).toBe(6);
  }, 120_000);

  it("Tantangan: soal pertama paling mudah (tingkat 1) tetapi bentuknya beda tiap siswa", () => {
    const rig = makeRig({ n: 6, settings: { pool: "T", introMode: "SHORT", mode: "QUICK", uniqueMaps: true, roundIds: [1, 2], seatLayout: { rows: 2, cols: 3, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    const maps = lookMaps(rig);
    expect(maps.every((m) => m.nodes.length === 8)).toBe(true);
    expect(new Set(maps.map(mapShapeKey)).size).toBe(6);
  }, 120_000);

  it("bawaan (uniqueMaps mati): perilaku lama, hanya empat soal setara yang beredar", () => {
    const rig = makeRig({ n: 8, settings: { introMode: "SHORT", mode: "QUICK", roundIds: [1], seatLayout: { rows: 2, cols: 4, aisleAfterCols: [], enabled: true } } });
    joinAll(rig);
    rig.session.start();
    runUntil(rig, "LOOK");
    expect(new Set(lookMaps(rig).map((m) => m.id)).size).toBeLessThanOrEqual(4);
  });
});

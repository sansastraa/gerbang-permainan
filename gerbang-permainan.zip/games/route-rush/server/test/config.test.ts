import { mkdtempSync, rmSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { normalizeBasePath, normalizeOrigin, readEnvConfig } from "../src/config";
import { createGameServer, type GameServer } from "../src/index";

describe("pengaturan dari variabel lingkungan", () => {
  it("bawaan pengembangan: port 3000, semua antarmuka, semua asal, ./data", () => {
    const c = readEnvConfig({}, "/app");
    expect(c).toMatchObject({ port: 3000, host: "0.0.0.0", nodeEnv: "development", simulate: false, allowedOrigins: "any", trustProxy: false, warnings: [] });
    expect(c.dataDir.replaceAll("\\", "/")).toMatch(/\/app\/data$/);
  });

  it("produksi: hanya satu asal kecuali didaftarkan; peringatan bila DATA_DIR kosong", () => {
    const c = readEnvConfig({ NODE_ENV: "production" });
    expect(c.allowedOrigins).toBe("same-origin");
    expect(c.warnings.join(" ")).toContain("DATA_DIR");
    expect(readEnvConfig({ NODE_ENV: "production", DATA_DIR: "/data" }).warnings).toEqual([]);
  });

  it("PORT, HOST, DATA_DIR, TRUST_PROXY dibaca; nilai rusak diganti bawaan dengan peringatan", () => {
    const c = readEnvConfig({ PORT: "8080", HOST: "127.0.0.1", DATA_DIR: "/var/rr", TRUST_PROXY: "1" }, "/x");
    expect(c).toMatchObject({ port: 8080, host: "127.0.0.1", trustProxy: 1 });
    expect(c.dataDir.replaceAll("\\", "/")).toMatch(/\/var\/rr$/);
    expect(readEnvConfig({ TRUST_PROXY: "true" }).trustProxy).toBe(true);
    expect(readEnvConfig({ TRUST_PROXY: "false" }).trustProxy).toBe(false);
    const bad = readEnvConfig({ PORT: "abc", TRUST_PROXY: "mungkin" });
    expect(bad.port).toBe(3000);
    expect(bad.warnings).toHaveLength(2);
    expect(readEnvConfig({ PORT: "70000" }).warnings[0]).toContain("PORT");
  });

  it("ALLOWED_ORIGINS: daftar dinormalkan, duplikat dibuang, alamat rusak dilewati; * berarti semua", () => {
    const c = readEnvConfig({ NODE_ENV: "production", DATA_DIR: "/d", ALLOWED_ORIGINS: "https://a.example.id/, https://a.example.id, ftp://x, bukan-url" });
    expect(c.allowedOrigins).toEqual(["https://a.example.id"]);
    expect(c.warnings).toHaveLength(2);
    expect(readEnvConfig({ ALLOWED_ORIGINS: "*" }).allowedOrigins).toBe("any");
    expect(readEnvConfig({ NODE_ENV: "production", DATA_DIR: "/d", ALLOWED_ORIGINS: "*" }).warnings[0]).toContain("produksi");
    expect(readEnvConfig({ NODE_ENV: "production", DATA_DIR: "/d", ALLOWED_ORIGINS: "xyz" }).allowedOrigins).toBe("same-origin");
    expect(readEnvConfig({ ALLOWED_ORIGINS: "xyz" }).allowedOrigins).toBe("any");
    expect(normalizeOrigin("https://contoh.id/path?q=1")).toBe("https://contoh.id");
    expect(normalizeOrigin("javascript:alert(1)")).toBeNull();
  });

  it("BASE_PATH dinormalkan; kosong berarti dari akar; nilai berbahaya ditolak dengan peringatan", () => {
    expect(readEnvConfig({}).basePath).toBe("");
    expect(readEnvConfig({ BASE_PATH: "/games/route-rush/" }).basePath).toBe("/games/route-rush");
    expect(readEnvConfig({ BASE_PATH: "games/route-rush" }).basePath).toBe("/games/route-rush");
    expect(readEnvConfig({ BASE_PATH: "/" }).basePath).toBe("");
    expect(normalizeBasePath("/a/../b")).toBeNull();
    expect(normalizeBasePath("/a//b")).toBeNull();
    expect(normalizeBasePath("/a b")).toBeNull();
    expect(normalizeBasePath("/a?x=1")).toBeNull();
    const bad = readEnvConfig({ BASE_PATH: "/a/../b" });
    expect(bad.basePath).toBe("");
    expect(bad.warnings.join(" ")).toContain("BASE_PATH");
  });

  it("SIMULATE hanya berlaku di luar produksi", () => {
    expect(readEnvConfig({ SIMULATE: "1" }).simulate).toBe(true);
    const p = readEnvConfig({ NODE_ENV: "production", DATA_DIR: "/d", SIMULATE: "1" });
    expect(p.simulate).toBe(false);
    expect(p.warnings.join(" ")).toContain("SIMULATE");
  });
});

describe("server produksi: /health, header, dan asal Socket.IO", () => {
  const dirs: string[] = [];
  const servers: GameServer[] = [];
  afterEach(async () => {
    for (const s of servers.splice(0)) await s.close();
    for (const d of dirs.splice(0)) rmSync(d, { recursive: true, force: true });
  });

  async function start(opts: { allowedOrigins?: "any" | "same-origin" | string[]; nodeEnv?: string }): Promise<string> {
    const dir = mkdtempSync(join(tmpdir(), "rr-config-"));
    dirs.push(dir);
    const server = createGameServer({ dataDir: join(dir, "data"), port: 0, host: "127.0.0.1", staticDir: join(dir, "kosong"), ...opts });
    servers.push(server);
    return `http://127.0.0.1:${await server.listen()}`;
  }

  it("/health melaporkan keadaan, penyimpanan, dan header keamanan; tanpa X-Powered-By", async () => {
    const base = await start({ nodeEnv: "production", allowedOrigins: "same-origin" });
    const res = await fetch(`${base}/health`);
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ok: boolean; game: string; sessions: number; storageWritable: boolean; uptimeS: number };
    expect(body).toMatchObject({ ok: true, game: "ROUTE_RUSH", sessions: 0, storageWritable: true });
    expect(body.uptimeS).toBeGreaterThanOrEqual(0);
    expect(res.headers.get("x-content-type-options")).toBe("nosniff");
    expect(res.headers.get("referrer-policy")).toBe("no-referrer");
    expect(res.headers.get("x-powered-by")).toBeNull();
    expect(res.headers.get("access-control-allow-origin")).toBe("*");
  });

  const poll = (base: string, origin: string): Promise<Response> => fetch(`${base}/socket.io/?EIO=4&transport=polling`, { headers: { Origin: origin } });

  it("same-origin: halaman dari asal lain tidak mendapat izin CORS Socket.IO", async () => {
    const base = await start({ allowedOrigins: "same-origin" });
    const res = await poll(base, "https://jahat.example");
    expect(res.headers.get("access-control-allow-origin")).toBeNull();
  });

  it("daftar asal: hanya asal terdaftar yang diizinkan; any: semua", async () => {
    const listed = await start({ allowedOrigins: ["https://simpeteri.example.id"] });
    expect((await poll(listed, "https://simpeteri.example.id")).headers.get("access-control-allow-origin")).toBe("https://simpeteri.example.id");
    expect((await poll(listed, "https://lain.example")).headers.get("access-control-allow-origin")).toBeNull();
    const any = await start({ allowedOrigins: "any" });
    expect((await poll(any, "https://lain.example")).headers.get("access-control-allow-origin")).toBe("https://lain.example");
  });
});

import { useCallback, useState } from "react";
import { COPY } from "@route-rush/shared";
import { NameScreen, PinScreen, SeatScreen } from "./Join";
import { BoardScreen, EndedScreen, PodiumScreen, ProbeScreen, ResultScreen, RoundScreen } from "./Play";
import { ReadyScreen, seedOf } from "./Ready";
import { RulesSheet } from "./Rules";
import { Tutorial } from "./Tutorial";
import { useGame, useIntegrity, useNow } from "./hooks";
import type { GameClient, GameState } from "./store";

function Playing({ game, s }: { game: GameClient; s: GameState }) {
  const phase = s.phase?.phase;
  const remaining = useCallback((): number | null => {
    const end = game.state.phaseEndsAt;
    return end === null ? null : Math.max(0, end - performance.now());
  }, [game]);
  const send = useCallback((event: string, payload: unknown) => game.emitRaw(event, payload), [game]);
  const nickname = s.me?.name.split(/\s+/)[0] ?? "";
  const seed = seedOf(s.me?.studentId ?? "");
  const introMode = s.phase?.introMode ?? "FULL";

  switch (phase) {
    case undefined:
    case "INTRO_IDENT":
    case "INTRO_TRAILER":
    case "LOBBY":
      return <ReadyScreen nickname={nickname} countdownEndsAt={null} introMode={introMode} seed={seed} />;
    case "COUNTDOWN":
      return <ReadyScreen nickname={nickname} countdownEndsAt={s.phaseEndsAt} introMode={introMode} seed={seed} />;
    case "TUTORIAL":
      return <Tutorial tutorial={s.tutorial} remainingMs={remaining} send={send} />;
    case "LOOK":
    case "WALK":
      return <RoundScreen game={game} s={s} />;
    case "PROBE":
      return <ProbeScreen game={game} s={s} />;
    case "RESULT":
      return <ResultScreen s={s} />;
    case "LEADERBOARD":
      return <BoardScreen s={s} />;
    case "PODIUM":
      return <PodiumScreen s={s} />;
    case "ENDED":
      return <EndedScreen />;
  }
}

export function App({ game }: { game: GameClient }) {
  const s = useGame(game);
  const now = useNow(100);
  const integrity = useIntegrity(game, s.phase?.phase);
  const [rules, setRules] = useState(false);
  const ph = s.phase?.phase;
  // "Cara bermain" bisa dibuka saat menunggu di lobi dan selama latihan; tidak saat ronde berjalan (tidak memakan waktu bermain)
  const canHelp = s.stage === "play" && (ph === undefined || ph === "LOBBY" || ph === "TUTORIAL");

  let body;
  if (s.stage === "pin") body = <PinScreen game={game} error={s.error} />;
  else if (s.stage === "name") body = <NameScreen game={game} roster={s.roster} error={s.error} />;
  else if (s.stage === "seat" && s.seatLayout?.enabled) body = <SeatScreen game={game} layout={s.seatLayout} taken={s.seatsTaken} error={s.error} />;
  else body = <Playing game={game} s={s} />;

  const showGo = s.stage === "play" && now < s.goUntil;
  return (
    <div className="app" data-phase={s.phase?.phase ?? ""} data-stage={s.stage}>
      {!s.online ? (
        <div className="offline" role="status" data-testid="offline">
          {COPY.offline}
        </div>
      ) : null}
      {body}
      {canHelp ? (
        <button type="button" className={`help-btn${ph === "TUTORIAL" ? " compact" : " on-dark"}`} onClick={() => setRules(true)} aria-label={COPY.howToPlay} data-testid="help-btn">
          <i aria-hidden="true">?</i> <span className="lbl">{COPY.howToPlay}</span>
        </button>
      ) : null}
      {rules && canHelp ? <RulesSheet onClose={() => setRules(false)} /> : null}
      {showGo ? (
        <div className="go-layer" aria-hidden="true">
          <ReadyScreen nickname="" countdownEndsAt={null} introMode={s.phase?.introMode ?? "FULL"} go seed={1} />
        </div>
      ) : null}
      {integrity.needFullscreen ? (
        <div className="fs-overlay" role="alertdialog" aria-modal="true" data-testid="fullscreen-overlay">
          <p>{COPY.fullscreenBack}</p>
          <button type="button" className="btn primary" onClick={integrity.dismiss} data-testid="fullscreen-back">
            OK
          </button>
        </div>
      ) : null}
    </div>
  );
}

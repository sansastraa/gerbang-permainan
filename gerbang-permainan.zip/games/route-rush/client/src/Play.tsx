import { useCallback, useEffect, useRef, useState } from "react";
import { COPY, createRoute, routeCost, tapNode, undoLast, type NodeId, type RouteState } from "@route-rush/shared";
import { MapView } from "./MapView";
import { useNow } from "./hooks";
import type { GameClient, GameState } from "./store";

/** Bilah sisa waktu fase; merah saat sisa ≤ 5 detik. Hanya menggerakkan lebar (transform/width), tanpa kedipan. */
export function TimeBar({ endsAt, totalMs, label }: { endsAt: number | null; totalMs: number | null; label?: string }) {
  const now = useNow(100);
  if (endsAt === null || totalMs === null || totalMs <= 0) return null;
  const left = Math.max(0, endsAt - now);
  const danger = left <= 5000;
  return (
    <div className={`timebar${danger ? " danger" : ""}`} role="timer" aria-label={label ?? "Sisa waktu"} data-testid="timebar" data-danger={danger ? "1" : "0"}>
      <i style={{ width: `${Math.min(100, (100 * left) / totalMs).toFixed(1)}%` }} />
      <span data-testid="time-left">{Math.ceil(left / 1000)}</span>
    </div>
  );
}

/** Getar singkat di HP sebagai umpan balik ketukan (diam di perangkat tanpa getar). */
function buzz(ms: number): void {
  try {
    navigator.vibrate?.(ms);
  } catch {
    /* tanpa getar */
  }
}

function roundTitle(phase: GameState["phase"]): string {
  if (!phase) return "";
  if (phase.roundId === 0) return COPY.practice;
  return COPY.roundOf(phase.displayIndex ?? 1, phase.totalRounds);
}

/** LOOK dan WALK: satu RouteState per ronde, aturan ketukan dari shared/route.ts. */
export function RoundScreen({ game, s }: { game: GameClient; s: GameState }) {
  const { phase, round, phaseEndsAt } = s;
  const roundId = round?.roundId ?? -1;
  const [route, setRoute] = useState<RouteState | null>(null);
  const [shake, setShake] = useState<NodeId | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const sent = useRef<number | null>(null);
  const routeRef = useRef<RouteState | null>(null);
  const mapId = round?.map.id;

  // RouteState baru setiap peta ronde baru datang
  useEffect(() => {
    if (!round) return;
    const fresh = createRoute(round.map);
    routeRef.current = fresh;
    setRoute(fresh);
    setNotice(null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [roundId, mapId]);

  const walking = phase?.phase === "WALK";
  const walkStart = phaseEndsAt !== null && phase?.durationMs ? phaseEndsAt - phase.durationMs : performance.now();

  const apply = useCallback(
    (next: RouteState) => {
      routeRef.current = next;
      setRoute(next);
    },
    [],
  );

  const submit = useCallback(
    (final: RouteState) => {
      if (!round || sent.current === round.roundId) return;
      sent.current = round.roundId;
      const elapsed = Math.min(Math.max(0, Math.round(performance.now() - walkStart)), phase?.durationMs ?? Number.MAX_SAFE_INTEGER);
      const coins = round.showWeights ? routeCost(round.map, final.path) : null;
      game.submitRoute(
        { roundId: round.roundId, path: final.path, clientElapsedMs: elapsed, tapLog: final.tapLog, invalidTaps: final.invalidTaps, undo: final.undo, revisits: final.revisits },
        coins,
      );
    },
    [game, phase?.durationMs, round, walkStart],
  );

  const tap = (id: NodeId): void => {
    const cur = routeRef.current;
    if (!round || !cur || !walking || s.submitted?.roundId === round.roundId) return;
    const tMs = Math.max(0, Math.round(performance.now() - walkStart));
    const next = tapNode(round.map, cur, id, tMs, true);
    if (next === cur) return;
    if (next.invalidTaps > cur.invalidTaps) {
      setShake(id);
      buzz(45);
      window.setTimeout(() => setShake(null), 300);
      return;
    }
    buzz(10);
    apply(next);
    game.emitRaw("route:progress", { roundId: round.roundId, path: next.path, tMs });
    if (next.done) {
      setNotice(null);
      submit(next);
    } else setNotice(next.path.at(-1) === round.map.goal ? COPY.packagesMissing : null);
  };

  const undo = (): void => {
    const cur = routeRef.current;
    if (!round || !cur || !walking) return;
    const next = undoLast(round.map, cur, Math.max(0, Math.round(performance.now() - walkStart)), true);
    if (next !== cur) {
      apply(next);
      setNotice(null);
    }
  };

  if (!phase || !round || !route) {
    return (
      <section className="screen center" data-testid="round-wait">
        <p className="instruction">{COPY.waitNext}</p>
      </section>
    );
  }

  const hidden = phase.condition === "HIDDEN";
  const looking = phase.phase === "LOOK";
  const finished = s.submitted?.roundId === round.roundId || route.done;

  if (!looking && finished) {
    return (
      <section className="screen center" data-testid="round-arrived">
        <div className="done-badge" aria-hidden="true">✓</div>
        <h2 className="big-title">{COPY.arrived}</h2>
        {s.submitted?.coins != null ? (
          <p className="instruction" data-testid="arrived-coins">
            Total koin rutemu: <strong>{s.submitted.coins}</strong>
          </p>
        ) : null}
      </section>
    );
  }

  const coins = round.showWeights ? routeCost(round.map, route.path) : null;
  return (
    <section className="screen play" data-testid="round-screen" data-phase={phase.phase} data-condition={phase.condition ?? ""}>
      <header className="topline">
        <span className="chip" data-testid="round-title">{roundTitle(phase)}</span>
        {walking && coins !== null ? <span className="chip coin" key={coins} data-testid="coin-counter">{COPY.coins}: {coins}</span> : null}
      </header>
      <TimeBar endsAt={phaseEndsAt} totalMs={phase.durationMs} />
      {looking ? (
        <div className="look-banner" data-testid="look-banner">
          <h2>{COPY.look}</h2>
          {hidden ? <p data-testid="will-hide">{COPY.willHide}</p> : null}
        </div>
      ) : (
        <p className={`instruction${notice ? " alert" : ""}`} data-testid="walk-notice" role="status">
          {notice ?? " "}
        </p>
      )}
      <div className="map-wrap">
        <MapView map={round.map} path={route.path} showWeights={round.showWeights} shakeNode={shake} onTap={tap} disabled={!walking} />
      </div>
      <footer className="actions">
        {walking ? (
          <button type="button" className="btn undo" onClick={undo} disabled={route.path.length <= 1} data-testid="undo">
            <span aria-hidden="true">↶</span> {COPY.undo}
          </button>
        ) : null}
      </footer>
    </section>
  );
}

/** Soal ingatan: peta tanpa angka, satu jalan berkedip, tiga tombol besar. */
export function ProbeScreen({ game, s }: { game: GameClient; s: GameState }) {
  const { probe, round, phaseEndsAt, phase } = s;
  const shownAt = useRef(performance.now());
  useEffect(() => {
    shownAt.current = performance.now();
  }, [probe?.edgeId]);
  if (!probe || !round) {
    return (
      <section className="screen center" data-testid="probe-wait">
        <p className="instruction">{COPY.waitNext}</p>
      </section>
    );
  }
  if (s.probeAnswered) {
    return (
      <section className="screen center" data-testid="probe-sent">
        <h2 className="big-title">{COPY.arrived}</h2>
      </section>
    );
  }
  return (
    <section className="screen play" data-testid="probe-screen">
      <TimeBar endsAt={phaseEndsAt} totalMs={phase?.durationMs ?? null} />
      <p className="question" data-testid="probe-question">
        {COPY.probeQuestion}
      </p>
      <div className="map-wrap">
        <MapView map={round.map} showWeights={false} hideBadges highlightEdge={probe.edgeId} disabled />
      </div>
      <div className="probe-options">
        {probe.options.map((o) => (
          <button key={o} type="button" className="btn big" onClick={() => game.answerProbe(o, Math.round(performance.now() - shownAt.current))} data-testid={`probe-option-${o}`}>
            {o}
          </button>
        ))}
      </div>
    </section>
  );
}

export function ResultScreen({ s }: { s: GameState }) {
  const r = s.result;
  if (!r) {
    return (
      <section className="screen center" data-testid="result-wait">
        <p className="instruction">{COPY.timeUp}</p>
      </section>
    );
  }
  const gained = r.racePoints + r.streakBonus + r.probePoints;
  return (
    <section className="screen center" data-testid="result-screen">
      <div className="stars" role="img" aria-label={`${r.stars} dari 3 bintang`} data-testid="stars" data-stars={r.stars}>
        {[1, 2, 3].map((i) => (
          <span key={i} className={i <= r.stars ? "star on" : "star"} aria-hidden="true">
            ★
          </span>
        ))}
      </div>
      {r.stars === 0 ? <p className="instruction">{COPY.timeUp}</p> : null}
      {s.phase?.roundId !== 0 ? (
        <p className="points" data-testid="round-points">
          +{COPY.points(gained)}
        </p>
      ) : (
        <p className="points">{COPY.practice}</p>
      )}
      {s.reveal ? (
        <p className="instruction" data-testid="reveal">
          Rute paling hemat: <strong>{s.reveal.optimalCost} koin</strong>
        </p>
      ) : null}
      {r.level !== undefined ? (
        <div className="levelbar" data-testid="level-bar" role="img" aria-label={`Tingkat soal berikutnya ${r.level} dari 10`}>
          <span className="levelbar-label">Tingkat berikutnya</span>
          <span className="levelbar-segs">
            {Array.from({ length: 10 }, (_, i) => (
              <i key={i} className={i < (r.level as number) ? "on" : ""} style={{ animationDelay: `${i * 40}ms` }} />
            ))}
          </span>
          <b>{r.level}/10</b>
        </div>
      ) : null}
    </section>
  );
}

export function BoardScreen({ s }: { s: GameState }) {
  const b = s.board;
  return (
    <section className="screen center" data-testid="board-screen">
      <h2 className="big-title" data-testid="rank-line">
        {b ? COPY.rankLine(b.myRank, b.myPoints) : COPY.waitNext}
      </h2>
    </section>
  );
}

export function PodiumScreen({ s }: { s: GameState }) {
  const rank = s.board?.myRank ?? s.result?.rank;
  const points = s.result?.totalPoints ?? s.board?.myPoints;
  return (
    <section className="screen center" data-testid="podium-screen">
      <h1 className="logo">{COPY.gameTitle}</h1>
      {rank && points !== undefined ? (
        <p className="big-title" data-testid="final-rank">
          {COPY.rankLine(rank, points)}
        </p>
      ) : null}
      <p className="instruction">{COPY.podiumCheer}</p>
    </section>
  );
}

export function EndedScreen() {
  return (
    <section className="screen center" data-testid="ended-screen">
      <h1 className="big-title">{COPY.endedTitle}</h1>
      <p className="instruction">{COPY.endedBody}</p>
    </section>
  );
}

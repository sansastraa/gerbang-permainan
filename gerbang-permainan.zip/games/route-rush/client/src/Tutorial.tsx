import { useCallback, useEffect, useRef, useState } from "react";
import { COPY, createRoute, optimalRoute, routeCost, tapNode, undoLast, type MapDef, type NodeId, type ProbeQuestion, type RouteState } from "@route-rush/shared";
import { MapView } from "./MapView";
import { stripWeights } from "./store";
import { DEMO_STEP_MS, IDLE_HINT_MS, MEMORY_SHOW_MS, demoTaps, ghostTarget, judgeStep } from "./tutorialLogic";

export interface StepReport {
  step: number;
  attempts: number;
  hintsShown: number;
  invalidTaps: number;
  undo: number;
  ms: number;
}

interface StepProps {
  step: number;
  map: MapDef;
  probe?: ProbeQuestion;
  /** Demo otomatis: waktu tutorial hampir habis, langkah ini dimainkan sendiri. */
  demo: boolean;
  onDone: (report: StepReport, extra: { auto: boolean; probeCorrect?: boolean }) => void;
}

const tNow = (): number => performance.now();

/** Satu langkah tutorial. Memakai RouteState dan aturan ketukan yang sama dengan ronde sungguhan. */
function TutorialStep({ step, map, probe, demo, onDone }: StepProps) {
  const [route, setRoute] = useState<RouteState>(() => createRoute(map));
  const routeRef = useRef<RouteState>(route);
  const [attempts, setAttempts] = useState(1);
  const [hints, setHints] = useState(0);
  const [shake, setShake] = useState<NodeId | null>(null);
  const [notice, setNotice] = useState<string | null>(null);
  const [ghost, setGhost] = useState<NodeId | null>(null);
  const [hidden, setHidden] = useState(false);
  const [good, setGood] = useState(false);
  const [retry, setRetry] = useState<{ path: NodeId[]; cost: number; best: number } | null>(null);
  const [asking, setAsking] = useState(false);
  const [reveal, setReveal] = useState<{ truth: number; correct: boolean } | null>(null);
  const started = useRef(tNow());
  const finished = useRef(false);
  const totals = useRef({ invalid: 0, undo: 0 });
  // Bobot asli langkah 4 hanya dipegang di sini untuk menilai soal latihan (ronde sungguhan tidak pernah punya ini).
  const truth = useRef(map);

  const shown = step === 4 && hidden ? stripWeights(map) : map;
  const locked = retry !== null || asking || good || demo;

  const finish = useCallback(
    (auto: boolean, probeCorrect?: boolean) => {
      if (finished.current) return;
      finished.current = true;
      onDone(
        { step, attempts, hintsShown: hints, invalidTaps: totals.current.invalid, undo: totals.current.undo, ms: Math.round(tNow() - started.current) },
        { auto, ...(probeCorrect === undefined ? {} : { probeCorrect }) },
      );
    },
    [attempts, hints, onDone, step],
  );

  // langkah 4: angka tampil 4 detik lalu berganti "?"
  useEffect(() => {
    if (step !== 4) return;
    const id = window.setTimeout(() => setHidden(true), MEMORY_SHOW_MS);
    return () => window.clearTimeout(id);
  }, [step]);

  // tangan bayangan setelah diam lebih dari 4 detik
  useEffect(() => {
    setGhost(null);
    if (locked) return;
    const id = window.setTimeout(() => {
      const target = ghostTarget(map, route.path);
      if (target) {
        setGhost(target);
        setHints((h) => h + 1);
      }
    }, IDLE_HINT_MS);
    return () => window.clearTimeout(id);
  }, [map, route, locked, retry]);

  const afterRoute = useCallback(
    (next: RouteState) => {
      const verdict = judgeStep(step, map, next);
      if (verdict.kind === "done") {
        if (step === 4 && !demo) {
          setGood(true);
          window.setTimeout(() => {
            setGood(false);
            setAsking(true);
          }, 900);
        } else {
          setGood(true);
          window.setTimeout(() => finish(demo), 900);
        }
      } else if (verdict.kind === "retry") {
        setAttempts((a) => a + 1);
        setRetry({ path: [...next.path], cost: verdict.cost, best: verdict.best });
        setNotice(COPY.tutorialRetry);
      } else if (verdict.kind === "incomplete") {
        setNotice(COPY.packagesMissing);
      } else setNotice(null);
    },
    [demo, finish, map, step],
  );

  const commit = (next: RouteState): void => {
    routeRef.current = next;
    setRoute(next);
  };

  const tap = useCallback(
    (id: NodeId) => {
      if (locked && !demo) return;
      const cur = routeRef.current;
      const next = tapNode(map, cur, id, Math.round(tNow() - started.current));
      if (next === cur) return;
      commit(next);
      if (next.invalidTaps > cur.invalidTaps) {
        totals.current.invalid++;
        setShake(id);
        window.setTimeout(() => setShake(null), 300);
        setNotice(step === 2 && id === map.goal ? COPY.tutorialNotConnected : null);
      } else afterRoute(next);
    },
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [afterRoute, demo, locked, map, step],
  );

  const undo = (): void => {
    if (locked) return;
    const cur = routeRef.current;
    const next = undoLast(map, cur, Math.round(tNow() - started.current));
    if (next === cur) return;
    totals.current.undo++;
    commit(next);
    setNotice(null);
  };

  const again = (): void => {
    setRetry(null);
    setNotice(null);
    commit(createRoute(map));
  };

  // demo otomatis: ketuk rute terhemat tiap 700 ms, tutup langkah setelah 5 detik
  useEffect(() => {
    if (!demo) return;
    commit(createRoute(map));
    setRetry(null);
    const taps = demoTaps(map);
    const ids = taps.map((id, i) => window.setTimeout(() => tap(id), 600 + i * 700));
    const end = window.setTimeout(() => finish(true), DEMO_STEP_MS);
    return () => {
      ids.forEach((i) => window.clearTimeout(i));
      window.clearTimeout(end);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demo]);

  const answer = (value: number): void => {
    const edge = truth.current.edges.find((e) => e.id === probe?.edgeId);
    const correct = edge?.w === value;
    setAsking(false);
    setReveal({ truth: edge?.w ?? value, correct });
    window.setTimeout(() => finish(false, correct), 1500);
  };

  const coins = routeCost(shown, route.path);
  const blinkUndo = step === 3 && attempts >= 2;
  const message = notice ?? (reveal ? null : COPY.tutorial[step - 1]);

  return (
    <section className="screen tutorial" data-testid="tutorial" data-step={step}>
      <header className="topline">
        <span className="chip" data-testid="tutorial-step-chip">
          Latihan {step} dari 5
        </span>
        {step !== 4 || !hidden ? <span className="chip coin" data-testid="coin-counter">{COPY.coins}: {coins ?? 0}</span> : null}
      </header>
      <p className={`instruction${notice ? " alert" : ""}`} data-testid="tutorial-text" role="status">
        {message}
      </p>
      <div className="map-wrap">
        <MapView
          map={shown}
          path={retry ? [] : route.path}
          trapPath={retry ? retry.path : undefined}
          hintPath={retry ? optimalRoute(map) : undefined}
          showWeights={!(step === 4 && hidden)}
          highlightEdge={asking ? (probe?.edgeId ?? null) : null}
          hideBadges={asking}
          shakeNode={shake}
          ghostNode={ghost}
          onTap={tap}
          disabled={locked && !demo}
        />
        {good ? (
          <div className="burst-star" data-testid="tutorial-good" aria-live="polite">
            <span aria-hidden="true">★</span> {COPY.tutorialGood}
          </div>
        ) : null}
        {retry ? (
          <div className="retry-card" data-testid="tutorial-retry">
            <p>
              Jalanmu: <strong>{retry.cost} koin</strong> · Jalan hemat: <strong>{retry.best} koin</strong>
            </p>
            <button type="button" className="btn primary" onClick={again} data-testid="tutorial-again">
              Coba lagi
            </button>
          </div>
        ) : null}
        {reveal ? (
          <div className="retry-card" data-testid="tutorial-reveal">
            <p>
              {COPY.tutorialAnswer} <strong>{reveal.truth}</strong> {reveal.correct ? "· Benar!" : "· Tidak apa-apa."}
            </p>
          </div>
        ) : null}
      </div>
      {asking && probe ? (
        <div className="probe" data-testid="tutorial-probe">
          <p className="question">{COPY.probeQuestion}</p>
          <div className="probe-options">
            {probe.options.map((o) => (
              <button key={o} type="button" className="btn big" onClick={() => answer(o)} data-testid={`probe-option-${o}`}>
                {o}
              </button>
            ))}
          </div>
        </div>
      ) : (
        <footer className="actions">
          <button type="button" className={`btn undo${blinkUndo ? " blink" : ""}`} onClick={undo} disabled={locked || route.path.length <= 1} data-testid="undo">
            <span aria-hidden="true">↶</span> {COPY.undo}
          </button>
          {blinkUndo ? <span className="undo-hint" data-testid="undo-hint">{COPY.undoHint}</span> : null}
        </footer>
      )}
    </section>
  );
}

export interface TutorialProps {
  tutorial: { step: number; map: MapDef; probe?: ProbeQuestion } | null;
  /** Sisa waktu fase (ms) pada saat dipanggil; null bila tanpa batas. */
  remainingMs: () => number | null;
  send: (event: string, payload: unknown) => void;
}

/** Rangkaian 5 langkah tutorial; pemain yang belum selesai saat batas waktu mendekat melihat demo otomatis. */
export function Tutorial({ tutorial, remainingMs, send }: TutorialProps) {
  const started = useRef(tNow());
  const autoSteps = useRef<number[]>([]);
  const probeCorrect = useRef<boolean | null>(null);
  const [finished, setFinished] = useState(false);
  const [demo, setDemo] = useState(false);

  useEffect(() => {
    if (!tutorial || demo) return;
    const id = window.setInterval(() => {
      const rem = remainingMs();
      if (rem !== null && rem <= DEMO_STEP_MS * (6 - tutorial.step)) setDemo(true);
    }, 250);
    return () => window.clearInterval(id);
  }, [demo, remainingMs, tutorial]);

  const onDone = useCallback(
    (report: StepReport, extra: { auto: boolean; probeCorrect?: boolean }) => {
      if (extra.auto) autoSteps.current.push(report.step);
      if (extra.probeCorrect !== undefined) probeCorrect.current = extra.probeCorrect;
      send("tutorial:step", report);
      if (report.step === 5) {
        send("tutorial:done", { totalMs: Math.round(tNow() - started.current), autoDemoSteps: autoSteps.current, probeCorrect: probeCorrect.current });
        setFinished(true);
      }
    },
    [send],
  );

  if (finished || !tutorial) {
    return (
      <section className="screen center" data-testid="tutorial-wait">
        <h2 className="big-title">{COPY.tutorialReady}</h2>
      </section>
    );
  }
  return <TutorialStep key={tutorial.step} step={tutorial.step} map={tutorial.map} demo={demo} onDone={onDone} {...(tutorial.probe ? { probe: tutorial.probe } : {})} />;
}

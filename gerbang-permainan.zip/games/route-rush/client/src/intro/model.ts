import type { IntroMode, IntroTimeline, Shot, TrailerNumbers } from "@route-rush/shared";
import { resolveScreenText } from "@route-rush/shared";

export const clamp01 = (x: number): number => Math.min(1, Math.max(0, x));
/** Kemajuan 0..1 dari `a` sampai `b` pada kemajuan shot `p`. */
export const seg = (p: number, a: number, b: number): number => clamp01((p - a) / (b - a));
export const easeOut = (x: number): number => 1 - (1 - x) ** 3;
export const easeInOut = (x: number): number => (x < 0.5 ? 4 * x * x * x : 1 - (-2 * x + 2) ** 3 / 2);
export const lerp = (a: number, b: number, x: number): number => a + (b - a) * x;

export type IntroKind = "IDENT" | "TRAILER";

/** Satu potongan yang sedang diputar: shot asli, dan kemajuan 0..1 di dalamnya (versi ringkas menskalakan durasi). */
export interface Playing {
  shot: Shot;
  /** Waktu di dalam shot asli (ms) setelah skala. */
  p: number;
  /** Indeks shot pada daftar yang diputar. */
  index: number;
}

/** Pengendali jam intro. Otomatis mengikuti sisa waktu fase dari server; `seek` membekukan jam agar uji bisa melompat ke detik tertentu. */
export class IntroClock {
  private manual: number | null = null;
  seek(ms: number): void {
    this.manual = ms;
  }
  release(): void {
    this.manual = null;
  }
  get frozen(): boolean {
    return this.manual !== null;
  }
  /** `auto` = waktu menurut server (ms sejak fase mulai). */
  resolve(auto: number): number {
    return this.manual ?? auto;
  }
}

/**
 * Menentukan shot dan kemajuannya pada waktu `t` (ms sejak fase dimulai).
 * Ident ringkas: potongan 4000–7000 ms dari ident penuh. Trailer ringkas: tiga potongan 4 detik dari shot-04, 05, 08.
 */
export function playingAt(tl: IntroTimeline, kind: IntroKind, mode: IntroMode, t: number): Playing {
  if (kind === "IDENT") {
    const at = mode === "SHORT" ? tl.identShort.fromMs + t : t;
    const last = tl.ident[tl.ident.length - 1] as Shot;
    const clamped = Math.min(Math.max(0, at), last.endMs - 1);
    const index = tl.ident.findIndex((s) => clamped >= s.startMs && clamped < s.endMs);
    const shot = tl.ident[index] as Shot;
    return { shot, p: clamped, index };
  }
  if (mode === "SHORT") {
    const lastEnd = (tl.trailerShort[tl.trailerShort.length - 1] as { endMs: number }).endMs;
    const clamped = Math.min(Math.max(0, t), lastEnd - 1);
    const index = tl.trailerShort.findIndex((s) => clamped >= s.startMs && clamped < s.endMs);
    const part = tl.trailerShort[index] as { fromShot: string; startMs: number; endMs: number };
    const shot = tl.trailer.find((s) => s.id === part.fromShot) as Shot;
    const frac = (clamped - part.startMs) / (part.endMs - part.startMs);
    return { shot, p: shot.startMs + frac * (shot.endMs - shot.startMs), index };
  }
  const last = tl.trailer[tl.trailer.length - 1] as Shot;
  const clamped = Math.min(Math.max(0, t), last.endMs - 1);
  const index = tl.trailer.findIndex((s) => clamped >= s.startMs && clamped < s.endMs);
  return { shot: tl.trailer[index] as Shot, p: clamped, index };
}

/** Kemajuan 0..1 di dalam shot. */
export const shotProgress = (pl: Playing): number => clamp01((pl.p - pl.shot.startMs) / (pl.shot.endMs - pl.shot.startMs));

/**
 * Mode gerak dikurangi: trailer menjadi gambar diam (`reducedMotionStills`), tiap gambar tampil sampai gambar berikutnya,
 * sehingga durasi tetap 45 detik. Mengembalikan id shot gambar yang tampil pada waktu `t`.
 */
export function stillAt(tl: IntroTimeline, stills: readonly string[], t: number): string {
  let chosen = stills[0] as string;
  for (const id of stills) {
    const s = tl.trailer.find((x) => x.id === id) as Shot;
    if (s.startMs <= t) chosen = id;
  }
  return chosen;
}

/** Subtitle: narasi (VO) selalu tampil sebagai teks. */
export const subtitleOf = (shot: Shot): string | null => shot.vo;

/** Teks kartu, dengan {trapCost}/{optimalCost} dihitung dari peta A-05. */
export const cardText = (shot: Shot, n: TrailerNumbers): string | null => (shot.screenText ? resolveScreenText(shot.screenText, n) : null);

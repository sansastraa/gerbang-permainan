import { allRoutes, minHops, optimalRoute, parseFormBank, parseTimeline, trailerNumbers, type IntroTimeline, type MapDef, type NodeId, type TrailerNumbers } from "@route-rush/shared";
import formA from "../../../shared/maps/formA.json";
import timelineJson from "../../../shared/intro/timeline.json";

export interface IntroData {
  timeline: IntroTimeline;
  stills: string[];
  /** Peta trailer (A-05 dari formA.json). */
  map: MapDef;
  numbers: TrailerNumbers;
  /** Rute hemat dan rute jebakan (hop paling sedikit), keduanya dihitung dari peta. */
  optimal: NodeId[];
  trap: NodeId[];
}

/** Semua data intro berasal dari berkas acuan dan fungsi shared/; angka koin tidak diketik di komponen. */
export function loadIntroData(): IntroData {
  const timeline = parseTimeline(timelineJson);
  const bank = parseFormBank(formA);
  const map = bank.maps.find((m) => m.id === timeline.trailerMap) as MapDef;
  const numbers = trailerNumbers(map);
  const hops = minHops(map);
  const trapRoute = allRoutes(map).find((r) => r.path.length - 1 === hops && r.cost === numbers.trapCost);
  if (!trapRoute) throw new RangeError("rute jebakan peta trailer tidak ditemukan");
  const stills = (timelineJson as { reducedMotionStills: string[] }).reducedMotionStills;
  return { timeline, stills, map, numbers, optimal: optimalRoute(map), trap: trapRoute.path };
}

export const introData: IntroData = loadIntroData();
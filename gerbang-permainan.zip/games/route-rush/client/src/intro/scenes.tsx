import type { ReactNode } from "react";
import type { MapDef, NodeId } from "@route-rush/shared";
import { COLORS } from "../MapView";
import { clamp01, easeInOut, easeOut, lerp, seg } from "./model";
import type { IntroData } from "./data";

export const W = 1600;
export const H = 900;

export interface Ctx {
  /** Kemajuan 0..1 di dalam shot. */
  p: number;
  d: IntroData;
  logoUrl: string;
  makerName: string;
  /** Teks kartu yang sudah dihitung ({trapCost}/{optimalCost}). */
  card: string | null;
}

/** Huruf kartu pembuka produksi: Plus Jakarta Sans (dimuat di host.css). */
const PJS = '"Plus Jakarta Sans", "Nunito", system-ui, sans-serif';

const NIGHT = "#0B1E3A";
const MORNING = "#FFB38A";

const pos = (map: MapDef, id: NodeId): { x: number; y: number } => {
  const n = map.nodes.find((x) => x.id === id) as { x: number; y: number };
  return { x: 260 + n.x * 1080, y: 150 + n.y * 600 };
};

const pathD = (map: MapDef, path: readonly NodeId[], upto = 1): string => {
  const pts = path.map((id) => pos(map, id));
  const total = pts.length - 1;
  const reach = upto * total;
  let d = `M${(pts[0] as { x: number }).x} ${(pts[0] as { y: number }).y}`;
  for (let i = 1; i <= total; i++) {
    const a = pts[i - 1] as { x: number; y: number };
    const b = pts[i] as { x: number; y: number };
    const f = clamp01(reach - (i - 1));
    if (f <= 0) break;
    d += ` L${lerp(a.x, b.x, f)} ${lerp(a.y, b.y, f)}`;
  }
  return d;
};

// ---------------------------------------------------------------- bangunan sederhana (flat 2,5D)

const Roof = ({ x, y, w, h, c }: { x: number; y: number; w: number; h: number; c: string }) => <polygon points={`${x - 8},${y} ${x + w / 2},${y - h} ${x + w + 8},${y}`} fill={c} />;
const Windows = ({ x, y, lit }: { x: number; y: number; lit: number }) => (
  <g opacity={0.25 + 0.75 * lit}>
    <rect x={x} y={y} width="26" height="30" rx="3" fill="#FFE082" />
    <rect x={x + 46} y={y} width="26" height="30" rx="3" fill="#FFE082" />
  </g>
);

function Building({ kind, x, y, lit }: { kind: "home" | "market" | "mosque" | "school" | "shop" | "library"; x: number; y: number; lit: number }) {
  switch (kind) {
    case "home":
      return (
        <g>
          <rect x={x} y={y - 110} width="130" height="110" fill="#E8D5B5" />
          <Roof x={x} y={y - 110} w={130} h={70} c="#B5532E" />
          <Windows x={x + 14} y={y - 80} lit={lit} />
          <rect x={x + 52} y={y - 50} width="26" height="50" fill="#6D4C41" />
        </g>
      );
    case "market":
      return (
        <g>
          <rect x={x} y={y - 80} width="170" height="80" fill="#F0E0C0" />
          <polygon points={`${x - 10},${y - 80} ${x + 180},${y - 80} ${x + 160},${y - 130} ${x + 10},${y - 130}`} fill="#E53935" />
          <rect x={x + 10} y={y - 130} width="28" height="50" fill="#fff" opacity={0.7} />
          <rect x={x + 76} y={y - 130} width="28" height="50" fill="#fff" opacity={0.7} />
          <Windows x={x + 30} y={y - 55} lit={lit} />
        </g>
      );
    case "mosque":
      return (
        <g>
          <rect x={x} y={y - 90} width="150" height="90" fill="#E0F2E9" />
          <path d={`M${x + 25} ${y - 90} A50 50 0 0 1 ${x + 125} ${y - 90} Z`} fill="#2E7D6B" />
          <rect x={x + 70} y={y - 160} width="10" height="22" fill="#2E7D6B" />
          <Windows x={x + 28} y={y - 60} lit={lit} />
        </g>
      );
    case "school":
      return (
        <g>
          <rect x={x} y={y - 100} width="190" height="100" fill="#F6E4E0" />
          <Roof x={x} y={y - 100} w={190} h={50} c={COLORS.school} />
          <rect x={x + 88} y={y - 188} width="6" height="70" fill="#555" />
          <polygon points={`${x + 94},${y - 188} ${x + 130},${y - 176} ${x + 94},${y - 164}`} fill={COLORS.school} />
          <Windows x={x + 22} y={y - 70} lit={lit} />
          <Windows x={x + 100} y={y - 70} lit={lit} />
        </g>
      );
    case "shop":
      return (
        <g>
          <rect x={x} y={y - 90} width="130" height="90" fill="#D7E3F4" />
          <rect x={x - 6} y={y - 100} width="142" height="18" fill="#1565C0" />
          <Windows x={x + 16} y={y - 62} lit={lit} />
        </g>
      );
    case "library":
      return (
        <g>
          <rect x={x} y={y - 100} width="150" height="100" fill="#EFE6F7" />
          <Roof x={x} y={y - 100} w={150} h={40} c="#5E35B1" />
          <Windows x={x + 20} y={y - 70} lit={lit} />
        </g>
      );
  }
}

const Courier = ({ x, y, s = 1, helmet = 1 }: { x: number; y: number; s?: number; helmet?: number }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle cx="-44" cy="34" r="20" fill="#263238" />
    <circle cx="-44" cy="34" r="8" fill="#90A4AE" />
    <circle cx="48" cy="34" r="20" fill="#263238" />
    <circle cx="48" cy="34" r="8" fill="#90A4AE" />
    <rect x="-52" y="10" width="92" height="18" rx="9" fill="#EF6C00" />
    <path d="M36 14 L50 -34" stroke="#37474F" strokeWidth="9" strokeLinecap="round" />
    <path d="M40 -36 H62" stroke="#37474F" strokeWidth="9" strokeLinecap="round" />
    <rect x="-14" y="-6" width="40" height="18" rx="6" fill="#37474F" />
    <path d="M10 -6 L38 -30" stroke="#F2C9A0" strokeWidth="10" strokeLinecap="round" />
    <rect x="-18" y="-66" width="44" height="64" rx="14" fill="#EF6C00" />
    <rect x="-18" y="-40" width="44" height="8" fill="#FFF8E1" />
    <circle cx="6" cy="-84" r="22" fill="#F2C9A0" />
    <g opacity={helmet}>
      <path d="M-18 -88 A24 24 0 0 1 30 -88 Z" fill="#FFC107" />
      <rect x="-12" y="-92" width="38" height="11" rx="5" fill="#37474F" />
    </g>
  </g>
);

const Box = ({ x, y, s = 1, c = COLORS.pack }: { x: number; y: number; s?: number; c?: string }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x="-34" y="-34" width="68" height="68" rx="8" fill={c} stroke="#fff" strokeWidth="5" />
    <path d="M-34 -8 H34 M0 -34 V-8" stroke="#fff" strokeWidth="5" />
  </g>
);

// ---------------------------------------------------------------- peta A-05

function RoadMap({ ctx, badgeShown, route, hideAll = 0, zoom, hideBlink }: { ctx: Ctx; badgeShown: (i: number) => number; route?: ReactNode; hideAll?: number; zoom?: { x: number; y: number; k: number }; hideBlink?: number }) {
  const { map } = ctx.d;
  const kindColor = (id: NodeId): string => (id === map.start ? COLORS.home : id === map.goal ? COLORS.school : COLORS.other);
  const tf = zoom ? `translate(${W / 2} ${H / 2}) scale(${zoom.k}) translate(${-zoom.x} ${-zoom.y})` : undefined;
  return (
    <g transform={tf}>
      {map.edges.map((e) => {
        const a = pos(map, e.a);
        const b = pos(map, e.b);
        return <line key={e.id} x1={a.x} y1={a.y} x2={b.x} y2={b.y} stroke={COLORS.road} strokeWidth="14" strokeLinecap="round" />;
      })}
      {route}
      {map.nodes.map((n) => {
        const p = pos(map, n.id);
        return (
          <g key={n.id} transform={`translate(${p.x} ${p.y})`}>
            <circle r="46" fill={kindColor(n.id)} stroke="#fff" strokeWidth="6" />
            <circle r="16" fill="#fff" opacity="0.85" />
          </g>
        );
      })}
      {map.edges.map((e, i) => {
        const a = pos(map, e.a);
        const b = pos(map, e.b);
        const shown = badgeShown(i);
        const q = hideAll;
        const blink = hideBlink ?? 1;
        return (
          <g key={`b-${e.id}`} transform={`translate(${(a.x + b.x) / 2} ${(a.y + b.y) / 2}) scale(${0.2 + 0.8 * easeOut(shown)})`} opacity={shown}>
            <circle r="34" fill={COLORS.coinBg} stroke={COLORS.coin} strokeWidth="7" />
            <text textAnchor="middle" dominantBaseline="central" fontSize="44" fontWeight="800" fill="#4E342E" opacity={(1 - q) * blink}>
              {e.w}
            </text>
            <text textAnchor="middle" dominantBaseline="central" fontSize="44" fontWeight="800" fill="#4E342E" opacity={q}>
              ?
            </text>
          </g>
        );
      })}
    </g>
  );
}

const Bg = ({ top = NIGHT, bottom = NIGHT }: { top?: string; bottom?: string }) => {
  const id = `bg-${top}-${bottom}`.replaceAll("#", "");
  return (
  <>
    <defs>
      <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={top} />
        <stop offset="1" stopColor={bottom} />
      </linearGradient>
    </defs>
    <rect width={W} height={H} fill={`url(#${id})`} />
  </>
  );
};

// ---------------------------------------------------------------- ident (8 detik)

const IDENT_POINTS: [number, number][] = [
  [800, 450],
  [520, 300],
  [1080, 270],
  [640, 640],
  [1010, 650],
  [1240, 460],
];
const IDENT_LINES: [number, number][] = [
  [0, 1],
  [0, 2],
  [0, 3],
  [0, 4],
  [1, 2],
  [3, 4],
  [2, 5],
  [4, 5],
];

/** `ms` = waktu ident penuh (0..8000). */
export function IdentScene({ ms, ctx }: { ms: number; ctx: Pick<Ctx, "logoUrl" | "makerName"> }) {
  const pulse = 0.65 + 0.35 * Math.sin(ms / 160);
  const popP = (i: number): number => seg(ms, 1000 + (i - 1) * 260, 1000 + (i - 1) * 260 + 260);
  const lineP = (i: number): number => seg(ms, 2500 + i * 120, 2500 + i * 120 + 600);
  const turn = easeInOut(seg(ms, 4000, 5500));
  const netOut = seg(ms, 4700, 5400);
  const logoIn = easeOut(seg(ms, 5200, 5900));
  const fade = seg(ms, 7000, 8000);
  const kilau = seg(ms, 5900, 6300);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg" role="img" aria-label="Pembuka produksi">
      <Bg />
      <g transform={`translate(800 450) rotate(${30 * turn}) scale(${lerp(1, 0.55, turn)}) translate(-800 -450)`} opacity={1 - netOut}>
        {IDENT_LINES.map(([a, b], i) => {
          const pa = IDENT_POINTS[a] as [number, number];
          const pb = IDENT_POINTS[b] as [number, number];
          const f = lineP(i);
          const green = i === 0 || i === 6;
          return <line key={i} x1={pa[0]} y1={pa[1]} x2={lerp(pa[0], pb[0], f)} y2={lerp(pa[1], pb[1], f)} stroke={green && f >= 1 ? "#3FBF5A" : "rgba(255,248,225,0.35)"} strokeWidth="5" strokeLinecap="round" />;
        })}
        {IDENT_POINTS.map(([x, y], i) => {
          const s = i === 0 ? (ms < 1000 ? 0.8 + 0.4 * pulse : 1) : 0.2 + 0.8 * easeOut(popP(i));
          return <circle key={i} cx={x} cy={y} r={i === 0 ? 26 : 20} fill={i === 0 ? "#F9A825" : "#FFF8E1"} transform={`translate(${x} ${y}) scale(${s}) translate(${-x} ${-y})`} opacity={i === 0 ? 1 : popP(i)} />;
        })}
      </g>
      <g opacity={logoIn}>
        <defs>
          <clipPath id="logoClip">
            <rect x={620} y={190} width="360" height="360" />
          </clipPath>
        </defs>
        <image href={ctx.logoUrl} x={620} y={190} width="360" height="360" preserveAspectRatio="xMidYMid meet" />
        <text x={800} y={630} textAnchor="middle" fontSize="76" fontWeight="800" fill="#FFF8E1" fontFamily={PJS} letterSpacing="-1">
          {ctx.makerName}
        </text>
        <text x={800} y={702} textAnchor="middle" fontSize="38" fontWeight="500" fill="rgba(255,248,225,0.78)" fontFamily={PJS} letterSpacing="6">
          Mempersembahkan
        </text>
        <g clipPath="url(#logoClip)">
          <rect x={560 + 480 * kilau} y={190} width="36" height="360" fill="#fff" opacity={kilau > 0 && kilau < 1 ? 0.35 : 0} transform="skewX(-20)" />
        </g>
      </g>
      <rect width={W} height={H} fill="#000" opacity={fade} />
    </svg>
  );
}

// ---------------------------------------------------------------- trailer

function City({ p, zoomK, lit }: { p: number; zoomK: number; lit: (i: number) => number }) {
  const sx = (layer: number): number => (0.5 - p) * 80 * layer;
  return (
    <g transform={`translate(800 540) scale(${zoomK}) translate(-800 -540)`}>
      <Bg top={NIGHT} bottom={MORNING} />
      <circle cx="1230" cy="470" r="90" fill="#FFD9A8" opacity={0.85} />
      <g transform={`translate(${sx(0.3)} 0)`} opacity="0.55">
        <polygon points="0,640 200,520 420,620 700,500 980,610 1250,510 1600,600 1600,900 0,900" fill="#2C3E66" />
      </g>
      <g transform={`translate(${sx(0.6)} 0)`}>
        <rect x="-100" y="690" width="1800" height="260" fill="#33456E" />
        <Building kind="home" x={100} y={700} lit={lit(0)} />
        <Building kind="market" x={330} y={700} lit={lit(1)} />
        <Building kind="mosque" x={600} y={700} lit={lit(2)} />
        <Building kind="shop" x={850} y={700} lit={lit(3)} />
        <Building kind="library" x={1060} y={700} lit={lit(4)} />
        <Building kind="school" x={1290} y={700} lit={lit(5)} />
      </g>
      <g transform={`translate(${sx(1)} 0)`}>
        <rect x="-100" y="770" width="1800" height="130" fill="#26324F" />
        <rect x="-100" y="800" width="1800" height="10" fill="#FFF8E1" opacity="0.4" />
      </g>
    </g>
  );
}

const Montage = ({ p, d }: { p: number; d: IntroData }) => {
  const i = Math.min(3, Math.floor(p * 4));
  const f = p * 4 - i;
  const parkPos = pos(d.map, (d.map.nodes.find((n) => n.kind === "park")?.id ?? d.map.start) as NodeId);
  const pop = 0.7 + 0.3 * easeOut(seg(f, 0, 0.2));
  return (
    <g>
      <Bg top="#10294D" bottom="#0B1E3A" />
      <g transform={`translate(800 450) scale(${pop}) translate(-800 -450)`}>
        {i === 0 ? (
          <g>
            <circle cx="800" cy="450" r="150" fill={COLORS.other} stroke="#fff" strokeWidth="10" />
            <Box x={920} y={340} s={2.2} />
            <text x="800" y="760" textAnchor="middle" fontSize="48" fill="#FFF8E1">
              Wajib mampir
            </text>
          </g>
        ) : null}
        {i === 1 ? (
          <g>
            <circle cx="800" cy="450" r="130" fill={COLORS.other} stroke="#fff" strokeWidth="10" />
            <circle cx="800" cy="450" r={60 + 160 * f} fill="none" stroke="#3FBF5A" strokeWidth="10" opacity={1 - f} />
            <path d="M830 560 L830 470 A16 16 0 0 1 862 470 V500 L880 495 A16 16 0 0 1 904 510 V570 Q890 640 840 650 H820 L770 590 Z" fill="#fff" stroke="#0B1E3A" strokeWidth="6" transform="translate(-30 0)" />
          </g>
        ) : null}
        {i === 2 ? (
          <g>
            <rect x="300" y="420" width="1000" height="60" rx="30" fill="rgba(255,248,225,0.18)" />
            <rect x="300" y="420" width={1000 * (1 - f)} height="60" rx="30" fill={f > 0.7 ? COLORS.trap : COLORS.coin} />
          </g>
        ) : null}
        {i === 3 ? (
          <g>
            {[0, 1, 2, 3, 4].map((r) => (
              <g key={r} transform={`translate(0 ${r * 100})`}>
                <text x="330" y="270" fontSize="56" fontWeight="800" fill="#FFF8E1" textAnchor="middle" fontFamily="var(--head)">
                  {r + 1}
                </text>
                <rect x="400" y="225" width={(840 - r * 120) * easeOut(seg(f, r * 0.08, 0.5 + r * 0.08))} height="64" rx="14" fill={r === 0 ? COLORS.coin : "#4C8DFF"} />
              </g>
            ))}
          </g>
        ) : null}
      </g>
      <circle cx={parkPos.x} cy={parkPos.y} r="0" />
    </g>
  );
};

/** `shotId` = shot asli yang digambar; `p` = kemajuan 0..1. */
export function TrailerScene({ shotId, ctx }: { shotId: string; ctx: Ctx }) {
  const { p, d } = ctx;
  const map = d.map;
  const opt = d.optimal;
  const trap = d.trap;
  switch (shotId) {
    case "shot-01": {
      const text = ctx.card ?? "";
      const n = Math.floor(clamp01(p / 0.75) * text.length);
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <rect width={W} height={H} fill="#000" />
          <text x={W / 2} y={H / 2} textAnchor="middle" fontSize="80" fill="#FFF8E1" fontFamily="var(--head)" fontWeight="800">
            {text.slice(0, n)}
          </text>
        </svg>
      );
    }
    case "shot-02":
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <City p={p} zoomK={lerp(1, 1.22, easeInOut(p))} lit={(i) => easeOut(seg(p, 0.1 + i * 0.13, 0.22 + i * 0.13))} />
        </svg>
      );
    case "shot-03": {
      const arrive = easeOut(seg(p, 0.05, 0.6));
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <City p={0.8} zoomK={1} lit={() => 1} />
          <g transform="translate(165 735)">
            <Box x={0} y={0} s={1.1} />
            <text y="-62" textAnchor="middle" fontSize="34" fill="#FFF8E1" fontWeight="800" stroke="#0B1E3A" strokeWidth="8" paintOrder="stroke">
              Untuk: Sekolah
            </text>
          </g>
          <Courier x={lerp(-200, 330, arrive)} y={790} s={1.5} helmet={easeOut(seg(p, 0.6, 0.78))} />
        </svg>
      );
    }
    case "shot-04": {
      const toMap = easeInOut(seg(p, 0, 0.35));
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Bg top="#10294D" bottom="#0B1E3A" />
          <g opacity={1 - toMap} transform={`translate(800 450) scale(${lerp(1, 0.5, toMap)}) translate(-800 -450)`}>
            <City p={0.8} zoomK={1.2} lit={() => 1} />
          </g>
          <g opacity={toMap} transform={`translate(800 450) scale(${lerp(0.8, 1, toMap)}) translate(-800 -450)`}>
            <RoadMap ctx={ctx} badgeShown={(i) => easeOut(seg(p, 0.38 + i * 0.07, 0.48 + i * 0.07))} />
          </g>
        </svg>
      );
    }
    case "shot-05": {
      const trapIn = seg(p, 0.05, 0.4);
      const optIn = seg(p, 0.5, 0.85);
      const route = (
        <g>
          <path d={pathD(map, trap, trapIn)} fill="none" stroke={COLORS.trap} strokeWidth="18" strokeDasharray="34 24" strokeLinecap="round" opacity={optIn > 0 ? 0.5 : 1} />
          <path d={pathD(map, opt, optIn)} fill="none" stroke="#3FBF5A" strokeWidth="22" strokeLinecap="round" />
        </g>
      );
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Bg top="#10294D" bottom="#0B1E3A" />
          <RoadMap ctx={ctx} badgeShown={() => 1} route={route} />
          <text x={W / 2} y="840" textAnchor="middle" fontSize="72" fontWeight="800" fontFamily="var(--head)" fill="#FFF8E1" opacity={seg(p, 0.35, 0.5)}>
            {ctx.card}
          </text>
        </svg>
      );
    }
    case "shot-06": {
      // berkedip 2 kali (1,25 Hz) lalu menjadi "?"; zoom ke satu jalan
      const blinkP = seg(p, 0.1, 0.5);
      const blink = blinkP <= 0 || blinkP >= 1 ? 1 : 0.5 + 0.5 * Math.cos(blinkP * Math.PI * 4);
      const q = seg(p, 0.5, 0.6);
      const e = map.edges.find((x) => x.id === "n2-n3") ?? (map.edges[0] as MapDef["edges"][number]);
      const a = pos(map, e.a);
      const b = pos(map, e.b);
      const z = easeInOut(seg(p, 0.6, 1));
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Bg top="#10294D" bottom="#0B1E3A" />
          <RoadMap ctx={ctx} badgeShown={() => 1} hideAll={q} hideBlink={blink} zoom={{ x: lerp(W / 2, (a.x + b.x) / 2, z), y: lerp(H / 2, (a.y + b.y) / 2, z), k: lerp(1, 1.9, z) }} />
          <text x={W / 2} y="160" textAnchor="middle" fontSize="110" fontWeight="800" fontFamily="var(--head)" fill={COLORS.coin} opacity={seg(p, 0.55, 0.7)}>
            {ctx.card}
          </text>
        </svg>
      );
    }
    case "shot-07":
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Montage p={p} d={d} />
        </svg>
      );
    case "shot-08": {
      const draw = seg(p, 0.05, 0.7);
      const fill = seg(p, 0.7, 0.95);
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Bg top="#10294D" bottom="#0B1E3A" />
          <text x={W / 2} y={H / 2 + 40} textAnchor="middle" fontSize="190" fontWeight="800" fontFamily="var(--head)" fill="#FFF8E1" fillOpacity={fill} stroke="#3FBF5A" strokeWidth="6" strokeDasharray="7000" strokeDashoffset={7000 * (1 - draw)}>
            {ctx.card}
          </text>
        </svg>
      );
    }
    case "shot-09": {
      const words = (ctx.card ?? "").split(/(?<=\.)\s+/);
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <Bg top="#10294D" bottom="#0B1E3A" />
          {words.map((w, i) => {
            const a = easeOut(seg(p, i * 0.25, i * 0.25 + 0.15));
            const y = 270 + i * 190;
            return (
              <g key={w} opacity={a} transform={`translate(0 ${(1 - a) * 30})`}>
                {i === 0 ? (
                  <g transform={`translate(560 ${y - 20})`} fill="none" stroke="#FFF8E1" strokeWidth="8" strokeLinejoin="round">
                    <rect x="-40" y="-50" width="80" height="100" rx="10" />
                    <rect x="-24" y="-36" width="48" height="22" />
                    <path d="M-20 10 H-14 M0 10 H6 M20 10 H26 M-20 32 H-14 M0 32 H6 M20 32 H26" />
                  </g>
                ) : null}
                {i === 1 ? (
                  <g transform={`translate(560 ${y - 20})`} fill="none" stroke="#FFF8E1" strokeWidth="8" strokeLinejoin="round">
                    <path d="M0 -50 C-50 -60 -70 0 -40 20 C-60 50 -10 70 0 50 C10 70 60 50 40 20 C70 0 50 -60 0 -50 Z" />
                    <path d="M0 -50 V50" />
                  </g>
                ) : null}
                {i === 2 ? (
                  <g transform={`translate(560 ${y - 20})`} fill="none" stroke="#FFF8E1" strokeWidth="8" strokeLinejoin="round">
                    <path d="M-50 -30 L-18 -44 L18 -30 L50 -44 V40 L18 54 L-18 40 L-50 54 Z M-18 -44 V40 M18 -30 V54" />
                  </g>
                ) : null}
                <text x="660" y={y + 20} fontSize="92" fontWeight="800" fontFamily="var(--head)" fill="#FFF8E1">
                  {w}
                </text>
              </g>
            );
          })}
        </svg>
      );
    }
    default: {
      // shot-10: kurir melaju keluar frame, wipe
      const go = easeInOut(seg(p, 0.1, 0.9));
      const wipe = seg(p, 0.55, 1);
      return (
        <svg viewBox={`0 0 ${W} ${H}`} className="intro-svg">
          <City p={1} zoomK={1.15} lit={() => 1} />
          <Courier x={lerp(500, 1900, go)} y={790} s={1.6} />
          <rect x={lerp(-W, 0, wipe)} y="0" width={W} height={H} fill={NIGHT} />
        </svg>
      );
    }
  }
}

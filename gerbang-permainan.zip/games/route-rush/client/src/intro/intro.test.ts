import { statSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { hasLiteralCoinNumbers, introDurations, isContiguous } from "@route-rush/shared";
import timelineJson from "../../../shared/intro/timeline.json";
import { introData } from "./data";
import { cardText, playingAt, shotProgress, stillAt } from "./model";

const { timeline, stills, numbers } = introData;

describe("data intro (dari berkas acuan dan fungsi shared)", () => {
  it("angka trailer dihitung dari A-05: jebakan 9, hemat 8; rute jebakan = hop paling sedikit", () => {
    expect(introData.map.id).toBe("A-05");
    expect(numbers).toEqual({ trapCost: 9, optimalCost: 8 });
    expect(introData.trap).toEqual(["n0", "n2", "n3", "n5"]);
    expect(introData.optimal.at(0)).toBe("n0");
    expect(introData.optimal.at(-1)).toBe("n5");
    expect(cardText(timeline.trailer[4]!, numbers)).toBe("9 vs 8");
    expect(hasLiteralCoinNumbers(timelineJson)).toBe(false);
  });

  it("durasi: ident 8 s, trailer 45 s, ringkas 3 s dan 12 s", () => {
    expect(isContiguous(timeline.ident)).toBe(true);
    expect(isContiguous(timeline.trailer)).toBe(true);
    expect(introDurations(timeline)).toEqual({ identMs: 8000, trailerMs: 45000, identShortMs: 3000, trailerShortMs: 12000 });
  });

  it("teks layar maksimal 6 kata per kartu", () => {
    for (const s of timeline.trailer) if (s.screenText) expect(s.screenText.split(/\s+/).length).toBeLessThanOrEqual(6);
  });

  it("logo pembuat kecil (aset intro jauh di bawah 5 MB)", () => {
    expect(statSync(resolve(process.cwd(), "../assets/brand/logo.svg")).size).toBeLessThan(200_000);
  });
});

describe("jam dan pemilihan shot", () => {
  it("trailer penuh: shot dan kemajuan mengikuti waktu", () => {
    const a = playingAt(timeline, "TRAILER", "FULL", 20_500);
    expect(a.shot.id).toBe("shot-05");
    expect(shotProgress(a)).toBeCloseTo(0.5, 5);
    expect(playingAt(timeline, "TRAILER", "FULL", 0).shot.id).toBe("shot-01");
    expect(playingAt(timeline, "TRAILER", "FULL", 99_999).shot.id).toBe("shot-10");
    expect(playingAt(timeline, "TRAILER", "FULL", -5).shot.id).toBe("shot-01");
  });

  it("trailer ringkas memutar shot-04, 05, 08 masing-masing 4 detik dengan kemajuan penuh 0..1", () => {
    expect(playingAt(timeline, "TRAILER", "SHORT", 1000).shot.id).toBe("shot-04");
    expect(playingAt(timeline, "TRAILER", "SHORT", 5000).shot.id).toBe("shot-05");
    expect(playingAt(timeline, "TRAILER", "SHORT", 11_999).shot.id).toBe("shot-08");
    expect(shotProgress(playingAt(timeline, "TRAILER", "SHORT", 6000))).toBeCloseTo(0.5, 5);
  });

  it("ident ringkas adalah potongan 4000–7000 ms dari ident penuh", () => {
    expect(playingAt(timeline, "IDENT", "SHORT", 0).p).toBe(4000);
    expect(playingAt(timeline, "IDENT", "SHORT", 2999).p).toBe(6999);
    expect(playingAt(timeline, "IDENT", "FULL", 7500).shot.id).toBe("ident-6");
  });

  it("gerak dikurangi: enam gambar diam menutup seluruh 45 detik", () => {
    const seen = new Set<string>();
    for (let t = 0; t < 45_000; t += 250) seen.add(stillAt(timeline, stills, t));
    expect([...seen].sort()).toEqual([...stills].sort());
    expect(stillAt(timeline, stills, 0)).toBe("shot-02");
    expect(stillAt(timeline, stills, 44_999)).toBe("shot-09");
  });
});
import { useEffect, useRef, useState } from "react";
import { COPY } from "@route-rush/shared";
import logoUrl from "../../../assets/brand/logo.svg?url";
import makerNameRaw from "../../../assets/brand/name.txt?raw";
import type { HostState } from "../hostStore";
import { answerAudio, introAudio, voAudio } from "../audio/engine";
import { introData } from "./data";
import { IntroClock, cardText, playingAt, shotProgress, stillAt, subtitleOf } from "./model";
import { IdentScene, TrailerScene } from "./scenes";

/** Satu jam intro untuk seluruh aplikasi guru; uji dapat `seek` ke detik tertentu lewat `window.__rr.introClock`. */
export const introClock = new IntroClock();

const makerName = makerNameRaw.trim();

const prefersReduced = (): boolean => typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Memuat semua yang dibutuhkan intro sebelum sesi dibuat (font, logo). Aset intro hanya SVG di kode + logo, jauh di bawah 5 MB. */
export async function preloadIntro(onProgress: (f: number) => void): Promise<void> {
  const steps: (() => Promise<unknown>)[] = [
    () => document.fonts?.ready ?? Promise.resolve(),
    () => introAudio.load(() => undefined),
    () => answerAudio.preload(),
    async () => {
      const img = new Image();
      img.src = logoUrl;
      await img.decode().catch(() => undefined);
    },
    async () => void introData.timeline,
  ];
  let done = 0;
  for (const s of steps) {
    await s();
    onProgress(++done / steps.length);
  }
}

export function LoadingBar({ fraction }: { fraction: number }) {
  return (
    <div className="hload" role="progressbar" aria-valuemin={0} aria-valuemax={100} aria-valuenow={Math.round(fraction * 100)} aria-label="Memuat aset intro" data-testid="intro-loading">
      <i style={{ width: `${Math.round(fraction * 100)}%` }} />
    </div>
  );
}

export function IntroStage({ s }: { s: HostState }) {
  const phase = s.phase;
  const [auto, setAuto] = useState(0);
  const last = useRef(-1);
  const spoken = useRef("");
  const reduced = prefersReduced();

  useEffect(() => {
    let raf = 0;
    const tick = (): void => {
      if (phase && phase.durationMs !== null && s.phaseEndsAt !== null) {
        const t = phase.durationMs - (s.phaseEndsAt - performance.now());
        if (Math.abs(t - last.current) >= 16 || introClock.frozen) {
          last.current = t;
          setAuto(t);
        }
      }
      raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [phase, s.phaseEndsAt]);

  const t = Math.max(0, introClock.resolve(auto));
  const d = introData;
  const kind = phase?.phase === "INTRO_TRAILER" ? "TRAILER" : "IDENT";
  const mode = phase?.introMode ?? "FULL";
  const pl = playingAt(d.timeline, kind, mode, t);

  // suara: campuran musik + efek diputar dari posisi waktu fase menurut server (tidak diputar saat jam dibekukan oleh uji)
  const startedFor = useRef("");
  useEffect(() => {
    if (!phase || phase.durationMs === null || s.phaseEndsAt === null || introClock.frozen) return;
    const key = `${kind}_${mode}` as const;
    const id = `${key}-${s.phaseEndsAt}`;
    if (startedFor.current === id) return;
    startedFor.current = id;
    introAudio.play(key, phase.durationMs - (s.phaseEndsAt - performance.now()));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [kind, mode, s.phaseEndsAt]);
  useEffect(
    () => () => {
      introAudio.stop();
      voAudio.stop();
    },
    [],
  );

  // narasi diputar sekali per shot
  useEffect(() => {
    const key = `${kind}-${pl.shot.id}`;
    if (kind === "TRAILER" && spoken.current !== key) {
      const line = mode === "SHORT" ? (pl.index === 0 ? { id: "short", text: COPY.shortIntroVo } : null) : pl.shot.vo ? { id: pl.shot.id, text: pl.shot.vo } : null;
      if (line) {
        spoken.current = key;
        void voAudio.say(line.id, line.text);
      }
    }
  }, [kind, mode, pl.index, pl.shot.id, pl.shot.vo]);

  let scene;
  let card: string | null;
  let still = "";
  if (kind === "IDENT") {
    card = null;
    scene = <IdentScene ms={pl.p} ctx={{ logoUrl, makerName }} />;
  } else {
    // versi ringkas memakai shot-04/05/08; gerak dikurangi memakai gambar diam dengan durasi tetap 45 detik
    const stillId = reduced && mode === "FULL" ? stillAt(d.timeline, d.stills, t) : pl.shot.id;
    const stillShot = d.timeline.trailer.find((x) => x.id === stillId) ?? pl.shot;
    const p = reduced && mode === "FULL" ? 1 : shotProgress(pl);
    still = reduced && mode === "FULL" ? stillId : "";
    card = cardText(stillShot, d.numbers);
    scene = <TrailerScene shotId={stillId} ctx={{ p, d, logoUrl, makerName, card }} />;
  }
  const subtitle = kind === "TRAILER" ? (mode === "SHORT" ? COPY.shortIntroVo : subtitleOf(pl.shot)) : null;

  return (
    <section className="intro" data-testid="host-intro" data-kind={kind} data-shot={pl.shot.id} data-t={Math.round(t)} data-reduced={reduced ? "1" : "0"} data-still={still} aria-label="Intro Route Rush">
      <div className="intro-frame">{scene}</div>
      {card ? (
        <span className="sr-only" data-testid="intro-card">
          {card}
        </span>
      ) : null}
      <p className="intro-sub" data-testid="intro-sub" aria-live="polite">
        {subtitle ?? " "}
      </p>
    </section>
  );
}

/** Tombol yang harus ditahan (2 detik) agar tidak terpencet tidak sengaja. */
export function HoldButton({ label, holdMs = 2000, onDone, testid }: { label: string; holdMs?: number; onDone: () => void; testid: string }) {
  const [progress, setProgress] = useState(0);
  const start = useRef<number | null>(null);
  const raf = useRef(0);

  const cancel = (): void => {
    start.current = null;
    cancelAnimationFrame(raf.current);
    setProgress(0);
  };
  const begin = (): void => {
    if (start.current !== null) return;
    start.current = performance.now();
    const tick = (): void => {
      if (start.current === null) return;
      const f = (performance.now() - start.current) / holdMs;
      if (f >= 1) {
        cancel();
        onDone();
        return;
      }
      setProgress(f);
      raf.current = requestAnimationFrame(tick);
    };
    raf.current = requestAnimationFrame(tick);
  };
  useEffect(() => cancel, []);

  return (
    <button
      type="button"
      className="btn hsmall hold"
      onPointerDown={begin}
      onPointerUp={cancel}
      onPointerLeave={cancel}
      onPointerCancel={cancel}
      onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && !e.repeat && begin()}
      onKeyUp={cancel}
      onBlur={cancel}
      aria-label={`${label} (tahan 2 detik)`}
      data-testid={testid}
      data-progress={progress.toFixed(2)}
    >
      <i className="hold-fill" style={{ transform: `scaleX(${progress})` }} />
      <span>{label} · tahan 2 detik</span>
    </button>
  );
}

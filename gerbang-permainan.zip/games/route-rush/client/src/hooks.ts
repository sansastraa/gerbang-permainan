import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { GameClient, GameState } from "./store";

export const useGame = (game: GameClient): GameState => useSyncExternalStore(game.subscribe, game.getSnapshot);

/** Jam yang berdetak tiap `ms` (untuk bilah waktu dan hitung mundur). */
export function useNow(ms = 100): number {
  const [now, setNow] = useState(() => performance.now());
  useEffect(() => {
    const id = window.setInterval(() => setNow(performance.now()), ms);
    return () => window.clearInterval(id);
  }, [ms]);
  return now;
}

export function enterFullscreen(): void {
  try {
    const el = document.documentElement;
    if (!document.fullscreenElement && typeof el.requestFullscreen === "function") void el.requestFullscreen().catch(() => undefined);
  } catch {
    /* peramban tanpa layar penuh (mis. iPhone): permainan tetap jalan */
  }
}

/**
 * Menangkap keluar tab/aplikasi (visibilitychange) pada fase LOOK dan WALK, serta keluar dari layar penuh.
 * Mengembalikan `needFullscreen` bila siswa perlu diminta kembali ke layar penuh.
 */
export function useIntegrity(game: GameClient, phase: string | undefined): { needFullscreen: boolean; dismiss: () => void } {
  const [needFullscreen, setNeed] = useState(false);
  const entered = useRef(false);
  const lost = useRef(false);
  const phaseRef = useRef(phase);
  phaseRef.current = phase;

  useEffect(() => {
    const t0 = performance.now();
    const playing = (): boolean => phaseRef.current === "LOOK" || phaseRef.current === "WALK";
    const onVisibility = (): void => {
      if (!playing()) return;
      if (document.visibilityState === "hidden") {
        if (lost.current) return;
        lost.current = true;
        game.integrity("FOCUS_LOST", Math.round(performance.now() - t0));
      } else if (lost.current) {
        lost.current = false;
        game.integrity("FOCUS_BACK", Math.round(performance.now() - t0));
      }
    };
    const onFullscreen = (): void => {
      if (document.fullscreenElement) {
        entered.current = true;
        setNeed(false);
        return;
      }
      if (!entered.current) return;
      const started = phaseRef.current !== undefined && phaseRef.current !== "LOBBY" && phaseRef.current !== "ENDED";
      if (!started) return;
      if (playing()) game.integrity("FULLSCREEN_EXIT", Math.round(performance.now() - t0));
      setNeed(true);
    };
    document.addEventListener("visibilitychange", onVisibility);
    document.addEventListener("fullscreenchange", onFullscreen);
    return () => {
      document.removeEventListener("visibilitychange", onVisibility);
      document.removeEventListener("fullscreenchange", onFullscreen);
    };
  }, [game]);

  // kembali ke tab setelah fase berganti: bersihkan penanda agar kehilangan fokus berikutnya tercatat lagi
  useEffect(() => {
    if (phase !== "LOOK" && phase !== "WALK") lost.current = false;
  }, [phase]);

  return {
    needFullscreen,
    dismiss: () => {
      enterFullscreen();
      setNeed(false);
    },
  };
}

/** Berlangganan store mana pun yang punya subscribe/getSnapshot (GameClient atau HostClient). */
export const useStore = <S,>(store: { subscribe: (l: () => void) => () => void; getSnapshot: () => S }): S => useSyncExternalStore(store.subscribe, store.getSnapshot);

import { useEffect, useMemo, useRef, useState } from "react";
import { COPY, DEFAULT_SEAT_LAYOUT, SETTING_LIMITS, defaultSettings, effectiveRoundMaxMs, mergeSettings, settingsRoundIds, type RosterEntry, type SeatLayout, type SessionSettings } from "@route-rush/shared";
import { answerAudio, introAudio, narrationStatus, voAudio } from "./audio/engine";
import { HoldButton, IntroStage, LoadingBar, preloadIntro } from "./intro/IntroStage";
import { studentAddress, studentUrl, withBase } from "./basePath";
import { MapView } from "./MapView";
import { RulesTicker } from "./Rules";
import { ReportScreen } from "./HostReport";
import { READY_MESSAGE, buildReturnUrl, parseImportMessage, type ImportedRoster } from "./importRoster";
import { useNow, useStore } from "./hooks";
import type { HostClient, HostState } from "./hostStore";

// ---------------------------------------------------------------- formulir pengaturan

export interface Draft {
  mode: SessionSettings["mode"];
  introMode: SessionSettings["introMode"];
  pool: SessionSettings["pool"];
  lookSeconds: string;
  walkSeconds: string;
  probeSeconds: string;
  resultSeconds: string;
  quota: string;
  rounds: string;
  hidden: string;
  rows: string;
  cols: string;
  aisle: string;
  seatsEnabled: boolean;
  /** Soal beda untuk tiap siswa (anti contek). Aktif bawaannya pada layar guru. */
  unique: boolean;
}

export const draftFrom = (s: SessionSettings | null, students = 0): Draft => ({
  mode: s?.mode ?? "STANDARD",
  introMode: s?.introMode ?? "FULL",
  pool: s?.pool ?? "A",
  lookSeconds: s?.lookSeconds == null ? "" : String(s.lookSeconds),
  walkSeconds: s?.walkSeconds == null ? "" : String(s.walkSeconds),
  probeSeconds: String(s?.probeSeconds ?? 5),
  resultSeconds: String(s?.resultSeconds ?? 3),
  quota: s ? String(s.quota) : students > 0 ? String(students) : "",
  rounds: s?.roundIds ? s.roundIds.join(",") : "",
  hidden: (s?.hiddenRounds ?? []).join(","),
  rows: String((s?.seatLayout ?? DEFAULT_SEAT_LAYOUT).rows),
  cols: String((s?.seatLayout ?? DEFAULT_SEAT_LAYOUT).cols),
  aisle: (s?.seatLayout ?? DEFAULT_SEAT_LAYOUT).aisleAfterCols.join(","),
  seatsEnabled: (s?.seatLayout ?? DEFAULT_SEAT_LAYOUT).enabled,
  unique: s ? s.uniqueMaps : true,
});

const num = (v: string): number => (v.trim() === "" ? Number.NaN : Number(v));

/** Draft → bagian pengaturan untuk server (kolom kosong pada waktu = bawaan ronde). */
export function toPatch(d: Draft): Partial<SessionSettings> {
  const seatLayout: SeatLayout = {
    rows: num(d.rows),
    cols: num(d.cols),
    aisleAfterCols: d.aisle
      .split(",")
      .map((x) => x.trim())
      .filter(Boolean)
      .map(Number),
    enabled: d.seatsEnabled,
  };
  return {
    mode: d.mode,
    introMode: d.introMode,
    pool: d.pool,
    lookSeconds: d.lookSeconds.trim() === "" ? null : num(d.lookSeconds),
    walkSeconds: d.walkSeconds.trim() === "" ? null : num(d.walkSeconds),
    probeSeconds: num(d.probeSeconds),
    resultSeconds: num(d.resultSeconds),
    quota: num(d.quota),
    roundIds: d.rounds.trim() === "" ? null : d.rounds.split(",").map((x) => Number(x.trim())),
    hiddenRounds: d.pool === "T" ? parseIds(d.hidden).filter((n) => n > 0) : [],
    uniqueMaps: d.unique,
    seatLayout,
  };
}

/** Pilihan satu-dari-beberapa berbentuk segmen. Inputnya tetap radio asli (menutupi segmen) agar bisa dipakai keyboard dan pembaca layar. */
function Seg<T extends string>({ legend, name, value, options, onChange }: { legend: string; name: string; value: T; options: { v: T; label: string; id: string }[]; onChange: (v: T) => void }) {
  return (
    <fieldset className="hseg">
      <legend>{legend}</legend>
      <div className="hseg-row">
        {options.map((o) => (
          <label key={o.v} className={`hseg-opt${value === o.v ? " on" : ""}`}>
            <input type="radio" name={name} checked={value === o.v} onChange={() => onChange(o.v)} data-testid={o.id} />
            <span>{o.label}</span>
          </label>
        ))}
      </div>
    </fieldset>
  );
}

function Field({ label, hint, children }: { label: string; hint?: string; children: React.ReactNode }) {
  return (
    <label className="hfield">
      <span>{label}</span>
      {children}
      {hint ? <small>{hint}</small> : null}
    </label>
  );
}

type Mix = "VISIBLE" | "HIDDEN" | "MIXED";
const ODD = [1, 3, 5, 7, 9];
const EVEN = [2, 4, 6, 8, 10];
const parseIds = (v: string): number[] => v.split(",").map((x) => Number(x.trim())).filter((n) => Number.isInteger(n) && n >= 0);

/** Daftar ronde dan ronde ingatan untuk sejumlah soal dan jenisnya. Bank A/B: ganjil = hitung, genap = ingatan. Tantangan: nomor 1..N, ingatan dipilih lewat `hidden`. */
export function planRounds(pool: Draft["pool"], intro: Draft["introMode"], count: number, mix: Mix): { rounds: string; hidden: string } {
  const lead = intro === "SHORT" ? [0] : [];
  if (pool === "T") {
    const ids = Array.from({ length: count }, (_, i) => i + 1);
    const hidden = mix === "VISIBLE" ? [] : mix === "HIDDEN" ? ids : ids.filter((n) => n % 2 === 0);
    return { rounds: [...lead, ...ids].join(","), hidden: hidden.join(",") };
  }
  const source = mix === "VISIBLE" ? ODD : mix === "HIDDEN" ? EVEN : [...ODD, ...EVEN].sort((x, y) => x - y);
  return { rounds: [...lead, ...source.slice(0, count)].join(","), hidden: "" };
}

const maxCount = (pool: Draft["pool"], mix: Mix): number => (pool === "T" || mix === "MIXED" ? 10 : 5);

/** Jumlah soal (1–10), jenis soal (hitung, ingatan, atau campuran), dengan pilihan cepat. Mengisi daftar ronde di bawahnya. */
function RoundCount({ d, set }: { d: Draft; set: (d: Draft) => void }) {
  const listed = d.rounds.trim() === "" ? null : parseIds(d.rounds).filter((n) => n > 0);
  const hiddenList = parseIds(d.hidden);
  const count = listed ? listed.length : d.mode === "STANDARD" ? 10 : 6;
  const mix: Mix = (() => {
    if (!listed) return "MIXED";
    if (d.pool === "T") return hiddenList.length === 0 ? "VISIBLE" : hiddenList.length >= listed.length ? "HIDDEN" : "MIXED";
    if (listed.every((n) => n % 2 === 1)) return "VISIBLE";
    if (listed.every((n) => n % 2 === 0)) return "HIDDEN";
    return "MIXED";
  })();
  const apply = (n: number, m: Mix): void => set({ ...d, ...planRounds(d.pool, d.introMode, Math.min(maxCount(d.pool, m), Math.max(1, n)), m) });
  const cap = maxCount(d.pool, mix);
  // ganti bank soal: susun ulang daftar ronde menurut jumlah dan jenis yang sama
  const lastPool = useRef(d.pool);
  useEffect(() => {
    if (lastPool.current !== d.pool) {
      lastPool.current = d.pool;
      if (d.rounds.trim() !== "") apply(count, mix);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [d.pool]);
  return (
    <fieldset className="hchoice hrounds" data-testid="round-count">
      <legend>Jumlah soal</legend>
      <div className="hstepper">
        <button type="button" className="hstep" onClick={() => apply(count - 1, mix)} disabled={count <= 1} aria-label="Kurangi satu soal" data-testid="round-minus">
          −
        </button>
        <output aria-live="polite" data-testid="round-number">
          <b>{count}</b> soal
        </output>
        <button type="button" className="hstep" onClick={() => apply(count + 1, mix)} disabled={count >= cap} aria-label="Tambah satu soal" data-testid="round-plus">
          +
        </button>
        <span className="hchips" role="group" aria-label="Pilihan cepat">
          {[3, 5, 7, 10]
            .filter((n) => n <= cap)
            .map((n) => (
              <button key={n} type="button" className={`hchip${count === n ? " on" : ""}`} aria-pressed={count === n} onClick={() => apply(n, mix)} data-testid={`round-chip-${n}`}>
                {n}
              </button>
            ))}
        </span>
      </div>
      <div className="hseg-row hmix" role="radiogroup" aria-label="Jenis soal">
        {(
          [
            ["VISIBLE", "Hitung", "angka tampil", "mix-visible"],
            ["HIDDEN", "Ingatan", "angka hilang", "mix-hidden"],
            ["MIXED", "Campuran", "selang-seling", "mix-mixed"],
          ] as const
        ).map(([v, label, sub, id]) => (
          <label key={v} className={`hseg-opt${mix === v ? " on" : ""}`}>
            <input type="radio" name="mix" checked={mix === v} onChange={() => apply(Math.min(count, maxCount(d.pool, v)), v)} data-testid={id} />
            <span>
              {label}
              <small>{sub}</small>
            </span>
          </label>
        ))}
      </div>
      <small>
        {mix === "VISIBLE" ? "Semua soal berupa hitung rute; angka bobot tetap terlihat." : mix === "HIDDEN" ? "Angka bobot hilang saat berjalan, lalu ada pertanyaan ingatan (waktunya diatur di bawah)." : "Soal hitung dan soal ingatan bergantian."}{" "}
        {d.pool !== "T" && mix !== "MIXED" ? "Bank A/B menyediakan paling banyak 5 soal untuk satu jenis; pilih Campuran atau bank Tantangan untuk sampai 10." : ""} Ronde latihan tidak dihitung sebagai soal.
      </small>
    </fieldset>
  );
}
export function SettingsForm({ d, set, lobby, stations = false, quotaMax }: { d: Draft; set: (d: Draft) => void; lobby: boolean; stations?: boolean; quotaMax?: number }) {
  const up = <K extends keyof Draft>(k: K, v: Draft[K]): void => set({ ...d, [k]: v });
  const L = SETTING_LIMITS;
  const intro = !lobby ? (
    <Seg
      key="intro"
      legend="Intro"
      name="intro"
      value={d.introMode}
      onChange={(v) => up("introMode", v)}
      options={[
        { v: "FULL", label: "Sesi perdana kelas ini", id: "intro-full" },
        { v: "SHORT", label: "Sudah pernah main", id: "intro-short" },
      ]}
    />
  ) : null;
  const mode = (
    <Seg
      key="mode"
      legend="Mode"
      name="mode"
      value={d.mode}
      onChange={(v) => up("mode", v)}
      options={[
        { v: "STANDARD", label: "Standar · 10 soal", id: "mode-standard" },
        { v: "QUICK", label: "Kilat · 6 soal", id: "mode-quick" },
      ]}
    />
  );
  const pool = (
    <Seg
      key="pool"
      legend="Bentuk soal"
      name="pool"
      value={d.pool}
      onChange={(v) => up("pool", v)}
      options={[
        { v: "A", label: "A", id: "pool-a" },
        { v: "B", label: "B", id: "pool-b" },
        { v: "T", label: "Tantangan", id: "pool-t" },
      ]}
    />
  );
  const count = <RoundCount key="count" d={d} set={set} />;
  const custom = (
    <Field key="custom" label="Pilih nomor ronde sendiri (lanjutan)" hint="mis. 1,2,3 (0–10); kosong = sesuai mode">
      <input value={d.rounds} onChange={(e) => up("rounds", e.target.value)} data-testid="set-rounds" />
    </Field>
  );
  const times = [
    <Field key="look" label="Waktu menghafal (detik)" hint={`${L.lookSeconds.min}–${L.lookSeconds.max}; kosong = bawaan ronde`}>
      <input inputMode="decimal" value={d.lookSeconds} onChange={(e) => up("lookSeconds", e.target.value)} data-testid="set-look" />
    </Field>,
    <Field key="walk" label="Waktu berjalan (detik)" hint={`${L.walkSeconds.min}–${L.walkSeconds.max}; kosong = bawaan ronde`}>
      <input inputMode="decimal" value={d.walkSeconds} onChange={(e) => up("walkSeconds", e.target.value)} data-testid="set-walk" />
    </Field>,
    <Field key="probe" label="Waktu soal ingatan (detik)" hint={`${L.probeSeconds.min}–${L.probeSeconds.max}`}>
      <input inputMode="decimal" value={d.probeSeconds} onChange={(e) => up("probeSeconds", e.target.value)} data-testid="set-probe" />
    </Field>,
    <Field key="result" label="Waktu layar hasil ronde (detik)" hint={`${L.resultSeconds.min}–${L.resultSeconds.max}; lebih lama agar semua nama sempat disebut`}>
      <input inputMode="decimal" value={d.resultSeconds} onChange={(e) => up("resultSeconds", e.target.value)} data-testid="set-result" />
    </Field>,
  ];
  const quota = (
    <Field key="quota" label="Kuota siswa yang harus masuk" hint={quotaMax ? `kosong = semua (${quotaMax} siswa)` : "kosong = semua siswa pada daftar"}>
      <input inputMode="numeric" value={d.quota} onChange={(e) => up("quota", e.target.value)} data-testid="set-quota" />
    </Field>
  );
  const unique = (
    <fieldset className="hchoice" key="unique">
      <legend>Anti contek</legend>
      <label className={`hswitch${d.unique ? " on" : ""}`}>
        <input type="checkbox" checked={d.unique} onChange={(e) => up("unique", e.target.checked)} data-testid="set-unique" />
        <i aria-hidden="true" />
        <span>Soal beda tiap siswa</span>
      </label>
      <small>Setiap siswa mendapat peta buatan sendiri yang setara tingkatnya, jadi tidak ada yang bisa menyontek atau bertanya. Soal pertama tetap yang termudah.</small>
    </fieldset>
  );
  const seats = (
    <fieldset className="hchoice" key="seats">
      <legend>Denah kursi</legend>
      <label className={`hswitch${d.seatsEnabled ? " on" : ""}`}>
        <input type="checkbox" checked={d.seatsEnabled} onChange={(e) => up("seatsEnabled", e.target.checked)} data-testid="set-seats" />
        <i aria-hidden="true" />
        <span>Pakai denah</span>
      </label>
      <div className="hrow">
        <Field label="Baris">
          <input inputMode="numeric" value={d.rows} onChange={(e) => up("rows", e.target.value)} data-testid="set-rows" />
        </Field>
        <Field label="Kolom">
          <input inputMode="numeric" value={d.cols} onChange={(e) => up("cols", e.target.value)} data-testid="set-cols" />
        </Field>
        <Field label="Lorong setelah kolom" hint="mis. 3 atau 3,6">
          <input value={d.aisle} onChange={(e) => up("aisle", e.target.value)} data-testid="set-aisle" />
        </Field>
      </div>
    </fieldset>
  );
  if (stations) {
    return (
      <div className="hstations-form" data-testid="settings-form">
        <StationBlock n={2} title="Soal" lead="Pilih bank soal, jumlahnya, dan jenisnya.">
          {mode}
          {pool}
          {count}
          {custom}
        </StationBlock>
        <StationBlock n={3} title="Waktu" lead="Kosongkan untuk memakai waktu bawaan tiap ronde.">
          {times}
        </StationBlock>
        <StationBlock n={4} title="Kelas dan denah" lead="Intro, kuota yang harus masuk, dan susunan kursi.">
          {intro}
          {quota}
          {unique}
          {seats}
        </StationBlock>
      </div>
    );
  }
  return (
    <div className="hform" data-testid="settings-form">
      {intro}
      {mode}
      {pool}
      {times}
      {quota}
      {unique}
      {count}
      {custom}
      {seats}
    </div>
  );
}

/** Satu stasiun pada jalur perakitan sesi: titik bernomor di jalur, judul, dan isian di bawahnya. */
function StationBlock({ n, title, lead, done = true, children }: { n: number; title: string; lead: string; done?: boolean; children: React.ReactNode }) {
  return (
    <section className={`hstation${done ? " done" : ""}`}>
      <span className="hstation-dot" aria-hidden="true">
        {done ? "✓" : n}
      </span>
      <h2>{title}</h2>
      <p className="hstation-lead">{lead}</p>
      <div className="hform">{children}</div>
    </section>
  );
}
// ---------------------------------------------------------------- buat sesi

function parseRoster(text: string): RosterEntry[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter(Boolean)
    .map((line, i) => {
      const [name, kelas] = line.split(/[;\t]/).map((x) => x.trim());
      return { id: `siswa-${i + 1}`, name: name as string, ...(kelas ? { kelas } : {}) };
    });
}

/** Isian layar buat sesi disimpan di peramban ini agar tidak hilang saat halaman dimuat ulang. */
const DRAFT_KEY = "rr.draft";
/** Panel "Atur sesi sendiri" tertutup bawaannya; pilihan buka/tutup guru diingat di peramban ini. */
const ADVANCED_KEY = "rr.advanced";
interface SavedDraft {
  text: string;
  imported: ImportedRoster | null;
  settings: Draft;
}

/** Layar buat sesi selalu mulai kosong: isian sesi sebelumnya tidak dipulihkan. Sisa simpanan lama dibersihkan. */
function readDraft(): SavedDraft {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch {
    /* penyimpanan dimatikan: tidak ada yang perlu dibersihkan */
  }
  return { text: "", imported: null, settings: draftFrom(null) };
}

function CreateScreen({ host, s }: { host: HostClient; s: HostState }) {
  const [saved] = useState(readDraft);
  const [text, setText] = useState(saved.text);
  const [d, setD] = useState<Draft>(saved.settings);
  const [busy, setBusy] = useState(false);
  const [loaded, setLoaded] = useState(0);
  const [imported, setImported] = useState<ImportedRoster | null>(saved.imported);
  const [advanced, setAdvanced] = useState<boolean>(() => {
    try {
      return localStorage.getItem(ADVANCED_KEY) === "1";
    } catch {
      return false;
    }
  });
  useEffect(() => {
    void preloadIntro(setLoaded);
  }, []);
  // Daftar siswa dari SIMPETERI: halaman SIMPETERI membuka layar ini sebagai jendela baru lalu mengirim daftar lewat postMessage.
  // Hanya pesan dari jendela pembuka yang diterima, dan bentuknya diperiksa (importRoster.ts).
  useEffect(() => {
    const onMessage = (e: MessageEvent): void => {
      if (!window.opener || e.source !== window.opener) return;
      const parsed = parseImportMessage(e.data, e.origin);
      if (parsed) setImported(parsed);
    };
    window.addEventListener("message", onMessage);
    try {
      window.opener?.postMessage({ type: READY_MESSAGE }, "*");
    } catch {
      /* tanpa jendela pembuka: pakai daftar manual */
    }
    return () => window.removeEventListener("message", onMessage);
  }, []);
  const roster = imported ? imported.roster : parseRoster(text);
  const names = new Set(roster.map((r) => r.name.toLowerCase()));
  const dup = names.size !== roster.length;
  const ready = roster.length > 0 && !dup && loaded >= 1;
  const summary = useMemo(() => {
    const listed = d.rounds.trim() === "" ? null : parseIds(d.rounds).filter((n) => n > 0);
    const count = listed ? listed.length : d.mode === "STANDARD" ? 10 : 6;
    const hid = parseIds(d.hidden).filter((n) => n > 0);
    const kind = d.pool === "T" ? (hid.length === 0 ? "Hitung" : hid.length >= count ? "Ingatan" : "Campuran") : listed ? (listed.every((n) => n % 2 === 1) ? "Hitung" : listed.every((n) => n % 2 === 0) ? "Ingatan" : "Campuran") : "Campuran";
    const merged = mergeSettings(defaultSettings(Math.max(1, roster.length)), toPatch({ ...d, quota: String(Math.max(1, roster.length)) }), Math.max(1, roster.length));
    const minutes = merged.ok ? Math.max(1, Math.round(settingsRoundIds(merged.settings).reduce((sum, id) => sum + effectiveRoundMaxMs(id, merged.settings), 0) / 60000)) : null;
    return { count, kind, minutes };
  }, [d, roster.length]);
  return (
    <section className="hscreen hcreate hmin" data-testid="host-create">
      <div className="hcreate-head">
        <p className="hkicker">Sesi baru</p>
        <h1 className="htitle">Siapa yang main hari ini?</h1>
        <p className="hsub">Tempel nama siswa, satu per baris. Dari SIMPETERI, daftar masuk sendiri.</p>
      </div>
      <div className="hroster">
        {imported ? (
          <div data-testid="imported-roster" className="himported-wrap">
            <p className="hsub">
              Daftar dari SIMPETERI{imported.kelas ? ` · Kelas ${imported.kelas}` : ""} · {imported.roster.length} siswa
            </p>
            <ol className="himported">
              {imported.roster.map((r) => (
                <li key={r.id} data-testid={`imported-${r.absen ?? "x"}`}>
                  {r.absen ? <b>{r.absen}.</b> : null} {r.name}
                </li>
              ))}
            </ol>
            <button type="button" className="btn hsmall" onClick={() => setImported(null)} data-testid="imported-clear">
              Pakai daftar manual
            </button>
          </div>
        ) : (
          <Field label="Daftar siswa" hint="Satu nama per baris; boleh ditambah ;kelas di belakangnya.">
            <textarea rows={7} value={text} onChange={(e) => setText(e.target.value)} placeholder={"Ani Lestari\nBudi Santoso\nCitra Dewi"} data-testid="roster-input" />
          </Field>
        )}
        <div className="hroster-foot">
          <p className={`hcount-note${dup ? " bad" : ""}`} data-testid="roster-count">
            {roster.length} siswa{dup ? " · ada nama kembar" : ""}
          </p>
          {!imported && text !== "" ? (
            <button type="button" className="hlink" onClick={() => setText("")} data-testid="roster-clear">
              Kosongkan
            </button>
          ) : null}
        </div>
        {!imported && roster.length > 0 ? (
          <ul className="hroster-chips" aria-hidden="true" data-testid="roster-chips">
            {roster.slice(0, 40).map((r) => (
              <li key={r.id}>{r.name}</li>
            ))}
            {roster.length > 40 ? <li>+{roster.length - 40} lagi</li> : null}
          </ul>
        ) : null}
      </div>
      <details
        className="hmore"
        open={advanced}
        onToggle={(e) => {
          const open = (e.currentTarget as HTMLDetailsElement).open;
          setAdvanced(open);
          try {
            localStorage.setItem(ADVANCED_KEY, open ? "1" : "0");
          } catch {
            /* tanpa penyimpanan: panel tetap menutup saat dimuat ulang */
          }
        }}
        data-testid="more-settings"
      >
        <summary>Atur sesi sendiri</summary>
        <SettingsForm d={d} set={setD} lobby={false} quotaMax={roster.length} />
      </details>
      <footer className="hmake">
        <p className="hmake-sum" data-testid="session-summary">
          <span>
            <b>{roster.length}</b> siswa
          </span>
          <span>
            <b>{summary.count}</b> soal
          </span>
          <span data-testid="est-minutes">{summary.minutes === null ? "–" : `± ${summary.minutes} menit`}</span>
        </p>
        {loaded < 1 ? <LoadingBar fraction={loaded} /> : null}
        {s.error ? (
          <p className="error" role="alert" data-testid="host-error">
            {s.error}
          </p>
        ) : null}
        <button
          type="button"
          className="btn coin hbtn"
          disabled={!ready || busy}
          onClick={async () => {
            introAudio.unlock(); // klik ini adalah gestur yang mengizinkan suara intro
            setBusy(true);
            const quota = d.quota.trim() === "" || num(d.quota) > roster.length ? String(roster.length) : d.quota;
            await host.create(roster, toPatch({ ...d, quota }), imported && (imported.pin || imported.kembali) ? { ...(imported.pin ? { pin: imported.pin } : {}), ...(imported.kembali ? { kembali: imported.kembali } : {}) } : undefined);
            setBusy(false);
          }}
          data-testid="create-btn"
        >
          Buat sesi
        </button>
        <p className="hmake-note">
          {roster.length === 0 ? <span className="hwhy">Isi daftar siswa dulu</span> : null}
          {dup ? <span className="hwhy">Ada nama kembar: bedakan lebih dulu</span> : null}
          {roster.length > 0 && !dup && loaded < 1 ? <span className="hwhy">Memuat aset intro…</span> : null}
        </p>
      </footer>
    </section>
  );
}

// ---------------------------------------------------------------- unsur tampilan bersama

/** Cincin kemajuan (SVG). `value` 0..1; isi cincin ada di `children`. */
function Ring({ value, size = 240, stroke = 18, tone = "coin", children }: { value: number; size?: number; stroke?: number; tone?: "coin" | "route" | "school"; children?: React.ReactNode }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const v = Math.min(1, Math.max(0, value));
  return (
    <div className={`hring hring-${tone}`} style={{ width: size, height: size }}>
      <svg viewBox={`0 0 ${size} ${size}`} width={size} height={size} aria-hidden="true">
        <circle className="hring-track" cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} fill="none" />
        <circle className="hring-bar" cx={size / 2} cy={size / 2} r={r} strokeWidth={stroke} fill="none" strokeDasharray={c} strokeDashoffset={c * (1 - v)} strokeLinecap="butt" transform={`rotate(-90 ${size / 2} ${size / 2})`} />
      </svg>
      <div className="hring-in">{children}</div>
    </div>
  );
}

/** Satu titik per siswa: terisi bila sudah masuk/siap/sampai. Dekoratif; angka sebenarnya ada di teks di sebelahnya. */
function DotRow({ total, filled }: { total: number; filled: number }) {
  const n = Math.max(0, Math.min(total, 60));
  return (
    <div className="hdots" aria-hidden="true">
      {Array.from({ length: n }, (_, i) => (
        <i key={i} className={i < filled ? "on" : ""} />
      ))}
    </div>
  );
}

const STATIONS = ["Lobi", "Latihan", "Ronde", "Hasil", "Podium"] as const;
function stationOf(phase: string | undefined): number {
  switch (phase) {
    case "LOBBY":
    case "COUNTDOWN":
      return 0;
    case "TUTORIAL":
      return 1;
    case "LOOK":
    case "WALK":
    case "PROBE":
      return 2;
    case "RESULT":
    case "LEADERBOARD":
      return 3;
    case "PODIUM":
    case "ENDED":
      return 4;
    default:
      return -1;
  }
}

/** Lintasan sesi seperti peta rute: tiap fase besar adalah satu halte; halte yang sudah dilewati terisi. */
function Stations({ s }: { s: HostState }) {
  const cur = stationOf(s.phase?.phase);
  const skipTutorial = s.settings?.introMode === "SHORT";
  const items = STATIONS.map((name, i) => ({ name, i })).filter((x) => !(skipTutorial && x.name === "Latihan"));
  const p = s.phase;
  return (
    <ol className="hstations" aria-label="Jalannya sesi" data-testid="stations">
      {items.map((x) => (
        <li key={x.name} className={x.i < cur ? "done" : x.i === cur ? "now" : ""} aria-current={x.i === cur ? "step" : undefined}>
          <i aria-hidden="true" />
          <span>{x.name === "Ronde" && x.i === cur && p?.displayIndex ? `Ronde ${p.displayIndex}/${p.totalRounds}` : x.name}</span>
        </li>
      ))}
    </ol>
  );
}

/** Alamat yang diketik siswa di HP; diketuk untuk disalin. */
function JoinChip() {
  const [copied, setCopied] = useState(false);
  const addr = typeof location === "undefined" ? "" : studentAddress(location.host);
  return (
    <button
      type="button"
      className="hjoin"
      title="Ketuk untuk menyalin alamat siswa"
      onClick={() => {
        void navigator.clipboard?.writeText(studentUrl(location.protocol, location.host)).then(
          () => {
            setCopied(true);
            window.setTimeout(() => setCopied(false), 1600);
          },
          () => undefined,
        );
      }}
      data-testid="join-chip"
    >
      <small>{copied ? "Tersalin" : "Siswa buka"}</small>
      <b>{addr}</b>
    </button>
  );
}

function AppBar({ s }: { s: HostState }) {
  return (
    <header className="happbar" data-testid="appbar">
      <div className="hbrand" aria-label="MinX Arena, Route Rush">
        <span className="hbrand-mark" aria-hidden="true">
          <svg viewBox="0 0 32 32" width="26" height="26" focusable="false"><line x1="9" y1="16" x2="23" y2="16" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /><circle cx="6.5" cy="16" r="4.5" fill="#fff" /><circle cx="25.5" cy="16" r="4.5" fill="currentColor" /></svg>
        </span>
        <span className="hbrand-text">
          <small>MinX Arena</small>
          <b>Route Rush</b>
        </span>
      </div>
      {s.created ? <Stations s={s} /> : <span className="hbar-note">Guru</span>}
      <JoinChip />
    </header>
  );
}

// ---------------------------------------------------------------- lobi

function SeatMap({ host, layout, s }: { host: HostClient; layout: SeatLayout; s: HostState }) {
  const players = s.lobby?.players ?? [];
  const initials = (n: string): string =>
    n
      .split(/\s+/)
      .filter(Boolean)
      .slice(0, 2)
      .map((w) => (w[0] ?? "").toUpperCase())
      .join("");
  return (
    <div className="hseats" data-testid="host-seatmap">
      <div className="hboard">Proyektor / papan tulis</div>
      {Array.from({ length: layout.rows }, (_, r) => (
        <div key={r} className="hseatrow">
          {Array.from({ length: layout.cols }, (_, c) => {
            const p = players.find((x) => x.seat?.row === r && x.seat.col === c);
            return (
              <span key={c} className="hseatcell">
                <button
                  type="button"
                  className={`hseat${p ? " taken" : ""}${p && !p.connected ? " off" : ""}`}
                  onClick={() => p && host.clearSeat(r, c)}
                  title={p ? `Kosongkan kursi ${p.name}` : "Kursi kosong"}
                  aria-label={p ? `Kursi baris ${r + 1} kolom ${c + 1}: ${p.name}. Ketuk untuk mengosongkan` : `Kursi baris ${r + 1} kolom ${c + 1} kosong`}
                  data-testid={`hseat-${r}-${c}`}
                >
                  {p ? initials(p.name) : ""}
                </button>
                {layout.aisleAfterCols.includes(c + 1) ? <i className="haisle" aria-hidden="true" /> : null}
              </span>
            );
          })}
        </div>
      ))}
    </div>
  );
}

const initialsOf = (n: string): string =>
  n
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => (w[0] ?? "").toUpperCase())
    .join("");

/** Nama siswa yang baru saja masuk (setelah PIN dan pilih nama) untuk ucapan selamat datang sesaat di layar guru. */
function useJoinToasts(players: { id: string; name: string }[]): { id: string; name: string }[] {
  const [seen] = useState(() => new Set<string>(players.map((p) => p.id)));
  const [toasts, setToasts] = useState<{ id: string; name: string }[]>([]);
  useEffect(() => {
    const fresh = players.filter((p) => !seen.has(p.id));
    if (fresh.length === 0) return;
    for (const p of fresh) seen.add(p.id);
    setToasts((t) => [...t, ...fresh.map((p) => ({ id: p.id, name: p.name }))].slice(-4));
    const ids = new Set(fresh.map((p) => p.id));
    window.setTimeout(() => setToasts((t) => t.filter((x) => !ids.has(x.id))), 3600);
  }, [players, seen]);
  return toasts;
}

function Lobby({ host, s }: { host: HostClient; s: HostState }) {
  const toasts = useJoinToasts(s.lobby?.players ?? []);
  const [open, setOpen] = useState(false);
  const [armed, setArmed] = useState<string | null>(null);
  const [d, setD] = useState<Draft>(() => draftFrom(s.settings));
  const [msg, setMsg] = useState<string | null>(null);
  const lobby = s.lobby;
  const joined = lobby?.joined ?? 0;
  const quota = lobby?.quota ?? s.settings?.quota ?? 0;
  const layout = s.settings?.seatLayout;
  const why = !lobby
    ? ""
    : joined < quota
      ? `Menunggu ${quota - joined} siswa lagi`
      : lobby.seatsPending > 0
        ? `${lobby.seatsPending} siswa belum memilih kursi`
        : "";
  const code = s.code ?? "······";
  return (
    <section className="hscreen hlobby" data-testid="host-lobby">
      <div className="hjoin-toasts" role="status" aria-live="polite">
        {toasts.map((t) => (
          <p key={t.id} className="hjoin-toast" data-testid="join-toast">
            <span className="hav" aria-hidden="true">
              {initialsOf(t.name)}
            </span>
            <span>
              <b>{t.name}</b> masuk
            </span>
          </p>
        ))}
      </div>
      <div className="hlobby-grid">
        <div className="hcard hcode-card">
          <p className="hkicker">Kode sesi</p>
          <p className="hcode" data-testid="host-pin" aria-label="Kode sesi">
            {[...code].map((ch, i) => (
              <span className="flap" key={`${i}-${ch}`} style={{ animationDelay: `${i * 70}ms` }}>
                {ch}
              </span>
            ))}
          </p>
          <ol className="hsteps">
            <li>
              Buka <b>{typeof location === "undefined" ? "" : studentAddress(location.host)}</b> di HP
            </li>
            <li>Masukkan kode, pilih namamu</li>
            <li>Ketuk kursimu di denah</li>
          </ol>
          <div className="hcount-row">
            <p className="hcount" data-testid="host-count">
              {joined}/{quota} sudah masuk
            </p>
            <DotRow total={quota} filled={joined} />
          </div>
          {(lobby?.players.length ?? 0) === 0 ? (
            <p className="hempty" data-testid="host-empty">
              Belum ada pemain
            </p>
          ) : (
            <ul className="hjoined" data-testid="joined-list" aria-label="Siswa yang sudah masuk">
              {lobby?.players.map((p) => (
                <li key={p.id} className={p.connected ? "" : "off"}>
                  <span className="hav" aria-hidden="true">
                    {initialsOf(p.name)}
                  </span>
                  <span className="hname">{p.name}</span>
                  <button
                    type="button"
                    className={`hrm${armed === p.id ? " armed" : ""}`}
                    aria-label={armed === p.id ? `Klik lagi untuk menghapus ${p.name}` : `Hapus ${p.name} dari sesi`}
                    title={armed === p.id ? "Klik lagi untuk menghapus" : "Hapus dari sesi"}
                    onClick={() => {
                      if (armed !== p.id) {
                        setArmed(p.id);
                        window.setTimeout(() => setArmed((cur) => (cur === p.id ? null : cur)), 4000);
                      } else {
                        setArmed(null);
                        void host.removePlayer(p.id);
                      }
                    }}
                    data-testid={`remove-${p.id}`}
                  >
                    {armed === p.id ? "Hapus?" : "×"}
                  </button>
                  <svg className="hcheck" viewBox="0 0 20 20" aria-hidden="true">
                    <circle cx="10" cy="10" r="9" fill="none" />
                    <path d="M5.5 10.5 L8.8 13.6 L14.6 7" fill="none" />
                  </svg>
                </li>
              ))}
            </ul>
          )}
        </div>
        {layout?.enabled ? (
          <div className="hcard hseat-card">
            <p className="hkicker">Denah kelas · ketuk kursi untuk mengosongkan</p>
            <SeatMap host={host} layout={layout} s={s} />
          </div>
        ) : null}
      </div>
      <div className="hactions">
        <button type="button" className="btn coin hbtn" disabled={!lobby?.canStart} onClick={() => void host.command("host:start")} data-testid="start-btn">
          Mulai
        </button>
        {why ? (
          <span className="hwhy" data-testid="start-why">
            {why}
          </span>
        ) : null}
        <button type="button" className="btn hbtn ghost" onClick={() => setOpen((v) => !v)} aria-expanded={open} data-testid="settings-toggle">
          Pengaturan
        </button>
      </div>
      {open ? (
        <div className="hcard hpanel">
          <SettingsForm d={d} set={setD} lobby />
          {msg ? (
            <p className="error" role="alert" data-testid="settings-error">
              {msg}
            </p>
          ) : null}
          <button
            type="button"
            className="btn primary hbtn"
            onClick={async () => {
              const err = await host.updateSettings(toPatch(d));
              setMsg(err);
            }}
            data-testid="settings-apply"
          >
            Terapkan
          </button>
        </div>
      ) : null}
    </section>
  );
}

// ---------------------------------------------------------------- fase permainan

function Big({ children, testid }: { children: React.ReactNode; testid?: string }) {
  return (
    <p className="hbig" data-testid={testid}>
      {children}
    </p>
  );
}

/** Hitung mundur besar dalam cincin yang menyusut; angkanya tetap teks biasa untuk uji dan pembaca layar. */
function Countdown({ s, size = 280 }: { s: HostState; size?: number }) {
  const now = useNow(100);
  if (s.phaseEndsAt === null) return null;
  const msLeft = Math.max(0, s.phaseEndsAt - now);
  const total = s.phase?.durationMs ?? 0;
  const left = Math.ceil(msLeft / 1000);
  return (
    <Ring value={total > 0 ? msLeft / total : 0} size={size} stroke={Math.round(size / 13)} tone={left <= 5 && total > 6000 ? "school" : "coin"}>
      <p className="hclock" data-testid="host-clock" aria-live="off">
        {left}
      </p>
    </Ring>
  );
}

function Round({ s }: { s: HostState }) {
  const p = s.phase;
  if (!p) return null;
  const label = p.roundId === 0 ? "Latihan · tidak dihitung" : `Ronde ${p.displayIndex ?? "?"} dari ${p.totalRounds}`;
  const hidden = p.condition === "HIDDEN";
  const kind = hidden ? "Angka akan hilang" : "Angka tampil";
  const title = p.phase === "LOOK" ? "Lihat baik-baik di perangkatmu!" : p.phase === "WALK" ? "Antar paketnya!" : "Soal ingatan";
  return (
    <section className="hscreen hround" data-testid="host-round" data-phase={p.phase}>
      <Countdown s={s} />
      <div className="hround-text">
        <p className="hkicker" data-testid="host-round-label">
          {label} · {kind}
        </p>
        <h1 className="htitle">{title}</h1>
        <p className={`hkind${hidden ? " hidden" : ""}`} aria-hidden="true">
          <b>{hidden ? "?" : "●"}</b>
          <span>{hidden ? "angka hilang setelah menghafal" : "angka terlihat di peta"}</span>
        </p>
        {p.phase === "WALK" || p.phase === "PROBE" ? (
          <>
            <Big testid="host-walk">{s.walk ? `${s.walk.finished}/${s.walk.total} sudah sampai` : ""}</Big>
            {s.walk ? <DotRow total={s.walk.total} filled={s.walk.finished} /> : null}
          </>
        ) : null}
      </div>
    </section>
  );
}

function Summary({ s }: { s: HostState }) {
  const sm = s.summary;
  return (
    <section className="hscreen hresult" data-testid="host-result">
      <div className="hresult-head">
        <h1 className="htitle">Rute paling hemat</h1>
        <Big testid="host-pct">
          {sm ? (
            <>
              <b>{sm.pctOptimal}%</b> kelas menemukan rute terhemat
            </>
          ) : (
            ""
          )}
        </Big>
      </div>
      <div className="hminis">
        {(sm?.items ?? []).map((it) => (
          <figure key={it.slot} className="hcard hmini" data-testid={`summary-${it.slot}`} style={{ animationDelay: `${it.slot * 120}ms` }}>
            <figcaption>
              <span className="hmini-tag">Soal {it.slot + 1}</span>
              <span className="hmini-size">{it.nodes} tempat</span>
            </figcaption>
            <MapView map={it.map} path={it.optimalPath} showWeights disabled />
            <dl className="hstats">
              <div data-testid={`summary-route-${it.slot}`}>
                <dt>Rute terbaik</dt>
                <dd>
                  <b>{it.steps}</b> langkah · <b>{it.optimalCost}</b> koin
                </dd>
              </div>
              <div data-testid={`summary-solvers-${it.slot}`}>
                <dt>Menemukan</dt>
                <dd>
                  <b>{it.solvers}</b>/{it.tried} siswa
                  <span className="hmeter" aria-hidden="true">
                    <i style={{ transform: `scaleX(${it.tried ? it.solvers / it.tried : 0})` }} />
                  </span>
                </dd>
              </div>
              <div data-testid={`summary-fastest-${it.slot}`}>
                <dt>Tercepat</dt>
                <dd>{it.fastestMs === null ? "belum ada" : <b>{(it.fastestMs / 1000).toFixed(1).replace(".", ",")} dtk</b>}</dd>
              </div>
            </dl>
          </figure>
        ))}
      </div>
    </section>
  );
}

function Board({ s }: { s: HostState }) {
  const rows = s.top5 ?? [];
  const max = Math.max(1, ...rows.map((r) => r.points));
  return (
    <section className="hscreen hboardscreen" data-testid="host-board">
      <h1 className="htitle">5 besar</h1>
      <ol className="hlist">
        {rows.map((r, i) => (
          <li key={`${r.nickname}-${i}`} data-testid={`board-${i}`} style={{ animationDelay: `${i * 90}ms` }}>
            <span className="hrank">{i + 1}</span>
            <strong>{r.nickname}</strong>
            <span className="hbar" aria-hidden="true">
              <i style={{ transform: `scaleX(${r.points / max})` }} />
            </span>
            <em>{r.points.toLocaleString("id-ID")} poin</em>
          </li>
        ))}
      </ol>
    </section>
  );
}

/** Mengambil berkas hasil dengan token guru lalu mengunduh atau membukanya; gagal = pesan di layar guru. */
async function openExport(host: HostClient, file: string, download: boolean): Promise<void> {
  try {
    const res = await host.fetchExport(file);
    if (!res.ok) throw new Error(String(res.status));
    const url = URL.createObjectURL(await res.blob());
    if (download) {
      const a = document.createElement("a");
      a.href = url;
      a.download = `route-rush-${file}`;
      a.click();
    } else window.open(url, "_blank", "noopener");
    window.setTimeout(() => URL.revokeObjectURL(url), 60_000);
  } catch {
    window.alert("Berkas belum dapat diambil. Coba lagi.");
  }
}

const FILES: [string, string, string, boolean][] = [
  ["rounds.csv", "rounds", "CSV", true],
  ["students.csv", "students", "CSV", true],
  ["tutorial.csv", "tutorial", "CSV", true],
  ["items.csv", "items", "CSV", true],
  ["report.html", "Laporan", "A4", false],
];

function Podium({ host, s }: { host: HostClient; s: HostState }) {
  return (
    <section className="hscreen hpodiumscreen" data-testid="host-podium">
      <h1 className="htitle">Juara Route Rush</h1>
      <ol className="hpodium">
        {(s.podium ?? []).map((r, i) => (
          <li key={`${r.nickname}-${i}`} className={`place p${i + 1}`} data-testid={`podium-${i}`} style={{ animationDelay: `${(2 - i) * 160}ms` }}>
            <strong>{r.nickname}</strong>
            <em>{r.points.toLocaleString("id-ID")} poin</em>
            <span className="hpillar">{i + 1}</span>
          </li>
        ))}
      </ol>
      <p className="hsub">{COPY.podiumCheer}</p>
      <nav className="hdownloads" aria-label="Unduh hasil" data-testid="downloads">
        {FILES.map(([file, name, tag, dl]) => (
          <a
            key={file}
            className="hdl"
            href={withBase(`api/sessions/${s.sessionId}/${file}${s.settings?.kind === "TEST" ? "?includeTest=1" : ""}`)}
            {...(dl ? { download: "" } : { target: "_blank", rel: "noreferrer" })}
            onClick={(e) => {
              // sesi masih berjalan: server meminta token guru di header, yang tidak bisa dibawa tautan biasa
              e.preventDefault();
              void openExport(host, file, dl);
            }}
            data-testid={`dl-${file}`}
          >
            <small>{tag}</small>
            <span>{dl ? `Unduh ${file}` : "Buka Laporan"}</span>
            <span className="hdl-name" aria-hidden="true">
              {name}
            </span>
          </a>
        ))}
      </nav>
      {s.backUrl ? (
        <a className="btn coin hbtn hback" href={buildReturnUrl(s.backUrl, s.sessionId)} data-testid="back-to-simpeteri">
          Kembali ke SIMPETERI
        </a>
      ) : null}
      {s.rejected > 0 ? (
        <p className="hsmallnote" data-testid="rejected-podium">
          {s.rejected} hasil tidak lolos pemeriksaan data dan tidak ikut diekspor.
        </p>
      ) : null}
    </section>
  );
}

/** Hitung mundur singkat sebelum guru dikembalikan ke SIMPETERI; bisa dibatalkan atau dipercepat. */
function ReturnCountdown({ url, onCancel }: { url: string; onCancel: () => void }) {
  const [left, setLeft] = useState(5);
  useEffect(() => {
    if (left <= 0) {
      window.location.assign(url);
      return;
    }
    const id = window.setTimeout(() => setLeft((n) => n - 1), 1000);
    return () => window.clearTimeout(id);
  }, [left, url]);
  return (
    <div className="hconfirm hreturn" role="status" data-testid="return-countdown">
      <p>
        Sesi selesai. Kembali ke SIMPETERI dalam <b>{Math.max(0, left)}</b> detik
      </p>
      <button type="button" className="btn hsmall" onClick={onCancel} data-testid="return-cancel">
        Batal
      </button>
      <button type="button" className="btn primary hsmall" onClick={() => window.location.assign(url)} data-testid="return-now">
        Kembali sekarang
      </button>
    </div>
  );
}

function Controls({ host, s, onReport }: { host: HostClient; s: HostState; onReport: () => void }) {
  const [ask, setAsk] = useState<null | "skip" | "end">(null);
  const [leave, setLeave] = useState<string | null>(null);
  const [sound, setSound] = useState(!introAudio.muted);
  const [voice, setVoice] = useState<string>("…");
  useEffect(() => {
    void narrationStatus().then((v) => setVoice(v === "dimatikan" ? "dimatikan (hanya subtitle)" : v === "ok" ? "suara peramban" : v === "tanpa-suara-indonesia" ? "tidak ada suara Indonesia di peramban ini (hanya subtitle)" : "tidak didukung (hanya subtitle)"));
  }, []);
  const phase = s.phase?.phase;
  const canSkip = phase !== undefined && phase !== "LOBBY" && phase !== "PODIUM" && phase !== "ENDED";
  return (
    <aside className="hcontrols" data-testid="host-controls">
      {leave ? <ReturnCountdown url={leave} onCancel={() => setLeave(null)} /> : null}
      {phase === "INTRO_IDENT" || phase === "INTRO_TRAILER" ? (
        <HoldButton label="Lewati intro" onDone={() => void host.command("host:skipIntro")} testid="skip-intro" />
      ) : canSkip ? (
        <button type="button" className="btn hsmall" onClick={() => setAsk("skip")} data-testid="skip-btn">
          Lewati
        </button>
      ) : null}
      <button type="button" className="btn hsmall" onClick={onReport} data-testid="report-btn">
        Laporan
      </button>
      <button
        type="button"
        className="btn hsmall"
        onClick={() => {
          introAudio.setMuted(sound);
          setSound(!sound);
        }}
        aria-pressed={!sound}
        data-testid="sound-toggle"
      >
        Suara: {sound ? "nyala" : "mati"}
      </button>
      {phase !== "ENDED" ? (
        <button type="button" className="btn hsmall danger" onClick={() => setAsk("end")} data-testid="end-btn">
          Akhiri
        </button>
      ) : null}
      <span className="hsmallnote" data-testid="narration-status" title="Suara narasi peramban dimatikan; teks tetap tampil sebagai subtitle">
        Narasi: {voice}
      </span>
      <span className="hsmallnote" data-testid="rejected-count" title="Hasil yang tidak lolos pemeriksaan integritas data">
        Hasil ditolak: {s.rejected}
      </span>
      {ask ? (
        <div className="hconfirm" role="alertdialog" aria-modal="true" data-testid="confirm">
          <p>{ask === "skip" ? "Lewati bagian ini?" : "Akhiri sesi sekarang?"}</p>
          <button
            type="button"
            className="btn primary hsmall"
            onClick={() => {
              const ending = ask === "end";
              const back = s.backUrl ? buildReturnUrl(s.backUrl, s.sessionId) : null;
              void host.command(ask === "skip" ? "host:skip" : "host:end").then((r) => {
                // sesi dari SIMPETERI: setelah berakhir, guru dikembalikan ke halaman SIMPETERI pengirim
                if (ending && r.ok && back) setLeave(back);
              });
              setAsk(null);
            }}
            data-testid="confirm-yes"
          >
            Ya
          </button>
          <button type="button" className="btn hsmall" onClick={() => setAsk(null)} data-testid="confirm-no">
            Batal
          </button>
        </div>
      ) : null}
    </aside>
  );
}

export function HostApp({ host }: { host: HostClient }) {
  const s = useStore(host);
  const [report, setReport] = useState(false);
  const phase = s.phase?.phase;
  // hasil ronde: bunyi benar/salah + nama siswa tercepat yang benar; berhenti begitu ronde berikutnya mulai
  const summary = s.summary;
  // sekali per ronde: ringkasan bisa tiba lagi (sambung ulang, pembaruan state) dan tidak boleh memutar bunyi dari awal
  const announced = useRef<number | null>(null);
  const roundId = s.phase?.roundId ?? null;
  useEffect(() => {
    if (phase === "LOOK") announced.current = null;
    if (phase === "RESULT" && summary && announced.current !== roundId) {
      announced.current = roundId;
      void answerAudio.announce(summary.correct, summary.wrong);
    }
  }, [phase, summary, roundId]);
  useEffect(() => {
    if (phase !== "RESULT" && phase !== "LEADERBOARD") answerAudio.stop();
  }, [phase]);
  // kalimat tutorial diputar sekali di proyektor saat tutorial dimulai (12A.7)
  useEffect(() => {
    if (phase === "TUTORIAL") void voAudio.sayAll(COPY.tutorial.map((text, i) => ({ id: `tutorial-${i + 1}`, text })));
    else if (phase !== "RESULT" && phase !== "LEADERBOARD") voAudio.stop();
  }, [phase]);
  const inIntro = s.created && (phase === undefined || phase === "INTRO_IDENT" || phase === "INTRO_TRAILER");
  let body;
  if (!s.created) body = <CreateScreen host={host} s={s} />;
  else
    switch (phase) {
      case undefined:
      case "INTRO_IDENT":
      case "INTRO_TRAILER":
        body = <IntroStage s={s} />;
        break;
      case "LOBBY":
        body = <Lobby host={host} s={s} />;
        break;
      case "COUNTDOWN":
        body = (
          <section className="hscreen hround" data-testid="host-countdown">
            <Countdown s={s} size={360} />
            <div className="hround-text">
              <p className="hkicker">Mulai sebentar lagi</p>
              <h1 className="htitle">Bersiap…</h1>
            </div>
          </section>
        );
        break;
      case "TUTORIAL":
        body = (
          <section className="hscreen htutorial" data-testid="host-tutorial">
            <div className="htutorial-top">
              <h1 className="htitle">Latihan singkat di perangkatmu</h1>
              <div className="htutorial-meta">
                <Countdown s={s} size={150} />
                <div>
                  <Big testid="host-ready">{s.tutorial ? `${s.tutorial.ready}/${s.tutorial.total} siap` : ""}</Big>
                  {s.tutorial ? <DotRow total={s.tutorial.total} filled={s.tutorial.ready} /> : null}
                </div>
              </div>
            </div>
            <RulesTicker />
          </section>
        );
        break;
      case "LOOK":
      case "WALK":
      case "PROBE":
        body = <Round s={s} />;
        break;
      case "RESULT":
        body = <Summary s={s} />;
        break;
      case "LEADERBOARD":
        body = <Board s={s} />;
        break;
      case "PODIUM":
        body = <Podium host={host} s={s} />;
        break;
      case "ENDED":
        body = (
          <section className="hscreen hcenter" data-testid="host-ended">
            <h1 className="htitle">Sesi selesai</h1>
            <p className="hsub">Terima kasih. Hasil sesi tetap bisa diunduh dari tautan yang sudah dibuka.</p>
            <button type="button" className="btn primary hbtn" onClick={() => host.reset()} data-testid="new-session">
              Sesi baru
            </button>
          </section>
        );
        break;
    }
  return (
    <div className="host" data-phase={phase ?? ""} data-intro={inIntro ? "1" : undefined} data-testid="host-app">
      {!s.online ? (
        <div className="offline" role="status" data-testid="offline">
          {COPY.offline}
        </div>
      ) : null}
      {inIntro ? null : <AppBar s={s} />}
      {body}
      {s.created ? <Controls host={host} s={s} onReport={() => setReport(true)} /> : null}
      {report && s.created ? <ReportScreen host={host} s={s} onClose={() => setReport(false)} /> : null}
    </div>
  );
}

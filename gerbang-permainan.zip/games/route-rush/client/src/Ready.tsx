import { useEffect, useRef, useState } from "react";
import { COPY, mulberry32, type IntroMode } from "@route-rush/shared";

/** Hash sederhana nama/ID siswa → seed ritme glitch (deterministik, memakai PRNG ber-seed). */
export function seedOf(text: string): number {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return h >>> 0;
}

/** Jeda antar-glitch 2,4–3,6 detik, seeded. */
export function burstSchedule(seed: number, n: number): number[] {
  const rnd = mulberry32(seed);
  const out: number[] = [];
  let t = 1200;
  for (let i = 0; i < n; i++) {
    out.push(t);
    t += 2400 + rnd() * 1200;
  }
  return out;
}

const prefersReduced = (): boolean => typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;

/** Motif peta A-05 (koordinat dari shared/maps/formA.json, diskalakan ke 300×180). */
function MapMotif() {
  return (
    <svg className="ready-map" viewBox="0 0 300 180" aria-hidden="true">
      <g>
        <line className="road" x1="20" y1="92" x2="92" y2="34" />
        <line className="road" x1="20" y1="92" x2="120" y2="100" />
        <line className="road" x1="92" y1="34" x2="120" y2="100" />
        <line className="road" x1="92" y1="34" x2="207" y2="58" />
        <line className="road" x1="120" y1="100" x2="207" y2="58" />
        <line className="road" x1="120" y1="100" x2="193" y2="160" />
        <line className="road" x1="207" y1="58" x2="280" y2="100" />
        <line className="road" x1="193" y1="160" x2="280" y2="100" />
      </g>
      <path className="lit" d="M20 92 L92 34 L120 100 L207 58 L280 100" />
      <circle className="rnode home" cx="20" cy="92" r="9" />
      <circle className="rnode" cx="92" cy="34" r="7" />
      <circle className="rnode" cx="120" cy="100" r="7" />
      <circle className="rnode" cx="207" cy="58" r="7" />
      <circle className="rnode" cx="193" cy="160" r="7" />
      <circle className="rnode school" cx="280" cy="100" r="9" />
      <circle className="rcoin" cx="56" cy="63" r="3" />
      <circle className="rcoin" cx="162" cy="79" r="3" />
      <circle className="rcoin" cx="242" cy="79" r="3" />
    </svg>
  );
}

interface ReadyProps {
  nickname: string;
  /** Sisa hitung mundur (ms) bila fase COUNTDOWN; null = masih menunggu guru. */
  countdownEndsAt: number | null;
  introMode: IntroMode;
  /** Tampilkan "GO!" saja (lapisan di atas layar berikutnya). */
  go?: boolean;
  /** Seed ritme glitch, mis. hash(studentId). */
  seed: number;
}

/** Layar READY glitch (12A.9) untuk siswa yang menunggu di LOBBY lalu hitung mundur 3-2-1-GO. */
export function ReadyScreen({ nickname, countdownEndsAt, introMode, go = false, seed }: ReadyProps) {
  const [word, setWord] = useState<string>(go ? COPY.readyGo : COPY.readyWord);
  const [burst, setBurst] = useState(false);
  const [fill, setFill] = useState(0);
  const lastWord = useRef(word);
  const bursts = useRef(burstSchedule(seed, 400));
  const startedAt = useRef(performance.now());
  const countdownTotal = useRef<number | null>(null);
  const reduce = prefersReduced();

  const flash = (): void => {
    if (reduce) return;
    setBurst(true);
    window.setTimeout(() => setBurst(false), 330);
  };

  useEffect(() => {
    if (go) {
      setWord(COPY.readyGo);
      flash();
      return;
    }
    let nextBurst = 0;
    const tick = (): void => {
      const now = performance.now();
      const elapsed = now - startedAt.current;
      if (countdownEndsAt !== null) {
        if (countdownTotal.current === null) countdownTotal.current = Math.max(1, countdownEndsAt - now);
        const remain = Math.max(0, countdownEndsAt - now);
        setFill(100 * Math.min(1, 1 - remain / countdownTotal.current));
        const n = Math.min(3, Math.max(1, Math.ceil(remain / 1000)));
        const next = String(n);
        if (next !== lastWord.current) {
          lastWord.current = next;
          setWord(next);
          flash();
        }
      } else {
        // menunggu guru: bilah berdenyut pelan, glitch tipis berkala
        setFill((elapsed / 40) % 100);
        if (nextBurst < bursts.current.length && elapsed >= (bursts.current[nextBurst] as number)) {
          nextBurst++;
          flash();
        }
        if (lastWord.current !== COPY.readyWord) {
          lastWord.current = COPY.readyWord;
          setWord(COPY.readyWord);
        }
      }
    };
    tick();
    const id = window.setInterval(tick, 50);
    return () => window.clearInterval(id);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [countdownEndsAt, go]);

  const counting = countdownEndsAt !== null;
  const hint = go ? COPY.readyGoHint[introMode] : counting ? COPY.readyCountdownHint : COPY.lookFront;
  const hello = nickname ? COPY.readyHello(nickname.slice(0, 12)) : COPY.readyNoName;

  return (
    <main className={`ready${go ? " ready-go" : ""}`} aria-live="polite" data-testid="ready-screen" data-counting={counting ? "1" : "0"}>
      <div className="ready-stack">
        {!go && !counting ? (
          <svg className="login-ok" viewBox="0 0 64 64" aria-hidden="true" data-testid="login-ok">
            <circle cx="32" cy="32" r="28" />
            <path d="M19 33 L28 42 L45 23" />
          </svg>
        ) : null}
        <MapMotif />
        <h1 className={`ready-word ${burst ? "burst" : "idle"}`} data-text={word} data-testid="ready-word">
          {word}
        </h1>
        <p className="ready-hello" data-testid="ready-hello">
          {hello}
        </p>
        {!go && !counting ? <p className="ready-wait">{COPY.lobbyWait}</p> : null}
        <p className="ready-hint">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">
            <rect x="3" y="6" width="18" height="11" rx="2" />
            <circle cx="15" cy="11.5" r="2.4" />
            <path d="M7 21l2-4M17 21l-2-4" />
          </svg>
          <span data-testid="ready-hint">{hint}</span>
        </p>
        <div className="ready-bar" aria-hidden="true">
          <i style={{ width: `${fill.toFixed(1)}%` }} />
        </div>
      </div>
    </main>
  );
}

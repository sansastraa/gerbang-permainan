import { describe, expect, it } from "vitest";
import { ROSTER_MESSAGE, buildReturnUrl, parseImportMessage, safeReturnUrl } from "./importRoster";

const ok = { type: ROSTER_MESSAGE, kelas: "6C", roster: [{ id: "a1", name: "  Adnan   Fahreza ", kelas: "6C", absen: 1 }, { id: "a2", name: "Adnan Sharif", absen: 2 }, { id: "a3", name: "Budi" }] };

describe("impor daftar siswa dari SIMPETERI", () => {
  it("menerima pesan sah, merapikan nama, dan mempertahankan nomor absen", () => {
    const r = parseImportMessage(ok)!;
    expect(r.kelas).toBe("6C");
    expect(r.roster).toEqual([{ id: "a1", name: "Adnan Fahreza", kelas: "6C", absen: 1 }, { id: "a2", name: "Adnan Sharif", absen: 2 }, { id: "a3", name: "Budi" }]);
  });
  it("menolak pesan asing, rusak, kosong, kebanyakan, id ganda, absen tidak sah", () => {
    expect(parseImportMessage(null)).toBeNull();
    expect(parseImportMessage("x")).toBeNull();
    expect(parseImportMessage({ type: "lain", roster: [] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: Array.from({ length: 81 }, (_, i) => ({ id: `s${i}`, name: "N" })) })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "A" }, { id: "x", name: "B" }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "A", absen: 0 }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "A", absen: 1.5 }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "x", name: "" }] })).toBeNull();
    expect(parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: 5, name: "A" }] })).toBeNull();
  });
  it("memotong nama dan id yang terlalu panjang", () => {
    const r = parseImportMessage({ type: ROSTER_MESSAGE, roster: [{ id: "i".repeat(100), name: "n".repeat(100) }] })!;
    expect(r.roster[0]?.id).toHaveLength(64);
    expect(r.roster[0]?.name).toHaveLength(60);
  });
  it("PIN, alamat kembali, dan id Multi Permainan ikut bila sah", () => {
    const origin = "https://simpeteri.example.id";
    const r = parseImportMessage({ ...ok, pin: "guru-1234", kembali: `${origin}/multi-permainan?x=1`, multiSesi: "3f2a-91bc" }, origin)!;
    expect(r.pin).toBe("guru-1234");
    expect(r.kembali).toBe(`${origin}/multi-permainan?x=1`);
    expect(r.multiSesi).toBe("3f2a-91bc");
  });
  it("bidang tautan yang ada tetapi tidak sah menolak seluruh pesan; yang tidak dikirim tidak masalah", () => {
    expect(parseImportMessage({ ...ok, pin: "abc" })).toBeNull();
    expect(parseImportMessage({ ...ok, pin: "guru-1234", multiSesi: "a b/c" })).toBeNull();
    expect(parseImportMessage({ ...ok, pin: 12345678 })).toBeNull();
    const plain = parseImportMessage(ok)!;
    expect(plain.pin).toBeUndefined();
    expect(plain.kembali).toBeUndefined();
    expect(plain.multiSesi).toBeUndefined();
  });
  it("alamat kembali ke asal lain, bukan http(s), atau berkredensial ditolak", () => {
    const origin = "https://simpeteri.example.id";
    expect(safeReturnUrl("https://jahat.example/x", origin)).toBeUndefined();
    expect(safeReturnUrl("javascript:alert(1)", origin)).toBeUndefined();
    expect(safeReturnUrl("https://u:p@simpeteri.example.id/x", origin)).toBeUndefined();
    expect(safeReturnUrl("/relatif", origin)).toBeUndefined();
    expect(safeReturnUrl(`${origin}/${"a".repeat(2100)}`, origin)).toBeUndefined();
    expect(parseImportMessage({ ...ok, kembali: "https://jahat.example/x" }, origin)).toBeNull();
  });
  it("buildReturnUrl menambah selesai=1 dan gameSesi tanpa merusak query yang ada", () => {
    const u = new URL(buildReturnUrl("https://simpeteri.example.id/multi-permainan?sesi=9", "rr-ab12cd34"));
    expect(u.searchParams.get("sesi")).toBe("9");
    expect(u.searchParams.get("selesai")).toBe("1");
    expect(u.searchParams.get("gameSesi")).toBe("rr-ab12cd34");
  });
});
import { announcementPlan, parseNameList, type AnnounceStep, type CorrectInput } from "@route-rush/shared";
import namesRaw from "../../../assets/audio/names/names.txt?raw";
import correctUrl from "../../../assets/audio/answers/correct.wav?url";
import wrongUrl from "../../../assets/audio/answers/wrong.wav?url";
import identFull from "../../../assets/audio/mix/IDENT_FULL.wav?url";
import identShort from "../../../assets/audio/mix/IDENT_SHORT.wav?url";
import trailerFull from "../../../assets/audio/mix/TRAILER_FULL.wav?url";
import trailerShort from "../../../assets/audio/mix/TRAILER_SHORT.wav?url";

export type MixKey = "IDENT_FULL" | "IDENT_SHORT" | "TRAILER_FULL" | "TRAILER_SHORT";

const URLS: Record<MixKey, string> = { IDENT_FULL: identFull, IDENT_SHORT: identShort, TRAILER_FULL: trailerFull, TRAILER_SHORT: trailerShort };

const automated = (): boolean => {
  try {
    return navigator.webdriver === true || new URLSearchParams(location.search).has("mute");
  } catch {
    return true;
  }
};

/**
 * Pemutar suara intro di proyektor. Campuran (musik + efek + penurunan 8 dB saat narasi) sudah dirender dan diseimbangkan
 * ke −16 LUFS oleh `scripts/gen-audio.ts`, jadi runtime hanya memutar berkas pada posisi waktu fase yang benar.
 * Perangkat siswa tidak pernah memakai ini (senyap).
 */
export class IntroAudio {
  private ctx: AudioContext | null = null;
  private buffers: Partial<Record<MixKey, AudioBuffer>> = {};
  private source: AudioBufferSourceNode | null = null;
  muted = automated();
  /** Jumlah pemutaran yang benar-benar dimulai (untuk uji). */
  started: { key: MixKey; offsetMs: number }[] = [];

  /** Dipanggil dari gestur pengguna (klik Buat sesi) agar peramban mengizinkan suara. */
  unlock(): void {
    try {
      this.ctx ??= new AudioContext();
      void this.ctx.resume();
    } catch {
      /* peramban tanpa WebAudio: intro tetap berjalan dengan subtitle */
    }
  }

  async load(onProgress: (f: number) => void): Promise<void> {
    try {
      this.ctx ??= new AudioContext();
    } catch {
      onProgress(1);
      return;
    }
    const ctx = this.ctx;
    const keys = Object.keys(URLS) as MixKey[];
    let done = 0;
    for (const k of keys) {
      try {
        const res = await fetch(URLS[k]);
        this.buffers[k] = await ctx.decodeAudioData(await res.arrayBuffer());
      } catch {
        /* berkas gagal dimuat: fase itu senyap */
      }
      onProgress(++done / keys.length);
    }
  }

  /** Konteks audio bersama (dipakai pengumuman jawaban). */
  get context(): AudioContext | null {
    return this.ctx;
  }

  get ready(): boolean {
    return Object.keys(this.buffers).length === 4;
  }

  /** Memutar campuran `key` mulai dari `offsetMs` (posisi waktu fase menurut server). */
  play(key: MixKey, offsetMs: number): void {
    this.stop();
    const buf = this.buffers[key];
    if (this.muted || !this.ctx || !buf) return;
    const offset = Math.max(0, offsetMs) / 1000;
    if (offset >= buf.duration) return;
    const src = this.ctx.createBufferSource();
    src.buffer = buf;
    src.connect(this.ctx.destination);
    src.start(0, offset);
    this.source = src;
    this.started.push({ key, offsetMs });
  }

  stop(): void {
    try {
      this.source?.stop();
    } catch {
      /* sudah berhenti */
    }
    this.source = null;
  }

  setMuted(m: boolean): void {
    this.muted = m;
    if (m) {
      this.stop();
      cancelNarration();
    }
  }
}

export const introAudio = new IntroAudio();

// ---------------------------------------------------------------- narasi (cadangan Web Speech API)

export function cancelNarration(): void {
  try {
    if (typeof speechSynthesis !== "undefined") speechSynthesis.cancel();
  } catch {
    /* abaikan */
  }
}

/** Memilih suara Indonesia terbaik: id-ID dulu, lalu id lain; di antaranya yang "Natural"/neural lebih disukai, lalu suara lokal. */
export function pickIndonesianVoice<V extends { name: string; lang: string; localService?: boolean }>(voices: readonly V[]): V | null {
  const id = voices.filter((v) => /^id([-_]|$)/i.test(v.lang));
  if (id.length === 0) return null;
  const score = (v: V): number => (/^id[-_]ID$/i.test(v.lang) ? 4 : 0) + (/natural|neural/i.test(v.name) ? 2 : 0) + (v.localService ? 1 : 0);
  return [...id].sort((a, b) => score(b) - score(a))[0] as V;
}

let voicesReady: Promise<SpeechSynthesisVoice[]> | null = null;
/** Daftar suara baru terisi setelah `voiceschanged` pada sebagian peramban; tunggu paling lama 1,5 detik. */
function loadVoices(): Promise<SpeechSynthesisVoice[]> {
  voicesReady ??= new Promise((resolve) => {
    const now = speechSynthesis.getVoices();
    if (now.length > 0) return resolve(now);
    const done = (): void => resolve(speechSynthesis.getVoices());
    speechSynthesis.addEventListener("voiceschanged", done, { once: true });
    window.setTimeout(done, 1500);
  });
  return voicesReady;
}

/** Status narasi untuk ditampilkan ke guru: "ok" | "tanpa-suara-indonesia" | "tidak-didukung". */
/** Narasi suara peramban dimatikan (keputusan pemilik proyek); subtitle tetap tampil. Ubah ke true untuk menyalakannya lagi. */
export const NARRATION_ENABLED = false;

export async function narrationStatus(): Promise<"ok" | "tanpa-suara-indonesia" | "tidak-didukung" | "dimatikan"> {
  if (!NARRATION_ENABLED) return "dimatikan";
  try {
    if (typeof speechSynthesis === "undefined") return "tidak-didukung";
    return pickIndonesianVoice(await loadVoices()) ? "ok" : "tanpa-suara-indonesia";
  } catch {
    return "tidak-didukung";
  }
}

/**
 * Narasi dengan suara peramban (Web Speech API) — keputusan pemilik proyek: tidak memakai rekaman VO. Hanya suara Indonesia yang
 * dipakai; bila peramban tidak punya, narasi dilewati (subtitle tetap tampil) daripada dibacakan dengan logat asing.
 * Kalimat yang dikirim hanyalah teks tetap permainan (tanpa data siswa).
 */
export function speak(texts: string | readonly string[], opts: { queue?: boolean } = {}): void {
  void (async () => {
    try {
      if (!NARRATION_ENABLED || introAudio.muted || typeof speechSynthesis === "undefined") return;
      const voice = pickIndonesianVoice(await loadVoices());
      if (!voice) return;
      if (!opts.queue) speechSynthesis.cancel();
      for (const t of Array.isArray(texts) ? texts : [texts]) {
        const u = new SpeechSynthesisUtterance(t as string);
        u.voice = voice;
        u.lang = voice.lang;
        u.rate = 0.95;
        speechSynthesis.speak(u);
      }
    } catch {
      /* tanpa suara: subtitle tetap ada */
    }
  })();
}
// ---------------------------------------------------------------- pengumuman jawaban benar/salah + nama siswa

const NAME_URLS = import.meta.glob("../../../assets/audio/names/*.wav", { query: "?url", import: "default", eager: true }) as Record<string, string>;
const nameUrl = (clip: number): string | undefined => {
  const nn = String(clip + 1).padStart(2, "0");
  return Object.entries(NAME_URLS).find(([k]) => k.endsWith(`/${nn}.wav`))?.[1];
};

/**
 * Suara hasil ronde di proyektor: bunyi "benar" lalu "<nama> menjawab dengan benar" untuk siswa tercepat yang menemukan rute
 * terhemat (klip hasil pemotongan suara daftar nama), atau bunyi "salah" bila tidak ada yang benar. Hanya suara — nama tidak
 * ditampilkan di layar (12.4). Perangkat siswa tetap senyap.
 */
export class AnswerAudio {
  /** Nama pada klip 01, 02, … (dari assets/audio/names/names.txt). */
  names: string[] = parseNameList(namesRaw);
  private buffers = new Map<string, AudioBuffer>();
  private token = 0;
  private current: AudioBufferSourceNode | null = null;
  /** Langkah yang benar-benar diputar (untuk uji). */
  played: AnnounceStep[] = [];

  setNames(list: string[]): void {
    this.names = list;
  }

  /** Jumlah klip suara nama yang tersedia (klip NN untuk absen NN). */
  clipCount(): number {
    return Object.keys(NAME_URLS).length;
  }

  private async buffer(url: string): Promise<AudioBuffer | null> {
    const ctx = introAudio.context;
    if (!ctx) return null;
    const cached = this.buffers.get(url);
    if (cached) return cached;
    try {
      const res = await fetch(url);
      const buf = await ctx.decodeAudioData(await res.arrayBuffer());
      this.buffers.set(url, buf);
      return buf;
    } catch {
      return null;
    }
  }

  /** Memuat bunyi benar/salah lebih dulu agar tidak terlambat saat dibutuhkan. */
  async preload(): Promise<void> {
    await Promise.all([this.buffer(correctUrl), this.buffer(wrongUrl)]);
  }

  stop(): void {
    this.token++;
    try {
      this.current?.stop();
    } catch {
      /* sudah berhenti */
    }
    this.current = null;
  }

  /** Memutar urutan pengumuman satu per satu; berhenti bila `stop()` dipanggil (mis. ronde berikutnya mulai). */
  async announce(correct: readonly CorrectInput[], wrong: number, maxNames = 5): Promise<AnnounceStep[]> {
    this.stop();
    const plan = announcementPlan(correct, wrong, this.names, maxNames, this.clipCount());
    const mine = this.token;
    const ctx = introAudio.context;
    if (introAudio.muted || !ctx || plan.length === 0) return plan;
    for (const step of plan) {
      if (mine !== this.token) break;
      const url = step.kind === "correct" ? correctUrl : step.kind === "wrong" ? wrongUrl : nameUrl(step.clip);
      const buf = url ? await this.buffer(url) : null;
      if (!buf || mine !== this.token) continue;
      await new Promise<void>((done) => {
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.onended = () => done();
        this.current = src;
        this.played.push(step);
        src.start();
      });
    }
    return plan;
  }
}

export const answerAudio = new AnswerAudio();
// ---------------------------------------------------------------- narasi (VO): rekaman bila ada, selain itu Web Speech API

const VO_URLS = import.meta.glob("../../../assets/audio/vo/*.wav", { query: "?url", import: "default", eager: true }) as Record<string, string>;
const voUrl = (id: string): string | undefined => Object.entries(VO_URLS).find(([k]) => k.endsWith(`/${id}.wav`))?.[1];

/**
 * Narasi di proyektor. Memakai rekaman `assets/audio/vo/<id>.wav` (hasil `scripts/build-vo.ts`) bila ada; bila belum direkam,
 * kalimat yang sama dibacakan Web Speech API `id-ID`. Teks selalu tampil juga sebagai subtitle. Musik sudah diturunkan 8 dB
 * pada jendela narasi di dalam campuran intro.
 */
export class VoAudio {
  private buffers = new Map<string, AudioBuffer>();
  private token = 0;
  private current: AudioBufferSourceNode | null = null;
  /** Yang diputar: `file` = rekaman, `speech` = suara peramban (untuk uji). */
  played: { id: string; via: "file" | "speech" }[] = [];

  has(id: string): boolean {
    return voUrl(id) !== undefined;
  }

  private async buffer(id: string): Promise<AudioBuffer | null> {
    const url = voUrl(id);
    const ctx = introAudio.context;
    if (!url || !ctx) return null;
    const hit = this.buffers.get(id);
    if (hit) return hit;
    try {
      const buf = await ctx.decodeAudioData(await (await fetch(url)).arrayBuffer());
      this.buffers.set(id, buf);
      return buf;
    } catch {
      return null;
    }
  }

  stop(): void {
    this.token++;
    try {
      this.current?.stop();
    } catch {
      /* sudah berhenti */
    }
    this.current = null;
    cancelNarration();
  }

  /** Memutar satu kalimat; `queue` = jangan memotong yang sedang berbunyi. */
  async say(id: string, text: string, opts: { queue?: boolean } = {}): Promise<void> {
    if (!opts.queue) this.stop();
    const mine = this.token;
    if (introAudio.muted) return;
    const buf = await this.buffer(id);
    const ctx = introAudio.context;
    if (buf && ctx && mine === this.token) {
      this.played.push({ id, via: "file" });
      await new Promise<void>((done) => {
        const src = ctx.createBufferSource();
        src.buffer = buf;
        src.connect(ctx.destination);
        src.onended = () => done();
        this.current = src;
        src.start();
      });
      return;
    }
    if (mine !== this.token) return;
    this.played.push({ id, via: "speech" });
    speak(text, { queue: opts.queue ?? false });
  }

  /** Beberapa kalimat berurutan (tutorial). */
  async sayAll(lines: { id: string; text: string }[]): Promise<void> {
    this.stop();
    const mine = this.token;
    for (const l of lines) {
      if (mine !== this.token) return;
      await this.say(l.id, l.text, { queue: true });
    }
  }
}

export const voAudio = new VoAudio();
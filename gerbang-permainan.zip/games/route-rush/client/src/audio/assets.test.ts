import { spawn, spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { readFileSync, readdirSync, statSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { SFX_NAMES, introAudioPlan, type SfxName } from "@route-rush/shared";
import { integratedLufs, maxMomentaryLufs, peakDb } from "../../../scripts/audio/lufs";
import { pickIndonesianVoice } from "./engine";
import { groupClips } from "../../../scripts/build-answer-audio";
import { phaseDuration, renderMix, type MixAssets } from "../../../scripts/audio/mix";
import { SR, encodeWav, readWav } from "../../../scripts/audio/wav";
import { introData } from "../intro/data";
import mix from "../../../assets/audio/mix.json";

const audio = resolve(process.cwd(), "../assets/audio");
const KEYS = ["IDENT_FULL", "IDENT_SHORT", "TRAILER_FULL", "TRAILER_SHORT"] as const;
const tl = introData.timeline;
const edges = introData.map.edges.length;

describe("pengukur kenyaringan (BS.1770)", () => {
  const sine = (amp: number, hz = 997, sec = 5): Float32Array => Float32Array.from({ length: sec * SR }, (_, i) => amp * Math.sin((2 * Math.PI * hz * i) / SR));
  it("sinus skala penuh 997 Hz = −3,01 LUFS; separuh amplitudo = −9,03 LUFS", () => {
    expect(integratedLufs(sine(1), SR)).toBeCloseTo(-3.01, 1);
    expect(integratedLufs(sine(0.5), SR)).toBeCloseTo(-9.03, 1);
  });
  it("sunyi dan sinyal terlalu pendek = −Infinity", () => {
    expect(integratedLufs(new Float32Array(SR * 2), SR)).toBe(-Infinity);
    expect(integratedLufs(new Float32Array(100), SR)).toBe(-Infinity);
  });
  it("puncak dan momentary", () => {
    expect(peakDb(sine(0.5))).toBeCloseTo(-6.02, 1);
    expect(maxMomentaryLufs(sine(0.5), SR)).toBeCloseTo(-9.03, 1);
  });
});

describe("I14: tingkat suara aset", () => {
  for (const k of KEYS) {
    it(`campuran ${k} = −16 LUFS ±1, durasi = durasi fase, tanpa clipping`, () => {
      const [kind, mode] = k.split("_") as ["IDENT" | "TRAILER", "FULL" | "SHORT"];
      const { samples, sampleRate } = readWav(resolve(audio, "mix", `${k}.wav`));
      expect(sampleRate).toBe(SR);
      expect(samples.length / SR).toBeCloseTo(phaseDuration(tl, kind, mode) / 1000, 2);
      const lufs = integratedLufs(samples, SR);
      expect(lufs).toBeGreaterThan(-17);
      expect(lufs).toBeLessThan(-15);
      expect(peakDb(samples)).toBeLessThanOrEqual(-0.9); // langit-langit −1 dBFS
    });
  }

  it("tidak ada efek yang melonjak lebih dari 6 dB di atas musik (trailer penuh dan ringkas)", () => {
    const music = readWav(resolve(audio, "music.wav")).samples;
    const sfx = Object.fromEntries(SFX_NAMES.map((n) => [n, readWav(resolve(audio, "sfx", `${n}.wav`)).samples])) as Record<SfxName, Float32Array>;
    const assets: MixAssets = { music, sfx };
    for (const mode of ["FULL", "SHORT"] as const) {
      const plan = introAudioPlan(tl, "TRAILER", mode, edges);
      const cfg = mix[`TRAILER_${mode}`];
      const dur = phaseDuration(tl, "TRAILER", mode);
      const m = integratedLufs(renderMix(plan, assets, cfg, dur, "music"), SR);
      const s = maxMomentaryLufs(renderMix(plan, assets, cfg, dur, "sfx"), SR);
      expect(s - m, `${mode}: efek ${s.toFixed(1)} vs musik ${m.toFixed(1)}`).toBeLessThanOrEqual(6);
    }
  });

  it("musik 45 detik; total aset intro yang dimuat client (campuran + logo) di bawah 5 MB", () => {
    expect(readWav(resolve(audio, "music.wav")).samples.length / SR).toBeCloseTo(45, 2);
    const bytes = readdirSync(resolve(audio, "mix")).reduce((a, f) => a + statSync(resolve(audio, "mix", f)).size, 0) + statSync(resolve(process.cwd(), "../assets/brand/logo.svg")).size;
    expect(bytes).toBeLessThan(5 * 1024 * 1024);
  });
});
describe("gerbang build produksi", () => {
  it("menolak build selama aset sementara dan aset wajib belum lengkap, dengan alasan yang jelas", () => {
    const r = spawnSync(process.execPath, [resolve(process.cwd(), "../scripts/check-production.mjs")], { encoding: "utf8" });
    expect(r.status).toBe(1);
    expect(r.stderr).toContain("Build produksi DITOLAK");
    expect(r.stderr).toContain("aset sementara masih terdaftar");
    // huruf (Product Sans dan Plus Jakarta Sans) sudah ada di client/public/fonts, jadi bukan lagi sumber penolakan
    expect(r.stderr).not.toContain("font lokal tidak ada");
    // nama pembuat sudah final ("MinX Arena"), jadi bukan lagi sumber penolakan
    expect(r.stderr).not.toContain("assets/brand/name.txt masih berisi nilai sementara");
    // aset audio buatan sendiri sudah tercantum di LICENSES.md, jadi bukan sumber penolakan
    expect(r.stderr).not.toContain("LICENSES.md tidak menyebut");
  });
});
describe("suara jawaban (benar, salah, 25 klip nama)", () => {
  const names = resolve(process.cwd(), "../assets/audio/names");
  const answers = resolve(process.cwd(), "../assets/audio/answers");
  it("bunyi benar dan salah ada, −16 LUFS, pendek", () => {
    for (const f of ["correct", "wrong"]) {
      const { samples, sampleRate } = readWav(resolve(answers, `${f}.wav`));
      expect(samples.length / sampleRate).toBeGreaterThan(0.5);
      expect(samples.length / sampleRate).toBeLessThan(3);
      expect(integratedLufs(samples, sampleRate)).toBeCloseTo(-16, 0);
      expect(peakDb(samples)).toBeLessThanOrEqual(-0.9);
    }
  });
  it("tepat 25 klip nama berurutan 01–25, tiap klip 2–5 detik dan −16 LUFS", () => {
    const idx = JSON.parse(readFileSync(resolve(names, "clips.json"), "utf8")) as { count: number; clips: { n: number; file: string }[] };
    expect(idx.count).toBe(25);
    expect(idx.clips.map((c) => c.file)).toEqual(Array.from({ length: 25 }, (_, i) => `${String(i + 1).padStart(2, "0")}.wav`));
    for (const c of idx.clips) {
      const { samples, sampleRate } = readWav(resolve(names, c.file));
      const sec = samples.length / sampleRate;
      expect(sec, c.file).toBeGreaterThan(2);
      expect(sec, c.file).toBeLessThan(5);
      expect(integratedLufs(samples, sampleRate), c.file).toBeCloseTo(-16, 0);
    }
  });
  it("pembagi klip memilih pembagian yang konsisten pada data sintetis (pasangan nama+frasa, satu nama dua kata)", () => {
    // 3 klip: [nama 1,0 s][frasa 1,7 s], [nama 0,6][nama 0,9][frasa 1,7], [nama 1,1][frasa 1,7]; jeda dalam 0,15, jeda antar-klip 0,35
    const lens = [1.0, 1.7, 0.6, 0.9, 1.7, 1.1, 1.7];
    const gaps = [0.15, 0.35, 0.12, 0.15, 0.35, 0.15, 1];
    let t = 0;
    const segs = lens.map((l, i) => {
      const s = { a: t, b: t + l };
      t += l + (gaps[i] as number);
      return s;
    });
    expect(groupClips(segs, 3)).toEqual([[0, 1], [2, 3, 4], [5, 6]]);
  });
});
describe("pemrosesan rekaman narasi (scripts/build-vo.ts)", () => {
  const tone = (sec: number): Float32Array => Float32Array.from({ length: Math.round(24000 * (sec + 1)) }, (_, i) => { const t = i / 24000; return t < 0.5 || t > sec + 0.5 ? 0 : 0.2 * Math.sin(2 * Math.PI * 220 * t) * (1 + 0.5 * Math.sin(2 * Math.PI * 3 * t)); });
  /** spawn asinkron: spawnSync akan memblokir pekerja vitest sampai RPC-nya kedaluwarsa. */
  const run = (dir: string, ...extra: string[]) =>
    new Promise<{ status: number | null; stderr: string }>((done) => {
      const c = spawn(process.execPath, [resolve(process.cwd(), "../node_modules/tsx/dist/cli.mjs"), resolve(process.cwd(), "../scripts/build-vo.ts"), "--dir", dir, ...extra], { cwd: resolve(process.cwd(), "..") });
      let stderr = "";
      c.stderr.on("data", (d: Buffer) => (stderr += d.toString()));
      c.on("close", (status) => done({ status, stderr }));
    });

  it("memangkas hening, menormalkan ke −16 LUFS, menandai yang belum direkam, dan menolak yang melebihi jendela adegan", async () => {
    const dir = mkdtempSync(resolve(tmpdir(), "rr-vo-"));
    mkdirSync(resolve(dir, "source"));
    writeFileSync(resolve(dir, "source/shot-03.wav"), encodeWav(tone(2), 24000)); // jendela 3,7 s: muat
    writeFileSync(resolve(dir, "source/shot-10.wav"), encodeWav(tone(3), 24000)); // jendela 1,7 s: terlalu panjang
    const r = await run(dir);
    expect(r.status).toBe(1);
    expect(r.stderr).toContain("shot-10: ");
    expect(r.stderr).toContain("Belum direkam");
    const out = readWav(resolve(dir, "shot-03.wav"));
    expect(out.samples.length / out.sampleRate).toBeCloseTo(2.1, 0); // keheningan 0,5 detik di tepi terpangkas
    expect(integratedLufs(out.samples, out.sampleRate)).toBeCloseTo(-16, 0);
  }, 120_000);

});

describe("pemilihan suara peramban untuk narasi", () => {
  const v = (name: string, lang: string, localService = false) => ({ name, lang, localService });
  it("memilih suara Indonesia; id-ID dan Natural lebih disukai; tanpa suara Indonesia → null (narasi dilewati)", () => {
    expect(pickIndonesianVoice([v("Microsoft David", "en-US"), v("Microsoft Heami", "ko-KR")])).toBeNull();
    expect(pickIndonesianVoice([])).toBeNull();
    expect(pickIndonesianVoice([v("Google Indonesia", "id-ID"), v("Microsoft Gadis Online (Natural) - Indonesian (Indonesia)", "id-ID")])?.name).toContain("Natural");
    expect(pickIndonesianVoice([v("Lain", "id"), v("Google Indonesia", "id-ID")])?.name).toBe("Google Indonesia");
    expect(pickIndonesianVoice([v("Online", "id-ID", false), v("Lokal", "id-ID", true)])?.name).toBe("Lokal");
  });
});
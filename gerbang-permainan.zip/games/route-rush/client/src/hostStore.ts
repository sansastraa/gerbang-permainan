import { io, type Socket } from "socket.io-client";
import { socketPath, withBase } from "./basePath";
import type { Ack, HostCreateAck, LobbyUpdate, PhasePayload, RosterEntry, RoundSummaryItem, SessionSettings } from "@route-rush/shared";

export interface RoundSummary {
  /** Nama siswa yang menemukan rute terhemat, tercepat dulu; hanya untuk suara pengumuman (tidak ditampilkan). */
  correct: { name: string; absen: number | null }[];
  wrong: number;
  items: RoundSummaryItem[];
  pctOptimal: number;
}

export interface HostState {
  online: boolean;
  /** Sesi sudah dibuat / dipulihkan. */
  created: boolean;
  sessionId: string;
  code: string | null;
  settings: SessionSettings | null;
  phase: PhasePayload | null;
  /** Batas waktu fase pada jam `performance.now()` (null = tanpa batas). */
  phaseEndsAt: number | null;
  lobby: LobbyUpdate | null;
  walk: { finished: number; total: number } | null;
  tutorial: { ready: number; total: number } | null;
  summary: RoundSummary | null;
  top5: { nickname: string; points: number }[] | null;
  podium: { nickname: string; points: number }[] | null;
  rejected: number;
  error: string | null;
  /** Halaman SIMPETERI untuk kembali setelah sesi berakhir (dari impor roster); null bila sesi dibuat manual. */
  backUrl: string | null;
}

export const initialHostState = (): HostState => ({
  online: false,
  created: false,
  sessionId: "",
  code: null,
  settings: null,
  phase: null,
  phaseEndsAt: null,
  lobby: null,
  walk: null,
  tutorial: null,
  summary: null,
  top5: null,
  podium: null,
  rejected: 0,
  error: null,
  backUrl: null,
});

const KEY = "rr.host";
/** hostToken kosong untuk sesi ber-PIN: PIN guru tidak ditulis ke localStorage (hanya sessionStorage tab ini). */
type Saved = { sessionId: string; hostToken?: string };

const PIN_KEY = "rr.host.pin";
const BACK_KEY = "rr.host.back";
const session = {
  get: (k: string): string | null => {
    try {
      return sessionStorage.getItem(k);
    } catch {
      return null;
    }
  },
  set: (k: string, v: string | null): void => {
    try {
      if (v === null) sessionStorage.removeItem(k);
      else sessionStorage.setItem(k, v);
    } catch {
      /* tanpa penyimpanan tab: sesi ber-PIN tidak dapat dipulihkan setelah muat ulang */
    }
  },
};

const readSaved = (): Saved | null => {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? (JSON.parse(raw) as Saved) : null;
  } catch {
    return null;
  }
};
const writeSaved = (v: Saved | null): void => {
  try {
    if (v) localStorage.setItem(KEY, JSON.stringify(v));
    else localStorage.removeItem(KEY);
  } catch {
    /* tanpa penyimpanan: sesi tidak bisa dipulihkan setelah muat ulang */
  }
};

type Listener = () => void;

/**
 * Keadaan layar guru/proyektor. Sengaja TIDAK berlangganan `round:map` (peta ronde berjalan) maupun `integrity:alert`:
 * peta tidak boleh ada di layar proyektor saat LOOK/WALK (12.4) dan tanda integritas hanya untuk laporan guru (A9).
 */
export class HostClient {
  state: HostState = initialHostState();
  private listeners = new Set<Listener>();
  readonly socket: Socket;
  private token = "";

  constructor(socket?: Socket) {
    this.socket = socket ?? io({ path: socketPath(), transports: ["websocket", "polling"], reconnectionDelay: 500, reconnectionDelayMax: 3000 });
    this.wire();
  }

  subscribe = (l: Listener): (() => void) => {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  };
  getSnapshot = (): HostState => this.state;

  private set(patch: Partial<HostState>): void {
    this.state = { ...this.state, ...patch };
    for (const l of this.listeners) l();
  }

  private ask<T extends object = object>(event: string, payload: Record<string, unknown> = {}): Promise<Ack<T>> {
    return new Promise((resolve) => {
      this.socket.timeout(5000).emit(event, payload, (err: Error | null, res: Ack<T>) => resolve(err ? ({ ok: false, error: "GENERIC" } as unknown as Ack<T>) : res));
    });
  }

  private auth(): { sessionId: string; hostToken: string } {
    return { sessionId: this.state.sessionId, hostToken: this.token };
  }

  private applyPhase(p: PhasePayload, remainingMs: number | null): void {
    const patch: Partial<HostState> = { phase: p, phaseEndsAt: remainingMs === null ? null : performance.now() + remainingMs };
    if (p.phase === "LOOK") Object.assign(patch, { summary: null, walk: null });
    if (p.phase === "TUTORIAL") Object.assign(patch, { tutorial: null });
    if (p.phase !== "LOBBY" && p.phase !== "COUNTDOWN" && p.phase !== "INTRO_IDENT" && p.phase !== "INTRO_TRAILER") Object.assign(patch, { code: null });
    this.set(patch);
  }

  private wire(): void {
    const s = this.socket;
    s.on("connect", () => {
      this.set({ online: true });
      void this.restore();
    });
    s.on("disconnect", () => this.set({ online: false }));
    s.on("phase", (p: PhasePayload) => this.applyPhase(p, p.durationMs));
    s.on("lobby:update", (lobby: LobbyUpdate) => this.set({ lobby }));
    s.on("walk:status", (walk: { finished: number; total: number }) => this.set({ walk }));
    s.on("tutorial:status", (tutorial: { ready: number; total: number }) => this.set({ tutorial }));
    s.on("round:summary", (summary: RoundSummary) => this.set({ summary }));
    s.on("leaderboard", (v: { top5: { nickname: string; points: number }[] }) => this.set({ top5: v.top5 }));
    s.on("podium", (v: { top3: { nickname: string; points: number }[] }) => this.set({ podium: v.top3 }));
    s.on("rejected:count", (v: { count: number }) => this.set({ rejected: v.count }));
    if (s.connected) {
      this.set({ online: true });
      void this.restore();
    }
  }

  /** Memulihkan sesi guru setelah muat ulang atau koneksi putus. */
  private async restore(): Promise<void> {
    const saved = readSaved();
    if (!saved) return;
    this.token = saved.hostToken ?? session.get(PIN_KEY) ?? "";
    this.set({ sessionId: saved.sessionId, backUrl: session.get(BACK_KEY) });
    const r = await this.ask<{ phase: string; lobby: LobbyUpdate; settings: SessionSettings; code: string | null; rejected: number; phaseState: { payload: PhasePayload; remainingMs: number | null } | null }>("host:attach", this.auth());
    if (!r.ok) {
      writeSaved(null);
      this.set({ ...initialHostState(), online: true });
      return;
    }
    this.set({ created: true, lobby: r.lobby, settings: r.settings, code: r.code, rejected: r.rejected });
    if (r.phaseState) this.applyPhase(r.phaseState.payload, r.phaseState.remainingMs);
  }

  // ------------------------------------------------------------------ aksi guru

  /**
   * Membuat sesi. `link.pin` (dari SIMPETERI) menjadi token guru sehingga guru tidak diminta PIN di sini; `link.kembali` adalah
   * halaman SIMPETERI tujuan saat sesi berakhir. PIN hanya hidup di memori dan sessionStorage tab ini: tidak masuk URL maupun localStorage.
   */
  async create(roster: RosterEntry[], settings: Partial<SessionSettings>, link?: { pin?: string; kembali?: string }): Promise<boolean> {
    this.set({ error: null });
    const r = await this.ask<HostCreateAck>("host:create", { roster, settings, ...(link?.pin ? { hostToken: link.pin } : {}) });
    if (!r.ok) {
      const detail = Array.isArray(r.detail) ? (r.detail as string[]).join("; ") : "";
      this.set({ error: `Sesi gagal dibuat. ${detail}`.trim() });
      return false;
    }
    this.token = r.hostToken;
    if (link?.pin) {
      writeSaved({ sessionId: r.sessionId });
      session.set(PIN_KEY, link.pin);
    } else {
      writeSaved({ sessionId: r.sessionId, hostToken: r.hostToken });
      session.set(PIN_KEY, null);
    }
    session.set(BACK_KEY, link?.kembali ?? null);
    this.set({ created: true, sessionId: r.sessionId, code: r.code, settings: r.settings, backUrl: link?.kembali ?? null });
    return true;
  }

  /** Header untuk mengambil berkas hasil sesi yang masih berjalan (token guru). */
  exportHeaders(): Record<string, string> {
    return this.token ? { "x-host-token": this.token } : {};
  }

  /** Mengambil berkas hasil dari server dengan token guru (tautan biasa tidak bisa membawa header). */
  fetchExport(file: string): Promise<Response> {
    const test = this.state.settings?.kind === "TEST" ? "?includeTest=1" : "";
    return fetch(withBase(`api/sessions/${this.state.sessionId}/${file}${test}`), { headers: this.exportHeaders() });
  }

  private clearLink(): void {
    session.set(PIN_KEY, null);
    session.set(BACK_KEY, null);
  }

  async updateSettings(patch: Partial<SessionSettings>): Promise<string | null> {
    const r = await this.ask<{ settings: SessionSettings }>("host:settings", { ...this.auth(), settings: patch });
    if (!r.ok) return Array.isArray(r.detail) ? (r.detail as string[]).join("; ") : "Pengaturan ditolak.";
    if ("settings" in r && r.settings) this.set({ settings: r.settings as SessionSettings });
    return null;
  }

  async command(event: "host:skipIntro" | "host:start" | "host:skip" | "host:end"): Promise<Ack> {
    const r = await this.ask(event, this.auth());
    if (!r.ok) this.set({ error: r.error });
    else this.set({ error: null });
    if (event === "host:end" && r.ok) {
      writeSaved(null);
      this.clearLink(); // backUrl tetap di state agar layar bisa kembali ke SIMPETERI sebelum memuat ulang
    }
    return r;
  }

  /** Menghapus siswa dari sesi (perangkat ter-reset/error): nama, hasil, dan peringkatnya dibuang. */
  async removePlayer(rosterId: string): Promise<boolean> {
    const r = await this.ask("host:removePlayer", { ...this.auth(), rosterId });
    return r.ok;
  }

  clearSeat(row: number, col: number): void {
    void this.ask("host:clearSeat", { ...this.auth(), row, col });
  }

  /** Sesi baru: lupakan sesi lama di perangkat ini. */
  reset(): void {
    writeSaved(null);
    this.token = "";
    this.set({ ...initialHostState(), online: this.state.online });
  }
}

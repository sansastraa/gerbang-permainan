import { isValidHostToken, type RosterEntry } from "@route-rush/shared";

/** Pesan dari SIMPETERI (jendela pembuka) berisi daftar siswa satu kelas. */
export const ROSTER_MESSAGE = "route-rush:roster";
/** Pesan balasan dari layar guru ke jendela pembuka: "saya siap menerima daftar". */
export const READY_MESSAGE = "route-rush:host-ready";

export interface ImportedRoster {
  kelas: string;
  roster: RosterEntry[];
  /** PIN guru dari SIMPETERI (4–32 karakter); dipakai sebagai token guru. Hanya di memori, tidak disimpan. */
  pin?: string;
  /** Alamat halaman SIMPETERI untuk kembali setelah sesi berakhir; selalu satu asal dengan pengirim pesan. */
  kembali?: string;
  /** Id sesi Multi Permainan di SIMPETERI; hanya dibawa pulang oleh SIMPETERI sendiri, game tidak memakainya. */
  multiSesi?: string;
}

const MAX_STUDENTS = 80;

/**
 * Memeriksa dan membersihkan pesan impor. Mengembalikan null bila bentuknya salah, sehingga pesan asing atau rusak diabaikan.

 * Nama dan id dipotong ke panjang wajar; id wajib unik; absen (bila ada) bilangan bulat 1–200.
 * Bidang opsional: `pin` (harus sah), `kembali` (URL http/https mutlak; diterima hanya bila satu asal dengan
 * `origin` pengirim pesan), dan `multiSesi` (id pendek berhuruf-angka). Bidang yang ada tetapi tidak sah menolak seluruh pesan.
 */
export function parseImportMessage(data: unknown, origin?: string): ImportedRoster | null {
  if (typeof data !== "object" || data === null) return null;
  const m = data as Record<string, unknown>;
  if (m["type"] !== ROSTER_MESSAGE || !Array.isArray(m["roster"])) return null;
  const raw = m["roster"] as unknown[];
  if (raw.length === 0 || raw.length > MAX_STUDENTS) return null;
  const seen = new Set<string>();
  const roster: RosterEntry[] = [];
  for (const r of raw) {
    if (typeof r !== "object" || r === null) return null;
    const e = r as Record<string, unknown>;
    const id = typeof e["id"] === "string" ? e["id"].trim().slice(0, 64) : "";
    const name = typeof e["name"] === "string" ? e["name"].trim().replace(/\s+/g, " ").slice(0, 60) : "";
    if (!id || !name || seen.has(id)) return null;
    seen.add(id);
    const absen = e["absen"];
    if (absen !== undefined && absen !== null && !(typeof absen === "number" && Number.isInteger(absen) && absen >= 1 && absen <= 200)) return null;
    roster.push({
      id,
      name,
      ...(typeof e["kelas"] === "string" && e["kelas"].trim() ? { kelas: e["kelas"].trim().slice(0, 40) } : {}),
      ...(typeof absen === "number" ? { absen } : {}),
    });
  }
  const kelas = typeof m["kelas"] === "string" ? m["kelas"].trim().slice(0, 40) : "";
  // bidang tautan SIMPETERI bersifat opsional, tetapi bila ada harus sah: bidang rusak menolak seluruh pesan
  const given = (k: string): boolean => m[k] !== undefined && m[k] !== null;
  if (given("pin") && !isValidHostToken(m["pin"])) return null;
  if (given("kembali") && safeReturnUrl(m["kembali"], origin) === undefined) return null;
  if (given("multiSesi") && !(typeof m["multiSesi"] === "string" && /^[\w-]{1,64}$/.test(m["multiSesi"]))) return null;
  const pin = given("pin") ? (m["pin"] as string) : undefined;
  const kembali = given("kembali") ? safeReturnUrl(m["kembali"], origin) : undefined;
  const multiSesi = given("multiSesi") ? (m["multiSesi"] as string) : undefined;
  return { kelas, roster, ...(pin ? { pin } : {}), ...(kembali ? { kembali } : {}), ...(multiSesi ? { multiSesi } : {}) };
}

/** URL kembali yang aman: http/https mutlak, tanpa kredensial, dan satu asal dengan pengirim pesan (bila asal pengirim diketahui). */
export function safeReturnUrl(value: unknown, origin?: string): string | undefined {
  if (typeof value !== "string" || value.length === 0 || value.length > 2048) return undefined;
  try {
    const u = new URL(value);
    if ((u.protocol !== "http:" && u.protocol !== "https:") || u.username || u.password) return undefined;
    if (origin !== undefined && u.origin !== origin) return undefined;
    return u.toString();
  } catch {
    return undefined;
  }
}

/** Alamat tujuan saat sesi berakhir: halaman SIMPETERI dengan `selesai=1` dan `gameSesi=<id sesi game>` ditambahkan. */
export function buildReturnUrl(kembali: string, sessionId: string): string {
  const u = new URL(kembali);
  u.searchParams.set("selesai", "1");
  u.searchParams.set("gameSesi", sessionId);
  return u.toString();
}
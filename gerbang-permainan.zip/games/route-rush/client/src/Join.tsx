import { useEffect, useMemo, useRef, useState } from "react";
import { COPY, type RosterView, type SeatLayout } from "@route-rush/shared";
import { withBase } from "./basePath";
import { enterFullscreen } from "./hooks";
import type { GameClient, SeatTaken } from "./store";

const ROAD = "M70 150 C 230 150, 270 70, 440 92 S 700 176, 800 118 S 900 106, 935 124";

/** Gambar peta kampung di kaki halaman depan: jalan dari Rumah ke Sekolah, koin di tiap ruas, kurir membawa paket (diam bila animasi dimatikan). */
function NeighborhoodRoad() {
  const still = typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;
  const road = useRef<SVGPathElement | null>(null);
  const [coins, setCoins] = useState<{ x: number; y: number; w: number }[]>([]);
  useEffect(() => {
    const p = road.current;
    if (!p || typeof p.getPointAtLength !== "function") return;
    const len = p.getTotalLength();
    setCoins(
      [0.16, 0.32, 0.62, 0.85].map((f, i) => {
        const pt = p.getPointAtLength(len * f); // DOMPoint: x dan y bukan properti sendiri, jadi tidak boleh disebar
        return { x: pt.x, y: pt.y, w: [3, 5, 2, 4][i] as number };
      }),
    );
  }, []);
  const place = (x: number, y: number, fill: string, label: string, step: string) => (
    <g className="lp-place" tabIndex={0}>
      <circle cx={x} cy={y} r="30" fill={fill} stroke="#0e1a33" strokeWidth="4" className="lp-place-dot" />
      <text x={x} y={y + 62} textAnchor="middle" className="lp-place-name">
        {label}
      </text>
      <text x={x} y={y + 82} textAnchor="middle" className="lp-place-step">
        {step}
      </text>
    </g>
  );
  return (
    <svg className="lp-map" viewBox="0 0 1000 250" role="img" aria-label="Peta jalan dari rumah ke sekolah">
      <ellipse cx="250" cy="215" rx="110" ry="26" fill="#cfe3b4" />
      <ellipse cx="610" cy="60" rx="120" ry="28" fill="#cfe3b4" />
      <ellipse cx="800" cy="38" rx="90" ry="22" fill="#cfe3b4" />
      {[[210, 205], [250, 222], [295, 208], [575, 56], [620, 66], [660, 52], [770, 34], [812, 42], [850, 30]].map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r="11" fill="#7fb069" stroke="#0e1a33" strokeWidth="2.5" />
      ))}
      <path d={ROAD} className="lp-road-bed" />
      <path ref={road} d={ROAD} className="lp-road" />
      <path d={ROAD} className="lp-road-dash" />
      {coins.map((c, i) => (
        <g key={i} transform={`translate(${c.x} ${c.y})`}>
          <g className="lp-coin" style={{ animationDelay: `${600 + i * 120}ms` }}>
            <circle r="17" fill="#fff8e1" stroke="#f9a825" strokeWidth="5" />
            <text textAnchor="middle" dominantBaseline="central" y="1" className="lp-coin-n">
              {c.w}
            </text>
          </g>
        </g>
      ))}
      {place(70, 150, "#1565c0", "Rumah", "1 · Lihat peta")}
      {place(440, 92, "#5e35b1", "Pasar", "2 · Hitung koin")}
      {place(935, 124, "#c62828", "Sekolah", "3 · Ketuk tempat")}
      {/* ikon sederhana di dalam lingkaran tempat */}
      <path d="M52 152 L70 136 L88 152 M57 150 V166 H83 V150 M66 166 V156 H74 V166" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M424 98 H456 M427 98 V86 H453 V98 M430 86 L433 78 H447 L450 86" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinejoin="round" strokeLinecap="round" />
      <path d="M917 142 V110 L935 100 L953 110 V142 Z M928 142 V128 H942 V142 M935 100 V88 L945 91 L935 94" fill="none" stroke="#fff" strokeWidth="3.5" strokeLinejoin="round" strokeLinecap="round" />
      <g className="lp-courier">
        <g transform="translate(0 -22)">
          <rect x="-13" y="-16" width="26" height="20" rx="4" fill="#ef6c00" stroke="#0e1a33" strokeWidth="3.5" />
          <path d="M-13 -8 H13 M0 -16 V4" stroke="#0e1a33" strokeWidth="3" />
          <circle cx="-14" cy="14" r="9" fill="none" stroke="#0e1a33" strokeWidth="4" />
          <circle cx="14" cy="14" r="9" fill="none" stroke="#0e1a33" strokeWidth="4" />
          <path d="M-14 14 L0 4 L14 14 M0 4 L-2 -2" fill="none" stroke="#0e1a33" strokeWidth="4" strokeLinecap="round" />
        </g>
        {still ? null : <animateMotion dur="11s" repeatCount="indefinite" path={ROAD} keyPoints="0;1" keyTimes="0;1" calcMode="linear" />}
      </g>
    </svg>
  );
}

/** Android/Chrome menawarkan pemasangan lewat peristiwa ini; iPhone dan iPad (Safari) tidak punya, jadi diberi langkahnya. */
interface InstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
}

const isStandalone = (): boolean => (typeof matchMedia === "function" && matchMedia("(display-mode: standalone)").matches) || (navigator as Navigator & { standalone?: boolean }).standalone === true;
/** iPhone, iPad, dan iPadOS (yang menyamar sebagai Mac tetapi punya layar sentuh). */
const isApple = (): boolean => /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);

function InstallHint() {
  const [event, setEvent] = useState<InstallPromptEvent | null>(null);
  const [steps, setSteps] = useState(false);
  const [done, setDone] = useState(false);
  useEffect(() => {
    const onPrompt = (e: Event): void => {
      e.preventDefault();
      setEvent(e as InstallPromptEvent);
    };
    const onInstalled = (): void => setDone(true);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);
  if (done || isStandalone()) return null;
  if (event) {
    return (
      <div className="a-install" data-testid="install-hint">
        <button
          type="button"
          className="btn"
          onClick={() => {
            void event.prompt();
            void event.userChoice.then(() => setEvent(null));
          }}
          data-testid="install-btn"
        >
          Pasang di layar utama
        </button>
        <small>Lebih cepat dibuka dan tampil layar penuh.</small>
      </div>
    );
  }
  if (isApple()) {
    return (
      <div className="a-install" data-testid="install-hint">
        <button type="button" className="btn" onClick={() => setSteps((v) => !v)} aria-expanded={steps} data-testid="install-btn">
          Pasang di layar utama
        </button>
        {steps ? (
          <ol>
            <li>
              <b>1</b>Ketuk tombol Bagikan di Safari
            </li>
            <li>
              <b>2</b>Pilih Tambah ke Layar Utama
            </li>
            <li>
              <b>3</b>Ketuk Tambah
            </li>
          </ol>
        ) : null}
      </div>
    );
  }
  return null;
}

/** Halaman depan: label paket untuk murid (kode sesi 6 digit + keypad), tautan layar guru, dan peta cara bermain. Uji memakai testid yang sama. */
export function PinScreen({ game, error }: { game: GameClient; error: string | null }) {
  const [code, setCode] = useState("");
  const [busy, setBusy] = useState(false);
  const buzz = (ms: number): void => {
    try {
      navigator.vibrate?.(ms);
    } catch {
      /* perangkat tanpa getar */
    }
  };
  const push = (d: string): void => {
    buzz(8);
    setCode((c) => (c.length < 6 ? c + d : c));
  };
  const submit = async (): Promise<void> => {
    if (code.length !== 6 || busy) return;
    setBusy(true);
    const ok = await game.enterPin(code);
    setBusy(false);
    if (!ok) {
      buzz(60);
      setCode("");
    }
  };
  // papan ketik fisik: angka mengisi kode, Backspace menghapus, Enter masuk
  const keyRef = useRef<(e: KeyboardEvent) => void>(() => undefined);
  keyRef.current = (e: KeyboardEvent): void => {
    if (e.ctrlKey || e.metaKey || e.altKey) return;
    const tag = (e.target as HTMLElement | null)?.tagName;
    if (tag === "INPUT" || tag === "TEXTAREA") return;
    if (/^\d$/.test(e.key)) push(e.key);
    else if (e.key === "Backspace") setCode((c) => c.slice(0, -1));
    else if (e.key === "Enter") void submit();
  };
  useEffect(() => {
    const on = (e: KeyboardEvent): void => keyRef.current(e);
    window.addEventListener("keydown", on);
    return () => window.removeEventListener("keydown", on);
  }, []);
  return (
    <section className="screen landing" data-testid="pin-screen">
      <nav className="lp-nav" aria-label="Navigasi">
        <span className="lp-brand" aria-label={`MinX Arena, ${COPY.gameTitle}`}>
          <span className="lp-brand-mark" aria-hidden="true">
          <svg viewBox="0 0 32 32" width="26" height="26" focusable="false"><line x1="9" y1="16" x2="23" y2="16" stroke="currentColor" strokeWidth="3" strokeLinecap="round" /><circle cx="6.5" cy="16" r="4.5" fill="#fff" /><circle cx="25.5" cy="16" r="4.5" fill="currentColor" /></svg>
        </span>
          <span className="lp-brand-text">
            <small>MinX Arena</small>
            <b>{COPY.gameTitle}</b>
          </span>
        </span>
        <a className="lp-host" href={withBase("host")} data-testid="open-host">
          Layar guru <span aria-hidden="true">→</span>
        </a>
      </nav>
      <div className="lp-main">
        <div className="lp-copy">
          <p className="lp-kicker">Antar paket dari rumah ke sekolah</p>
          <h1 className="lp-logo" aria-label={COPY.gameTitle}>
            <span className="lp-w1">Route</span>
            <span className="lp-w2">Rush</span>
          </h1>
          <p className="lp-lead">Kurirmu harus sampai di sekolah dengan koin paling sedikit. Jumlahkan koin di setiap jalan, lalu ketuk tempat-tempatnya sebelum teman-temanmu.</p>
        </div>
        <article className="lp-label" aria-label="Label paket murid">
          <header className="lp-label-top">
            <span className="lp-label-tape" aria-hidden="true" />
            <span className="lp-label-kick">Paket · ke Sekolah</span>
            <p className="lp-label-title">{COPY.pinTitle}</p>
            <output className="pin-display" data-testid="pin-display" aria-live="polite">
              {Array.from({ length: 6 }, (_, i) => (
                <span key={i} className={code[i] ? "pin-digit filled" : "pin-digit"}>
                  {code[i] ?? ""}
                </span>
              ))}
            </output>
            {error ? (
              <p className="error" role="alert" data-testid="error">
                {error}
              </p>
            ) : null}
          </header>
          <div className="lp-perf" aria-hidden="true" />
          <div className="keypad" role="group" aria-label="Keypad PIN">
            {["1", "2", "3", "4", "5", "6", "7", "8", "9"].map((d) => (
              <button key={d} type="button" className="key" onClick={() => push(d)} data-testid={`key-${d}`}>
                {d}
              </button>
            ))}
            <button type="button" className="key small" onClick={() => setCode((c) => c.slice(0, -1))} data-testid="key-del">
              {COPY.pinDelete}
            </button>
            <button type="button" className="key" onClick={() => push("0")} data-testid="key-0">
              0
            </button>
            <button type="button" className="key go" disabled={code.length !== 6 || busy} onClick={() => void submit()} data-testid="pin-go">
              {COPY.pinGo}
            </button>
          </div>
        </article>
      </div>
      <InstallHint />
      <NeighborhoodRoad />
    </section>
  );
}
/** Tiga langkah masuk: kode → nama → kursi. `now` = langkah yang sedang dikerjakan (0..2). */
function Steps({ now }: { now: number }) {
  return (
    <ol className="a-steps" aria-label="Langkah masuk">
      {["Kode", "Nama", "Kursi"].map((label, i) => (
        <li key={label} className={i < now ? "done" : i === now ? "now" : ""} aria-current={i === now ? "step" : undefined}>
          <i aria-hidden="true">{i < now ? "✓" : i + 1}</i>
          {label}
        </li>
      ))}
    </ol>
  );
}

/** Memilih nama dari daftar siswa SIMPETERI. Nama yang sudah dipakai teman dinonaktifkan. */
export function NameScreen({ game, roster, error }: { game: GameClient; roster: RosterView[]; error: string | null }) {
  const [q, setQ] = useState("");
  const list = useMemo(() => roster.filter((r) => r.name.toLowerCase().includes(q.trim().toLowerCase())), [roster, q]);
  return (
    <section className="screen" data-testid="name-screen">
      <Steps now={1} />
      <h1 className="title">{COPY.nameTitle}</h1>
      <input className="search" type="search" value={q} onChange={(e) => setQ(e.target.value)} placeholder={COPY.nameSearch} aria-label={COPY.nameSearch} data-testid="name-search" />
      {error ? (
        <p className="error" role="alert" data-testid="error">
          {error}
        </p>
      ) : null}
      <ul className="names">
        {list.map((r) => (
          <li key={r.id}>
            <button
              type="button"
              className="name-btn"
              disabled={r.taken}
              onClick={() => {
                enterFullscreen();
                void game.claim(r.id);
              }}
              data-testid={`name-${r.id}`}
            >
              <span>{r.name}</span>
              {r.taken ? <small>{COPY.nameTaken}</small> : null}
            </button>
          </li>
        ))}
        {list.length === 0 ? <li className="empty">{COPY.nameNone}</li> : null}
      </ul>
    </section>
  );
}

/** Denah kelas: "Proyektor / papan tulis" di atas, lorong tampilan, kursi terisi abu-abu dengan inisial. */
export function SeatScreen({ game, layout, taken, error }: { game: GameClient; layout: SeatLayout; taken: SeatTaken[]; error: string | null }) {
  const [pick, setPick] = useState<{ row: number; col: number } | null>(null);
  const takenAt = (row: number, col: number): SeatTaken | undefined => taken.find((t) => t.row === row && t.col === col);
  return (
    <section className="screen" data-testid="seat-screen">
      <Steps now={2} />
      <h1 className="title">{COPY.seatPick}</h1>
      <div className="front-board" data-testid="seat-front">
        {COPY.seatFront}
      </div>
      <div className="seat-grid" role="grid">
        {Array.from({ length: layout.rows }, (_, row) => (
          <div key={row} className="seat-row" role="row">
            {Array.from({ length: layout.cols }, (_, col) => {
              const t = takenAt(row, col);
              const selected = pick?.row === row && pick.col === col;
              return (
                <span key={col} className="seat-cell">
                  <button
                    type="button"
                    className={`seat${t ? " taken" : ""}${selected ? " selected" : ""}`}
                    disabled={!!t}
                    onClick={() => setPick({ row, col })}
                    aria-label={t ? `Kursi baris ${row + 1} kolom ${col + 1}, ${COPY.seatTaken}` : `Kursi baris ${row + 1} kolom ${col + 1}`}
                    data-testid={`seat-${row}-${col}`}
                  >
                    {t ? t.initials : ""}
                  </button>
                  {layout.aisleAfterCols.includes(col + 1) ? <i className="aisle" aria-hidden="true" /> : null}
                </span>
              );
            })}
          </div>
        ))}
      </div>
      <p className="a-seat-pick" aria-live="polite">
        {pick ? (
          <>
            Kursimu: baris <b>{pick.row + 1}</b>, kolom <b>{pick.col + 1}</b>
          </>
        ) : (
          "Ketuk satu kursi kosong"
        )}
      </p>
      {error ? (
        <p className="error" role="alert" data-testid="error">
          {error}
        </p>
      ) : null}
      <button
        type="button"
        className="btn primary wide"
        disabled={!pick}
        onClick={() => {
          if (!pick) return;
          enterFullscreen();
          void game.takeSeat(pick.row, pick.col).then((ok) => {
            if (!ok) setPick(null);
          });
        }}
        data-testid="seat-confirm"
      >
        {COPY.seatConfirm}
      </button>
    </section>
  );
}

/**
 * Awalan jalur aplikasi. Build biasa: "/" . Di bawah gerbang satu pintu SIMPETERI (mis. /games/route-rush) build dibuat dengan
 * BASE_PATH=/games/route-rush sehingga Vite menetapkan BASE_URL "/games/route-rush/". Semua jalur ke server (socket, API, tautan, halaman)
 * disusun lewat fungsi di sini, jangan menulis jalur dari akar ("/api/...") langsung.
 */
export const BASE: string = import.meta.env.BASE_URL;

/** Menyusun jalur di bawah awalan: withBase("api/x", "/a/") = "/a/api/x"; withBase("/host", "/") = "/host". */
export function withBase(path: string, base: string = BASE): string {
  return `${base.replace(/\/+$/, "")}/${path.replace(/^\/+/, "")}`;
}

/** Jalur Socket.IO di bawah awalan (server memakai awalan yang sama). */
export const socketPath = (base: string = BASE): string => withBase("socket.io", base);

/** Jalur halaman relatif terhadap awalan: routeOf("/games/route-rush/host", "/games/route-rush/") = "/host". */
export function routeOf(pathname: string, base: string = BASE): string {
  const prefix = base.replace(/\/+$/, "");
  if (prefix && (pathname === prefix || pathname.startsWith(`${prefix}/`))) return pathname.slice(prefix.length) || "/";
  return pathname;
}

/** Alamat yang diketik siswa di HP: host (dan awalan bila ada), mis. "kelas.example.id/games/route-rush"; dari akar hanya host. */
export function studentAddress(host: string, base: string = BASE): string {
  return `${host}${base.replace(/\/+$/, "")}`;
}

/** Alamat lengkap halaman siswa untuk disalin: "https://kelas.example.id/games/route-rush/". */
export function studentUrl(protocol: string, host: string, base: string = BASE): string {
  return `${protocol}//${host}${base.endsWith("/") ? base : `${base}/`}`;
}
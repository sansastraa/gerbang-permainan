import { optimalCost, optimalRoute, packagesIncomplete, routeCost, type MapDef, type NodeId, type RouteState } from "@route-rush/shared";

/** Hasil penilaian ketukan terakhir pada satu langkah tutorial (aturan 12A.5). */
export type StepOutcome = { kind: "going" } | { kind: "done" } | { kind: "retry"; cost: number; best: number } | { kind: "incomplete" };

/** Lama diam sebelum tangan bayangan muncul. */
export const IDLE_HINT_MS = 4000;
/** Angka pada langkah 4 tampil sekian lama lalu berganti "?". */
export const MEMORY_SHOW_MS = 4000;
/** Demo otomatis per langkah bila waktu tutorial habis. */
export const DEMO_STEP_MS = 5000;

/**
 * Menilai RouteState pada langkah `step`. Langkah 3 hanya lolos dengan rute termurah;
 * rute lain yang sampai Sekolah membuat peta diulang. Semua langkah lain lolos begitu sampai.
 */
export function judgeStep(step: number, map: MapDef, state: RouteState): StepOutcome {
  if (state.done) {
    if (step === 3) {
      const cost = routeCost(map, state.path) ?? 0;
      const best = optimalCost(map);
      if (cost !== best) return { kind: "retry", cost, best };
    }
    return { kind: "done" };
  }
  if (packagesIncomplete(map, state)) return { kind: "incomplete" };
  return { kind: "going" };
}

/** Node berikutnya pada rute benar bila pemain masih di jalur itu; null bila sudah menyimpang (pakai tombol Batal). */
export function ghostTarget(map: MapDef, path: readonly NodeId[]): NodeId | null {
  const best = optimalRoute(map);
  if (path.length >= best.length) return null;
  for (let i = 0; i < path.length; i++) if (path[i] !== best[i]) return null;
  return best[path.length] ?? null;
}

/** Urutan ketukan demo otomatis (rute terhemat tanpa titik awal). */
export const demoTaps = (map: MapDef): NodeId[] => optimalRoute(map).slice(1);

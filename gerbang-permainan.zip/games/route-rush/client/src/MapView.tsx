import { useEffect, useState } from "react";
import type { MapDef, MapNode, NodeId, PlaceKind } from "@route-rush/shared";
import { COPY } from "@route-rush/shared";

/**
 * Dua tata letak dengan viewBox lebar 1000: potret (HP) memberi ruang tegak sehingga simpul berdiameter ≥ 64 px pada layar 360 px,
 * lanskap (tablet/HP miring) memakai bidang yang lebih pendek. Jarak simpul terdekat di semua peta: 234 (potret) / 136 (lanskap) satuan.
 */
export interface Layout {
  W: number;
  H: number;
  padX: number;
  padY: number;
  nodeR: number;
  label: number;
  badgeR: number;
  badgeFont: number;
  /** Tambahan radius ketuk di luar lingkaran visual (≈ 12 px). */
  tapExtra: number;
}
// Ukuran dipilih agar lencana bobot, simpul, dan nama tempat (di bawah simpul) tidak saling menimpa pada grid 3×3 dengan jitter.
export const PORTRAIT: Layout = { W: 1000, H: 1200, padX: 110, padY: 110, nodeR: 62, label: 36, badgeR: 38, badgeFont: 46, tapExtra: 30 };
export const LANDSCAPE: Layout = { W: 1000, H: 800, padX: 110, padY: 100, nodeR: 40, label: 27, badgeR: 28, badgeFont: 36, tapExtra: 16 };
const LABEL_ROOM = 50;

/** Lencana di titik tengah jalan; pada jalan tegak digeser menjauhi nama tempat di bawah simpul atasnya. */
export function badgeAt(a: { x: number; y: number }, b: { x: number; y: number }): { x: number; y: number } {
  const [top, bottom] = a.y <= b.y ? [a, b] : [b, a];
  const len = Math.hypot(bottom.x - top.x, bottom.y - top.y) || 1;
  const t = 0.5 + 0.12 * ((bottom.y - top.y) / len);
  return { x: top.x + (bottom.x - top.x) * t, y: top.y + (bottom.y - top.y) * t };
}

export const COLORS = {
  home: "#1565C0",
  school: "#C62828",
  other: "#5E35B1",
  pack: "#EF6C00",
  road: "#9E9E9E",
  route: "#2E7D32",
  trap: "#E53935",
  coin: "#F9A825",
  coinBg: "#FFF8E1",
} as const;

export const project = (n: Pick<MapNode, "x" | "y">, L: Layout): { x: number; y: number } => ({
  x: L.padX + n.x * (L.W - 2 * L.padX),
  y: L.padY + n.y * (L.H - 2 * L.padY - LABEL_ROOM),
});

/** Meregangkan sebaran simpul peta ke seluruh bidang gambar (peta kecil jangan menyisakan ruang kosong dan jalan yang terlalu pendek untuk lencana). */
export function fitNodes(nodes: readonly MapNode[]): MapNode[] {
  const span = (vals: number[]): [number, number] => [Math.min(...vals), Math.max(...vals)];
  const [x0, x1] = span(nodes.map((n) => n.x));
  const [y0, y1] = span(nodes.map((n) => n.y));
  const unit = (v: number, lo: number, hi: number, margin: number): number => (hi - lo < 1e-6 ? 0.5 : margin + ((v - lo) / (hi - lo)) * (1 - 2 * margin));
  return nodes.map((n) => ({ ...n, x: unit(n.x, x0, x1, 0), y: unit(n.y, y0, y1, 0) }));
}

const isPortrait = (): boolean => typeof matchMedia === "function" && matchMedia("(orientation: portrait)").matches;

function usePortrait(): boolean {
  const [p, setP] = useState(isPortrait);
  useEffect(() => {
    if (typeof matchMedia !== "function") return;
    const mq = matchMedia("(orientation: portrait)");
    const on = (): void => setP(mq.matches);
    mq.addEventListener("change", on);
    return () => mq.removeEventListener("change", on);
  }, []);
  return p;
}

const nodeColor = (map: MapDef, n: MapNode): string => (n.id === map.start ? COLORS.home : n.id === map.goal ? COLORS.school : COLORS.other);

/** Ikon tempat buatan sendiri, digambar dari bentuk dasar di kotak -40..40. */
function PlaceIcon({ kind }: { kind: PlaceKind }) {
  const s = { fill: "none", stroke: "#fff", strokeWidth: 6, strokeLinecap: "round", strokeLinejoin: "round" } as const;
  switch (kind) {
    case "home":
      return (
        <g {...s}>
          <path d="M-34 -2 L0 -34 L34 -2" />
          <path d="M-24 -6 V30 H24 V-6" />
          <path d="M-7 30 V10 H7 V30" />
        </g>
      );
    case "school":
      return (
        <g {...s}>
          <path d="M-30 30 V-8 L0 -26 L30 -8 V30 Z" />
          <path d="M-8 30 V8 H8 V30" />
          <path d="M0 -26 V-42 L16 -37 L0 -32" />
        </g>
      );
    case "market":
      return (
        <g {...s}>
          <path d="M-34 -4 L-26 -28 H26 L34 -4 Z" />
          <path d="M-28 -4 V30 H28 V-4" />
          <path d="M-12 30 V10 H12 V30" />
        </g>
      );
    case "park":
      return (
        <g {...s}>
          <circle cx="0" cy="-12" r="22" />
          <path d="M0 10 V34" />
          <path d="M-14 34 H14" />
        </g>
      );
    case "mosque":
      return (
        <g {...s}>
          <path d="M-26 30 V0 A26 26 0 0 1 26 0 V30 Z" />
          <path d="M0 -26 V-40" />
          <path d="M-8 30 V14 H8 V30" />
        </g>
      );
    case "shop":
      return (
        <g {...s}>
          <path d="M-30 -2 V30 H30 V-2" />
          <path d="M-34 -2 H34 L28 -26 H-28 Z" />
          <path d="M-10 30 V8 H10 V30" />
        </g>
      );
    case "library":
      return (
        <g {...s}>
          <path d="M0 -22 V30" />
          <path d="M0 -22 C-12 -30 -26 -28 -34 -24 V26 C-26 22 -12 22 0 30 C12 22 26 22 34 26 V-24 C26 -28 12 -30 0 -22 Z" />
        </g>
      );
    case "clinic":
      return (
        <g {...s}>
          <rect x="-30" y="-30" width="60" height="60" rx="10" />
          <path d="M0 -16 V16 M-16 0 H16" />
        </g>
      );
    case "field":
      return (
        <g {...s}>
          <rect x="-34" y="-22" width="68" height="44" rx="4" />
          <path d="M0 -22 V22" />
          <circle cx="0" cy="0" r="9" />
        </g>
      );
  }
}

/** Kotak paket: penanda tempat wajib mampir (selain warna: bentuk). */
function PackageBadge({ r }: { r: number }) {
  return (
    <g transform={`translate(${r * 0.75} ${-r * 0.75}) scale(${r / 78})`}>
      <rect x="-26" y="-26" width="52" height="52" rx="8" fill={COLORS.pack} stroke="#fff" strokeWidth="6" />
      <path d="M-26 -6 H26 M0 -26 V-6" stroke="#fff" strokeWidth="6" />
    </g>
  );
}

function FlagBadge({ r }: { r: number }) {
  return (
    <g transform={`translate(${r * 0.75} ${-r * 0.75}) scale(${r / 78})`}>
      <circle r="28" fill="#fff" stroke={COLORS.school} strokeWidth="6" />
      <path d="M-8 16 V-16 L14 -8 L-8 0" fill={COLORS.school} stroke={COLORS.school} strokeWidth="5" strokeLinejoin="round" />
    </g>
  );
}

function Courier({ x, y, r }: { x: number; y: number; r: number }) {
  return (
    <g className="courier" style={{ transform: `translate(${x + r + 10}px, ${y - r * 0.8}px) scale(${r / 78})` }} data-testid="courier" pointerEvents="none">
      <circle r="34" fill="#FFD54F" stroke="#fff" strokeWidth="6" />
      <path d="M-22 -2 A22 22 0 0 1 22 -2 Z" fill="#FFC107" stroke="#EF6C00" strokeWidth="4" />
      <rect x="-16" y="-8" width="32" height="10" rx="5" fill="#37474F" />
      <path d="M-24 18 H24" stroke="#EF6C00" strokeWidth="10" strokeLinecap="round" />
      <circle cx="-18" cy="30" r="9" fill="#37474F" />
      <circle cx="18" cy="30" r="9" fill="#37474F" />
    </g>
  );
}

function GhostHand({ x, y }: { x: number; y: number }) {
  return (
    <g className="ghost-hand" style={{ transform: `translate(${x + 18}px, ${y + 8}px)` }} data-testid="ghost-hand" pointerEvents="none">
      <path
        d="M0 0 L0 -62 A12 12 0 0 1 24 -62 V-30 L30 -34 A12 12 0 0 1 48 -22 V12 A44 44 0 0 1 4 52 H-4 L-40 14 A12 12 0 0 1 -24 -2 L-12 8 V0"
        fill="#fff"
        stroke="#0B1E3A"
        strokeWidth="6"
        strokeLinejoin="round"
        opacity="0.92"
      />
    </g>
  );
}

export interface MapViewProps {
  map: MapDef;
  /** Jalur yang sudah ditempuh pemain. */
  path?: readonly NodeId[];
  /** false = lencana berisi "?" (HIDDEN setelah LOOK). */
  showWeights?: boolean;
  /** Jalan yang disorot berkedip (soal ingatan). */
  highlightEdge?: string | null;
  /** Jalur pembanding berwarna merah putus-putus (latihan langkah 3). */
  trapPath?: readonly NodeId[];
  /** Jalur hemat yang ditampilkan setelah ronde (hijau putus-putus). */
  hintPath?: readonly NodeId[];
  shakeNode?: NodeId | null;
  ghostNode?: NodeId | null;
  /** Sembunyikan semua lencana kecuali jalan yang disorot (soal ingatan). */
  hideBadges?: boolean;
  onTap?: (id: NodeId) => void;
  disabled?: boolean;
}

const edgeKey = (a: NodeId, b: NodeId): string => (a < b ? `${a}|${b}` : `${b}|${a}`);

function pathEdges(path: readonly NodeId[] | undefined): Set<string> {
  const s = new Set<string>();
  if (!path) return s;
  for (let i = 1; i < path.length; i++) s.add(edgeKey(path[i - 1] as NodeId, path[i] as NodeId));
  return s;
}

/** Peta SVG bersama untuk Player (dan latihan). viewBox lebar 1000 (potret 1200 tinggi, lanskap 760). */
export function MapView({ map, path = [], showWeights = true, highlightEdge = null, trapPath, hintPath, shakeNode = null, ghostNode = null, hideBadges = false, onTap, disabled = false }: MapViewProps) {
  const portrait = usePortrait();
  const L = portrait ? PORTRAIT : LANDSCAPE;
  const pos = new Map(fitNodes(map.nodes).map((n) => [n.id, project(n, L)] as const));
  // Area ketuk tidak boleh menutupi lingkaran simpul tetangga: dibatasi oleh jarak ke simpul terdekat.
  const nearest = (id: NodeId): number => {
    const me = pos.get(id) as { x: number; y: number };
    let best = Infinity;
    for (const [other, q] of pos) if (other !== id) best = Math.min(best, Math.hypot(q.x - me.x, q.y - me.y));
    return best;
  };
  const walked = pathEdges(path);
  const trap = pathEdges(trapPath);
  const hint = pathEdges(hintPath);
  const here = path.length ? (path[path.length - 1] as NodeId) : map.start;
  const herePos = pos.get(here);
  const visited = new Set(path);

  return (
    <svg className="mapview" viewBox={`0 0 ${L.W} ${L.H}`} role="group" aria-label="Peta jalan" data-testid="map" preserveAspectRatio="xMidYMid meet">
      <g>
        {map.edges.map((e) => {
          const a = pos.get(e.a);
          const b = pos.get(e.b);
          if (!a || !b) return null;
          const k = edgeKey(e.a, e.b);
          const onRoute = walked.has(k);
          const stroke = onRoute ? COLORS.route : trap.has(k) ? COLORS.trap : hint.has(k) ? COLORS.route : COLORS.road;
          return (
            <line
              key={e.id}
              x1={a.x}
              y1={a.y}
              x2={b.x}
              y2={b.y}
              stroke={stroke}
              strokeWidth={onRoute ? 22 : 16}
              strokeLinecap="round"
              strokeDasharray={!onRoute && (trap.has(k) || hint.has(k)) ? "26 22" : undefined}
              data-testid={`edge-${e.id}`}
              data-walked={onRoute ? "1" : "0"}
            />
          );
        })}
      </g>
      <g>
        {map.edges.map((e) => {
          const a = pos.get(e.a);
          const b = pos.get(e.b);
          if (!a || !b) return null;
          const marked = highlightEdge === e.id;
          if (hideBadges && !marked) return null;
          const label = marked && !showWeights ? "?" : showWeights ? String(e.w) : "?";
          const at = badgeAt(a, b);
          return (
            <g key={e.id} transform={`translate(${at.x} ${at.y})`} className={marked ? "badge blink" : "badge"} data-testid={`badge-${e.id}`}>
              <circle r={L.badgeR} fill={COLORS.coinBg} stroke={COLORS.coin} strokeWidth="9" />
              <text textAnchor="middle" dominantBaseline="central" fontSize={L.badgeFont} fontWeight="800" fill="#4E342E" className="badge-text">
                {label}
              </text>
            </g>
          );
        })}
      </g>
      <g>
        {map.nodes.map((n) => {
          const p = pos.get(n.id) as { x: number; y: number };
          const isStop = map.stops.includes(n.id);
          const color = nodeColor(map, n);
          const shaking = shakeNode === n.id;
          return (
            <g
              key={n.id}
              transform={`translate(${p.x} ${p.y})`}
              data-testid={`node-${n.id}`}
              data-kind={n.kind}
              data-visited={visited.has(n.id) ? "1" : "0"}
              data-stop={isStop ? "1" : "0"}
              data-shaking={shaking ? "1" : "0"}
              role="button"
              aria-label={COPY.placeNames[n.kind]}
              aria-disabled={disabled}
              tabIndex={disabled ? -1 : 0}
              style={{ cursor: disabled ? "default" : "pointer" }}
              onClick={() => !disabled && onTap?.(n.id)}
              onKeyDown={(ev) => {
                if (!disabled && (ev.key === "Enter" || ev.key === " ")) {
                  ev.preventDefault();
                  onTap?.(n.id);
                }
              }}
            >
              <g className={shaking ? "shake" : undefined}>
                <circle r={Math.max(L.nodeR, Math.min(L.nodeR + L.tapExtra, nearest(n.id) - L.nodeR - 4))} fill="transparent" />
                <circle r={L.nodeR} fill={color} stroke={isStop ? COLORS.pack : "#fff"} strokeWidth={isStop ? 12 : 8} />
                <g transform={`scale(${(L.nodeR / 78) * 1.15})`}>
                  <PlaceIcon kind={n.kind} />
                </g>
                {isStop ? <PackageBadge r={L.nodeR} /> : null}
                {n.id === map.goal ? <FlagBadge r={L.nodeR} /> : null}
                <text y={L.nodeR + L.label * 0.95} textAnchor="middle" fontSize={L.label} fontWeight="800" fill="#1B1B2F" stroke="#FFFDF5" strokeWidth="8" paintOrder="stroke" className="node-label">
                  {COPY.placeNames[n.kind]}
                </text>
              </g>
            </g>
          );
        })}
      </g>
      {herePos ? <Courier x={herePos.x} y={herePos.y} r={L.nodeR} /> : null}
      {ghostNode && pos.get(ghostNode) ? <GhostHand x={(pos.get(ghostNode) as { x: number }).x} y={(pos.get(ghostNode) as { y: number }).y} /> : null}
    </svg>
  );
}

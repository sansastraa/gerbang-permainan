import { Fragment, useCallback, useEffect, useMemo, useState } from "react";
import type { HostClient, HostState } from "./hostStore";

interface RoundRow {
  roundId: number;
  nNodes: number;
  steps: number;
  optimalCost: number;
  playerCost: number | null;
  optimalHit: boolean;
  completed: boolean;
  timedOut: boolean;
  missed: boolean;
  er: number;
  tRouteMs: number;
  timeLimitS: number;
  points: number;
}

interface StudentRow {
  studentId: string;
  name: string;
  isBot: boolean;
  points: number;
  roundsPlayed: number;
  roundsMissed: number;
  optimal: number;
  meanEr: number | null;
  medianT: number | null;
  integrity: string | null;
  rounds: RoundRow[];
}

interface ReportData {
  sessionId: string;
  kind: "LIVE" | "TEST";
  form: string;
  mode: string;
  students: StudentRow[];
}

type SortKey = "points" | "name" | "optimal" | "time";

const sec = (ms: number | null): string => (ms === null ? "–" : `${(ms / 1000).toFixed(1).replace(".", ",")} dtk`);
const pct = (v: number | null): string => (v === null ? "–" : `${Math.round(v * 100)}%`);

/** Warna titik per ronde: tepat, hampir hemat, selesai tetapi boros, tidak selesai, tidak ikut. */
function dotClass(r: RoundRow): string {
  if (r.missed) return "miss";
  if (!r.completed || r.timedOut) return "bad";
  if (r.optimalHit) return "ok";
  return r.er >= 0.8 ? "near" : "low";
}

const dotLabel: Record<string, string> = { ok: "tepat", near: "hampir hemat", low: "boros", bad: "tidak selesai", miss: "tidak ikut" };

/** Menu Laporan di layar guru: tabel siswa yang bisa dicari dan diurutkan, rincian per ronde, hapus siswa, dan ekspor PDF lewat cetak peramban. */
export function ReportScreen({ host, s, onClose }: { host: HostClient; s: HostState; onClose: () => void }) {
  const [data, setData] = useState<ReportData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("points");
  const [open, setOpen] = useState<string | null>(null);
  const [armed, setArmed] = useState<string | null>(null);
  const [detail, setDetail] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const res = await host.fetchExport("summary.json");
      if (!res.ok) throw new Error(String(res.status));
      setData((await res.json()) as ReportData);
      setError(null);
    } catch {
      setError("Laporan belum dapat dimuat. Coba muat ulang.");
    } finally {
      setBusy(false);
    }
  }, [s.sessionId, s.settings?.kind]);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent): void => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = (data?.students ?? []).filter((r) => q === "" || r.name.toLowerCase().includes(q));
    const by: Record<SortKey, (a: StudentRow, b: StudentRow) => number> = {
      points: (a, b) => b.points - a.points || a.name.localeCompare(b.name),
      name: (a, b) => a.name.localeCompare(b.name),
      optimal: (a, b) => b.optimal - a.optimal || b.points - a.points,
      time: (a, b) => (a.medianT ?? Infinity) - (b.medianT ?? Infinity),
    };
    return [...list].sort(by[sort]);
  }, [data, query, sort]);

  const totals = useMemo(() => {
    const all = data?.students ?? [];
    const rounds = all.flatMap((r) => r.rounds.filter((x) => !x.missed));
    const hit = rounds.filter((x) => x.optimalHit).length;
    const times = rounds.map((x) => x.tRouteMs).sort((a, b) => a - b);
    return {
      students: all.length,
      rounds: rounds.length,
      hitPct: rounds.length ? hit / rounds.length : null,
      medianMs: times.length ? (times[Math.floor((times.length - 1) / 2)] as number) : null,
    };
  }, [data]);

  const remove = async (id: string): Promise<void> => {
    if (armed !== id) {
      setArmed(id);
      window.setTimeout(() => setArmed((cur) => (cur === id ? null : cur)), 4000);
      return;
    }
    setArmed(null);
    if (await host.removePlayer(id)) await load();
  };

  return (
    <div className={`hreport${detail ? " with-detail" : ""}`} role="dialog" aria-modal="true" aria-label="Laporan sesi" data-testid="report">
      <div className="hreport-sheet">
        <header className="hreport-head">
          <div>
            <p className="hkicker">Laporan sesi</p>
            <h1 className="htitle">{data ? `${data.students.length} siswa` : "Memuat…"}</h1>
            <p className="hreport-meta" data-testid="report-meta">
              {data ? `${new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric" })} · Bank ${data.form === "T" ? "Tantangan" : data.form} · Mode ${data.mode === "QUICK" ? "Kilat" : "Standar"}` : ""}
            </p>
          </div>
          <div className="hreport-actions">
            <label className="hswitch" data-on={detail ? "1" : "0"}>
              <input type="checkbox" checked={detail} onChange={(e) => setDetail(e.target.checked)} data-testid="report-detail" />
              <i aria-hidden="true" />
              <span>Sertakan rincian ronde di PDF</span>
            </label>
            <button type="button" className="btn primary hsmall" onClick={() => window.print()} disabled={!data} data-testid="report-pdf">
              Ekspor PDF
            </button>
            <button type="button" className="btn hsmall" onClick={() => void load()} disabled={busy} data-testid="report-reload">
              Muat ulang
            </button>
            <button type="button" className="btn hsmall" onClick={onClose} data-testid="report-close">
              Tutup
            </button>
          </div>
        </header>

        {error ? (
          <p className="error" role="alert" data-testid="report-error">
            {error}
          </p>
        ) : null}

        <section className="hreport-stats" aria-label="Ringkasan kelas">
          <div>
            <b data-testid="stat-students">{totals.students}</b>
            <span>siswa</span>
          </div>
          <div>
            <b data-testid="stat-hit">{pct(totals.hitPct)}</b>
            <span>jawaban tepat</span>
          </div>
          <div>
            <b>{sec(totals.medianMs)}</b>
            <span>waktu median</span>
          </div>
          <div>
            <b>{totals.rounds}</b>
            <span>jawaban terkumpul</span>
          </div>
        </section>

        <div className="hreport-tools">
          <input type="search" placeholder="Cari nama siswa" value={query} onChange={(e) => setQuery(e.target.value)} aria-label="Cari nama siswa" data-testid="report-search" />
          <div className="hseg-row" role="group" aria-label="Urutkan">
            {(
              [
                ["points", "Poin"],
                ["optimal", "Tepat"],
                ["time", "Tercepat"],
                ["name", "Nama"],
              ] as const
            ).map(([k, label]) => (
              <button key={k} type="button" className={`hseg-opt${sort === k ? " on" : ""}`} aria-pressed={sort === k} onClick={() => setSort(k)} data-testid={`sort-${k}`}>
                {label}
              </button>
            ))}
          </div>
        </div>

        <table className="hreport-table" data-testid="report-table">
          <thead>
            <tr>
              <th>#</th>
              <th>Nama</th>
              <th>Poin</th>
              <th>Tepat</th>
              <th>Ronde</th>
              <th>Waktu median</th>
              <th className="noprint" aria-label="Aksi" />
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={7} className="hreport-empty" data-testid="report-empty">
                  {data ? (query ? "Tidak ada nama yang cocok." : "Belum ada siswa yang menjawab.") : "Memuat…"}
                </td>
              </tr>
            ) : null}
            {rows.map((r, i) => (
              <Fragment key={r.studentId}>
                <tr className={open === r.studentId ? "open" : ""} data-testid={`report-row-${r.studentId}`}>
                  <td className="hrank-cell">{i + 1}</td>
                  <td>
                    <button type="button" className="hname-btn" aria-expanded={open === r.studentId} onClick={() => setOpen(open === r.studentId ? null : r.studentId)}>
                      {r.name}
                    </button>
                    {r.integrity ? <small className="hflag">{r.integrity}</small> : null}
                  </td>
                  <td className="num">{r.points}</td>
                  <td className="num">
                    {r.optimal}/{r.roundsPlayed}
                  </td>
                  <td>
                    <span className="hdotrow" role="img" aria-label={r.rounds.map((x) => dotLabel[dotClass(x)]).join(", ")}>
                      {r.rounds.map((x) => (
                        <i key={x.roundId} className={dotClass(x)} title={`Ronde ${x.roundId}: ${dotLabel[dotClass(x)]}`} />
                      ))}
                    </span>
                  </td>
                  <td className="num">{sec(r.medianT === null ? null : r.medianT * 1000)}</td>
                  <td className="noprint hreport-act">
                    <button type="button" className={`btn hsmall danger${armed === r.studentId ? " armed" : ""}`} onClick={() => void remove(r.studentId)} data-testid={`report-remove-${r.studentId}`} aria-label={`Hapus ${r.name} dari sesi`}>
                      {armed === r.studentId ? "Yakin hapus?" : "Hapus"}
                    </button>
                  </td>
                </tr>
                {open === r.studentId || detail ? (
                  <tr className={`hreport-detail${open === r.studentId ? " shown" : ""}`}>
                    <td />
                    <td colSpan={6}>
                      <table className="hreport-rounds">
                        <thead>
                          <tr>
                            <th>Ronde</th>
                            <th>Peta</th>
                            <th>Langkah</th>
                            <th>Koin (rute / terbaik)</th>
                            <th>Waktu</th>
                            <th>Hasil</th>
                            <th>Poin</th>
                          </tr>
                        </thead>
                        <tbody>
                          {r.rounds.map((x) => (
                            <tr key={x.roundId}>
                              <td>{x.roundId}</td>
                              <td>{x.nNodes} tempat</td>
                              <td>{x.missed ? "–" : `${x.steps}`}</td>
                              <td>{x.playerCost === null ? "–" : `${x.playerCost} / ${x.optimalCost}`}</td>
                              <td>{x.missed ? "–" : `${sec(x.tRouteMs)} dari ${x.timeLimitS} dtk`}</td>
                              <td>
                                <span className={`hpill ${dotClass(x)}`}>{dotLabel[dotClass(x)]}</span>
                              </td>
                              <td className="num">{x.points}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                ) : null}
              </Fragment>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

import { describe, expect, it } from "vitest";
import { createRoute, parseTutorial, tapNode, type MapDef } from "@route-rush/shared";
import { burstSchedule, seedOf } from "./Ready";
import { stripWeights } from "./store";
import { demoTaps, ghostTarget, judgeStep } from "./tutorialLogic";
import tutorialJson from "../../shared/maps/tutorial.json";

const tutorial = (n: number): MapDef => parseTutorial(tutorialJson)[n - 1] as MapDef;

const walk = (map: MapDef, ids: string[]) => ids.reduce((s, id, i) => tapNode(map, s, id, i * 700), createRoute(map));

describe("ritme glitch READY (I20)", () => {
  it("studentId sama → jadwal burst identik; studentId berbeda → jadwal berbeda", () => {
    const a1 = burstSchedule(seedOf("siswa-1"), 10);
    const a2 = burstSchedule(seedOf("siswa-1"), 10);
    const b = burstSchedule(seedOf("siswa-2"), 10);
    expect(a1).toEqual(a2);
    expect(a1).not.toEqual(b);
  });

  it("selang antar-burst selalu 2,4–3,6 detik dan burst pertama pada 1,2 detik", () => {
    const s = burstSchedule(seedOf("siswa-3"), 200);
    expect(s[0]).toBe(1200);
    for (let i = 1; i < s.length; i++) {
      const gap = (s[i] as number) - (s[i - 1] as number);
      expect(gap).toBeGreaterThanOrEqual(2400);
      expect(gap).toBeLessThan(3600);
    }
  });
});

describe("aturan tutorial (12A.5)", () => {
  it("langkah 3: rute 9 koin diulang, rute 7 koin lolos (I8)", () => {
    const m = tutorial(3);
    const mahal = walk(m, ["n3", "n4"]);
    expect(judgeStep(3, m, mahal)).toEqual({ kind: "retry", cost: 9, best: 7 });
    expect(judgeStep(3, m, walk(m, ["n1", "n2", "n4"]))).toEqual({ kind: "done" });
    expect(judgeStep(3, m, walk(m, ["n1"]))).toEqual({ kind: "going" });
  });

  it("langkah 5: jalan pintas tidak selesai dan memberi 'paket belum lengkap' (I7)", () => {
    const m = tutorial(5);
    const pintas = walk(m, ["n2", "n4"]);
    expect(pintas.done).toBe(false);
    expect(judgeStep(5, m, pintas)).toEqual({ kind: "incomplete" });
    expect(judgeStep(5, m, walk(m, ["n1", "n3", "n4"]))).toEqual({ kind: "done" });
  });

  it("langkah 2: ketuk Sekolah dari Rumah tidak valid dan jalur tetap [n0] (I6)", () => {
    const m = tutorial(2);
    const s = walk(m, ["n3"]);
    expect(s.invalidTaps).toBe(1);
    expect(s.path).toEqual(["n0"]);
  });

  it("tangan bayangan menunjuk node berikutnya pada rute benar; null bila sudah menyimpang", () => {
    const m = tutorial(5);
    expect(ghostTarget(m, ["n0"])).toBe("n1");
    expect(ghostTarget(m, ["n0", "n1"])).toBe("n3");
    expect(ghostTarget(m, ["n0", "n2"])).toBeNull();
    expect(ghostTarget(m, ["n0", "n1", "n3", "n4"])).toBeNull();
  });

  it("demo otomatis mengetuk rute terhemat tanpa titik awal", () => {
    expect(demoTaps(tutorial(1))).toEqual(["n1", "n2"]);
    expect(demoTaps(tutorial(5))).toEqual(["n1", "n3", "n4"]);
  });
});

describe("angka HIDDEN dibuang dari store (A3)", () => {
  it("stripWeights menjadikan semua bobot 0 tanpa mengubah struktur", () => {
    const map = tutorial(4);
    const stripped = stripWeights(map);
    expect(stripped.edges.every((e) => e.w === 0)).toBe(true);
    expect(stripped.edges.map((e) => e.id)).toEqual(map.edges.map((e) => e.id));
    expect(map.edges.some((e) => e.w > 0)).toBe(true);
  });
});
import { useEffect, useState } from "react";
import { COPY, optimalRoute, parseTutorial, type MapDef, type NodeId } from "@route-rush/shared";
import tutorialJson from "../../shared/maps/tutorial.json";
import { MapView } from "./MapView";
import { useNow } from "./hooks";

/** Peta contoh = peta tutorial dari berkas acuan (bukan data buatan). */
const T = parseTutorial(tutorialJson);
const map = (n: number): MapDef => T[n - 1] as MapDef;

export interface RuleCard {
  text: string;
  /** Gambar contoh: peta latihan + jalur yang ditunjukkan. */
  map: MapDef | null;
  path: NodeId[];
  trapPath?: NodeId[];
  showWeights: boolean;
  stars?: boolean;
}

const pick = (m: MapDef, upto: number): NodeId[] => optimalRoute(m).slice(0, upto);

/** Enam kartu aturan; contoh gambarnya dihitung dari peta latihan 3, 4, dan 5 (solver `shared/`). */
export function ruleCards(): RuleCard[] {
  const t3 = map(3);
  const t4 = map(4);
  const t5 = map(5);
  return [
    { text: COPY.rules[0] as string, map: t3, path: [t3.start], showWeights: false },
    { text: COPY.rules[1] as string, map: t3, path: pick(t3, 2), showWeights: false },
    { text: COPY.rules[2] as string, map: t3, path: optimalRoute(t3), showWeights: true },
    { text: COPY.rules[3] as string, map: t5, path: optimalRoute(t5), showWeights: true },
    { text: COPY.rules[4] as string, map: null, path: [], showWeights: false, stars: true },
    { text: COPY.rules[5] as string, map: t4, path: pick(t4, 1), showWeights: false },
  ];
}

export function RuleIllustration({ card }: { card: RuleCard }) {
  if (card.stars)
    return (
      <div className="rule-stars" aria-hidden="true">
        <span>★</span>
        <span>★</span>
        <span>★</span>
      </div>
    );
  return <div className="rule-map">{card.map ? <MapView map={card.map} path={card.path} showWeights={card.showWeights} {...(card.trapPath ? { trapPath: card.trapPath } : {})} disabled /> : null}</div>;
}

/** Lembar "Cara bermain" untuk perangkat siswa: kartu bergambar yang bisa dibalik, kapan saja dibuka dan ditutup. */
export function RulesSheet({ onClose }: { onClose: () => void }) {
  const cards = ruleCards();
  const [i, setI] = useState(0);
  const card = cards[i] as RuleCard;
  const last = i === cards.length - 1;
  useEffect(() => {
    const k = (e: KeyboardEvent): void => {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") setI((v) => Math.min(cards.length - 1, v + 1));
      if (e.key === "ArrowLeft") setI((v) => Math.max(0, v - 1));
    };
    window.addEventListener("keydown", k);
    return () => window.removeEventListener("keydown", k);
  }, [cards.length, onClose]);

  return (
    <div className="rules-sheet" role="dialog" aria-modal="true" aria-label={COPY.howToPlay} data-testid="rules-sheet">
      <header className="rules-top">
        <h2>{COPY.howToPlay}</h2>
        <button type="button" className="btn rules-close" onClick={onClose} data-testid="rules-close">
          {COPY.rulesClose}
        </button>
      </header>
      <RuleIllustration card={card} />
      <p className="rule-text" data-testid="rule-text" data-index={i}>
        {card.text}
      </p>
      <ol className="rule-dots" aria-hidden="true">
        {cards.map((_, k) => (
          <li key={k} className={k === i ? "on" : ""} />
        ))}
      </ol>
      <footer className="rules-nav">
        <button type="button" className="btn" disabled={i === 0} onClick={() => setI(i - 1)} data-testid="rules-prev">
          {COPY.rulesPrev}
        </button>
        {last ? (
          <button type="button" className="btn primary" onClick={onClose} data-testid="rules-done">
            {COPY.rulesDone}
          </button>
        ) : (
          <button type="button" className="btn primary" onClick={() => setI(i + 1)} data-testid="rules-next">
            {COPY.rulesNext}
          </button>
        )}
      </footer>
    </div>
  );
}

/** Untuk proyektor: kartu aturan berganti otomatis (tiap `everyMs`) selama latihan di perangkat siswa. */
export function RulesTicker({ everyMs = 12_000 }: { everyMs?: number }) {
  const cards = ruleCards();
  const now = useNow(500);
  const [start] = useState(() => performance.now());
  const i = Math.floor((now - start) / everyMs) % cards.length;
  const card = cards[i] as RuleCard;
  return (
    <div className="rules-ticker" data-testid="rules-ticker">
      <h2 className="hsub">{COPY.howToPlay}</h2>
      <RuleIllustration card={card} />
      <p className="rule-text big" data-testid="ticker-text" data-index={i}>
        {card.text}
      </p>
    </div>
  );
}

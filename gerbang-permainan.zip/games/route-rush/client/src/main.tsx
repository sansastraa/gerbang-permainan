import { StrictMode } from "react";
import { createRoot } from "react-dom/client";
import { App } from "./App";
import { HostApp } from "./Host";
import { HostClient } from "./hostStore";
import { answerAudio, introAudio } from "./audio/engine";
import { introClock } from "./intro/IntroStage";
import { GameClient } from "./store";
import { routeOf, withBase } from "./basePath";
import "./styles.css";
import "./player.css";
import "./landing.css";
import "./host.css";
import "./host-arena.css";
import "./player-arena.css";
import "./mobile.css";

const root = createRoot(document.getElementById("root") as HTMLElement);
const isHost = /^\/host\/?$/.test(routeOf(location.pathname));

// Pengait baca-saja untuk pengujian e2e (tidak dipakai kode permainan).
if (isHost) {
  const host = new HostClient();
  (window as unknown as { __rr: { host: HostClient; introClock: typeof introClock; introAudio: typeof introAudio; answerAudio: typeof answerAudio } }).__rr = { host, introClock, introAudio, answerAudio };
  root.render(
    <StrictMode>
      <HostApp host={host} />
    </StrictMode>,
  );
} else {
  const game = new GameClient();
  (window as unknown as { __rr: { game: GameClient } }).__rr = { game };
  root.render(
    <StrictMode>
      <App game={game} />
    </StrictMode>,
  );
}

// Aplikasi bisa dipasang (PWA). Hanya di build produksi, di koneksi aman atau localhost, dan tidak saat diotomasi (tes).
if (import.meta.env.PROD && "serviceWorker" in navigator && !navigator.webdriver && (location.protocol === "https:" || location.hostname === "localhost")) {
  window.addEventListener("load", () => {
    navigator.serviceWorker.register(withBase("sw.js")).catch(() => undefined);
  });
}
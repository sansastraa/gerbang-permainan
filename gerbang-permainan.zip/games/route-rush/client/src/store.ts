import { io, type Socket } from "socket.io-client";
import { socketPath } from "./basePath";
import type {
  Ack,
  ClaimAck,
  JoinAck,
  MapDef,
  NodeId,
  PhasePayload,
  ProbeQuestion,
  RoundMapPayload,
  RoundResultPayload,
  RosterView,
  SeatLayout,
  SessionPhase,
} from "@route-rush/shared";
import { COPY } from "@route-rush/shared";

export type Stage = "pin" | "name" | "seat" | "play";

export interface SeatTaken {
  row: number;
  col: number;
  initials: string;
}

export interface GameState {
  online: boolean;
  stage: Stage;
  code: string;
  roster: RosterView[];
  seatLayout: SeatLayout | null;
  seatsTaken: SeatTaken[];
  me: { studentId: string; name: string; seat: { row: number; col: number } | null } | null;
  phase: PhasePayload | null;
  /** Batas waktu fase pada jam `performance.now()` perangkat ini (null = tanpa batas). */
  phaseEndsAt: number | null;
  phaseSeq: number;
  tutorial: { step: number; map: MapDef; probe?: ProbeQuestion } | null;
  round: { roundId: number; map: MapDef; showWeights: boolean } | null;
  submitted: { roundId: number; coins: number | null } | null;
  probe: (ProbeQuestion & { roundId: number }) | null;
  probeAnswered: boolean;
  result: RoundResultPayload | null;
  reveal: { optimalPath: NodeId[]; optimalCost: number } | null;
  board: { myRank: number; myPoints: number } | null;
  podium: { nickname: string; points: number }[] | null;
  error: string | null;
  /** `performance.now()` sampai kapan "GO!" ditampilkan di atas layar berikutnya. */
  goUntil: number;
}

export const initialState = (): GameState => ({
  online: false,
  stage: "pin",
  code: "",
  roster: [],
  seatLayout: null,
  seatsTaken: [],
  me: null,
  phase: null,
  phaseEndsAt: null,
  phaseSeq: 0,
  tutorial: null,
  round: null,
  submitted: null,
  probe: null,
  probeAnswered: false,
  result: null,
  reveal: null,
  board: null,
  podium: null,
  error: null,
  goUntil: 0,
});

const SAVE_KEY = "rr.session";
export const GO_MS = 700;

interface Saved {
  code: string;
  token: string;
}

function readSaved(): Saved | null {
  try {
    const raw = localStorage.getItem(SAVE_KEY);
    return raw ? (JSON.parse(raw) as Saved) : null;
  } catch {
    return null;
  }
}

function writeSaved(v: Saved | null): void {
  try {
    if (v) localStorage.setItem(SAVE_KEY, JSON.stringify(v));
    else localStorage.removeItem(SAVE_KEY);
  } catch {
    /* penyimpanan dimatikan: sambung ulang otomatis tidak tersedia */
  }
}

/** Pada ronde HIDDEN setelah LOOK, angka dibuang dari peta di sisi client (bukan hanya disembunyikan). */
export function stripWeights(map: MapDef): MapDef {
  return { ...map, edges: map.edges.map((e) => ({ ...e, w: 0 })) };
}

export const errorText = (code: string | undefined): string => {
  const table = COPY.errors as Record<string, string>;
  return (code && table[code]) || COPY.errors.GENERIC;
};

type Listener = () => void;

/** Penghubung ke server + keadaan permainan di perangkat siswa. */
export class GameClient {
  state: GameState = initialState();
  private listeners = new Set<Listener>();
  readonly socket: Socket;
  private pendingReattach = false;

  constructor(socket?: Socket) {
    this.socket = socket ?? io({ path: socketPath(), transports: ["websocket", "polling"], reconnectionDelay: 500, reconnectionDelayMax: 3000 });
    this.wire();
  }

  subscribe = (l: Listener): (() => void) => {
    this.listeners.add(l);
    return () => this.listeners.delete(l);
  };

  getSnapshot = (): GameState => this.state;

  private set(patch: Partial<GameState>): void {
    this.state = { ...this.state, ...patch };
    for (const l of this.listeners) l();
  }

  private emit<T extends object = object>(event: string, payload: unknown): Promise<Ack<T>> {
    return new Promise((resolve) => {
      this.socket.timeout(5000).emit(event, payload, (err: Error | null, res: Ack<T>) => resolve(err ? ({ ok: false, error: "GENERIC" } as unknown as Ack<T>) : res));
    });
  }

  private applyPhase(p: PhasePayload, remainingMs: number | null): void {
    const now = performance.now();
    const prev = this.state.phase?.phase;
    const resetRound = p.phase === "LOOK" || p.phase === "COUNTDOWN" || p.phase === "TUTORIAL";
    this.set({
      phase: p,
      phaseEndsAt: remainingMs === null ? null : now + remainingMs,
      phaseSeq: this.state.phaseSeq + 1,
      goUntil: prev === "COUNTDOWN" && p.phase !== "COUNTDOWN" ? now + GO_MS : this.state.goUntil,
      ...(this.state.round && p.roundId !== undefined ? { round: { ...this.state.round, roundId: p.roundId } } : {}),
      ...(resetRound && p.phase === "LOOK" ? { submitted: null, probe: null, probeAnswered: false, result: null, reveal: null } : {}),
    });
  }

  private enterFromJoin(ack: JoinAck, code: string): void {
    this.set({ code, roster: ack.roster, seatLayout: ack.seatLayout });
    if (ack.me) {
      this.set({ me: ack.me, stage: "play" });
      if (ack.phaseState) this.applyPhase(ack.phaseState.payload, ack.phaseState.remainingMs);
    }
  }

  private async reattach(): Promise<void> {
    const saved = readSaved();
    if (!saved) return;
    this.pendingReattach = true;
    const r = await this.emit<JoinAck>("player:join", { code: saved.code, studentToken: saved.token });
    this.pendingReattach = false;
    if (r.ok) {
      this.enterFromJoin(r, saved.code);
      if (r.me && this.state.stage === "play" && r.me.seat === null && r.seatLayout.enabled && r.phase === "LOBBY") this.set({ stage: "seat" });
    } else {
      writeSaved(null);
      this.set({ error: errorText(r.error), stage: "pin", me: null });
    }
  }

  private wire(): void {
    const s = this.socket;
    s.on("connect", () => {
      this.set({ online: true });
      void this.reattach();
    });
    s.on("disconnect", () => this.set({ online: false }));
    s.on("phase", (p: PhasePayload) => {
      this.applyPhase(p, p.durationMs);
    });
    s.on("roster:update", (roster: RosterView[]) => this.set({ roster }));
    s.on("seat:update", (v: { taken: SeatTaken[] }) => this.set({ seatsTaken: v.taken }));
    s.on("settings:update", (v: { seatLayout: SeatLayout }) => this.set({ seatLayout: v.seatLayout }));
    s.on("player:released", () => {
      writeSaved(null);
      this.set({ ...initialState(), online: this.state.online, error: COPY.errors.TOKEN_INVALID });
    });
    s.on("tutorial:map", (v: { step: number; map: MapDef | null; probe?: ProbeQuestion }) => {
      if (v.map) this.set({ tutorial: { step: v.step, map: v.map, ...(v.probe ? { probe: v.probe } : {}) } });
    });
    s.on("round:map", (v: RoundMapPayload & { roundId?: number }) => {
      const roundId = this.state.phase?.roundId ?? v.roundId ?? 0;
      this.set({ round: { roundId, map: v.showWeights ? v.map : stripWeights(v.map), showWeights: v.showWeights } });
    });
    s.on("round:hideWeights", () => {
      const r = this.state.round;
      if (r) this.set({ round: { ...r, map: stripWeights(r.map), showWeights: false } });
    });
    s.on("probe:question", (q: ProbeQuestion) => this.set({ probe: { ...q, roundId: this.state.phase?.roundId ?? 0 }, probeAnswered: false }));
    s.on("round:result", (r: RoundResultPayload) => this.set({ result: r }));
    s.on("round:reveal", (v: { optimalPath: NodeId[]; optimalCost: number }) => this.set({ reveal: v }));
    s.on("leaderboard", (v: { myRank: number; myPoints: number }) => this.set({ board: { myRank: v.myRank, myPoints: v.myPoints } }));
    s.on("podium", (v: { top3: { nickname: string; points: number }[] }) => this.set({ podium: v.top3 }));
    if (s.connected) {
      this.set({ online: true });
      void this.reattach();
    }
  }

  // ------------------------------------------------------------------ aksi siswa

  async enterPin(code: string): Promise<boolean> {
    this.set({ error: null });
    const r = await this.emit<JoinAck>("player:join", { code });
    if (!r.ok) {
      this.set({ error: errorText(r.error) });
      return false;
    }
    this.set({ code, roster: r.roster, seatLayout: r.seatLayout, stage: "name", error: null });
    return true;
  }

  async claim(rosterId: string): Promise<boolean> {
    this.set({ error: null });
    const r = await this.emit<ClaimAck>("player:claim", { rosterId });
    if (!r.ok) {
      this.set({ error: errorText(r.error) });
      if (r.error === "NAME_TAKEN" || r.error === "SECOND_DEVICE") this.set({ error: COPY.errors.NAME_TAKEN });
      return false;
    }
    writeSaved({ code: this.state.code, token: r.studentToken });
    const name = this.state.roster.find((x) => x.id === rosterId)?.name ?? "";
    this.set({ me: { studentId: r.studentId, name, seat: null }, seatLayout: r.seatLayout, stage: r.seatLayout.enabled ? "seat" : "play" });
    return true;
  }

  async takeSeat(row: number, col: number): Promise<boolean> {
    this.set({ error: null });
    const r = await this.emit("player:seat", { row, col });
    if (!r.ok) {
      this.set({ error: errorText(r.error) });
      return false;
    }
    const me = this.state.me;
    this.set({ me: me ? { ...me, seat: { row, col } } : me, stage: "play" });
    return true;
  }

  /** Tanpa pilihan kursi (denah dimatikan oleh guru setelah siswa memilih nama). */
  skipSeat(): void {
    this.set({ stage: "play" });
  }

  sendTutorialStep(step: Parameters<GameClient["emitRaw"]>[1]): void {
    this.emitRaw("tutorial:step", step);
  }

  emitRaw(event: string, payload: unknown): void {
    this.socket.emit(event, payload, () => undefined);
  }

  submitRoute(payload: { roundId: number; path: NodeId[]; clientElapsedMs: number; tapLog: unknown[]; invalidTaps: number; undo: number; revisits: number }, coins: number | null): void {
    this.set({ submitted: { roundId: payload.roundId, coins } });
    this.emitRaw("route:submit", payload);
  }

  answerProbe(value: number, ms: number): void {
    const roundId = this.state.probe?.roundId ?? this.state.phase?.roundId ?? 0;
    this.set({ probeAnswered: true });
    this.emitRaw("probe:answer", { roundId, value, clientElapsedMs: ms });
  }

  integrity(type: "FOCUS_LOST" | "FOCUS_BACK" | "FULLSCREEN_EXIT", tMs: number): void {
    const phase: SessionPhase = this.state.phase?.phase ?? "LOBBY";
    this.emitRaw("integrity:event", { type, phase, roundId: this.state.phase?.roundId ?? 0, tMs });
  }

  forget(): void {
    writeSaved(null);
  }

  get reattaching(): boolean {
    return this.pendingReattach;
  }
}

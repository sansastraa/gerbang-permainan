import { describe, expect, it } from "vitest";
import { routeOf, socketPath, studentAddress, studentUrl, withBase } from "./basePath";

describe("penyusun URL di bawah awalan jalur (gerbang satu pintu)", () => {
  it("dari akar: jalur tetap dari akar", () => {
    expect(withBase("api/sessions/x/summary.json", "/")).toBe("/api/sessions/x/summary.json");
    expect(withBase("/host", "/")).toBe("/host");
    expect(socketPath("/")).toBe("/socket.io");
  });
  it("di bawah awalan: semua jalur ikut awalan, tanpa garis miring ganda", () => {
    const base = "/games/route-rush/";
    expect(withBase("host", base)).toBe("/games/route-rush/host");
    expect(withBase("/api/sessions/x/rounds.csv?includeTest=1", base)).toBe("/games/route-rush/api/sessions/x/rounds.csv?includeTest=1");
    expect(withBase("sw.js", base)).toBe("/games/route-rush/sw.js");
    expect(socketPath(base)).toBe("/games/route-rush/socket.io");
  });
  it("routeOf membuang awalan dari jalur halaman", () => {
    const base = "/games/route-rush/";
    expect(routeOf("/games/route-rush/host", base)).toBe("/host");
    expect(routeOf("/games/route-rush/host/", base)).toBe("/host/");
    expect(routeOf("/games/route-rush", base)).toBe("/");
    expect(routeOf("/games/route-rush/", base)).toBe("/");
    expect(routeOf("/host", "/")).toBe("/host");
    expect(routeOf("/games/route-rushmore/host", base)).toBe("/games/route-rushmore/host"); // awalan harus berbatas segmen
  });

  it("alamat untuk siswa memuat awalan bila ada", () => {
    expect(studentAddress("localhost:3000", "/")).toBe("localhost:3000");
    expect(studentAddress("kelas.example.id", "/games/route-rush/")).toBe("kelas.example.id/games/route-rush");
    expect(studentUrl("https:", "kelas.example.id", "/games/route-rush/")).toBe("https://kelas.example.id/games/route-rush/");
    expect(studentUrl("http:", "localhost:3000", "/")).toBe("http://localhost:3000/");
  });
});
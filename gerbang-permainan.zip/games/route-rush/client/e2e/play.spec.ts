import { expect, test, type Page } from "@playwright/test";
import { racePoints, type MapDef, type NodeId, type RoundResult } from "@route-rush/shared";
import {
  HostDriver,
  autoSkip,
  joinAs,
  longestSimplePath,
  node,
  readRounds,
  readTutorials,
  solve,
  startServer,
  stateOf,
  tutorialMap,
  visitedCount,
  watchShake,
  expectShake,
  waitApp,
  type TestServer,
} from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

const expected = (r: RoundResult): number =>
  racePoints({ optimalHit: r.optimalHit, completed: r.completed, er: r.er, tSec: r.tRouteMs / 1000, limitSec: r.timeLimitS });

async function lobbyWith(settings: Record<string, unknown>, browser: import("@playwright/test").Browser) {
  const host = new HostDriver(server.url);
  await host.create(settings);
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
  await joinAs(b, server.url, host.code, "siswa-2", { row: 0, col: 1 });
  return { host, a, b };
}

/** Tutorial 5 langkah. `detailed` ikut memeriksa semua umpan balik (getar, ulang, Batal berkedip, paket belum lengkap, ...). */
async function playTutorial(page: Page, detailed: boolean): Promise<void> {
  const step = (n: number) => page.locator(`[data-testid=tutorial][data-step="${n}"]`);

  // 1: Rumah–Pasar–Sekolah
  await step(1).waitFor();
  const t1 = await tutorialMap(page);
  await expect(page.getByTestId("tutorial-text")).toHaveText("Ketuk Pasar untuk berangkat.");
  if (detailed) {
    // diam lebih dari 4 detik → tangan bayangan menunjuk tempat yang benar
    await expect(page.getByTestId("ghost-hand")).toBeVisible({ timeout: 7000 });
  }
  const r1 = solve(t1);
  await node(page, r1[1] as NodeId).click();
  await expect(page.getByTestId("coin-counter")).toContainText("2");
  await node(page, r1[2] as NodeId).click();
  await expect(page.getByTestId("tutorial-good")).toContainText("Bagus!");

  // 2: Rumah tidak tersambung ke Sekolah
  await step(2).waitFor();
  const t2 = await tutorialMap(page);
  if (detailed) {
    await watchShake(page, t2.goal);
    await node(page, t2.goal).click();
    await expect(page.getByTestId("tutorial-text")).toHaveText("Belum tersambung. Cari jalannya!");
    expect(await visitedCount(page)).toBe(1); // I6: jalur tetap [n0], ketukan tidak valid tidak menggerakkan kurir
    await expectShake(page);
  }
  await walkRoute(page, solve(t2));

  // 3: dua jalan, 9 koin atau 7 koin
  await step(3).waitFor();
  const t3 = await tutorialMap(page);
  if (detailed) {
    // I8: n0 → n3 → n4 berbiaya 9, bukan yang termurah
    await node(page, "n3").click();
    await node(page, "n4").click();
    await expect(page.getByTestId("tutorial-retry")).toContainText("9 koin");
    await expect(page.getByTestId("tutorial-text")).toHaveText("Jalan itu lebih mahal. Coba lagi!");
    await expect(step(3)).toBeVisible(); // belum lanjut
    await page.getByTestId("tutorial-again").click();
    await expect(page.getByTestId("undo")).toHaveClass(/blink/);
    await expect(page.getByTestId("undo-hint")).toHaveText("Salah jalan? Tekan panah ini untuk mundur.");
    await node(page, "n1").click();
    expect(await visitedCount(page)).toBe(2);
    await page.getByTestId("undo").click(); // Batal berfungsi
    expect(await visitedCount(page)).toBe(1);
  }
  await walkRoute(page, solve(t3));

  // 4: angka tampil 4 detik lalu "?"
  await step(4).waitFor();
  const t4 = await tutorialMap(page);
  const probeEdge = (await stateOf<{ edgeId: string }>(page, "s.tutorial.probe")).edgeId;
  if (detailed) {
    await expect(page.getByTestId(`badge-${t4.edges[0]?.id}`)).toHaveText(String(t4.edges[0]?.w));
    await expect(page.getByTestId(`badge-${t4.edges[0]?.id}`)).toHaveText("?", { timeout: 6000 });
    for (const e of t4.edges) await expect(page.getByTestId(`badge-${e.id}`)).toHaveText("?");
  }
  await walkRoute(page, solve(t4));
  await expect(page.getByTestId("tutorial-probe")).toBeVisible();
  const truth = t4.edges.find((e) => e.id === probeEdge)?.w;
  await page.getByTestId(`probe-option-${truth}`).click();
  await expect(page.getByTestId("tutorial-reveal")).toContainText(String(truth));

  // 5: wajib mampir ke Taman
  await step(5).waitFor();
  const t5 = await tutorialMap(page);
  if (detailed) {
    // I7: jalan pintas n0 → n2 → n4 berbiaya 2 dan tidak selesai
    await node(page, "n2").click();
    await node(page, "n4").click();
    await expect(page.getByTestId("tutorial-text")).toHaveText("Paket belum lengkap!");
    await expect(page.getByTestId("coin-counter")).toContainText("2");
    await page.getByTestId("undo").click();
    await page.getByTestId("undo").click();
    expect(await visitedCount(page)).toBe(1);
  }
  await walkRoute(page, solve(t5));
  if (detailed) await expect(page.getByTestId("coin-counter")).toContainText("6");
  // yang selesai lebih dulu melihat "Kamu siap!"; yang terakhir langsung masuk ronde pertama
  await expect(page.locator("[data-testid=tutorial-wait], .app[data-phase=LOOK]").first()).toBeVisible({ timeout: 8000 });
}

async function walkRoute(page: Page, path: readonly NodeId[]): Promise<void> {
  for (const id of path.slice(1)) await node(page, id).click();
}

test("2 pemain: READY → tutorial → ronde VISIBLE/HIDDEN → podium (I6–I8, A3, Batal, getar, '?')", async ({ browser }) => {
  const { host, a, b } = await lobbyWith({ introMode: "FULL", roundIds: [1, 2, 3], lookSeconds: 15, walkSeconds: 40 }, browser);
  autoSkip(host);
  await host.cmd("host:start");
  await waitApp(a, "TUTORIAL");
  await waitApp(b, "TUTORIAL");
  await Promise.all([playTutorial(a, true), playTutorial(b, false)]);

  const tut = readTutorials(server.dataDir, host.sessionId);
  await expect.poll(() => readTutorials(server.dataDir, host.sessionId).length).toBe(2);
  const ani = tut.find((t) => t.studentId === "siswa-1");
  void ani;
  const tutorials = readTutorials(server.dataDir, host.sessionId);
  const rich = tutorials.find((t) => t.steps[1]?.invalidTaps === 1) ?? null;
  expect(rich, "langkah 2: tepat satu ketukan tidak valid (Sekolah dari Rumah)").not.toBeNull();
  expect(rich?.step3Attempts).toBe(2);
  expect(rich?.completed).toBe(true);
  expect(rich?.hints).toBeGreaterThanOrEqual(1);
  expect(rich?.probeCorrect).toBe(true);
  expect(rich?.autoDemoSteps).toEqual([]);
  expect(rich?.steps[2]?.undo).toBe(1);

  const sawBoard: string[] = [];
  for (const roundId of [1, 2, 3]) {
    const hidden = roundId === 2;
    await Promise.all(
      [a, b].map(async (page, i) => {
        await waitApp(page, "LOOK");
        await expect(page.getByTestId("look-banner")).toContainText("Lihat baik-baik!");
        const map = await stateOf<MapDef>(page, "s.round.map");
        // ketukan saat LOOK tidak menggerakkan kurir
        await node(page, solve(map)[1] as NodeId).click({ force: true });
        expect(await visitedCount(page)).toBe(1);
        // satu pembacaan atomik saat LOOK (angka tampil pada kedua jenis ronde)
        const seen = await page.evaluate(() => ({
          badges: [...document.querySelectorAll("[data-testid^=badge-]")].map((el) => [el.getAttribute("data-testid"), el.textContent]),
          willHide: document.querySelector("[data-testid=will-hide]")?.textContent ?? null,
        }));
        expect(Object.fromEntries(seen.badges)).toEqual(Object.fromEntries(map.edges.map((e) => [`badge-${e.id}`, String(e.w)])));
        expect(seen.willHide).toBe(hidden ? "Angka akan hilang!" : null);
        await expect(node(page, map.start)).toBeVisible();

        await waitApp(page, "WALK");
        if (hidden) {
          // A3: angka hilang dari DOM dan store client
          for (const e of map.edges) await expect(page.getByTestId(`badge-${e.id}`)).toHaveText("?");
          expect(await stateOf<boolean>(page, "s.round.map.edges.every((e) => e.w === 0) && s.round.showWeights === false")).toBe(true);
          await expect(page.getByTestId("coin-counter")).toHaveCount(0);
          const html = await page.content();
          expect(html).not.toMatch(/data-w=/);
          expect(await page.locator(".badge-text").allTextContents()).toEqual(map.edges.map(() => "?"));
        } else {
          await expect(page.getByTestId("coin-counter")).toContainText("0");
        }
        const route = solve(map);
        if (i === 0 && roundId === 1) {
          // ketukan tidak valid bergetar 300 ms; Batal berfungsi
          const far = map.nodes.find((n) => n.id !== map.start && !map.edges.some((e) => (e.a === map.start && e.b === n.id) || (e.b === map.start && e.a === n.id)));
          expect(far, "peta punya node yang tidak bertetangga dengan Rumah").toBeDefined();
          await watchShake(page, far?.id as NodeId);
          await node(page, far?.id as NodeId).click();
          await expectShake(page);
          expect(await visitedCount(page)).toBe(1);
          await node(page, route[1] as NodeId).click();
          expect(await visitedCount(page)).toBe(2);
          await page.getByTestId("undo").click();
          expect(await visitedCount(page)).toBe(1);
        }
        for (const id of route.slice(1)) await node(page, id).click();
        // pemain terakhir yang sampai langsung melihat layar berikutnya; yang lain melihat "Sudah sampai!"
        await expect(page.locator("[data-testid=round-arrived],[data-testid=probe-screen],[data-testid=result-screen]").first()).toBeVisible();
        if (hidden) {
          await expect(page.getByTestId("probe-screen")).toBeVisible({ timeout: 15_000 });
          const q = await stateOf<{ edgeId: string; options: number[] }>(page, "s.probe");
          const w = map.edges.find((e) => e.id === q.edgeId)?.w;
          await expect(page.getByTestId("probe-question")).toHaveText("Berapa koin di jalan ini?");
          await page.getByTestId(`probe-option-${w}`).click();
        }
        await expect(page.getByTestId("result-screen")).toBeVisible({ timeout: 20_000 });
        await expect(page.getByTestId("stars")).toHaveAttribute("data-stars", "3");
        await expect(page.getByTestId("round-points")).toContainText("poin");
        await expect(page.getByTestId("board-screen")).toBeVisible({ timeout: 20_000 });
        sawBoard.push(await page.getByTestId("rank-line").innerText());
      }),
    );
  }
  await waitApp(a, "PODIUM");
  await waitApp(b, "PODIUM");
  await expect(a.getByTestId("podium-screen")).toContainText("Hebat! Kamu sudah jadi kurir yang hemat.");
  expect(sawBoard.length).toBe(6);
  for (const line of sawBoard) expect(line).toMatch(/^Peringkatmu: #[12] · [\d.]+ poin$/);

  const rounds = readRounds(server.dataDir, host.sessionId);
  expect(rounds).toHaveLength(6);
  expect(rounds.every((r) => r.completed && r.optimalHit)).toBe(true);
  expect(rounds.filter((r) => r.condition === "HIDDEN").every((r) => r.probeCorrect === true)).toBe(true);
  host.close();
});

test("A5: halaman disembunyikan saat WALK → focusLost +1, flag FOCUS_LOST, poin tidak dikurangi", async ({ browser }) => {
  const { host, a, b } = await lobbyWith({ introMode: "SHORT", roundIds: [1], lookSeconds: 2, walkSeconds: 40 }, browser);
  autoSkip(host);
  await host.cmd("host:start");
  await Promise.all(
    [a, b].map(async (page) => {
      await waitApp(page, "WALK");
    }),
  );
  const map = await stateOf<MapDef>(a, "s.round.map");
  await a.evaluate(() => {
    Object.defineProperty(document, "visibilityState", { value: "hidden", configurable: true });
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await a.waitForTimeout(300);
  await a.evaluate(() => {
    Object.defineProperty(document, "visibilityState", { value: "visible", configurable: true });
    document.dispatchEvent(new Event("visibilitychange"));
  });
  await a.waitForTimeout(200);
  void map;
  await Promise.all([a, b].map(async (p) => walkRoute(p, solve(await stateOf<MapDef>(p, "s.round.map")))));
  await waitApp(a, "PODIUM");
  const rounds = readRounds(server.dataDir, host.sessionId);
  const ra = rounds.find((r) => r.studentId === "siswa-1") as RoundResult;
  const rb = rounds.find((r) => r.studentId === "siswa-2") as RoundResult;
  expect(ra.focusLost).toBe(1);
  expect(ra.integrityFlags).toContain("FOCUS_LOST");
  expect(rb.focusLost).toBe(0);
  expect(rb.integrityFlags).not.toContain("FOCUS_LOST");
  expect(ra.racePoints).toBeGreaterThan(0);
  expect(ra.racePoints).toBe(expected(ra));
  host.close();
});

test("A7: rute ≥ 3 langkah dikirim < 1000 ms → flag TOO_FAST, poin tetap dihitung normal", async ({ browser }) => {
  const { host, a, b } = await lobbyWith({ introMode: "SHORT", roundIds: [1], lookSeconds: 5, walkSeconds: 40 }, browser);
  autoSkip(host);
  await host.cmd("host:start");
  await Promise.all([a, b].map((p) => waitApp(p, "LOOK")));
  const map = await stateOf<MapDef>(a, "s.round.map");
  const path = longestSimplePath(map);
  expect(path.length - 1).toBeGreaterThanOrEqual(3);
  // dipasang saat LOOK: begitu WALK dimulai, seluruh rute diketuk dalam satu tarikan (tanpa menunggu polling tes)
  await a.evaluate((ids) => {
    const fire = (): void => {
      if (!document.querySelector(".app[data-phase=WALK]")) return void setTimeout(fire, 2);
      for (const id of ids) document.querySelector(`[data-testid="node-${id}"]`)?.dispatchEvent(new MouseEvent("click", { bubbles: true }));
    };
    fire();
  }, path.slice(1));
  await waitApp(a, "WALK");
  await expect(a.getByText("Sudah sampai! Menunggu teman…")).toBeVisible();
  await expect(a.getByTestId("arrived-coins")).toContainText("Total koin rutemu");
  await walkRoute(b, solve(await stateOf<MapDef>(b, "s.round.map")));
  await waitApp(a, "PODIUM");
  const ra = readRounds(server.dataDir, host.sessionId).find((r) => r.studentId === "siswa-1") as RoundResult;
  expect(ra.steps).toBeGreaterThanOrEqual(3);
  expect(ra.tRouteMs).toBeLessThan(1000);
  expect(ra.integrityFlags).toContain("TOO_FAST");
  expect(ra.racePoints).toBe(expected(ra));
  host.close();
});

test("sambung ulang: muat ulang halaman saat LOBBY dan saat WALK HIDDEN kembali ke keadaan yang sama tanpa angka", async ({ browser }) => {
  const { host, a, b } = await lobbyWith({ introMode: "SHORT", roundIds: [2], lookSeconds: 2, walkSeconds: 40 }, browser);
  autoSkip(host);
  await a.reload();
  await expect(a.getByTestId("ready-hello")).toHaveText("Halo, Ani!");
  await host.cmd("host:start");
  await Promise.all([a, b].map((p) => waitApp(p, "LOOK")));
  const map = await stateOf<MapDef>(a, "s.round.map");
  await waitApp(a, "WALK");
  await a.waitForTimeout(500);
  await a.reload();
  await expect(a.getByTestId("round-screen")).toHaveAttribute("data-phase", "WALK");
  for (const e of map.edges) await expect(a.getByTestId(`badge-${e.id}`)).toHaveText("?");
  expect(await stateOf<boolean>(a, "s.round.map.edges.every((e) => e.w === 0)")).toBe(true);
  expect(await stateOf<number>(a, "s.round.roundId")).toBe(2);
  await Promise.all([walkRoute(a, solve(map)), walkRoute(b, solve(await stateOf<MapDef>(b, "s.round.map")))]);
  await expect(a.locator("[data-testid=probe-screen],[data-testid=result-screen]")).toBeVisible({ timeout: 15_000 });
  host.close();
});

test("tutorial tidak selesai sampai batas waktu → demo otomatis memainkan langkah tersisa lalu ikut ronde pertama", async ({ browser }) => {
  test.setTimeout(300_000);
  const { host, a, b } = await lobbyWith({ introMode: "FULL", roundIds: [1], lookSeconds: 2, walkSeconds: 30 }, browser);
  autoSkip(host);
  await host.cmd("host:start");
  await waitApp(a, "TUTORIAL");
  await waitApp(b, "TUTORIAL");
  // keduanya diam; mendekati batas waktu demo otomatis berjalan sendiri
  await expect(a.locator("[data-testid=tutorial][data-step]").first()).toBeVisible();
  await waitApp(a, "LOOK", 150_000);
  await waitApp(b, "LOOK", 5000);
  await expect.poll(() => readTutorials(server.dataDir, host.sessionId).length, { timeout: 10_000 }).toBe(2);
  for (const t of readTutorials(server.dataDir, host.sessionId)) {
    expect(t.completed).toBe(false);
    expect(t.autoDemoSteps.length).toBeGreaterThanOrEqual(1);
  }
  host.close();
});
import { expect, test, type Page } from "@playwright/test";
import { SocketPlayer, startServer, waitUntil, type TestServer } from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

const NAMES = ["Ani Lestari", "Budi Santoso", "Citra Dewi"];

/** Membuka layar guru dan membuat sesi lewat formulir. */
async function createViaUi(page: Page, opts: { names?: string[]; intro?: "full" | "short"; rounds?: string; look?: string; walk?: string; mode?: "quick"; unique?: boolean } = {}): Promise<void> {
  await page.goto(`${server.url}/host`);
  await expect(page.getByTestId("host-create")).toBeVisible();
  await page.getByTestId("roster-input").fill((opts.names ?? NAMES).join("\n"));
  await expect(page.getByTestId("roster-count")).toHaveText(`${(opts.names ?? NAMES).length} siswa`);
  await page.getByTestId(opts.intro === "full" ? "intro-full" : "intro-short").check();
  if (opts.mode === "quick") await page.getByTestId("mode-quick").check();
  if (opts.unique === false) await page.getByTestId("set-unique").uncheck(); // bawaan layar guru: soal beda tiap siswa
  if (opts.rounds) await page.getByTestId("set-rounds").fill(opts.rounds);
  await page.getByTestId("set-look").fill(opts.look ?? "3");
  await page.getByTestId("set-walk").fill(opts.walk ?? "30");
  await page.getByTestId("create-btn").click();
  await expect(page.getByTestId("host-intro")).toBeVisible();
}

async function toLobby(page: Page): Promise<string> {
  await expect(page.getByTestId("host-pin")).toHaveCount(0); // kode belum tampil selama intro
  // Lewati intro harus ditahan 2 detik
  await page.getByTestId("skip-intro").hover();
  await page.mouse.down();
  await page.waitForTimeout(2300);
  await page.mouse.up();
  await expect(page.getByTestId("host-lobby")).toBeVisible();
  const pin = (await page.getByTestId("host-pin").innerText()).trim();
  expect(pin).toMatch(/^\d{6}$/);
  return pin;
}

test("lobi: kosong → 'Belum ada pemain'; jumlah, denah dan tombol Mulai mengikuti pemain nyata; sambung ulang", async ({ page }) => {
  await createViaUi(page);
  const pin = await toLobby(page);
  await expect(page.getByTestId("host-empty")).toHaveText("Belum ada pemain");
  await expect(page.getByTestId("host-count")).toHaveText("0/3 sudah masuk");
  await expect(page.getByTestId("start-btn")).toBeDisabled();
  await expect(page.getByTestId("start-why")).toHaveText("Menunggu 3 siswa lagi");
  await expect(page.getByTestId("host-seatmap")).toContainText("Proyektor / papan tulis");

  const a = new SocketPlayer(server.url, "siswa-1");
  const b = new SocketPlayer(server.url, "siswa-2");
  const c = new SocketPlayer(server.url, "siswa-3");
  await a.join(pin, { row: 0, col: 0 });
  await expect(page.getByTestId("host-count")).toHaveText("1/3 sudah masuk");
  await expect(page.getByTestId("host-empty")).toHaveCount(0);
  await expect(page.getByTestId("hseat-0-0")).toHaveText("AL");
  await b.join(pin, null);
  await expect(page.getByTestId("host-count")).toHaveText("2/3 sudah masuk");
  await expect(page.getByTestId("start-btn")).toBeDisabled();
  await c.join(pin, { row: 1, col: 2 });
  await expect(page.getByTestId("host-count")).toHaveText("3/3 sudah masuk");
  await expect(page.getByTestId("start-btn")).toBeDisabled();
  await expect(page.getByTestId("start-why")).toHaveText("1 siswa belum memilih kursi");
  expect((await b.ask("player:seat", { row: 0, col: 1 })).ok).toBe(true);
  await expect(page.getByTestId("hseat-0-1")).toHaveText("BS");
  await expect(page.getByTestId("start-btn")).toBeEnabled();

  // guru mengosongkan kursi dengan mengetuknya
  await page.getByTestId("hseat-0-1").click();
  await expect(page.getByTestId("hseat-0-1")).toHaveText("");
  await expect(page.getByTestId("start-btn")).toBeDisabled();
  expect((await b.ask("player:seat", { row: 0, col: 1 })).ok).toBe(true);
  await expect(page.getByTestId("start-btn")).toBeEnabled();

  // muat ulang: sesi pulih dengan kode dan jumlah yang sama
  await page.reload();
  await expect(page.getByTestId("host-pin")).toHaveText(pin);
  await expect(page.getByTestId("host-count")).toHaveText("3/3 sudah masuk");
  await expect(page.getByTestId("hseat-1-2")).toHaveText("CD");

  // pemain terputus tidak dihitung
  c.close();
  await expect(page.getByTestId("host-count")).toHaveText("2/3 sudah masuk");
  a.close();
  b.close();
});

test("pengaturan di lobi: ubah kuota dan denah; nilai tidak sah ditolak dengan pesan", async ({ page }) => {
  await createViaUi(page);
  const pin = await toLobby(page);
  await page.getByTestId("settings-toggle").click();
  await page.getByTestId("set-look").fill("1");
  await page.getByTestId("settings-apply").click();
  await expect(page.getByTestId("settings-error")).toBeVisible();
  await page.getByTestId("set-look").fill("8");
  await page.getByTestId("set-quota").fill("2");
  await page.getByTestId("set-rows").fill("2");
  await page.getByTestId("set-cols").fill("3");
  await page.getByTestId("set-aisle").fill("1");
  await page.getByTestId("settings-apply").click();
  await expect(page.getByTestId("settings-error")).toHaveCount(0);
  await expect(page.getByTestId("host-count")).toHaveText("0/2 sudah masuk");
  await expect(page.locator("[data-testid^=hseat-]")).toHaveCount(6);
  const a = new SocketPlayer(server.url, "siswa-1");
  const b = new SocketPlayer(server.url, "siswa-2");
  await a.join(pin, { row: 0, col: 0 });
  await b.join(pin, { row: 1, col: 1 });
  await expect(page.getByTestId("start-btn")).toBeEnabled(); // kuota 2 terpenuhi walau daftar 3 siswa
  a.close();
  b.close();
});

test("Lewati dan Akhiri meminta konfirmasi; Akhiri menutup sesi", async ({ page }) => {
  await createViaUi(page);
  const pin = await toLobby(page);
  const ps = [new SocketPlayer(server.url, "siswa-1"), new SocketPlayer(server.url, "siswa-2"), new SocketPlayer(server.url, "siswa-3")];
  for (const [i, p] of ps.entries()) await p.join(pin, { row: 0, col: i });
  await page.getByTestId("start-btn").click();
  await expect(page.locator(".host[data-phase=COUNTDOWN], .host[data-phase=LOOK]").first()).toBeVisible();
  await page.getByTestId("skip-btn").click();
  await expect(page.getByTestId("confirm")).toBeVisible();
  await page.getByTestId("confirm-no").click();
  await expect(page.getByTestId("confirm")).toHaveCount(0);
  await page.getByTestId("end-btn").click();
  await page.getByTestId("confirm-yes").click();
  await expect(page.getByTestId("host-ended")).toBeVisible();
  ps.forEach((p) => p.close());
});

test("sesi penuh: tutorial x/y siap, LOOK/WALK tanpa peta, x/y sudah sampai, 4 rute hemat, 5 besar, podium, tanda integritas tidak pernah tampil (A9)", async ({ page }) => {
  test.setTimeout(240_000);
  // empat soal setara pada ringkasan ronde hanya ada bila soal tidak dibedakan per siswa
  await createViaUi(page, { intro: "full", rounds: "1,2", look: "3", walk: "30", unique: false });
  const pin = await toLobby(page);
  const [a, b, c] = ["siswa-1", "siswa-2", "siswa-3"].map((id) => new SocketPlayer(server.url, id)) as [SocketPlayer, SocketPlayer, SocketPlayer];
  c.holdTutorial = true;
  for (const [i, p] of [a, b, c].entries()) await p.join(pin, { row: 0, col: i });

  // A9: rekam semua teks yang pernah tampil di layar proyektor
  await page.evaluate(() => {
    const w = window as unknown as { __seen: string[] };
    w.__seen = [];
    const snap = (): void => {
      w.__seen.push(document.body.innerText);
    };
    new MutationObserver(snap).observe(document.body, { childList: true, subtree: true, characterData: true });
    snap();
  });

  await page.getByTestId("start-btn").click();
  await expect(page.getByTestId("host-countdown")).toBeVisible();
  await expect(page.getByTestId("host-tutorial")).toBeVisible();
  await expect(page.getByTestId("host-ready")).toHaveText("2/3 siap");
  c.releaseTutorial();

  // ronde 1 (VISIBLE): peta tidak pernah ada di DOM host
  await expect(page.locator('.host[data-phase="LOOK"]')).toBeVisible();
  await expect(page.getByTestId("host-round-label")).toHaveText("Ronde 1 dari 2 · Angka tampil");
  expect(await page.locator('[data-testid="map"], [data-testid^="node-"], [data-testid^="badge-"], svg.mapview').count()).toBe(0);

  // gangguan yang menimbulkan tanda integritas (hanya untuk laporan guru)
  a.socket.emit("integrity:event", { type: "FOCUS_LOST", phase: "LOOK", roundId: 1, tMs: 100 });
  const second = new SocketPlayer(server.url, "siswa-2");
  await second.ask("player:join", { code: pin, studentToken: b.token }); // perangkat kedua: SECOND_DEVICE
  second.close();
  b.tapGapMs = 100; // TOO_FAST
  c.holdWalk = true;
  a.holdWalk = true;

  await expect(page.locator('.host[data-phase="WALK"]')).toBeVisible();
  expect(await page.locator('[data-testid="map"], [data-testid^="node-"], svg.mapview').count()).toBe(0);
  await expect(page.getByTestId("host-walk")).toHaveText("1/3 sudah sampai"); // b sudah mengirim otomatis
  a.holdWalk = false;
  a.submitWalk();
  await expect(page.getByTestId("host-walk")).toHaveText("2/3 sudah sampai");
  c.holdWalk = false;
  c.submitWalk();

  // RESULT: 4 gambar rute terhemat + persentase
  await expect(page.getByTestId("host-result")).toBeVisible();
  for (const slot of [0, 1, 2, 3]) await expect(page.getByTestId(`summary-${slot}`)).toBeVisible();
  await expect(page.getByTestId("host-pct")).toHaveText("100% kelas menemukan rute terhemat");
  await expect(page.getByTestId("summary-0").locator('[data-walked="1"]').first()).toBeVisible();

  // papan 5 besar (hanya 3 siswa → 3 baris)
  await expect(page.getByTestId("host-board")).toBeVisible({ timeout: 15_000 });
  await expect(page.getByTestId("board-0")).toBeVisible();
  await expect(page.locator('[data-testid^="board-"]')).toHaveCount(3);

  // ronde 2 (HIDDEN): tetap tanpa peta, ada soal ingatan
  await expect(page.locator('.host[data-phase="LOOK"]')).toBeVisible({ timeout: 15_000 });
  await expect(page.getByTestId("host-round-label")).toHaveText("Ronde 2 dari 2 · Angka akan hilang");
  expect(await page.locator('[data-testid="map"], svg.mapview').count()).toBe(0);
  c.holdWalk = true; // tahan satu siswa agar fase WALK tetap tampil
  c.holdProbe = true;
  await expect(page.locator('.host[data-phase="WALK"]')).toBeVisible();
  expect(await page.locator('[data-testid="map"], svg.mapview').count()).toBe(0);
  await expect(page.getByTestId("host-walk")).toHaveText("2/3 sudah sampai");
  c.holdWalk = false;
  c.submitWalk();
  await expect(page.locator('.host[data-phase="PROBE"]')).toBeVisible({ timeout: 20_000 });
  expect(await page.locator('[data-testid="map"], svg.mapview').count()).toBe(0);
  await expect(page.getByTestId("host-clock")).toBeVisible();
  c.releaseProbe();
  await expect(page.getByTestId("host-result")).toBeVisible({ timeout: 20_000 });
  await expect(page.getByTestId("host-board")).toBeVisible({ timeout: 15_000 });

  // podium 3 besar
  await expect(page.getByTestId("host-podium")).toBeVisible({ timeout: 15_000 });
  await expect(page.locator('[data-testid^="podium-"]')).toHaveCount(3);
  await expect(page.getByTestId("rejected-count")).toHaveText("Hasil ditolak: 0");
  // unduhan di podium: sesi dari layar guru berjenis LIVE (tanpa includeTest); CSV berawalan BOM dan memuat data nyata sesi
  // sesi masih berjalan: berkas hanya terbuka untuk pemegang token guru (tautan di layar mengambilnya dengan header)
  const hostToken = (await page.evaluate(() => (JSON.parse(localStorage.getItem("rr.host") ?? "{}") as { hostToken?: string }).hostToken)) ?? "";
  const asHost = { headers: { "x-host-token": hostToken } };
  for (const f of ["rounds.csv", "students.csv", "tutorial.csv", "items.csv", "report.html"]) {
    const href = await page.getByTestId(`dl-${f}`).getAttribute("href");
    expect(href).not.toContain("includeTest");
    expect((await page.request.get(`${server.url}${href}`)).status(), `${f} tanpa token`).toBe(401);
    const res = await page.request.get(`${server.url}${href}`, asHost);
    expect(res.status(), f).toBe(200);
    if (f.endsWith(".csv")) expect([...(await res.body()).subarray(0, 3)]).toEqual([0xef, 0xbb, 0xbf]);
  }
  const rounds = (await (await page.request.get(`${server.url}${await page.getByTestId("dl-rounds.csv").getAttribute("href")}`, asHost)).text()).trim().split(/\r?\n/);
  expect(rounds.length - 1).toBe(6); // 3 siswa × 2 ronde
  const report = await (await page.request.get(`${server.url}${await page.getByTestId("dl-report.html").getAttribute("href")}`, asHost)).text();
  expect(report).toMatch(/Catatan integritas: keluar aplikasi 1 kali saat ronde 1/); // flag hanya di laporan guru

  const seen = await page.evaluate(() => (window as unknown as { __seen: string[] }).__seen);
  const bad = seen.filter((t) => /FOCUS|TOO_FAST|SECOND_DEVICE|FULLSCREEN|SEAT_CHANGED|curang|mencurigakan|perangkat lain|integritas/i.test(t));
  expect(bad, "teks tanda integritas tidak boleh pernah tampil di proyektor").toEqual([]);
  expect(await page.content()).not.toMatch(/FOCUS_LOST|TOO_FAST|SECOND_DEVICE/);
  await waitUntil(() => true);
  [a, b, c].forEach((p) => p.close());
});
test("impor daftar siswa dari SIMPETERI: jendela pembuka mengirim daftar; pesan dari sumber lain diabaikan; id dan absen ikut ke sesi", async ({ page, context }) => {
  // `page` berperan sebagai halaman SIMPETERI: membuka layar guru lalu membalas "siap" dengan daftar kelas
  await page.goto(`${server.url}/health`);
  await page.evaluate(() => {
    window.addEventListener("message", (e) => {
      if ((e.data as { type?: string })?.type === "route-rush:host-ready")
        (e.source as Window).postMessage({ type: "route-rush:roster", kelas: "6C", roster: [{ id: "uuid-a", name: "Adnan Fahreza", kelas: "6C", absen: 1 }, { id: "uuid-b", name: "Adnan Sharif", kelas: "6C", absen: 2 }, { id: "uuid-c", name: "Budi Santoso", kelas: "6C", absen: 3 }] }, "*");
    });
    window.open(`${location.origin}/host?mute=1`, "_blank");
  });
  const host = await context.waitForEvent("page");
  await expect(host.getByTestId("imported-roster")).toContainText("Kelas 6C · 3 siswa");
  await expect(host.getByTestId("imported-2")).toContainText("Adnan Sharif");
  await expect(host.getByTestId("roster-input")).toHaveCount(0);

  // pesan yang bukan dari jendela pembuka (mis. disisipkan skrip lain di halaman) diabaikan
  await host.evaluate(() => window.dispatchEvent(new MessageEvent("message", { data: { type: "route-rush:roster", kelas: "X", roster: [{ id: "z", name: "Palsu" }] } })));
  await expect(host.getByTestId("imported-roster")).toContainText("Kelas 6C · 3 siswa");
  await expect(host.getByTestId("imported-roster")).not.toContainText("Palsu");

  await host.getByTestId("intro-short").check();
  await host.getByTestId("set-rounds").fill("1");
  await host.getByTestId("set-seats").uncheck();
  await expect(host.getByTestId("create-btn")).toBeEnabled();
  await host.getByTestId("create-btn").click();
  await host.getByTestId("skip-intro").hover();
  await host.mouse.down();
  await host.waitForTimeout(2300);
  await host.mouse.up();
  await expect(host.getByTestId("host-lobby")).toBeVisible();
  const pin = (await host.getByTestId("host-pin").innerText()).trim();
  const p = new SocketPlayer(server.url, "uuid-b"); // id dari SIMPETERI dipakai sebagai id siswa
  await p.join(pin, null);
  await expect(host.getByTestId("host-count")).toHaveText("1/3 sudah masuk");
  p.close();

  await host.getByTestId("end-btn").click();
  await host.getByTestId("confirm-yes").click();
  await host.reload();
  // muat ulang: jendela pembuka masih ada, jadi daftar kelas dikirim lagi; "Pakai daftar manual" mengembalikan kolom teks
  await expect(host.getByTestId("imported-roster")).toContainText("Kelas 6C · 3 siswa");
  await host.getByTestId("imported-clear").click();
  await expect(host.getByTestId("roster-input")).toBeVisible();
});
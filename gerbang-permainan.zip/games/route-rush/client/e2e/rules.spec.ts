import { expect, test } from "@playwright/test";
import { COPY } from "@route-rush/shared";
import { HostDriver, SocketPlayer, joinAs, startServer, waitApp, type TestServer } from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

test("Cara bermain di perangkat siswa: dibuka dari lobi, 6 kartu bergambar, bisa dibalik dan ditutup; juga tersedia saat latihan", async ({ browser }) => {
  const host = new HostDriver(server.url);
  await host.create({ introMode: "FULL", roundIds: [1], lookSeconds: 3, walkSeconds: 20 });
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const page = await (await browser.newContext()).newPage();
  await joinAs(page, server.url, host.code, "siswa-1", { row: 0, col: 0 });

  await page.getByTestId("help-btn").click();
  await expect(page.getByTestId("rules-sheet")).toBeVisible();
  for (const [i, text] of COPY.rules.entries()) {
    await expect(page.getByTestId("rule-text")).toHaveText(text);
    await expect(page.getByTestId("rule-text")).toHaveAttribute("data-index", String(i));
    if (i === 0) await expect(page.getByTestId("rules-prev")).toBeDisabled();
    if (i === 0 || i === 1) await expect(page.getByTestId("rules-sheet").locator('[data-testid="map"]')).toBeVisible(); // gambar contoh dari peta latihan
    if (i === 4) await expect(page.locator(".rule-stars")).toBeVisible();
    if (i < COPY.rules.length - 1) await page.getByTestId("rules-next").click();
  }
  await expect(page.getByTestId("rules-done")).toBeVisible();
  await page.getByTestId("rules-prev").click();
  await expect(page.getByTestId("rule-text")).toHaveText(COPY.rules[4] as string);
  await page.getByTestId("rules-next").click();
  await page.getByTestId("rules-done").click();
  await expect(page.getByTestId("rules-sheet")).toHaveCount(0);
  await expect(page.getByTestId("ready-screen")).toBeVisible();

  // aturan di dalam kartu angka hilang: peta contoh tanpa angka
  await page.getByTestId("help-btn").click();
  for (let i = 0; i < 5; i++) await page.getByTestId("rules-next").click();
  await expect(page.getByTestId("rule-text")).toHaveText(COPY.rules[5] as string);
  await expect(page.getByTestId("rules-sheet").locator(".badge-text").first()).toHaveText("?");
  await page.keyboard.press("Escape");
  await expect(page.getByTestId("rules-sheet")).toHaveCount(0);

  // tombol bantuan tidak ada saat ronde berjalan
  const bot = new SocketPlayer(server.url, "siswa-2");
  await bot.join(host.code, { row: 0, col: 1 });
  await host.cmd("host:start");
  await waitApp(page, "TUTORIAL");
  await expect(page.getByTestId("help-btn")).toBeVisible();
  await page.getByTestId("help-btn").click();
  await expect(page.getByTestId("rules-sheet")).toBeVisible();
  await page.getByTestId("rules-close").click();
  await expect(page.getByTestId("tutorial")).toBeVisible(); // latihan tetap berjalan di belakang lembar
  await host.cmd("host:skip");
  await waitApp(page, "LOOK");
  await expect(page.getByTestId("help-btn")).toHaveCount(0);
  bot.close();
  host.close();
});

test("Proyektor menampilkan kartu aturan bergambar selama latihan di perangkat siswa", async ({ page }) => {
  await page.setViewportSize({ width: 1280, height: 720 });
  await page.goto(`${server.url}/host?mute=1`);
  await page.getByTestId("roster-input").fill("Ani Lestari");
  await page.getByTestId("intro-full").check();
  await page.getByTestId("set-rounds").fill("1");
  await page.getByTestId("set-quota").fill("1");
  await page.getByTestId("set-seats").uncheck();
  await expect(page.getByTestId("create-btn")).toBeEnabled();
  await page.getByTestId("create-btn").click();
  await page.getByTestId("skip-intro").hover();
  await page.mouse.down();
  await page.waitForTimeout(2300);
  await page.mouse.up();
  await expect(page.getByTestId("host-lobby")).toBeVisible();
  const pin = (await page.getByTestId("host-pin").innerText()).trim();
  const p = new SocketPlayer(server.url, "siswa-1");
  p.holdTutorial = true;
  await p.join(pin, null);
  await page.getByTestId("start-btn").click();
  await expect(page.getByTestId("host-tutorial")).toBeVisible();
  await expect(page.getByTestId("rules-ticker")).toBeVisible();
  await page.getByTestId("skip-btn").hover();
  await expect(page.getByTestId("narration-status")).toHaveText(/^Narasi: dimatikan/);
  await expect(page.getByTestId("ticker-text")).toHaveText(COPY.rules[0] as string);
  await expect(page.getByTestId("ticker-text")).toHaveText(COPY.rules[1] as string, { timeout: 15_000 });
  p.close();
});
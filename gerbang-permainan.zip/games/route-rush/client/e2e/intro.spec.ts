import { expect, test, type Page } from "@playwright/test";
import { SocketPlayer, startServer, type TestServer } from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

test.use({ viewport: { width: 1280, height: 720 } });

type RR = { __rr: { host: { state: { phase: { phase: string; durationMs: number | null; introMode: string } | null; created: boolean; code: string | null }; subscribe(l: () => void): void }; introClock: { seek(ms: number): void; release(): void } } };

async function create(page: Page, intro: "full" | "short", extra: { rounds?: string } = {}): Promise<void> {
  await page.goto(`${server.url}/host?mute=1`);
  await page.getByTestId("roster-input").fill("Ani Lestari\nBudi Santoso");
  await page.getByTestId(intro === "full" ? "intro-full" : "intro-short").check();
  if (extra.rounds) await page.getByTestId("set-rounds").fill(extra.rounds);
  await expect(page.getByTestId("create-btn")).toBeEnabled(); // aset intro selesai dimuat
  await page.getByTestId("create-btn").click();
  await expect(page.getByTestId("host-intro")).toBeVisible();
}

const seek = (page: Page, ms: number) => page.evaluate((t) => (window as unknown as RR).__rr.introClock.seek(t), ms);

/** Menunggu fase INTRO_TRAILER (setelah ident 8 detik pada intro penuh). */
const waitTrailer = (page: Page) => expect(page.getByTestId("host-intro")).toHaveAttribute("data-kind", "TRAILER", { timeout: 20_000 });

test("pemuatan: tombol Buat sesi menunggu aset intro dimuat (bilah pemuatan)", async ({ page }) => {
  await page.goto(`${server.url}/host`);
  await expect(page.getByTestId("create-btn")).toBeDisabled();
  await page.getByTestId("roster-input").fill("Ani Lestari");
  await expect(page.getByTestId("create-btn")).toBeEnabled();
  await expect(page.getByTestId("intro-loading")).toHaveCount(0);
});

test("I9: intro penuh → ident → trailer → lobi → tutorial → ronde 1 (ronde 0 tidak muncul); subtitle dan angka trailer dihitung", async ({ page }) => {
  test.setTimeout(240_000);
  await create(page, "full", { rounds: "1" });
  await page.evaluate(() => {
    const w = window as unknown as RR & { __phases: string[] };
    const rr = w.__rr.host;
    w.__phases = rr.state.phase ? [rr.state.phase.phase] : [];
    rr.subscribe(() => {
      const p = rr.state.phase?.phase;
      if (p && w.__phases.at(-1) !== p) w.__phases.push(p);
    });
  });
  await expect(page.getByTestId("host-intro")).toHaveAttribute("data-kind", "IDENT");
  await waitTrailer(page);
  // kartu shot-05 memuat angka yang dihitung dari A-05, bukan diketik
  await seek(page, 20_000);
  await expect(page.getByTestId("intro-card")).toHaveText("9 vs 8");
  await seek(page, 10_000);
  await expect(page.getByTestId("intro-sub")).toHaveText("Setiap hari, ada paket yang harus diantar.");
  await seek(page, 25_000);
  await expect(page.getByTestId("intro-card")).toHaveText("INGAT!");
  await expect(page.getByTestId("intro-sub")).toHaveText("Dan kadang… angkanya menghilang.");
  await page.evaluate(() => (window as unknown as RR).__rr.introClock.release());

  await expect(page.getByTestId("host-lobby")).toBeVisible({ timeout: 60_000 });
  const pin = (await page.getByTestId("host-pin").innerText()).trim();
  const a = new SocketPlayer(server.url, "siswa-1");
  const b = new SocketPlayer(server.url, "siswa-2");
  await a.join(pin, null);
  await b.join(pin, null);
  await page.getByTestId("settings-toggle").click();
  await page.getByTestId("set-seats").uncheck();
  await page.getByTestId("settings-apply").click();
  await expect(page.getByTestId("start-btn")).toBeEnabled();
  await page.getByTestId("start-btn").click();
  await expect(page.locator('.host[data-phase="LOOK"]')).toBeVisible({ timeout: 30_000 });
  const phases = await page.evaluate(() => (window as unknown as { __phases: string[] }).__phases);
  expect(phases).toEqual(["INTRO_IDENT", "INTRO_TRAILER", "LOBBY", "COUNTDOWN", "TUTORIAL", "LOOK"]);
  await expect(page.getByTestId("host-round-label")).toHaveText("Ronde 1 dari 1 · Angka tampil");
  a.close();
  b.close();
});

test("I10: Lewati ditahan 2 detik menghentikan intro; ditekan sebentar tidak terjadi apa-apa", async ({ page }) => {
  await create(page, "short");
  const btn = page.getByTestId("skip-intro");
  await btn.hover();
  await page.mouse.down();
  await page.waitForTimeout(400);
  await page.mouse.up();
  await expect(page.getByTestId("host-intro")).toBeVisible();
  await expect(btn).toHaveAttribute("data-progress", "0.00");
  // tahan sampai 2 detik: berhasil
  await btn.hover();
  await page.mouse.down();
  await page.waitForTimeout(1000);
  await expect(page.getByTestId("host-intro")).toBeVisible(); // belum cukup
  await page.waitForTimeout(1300);
  await page.mouse.up();
  await expect(page.getByTestId("host-lobby")).toBeVisible();
  await expect(page.getByTestId("host-pin")).toHaveText(/^\d{6}$/);
});

test("intro ringkas: ident 3 detik lalu trailer 12 detik dari shot-04, 05, 08 dengan narasi singkat", async ({ page }) => {
  await create(page, "short");
  await expect(page.getByTestId("host-intro")).toHaveAttribute("data-kind", "IDENT");
  await waitTrailer(page);
  const dur = await page.evaluate(() => (window as unknown as RR).__rr.host.state.phase?.durationMs);
  expect(dur).toBe(12_000);
  await seek(page, 5000);
  await expect(page.getByTestId("host-intro")).toHaveAttribute("data-shot", "shot-05");
  await expect(page.getByTestId("intro-card")).toHaveText("9 vs 8");
  await expect(page.getByTestId("intro-sub")).toHaveText("Ingat, cari jalan paling hemat!");
  await seek(page, 9000);
  await expect(page.getByTestId("host-intro")).toHaveAttribute("data-shot", "shot-08");
  await seek(page, 100);
  await expect(page.getByTestId("host-intro")).toHaveAttribute("data-shot", "shot-04");
});

test.describe("I11: prefers-reduced-motion", () => {
  test.use({ contextOptions: { reducedMotion: "reduce" } });
  test("trailer menjadi 6 gambar diam, durasi tetap 45 detik, VO dan subtitle sama", async ({ page }) => {
    await create(page, "full");
    await waitTrailer(page);
    const info = await page.evaluate(() => (window as unknown as RR).__rr.host.state.phase?.durationMs);
    expect(info).toBe(45_000);
    const seen = new Set<string>();
    for (let t = 0; t < 45_000; t += 1000) {
      await seek(page, t);
      await expect(page.getByTestId("host-intro")).toHaveAttribute("data-t", String(t));
      seen.add((await page.getByTestId("host-intro").getAttribute("data-still")) ?? "?");
    }
    expect([...seen].sort()).toEqual(["shot-02", "shot-04", "shot-05", "shot-06", "shot-08", "shot-09"]);
    // tidak ada animasi CSS/WAAPI yang berjalan, dan subtitle tetap mengikuti narasi
    expect(await page.evaluate(() => document.getAnimations().length)).toBe(0);
    await seek(page, 14_000);
    await expect(page.getByTestId("intro-sub")).toHaveText("Tapi setiap jalan ada harganya.");
    await expect(page.getByTestId("host-intro")).toHaveAttribute("data-still", "shot-04");
    await page.evaluate(() => (window as unknown as RR).__rr.introClock.release());
  });
});

test("I12: gambar trailer pada detik 5, 15, 20, 25, dan 35 (jam terkendali) cocok dengan gambar acuan", async ({ page }) => {
  await create(page, "full");
  await waitTrailer(page);
  for (const s of [5, 15, 20, 25, 35]) {
    await seek(page, s * 1000);
    await expect(page.getByTestId("host-intro")).toHaveAttribute("data-t", String(s * 1000));
    await expect(page.locator(".intro-frame")).toHaveScreenshot(`trailer-${s}s.png`, { maxDiffPixelRatio: 0.002 });
  }
  await page.evaluate(() => (window as unknown as RR).__rr.introClock.release());
});

test("I13: tidak ada elemen yang berganti opasitas lebih dari 3 kali per detik; < 500 elemen SVG; tanpa filter", async ({ page }) => {
  test.setTimeout(240_000);
  await create(page, "full");

  const sweep = (from: number, to: number, step: number) =>
    page.evaluate(
      async ({ from: f, to: tt, step: st }) => {
        const clock = (window as unknown as RR).__rr.introClock;
        const series = new Map<Element, { t: number; v: number }[]>();
        let maxEls = 0;
        let filters = 0;
        for (let t = f; t < tt; t += st) {
          clock.seek(t);
          await new Promise<void>((r) => requestAnimationFrame(() => requestAnimationFrame(() => r())));
          const els = document.querySelectorAll(".intro-svg *");
          maxEls = Math.max(maxEls, els.length);
          for (const el of els) {
            if (el.hasAttribute("filter") || (el as HTMLElement).style?.filter) filters++;
            const raw = el.getAttribute("opacity");
            if (raw === null) continue;
            const v = Number(raw);
            const arr = series.get(el) ?? [];
            arr.push({ t, v });
            series.set(el, arr);
          }
        }
        // satu "kedipan" = satu balikan arah opasitas dengan ayunan ≥ 0,3; kedipan penuh = 2 balikan
        let worst = 0;
        for (const arr of series.values()) {
          const flips: number[] = [];
          let dir = 0;
          let anchor = arr[0]?.v ?? 0;
          for (const { t, v } of arr) {
            if (dir >= 0 && v - anchor <= -0.3) {
              if (dir === 1) flips.push(t);
              dir = -1;
              anchor = v;
            } else if (dir <= 0 && v - anchor >= 0.3) {
              if (dir === -1) flips.push(t);
              dir = 1;
              anchor = v;
            } else if ((dir === 1 && v > anchor) || (dir === -1 && v < anchor)) anchor = v;
            else if (dir === 0) anchor = v;
          }
          for (const t0 of flips) worst = Math.max(worst, flips.filter((x) => x >= t0 && x < t0 + 1000).length);
        }
        return { maxEls, filters, worstFlipsPerSecond: worst };
      },
      { from, to, step },
    );

  const ident = await sweep(0, 7960, 40);
  expect(ident.maxEls).toBeLessThan(500);
  expect(ident.filters).toBe(0);
  expect(ident.worstFlipsPerSecond / 2).toBeLessThanOrEqual(3);
  await page.evaluate(() => (window as unknown as RR).__rr.introClock.release());
  await waitTrailer(page);
  const trailer = await sweep(0, 44_960, 40);
  expect(trailer.maxEls).toBeLessThan(500);
  expect(trailer.filters).toBe(0);
  expect(trailer.worstFlipsPerSecond / 2).toBeLessThanOrEqual(3);
  test.info().annotations.push({ type: "flicker", description: `ident ${ident.worstFlipsPerSecond / 2}/s, trailer ${trailer.worstFlipsPerSecond / 2}/s, elemen maks ${Math.max(ident.maxEls, trailer.maxEls)}` });
});

test("kinerja: trailer berjalan mendekati 60 fps dengan CPU diperlambat 4×", async ({ page, context }) => {
  test.setTimeout(120_000);
  await create(page, "full");
  await waitTrailer(page);
  const cdp = await context.newCDPSession(page);
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 4 });
  // bagian terberat: shot-04 (peta + kota) sampai shot-07; jam otomatis dari server
  const stats = await page.evaluate(
    () =>
      new Promise<{ frames: number; avgMs: number; p95Ms: number; over33: number }>((resolve) => {
        const ts: number[] = [];
        const t0 = performance.now();
        const loop = (now: number): void => {
          ts.push(now);
          if (now - t0 < 8000) requestAnimationFrame(loop);
          else {
            const d = ts.slice(1).map((x, i) => x - (ts[i] as number));
            const sorted = [...d].sort((a, b) => a - b);
            resolve({ frames: ts.length, avgMs: d.reduce((a, b) => a + b, 0) / d.length, p95Ms: sorted[Math.floor(sorted.length * 0.95)] as number, over33: d.filter((x) => x > 33.4).length });
          }
        };
        requestAnimationFrame(loop);
      }),
  );
  await cdp.send("Emulation.setCPUThrottlingRate", { rate: 1 });
  test.info().annotations.push({ type: "fps", description: JSON.stringify(stats) });
  console.log("FPS dengan CPU 4×:", JSON.stringify(stats));
  expect(1000 / stats.avgMs).toBeGreaterThan(50);
  expect(stats.over33 / stats.frames).toBeLessThan(0.08);
});

test("suara: campuran ident dan trailer diputar dari posisi waktu fase; tombol Suara mematikan", async ({ page }) => {
  test.setTimeout(120_000);
  type Audio = { __rr: { introAudio: { muted: boolean; ready: boolean; started: { key: string; offsetMs: number }[] } } };
  await page.goto(`${server.url}/host?mute=1`);
  await page.evaluate(() => {
    (window as unknown as Audio).__rr.introAudio.muted = false; // uji otomatis biasanya senyap
  });
  await page.getByTestId("roster-input").fill("Ani Lestari");
  await page.getByTestId("intro-full").check();
  await expect(page.getByTestId("create-btn")).toBeEnabled();
  await expect.poll(() => page.evaluate(() => (window as unknown as Audio).__rr.introAudio.ready)).toBe(true);
  await page.getByTestId("create-btn").click();
  await expect(page.getByTestId("host-intro")).toBeVisible();
  await expect.poll(() => page.evaluate(() => (window as unknown as Audio).__rr.introAudio.started.length)).toBeGreaterThanOrEqual(1);
  const first = await page.evaluate(() => (window as unknown as Audio).__rr.introAudio.started[0]);
  expect(first?.key).toBe("IDENT_FULL");
  expect(first?.offsetMs).toBeLessThan(2500);
  await waitTrailer(page);
  const all = await page.evaluate(() => (window as unknown as Audio).__rr.introAudio.started);
  const trailer = all.find((s) => s.key === "TRAILER_FULL");
  expect(trailer, JSON.stringify(all)).toBeDefined();
  expect(trailer?.offsetMs).toBeLessThan(2500);
  await expect(page.getByTestId("sound-toggle")).toHaveText("Suara: nyala");
  await page.getByTestId("sound-toggle").hover();
  await page.getByTestId("sound-toggle").click();
  await expect(page.getByTestId("sound-toggle")).toHaveText("Suara: mati");
  expect(await page.evaluate(() => (window as unknown as Audio).__rr.introAudio.muted)).toBe(true);
});
import { expect, test, type Page } from "@playwright/test";
import { SocketPlayer, longestSimplePath, startServer, waitUntil, type TestServer } from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

type RR = { __rr: { introAudio: { muted: boolean; ready: boolean }; answerAudio: { names: string[]; played: { kind: string; clip?: number; student?: string }[]; setNames(l: string[]): void } } };

async function startHost(page: Page, resultSeconds: string): Promise<string> {
  await page.goto(`${server.url}/host?mute=1`);
  await page.evaluate(() => {
    const a = (window as unknown as RR).__rr;
    a.introAudio.muted = false; // uji otomatis biasanya senyap
    a.answerAudio.setNames(["Ani Lestari", "Budi Santoso"]); // klip 01 dan 02 (daftar uji; daftar asli ada di assets/audio/names/names.txt)
  });
  await page.getByTestId("roster-input").fill("Ani Lestari\nBudi Santoso");
  await page.getByTestId("intro-short").check();
  await page.getByTestId("set-rounds").fill("1");
  await page.getByTestId("set-look").fill("6");
  await page.getByTestId("set-result").fill(resultSeconds);
  await page.getByTestId("set-seats").uncheck();
  await expect(page.getByTestId("create-btn")).toBeEnabled();
  await expect.poll(() => page.evaluate(() => (window as unknown as RR).__rr.introAudio.ready)).toBe(true);
  await page.getByTestId("create-btn").click();
  await page.getByTestId("skip-intro").hover();
  await page.mouse.down();
  await page.waitForTimeout(2300);
  await page.mouse.up();
  await expect(page.getByTestId("host-lobby")).toBeVisible();
  return (await page.getByTestId("host-pin").innerText()).trim();
}

const played = (page: Page) => page.evaluate(() => (window as unknown as RR).__rr.answerAudio.played);

test("hasil ronde: bunyi benar lalu nama siswa tercepat yang benar (klip 02 sebelum 01); nama tidak tampil di layar", async ({ page }) => {
  test.setTimeout(120_000);
  const pin = await startHost(page, "20");
  const a = new SocketPlayer(server.url, "siswa-1"); // Ani: lambat
  const b = new SocketPlayer(server.url, "siswa-2"); // Budi: cepat
  a.tapGapMs = 900;
  b.tapGapMs = 500;
  await a.join(pin, null);
  await b.join(pin, null);
  await page.getByTestId("start-btn").click();
  await expect(page.getByTestId("host-result")).toBeVisible({ timeout: 60_000 });
  await waitUntil(() => true);
  await expect.poll(async () => (await played(page)).length, { timeout: 30_000 }).toBe(3);
  const steps = await played(page);
  expect(steps.map((s) => s.kind)).toEqual(["correct", "name", "name"]);
  expect(steps.slice(1).map((s) => s.clip)).toEqual([1, 0]); // Budi (klip 02) lebih cepat daripada Ani (klip 01)
  expect(steps.slice(1).map((s) => s.student)).toEqual(["Budi Santoso", "Ani Lestari"]);
  const text = await page.getByTestId("host-result").innerText();
  expect(text).not.toMatch(/Budi|Ani/);
  a.close();
  b.close();
});

test("tidak ada yang menemukan rute terhemat: hanya bunyi salah", async ({ page }) => {
  test.setTimeout(120_000);
  const pin = await startHost(page, "6");
  const a = new SocketPlayer(server.url, "siswa-1");
  const b = new SocketPlayer(server.url, "siswa-2");
  await a.join(pin, null);
  await b.join(pin, null);
  await page.getByTestId("start-btn").click();
  for (const p of [a, b]) {
    await waitUntil(() => p.map !== null, 30_000, "peta ronde");
    p.route = longestSimplePath(p.map!);
  }
  await expect(page.getByTestId("host-result")).toBeVisible({ timeout: 60_000 });
  await expect.poll(async () => (await played(page)).length, { timeout: 15_000 }).toBe(1);
  expect((await played(page))[0]).toEqual({ kind: "wrong" });
  a.close();
  b.close();
});

test("pengumuman berhenti begitu ronde berikutnya mulai; nama tanpa klip tidak disebut", async ({ page }) => {
  test.setTimeout(120_000);
  const pin = await startHost(page, "3");
  await page.evaluate(() => (window as unknown as RR).__rr.answerAudio.setNames(["Budi Santoso"])); // Ani tidak punya klip
  const a = new SocketPlayer(server.url, "siswa-1");
  const b = new SocketPlayer(server.url, "siswa-2");
  await a.join(pin, null);
  await b.join(pin, null);
  await page.getByTestId("start-btn").click();
  await expect(page.getByTestId("host-result")).toBeVisible({ timeout: 60_000 });
  await expect.poll(async () => (await played(page)).length, { timeout: 15_000 }).toBeGreaterThanOrEqual(2);
  const steps = await played(page);
  expect(steps.filter((s) => s.kind === "name").map((s) => s.student)).toEqual(["Budi Santoso"]);
  a.close();
  b.close();
});
import { expect, test } from "@playwright/test";
import { HostDriver, joinAs, startServer, waitApp, type TestServer } from "./support";

let server: TestServer;
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

/** Merekam setiap kata READY dan kemunculan "GO!" di halaman (tanpa bergantung pada kecepatan polling tes). */
async function recordReady(page: import("@playwright/test").Page): Promise<void> {
  await page.evaluate(() => {
    const w = window as unknown as { __words: { t: number; text: string }[]; __go: { t: number; text: string; hint: string }[] };
    w.__words = [];
    w.__go = [];
    const el = document.querySelector("[data-testid=ready-word]") as HTMLElement;
    new MutationObserver(() => w.__words.push({ t: performance.now(), text: el.textContent ?? "" })).observe(el, { childList: true, characterData: true, subtree: true });
    const rr = (window as unknown as { __rr: { game: { state: { phase: { phase: string } | null }; subscribe(l: () => void): void } } }).__rr;
    const ww = w as unknown as { __countdownAt: number | null; __phaseAt: Record<string, number> };
    ww.__countdownAt = null;
    ww.__phaseAt = {};
    rr.game.subscribe(() => {
      const ph = rr.game.state.phase?.phase;
      if (ph === "COUNTDOWN" && ww.__countdownAt === null) ww.__countdownAt = performance.now();
      if (ph && ww.__phaseAt[ph] === undefined) ww.__phaseAt[ph] = performance.now();
    });
    new MutationObserver(() => {
      const go = document.querySelector(".go-layer [data-testid=ready-word]");
      if (go && !w.__go.some((g) => performance.now() - g.t < 400)) w.__go.push({ t: performance.now(), text: go.textContent ?? "", hint: document.querySelector(".go-layer [data-testid=ready-hint]")?.textContent ?? "" });
    }).observe(document.body, { childList: true, subtree: true, characterData: true });
  });
}

const readWords = (page: import("@playwright/test").Page) =>
  page.evaluate(() => {
    const w = window as unknown as { __words: { t: number; text: string }[]; __go: { t: number; text: string; hint: string }[] };
    const ww = w as unknown as { __countdownAt: number | null; __phaseAt: Record<string, number> };
    return { words: w.__words, go: w.__go, countdownAt: ww.__countdownAt, phaseAt: ww.__phaseAt };
  });

async function newSession(settings: Record<string, unknown> = {}): Promise<HostDriver> {
  const host = new HostDriver(server.url);
  await host.create({ introMode: "FULL", roundIds: [1], lookSeconds: 2, walkSeconds: 20, ...settings });
  return host;
}

test("I16: PIN baru dipakai setelah intro; layar READY tampil dengan nama dari server dan tanpa peta yang bisa diketuk", async ({ page }) => {
  const host = await newSession();
  await page.goto(server.url);
  for (const d of host.code) await page.getByTestId(`key-${d}`).click();
  await page.getByTestId("pin-go").click();
  await expect(page.getByTestId("error")).toContainText("Intro belum selesai");
  await expect(page.getByTestId("pin-screen")).toBeVisible();

  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  for (const d of host.code) await page.getByTestId(`key-${d}`).click();
  await page.getByTestId("pin-go").click();
  await expect(page.getByTestId("name-screen")).toBeVisible();
  await page.getByTestId("name-siswa-1").click();
  await page.getByTestId("seat-0-0").click();
  await page.getByTestId("seat-confirm").click();

  const ready = page.getByTestId("ready-screen");
  await expect(ready).toBeVisible();
  await expect(page.getByTestId("ready-hello")).toHaveText("Halo, Ani!");
  await expect(page.getByTestId("ready-word")).toHaveText("READY");
  await expect(page.getByTestId("ready-hint")).toHaveText("Lihat ke layar depan");
  await expect(page.getByTestId("map")).toHaveCount(0);
  await expect(page.locator("[data-testid^=node-]")).toHaveCount(0);
  host.close();
});

test("A1: kursi yang sama dipilih dua siswa → siswa kedua mendapat SEAT_TAKEN, kursi terisi abu-abu dengan inisial", async ({ browser }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });

  await b.goto(server.url);
  for (const d of host.code) await b.getByTestId(`key-${d}`).click();
  await b.getByTestId("pin-go").click();
  await b.getByTestId("name-siswa-2").click();
  await expect(b.getByText("Proyektor / papan tulis")).toBeVisible();
  const taken = b.getByTestId("seat-0-0");
  await expect(taken).toBeDisabled();
  await expect(taken).toHaveText("AL");
  // balapan: peta kursi lama masih terbuka, ketuk kursi itu lewat protokol
  const ok = await b.evaluate(() => (window as unknown as { __rr: { game: { takeSeat(r: number, c: number): Promise<boolean> } } }).__rr.game.takeSeat(0, 0));
  expect(ok).toBe(false);
  await expect(b.getByTestId("error")).toHaveText("Kursi ini sudah dipakai teman");
  await b.getByTestId("seat-0-1").click();
  await b.getByTestId("seat-confirm").click();
  await expect(b.getByTestId("ready-screen")).toBeVisible();
  host.close();
});

test("I17: hitung mundur 3 muncul saat fase dimulai, GO! saat fase berganti; Lewati memunculkan GO! ≤ 600 ms", async ({ browser }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
  await joinAs(b, server.url, host.code, "siswa-2", { row: 0, col: 1 });

  await a.bringToFront();
  await recordReady(a);
  expect((await host.cmd("host:start")).ok).toBe(true);
  await waitApp(a, "TUTORIAL");
  const { words, go, countdownAt } = await readWords(a);
  // angka 3 muncul ≤ 250 ms setelah perangkat menerima fase COUNTDOWN (sisa 3000 ms menurut server)
  const first3 = words.find((w) => w.text === "3");
  expect(first3).toBeDefined();
  expect((first3?.t ?? 0) - (countdownAt ?? 0)).toBeLessThan(250);
  expect(go[0]?.text).toBe("GO!");
  expect(go[0]?.hint).toBe("Tutorial dimulai");
  // angka diturunkan dari sisa waktu, jadi urutannya selalu menurun (pada mesin yang sangat lambat sebuah angka boleh terlewat)
  const digits = words.map((w) => w.text).filter((x) => /^[123]$/.test(x)).filter((x, i, all) => all[i - 1] !== x);
  expect(digits[0]).toBe("3");
  expect([...digits].sort((x, y) => Number(y) - Number(x))).toEqual(digits);
  if (digits.includes("2")) {
    const gap = (words.find((w) => w.text === "2")?.t ?? 0) - (words.find((w) => w.text === "3")?.t ?? 0);
    expect(gap).toBeGreaterThan(700);
    expect(gap).toBeLessThan(1400);
  }

  host.close();
});

test("I17b: Lewati di host saat hitung mundur memunculkan GO! dalam 600 ms", async ({ browser }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
  await joinAs(b, server.url, host.code, "siswa-2", { row: 0, col: 1 });
  await a.bringToFront();
  await recordReady(a);
  await host.cmd("host:start");
  await expect(a.getByTestId("ready-word")).toHaveText("3");
  await host.cmd("host:skip");
  await waitApp(a, "TUTORIAL");
  const { go, phaseAt } = await readWords(a);
  expect(go[0]?.text).toBe("GO!");
  // GO! muncul ≤ 600 ms sejak perangkat menerima fase berikutnya
  expect((go[0]?.t ?? 0) - (phaseAt["TUTORIAL"] ?? 0)).toBeLessThan(600);
  host.close();
});

test("I18: kedipan READY tidak mengubah kecerahan latar dan selang antar-burst ≥ 2400 ms", async ({ browser }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
  const bg0 = await a.locator(".ready").evaluate((el) => getComputedStyle(el).backgroundImage);
  const stamps = await a.evaluate(
    () =>
      new Promise<number[]>((resolve) => {
        const out: number[] = [];
        const el = document.querySelector("[data-testid=ready-word]") as HTMLElement;
        const mo = new MutationObserver(() => {
          if (el.classList.contains("burst") && out[out.length - 1] !== Math.round(performance.now()) ) {
            const last = out[out.length - 1];
            if (last === undefined || performance.now() - last > 500) out.push(performance.now());
          }
        });
        mo.observe(el, { attributes: true, attributeFilter: ["class"] });
        setTimeout(() => {
          mo.disconnect();
          resolve(out);
        }, 14_000);
      }),
  );
  const bg1 = await a.locator(".ready").evaluate((el) => getComputedStyle(el).backgroundImage);
  expect(bg1).toBe(bg0);
  expect(stamps.length).toBeGreaterThanOrEqual(2);
  for (let i = 1; i < stamps.length; i++) expect((stamps[i] as number) - (stamps[i - 1] as number)).toBeGreaterThanOrEqual(2400 - 150);
  host.close();
});

test.describe("I19: prefers-reduced-motion", () => {
  test.use({ contextOptions: { reducedMotion: "reduce" } });
  test("tidak ada burst dan animasi peta; hitung mundur tetap berjalan", async ({ browser }) => {
    const host = await newSession();
    await host.cmd("host:skipIntro");
    await host.waitPhase("LOBBY");
    const ctx = await browser.newContext({ reducedMotion: "reduce" });
    const a = await ctx.newPage();
    await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
    const bursts = await a.evaluate(
      () =>
        new Promise<number>((resolve) => {
          let n = 0;
          const el = document.querySelector("[data-testid=ready-word]") as HTMLElement;
          const mo = new MutationObserver(() => {
            if (el.classList.contains("burst")) n++;
          });
          mo.observe(el, { attributes: true, attributeFilter: ["class"] });
          setTimeout(() => {
            mo.disconnect();
            resolve(n);
          }, 6000);
        }),
    );
    expect(bursts).toBe(0);
    expect(await a.locator(".ready-map .lit").evaluate((el) => getComputedStyle(el).animationName)).toBe("none");
    const b = await (await browser.newContext({ reducedMotion: "reduce" })).newPage();
    await joinAs(b, server.url, host.code, "siswa-2", { row: 0, col: 1 });
    await a.bringToFront();
    await recordReady(a);
    await host.cmd("host:start");
    await waitApp(a, "TUTORIAL");
    const { words } = await readWords(a);
    const digits = words.map((w) => w.text).filter((x) => /^[123]$/.test(x)).filter((x, i, all) => all[i - 1] !== x);
    expect(digits[0]).toBe("3");
    expect(digits.length).toBeGreaterThanOrEqual(2);
    expect([...digits].sort((x, y) => Number(y) - Number(x))).toEqual(digits);
    host.close();
  });
});

test("keadaan kosong dan sambung ulang: nama tidak ditemukan, koneksi terputus lalu pulih tanpa memilih nama lagi", async ({ page }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  await page.goto(server.url);
  for (const d of host.code) await page.getByTestId(`key-${d}`).click();
  await page.getByTestId("pin-go").click();
  await page.getByTestId("name-search").fill("zzz");
  await expect(page.getByText("Tidak ada nama yang cocok.")).toBeVisible();
  await page.getByTestId("name-search").fill("budi");
  await expect(page.getByTestId("name-siswa-2")).toBeVisible();
  await expect(page.getByTestId("name-siswa-1")).toHaveCount(0);
  await page.getByTestId("name-siswa-2").click();
  await page.getByTestId("seat-1-1").click();
  await page.getByTestId("seat-confirm").click();
  await expect(page.getByTestId("ready-hello")).toHaveText("Halo, Budi!");

  await page.evaluate(() => (window as unknown as { __rr: { game: { socket: { disconnect(): void } } } }).__rr.game.socket.disconnect());
  await expect(page.getByTestId("offline")).toHaveText("Terputus. Menyambungkan kembali…");
  await page.evaluate(() => (window as unknown as { __rr: { game: { socket: { connect(): void } } } }).__rr.game.socket.connect());
  await expect(page.getByTestId("offline")).toHaveCount(0);
  await expect(page.getByTestId("ready-hello")).toHaveText("Halo, Budi!");
  host.close();
});

test("nama yang sudah dipilih teman tidak bisa dipilih lagi (perangkat kedua)", async ({ browser }) => {
  const host = await newSession();
  await host.cmd("host:skipIntro");
  await host.waitPhase("LOBBY");
  const a = await (await browser.newContext()).newPage();
  const b = await (await browser.newContext()).newPage();
  await joinAs(a, server.url, host.code, "siswa-1", { row: 0, col: 0 });
  await b.goto(server.url);
  for (const d of host.code) await b.getByTestId(`key-${d}`).click();
  await b.getByTestId("pin-go").click();
  await expect(b.getByTestId("name-siswa-1")).toBeDisabled();
  await expect(b.getByTestId("name-siswa-1")).toContainText("sudah dipakai");
  host.close();
});
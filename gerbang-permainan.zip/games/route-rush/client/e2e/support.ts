import { spawn, type ChildProcess } from "node:child_process";
import { existsSync, mkdtempSync, readdirSync, readFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { expect, type Page } from "@playwright/test";
import { io, type Socket } from "socket.io-client";
import { optimalRoute, type MapDef, type NodeId, type RoundResult, type TutorialResult } from "@route-rush/shared";

const here = dirname(fileURLToPath(import.meta.url));
const root = resolve(here, "../..");

export interface TestServer {
  url: string;
  dataDir: string;
  stop(): Promise<void>;
}

/** Menjalankan server sungguhan (NODE_ENV=test, jam nyata) beserta client hasil build yang disajikannya. */
export async function startServer(): Promise<TestServer> {
  const dataDir = mkdtempSync(join(tmpdir(), "rr-e2e-"));
  const tsx = join(root, "node_modules", "tsx", "dist", "cli.mjs");
  const child: ChildProcess = spawn(process.execPath, [tsx, join(root, "server", "src", "main.ts")], {
    cwd: root,
    env: { ...process.env, PORT: "0", NODE_ENV: "test", DATA_DIR: dataDir },
    stdio: ["ignore", "pipe", "pipe"],
  });
  const port = await new Promise<number>((resolvePort, reject) => {
    const timer = setTimeout(() => reject(new Error("server tidak menyala dalam 90 detik")), 90_000);
    let buf = "";
    child.stdout?.on("data", (d: Buffer) => {
      buf += d.toString();
      const m = /port (\d+)/.exec(buf);
      if (m) {
        clearTimeout(timer);
        resolvePort(Number(m[1]));
      }
    });
    child.stderr?.on("data", (d: Buffer) => process.stderr.write(d));
    child.on("exit", (code) => reject(new Error(`server berhenti (${code})`)));
  });
  return {
    url: `http://127.0.0.1:${port}`,
    dataDir,
    stop: () =>
      new Promise((done) => {
        child.removeAllListeners("exit");
        child.once("exit", () => done());
        child.kill();
        setTimeout(done, 3000);
      }),
  };
}

export const ROSTER = [
  { id: "siswa-1", name: "Ani Lestari", kelas: "6C" },
  { id: "siswa-2", name: "Budi Santoso", kelas: "6C" },
];

export type Ack = { ok: boolean; error?: string; [k: string]: unknown };

/** Perangkat guru tiruan: membuat sesi dan menggerakkan fase lewat protokol yang sama dengan layar host. */
export class HostDriver {
  readonly socket: Socket;
  sessionId = "";
  code = "";
  hostToken = "";
  phase = "";
  readonly phases: { phase: string; at: number }[] = [];

  constructor(url: string) {
    this.socket = io(url, { transports: ["websocket"], forceNew: true });
    this.socket.on("phase", (p: { phase: string }) => {
      this.phase = p.phase;
      this.phases.push({ phase: p.phase, at: Date.now() });
    });
  }

  ask(event: string, payload: Record<string, unknown> = {}): Promise<Ack> {
    return new Promise((res, rej) => {
      this.socket.timeout(5000).emit(event, payload, (err: Error | null, r: Ack) => (err ? rej(err) : res(r)));
    });
  }

  async create(settings: Record<string, unknown>, roster: typeof ROSTER = ROSTER): Promise<void> {
    await new Promise<void>((res) => (this.socket.connected ? res() : this.socket.once("connect", () => res())));
    const r = await this.ask("host:create", { roster, settings: { kind: "TEST", ...settings } });
    expect(r.ok, JSON.stringify(r)).toBe(true);
    this.sessionId = r.sessionId as string;
    this.code = r.code as string;
    this.hostToken = r.hostToken as string;
  }

  cmd(event: "host:skipIntro" | "host:start" | "host:skip" | "host:end"): Promise<Ack> {
    return this.ask(event, { sessionId: this.sessionId, hostToken: this.hostToken });
  }

  async waitPhase(name: string, ms = 30_000): Promise<void> {
    const until = Date.now() + ms;
    while (this.phase !== name) {
      if (Date.now() > until) throw new Error(`menunggu fase ${name}, terakhir ${this.phase}`);
      await new Promise((r) => setTimeout(r, 20));
    }
  }

  close(): void {
    this.socket.close();
  }
}

/** Semua RoundResult yang tersimpan di berkas jsonl sesi uji. */
export function readRounds(dataDir: string, sessionId: string): RoundResult[] {
  const dir = join(dataDir, "test-sessions");
  if (!existsSync(dir)) return [];
  const out: RoundResult[] = [];
  for (const f of readdirSync(dir).filter((n) => n.includes(sessionId))) {
    for (const line of readFileSync(join(dir, f), "utf8").split(/\r?\n/)) {
      if (!line.trim()) continue;
      const row = JSON.parse(line) as { result?: RoundResult; type?: string; kind?: string };
      if (row.result && "roundId" in row.result && "racePoints" in row.result) out.push(row.result);
    }
  }
  return out;
}

// ---------------------------------------------------------------- bantuan halaman siswa

export const stateOf = <T>(page: Page, pick: string): Promise<T> =>
  page.evaluate((p) => new Function("s", `return ${p}`)((window as unknown as { __rr: { game: { state: unknown } } }).__rr.game.state), pick) as Promise<T>;

export const node = (page: Page, id: NodeId) => page.getByTestId(`node-${id}`);

export async function joinAs(page: Page, url: string, code: string, rosterId: string, seat: { row: number; col: number } | null): Promise<void> {
  await page.goto(url);
  for (const d of code) await page.getByTestId(`key-${d}`).click();
  await page.getByTestId("pin-go").click();
  await page.getByTestId(`name-${rosterId}`).click();
  if (seat) {
    await page.getByTestId(`seat-${seat.row}-${seat.col}`).click();
    await page.getByTestId("seat-confirm").click();
  }
  await expect(page.getByTestId("ready-screen")).toBeVisible();
}

export async function walkPath(page: Page, path: readonly NodeId[]): Promise<void> {
  for (const id of path.slice(1)) await node(page, id).click();
}

export const solve = (map: MapDef): NodeId[] => optimalRoute(map);

export const phaseIs = (page: Page, phase: string) => expect(page.locator(`.app[data-phase="${phase}"]`));

export async function waitApp(page: Page, phase: string, timeout = 30_000): Promise<void> {
  await page.locator(`.app[data-phase="${phase}"]`).waitFor({ timeout });
}

function readRows(dataDir: string, sessionId: string): { type: string; result?: unknown }[] {
  const dir = join(dataDir, "test-sessions");
  if (!existsSync(dir)) return [];
  const rows: { type: string; result?: unknown }[] = [];
  for (const f of readdirSync(dir).filter((n) => n.includes(sessionId))) {
    for (const line of readFileSync(join(dir, f), "utf8").split(/\r?\n/)) if (line.trim()) rows.push(JSON.parse(line) as { type: string; result?: unknown });
  }
  return rows;
}

export const readTutorials = (dataDir: string, sessionId: string): TutorialResult[] =>
  readRows(dataDir, sessionId)
    .filter((r) => r.type === "tutorial")
    .map((r) => r.result as TutorialResult);

/** Jalur sederhana terpanjang dari start ke goal yang melewati semua stop (untuk uji rute cepat). */
export function longestSimplePath(map: MapDef): NodeId[] {
  const adj = new Map<NodeId, NodeId[]>();
  for (const e of map.edges) {
    adj.set(e.a, [...(adj.get(e.a) ?? []), e.b]);
    adj.set(e.b, [...(adj.get(e.b) ?? []), e.a]);
  }
  let best: NodeId[] = [];
  const go = (path: NodeId[]): void => {
    const last = path[path.length - 1] as NodeId;
    if (last === map.goal) {
      if (map.stops.every((s) => path.includes(s)) && path.length > best.length) best = [...path];
      return;
    }
    for (const n of adj.get(last) ?? []) if (!path.includes(n)) go([...path, n]);
  };
  go([map.start]);
  return best;
}

/** Guru tiruan menyelesaikan layar hasil dan papan peringkat dengan cepat (setelah jeda singkat agar siswa sempat melihatnya). */
export function autoSkip(host: HostDriver, resultMs = 2200, boardMs = 2200): void {
  host.socket.on("phase", (p: { phase: string }) => {
    if (p.phase === "RESULT") setTimeout(() => void host.cmd("host:skip"), resultMs);
    if (p.phase === "LEADERBOARD") setTimeout(() => void host.cmd("host:skip"), boardMs);
  });
}

export async function visitedCount(page: Page): Promise<number> {
  return page.locator('[data-testid^="node-"][data-visited="1"]').count();
}

export async function tutorialMap(page: Page): Promise<MapDef> {
  return stateOf<MapDef>(page, "s.tutorial.map");
}
/** Mulai merekam getaran node di dalam halaman (getaran hanya 300 ms, terlalu singkat untuk di-polling dari tes). */
export async function watchShake(page: Page, id: NodeId): Promise<void> {
  await page.evaluate((nodeId) => {
    const w = window as unknown as { __shake: { on: number | null; off: number | null } };
    w.__shake = { on: null, off: null };
    const el = document.querySelector(`[data-testid="node-${nodeId}"]`) as Element;
    new MutationObserver(() => {
      const now = performance.now();
      if (el.getAttribute("data-shaking") === "1" && w.__shake.on === null) w.__shake.on = now;
      if (el.getAttribute("data-shaking") === "0" && w.__shake.on !== null && w.__shake.off === null) w.__shake.off = now;
    }).observe(el, { attributes: true, attributeFilter: ["data-shaking"] });
  }, id);
}

/** Getaran harus tercatat dan berlangsung ± 300 ms. */
export async function expectShake(page: Page): Promise<void> {
  await expect
    .poll(async () => page.evaluate(() => (window as unknown as { __shake: { off: number | null } }).__shake.off !== null), { timeout: 5000 })
    .toBe(true);
  const { on, off } = await page.evaluate(() => (window as unknown as { __shake: { on: number; off: number } }).__shake);
  expect(off - on).toBeGreaterThanOrEqual(250);
  expect(off - on).toBeLessThanOrEqual(600);
}
/** Siswa lewat protokol Socket.IO (tanpa peramban): memilih nama sendiri seperti client sungguhan, lalu bermain rute terhemat. */
export class SocketPlayer {
  readonly socket: Socket;
  map: MapDef | null = null;
  roundId = -1;
  phase = "";
  holdWalk = false;
  holdTutorial = false;
  holdProbe = false;
  private pendingProbe: { edgeId: string } | null = null;
  /** Rute yang dikirim; null = rute terhemat dari peta yang diterima saat LOOK. */
  route: NodeId[] | null = null;
  tapGapMs = 700;
  readonly submitted = new Set<number>();
  token = "";
  private pendingTutorial: { step: number }[] = [];

  constructor(url: string, readonly rosterId: string) {
    this.socket = io(url, { transports: ["websocket"], forceNew: true });
    this.socket.on("phase", (p: { phase: string; roundId?: number }) => {
      this.phase = p.phase;
      if (p.roundId !== undefined) this.roundId = p.roundId;
      if (p.phase === "WALK" && !this.holdWalk) this.submitWalk();
    });
    this.socket.on("round:map", (v: { map: MapDef; showWeights: boolean }) => {
      if (v.showWeights) this.map = v.map;
    });
    this.socket.on("tutorial:map", (v: { step: number }) => {
      if (this.holdTutorial) this.pendingTutorial.push(v);
      else this.doTutorial(v.step);
    });
    this.socket.on("probe:question", (q: { edgeId: string }) => {
      if (this.holdProbe) this.pendingProbe = q;
      else this.answerProbe(q);
    });
  }

  ask(event: string, payload: unknown): Promise<Ack> {
    return new Promise((res, rej) => this.socket.timeout(5000).emit(event, payload, (e: Error | null, r: Ack) => (e ? rej(e) : res(r))));
  }

  async join(code: string, seat: { row: number; col: number } | null): Promise<void> {
    await new Promise<void>((res) => (this.socket.connected ? res() : this.socket.once("connect", () => res())));
    const a = await this.ask("player:join", { code });
    expect(a.ok, JSON.stringify(a)).toBe(true);
    const c = await this.ask("player:claim", { rosterId: this.rosterId });
    expect(c.ok, JSON.stringify(c)).toBe(true);
    this.token = c.studentToken as string;
    if (seat) expect((await this.ask("player:seat", seat)).ok).toBe(true);
  }

  private answerProbe(q: { edgeId: string }): void {
    const w = this.map?.edges.find((e) => e.id === q.edgeId)?.w;
    if (w !== undefined) this.socket.emit("probe:answer", { roundId: this.roundId, value: w, clientElapsedMs: 1200 });
  }

  releaseProbe(): void {
    this.holdProbe = false;
    if (this.pendingProbe) this.answerProbe(this.pendingProbe);
    this.pendingProbe = null;
  }

  private doTutorial(step: number): void {
    this.socket.emit("tutorial:step", { step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 4000 });
    if (step === 5) this.socket.emit("tutorial:done", { totalMs: 20_000, autoDemoSteps: [], probeCorrect: true });
  }

  releaseTutorial(): void {
    for (const t of this.pendingTutorial.splice(0)) this.doTutorial(t.step);
    this.holdTutorial = false;
  }

  submitWalk(): void {
    if (!this.map || this.submitted.has(this.roundId)) return;
    this.submitted.add(this.roundId);
    const path = this.route ?? optimalRoute(this.map);
    this.socket.emit("route:submit", {
      roundId: this.roundId,
      path,
      clientElapsedMs: (path.length - 1) * this.tapGapMs,
      tapLog: path.slice(1).map((nodeId, i) => ({ tMs: (i + 1) * this.tapGapMs, nodeId, valid: true })),
      invalidTaps: 0,
      undo: 0,
      revisits: 0,
    });
  }

  close(): void {
    this.socket.close();
  }
}

export async function waitUntil(cond: () => boolean, ms = 20_000, what = "kondisi"): Promise<void> {
  const until = Date.now() + ms;
  while (!cond()) {
    if (Date.now() > until) throw new Error(`waktu habis menunggu ${what}`);
    await new Promise((r) => setTimeout(r, 25));
  }
}
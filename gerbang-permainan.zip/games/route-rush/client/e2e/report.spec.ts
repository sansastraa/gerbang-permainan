import { expect, test } from "@playwright/test";
import { SocketPlayer, startServer, type TestServer } from "./support";

let server: TestServer;
test.beforeEach(async ({ page }) => {
  await page.addInitScript(() => localStorage.setItem("rr.advanced", "1")); // panel "Atur sesi sendiri" terbuka
});
test.beforeAll(async () => {
  test.setTimeout(120_000);
  server = await startServer();
});
test.afterAll(async () => {
  await server?.stop();
});

const NAMES = ["Ani Lestari", "Budi Santoso", "Citra Dewi"];

test("Tantangan: hasil proyektor memuat rute terbaik; laporan bisa dicari, diurutkan, diekspor, dan siswa bisa dihapus", async ({ page }) => {
  test.setTimeout(200_000);
  await page.setViewportSize({ width: 1366, height: 768 });
  await page.goto(`${server.url}/host`);
  await page.getByTestId("roster-input").fill(NAMES.join("\n"));
  await page.getByTestId("intro-short").check();
  await page.getByTestId("pool-t").check();
  await page.getByTestId("set-rounds").fill("1");
  await page.getByTestId("set-look").fill("3");
  await page.getByTestId("set-walk").fill("30");
  await page.getByTestId("create-btn").click();
  await expect(page.getByTestId("host-intro")).toBeVisible();
  await page.getByTestId("skip-intro").hover();
  await page.mouse.down();
  await page.waitForTimeout(2300);
  await page.mouse.up();
  await expect(page.getByTestId("host-lobby")).toBeVisible();
  const pin = (await page.getByTestId("host-pin").innerText()).trim();

  const players = ["siswa-1", "siswa-2", "siswa-3"].map((id) => new SocketPlayer(server.url, id)) as [SocketPlayer, SocketPlayer, SocketPlayer];
  for (const [i, p] of players.entries()) await p.join(pin, { row: 0, col: i });
  // animasi masuk: kartu "masuk" dan chip bercentang di layar guru
  await expect(page.getByTestId("joined-list").locator("li")).toHaveCount(3);
  await page.screenshot({ path: "test-results/report-lobby.png" });

  await page.getByTestId("start-btn").click();
  await expect(page.getByTestId("host-result")).toBeVisible({ timeout: 90_000 });
  await expect(page.getByTestId("summary-route-0")).toContainText("langkah");
  await expect(page.getByTestId("summary-solvers-0")).toContainText("siswa");
  await expect(page.getByTestId("summary-fastest-0")).toContainText("dtk");
  await page.screenshot({ path: "test-results/report-result.png" });

  await page.getByTestId("report-btn").click();
  await expect(page.getByTestId("report")).toBeVisible();
  await expect(page.getByTestId("stat-students")).toHaveText("3");
  await expect(page.locator('[data-testid^="report-row-"]')).toHaveCount(3);
  await page.getByTestId("report-search").fill("budi");
  await expect(page.locator('[data-testid^="report-row-"]')).toHaveCount(1);
  await page.getByTestId("report-search").fill("zzz");
  await expect(page.getByTestId("report-empty")).toContainText("Tidak ada nama");
  await page.getByTestId("report-search").fill("");
  await page.getByTestId("sort-name").click();
  await expect(page.locator('[data-testid^="report-row-"]').first()).toContainText("Ani Lestari");
  await page.getByTestId("report-row-siswa-1").getByRole("button", { name: "Ani Lestari", exact: true }).click();
  await expect(page.getByText("Koin (rute / terbaik)")).toBeVisible();
  await page.screenshot({ path: "test-results/report-open.png" });
  await expect(page.getByTestId("report-pdf")).toBeEnabled();

  // hapus siswa: dua langkah (konfirmasi), lalu hilang dari tabel dan sesi
  await page.getByTestId("report-remove-siswa-2").click();
  await expect(page.getByTestId("report-remove-siswa-2")).toContainText("Yakin");
  await page.getByTestId("report-remove-siswa-2").click();
  await expect(page.locator('[data-testid^="report-row-"]')).toHaveCount(2);
  await expect(page.getByTestId("stat-students")).toHaveText("2");
  await expect(page.getByTestId("report-table")).not.toContainText("Budi Santoso");

  const saved = await page.evaluate(() => JSON.parse(localStorage.getItem("rr.host") ?? "{}") as { sessionId?: string; hostToken?: string });
  const summaryUrl = `${server.url}/api/sessions/${saved.sessionId}/summary.json?includeTest=1`;
  expect((await page.request.get(summaryUrl)).status()).toBe(401); // tanpa token guru, laporan sesi berjalan tertutup
  const json = await (await page.request.get(summaryUrl, { headers: { "x-host-token": saved.hostToken ?? "" } })).json();
  expect((json as { students: unknown[] }).students).toHaveLength(2);
  await page.getByTestId("report-close").click();
  await expect(page.getByTestId("report")).toHaveCount(0);
  for (const p of players) p.close();
});

test("jumlah ronde bisa dikustom: pilihan cepat dan stepper mengisi daftar ronde (ronde latihan ikut pada intro ringkas)", async ({ page }) => {
  await page.goto(`${server.url}/host`);
  await expect(page.getByTestId("round-number")).toContainText("10"); // Standar
  await page.getByTestId("round-chip-3").click();
  await expect(page.getByTestId("set-rounds")).toHaveValue("1,2,3");
  await page.getByTestId("round-plus").click();
  await expect(page.getByTestId("round-number")).toContainText("4");
  await expect(page.getByTestId("set-rounds")).toHaveValue("1,2,3,4");
  await page.getByTestId("intro-short").check();
  await page.getByTestId("round-minus").click();
  await expect(page.getByTestId("set-rounds")).toHaveValue("0,1,2,3");
  await page.getByTestId("round-chip-10").click();
  await expect(page.getByTestId("round-plus")).toBeDisabled();
  // jenis soal: hitung (ganjil), ingatan (genap), campuran; satu jenis dibatasi 5 soal pada bank A/B
  await page.getByTestId("round-chip-3").click();
  await page.getByTestId("mix-visible").check();
  await expect(page.getByTestId("set-rounds")).toHaveValue("0,1,3,5");
  await page.getByTestId("mix-hidden").check();
  await expect(page.getByTestId("set-rounds")).toHaveValue("0,2,4,6");
  await page.getByTestId("round-chip-5").click();
  await expect(page.getByTestId("round-plus")).toBeDisabled();
  // Tantangan: ingatan lewat daftar ronde tersembunyi; waktu ingatan sampai 180 detik
  await page.getByTestId("pool-t").check();
  await page.getByTestId("mix-mixed").check();
  await page.getByTestId("round-chip-10").click();
  await page.getByTestId("set-probe").fill("180");
  await page.getByTestId("roster-input").fill("Ani\nBudi");
  await page.getByTestId("create-btn").click();
  await expect(page.getByTestId("host-intro")).toBeVisible();
});
test("layar buat sesi selalu mulai kosong: isian sebelumnya tidak dipulihkan saat halaman dimuat ulang", async ({ page }) => {
  await page.goto(`${server.url}/host`);
  await page.getByTestId("roster-input").fill("Ani Lestari\nBudi Santoso;6C");
  await page.getByTestId("round-chip-5").click();
  await page.getByTestId("set-walk").fill("45");
  await expect(page.getByTestId("roster-count")).toHaveText("2 siswa");
  await expect(page.getByTestId("roster-chips")).toContainText("Ani Lestari");
  await page.reload();
  await expect(page.getByTestId("roster-input")).toHaveValue("");
  await expect(page.getByTestId("roster-count")).toHaveText("0 siswa");
  await expect(page.getByTestId("round-number")).toContainText("10");
  await expect(page.getByTestId("set-walk")).toHaveValue("");
});
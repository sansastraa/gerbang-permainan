import { defineConfig } from "@playwright/test";

/** Memakai Microsoft Edge yang sudah terpasang di sistem (tanpa mengunduh peramban). Server dijalankan oleh tes sendiri. */
export default defineConfig({
  testDir: "e2e",
  timeout: 240_000,
  expect: { timeout: 10_000 },
  workers: 1,
  fullyParallel: false,
  reporter: [["list"]],
  use: { channel: "msedge", headless: true, viewport: { width: 412, height: 860 }, actionTimeout: 20_000, launchOptions: { args: ["--disable-renderer-backgrounding", "--disable-backgrounding-occluded-windows", "--disable-background-timer-throttling"] } },
});
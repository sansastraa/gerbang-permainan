import react from "@vitejs/plugin-react";
import { defineConfig } from "vitest/config";

/** BASE_PATH=/games/route-rush membuat build hidup di bawah awalan jalur (gerbang satu pintu SIMPETERI); kosong = dari akar. */
export function normalizeBasePath(raw: string | undefined): string {
  const t = (raw ?? "").trim().replace(/\/+$/, "");
  if (!t) return "";
  return t.startsWith("/") ? t : `/${t}`;
}
const basePath = normalizeBasePath(process.env["BASE_PATH"]);

export default defineConfig({
  base: basePath ? `${basePath}/` : "/",
  plugins: [react()],
  server: { proxy: { [`${basePath}/socket.io`]: { target: "http://localhost:3000", ws: true } } },
  build: { outDir: "dist", sourcemap: false },
  test: { environment: "jsdom", include: ["src/**/*.test.{ts,tsx}"] },
});
# Font lokal

Letakkan berkas font OFL di folder ini (bukan dari CDN, karena jaringan sekolah sering lambat):

- `Baloo2-ExtraBold.woff2` (Baloo 2, bobot 800)
- `Nunito-SemiBold.woff2` (Nunito, bobot 600)
- `Nunito-Bold.woff2` (Nunito, bobot 700)

`client/src/styles.css` sudah memuat `@font-face` yang menunjuk ke nama berkas di atas. Selama berkas belum ada,
tampilan memakai font sistem yang bulat sebagai cadangan.
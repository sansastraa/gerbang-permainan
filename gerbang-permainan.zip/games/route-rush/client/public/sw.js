/*
  Service worker Route Rush: hanya membuat aplikasi bisa dipasang (Android/Chrome, iOS/iPadOS lewat Tambah ke Layar Utama)
  dan memuat kerangka halaman lebih cepat. Permainan tetap butuh internet: socket, API, dan klip suara tidak pernah disimpan.
*/
const CACHE = "rr-shell-v1";
// awalan jalur = cakupan pendaftaran ("/" atau mis. "/games/route-rush/"), jadi sama untuk akar maupun gerbang satu pintu
const BASE = new URL(self.registration.scope).pathname;
const SHELL = [BASE, `${BASE}manifest.webmanifest`, `${BASE}icons/icon-192.png`, `${BASE}icons/apple-touch-icon.png`];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches
      .keys()
      .then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k))))
      .then(() => self.clients.claim()),
  );
});

const NEVER = /^\/(socket\.io|api|health|clips)(\/|$)/;
const STATIC = /\.(js|css|woff2?|ttf|png|svg|webmanifest)$/;

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  const rel = url.pathname.startsWith(BASE) ? `/${url.pathname.slice(BASE.length)}` : url.pathname;
  if (url.origin !== self.location.origin || !url.pathname.startsWith(BASE) || NEVER.test(rel)) return;
  if (req.mode === "navigate") {
    // halaman: selalu coba jaringan dulu agar versi baru langsung terpakai; tanpa jaringan, tampilkan kerangka tersimpan
    e.respondWith(fetch(req).catch(() => caches.match(BASE).then((r) => r ?? Response.error())));
    return;
  }
  if (STATIC.test(url.pathname)) {
    e.respondWith(
      caches.open(CACHE).then(async (cache) => {
        const hit = await cache.match(req);
        if (hit) return hit;
        const res = await fetch(req);
        if (res.ok) void cache.put(req, res.clone());
        return res;
      }),
    );
  }
});
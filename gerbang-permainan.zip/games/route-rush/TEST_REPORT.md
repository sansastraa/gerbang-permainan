# TEST_REPORT — Route Rush

## Fase 9 — Pemeriksaan lapangan (terbaru; **menunggu uji di kelas sungguhan**)

Yang disiapkan Claude Code sesuai spek: `npm run field-check -- --session <id>` membaca sesi LIVE dan menulis `docs/field-check-<sessionId>.md`. Uji kelasnya sendiri dijalankan tim peneliti/guru dan **belum terjadi**; tidak ada hasil lapangan di laporan ini.

`npm test`: shared **198** (cakupan baris 97,46%, cabang 94,48%), server **62**, client 31 lulus; typecheck dan lint bersih.

| Yang diuji | Bukti |
|---|---|
| Kruskal-Wallis dan khi-kuadrat | nilai baku: 4 uji (H = 7,2 → p 0,0273; koreksi kembar; titik kritis 0,05 df 1, 2, 4; kasus tak terdefinisi) |
| 10 pemeriksaan | 11 uji pada kelas sintetis 28 siswa × 4 ronde: semua lulus pada data sehat; tiap pemeriksaan gagal tepat ketika datanya digeser (kurang selesai, demo tutorial, langkah 3, hasil ditolak, ronde kehabisan waktu, OH di luar rentang, durasi lewat batas, soal menyimpang, varian berbeda, tanpa denah); sampel kecil → "data kurang"; sesi lanjutan → "tidak berlaku" |
| Laporan Markdown | ringkasan 10 baris, tabel per ronde, tindak lanjut (soal yang diganti dengan Pool C, D), peringatan data TEST, peringatan sampel kecil |
| CLI | server: sesi TEST ditolak tanpa `--include-test` (kode 2), id tidak sah/tidak ada, sesi LIVE buatan (dengan dan tanpa hasil ditolak), berkas `.md` ditulis ke folder keluaran, kode keluar 0/1/2 |
| Penanda Mulai/podium | sesi bot sungguhan mencatat `start` dan `podium`; C7 dihitung |

**Temuan dan keputusan (DECISIONS 85):** pada simulasi 30 bot dengan soal setara menurut konstruksi, syarat selisih rerata ER ≤ 0,15 menandai 9–10 dari 10 ronde (sampel 7–8 hasil per soal), sedangkan Kruskal-Wallis lolos di semua 10 ronde. Atas keputusan pemilik, selisih kini **hanya penanda** ("Dipantau"); C9 gagal hanya bila p < 0,05. Pada simulasi yang sama sekarang: C9 LULUS (10/10 ronde lolos, 9 bertanda selisih) dan semua 10 pemeriksaan lulus. Uji deterministik: selisih 0,20 dengan p > 0,05 → LULUS + dipantau; sebaran terpisah → GAGAL + diganti.

Hal yang belum ada: data siswa nyata; pemeriksaan C1–C10 hanya diuji pada data sintetis dan bot; sesi yang dibuat sebelum Fase 9 tidak punya penanda Mulai/podium. Python oracle masih belum dapat dijalankan.

## Fase 8 — Ekspor, laporan, dan uji tempo

`npm test`: shared **180** (cakupan baris 97,23%, cabang 95,11%), server **57** (baris 95,69%, cabang 88,2%), client 31 lulus; `typecheck` dan `lint:nodummy` bersih. Playwright: `host.spec.ts` "sesi penuh" lulus dengan unduhan di podium (satu uji; suite penuh belum dijalankan ulang).

| Kriteria selesai | Bukti | Status |
|---|---|---|
| **T26** `students.csv` identik dengan hitung ulang dari `rounds.csv` | shared: tiap kolom indeks/poin/jumlah ronde dibandingkan dengan `summarizeStudent` atas `parseRoundsCsv(roundsCsv)`; server: pada data sesi bot sungguhan lewat HTTP, dan byte-per-byte dengan pembuat langsung | lulus |
| Sesi TEST ditolak tanpa `includeTest=1` | server: 5 berkas → 403 `SESSION_TEST`, 200 dengan `?includeTest=1`; `?includeTest=0` tetap 403; sesi LIVE tanpa parameter 200 | lulus |
| CSV terbuka rapi di Excel (BOM UTF-8) | byte awal `EF BB BF` dan CRLF diperiksa di server dan e2e; sel dengan koma/kutip/baris baru dikutip dan dibaca balik. **Belum dibuka di Excel sungguhan** | BOM terbukti, Excel belum |
| Laporan tanpa poin/peringkat | uji: kartu tidak memuat kata poin/peringkat/race_points/total_points (shared dan server) | lulus |
| Catatan otomatis lengkap (ronde, tutorial, integritas) | 6 uji: urutan, batas 3, kalimat tutorial, kalimat integritas persis seperti spek | lulus |
| Flag integritas hanya di laporan guru | e2e: kartu laporan sesi nyata memuat "keluar aplikasi 1 kali saat ronde 1", sementara teks layar proyektor tidak pernah memuatnya (A9) | lulus |
| Durasi simulasi tidak melewati S1–S4 | `npm run simulate -- --players 30`: **S1 506/608, S2 332/428, S3 498/508, S4 324/328 detik**, 27 detik waktu nyata; diuji juga dengan 12 pemain | lulus (S3 dan S4 margin tipis) |
| `README.md` lengkap | instalasi, menjalankan di LAN, membuat sesi, ekspor, uji/simulasi, aset, struktur | ada; belum dicoba oleh orang lain dari nol |

Catatan jujur: ekspor dan laporan hanya diuji dengan data bot dan satu sesi uji e2e (dua pemain protokol), bukan data kelas nyata; tampilan `report.html` saat dicetak A4 belum dilihat di pencetak atau pratinjau cetak (hanya struktur HTML/CSS yang diuji); alamat unduhan tanpa kata sandi (DECISIONS 79); notifikasi SECOND_DEVICE di layar guru tidak dibuat (DECISIONS 79). Python oracle masih belum dapat dijalankan.

## Tambahan setelah Fase 7: Cara bermain dan suara jawaban

`npm test`: shared 162, server 46, client 29 lulus; typecheck dan lint bersih. Playwright: `rules.spec.ts` (2 uji), `answers.spec.ts` (3 uji) lulus; `host.spec.ts` lulus ulang setelah perubahan (6/6 bersama `rules.spec.ts`). Suite penuh belum dijalankan ulang setelah tambahan ini.

| Permintaan | Bukti |
|---|---|
| Tutorial cara bermain di sisi client | e2e: tombol dibuka dari lobi, 6 kartu (teks = `COPY.rules`), kartu 1–2 memuat peta contoh, kartu 5 bintang, kartu 6 lencana "?"; Prev/Next/Mengerti/Esc; tersedia saat TUTORIAL (latihan tetap berjalan), **tidak ada** saat LOOK/WALK. Tangkapan layar ditinjau: kartu koin terbaca jelas di layar 412 px |
| Tampil juga di proyektor | e2e: `rules-ticker` tampil saat TUTORIAL dan berganti kartu |
| 25 klip nama dipotong per jeda | `clips.json` = 25 klip berurutan 01–25, tiap klip 2–5 detik, −16 LUFS; uji unit pembagi pada data sintetis. **Pembagian terhadap suara asli hanya diperiksa secara struktural** (pola nama + frasa tetap, 51 subsegmen = 25 klip + satu nama berkata dua); saya tidak dapat mendengar apakah batas tiap klip pas |
| Benar → bunyi benar + nama; salah → bunyi salah | e2e: urutan `correct, name(02), name(01)` dengan nama diurutkan menurut waktu tercepat; hanya `wrong` bila tak ada yang benar; nama tanpa klip tidak disebut; nama tidak tampil di layar RESULT |
| Pencocokan nama siswa ↔ klip | 7 uji unit (nama kembar awalan "Adnan Fahreza"/"Adnan Sharif" tidak tertukar, nama panjang, ambigu → diam) |

**Belum bisa diselesaikan tanpa Anda:** daftar 25 nama sesuai urutan klip (`assets/audio/names/names.txt`) dan kepastian lisensi ketiga MP3. Bunyi sebenarnya di speaker tidak dapat saya verifikasi.

## Fase 7 — Audio dan aset (**belum selesai**)

Yang dikerjakan: `scripts/gen-audio.ts` + `scripts/audio/` (sintesis, WAV, pengukur LUFS, perender campuran), `shared/src/audioCues.ts` (jadwal suara dari timeline), `client/src/audio/engine.ts` (pemutar + narasi cadangan), `scripts/check-production.mjs` (gerbang build), `assets/audio/LICENSES.md`, `LICENSES.md`, `assets/PLACEHOLDERS.md`. `npm test`: shared 153, server 46, client 26 lulus; typecheck dan lint bersih.

| Kriteria selesai | Status |
|---|---|
| **I14** campuran −16 LUFS ±1 | **lulus** untuk keempat campuran (IDENT/TRAILER × FULL/SHORT), diukur dengan pengukur BS.1770 buatan sendiri (bukan ffmpeg); puncak ≤ −0,9 dBFS; tidak ada efek > 6 dB di atas musik (jadwal dan penguatan dihitung otomatis dan diuji) |
| Musik orisinal 45 detik, lisensi tertulis | musik **sintetis** 45 detik ada dan berlisensi milik proyek; **belum didengarkan/disetujui manusia** |
| Suara diputar di proyektor sesuai posisi fase | e2e "suara": IDENT_FULL dimulai ≤ 2,5 detik dari awal fase, TRAILER_FULL juga; tombol Suara berfungsi. Bunyi sebenarnya di speaker **tidak dapat diverifikasi** di mesin uji |
| Total aset intro ≤ 5 MB | ≈ 3 MB campuran + logo (lulus, diuji) |
| `LICENSES.md` lengkap | audio: lengkap (semua berkas disebut, uji gerbang); **font dan rekaman VO: belum ada** |
| `PLACEHOLDERS.md` kosong | **TIDAK**: 6 baris (logo, nama pembuat, musik/efek belum disetujui, VO, font, visual trailer) |
| `npm run build` produksi berhasil | **TIDAK, sengaja**: gerbang menolak dengan 9 alasan; diuji bahwa penolakan terjadi dan menyebut alasannya. `npm run build:dev` berhasil |

Yang dibutuhkan dari pemilik proyek agar fase ini benar-benar selesai: (1) berkas font Baloo 2 dan Nunito (OFL) di `client/public/fonts/`; (2) logo dan nama pembuat; (3) rekaman narasi VO (atau keputusan memakai suara sintetis peramban); (4) mendengarkan musik/efek dan menyetujui atau menggantinya; (5) persetujuan visual intro. Setiap butir dihapus dari `PLACEHOLDERS.md` saat selesai; gerbang akan lulus ketika daftar kosong.

## Fase 6 — Intro sinematik

`client/src/intro/` (`model.ts` jam + pemilihan shot, `data.ts` data dari berkas acuan, `scenes.tsx` adegan SVG, `IntroStage.tsx` pemutar + subtitle + tombol tahan). Uji: `client/e2e/intro.spec.ts` (8 uji, Edge 1280×720) dan `client/src/intro/intro.test.ts` (8 uji unit). **Tahap (a) animatik**; visual final (b) belum (DECISIONS 53).

| Kriteria selesai | Bukti | Status |
|---|---|---|
| **I9** FULL: ident → trailer → tutorial → ronde 1, ronde 0 tidak muncul | urutan fase INTRO_IDENT, INTRO_TRAILER, LOBBY, COUNTDOWN, TUTORIAL, LOOK(ronde 1) pada jam nyata (± 70 detik) + kartu "9 vs 8" dan subtitle dari timeline | lulus (diadaptasi ke alur PIN setelah intro, DECISIONS 56) |
| **I10** tahan Lewati 2 detik / tekan sebentar | tekan 0,4 detik: intro tetap; tahan 2,3 detik: LOBBY dan kode tampil | lulus (berakhir di LOBBY, bukan TUTORIAL) |
| **I11** `prefers-reduced-motion` | 45 titik waktu → tepat 6 gambar diam (shot-02, 04, 05, 06, 08, 09); `durationMs` 45000; 0 animasi CSS/WAAPI; subtitle sama | lulus |
| **I12** gambar pada 5, 15, 20, 25, 35 detik (jam terkendali) | 5 tangkapan layar dibandingkan dengan baseline | lulus, **tetapi baseline dibuat dari render saat ini dan belum disetujui manusia** |
| **I13** kedipan | sapuan tiap 40 ms pada ident dan trailer: kedipan opasitas terburuk ≤ 3 per detik; elemen SVG aktif < 500; tidak ada `filter` | lulus (angka tercatat di anotasi uji) |
| **60 fps dengan CPU 4×** | CDP `setCPUThrottlingRate 4`, 8 detik berjalan: 489 frame, rata-rata 16,4 ms (≈ 61 fps), p95 18,9 ms, 0 frame > 33 ms | lulus pada Edge headless; **bukan profil performa Chrome pada laptop sekolah sungguhan** |
| Total aset intro ≤ 5 MB | logo 1 KB + animasi di kode (bundel JS 275 KB) | lulus (uji unit) |
| Versi ringkas (ident 3 detik, trailer 12 detik = shot-04, 05, 08) | uji unit dan e2e | lulus |
| Bilah pemuatan sebelum intro | tombol Buat sesi menunggu aset | lulus |

Angka trailer berasal dari data (9 dan 8 dihitung dari A-05 lewat `trailerNumbers`); `hasLiteralCoinNumbers(timeline.json)` = false.

**Tinjauan visual (22 tangkapan layar di ident dan setiap shot trailer, lalu 7 tangkapan ulang setelah perbaikan).** Temuan dan perbaikan: kurir tampak seperti segitiga oranye dan menutupi masjid pada shot-03 (kurir digambar ulang dan berjalan di jalan; paket diletakkan di depan Rumah); kilau ident berupa batang putih besar yang menimpa logo (dipotong ke kotak logo, logo diperbesar, jaringan memudar sebelum logo muncul); montase shot-07 sempat kosong pada tiap pergantian panel (fade diganti letupan skala); tiga kata shot-09 menempel ke kiri (digeser ke tengah); gambar tidak penuh layar dengan pita hitam (kini penuh dengan subtitle bergradien di bawah). Baseline I12 dibuat ulang setelah perbaikan.

Catatan jujur:
- **Visual belum final**: bentuk dasar, kurir/bangunan sederhana; paralaks dan montase ada tetapi belum diolah desainer. Setelah tinjauan, kualitasnya setara animatik yang layak ditonton, bukan seni akhir: panel montase "ketuk" dan "wajib mampir" masih lingkaran dan kotak polos, kota hanya enam bangunan datar.
- **Kinerja bervariasi**: setelah gambar dibuat penuh layar, uji 4× CPU memberi 57 fps saat sendirian (2 kali) dan 40 fps sekali saat mesin sedang sibuk; ambang uji diturunkan ke 50 fps / 8% frame lambat.
- **Audio belum ada** (Fase 7): hanya cadangan Web Speech API; I14 belum dikerjakan.
- **I9 dijalankan di jam nyata** karena trailer dan ident berjalan di server; satu uji memakan ± 70 detik.
- Logo dan nama pembuat sementara; `assets/PLACEHOLDERS.md` tidak kosong, sehingga build produksi (Fase 7) harus gagal sampai diganti.

## Fase 5 — Client Host

Layar guru/proyektor di `/host` (`client/src/Host.tsx`, `hostStore.ts`). Uji: `client/e2e/host.spec.ts` (4 uji, server sungguhan + Edge; siswa lewat protokol Socket.IO memakai `SocketPlayer`). `npm test` tetap hijau (shared 148, server 46, client 8), `typecheck` dan `lint:nodummy` bersih.

| Kriteria selesai | Bukti | Status |
|---|---|---|
| Lobi kosong menampilkan "Belum ada pemain" | `host-empty`, hilang saat siswa pertama masuk | lulus |
| Angka penghitung cocok dengan jumlah pemain nyata | "0/3 → 1/3 → 2/3 → 3/3 sudah masuk", turun ke 2/3 saat satu siswa terputus; "2/3 siap" (tutorial); "1/3, 2/3 sudah sampai" (WALK) sesuai kiriman nyata | lulus |
| Kode sesi baru tampil setelah intro; Mulai terkunci sampai kuota dan kursi lengkap, dengan alasan ("Menunggu 3 siswa lagi", "1 siswa belum memilih kursi") | `host.spec.ts` lobi | lulus |
| Denah langsung dengan inisial; guru mengetuk kursi untuk mengosongkannya (tombol Mulai terkunci lagi) | `hseat-*` | lulus |
| Pengaturan di lobi: kuota, denah, waktu; nilai tidak sah ditolak dengan pesan | "pengaturan di lobi" | lulus |
| Peta tidak pernah ada di DOM host saat LOOK/WALK/PROBE (VISIBLE dan HIDDEN) | pemeriksaan `svg.mapview`, `node-*`, `badge-*` = 0 pada tiap fase | lulus |
| RESULT: 4 gambar rute terhemat + "% kelas menemukan rute terhemat"; 5 besar; podium 3 besar | `summary-0..3`, `host-pct`, `board-*`, `podium-*` | lulus |
| **A9**: tanda integritas (FOCUS_LOST, TOO_FAST, SECOND_DEVICE) tidak pernah tampil di proyektor | seluruh teks layar direkam sepanjang sesi 2 ronde saat ketiga tanda sengaja dipicu; tidak ada yang cocok | lulus |
| Lewati/Akhiri meminta konfirmasi; Akhiri menutup sesi; pilihan intro FULL/SHORT; muat ulang memulihkan sesi | uji "Lewati dan Akhiri…", "lobi…" | lulus |
| Penghitung hasil ditolak | tampil ("Hasil ditolak: 0") | **hanya nilai awal 0 yang diuji**; menaikkannya butuh hasil yang gagal pemeriksaan integritas, sudah tercakup di uji server |

Perubahan server di fase ini: `round:summary` selalu memuat keempat soal setara; `host:attach` mengembalikan `phaseState`, `code`, `rejected` (DECISIONS 45–52).

Catatan jujur: tombol Unduh pada podium belum ada (Fase 8); tata letak proyektor 16:9 belum ditinjau visual di layar besar (hanya viewport 412×860 pada uji, jadi tampilan host belum dilihat pada ukuran proyektor); daftar siswa masih dari kolom teks, belum tersambung ke data SIMPETERI.

## Fase 4 — Client Player (Vite + React 18) dan uji Playwright

Dijalankan dengan `npm test` (shared + server + uji unit client), `npm run typecheck`, `npm run lint:nodummy`, `npm run build -w client`, dan `npx playwright test` di folder `client` (atau `npm run e2e` dari akar). Playwright memakai **Microsoft Edge yang sudah terpasang** (`channel: "msedge"`, tanpa mengunduh peramban); setiap berkas uji menjalankan server sungguhan (`NODE_ENV=test`, jam nyata) yang juga menyajikan hasil build client.

| Pemeriksaan | Hasil |
|---|---|
| Uji Playwright (Edge, viewport 412×860 potret) | **13 uji** dalam 2 berkas (`lobby.spec.ts`, `play.spec.ts`), lihat tabel di bawah |
| Uji unit client (`client/src/logic.test.ts`) | **8 lulus**: jadwal glitch (I20), aturan langkah tutorial (I6–I8), tangan bayangan, demo otomatis, `stripWeights` (A3) |
| `npm test` shared / server | tetap hijau: shared **148**, server **46** (cakupan server: baris 97,53%, cabang 89,2%) |
| `npm run typecheck`, `npm run lint:nodummy`, `npm run build -w client` | bersih / lulus |
| Data acuan | tidak disentuh (`shared/maps`, `shared/intro`, `shared/test/golden`, `reference`) |
| `python3 test_oracle.py` | masih belum dapat dijalankan di mesin ini (DECISIONS no. 10) |

### Kriteria selesai Fase 4

| Kriteria | Uji | Status |
|---|---|---|
| 2 pemain melihat layar READY, menyelesaikan tutorial 5 langkah, dan bermain sampai podium (ronde 1 VISIBLE, 2 HIDDEN + probe, 3 VISIBLE dengan jebakan; semua bintang 3, probe benar) | `play.spec.ts` "2 pemain…" | lulus |
| I16 READY dengan nickname dari server, tanpa peta/node di DOM; PIN ditolak selama intro | `lobby.spec.ts` I16 | lulus (diadaptasi ke alur PIN setelah intro, DECISIONS 33) |
| I17 hitung mundur 3 ≤ 250 ms setelah fase diterima, GO! saat fase berganti, GO! ≤ 600 ms setelah Lewati | I17, I17b | lulus |
| I18 latar tidak berubah, selang burst ≥ 2400 ms | I18 (rekaman 14 detik) | lulus |
| I19 `prefers-reduced-motion`: tanpa burst, tanpa animasi peta, hitung mundur berjalan | I19 | lulus |
| I20 jadwal burst deterministik per `studentId` | `logic.test.ts` | lulus (uji unit) |
| A1 kursi sama → `SEAT_TAKEN`; kursi terisi abu-abu dengan inisial | A1 | lulus |
| A3 HIDDEN setelah WALK: semua lencana "?", bobot 0 di store, tanpa penghitung koin, tanpa `data-w`; juga setelah muat ulang di tengah WALK | "2 pemain…", "sambung ulang" | lulus |
| A5 halaman disembunyikan saat WALK → `focusLost` 1, flag `FOCUS_LOST`, poin = rumus | A5 | lulus |
| A7 rute ≥ 3 langkah < 1000 ms → `TOO_FAST`, poin = rumus | A7 | lulus |
| Ketukan tidak valid bergetar 300 ms (`data-shaking` 1 lalu 0), kurir tidak bergerak | "2 pemain…" (ronde 1 dan tutorial 2) | lulus |
| Angka berubah "?" pada HIDDEN (tutorial 4 setelah 4 detik; ronde HIDDEN saat WALK) | "2 pemain…" | lulus |
| Batal berfungsi (ronde dan tutorial); Batal berkedip + petunjuk setelah salah di langkah 3 | "2 pemain…" | lulus |
| I6 (Sekolah dari Rumah: 1 ketukan tidak valid, jalur tetap [n0]), I7 (jalan pintas 2 koin tidak selesai → "Paket belum lengkap!"; n0→n1→n3→n4 = 6 koin selesai), I8 (n0→n3→n4 = 9 koin, langkah 3 tidak lanjut, `step3Attempts` 2) | "2 pemain…" (UI) + `logic.test.ts` | lulus |
| Tangan bayangan setelah diam 4 detik; `hints` tercatat | "2 pemain…" | lulus |
| Demo otomatis bila tutorial tidak selesai pada batas 90 detik (`completed = false`, `autoDemoSteps` terisi, lanjut ke ronde 1) | "tutorial tidak selesai…" (± 1,5 menit) | lulus |
| Sambung ulang: muat ulang di LOBBY dan di tengah WALK HIDDEN; koneksi diputus lalu pulih tanpa memilih nama lagi | "sambung ulang", "keadaan kosong…" | lulus |
| Keadaan kosong: nama tidak ditemukan, nama sudah dipakai teman | "keadaan kosong…", "nama yang sudah dipilih…" | lulus |

### Temuan nyata dari uji Playwright (sudah diperbaiki)

1. Area ketuk simpul yang besar menutupi simpul tetangga pada peta padat → ketukan ke simpul lain tidak sampai. Perbaikan: dua tata letak peta dan radius ketuk dibatasi jarak ke simpul terdekat (DECISIONS 36).
2. Setelah muat ulang di tengah ronde, peta tidak muncul: server mengirim ulang peta **sebelum** perangkat masuk ke ruangnya. Perbaikan: `resendState` dipanggil setelah `attachPlayer` dan `JoinAck` membawa `phaseState` (DECISIONS 38).
3. Angka hitung mundur sempat menampilkan "4" karena sampel `requestAnimationFrame` lebih awal dari penerimaan fase: sekarang `setInterval` 50 ms dan angka dibatasi 3 (DECISIONS 34).

### Catatan jujur

- **Keluar dari layar penuh (`FULLSCREEN_EXIT`) dan penutup "Kembali ke layar penuh…" belum diuji otomatis**: Edge headless tidak masuk ke layar penuh lewat gerakan pengguna tiruan. Logikanya ada di `client/src/hooks.ts` (`useIntegrity`); perlu dicoba sekali di tablet sungguhan.
- **Berkas font Baloo 2 dan Nunito belum disertakan** (tidak ada izin unduh); tampilan memakai font sistem sampai berkasnya diletakkan di `client/public/fonts/` (DECISIONS 41). Checklist aset produksi tetap terbuka.
- **Tidak ada pengujian pada perangkat sentuh sungguhan**: uji memakai klik mouse pada Edge headless. Ukuran simpul ≥ 64 px dihitung dari tata letak (r = 90 satuan pada layar 360 px = 64,8 px), bukan diukur di HP.
- **Beberapa uji bergantung pada waktu nyata** (hitung mundur, GO!, burst). Pada mesin dengan memori sangat sempit (± 1 GB bebas) uji-uji ini sempat gagal sesekali; asersinya sudah dibuat memakai waktu di dalam halaman (bukan waktu tes) dan urutan angka direkam, bukan di-polling. Hasil putaran penuh terakhir (± 8 menit): **12 dari 13 lulus**; satu uji (alur 2 pemain) gagal karena sebuah klik tutorial melewati batas waktu pada mesin yang sedang kekurangan memori, lalu lulus 2 dari 2 saat diulang sendirian (`--repeat-each=2`, batas aksi dinaikkan ke 20 detik). Semua 13 uji pernah lulus, tetapi belum ada satu putaran penuh yang lulus 13/13 berturut-turut; uji ini lebih aman dijalankan di mesin dengan memori longgar. Sekali `npm test` gagal pada 2 uji `shared` tepat setelah putaran Playwright (kemungkinan batas waktu karena beban) dan lulus 148/148 pada dua kali ulang berikutnya.
- Layar Host (Fase 5) belum ada: pada uji, guru ditiru lewat Socket.IO (`HostDriver`).

## Fase 3 — Server (Express + Socket.IO), dengan alur PIN setelah intro

Dijalankan dengan `npm test` (menjalankan `shared` lalu `server`), `npm run typecheck`, dan `npm run lint:nodummy`.

| Pemeriksaan | Hasil |
|---|---|
| Test `shared` | **148 lulus** (Fase 2: 141; +7 untuk menu pengaturan). Cakupan baris 96,33%, cabang 97,85% (ambang ≥ 95% / ≥ 90%) |
| Test `server` | **46 lulus** dalam 2 berkas: 32 uji sesi tanpa jaringan (jam terkendali) dan 14 uji Socket.IO sungguhan |
| Cakupan `server/src` | baris 97,91% · cabang 89,81% · fungsi 96,77% (ambang server: baris ≥ 90%, cabang ≥ 80%) |
| Waktu `npm test` | ± 2 menit (sebagian besar dari test pembuatan bank `shared`) |
| `npm run typecheck`, `npm run lint:nodummy` | bersih |
| Data acuan | tidak disentuh (`shared/maps`, `shared/intro`, `shared/test/golden`, `reference`) |
| `python3 test_oracle.py` | masih belum dapat dijalankan di mesin ini (DECISIONS no. 10) |

### Kriteria selesai Fase 3

| Kriteria | Berkas test | Status |
|---|---|---|
| 1 host + 3 bot menyelesaikan sesi **FULL Standar**, **FULL Kilat**, **SHORT Standar**, **SHORT Kilat** (intro → PIN → bot masuk → mulai → podium), hasil tersimpan sebagai sesi TEST | `socket.test.ts` | lulus (30, 18, 33, 21 hasil) |
| Tutorial berakhir lebih awal saat semua bot selesai (tanpa menunggu 90 detik) | `session.test.ts` | lulus |
| Ronde 0 tidak dimainkan pada FULL, dimainkan tanpa poin dan tanpa papan peringkat pada SHORT | `session.test.ts`, `socket.test.ts` | lulus |
| Timeout dan missed tercatat benar (timeout = poin 0 dan `tRouteMs = walkMs`; missed = tidak pernah tersambung, poin 0, `playerCost = null`) | `session.test.ts`, `socket.test.ts` | lulus |
| T27 server `NODE_ENV=production`: event pembuat bot tidak dikenal, tidak ada pemain baru | `socket.test.ts` | lulus |
| A2 tidak ada `optimalCost`, `optimalPath`, `probeEdgeId`, atau penanda jawaban di payload ke siswa sebelum `round:reveal` | `session.test.ts` (log keluaran) dan `socket.test.ts` (pada paket yang benar-benar diterima 3 bot di 4 jenis sesi) | lulus |
| A4 kursi bersebelahan (8 arah) mendapat `itemId` berbeda di setiap ronde | `session.test.ts` | lulus |
| A6 token sama dari perangkat kedua ditolak, flag `SECOND_DEVICE`, guru diberi notifikasi | `session.test.ts`, `socket.test.ts` | lulus |
| A8 ganti kursi setelah ronde 1 dimulai → `SEAT_LOCKED` | `session.test.ts` | lulus |

### Permintaan baru yang dikerjakan di fase ini

| Permintaan | Bukti |
|---|---|
| PIN dibuat di dalam game; siswa baru bisa memasukkan PIN **setelah intro** | `NOT_OPEN` saat INTRO_IDENT/INTRO_TRAILER, `lookup` baru berhasil di LOBBY (`session.test.ts`, `socket.test.ts`) |
| Siswa memilih namanya dari daftar siswa (sumber: SIMPETERI), satu nama satu perangkat | `NAME_UNKNOWN`, `NAME_TAKEN`, `ALREADY_CLAIMED`, `releaseName` (`session.test.ts`, `socket.test.ts`) |
| Menunggu sampai dimulai; **permainan hanya boleh dimulai bila kuota terpenuhi** (dan semua sudah memilih kursi bila denah aktif) | `QUOTA_NOT_MET {joined, quota}`, `SEATS_PENDING`; siswa terputus tidak dihitung (`session.test.ts`, `socket.test.ts`) |
| Menu parameter yang dikustomisasi: waktu menghafal, waktu berjalan, waktu probe, ronde khusus, kuota, denah, mode, intro, bank soal | `host:settings` + 7 test `settings.test.ts` (batas nilai, nilai tidak sah ditolak) + fase LOOK/WALK/PROBE mengikuti pengaturan (`session.test.ts`, `socket.test.ts`) |

### Catatan jujur

- Fase 3 hanya memuat server. **Layar siswa (meja jawab di web) dan layar host ada di Fase 4–5**; yang sudah ada sekarang adalah kontrak protokolnya (`shared/src/protocol.ts`) dan perangkat siswa tiruan di folder `server/test/` yang menjalankan protokol itu.
- **Sumber daftar siswa SIMPETERI belum tersambung.** Server menerima daftar siswa (`roster`) dari guru saat `host:create`; pengambilan data dari SIMPETERI (Supabase) dilakukan layar host di Fase 5.
- Pemulihan sesi dari JSONL: data tersimpan dan bisa dibaca (`store.read`), tetapi server belum melanjutkan sesi yang terputus secara otomatis.
- Flag `FOCUS_LOST`, `FULLSCREEN_EXIT`, `TOO_FAST`, `SEAT_CHANGED`, dan `SECOND_DEVICE` diuji sisi server. Uji peramban A5 dan A7 tetap di Fase 4.
- Hasil yang gagal integritas tercatat di `data/rejected/` dan tidak masuk hasil maupun poin (diuji dengan rute yang dimanipulasi).

---
## Fase 2 — Validator, varian, distribusi kursi, generator, data acuan (diperbarui)

Dijalankan dengan `npm test` (Vitest 3 + cakupan v8), `npm run typecheck`, dan `npm run lint:nodummy`.

| Pemeriksaan | Hasil |
|---|---|
| Berkas uji | 13 |
| Jumlah test | **141 lulus, 0 gagal** (Fase 1: 84; Fase 2 menambah 57) |
| Waktu `npm test` | ± 65 detik |
| Cakupan `shared/src` | pernyataan 95,95% · **baris 95,95%** · fungsi 98,54% · **cabang 97,58%** (ambang: baris ≥ 95%, cabang ≥ 90%) |
| Properti fast-check | 6 properti × 500 kasus lulus, termasuk properti varian (0–7 menjaga `optimalCost` dan tanpa perpotongan) |
| `npm run typecheck` | bersih |
| `npm run lint:nodummy` | lulus |
| Data acuan (`shared/maps`, `shared/intro`, `shared/test/golden`, `reference`) | 16 berkas, SHA-256 identik dengan `route-rush.zip` |
| Folder `shared/maps` | tidak bertambah berkas (hanya formA/B, poolA/B, tutorial) |
| `python3 test_oracle.py` (65/65) | **masih belum dapat dijalankan**: Python tidak terpasang di mesin ini (lihat DECISIONS no. 10) |

### Kriteria selesai Fase 2

| Kasus | Berkas test | Status |
|---|---|---|
| T19 (8 varian × 22 peta bank: `optimalCost` tetap, id tetap, koordinat 0..1, tanpa edge berpotongan) | `variant-distribution.test.ts` | lulus |
| T20 (22 peta bank lolos V1–V9 termasuk V7 berpasangan; 82 soal pool lolos) | `validator.test.ts` | lulus |
| T20b (dua rute optimal → V2; edge berpotongan → V6; bobot 0/10/2,5 → V9) | `validator.test.ts` | lulus; ditambah negatif untuk V1, V3, V4, V5, V6-jarak, V7, V8, V9-stop, V9-probe |
| T24 (golden: `optimalCost`, `optimalRoute`, `minHops`, `secondBestGap`, urutan stop, `probeEdgeId` untuk 22 peta + 5 peta tutorial) | `pool-data.test.ts` | lulus |
| I1 (8000 / 45000 / 3000 / 12000 ms) | `pool-data.test.ts` | lulus |
| I2 (shot bersambung) | `pool-data.test.ts` | lulus |
| I3 (angka shot 5 dihitung dari A-05: 9 dan 8) | `pool-data.test.ts` | lulus |
| I4 (tidak ada angka koin literal di `timeline.json`) | `pool-data.test.ts` | lulus |
| I5 (tutorial lolos validator, hanya T-01 dikecualikan V3; optimal 5, 3, 7, 4, 6) | `validator.test.ts`, `pool-data.test.ts` | lulus |
| I6, I7, I8 | `route.test.ts` (Fase 1) | lulus |
| P1 (41 soal per pool, lolos V1–V9) · P2 · P3 · P4 | `pool-data.test.ts` (`checkPool`, ditambah 5 test negatif) | lulus |
| P5 (`pool_golden.json`, 82 soal) | `solver.test.ts`, `pool-data.test.ts` | lulus |
| P6 (0 soal kembar Pool A vs B) | `pool-data.test.ts` | lulus |
| P7 (tetangga 8 arah, denah ≤ 8 × 10, 24 permutasi × 4 offset × 11 ronde: 283.008 pasang) | `variant-distribution.test.ts` | lulus |
| P8 / P8b (Standar 2–3 kali, Kilat maks 2 kali) | `variant-distribution.test.ts` | lulus |
| P9 (tanpa denah, urutan masuk berurutan beda soal) | `variant-distribution.test.ts` | lulus |
| P10 (radius 2 kursi, soal sama selalu beda varian) | `variant-distribution.test.ts` | lulus |
| 20 peta hasil generator TypeScript dengan seed berbeda lolos validator | `generator.test.ts` | lulus (20 dari 20, mencakup semua 11 jenis ronde) |
| `scripts/gen-pool.ts` menolak menimpa berkas | `generator.test.ts`, `gen-pool-script.test.ts` | lulus: tanpa seed → kode 2; Pool A/B → ditolak; berkas ada → ditolak dan isinya tidak berubah |

### Catatan jujur

- **`poolBuilder.ts` hanya 47% terukur oleh cakupan.** Pembuatan satu bank penuh butuh ± 36 detik pada kecepatan asli dan lebih dari 10 menit bila dijalankan di dalam proses berinstrumen cakupan, sehingga jalur suksesnya diuji lewat `gen-pool-script.test.ts`, yang menjalankan skrip di proses terpisah: menghasilkan 41 soal, lolos `checkPool` (P1–P4), ditulis ke folder sementara, lalu menolak ditimpa. Jalur itu lulus tetapi tidak terhitung dalam angka cakupan.
- Bank buatan generator TypeScript tidak sama dengan JSON oracle Python (memang tidak diwajibkan, Bagian 8.2); yang diwajibkan adalah validator dan pemeriksa kesetaraan TypeScript meluluskan 22 peta fixture dan 82 soal pool, dan itu terpenuhi.
- Python/oracle belum dijalankan (butuh mesin lain).

### Belum termasuk Fase 2 (sengaja)

T26, T27, A1–A9, I9–I20 (server, client, Playwright: Fase 3–8).

---

## Fase 1 — Logika inti (ringkasan)

84 test, cakupan baris 100%, T1–T18b, T21–T25, S1–S4, properti 0A.5, `lint:nodummy` diuji negatif. Rincian pemetaan ada di riwayat laporan sebelumnya dan semua test tersebut masih lulus.

## Tambahan: UI elegan, Tantangan adaptif, laporan, hapus siswa (3 November 2026)
- Tes otomatis: shared 208, server 70 (termasuk `adaptive.test.ts`: naik tingkat, statistik layar hasil, hapus siswa), client 34; e2e 29 lolos (termasuk `report.spec.ts`: hasil proyektor, laporan cari/urut/hapus, endpoint ringkasan). Uji kinerja intro (CPU 4×) tidak dijalankan ulang pada putaran ini.
- Dua kegagalan di putaran penuh ditelusuri: gambar acuan intro berubah karena skala layar guru dan font global menyentuh intro (diperbaiki: intro dikecualikan dari skala dan tidak memakai font baru), dan satu uji alur pemain yang lolos bila dijalankan sendiri (beban bersamaan).
- Belum diverifikasi: tampilan cetak PDF (`window.print()` ke "Simpan sebagai PDF") dan `report.html` pada banyak siswa (>40) hanya diuji lewat CSS cetak, belum dilihat sebagai berkas PDF; adaptivitas Tantangan belum diuji dengan kelas sungguhan.
## Server online (keputusan 95)
- Tes: server 78 (termasuk `config.test.ts`: pembacaan variabel lingkungan, `/health`, header keamanan, CORS Socket.IO per asal), shared 209, client 34, SIMPETERI 16 pada berkas Route Rush; e2e lolos (22 dari putaran penuh dan 7 yang diulang setelah log `port N` dikembalikan, karena `client/e2e/support.ts` membacanya).
- Diuji nyata: `NODE_ENV=production PORT=8099 DATA_DIR=... npm start` → `/health`, `/`, `/host` menjawab 200 dan folder data dibuat.
- Belum diuji: build Docker (Docker tidak terpasang di mesin ini), deploy ke Fly/Render/Railway, https dan WebSocket lewat proxy sungguhan, dan kelas sungguhan lewat internet. `npx tsc` SIMPETERI melaporkan galat di `src/integrations/supabase/types.ts` yang sudah ada sebelumnya dan tidak terkait.
- Batas yang diketahui: satu instance; sesi yang sedang berjalan hilang bila server dimulai ulang.
/**
 * Memproses rekaman narasi (VO) menjadi aset siap putar.
 *
 *   1. Rekam/hasilkan 12 kalimat di assets/audio/vo/SCRIPT.md (mis. dengan suara ElevenLabs yang sama dengan klip nama).
 *   2. Simpan hasilnya di assets/audio/vo/source/<id>.mp3 (atau .wav, .m4a), mis. shot-03.mp3, short.mp3, tutorial-1.mp3.
 *   3. Jalankan:  npx tsx scripts/build-vo.ts [--dir <folder>] [--strict]
 *
 * Tiap berkas didekode (Edge terpasang, tanpa ffmpeg), dipangkas keheningannya, dinormalkan ke −16 LUFS, diperiksa muat
 * di jendela adegannya, lalu ditulis ke assets/audio/vo/<id>.wav. `--strict` gagal bila ada kalimat yang belum direkam.
 */
import { existsSync, readdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { parseTimeline, voScript } from "@route-rush/shared";
import { integratedLufs, peakDb } from "./audio/lufs";
import { encodeWav } from "./audio/wav";
import { decode, downsample, normalize, trimSilence } from "./build-answer-audio";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const arg = (n: string): string | undefined => {
  const i = process.argv.indexOf(n);
  return i >= 0 ? process.argv[i + 1] : undefined;
};
const dir = resolve(arg("--dir") ?? resolve(root, "assets/audio/vo"));
const strict = process.argv.includes("--strict");

const tl = parseTimeline(JSON.parse(readFileSync(resolve(root, "shared/intro/timeline.json"), "utf8")));
const lines = voScript(tl);
const sourceDir = resolve(dir, "source");
const files = existsSync(sourceDir) ? readdirSync(sourceDir) : [];
const missing: string[] = [];
const tooLong: string[] = [];
const done: { id: string; seconds: number; lufs: number; peakDb: number }[] = [];

for (const line of lines) {
  const f = files.find((n) => new RegExp(`^${line.id}\\.(mp3|wav|m4a|ogg|opus)$`, "i").test(n));
  if (!f) {
    missing.push(line.id);
    continue;
  }
  const d = decode(resolve(sourceDir, f));
  const factor = d.sampleRate >= 44100 ? 2 : 1;
  const fs = d.sampleRate / factor;
  const x = normalize(downsample(trimSilence(d.samples, d.sampleRate, 0.04), factor), fs);
  const seconds = x.length / fs;
  if (seconds > line.maxSeconds) tooLong.push(`${line.id}: ${seconds.toFixed(2)} s > ${line.maxSeconds} s (${line.where})`);
  writeFileSync(resolve(dir, `${line.id}.wav`), encodeWav(x, fs));
  done.push({ id: line.id, seconds: +seconds.toFixed(2), lufs: +integratedLufs(x, fs).toFixed(1), peakDb: +peakDb(x).toFixed(1) });
}
writeFileSync(resolve(dir, "index.json"), JSON.stringify({ lines: done, missing }, null, 2) + "\n");
console.table(done);
if (missing.length) console.warn(`Belum direkam (${missing.length}): ${missing.join(", ")}`);
if (tooLong.length) {
  console.error(`Terlalu panjang untuk jendelanya:\n${tooLong.join("\n")}`);
  process.exit(1);
}
if (strict && missing.length) process.exit(1);
/**
 * Gerbang build produksi (Bagian 0A.1 dan Fase 7): gagal bila masih ada aset sementara atau aset wajib yang belum ada.
 * Dipanggil oleh `npm run build`; `npm run build:dev` melewatinya untuk pengembangan dan uji.
 */
import { existsSync, readFileSync, readdirSync, statSync } from "node:fs";
import { dirname, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const problems = [];
const rel = (p) => relative(root, p).replaceAll("\\", "/");

// 1. daftar aset sementara harus kosong (baris tabel selain judul dan pemisah)
const ph = resolve(root, "assets", "PLACEHOLDERS.md");
if (!existsSync(ph)) problems.push("assets/PLACEHOLDERS.md tidak ada");
else {
  const rows = readFileSync(ph, "utf8")
    .split(/\r?\n/)
    .filter((l) => l.trim().startsWith("|") && !/^\|\s*-+/.test(l.trim()) && !/^\|\s*Berkas\s*\|/i.test(l.trim()));
  for (const r of rows) problems.push(`aset sementara masih terdaftar: ${r.trim()}`);
}

// 2. aset wajib
const need = ["assets/brand/logo.svg", "assets/brand/name.txt", "assets/audio/music.wav", "assets/audio/mix.json", "assets/audio/LICENSES.md", "LICENSES.md"];
for (const f of need) if (!existsSync(resolve(root, f))) problems.push(`berkas wajib tidak ada: ${f}`);
for (const f of ["ProductSans-Regular.ttf", "ProductSans-Medium.ttf", "ProductSans-Bold.ttf", "ProductSans-Black.ttf", "PlusJakartaSans-Variable.ttf"]) if (!existsSync(resolve(root, "client/public/fonts", f))) problems.push(`font lokal tidak ada: client/public/fonts/${f}`);
// narasi: keputusan pemilik proyek = suara peramban (Web Speech API), jadi rekaman di assets/audio/vo/ bersifat opsional
// 3. LICENSES.md audio harus menyebut setiap berkas audio
const lic = resolve(root, "assets/audio/LICENSES.md");
if (existsSync(lic)) {
  const text = readFileSync(lic, "utf8");
  const walk = (d) => readdirSync(d).flatMap((n) => (statSync(resolve(d, n)).isDirectory() ? walk(resolve(d, n)) : [resolve(d, n)]));
  for (const f of walk(resolve(root, "assets/audio")).filter((x) => /\.(wav|opus|ogg|mp3)$/.test(x))) {
    const name = f.split(/[\\/]/).pop();
    if (!text.includes(name)) problems.push(`assets/audio/LICENSES.md tidak menyebut ${rel(f)}`);
  }
}

// 3b. klip suara nama dipilih lewat nomor absen dari SIMPETERI; names.txt hanya cadangan untuk daftar manual tanpa absen
{
  const clips = resolve(root, "assets/audio/names/clips.json");
  if (!existsSync(clips)) problems.push("assets/audio/names/clips.json tidak ada (jalankan scripts/build-answer-audio.ts)");
}

// 4. nama pembuat tidak boleh nilai sementara
const nm = resolve(root, "assets/brand/name.txt");
if (existsSync(nm) && /NAMA PEMBUAT/i.test(readFileSync(nm, "utf8"))) problems.push("assets/brand/name.txt masih berisi nilai sementara");

if (problems.length) {
  console.error(`Build produksi DITOLAK (${problems.length} masalah):`);
  for (const p of problems) console.error(" - " + p);
  process.exit(1);
}
console.log("Pemeriksaan aset produksi lulus.");
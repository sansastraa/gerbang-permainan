/**
 * Membuat bank soal paralel baru (Pool C, D, …) yang memenuhi syarat 8.5.
 *   npx tsx scripts/gen-pool.ts --seed RR-POOL-C [--samples 500] [--out shared/maps/poolC.json]
 * Tidak pernah menimpa berkas yang sudah ada, dan tidak boleh membuat ulang Pool A/B.
 */
import { existsSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { buildPool, checkPool } from "../shared/src/index";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

const seed = arg("seed");
if (!seed) {
  console.error("Pakai: gen-pool.ts --seed RR-POOL-C [--samples 500] [--out berkas.json]");
  process.exit(2);
}
const letter = seed.slice(-1);
if (letter === "A" || letter === "B") {
  console.error(`DITOLAK: Pool ${letter} adalah data acuan dan tidak boleh dibuat ulang.`);
  process.exit(1);
}
const out = resolve(root, arg("out") ?? `shared/maps/pool${letter}.json`);
if (existsSync(out)) {
  console.error(`DITOLAK: ${out} sudah ada dan tidak akan ditimpa.`);
  process.exit(1);
}

const samples = Number(arg("samples") ?? 500);
const started = Date.now();
const pool = buildPool(seed, { samples });
const check = checkPool(pool);
if (!check.ok) {
  console.error("Bank gagal pemeriksaan kesetaraan:\n" + check.issues.join("\n"));
  process.exit(3);
}
writeFileSync(out, JSON.stringify({ ...pool, generatedBy: "scripts/gen-pool.ts" }, null, 2) + "\n", { encoding: "utf8", flag: "wx" });
console.log(`Pool ${letter} dibuat: ${pool.rounds.reduce((n, r) => n + r.items.length, 0)} soal dalam ${((Date.now() - started) / 1000).toFixed(1)} dtk → ${out}`);

/** Kenyaringan terpadu ITU-R BS.1770-4 / EBU R128 untuk sinyal mono (tanpa ffmpeg). */

interface Biquad {
  b: [number, number, number];
  a: [number, number];
}

function kWeighting(fs: number): Biquad[] {
  // tahap 1: rak tinggi
  const f1 = 1681.974450955533;
  const G = 3.999843853973347;
  const Q1 = 0.7071752369554196;
  const K1 = Math.tan((Math.PI * f1) / fs);
  const Vh = 10 ** (G / 20);
  const Vb = Vh ** 0.4996667741545416;
  const a0 = 1 + K1 / Q1 + K1 * K1;
  const s1: Biquad = {
    b: [(Vh + (Vb * K1) / Q1 + K1 * K1) / a0, (2 * (K1 * K1 - Vh)) / a0, (Vh - (Vb * K1) / Q1 + K1 * K1) / a0],
    a: [(2 * (K1 * K1 - 1)) / a0, (1 - K1 / Q1 + K1 * K1) / a0],
  };
  // tahap 2: lolos-tinggi RLB
  const f2 = 38.13547087602444;
  const Q2 = 0.5003270373238773;
  const K2 = Math.tan((Math.PI * f2) / fs);
  const c0 = 1 + K2 / Q2 + K2 * K2;
  const s2: Biquad = { b: [1, -2, 1], a: [(2 * (K2 * K2 - 1)) / c0, (1 - K2 / Q2 + K2 * K2) / c0] };
  return [s1, s2];
}

function filter(x: Float32Array | Float64Array, q: Biquad): Float64Array {
  const y = new Float64Array(x.length);
  let x1 = 0;
  let x2 = 0;
  let y1 = 0;
  let y2 = 0;
  for (let i = 0; i < x.length; i++) {
    const xi = x[i] as number;
    const yi = q.b[0] * xi + q.b[1] * x1 + q.b[2] * x2 - q.a[0] * y1 - q.a[1] * y2;
    x2 = x1;
    x1 = xi;
    y2 = y1;
    y1 = yi;
    y[i] = yi;
  }
  return y;
}

/** Kenyaringan terpadu (LUFS); -Infinity bila terlalu sunyi atau terlalu pendek. */
export function integratedLufs(samples: Float32Array, fs: number): number {
  let y: Float64Array = Float64Array.from(samples);
  for (const q of kWeighting(fs)) y = filter(y, q);
  const block = Math.round(0.4 * fs);
  const hop = Math.round(0.1 * fs);
  const z: number[] = [];
  for (let s = 0; s + block <= y.length; s += hop) {
    let sum = 0;
    for (let i = s; i < s + block; i++) sum += (y[i] as number) ** 2;
    z.push(sum / block);
  }
  const lk = (m: number): number => -0.691 + 10 * Math.log10(m);
  const abs = z.filter((m) => lk(m) > -70);
  if (abs.length === 0) return -Infinity;
  const mean = abs.reduce((a, b) => a + b, 0) / abs.length;
  const rel = abs.filter((m) => lk(m) > lk(mean) - 10);
  if (rel.length === 0) return -Infinity;
  return lk(rel.reduce((a, b) => a + b, 0) / rel.length);
}

/** Puncak sampel dalam dBFS. */
export function peakDb(samples: Float32Array): number {
  let p = 0;
  for (const s of samples) p = Math.max(p, Math.abs(s));
  return p === 0 ? -Infinity : 20 * Math.log10(p);
}
/** Kenyaringan momentary (blok 400 ms) tertinggi, dalam LUFS. */
export function maxMomentaryLufs(samples: Float32Array, fs: number): number {
  let y: Float64Array = Float64Array.from(samples);
  for (const q of kWeighting(fs)) y = filter(y, q);
  const block = Math.round(0.4 * fs);
  const hop = Math.round(0.1 * fs);
  let best = -Infinity;
  for (let s = 0; s + block <= y.length; s += hop) {
    let sum = 0;
    for (let i = s; i < s + block; i++) sum += (y[i] as number) ** 2;
    best = Math.max(best, -0.691 + 10 * Math.log10(sum / block + 1e-20));
  }
  return best;
}
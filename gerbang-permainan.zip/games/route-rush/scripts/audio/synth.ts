import { mulberry32, type SfxName } from "@route-rush/shared";
import { SR } from "./wav";

/** Sintesis orisinal (tanpa sampel pihak ketiga): semua suara dihitung dari rumus di berkas ini dengan PRNG ber-seed. */

const TAU = Math.PI * 2;
const mtof = (m: number): number => 440 * 2 ** ((m - 69) / 12);
const buf = (sec: number): Float32Array => new Float32Array(Math.round(sec * SR));
const env = (t: number, attack: number, decay: number): number => Math.min(1, t / attack) * Math.exp(-t / decay);

function add(dst: Float32Array, src: Float32Array, atSec: number, gain = 1): void {
  const off = Math.round(atSec * SR);
  for (let i = 0; i < src.length && off + i < dst.length; i++) if (off + i >= 0) dst[off + i] = (dst[off + i] as number) + (src[i] as number) * gain;
}

/** Petikan bergaya piano: harmonik dengan peluruhan makin cepat ke atas. */
function pluck(freq: number, sec: number, decay = 1.1): Float32Array {
  const out = buf(sec);
  const harm = [1, 0.55, 0.3, 0.18, 0.1, 0.06];
  for (let i = 0; i < out.length; i++) {
    const t = i / SR;
    let v = 0;
    harm.forEach((a, h) => {
      v += a * Math.sin(TAU * freq * (h + 1) * t) * Math.exp(-t / (decay / (1 + h * 0.8)));
    });
    out[i] = v * Math.min(1, t / 0.004) * 0.35;
  }
  return out;
}

function sine(freq: number, sec: number, decay: number, attack = 0.005, h2 = 0): Float32Array {
  const out = buf(sec);
  for (let i = 0; i < out.length; i++) {
    const t = i / SR;
    out[i] = (Math.sin(TAU * freq * t) + h2 * Math.sin(TAU * freq * 2 * t)) * env(t, attack, decay);
  }
  return out;
}

function noise(sec: number, seed: number): Float32Array {
  const r = mulberry32(seed);
  const out = buf(sec);
  for (let i = 0; i < out.length; i++) out[i] = r() * 2 - 1;
  return out;
}

const lowpass = (x: Float32Array, hz: number): Float32Array => {
  const a = 1 - Math.exp((-TAU * hz) / SR);
  const y = new Float32Array(x.length);
  let s = 0;
  for (let i = 0; i < x.length; i++) {
    s += a * ((x[i] as number) - s);
    y[i] = s;
  }
  return y;
};
const highpass = (x: Float32Array, hz: number): Float32Array => {
  const lp = lowpass(x, hz);
  return x.map((v, i) => v - (lp[i] as number));
};
const shape = (x: Float32Array, f: (t: number) => number): Float32Array => x.map((v, i) => v * f(i / SR));

// ---------------------------------------------------------------- efek suara

export function synthSfx(name: SfxName): Float32Array {
  switch (name) {
    case "hum":
      return shape(sine(55, 1.1, 99, 0.2, 0.5), (t) => Math.min(1, t / 0.9) * 0.7);
    case "coin": {
      const o = buf(0.5);
      add(o, sine(1318, 0.5, 0.12, 0.002, 0.3), 0, 0.6);
      add(o, sine(1975, 0.5, 0.2, 0.002, 0.2), 0.07, 0.6);
      return o;
    }
    case "pop": {
      const o = buf(0.18);
      for (let i = 0; i < o.length; i++) {
        const t = i / SR;
        o[i] = Math.sin(TAU * (900 - 5000 * t) * t) * Math.exp(-t / 0.04);
      }
      return o;
    }
    case "whoosh":
      return shape(lowpass(highpass(noise(0.9, 11), 300), 2500), (t) => Math.sin((Math.PI * t) / 0.9) ** 2 * 0.8);
    case "click": {
      const o = buf(0.25);
      add(o, shape(highpass(noise(0.03, 5), 1500), (t) => Math.exp(-t / 0.006)), 0, 0.9);
      add(o, shape(highpass(noise(0.03, 6), 1800), (t) => Math.exp(-t / 0.006)), 0.09, 0.6);
      add(o, sine(240, 0.1, 0.03, 0.001), 0.09, 0.4);
      return o;
    }
    case "wrong": {
      const o = buf(0.8);
      add(o, sine(262, 0.5, 0.22, 0.01, 0.3), 0, 0.5);
      add(o, sine(208, 0.6, 0.28, 0.01, 0.3), 0.22, 0.5);
      return o;
    }
    case "right": {
      const o = buf(0.9);
      add(o, sine(523, 0.5, 0.2, 0.005, 0.4), 0, 0.5);
      add(o, sine(784, 0.8, 0.35, 0.005, 0.4), 0.14, 0.55);
      add(o, sine(1047, 0.8, 0.45, 0.005, 0.2), 0.28, 0.4);
      return o;
    }
    case "heartbeat": {
      const o = buf(0.9);
      const thump = (f: number): Float32Array => shape(sine(f, 0.3, 0.06, 0.004), (t) => 1 + 0 * t);
      add(o, thump(55), 0, 1);
      add(o, thump(48), 0.28, 0.8);
      return o;
    }
    case "title": {
      const o = buf(1.6);
      add(o, sine(46, 1.4, 0.35, 0.003, 0.5), 0, 1);
      add(o, shape(highpass(noise(1.6, 21), 3000), (t) => env(t, 0.01, 0.5)), 0.02, 0.35);
      return o;
    }
    case "logo": {
      const o = buf(1.6);
      [523, 659, 784].forEach((f, i) => add(o, sine(f, 1.2, 0.5, 0.01, 0.25), i * 0.22, 0.5));
      return o;
    }
    case "scooter": {
      const n = highpass(noise(2.4, 31), 120);
      const o = shape(lowpass(n, 700), (t) => Math.min(1, t / 0.4) * Math.min(1, (2.4 - t) / 0.5) * (0.5 + 0.2 * Math.sin(TAU * 38 * t)));
      return o;
    }
    case "city": {
      return shape(lowpass(noise(4, 41), 500), (t) => Math.min(1, t / 0.8) * Math.min(1, (4 - t) / 0.8) * 0.5);
    }
    case "kick":
      return kick(0.4);
  }
}

function kick(sec: number): Float32Array {
  const o = buf(sec);
  for (let i = 0; i < o.length; i++) {
    const t = i / SR;
    o[i] = Math.sin(TAU * (45 + 90 * Math.exp(-t / 0.03)) * t) * Math.exp(-t / 0.12);
  }
  return o;
}

// ---------------------------------------------------------------- musik 45 detik, 100 BPM

const BEAT = 0.6;
const BAR = BEAT * 4;
/** Akor per birama: C, Am, F, G (akar MIDI, intervalnya mayor/minor). */
const PROG: { root: number; third: number }[] = [
  { root: 48, third: 4 },
  { root: 45, third: 3 },
  { root: 41, third: 4 },
  { root: 43, third: 4 },
];

export function synthMusic(totalSec = 45): Float32Array {
  const out = buf(totalSec);
  const rnd = mulberry32(2026);
  const bars = Math.ceil(totalSec / BAR);
  for (let b = 0; b < bars; b++) {
    const ch = PROG[b % 4] as { root: number; third: number };
    const t0 = b * BAR;
    const tones = [ch.root + 12, ch.root + 12 + ch.third, ch.root + 19, ch.root + 24];
    const vel = 0.5 + 0.5 * Math.min(1, t0 / 33);
    // piano: akor pelan di awal (sampai detik 9), lalu arpeggio per delapanan
    if (t0 < 9) {
      tones.slice(0, 3).forEach((m, i) => add(out, pluck(mtof(m), 2.6, 1.6), t0 + i * 0.05, 0.7 * vel));
    } else {
      for (let e = 0; e < 8; e++) {
        const m = tones[[0, 1, 2, 3, 2, 1, 2, 1][e] as number] as number;
        add(out, pluck(mtof(m), 1.2, 0.9), t0 + e * (BEAT / 2) + (rnd() - 0.5) * 0.008, vel);
      }
    }
    // bas mulai detik 13
    if (t0 >= 13) for (let k = 0; k < 4; k++) add(out, sine(mtof(ch.root - 12), 0.5, 0.2, 0.01, 0.4), t0 + k * BEAT, 0.5 * vel);
    // pad mulai detik 18, makin penuh menuju puncak
    if (t0 >= 18) {
      const pad = buf(BAR + 0.3);
      [ch.root + 12, ch.root + 12 + ch.third, ch.root + 19].forEach((m) => {
        for (let i = 0; i < pad.length; i++) {
          const t = i / SR;
          pad[i] = (pad[i] as number) + (Math.sin(TAU * mtof(m) * t) + 0.5 * Math.sin(TAU * mtof(m) * 1.003 * t)) * Math.min(1, t / 0.5) * Math.min(1, (BAR + 0.3 - t) / 0.3) * 0.07;
        }
      });
      add(out, pad, t0, 0.5 + 0.8 * Math.min(1, (t0 - 18) / 15));
    }
  }
  // drum masuk detik 28
  const kk = kick(0.4);
  const snare = (): Float32Array => {
    const o = buf(0.25);
    const n = highpass(noise(0.25, 51), 800);
    for (let i = 0; i < o.length; i++) o[i] = ((n[i] as number) * 0.8 + Math.sin(TAU * 190 * (i / SR)) * 0.4) * Math.exp(-(i / SR) / 0.06);
    return o;
  };
  const hat = (): Float32Array => shape(highpass(noise(0.06, 61), 6000), (t) => Math.exp(-t / 0.015));
  for (let t = 28; t < totalSec - 1; t += BEAT / 2) {
    const beat = Math.round((t - 28) / (BEAT / 2));
    if (beat % 2 === 0) add(out, kk, t, 0.9);
    if (beat % 4 === 2) add(out, snare(), t, 0.7);
    add(out, hat(), t, 0.25);
  }
  // sebelum masuk: gulungan snare singkat (detik 27,4–28)
  for (let k = 0; k < 4; k++) add(out, snare(), 27.45 + k * 0.15, 0.35 + k * 0.1);
  // puncak detik 33: simbal
  add(out, shape(highpass(noise(2.2, 71), 4000), (t) => env(t, 0.005, 0.7)), 33, 0.5);
  add(out, kk, 33, 1);
  // keluar halus
  const fade = Math.round(1.5 * SR);
  for (let i = 0; i < fade; i++) out[out.length - 1 - i] = (out[out.length - 1 - i] as number) * (i / fade);
  return out;
}

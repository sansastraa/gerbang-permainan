import { introAudioPlan, musicGainAt, type IntroAudioPlan, type IntroMode, type IntroTimeline, type SfxName } from "@route-rush/shared";
import { integratedLufs, maxMomentaryLufs } from "./lufs";
import { SR } from "./wav";

export interface MixAssets {
  music: Float32Array;
  sfx: Record<SfxName, Float32Array>;
}
export interface MixCfg {
  music: number;
  sfx: number;
}
export type MixKey = "IDENT_FULL" | "IDENT_SHORT" | "TRAILER_FULL" | "TRAILER_SHORT";
export type MixConfig = Record<MixKey, MixCfg>;

export const TARGET_LUFS = -16;

export const mixKey = (kind: "IDENT" | "TRAILER", mode: IntroMode): MixKey => `${kind}_${mode}`;

/** Durasi fase intro (ms) menurut jenis dan mode. */
export function phaseDuration(tl: IntroTimeline, kind: "IDENT" | "TRAILER", mode: IntroMode): number {
  if (kind === "IDENT") return mode === "FULL" ? (tl.ident[tl.ident.length - 1] as { endMs: number }).endMs : tl.identShort.toMs - tl.identShort.fromMs;
  return mode === "FULL" ? (tl.trailer[tl.trailer.length - 1] as { endMs: number }).endMs : (tl.trailerShort[tl.trailerShort.length - 1] as { endMs: number }).endMs;
}

/** Pembatas lembut: linear di bawah 0,6, lalu menekuk mulus ke langit-langit 0,89 (−1 dBFS); tidak pernah terpotong keras. */
export const softLimit = (x: number): number => {
  const a = Math.abs(x);
  return a < 0.6 ? x : Math.sign(x) * (0.6 + 0.29 * Math.tanh((a - 0.6) / 0.29));
};

/** Merender campuran (musik + efek) satu fase seperti yang akan diputar di proyektor. Narasi manusia belum termasuk. */
export function renderMix(plan: IntroAudioPlan, assets: MixAssets, cfg: MixCfg, durationMs: number, only: "all" | "music" | "sfx" = "all"): Float32Array {
  const out = new Float32Array(Math.round((durationMs / 1000) * SR));
  if (plan.music && only !== "sfx") {
    const off = Math.round((plan.music.fromMs / 1000) * SR);
    for (let i = 0; i < out.length; i++) {
      const src = assets.music[off + i];
      if (src === undefined) break;
      out[i] = (out[i] as number) + src * cfg.music * musicGainAt(plan, (i / SR) * 1000);
    }
  }
  if (only !== "music") {
    for (const cue of plan.cues) {
      const s = assets.sfx[cue.sfx];
      const start = Math.round((cue.ms / 1000) * SR);
      for (let i = 0; ; i++) {
        const pos = i * cue.rate;
        const k = Math.floor(pos);
        if (k + 1 >= s.length || start + i >= out.length) break;
        const v = (s[k] as number) * (1 - (pos - k)) + (s[k + 1] as number) * (pos - k);
        out[start + i] = (out[start + i] as number) + v * cue.gain * cfg.sfx;
      }
    }
  }
  if (only === "all") for (let i = 0; i < out.length; i++) out[i] = softLimit(out[i] as number);
  return out;
}

/** Mencari penguatan agar campuran −16 LUFS dan tidak ada efek yang lebih dari +3 dB di atas musik (batas spek: 6 dB). */
export function calibrate(tl: IntroTimeline, kind: "IDENT" | "TRAILER", mode: IntroMode, edgeCount: number, assets: MixAssets): MixCfg {
  const plan = introAudioPlan(tl, kind, mode, edgeCount);
  const dur = phaseDuration(tl, kind, mode);
  let rel = 1;
  if (plan.music) {
    const lm = integratedLufs(renderMix(plan, assets, { music: 1, sfx: 1 }, dur, "music"), SR);
    const ms = maxMomentaryLufs(renderMix(plan, assets, { music: 1, sfx: 1 }, dur, "sfx"), SR);
    rel = Math.min(1.5, 10 ** ((lm + 3 - ms) / 20));
  }
  let cfg: MixCfg = { music: plan.music ? 1 : 0, sfx: rel };
  // pembatas membuat hubungan penguatan–kenyaringan tidak linear, maka diulang sampai −16 LUFS (± 0,05)
  for (let i = 0; i < 12; i++) {
    const l = integratedLufs(renderMix(plan, assets, cfg, dur), SR);
    if (Math.abs(l - TARGET_LUFS) < 0.05) break;
    const s = 10 ** ((TARGET_LUFS - l) / 20);
    cfg = { music: cfg.music * s, sfx: cfg.sfx * s };
  }
  return cfg;
}
import { readFileSync, writeFileSync } from "node:fs";

export const SR = 22050;

/** WAV PCM 16-bit mono. */
export function encodeWav(samples: Float32Array, sampleRate = SR): Buffer {
  const data = Buffer.alloc(samples.length * 2);
  for (let i = 0; i < samples.length; i++) data.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round((samples[i] as number) * 32767))), i * 2);
  const head = Buffer.alloc(44);
  head.write("RIFF", 0);
  head.writeUInt32LE(36 + data.length, 4);
  head.write("WAVEfmt ", 8);
  head.writeUInt32LE(16, 16);
  head.writeUInt16LE(1, 20);
  head.writeUInt16LE(1, 22);
  head.writeUInt32LE(sampleRate, 24);
  head.writeUInt32LE(sampleRate * 2, 28);
  head.writeUInt16LE(2, 32);
  head.writeUInt16LE(16, 34);
  head.write("data", 36);
  head.writeUInt32LE(data.length, 40);
  return Buffer.concat([head, data]);
}

export function decodeWav(buf: Buffer): { samples: Float32Array; sampleRate: number } {
  if (buf.toString("ascii", 0, 4) !== "RIFF" || buf.toString("ascii", 8, 12) !== "WAVE") throw new Error("bukan WAV");
  const sampleRate = buf.readUInt32LE(24);
  if (buf.readUInt16LE(20) !== 1 || buf.readUInt16LE(22) !== 1 || buf.readUInt16LE(34) !== 16) throw new Error("hanya PCM 16-bit mono");
  const n = buf.readUInt32LE(40) / 2;
  const samples = new Float32Array(n);
  for (let i = 0; i < n; i++) samples[i] = buf.readInt16LE(44 + i * 2) / 32767;
  return { samples, sampleRate };
}

export const writeWav = (path: string, samples: Float32Array): void => writeFileSync(path, encodeWav(samples));
export const readWav = (path: string): { samples: Float32Array; sampleRate: number } => decodeWav(readFileSync(path));
/**
 * Membuat aset audio intro secara sintetis dan orisinal: bahan (musik 45 detik 100 BPM + 13 efek suara) di assets/audio/,
 * lalu empat campuran siap putar di assets/audio/mix/ dengan penguatan yang dihitung agar −16 LUFS (pembatas lembut, tanpa clipping).
 * Hanya folder mix/ yang dimuat client (total di bawah 5 MB). Tidak memakai sampel pihak ketiga. Menolak menimpa berkas yang sudah ada kecuali `--force`.
 *
 *   npx tsx scripts/gen-audio.ts [--force]
 */
import { existsSync, mkdirSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { SFX_NAMES, introAudioPlan, parseFormBank, parseTimeline, type MapDef, type SfxName } from "@route-rush/shared";
import { calibrate, phaseDuration, renderMix, type MixAssets, type MixConfig } from "./audio/mix";
import { synthMusic, synthSfx } from "./audio/synth";
import { writeWav } from "./audio/wav";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const audio = resolve(root, "assets", "audio");
const force = process.argv.includes("--force");

const normalize = (x: Float32Array, peak = 0.9): Float32Array => {
  let p = 0;
  for (const v of x) p = Math.max(p, Math.abs(v));
  return p === 0 ? x : x.map((v) => (v / p) * peak);
};

const KEYS = ["IDENT_FULL", "IDENT_SHORT", "TRAILER_FULL", "TRAILER_SHORT"] as const;
const targets = [resolve(audio, "music.wav"), ...KEYS.map((k) => resolve(audio, "mix", `${k}.wav`)), ...SFX_NAMES.map((n) => resolve(audio, "sfx", `${n}.wav`)), resolve(audio, "mix.json")];
const existing = targets.filter((t) => existsSync(t));
if (existing.length && !force) {
  console.error(`Berkas sudah ada; tidak ditimpa (pakai --force bila sengaja):\n${existing.join("\n")}`);
  process.exit(1);
}
mkdirSync(resolve(audio, "sfx"), { recursive: true });
mkdirSync(resolve(audio, "mix"), { recursive: true });

const music = normalize(synthMusic(45));
writeWav(resolve(audio, "music.wav"), music);
const sfx = {} as Record<SfxName, Float32Array>;
for (const n of SFX_NAMES) {
  sfx[n] = normalize(synthSfx(n), 0.8);
  writeWav(resolve(audio, "sfx", `${n}.wav`), sfx[n]);
}

const tl = parseTimeline(JSON.parse(readFileSync(resolve(root, "shared/intro/timeline.json"), "utf8")));
const bank = parseFormBank(JSON.parse(readFileSync(resolve(root, "shared/maps/formA.json"), "utf8")));
const map = bank.maps.find((m) => m.id === tl.trailerMap) as MapDef;
const assets: MixAssets = { music, sfx };
const cfg: MixConfig = {
  IDENT_FULL: calibrate(tl, "IDENT", "FULL", map.edges.length, assets),
  IDENT_SHORT: calibrate(tl, "IDENT", "SHORT", map.edges.length, assets),
  TRAILER_FULL: calibrate(tl, "TRAILER", "FULL", map.edges.length, assets),
  TRAILER_SHORT: calibrate(tl, "TRAILER", "SHORT", map.edges.length, assets),
};
for (const k of KEYS) {
  const [kind, mode] = k.split("_") as ["IDENT" | "TRAILER", "FULL" | "SHORT"];
  const plan = introAudioPlan(tl, kind, mode, map.edges.length);
  writeWav(resolve(audio, "mix", `${k}.wav`), renderMix(plan, assets, cfg[k], phaseDuration(tl, kind, mode)));
}
writeFileSync(resolve(audio, "mix.json"), JSON.stringify({ targetLufs: -16, sampleRate: 22050, ...cfg }, null, 2) + "\n");
console.log("Aset audio dibuat di", audio);
console.log(JSON.stringify(cfg));
/**
 * Membuat aset suara jawaban dari tiga berkas MP3 yang diberikan pemilik proyek:
 *   assets/audio/answers/source/correct.mp3  → answers/correct.wav   (jawaban benar)
 *   assets/audio/answers/source/wrong.mp3    → answers/wrong.wav     (jawaban salah)
 *   assets/audio/names/source-names.mp3      → names/01.wav … 25.wav (satu klip per siswa: "<nama> menjawab dengan benar")
 * MP3 didekode lewat Edge/Chrome terpasang (scripts/decode-mp3.mjs), lalu klip nama dipotong per jeda dan dinormalkan ke −16 LUFS.
 *
 *   npx tsx scripts/build-answer-audio.ts [--expect 25]
 */
import { spawnSync } from "node:child_process";
import { mkdirSync, mkdtempSync, readFileSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { integratedLufs, peakDb } from "./audio/lufs";
import { encodeWav } from "./audio/wav";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const expectArg = process.argv.indexOf("--expect");
const EXPECT = expectArg >= 0 ? Number(process.argv[expectArg + 1]) : 25;

export function decode(src: string): { samples: Float32Array; sampleRate: number } {
  const dir = mkdtempSync(join(tmpdir(), "rr-dec-"));
  const out = join(dir, "pcm.json");
  const r = spawnSync(process.execPath, [resolve(root, "scripts/decode-mp3.mjs"), src, out], { encoding: "utf8" });
  if (r.status !== 0) throw new Error(`dekode gagal: ${r.stderr}`);
  const j = JSON.parse(readFileSync(out, "utf8")) as { sampleRate: number; samples: string };
  const b = Buffer.from(j.samples, "base64");
  const i16 = new Int16Array(b.buffer, b.byteOffset, b.length / 2);
  return { samples: Float32Array.from(i16, (v) => v / 32768), sampleRate: j.sampleRate };
}

/** Turunkan laju sampel dengan rerata blok (cukup untuk suara; faktor bulat). */
export function downsample(x: Float32Array, factor: number): Float32Array {
  if (factor === 1) return x;
  const out = new Float32Array(Math.floor(x.length / factor));
  for (let i = 0; i < out.length; i++) {
    let s = 0;
    for (let k = 0; k < factor; k++) s += x[i * factor + k] as number;
    out[i] = s / factor;
  }
  return out;
}

const softLimit = (v: number): number => {
  const a = Math.abs(v);
  return a < 0.6 ? v : Math.sign(v) * (0.6 + 0.29 * Math.tanh((a - 0.6) / 0.29));
};

/** Penguatan ke −16 LUFS (± 0,05) dengan pembatas lembut; fade 10 ms di kedua ujung. */
export function normalize(x: Float32Array, fs: number, target = -16): Float32Array {
  let gain = 1;
  let y = x;
  for (let i = 0; i < 10; i++) {
    y = x.map((v) => softLimit(v * gain));
    const l = integratedLufs(y, fs);
    if (!Number.isFinite(l) || Math.abs(l - target) < 0.05) break;
    gain *= 10 ** ((target - l) / 20);
  }
  const f = Math.round(0.01 * fs);
  for (let i = 0; i < f; i++) {
    y[i] = (y[i] as number) * (i / f);
    y[y.length - 1 - i] = (y[y.length - 1 - i] as number) * (i / f);
  }
  return y;
}

/** Potong keheningan di awal dan akhir (ambang −50 dBFS pada jendela 10 ms), sisakan `pad` detik. */
export function trimSilence(x: Float32Array, fs: number, pad = 0.05, thDb = -50): Float32Array {
  const win = Math.round(fs * 0.01);
  const loud = (i: number): boolean => {
    let s = 0;
    for (let k = i; k < Math.min(x.length, i + win); k++) s += (x[k] as number) ** 2;
    return 10 * Math.log10(s / win + 1e-12) > thDb;
  };
  let a = 0;
  while (a < x.length && !loud(a)) a += win;
  let b = x.length - win;
  while (b > a && !loud(b)) b -= win;
  const p = Math.round(pad * fs);
  return x.slice(Math.max(0, a - p), Math.min(x.length, b + win + p));
}

// ---------------------------------------------------------------- pemotongan klip nama

interface Seg {
  a: number;
  b: number;
}

/** Subsegmen bersuara (ambang −45 dBFS, jendela 10 ms, jeda dalam ≤ 80 ms disatukan, durasi > 150 ms). */
function voiced(x: Float32Array, fs: number): Seg[] {
  const win = Math.round(fs * 0.01);
  const db: number[] = [];
  for (let i = 0; i + win <= x.length; i += win) {
    let s = 0;
    for (let k = i; k < i + win; k++) s += (x[k] as number) ** 2;
    db.push(10 * Math.log10(s / win + 1e-12));
  }
  const segs: Seg[] = [];
  let start = -1;
  let last = -1;
  db.forEach((v, i) => {
    if (v > -45) {
      if (start < 0) start = i;
      else if ((i - last) * 0.01 > 0.08) {
        segs.push({ a: start * 0.01, b: last * 0.01 });
        start = i;
      }
      last = i;
    }
  });
  if (start >= 0) segs.push({ a: start * 0.01, b: last * 0.01 });
  return segs.filter((s) => s.b - s.a > 0.15);
}

/**
 * Setiap klip berbunyi "<nama> menjawab dengan benar": satu atau lebih bagian nama lalu frasa tetap (± 1,7 detik).
 * Jeda antar-klip dan jeda di dalam klip tumpang-tindih (0,24–0,47 s vs 0,11–0,30 s), maka pembagian dipilih dengan
 * pemrograman dinamis: tepat `count` klip, tiap klip 2–4 bagian, bagian terakhir berdurasi mendekati frasa tetap,
 * dan jeda sesudah klip sebesar mungkin dibanding jeda di dalamnya.
 */
export function groupClips(segs: Seg[], count: number, phraseSec = 1.7): number[][] {
  const n = segs.length;
  const gap = (i: number): number => (i + 1 < n ? (segs[i + 1] as Seg).a - (segs[i] as Seg).b : 1);
  const INF = 1e9;
  // best[k][i] = biaya terbaik memakai k klip untuk segs[0..i)
  const best: number[][] = Array.from({ length: count + 1 }, () => Array<number>(n + 1).fill(INF));
  const from: number[][] = Array.from({ length: count + 1 }, () => Array<number>(n + 1).fill(-1));
  best[0]![0] = 0;
  for (let k = 1; k <= count; k++)
    for (let i = 2; i <= n; i++)
      for (let len = 2; len <= 4 && i - len >= 0; len++) {
        const prev = best[k - 1]![i - len] as number;
        if (prev >= INF) continue;
        const last = segs[i - 1] as Seg;
        let cost = Math.abs(last.b - last.a - phraseSec) * 10;
        for (let j = i - len; j < i - 1; j++) cost += gap(j) * 4; // jeda di dalam klip: makin kecil makin baik
        cost -= gap(i - 1) * 4; // jeda setelah klip: makin besar makin baik
        if (prev + cost < (best[k]![i] as number)) {
          best[k]![i] = prev + cost;
          from[k]![i] = len;
        }
      }
  if ((best[count]![n] as number) >= INF) throw new Error(`tidak dapat membagi ${n} subsegmen menjadi ${count} klip`);
  const groups: number[][] = [];
  let i = n;
  for (let k = count; k >= 1; k--) {
    const len = from[k]![i] as number;
    groups.unshift(Array.from({ length: len }, (_, j) => i - len + j));
    i -= len;
  }
  return groups;
}

function main(): void {
  const answers = resolve(root, "assets/audio/answers");
  const names = resolve(root, "assets/audio/names");
  mkdirSync(answers, { recursive: true });
  mkdirSync(names, { recursive: true });

  for (const [name, file] of [
    ["correct", "source/correct.mp3"],
    ["wrong", "source/wrong.mp3"],
  ] as const) {
    const d = decode(resolve(answers, file));
    const x = normalize(trimSilence(d.samples, d.sampleRate, 0.02), d.sampleRate);
    writeFileSync(resolve(answers, `${name}.wav`), encodeWav(x, d.sampleRate));
    console.log(`${name}.wav: ${(x.length / d.sampleRate).toFixed(2)} s, ${integratedLufs(x, d.sampleRate).toFixed(1)} LUFS, puncak ${peakDb(x).toFixed(1)} dBFS`);
  }

  const d = decode(resolve(names, "source-names.mp3"));
  const segs = voiced(d.samples, d.sampleRate);
  const groups = groupClips(segs, EXPECT);
  const factor = d.sampleRate >= 44100 ? 2 : 1;
  const fs = d.sampleRate / factor;
  const clips: { n: number; file: string; startS: number; endS: number; durationS: number; parts: number }[] = [];
  groups.forEach((g, idx) => {
    const a = Math.max(0, (segs[g[0] as number] as Seg).a - 0.08);
    const b = Math.min(d.samples.length / d.sampleRate, (segs[g.at(-1) as number] as Seg).b + 0.12);
    const part = downsample(d.samples.slice(Math.round(a * d.sampleRate), Math.round(b * d.sampleRate)), factor);
    const x = normalize(part, fs);
    const file = `${String(idx + 1).padStart(2, "0")}.wav`;
    writeFileSync(resolve(names, file), encodeWav(x, fs));
    clips.push({ n: idx + 1, file, startS: +a.toFixed(2), endS: +b.toFixed(2), durationS: +(x.length / fs).toFixed(2), parts: g.length });
  });
  writeFileSync(resolve(names, "clips.json"), JSON.stringify({ count: clips.length, sampleRate: fs, clips }, null, 2) + "\n");
  console.table(clips);
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main();

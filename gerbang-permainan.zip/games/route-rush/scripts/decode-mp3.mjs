/**
 * Mendekode MP3 menjadi PCM mono 16-bit memakai Microsoft Edge/Chrome yang sudah terpasang (WebAudio), tanpa ffmpeg.
 *   node scripts/decode-mp3.mjs <masuk.mp3> <keluar.pcm.json>
 * Keluaran: {sampleRate, samples: base64 Int16 mono}
 */
import { readFileSync, writeFileSync } from "node:fs";
import { chromium } from "@playwright/test";

const [src, out] = process.argv.slice(2);
const b64 = readFileSync(src).toString("base64");
const browser = await chromium.launch({ channel: "msedge", headless: true });
const page = await browser.newPage();
const res = await page.evaluate(async (data) => {
  const bin = Uint8Array.from(atob(data), (c) => c.charCodeAt(0));
  const ctx = new AudioContext();
  const buf = await ctx.decodeAudioData(bin.buffer);
  const mono = new Float32Array(buf.length);
  for (let c = 0; c < buf.numberOfChannels; c++) {
    const ch = buf.getChannelData(c);
    for (let i = 0; i < buf.length; i++) mono[i] += ch[i] / buf.numberOfChannels;
  }
  const i16 = new Int16Array(buf.length);
  for (let i = 0; i < buf.length; i++) i16[i] = Math.max(-32768, Math.min(32767, Math.round(mono[i] * 32767)));
  let s = "";
  const u8 = new Uint8Array(i16.buffer);
  for (let i = 0; i < u8.length; i += 0x8000) s += String.fromCharCode(...u8.subarray(i, i + 0x8000));
  return { sampleRate: buf.sampleRate, duration: buf.duration, samples: btoa(s) };
}, b64);
await browser.close();
writeFileSync(out, JSON.stringify(res));
console.log(`${src}: ${res.duration.toFixed(2)} s @ ${res.sampleRate} Hz`);
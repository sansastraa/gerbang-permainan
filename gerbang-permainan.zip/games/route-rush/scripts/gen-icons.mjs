// Membuat ikon aplikasi (PNG) untuk PWA: Android (192/512 + maskable), iOS/iPadOS (apple-touch-icon 180).
// Tanpa pustaka gambar: tiap piksel dihitung dari bentuk sederhana (kotak membulat tinta + titik, garis, titik), lalu ditulis sebagai PNG.
// Jalankan: node scripts/gen-icons.mjs   (hasil di client/public/icons/)
import { mkdirSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { deflateSync } from "node:zlib";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const out = resolve(root, "client/public/icons");
mkdirSync(out, { recursive: true });

const INK = [16, 24, 40];
const COIN = [255, 192, 46];
const WHITE = [255, 255, 255];

const crcTable = Array.from({ length: 256 }, (_, n) => {
  let c = n;
  for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1;
  return c >>> 0;
});
const crc32 = (buf) => {
  let c = 0xffffffff;
  for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
};
const chunk = (type, data) => {
  const len = Buffer.alloc(4);
  len.writeUInt32BE(data.length);
  const body = Buffer.concat([Buffer.from(type), data]);
  const crc = Buffer.alloc(4);
  crc.writeUInt32BE(crc32(body));
  return Buffer.concat([len, body, crc]);
};

/** Jarak bertanda ke kotak membulat (negatif = di dalam). */
const roundRect = (x, y, w, h, r) => {
  const qx = Math.abs(x - w / 2) - (w / 2 - r);
  const qy = Math.abs(y - h / 2) - (h / 2 - r);
  return Math.hypot(Math.max(qx, 0), Math.max(qy, 0)) + Math.min(Math.max(qx, qy), 0) - r;
};
const segDist = (px, py, ax, ay, bx, by) => {
  const dx = bx - ax;
  const dy = by - ay;
  const t = Math.max(0, Math.min(1, ((px - ax) * dx + (py - ay) * dy) / (dx * dx + dy * dy)));
  return Math.hypot(px - (ax + t * dx), py - (ay + t * dy));
};

/** `maskable`: latar penuh tanpa sudut membulat dan gambar di zona aman (80%) agar tidak terpotong bentuk ikon Android. */
function render(size, maskable) {
  const s = maskable ? 0.8 : 1;
  const off = (1 - s) / 2;
  const P = (u, v) => [(off + u * s) * size, (off + v * s) * size];
  const route = [P(0.24, 0.5), P(0.76, 0.5)];
  const stroke = 0.085 * s * size;
  const dotR = 0.1 * s * size;
  const px = Buffer.alloc(size * size * 4);
  const SS = 3;
  for (let y = 0; y < size; y++) {
    for (let x = 0; x < size; x++) {
      let r = 0;
      let g = 0;
      let b = 0;
      let a = 0;
      for (let sy = 0; sy < SS; sy++) {
        for (let sx = 0; sx < SS; sx++) {
          const fx = x + (sx + 0.5) / SS;
          const fy = y + (sy + 0.5) / SS;
          const inside = maskable ? true : roundRect(fx, fy, size, size, size * 0.22) <= 0;
          if (!inside) continue;
          let c = INK;
          for (let i = 0; i < route.length - 1; i++) if (segDist(fx, fy, ...route[i], ...route[i + 1]) <= stroke / 2) c = COIN;
          if (Math.hypot(fx - route[0][0], fy - route[0][1]) <= dotR) c = WHITE;
          if (Math.hypot(fx - route[1][0], fy - route[1][1]) <= dotR) c = COIN;
          r += c[0];
          g += c[1];
          b += c[2];
          a += 255;
        }
      }
      const n = SS * SS;
      const covered = a / 255;
      const i = (y * size + x) * 4;
      px[i] = covered ? Math.round(r / covered) : 0;
      px[i + 1] = covered ? Math.round(g / covered) : 0;
      px[i + 2] = covered ? Math.round(b / covered) : 0;
      px[i + 3] = Math.round(a / n);
    }
  }
  const raw = Buffer.alloc((size * 4 + 1) * size);
  for (let y = 0; y < size; y++) {
    raw[y * (size * 4 + 1)] = 0;
    px.copy(raw, y * (size * 4 + 1) + 1, y * size * 4, (y + 1) * size * 4);
  }
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0);
  ihdr.writeUInt32BE(size, 4);
  ihdr[8] = 8;
  ihdr[9] = 6;
  return Buffer.concat([Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]), chunk("IHDR", ihdr), chunk("IDAT", deflateSync(raw, { level: 9 })), chunk("IEND", Buffer.alloc(0))]);
}

const files = [
  ["icon-192.png", 192, false],
  ["icon-512.png", 512, false],
  ["icon-maskable-512.png", 512, true],
  // iOS menempelkan ikon di atas latar sendiri dan membulatkan sudutnya: kirim kotak penuh tanpa transparansi
  ["apple-touch-icon.png", 180, true],
];
for (const [name, size, maskable] of files) {
  writeFileSync(resolve(out, name), render(size, maskable));
  console.log(`${name} ${size}x${size}${maskable ? " (penuh)" : ""}`);
}

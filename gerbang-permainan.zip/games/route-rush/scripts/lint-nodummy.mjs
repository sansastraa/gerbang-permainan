// Gagal bila folder src/ mana pun memuat Math.random, kata terlarang, atau nama pemain contoh.
import { readdirSync, readFileSync, statSync } from "node:fs";
import { join, relative } from "node:path";

const ROOT = new URL("..", import.meta.url).pathname.replace(/^\/([A-Za-z]:)/, "$1");
const SKIP = new Set(["node_modules", "dist", "coverage", ".git"]);
const FORBIDDEN = [
  { re: /Math\.random/, why: "Math.random dilarang; pakai shared/src/rng.ts" },
  { re: /\b(dummy|mock|fake|lorem)\b/i, why: "kata terlarang (dummy/mock/fake/lorem)" },
  { re: /\b(Ani|Budi|Citra|Dodi|Siswa Contoh|Pemain Contoh)\b/, why: "nama pemain contoh" },
];

function srcDirs(dir, out = []) {
  for (const name of readdirSync(dir)) {
    if (SKIP.has(name)) continue;
    const full = join(dir, name);
    if (!statSync(full).isDirectory()) continue;
    if (name === "src") out.push(full);
    else srcDirs(full, out);
  }
  return out;
}

function files(dir, out = []) {
  for (const name of readdirSync(dir)) {
    const full = join(dir, name);
    if (statSync(full).isDirectory()) files(full, out);
    else if (/\.(ts|tsx|js|jsx|mjs|json|css|html)$/.test(name)) out.push(full);
  }
  return out;
}

const problems = [];
for (const dir of srcDirs(ROOT)) {
  for (const file of files(dir)) {
    readFileSync(file, "utf8")
      .split(/\r?\n/)
      .forEach((line, i) => {
        for (const { re, why } of FORBIDDEN) {
          if (re.test(line)) problems.push(`${relative(ROOT, file)}:${i + 1}  ${why}: ${line.trim()}`);
        }
      });
  }
}

if (problems.length) {
  console.error(`lint:nodummy GAGAL (${problems.length} temuan)\n` + problems.join("\n"));
  process.exit(1);
}
console.log("lint:nodummy lulus");

/**
 * Membuat bank Tantangan (pool T): peta besar dengan waktu jalan 1–2 menit.
 *   npx tsx scripts/gen-challenge.ts [--seed RR-CHALLENGE-T] [--out shared/maps/poolT.json]
 * Tidak menimpa berkas yang sudah ada. Pool A/B tidak disentuh (hanya peta latihan ronde 0 yang disalin).
 */
import { existsSync, readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { CHALLENGE_CONFIGS, buildChallengePool, checkChallengeMap, parsePool } from "../shared/src/index";

const root = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const arg = (name: string): string | undefined => {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
};
const seed = arg("seed") ?? "RR-CHALLENGE-T";
const out = resolve(root, arg("out") ?? "shared/maps/poolT.json");
if (existsSync(out)) {
  console.error(`DITOLAK: ${out} sudah ada dan tidak akan ditimpa.`);
  process.exit(1);
}
const poolA = parsePool(JSON.parse(readFileSync(resolve(root, "shared/maps/poolA.json"), "utf8")));
const practice = poolA.rounds.find((r) => r.roundId === 0);
if (!practice) throw new Error("Pool A tidak punya ronde 0");

const started = Date.now();
const pool = buildChallengePool(seed, practice);
for (const r of pool.rounds) {
  const c = CHALLENGE_CONFIGS.find((x) => x.roundId === r.roundId);
  if (!c) continue;
  for (const m of r.items) {
    const v = checkChallengeMap(m, c);
    if (v.issues.length) throw new Error(`${m.id}: ${v.issues.join("; ")}`);
  }
}
writeFileSync(out, JSON.stringify({ ...pool, generatedBy: "scripts/gen-challenge.ts" }, null, 2) + "\n", { encoding: "utf8", flag: "wx" });
console.log(`Pool T dibuat dalam ${((Date.now() - started) / 1000).toFixed(1)} dtk → ${out}`);

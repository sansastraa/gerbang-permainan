# ROUTE RUSH — Spesifikasi Implementasi Lengkap

> Spesifikasi end-to-end yang siap dikerjakan Claude Code: logika game, server balapan, layar guru dan siswa, intro sinematik, tutorial, ekspor laporan, sampai uji lapangan.
>
> **Nama game:** Route Rush · kode `ROUTE_RUSH` · nama repo `route-rush`. Tokoh di dalam game cukup disebut "kurir".
> **Bahasa UI:** Bahasa Indonesia (pengguna siswa kelas 6 SD). **Bahasa kode** (variabel, fungsi, file): Inggris.
>
> **Tanpa data dummy, semua angka sudah diuji.** Paket `route-rush.zip` berisi bank soal paralel nyata (Pool A dan B, 82 soal: 4 soal setara per ronde), peta fixture (Form A dan B), 5 peta tutorial, data timeline intro, file golden, dan oracle Python yang menjalankan 65 kasus uji dengan hasil **65/65 lulus** (`reference/test_report.txt`).

---

## 0. Instruksi untuk Claude Code

**Cara pakai:** ekstrak `route-rush.zip` ke folder kosong (isinya `SPEC.md`, `shared/maps/`, `shared/intro/`, `shared/test/golden/`, `reference/`, `docs/preview/`), lalu jalankan Claude Code di folder itu dengan prompt:

```
Baca SPEC.md sampai habis. Kerjakan Fase 1 saja (Bagian 15), jalankan semua test,
lalu berhenti dan laporkan hasilnya sebelum lanjut ke fase berikutnya.
```

**Aturan kerja:**

1. Kerjakan per fase sesuai Bagian 15. Setelah setiap fase: jalankan `npm test`, pastikan lulus, lalu berhenti dan laporkan.
2. **Jangan mengubah rumus** di Bagian 9 dan 10 tanpa bertanya. Semua angka uji di Bagian 14 harus cocok persis.
3. Semua logika game (solver, skor, metrik, generator, varian) ditaruh di paket `shared/` sebagai fungsi murni tanpa I/O, agar bisa diuji dan dipakai server maupun client.
4. Server adalah sumber kebenaran untuk fase dan waktu. Client hanya menampilkan dan mengirim ketukan/hasil.
5. Simpan nilai mentah (tanpa pembulatan). Pembulatan hanya saat ditampilkan atau diekspor (1 desimal untuk indeks, 2 desimal untuk ER).
6. Bila ada hal yang tidak diatur di spesifikasi, pilih opsi paling sederhana dan catat di `DECISIONS.md`.
7. **Patuhi Bagian 0A (Kebijakan Data Nyata dan Wajib Uji).** Tidak boleh ada data dummy di jalur produksi, dan fase tidak dianggap selesai tanpa test yang lulus.
8. File di `shared/maps/` (termasuk `poolA.json` dan `poolB.json`), `shared/intro/`, dan `shared/test/golden/` adalah **data acuan yang sudah diverifikasi. Jangan diedit atau dibuat ulang.** Bila test TypeScript tidak cocok dengan data acuan, yang salah adalah kode TypeScript. Laporkan bila Anda yakin sebaliknya.
9. Jalankan juga `python3 test_oracle.py` dari folder `reference/` untuk memastikan data acuan tetap utuh. Hasil wajib `65/65 lulus`.

---

## 0A. Kebijakan Data Nyata dan Wajib Uji

### 0A.1 Larangan data dummy

| Dilarang | Yang harus dilakukan |
|---|---|
| Pemain, skor, atau sesi contoh yang muncul di UI, ekspor, atau laporan | Tampilkan *empty state* yang jujur: "Belum ada pemain", "Belum ada data sesi" |
| Peta acak buatan saat runtime | Semua ronde memakai bank soal `shared/maps/poolA.json` / `poolB.json` (4 soal setara per ronde); tutorial memakai `tutorial.json`; trailer memakai A-05 dari `formA.json` |
| Angka hardcode di UI (mis. "18/28 sudah sampai", poin, peringkat, angka koin di trailer) | Semua angka berasal dari state server atau dihitung dari data acuan memakai fungsi `shared/` |
| `Math.random()` di logika game | Hanya PRNG ber-seed dari `shared/src/rng.ts`, untuk varian tampilan, urutan opsi probe, dan generator offline |
| Mock data di folder `src/` | Fixture hanya boleh ada di folder `test/` dan `e2e/` |
| Aset audio/gambar placeholder di build produksi | Aset placeholder hanya di mode pengembangan dan ditandai di `assets/PLACEHOLDERS.md`; build produksi gagal bila daftar itu tidak kosong |
| Menghitung ulang metrik di client | Metrik dihitung sekali di server memakai fungsi `shared/` dari data ketukan nyata |

### 0A.2 Pemisahan data uji dan data nyata

- Setiap sesi punya field `kind: "LIVE" | "TEST"`. Sesi yang dibuat oleh test, simulasi, atau bot **wajib** `TEST`.
- Pemain bot punya `isBot: true` dan hanya bisa dibuat bila server berjalan dengan `NODE_ENV=test` atau lewat `npm run simulate`. Di mode produksi, event pembuat bot tidak terdaftar sama sekali.
- File sesi `TEST` disimpan di `data/test-sessions/`, terpisah dari `data/sessions/`.
- Endpoint ekspor dan laporan menolak sesi `TEST` kecuali dipanggil dengan `?includeTest=1`; bila begitu, setiap baris diberi kolom `kind=TEST`.
- Test otomatis memastikan sesi `LIVE` tidak pernah berisi pemain `isBot`.

### 0A.3 Uji integritas data hasil

Setiap `RoundResult` diperiksa oleh `assertRoundIntegrity(result, canonicalMap)` di `shared/` sebelum disimpan. Fungsi ini melempar error bila salah satu syarat gagal:

1. `playerPath[0] === map.start`, dan setiap pasangan berurutan adalah edge yang ada di peta.
2. `playerCost` sama dengan hasil hitung ulang dari `playerPath`.
3. `completed` benar hanya bila node terakhir adalah goal dan semua stop ada di path.
4. `er`, `optimalHit`, `errorType`, dan poin sama persis dengan hasil fungsi `shared/`.
5. `0 ≤ tRouteMs ≤ walkMs`, dan `tFirstMs ≤ tRouteMs` bila tidak null.
6. `steps === playerPath.length − 1`, dan `revisits` sama dengan hitung ulang dari path.
7. `tapLog` urut naik berdasarkan `tMs`; jumlah entri `valid:false` sama dengan `invalidTaps`; jumlah entri `UNDO` sama dengan `undo`.

`TutorialResult` diperiksa serupa oleh `assertTutorialIntegrity`: jumlah langkah 5, `ms` tiap langkah ≥ 0 dan totalnya ≤ `totalMs`, `completed` salah bila `autoDemoSteps` tidak kosong.

Hasil yang gagal integritas disimpan di `data/rejected/` beserta alasannya, tetapi **tidak** masuk ke indeks dan ekspor. Jumlahnya ditampilkan di layar podium host bila lebih dari 0. `students.csv` wajib bisa dihitung ulang dari `rounds.csv` dengan hasil identik.

### 0A.4 Tingkatan pengujian wajib

| Tingkat | Alat | Cakupan minimum |
|---|---|---|
| Unit | Vitest | `shared/`: cakupan baris ≥ 95%, cabang ≥ 90% |
| Golden | Vitest | 22 peta bank + 5 peta tutorial cocok dengan `golden.json` dan `tutorial.json`; timeline cocok dengan `timeline.json` |
| Property-based | fast-check | Lihat 0A.5 |
| Integrasi | Vitest + socket.io-client | Sesi lengkap FULL dan SHORT, Standar dan Kilat, dengan bot (sesi `TEST`) |
| End-to-end | Playwright | 1 host + 2 pemain di browser sungguhan, dari lobi, intro, tutorial, sampai unduh CSV |
| Visual | Playwright screenshot | Frame kunci intro dengan jam terkendali (I12) |
| Lapangan | Kelas nyata | Fase 9 |

`npm test` menjalankan unit, golden, property, dan integrasi. `npm run test:e2e` menjalankan Playwright. Keduanya wajib hijau sebelum fase selesai, dan ringkasannya ditulis ke `TEST_REPORT.md`.

### 0A.5 Uji property-based (fast-check, minimal 500 kasus per properti)

- Peta acak yang lolos validator + rute acak yang valid: `playerCost ≥ optimalCost`, sehingga `0 < er ≤ 1`.
- Untuk setiap `er < 1` dan `0 ≤ t ≤ T`: poin optimal di `t = T` lebih besar dari poin tidak optimal di `t = 0`.
- `racePoints` di 0–1000, `probePoints` di 0–200, `streakBonus` di 0–300.
- `applyVariant` untuk varian 0–7 tidak mengubah `optimalCost`, id node/edge, dan tidak membuat edge berpotongan.
- Urutan ketukan acak (termasuk tidak valid dan Batal) selalu menghasilkan `RouteState` yang lolos `assertRoundIntegrity`.
- IL, IM, IS selalu di 0–100 atau `null`.

---

## 1. Ringkasan Produk

Game balapan kelas ala kuis Kahoot untuk siswa kelas 6 SD, berbasis **Masalah Pilihan Perjalanan** (jalur terpendek dengan tempat wajib singgah).

- Guru membuka sesi di layar proyektor (**Host**). Siswa masuk dengan kode sesi dari perangkat masing-masing (**Player**).
- Setiap ronde, semua siswa mendapat peta yang setara pada saat bersamaan. Mereka mengetuk tempat demi tempat untuk membuat rute dari **Rumah** ke **tujuan** dengan total koin sekecil mungkin.
- Dua jenis ronde: **VISIBLE** (angka koin terlihat terus) dan **HIDDEN** (angka hilang setelah fase Lihat, lalu ada soal ingatan).
- Hasil:
  1. **Poin balapan** untuk keseruan dan papan peringkat.
  2. **Metrik individu** (Indeks Logika, Memori, Spasial, kecepatan-ketepatan) untuk laporan guru. Keduanya **tidak boleh dicampur**.
- **Anti-contek:** setiap ronde punya 4 soal setara. Siswa memilih kursinya di denah saat bergabung, lalu server membagi soal sehingga kursi yang bersebelahan (depan, belakang, samping, diagonal) selalu mendapat soal berbeda, dan peta juga diputar atau dicerminkan berbeda. Soal tetap naik dari paling sederhana ke paling rumit. Detail di Bagian 8.5, 8.6, dan 12B.
- Sesi perdana satu kelas dibuka dengan **intro sinematik** di proyektor (ident 8 detik + trailer 45 detik) dan **tutorial interaktif** 5 langkah di perangkat siswa (maks 90 detik). Sesi berikutnya memakai intro ringkas 15 detik tanpa tutorial. Detailnya di Bagian 12A.

Durasi pada batas maksimal (terverifikasi oleh oracle, uji T23 dan S1–S4):

| Jenis sesi | Lobi | Intro | Tutorial | Ronde | Podium | Total |
|---|---|---|---|---|---|---|
| Perdana, Standar | 30 s | 53 s | 90 s | 415 s (ronde 1–10) | 20 s | 608 s (±10,1 menit) |
| Perdana, Kilat | 30 s | 53 s | 90 s | 235 s (6 ronde) | 20 s | 428 s (±7,1 menit) |
| Lanjutan, Standar | 30 s | 15 s | – | 443 s (ronde 0–10) | 20 s | 508 s (±8,5 menit) |
| Lanjutan, Kilat | 30 s | 15 s | – | 263 s (ronde 0 + 6 ronde) | 20 s | 328 s (±5,5 menit) |

Di sesi perdana, ronde latihan 0 (28 detik) dilewati karena tutorial menggantikannya. Dalam praktik sesi lebih singkat karena tutorial dan ronde berakhir begitu semua siswa selesai. Bila waktu pelajaran ketat, sesi perdana sebaiknya memakai Mode Kilat.

---

## 2. Tech Stack dan Struktur Repo

| Bagian | Pilihan |
|---|---|
| Bahasa | TypeScript (strict) |
| Monorepo | npm workspaces |
| Shared logic | `shared/` — fungsi murni |
| Server | Node 20, Express, Socket.IO |
| Client | Vite + React 18, peta digambar dengan SVG |
| Test | Vitest, fast-check (property-based), Playwright (end-to-end dan screenshot) |
| Animasi intro | React + SVG + Web Animations API (tanpa pustaka berbayar, tanpa file video) |
| Penyimpanan | Memori + log JSONL per sesi di `data/sessions/` (tahan crash) |
| Ekspor | CSV dan HTML laporan yang bisa dicetak |

```
route-rush/
├── package.json              # workspaces: shared, server, client
├── SPEC.md
├── DECISIONS.md
├── shared/
│   ├── src/
│   │   ├── types.ts
│   │   ├── rng.ts            # PRNG ber-seed (mulberry32)
│   │   ├── graph.ts          # adjacency, dijkstra, bfs, enumerate paths
│   │   ├── solver.ts         # optimalCost, optimalRoute, minHops
│   │   ├── generator.ts      # generate + validate map
│   │   ├── variant.ts        # 8 simetri + acak label
│   │   ├── route.ts          # state machine ketukan (tap, undo, packages)
│   │   ├── scoring.ts        # poin balapan, streak, probe
│   │   ├── metrics.ts        # metrik per ronde, error type
│   │   ├── indices.ts        # IL, IM, IS, RTM, kuadran, catatan otomatis
│   │   ├── rounds.ts         # konfigurasi ronde + mode
│   │   ├── budget.ts         # anggaran waktu sesi (S1–S4)
│   │   ├── distribution.ts   # assignSlot, assignVariant (pembagian soal per kursi)
│   │   ├── integrity.ts      # assertRoundIntegrity, assertTutorialIntegrity, flag integritas
│   │   ├── introTimeline.ts  # memuat + memvalidasi shared/intro/timeline.json
│   │   └── copy.ts           # semua teks UI Bahasa Indonesia
│   ├── maps/
│   │   ├── poolA.json        # DISEDIAKAN — bank soal sesi 1: 4 soal setara per ronde (41 soal)
│   │   ├── poolB.json        # DISEDIAKAN — bank soal sesi 2 (41 soal, tidak ada yang sama dengan Pool A)
│   │   ├── formA.json        # DISEDIAKAN — peta fixture uji + A-05 untuk trailer
│   │   ├── formB.json        # DISEDIAKAN — peta fixture uji
│   │   └── tutorial.json     # DISEDIAKAN — 5 peta tutorial + nilai golden
│   ├── intro/
│   │   └── timeline.json     # DISEDIAKAN — data shot ident + trailer
│   └── test/
│       └── golden/
│           ├── golden.json       # DISEDIAKAN — jawaban benar peta fixture Form A/B
│           └── pool_golden.json  # DISEDIAKAN — jawaban benar 82 soal Pool A/B
├── server/
│   └── src/
│       ├── index.ts
│       ├── session.ts        # state machine sesi
│       ├── socket.ts         # event handler
│       ├── store.ts          # JSONL writer/reader
│       └── export.ts         # CSV + report HTML
├── client/
│   └── src/
│       ├── host/             # layar guru
│       ├── player/           # layar siswa
│       ├── components/MapView.tsx
│       ├── intro/            # IntroPlayer, IntroClock, shots/, ident/, characters/, town/, stills/, subtitles
│       ├── tutorial/         # Tutorial.tsx, steps.ts
│       └── assets/icons/     # ikon tempat (SVG buatan sendiri)
├── scripts/
│   ├── gen-pool.ts           # membuat Pool baru (C, D, …) dengan syarat 8.5; tidak boleh menimpa file yang ada
│   ├── simulate.ts           # sesi TEST dengan bot
│   └── field-check.ts        # laporan kelayakan sesi LIVE (Fase 9)
├── assets/
│   ├── audio/                # music.opus, vo/, sfx/, LICENSES.md
│   ├── brand/                # logo.svg, name.txt (untuk ident)
│   └── PLACEHOLDERS.md       # harus kosong saat build produksi
├── e2e/                      # Playwright
├── reference/                # DISEDIAKAN — oracle Python + laporan uji (jangan diubah)
├── docs/preview/             # DISEDIAKAN — pratinjau peta + seat_distribution.png (contoh pembagian soal per kursi)
├── docs/reference-ui/        # DISEDIAKAN — ready-glitch.html (acuan visual dan gerak layar READY)
├── TEST_REPORT.md
└── data/
    ├── sessions/             # LIVE
    ├── test-sessions/        # TEST
    └── rejected/             # hasil gagal integritas
```

---

## 3. Model Data (shared/src/types.ts)

```ts
export type NodeId = string;              // "n0".."n7"
export type PlaceKind =
  | "home" | "school" | "market" | "park" | "mosque"
  | "shop" | "library" | "clinic" | "field";

export interface MapNode {
  id: NodeId;
  kind: PlaceKind;          // ikon + nama tampil
  x: number; y: number;     // koordinat ternormalisasi 0..1
}

export interface MapEdge {
  id: string;               // "n0-n1" (id kecil di depan)
  a: NodeId; b: NodeId;
  w: number;                // koin, integer 1..9
}

export interface MapDef {
  id: string;               // "A-05"
  nodes: MapNode[];
  edges: MapEdge[];
  start: NodeId;            // kind "home"
  goal: NodeId;             // kind "school"
  stops: NodeId[];          // tempat paket wajib singgah (0..2)
  probeEdgeId?: string;     // hanya untuk ronde HIDDEN
}

export type Condition = "VISIBLE" | "HIDDEN";

export interface RoundConfig {
  roundId: number;          // 0 = latihan
  condition: Condition;
  nNodes: number; nEdges: number; nStops: number;
  lookMs: number; walkMs: number;
  trap: boolean;            // wajib: rute paling sedikit jalan ≠ optimal
  scored: boolean;          // latihan = false
}

export type ErrorType =
  | "NONE" | "FEW_ROADS_TRAP" | "STOP_ORDER" | "DETOUR" | "TIMEOUT";

export interface TapEvent {
  tMs: number;              // sejak akhir fase Lihat
  nodeId: NodeId | "UNDO";
  valid: boolean;
}

export interface RoundResult {
  sessionId: string; studentId: string; nickname: string;
  form: "A" | "B";            // = Pool A / Pool B
  mode: "STANDARD" | "QUICK";
  roundId: number; condition: Condition; variantId: number;
  itemId: string;             // mis. "PA-05-2"
  itemSlot: 0 | 1 | 2 | 3;
  seatMode: "SEATED" | "NO_SEAT";
  seatRow: number | null; seatCol: number | null;
  focusLost: number;          // keluar aplikasi/tab saat LOOK atau WALK
  fullscreenExits: number;
  integrityFlags: IntegrityFlag[];
  nNodes: number; nEdges: number; nStops: number; timeLimitS: number;
  optimalCost: number; playerCost: number | null; playerPath: NodeId[];
  completed: boolean; optimalHit: boolean; timedOut: boolean; missed: boolean;
  er: number;
  tFirstMs: number | null; tRouteMs: number;
  invalidTaps: number; undo: number; revisits: number; steps: number;
  probeCorrect: boolean | null; probeMs: number | null;
  racePoints: number; streakBonus: number; probePoints: number; rankAfter: number;
  errorType: ErrorType;
  tapLog: TapEvent[];
}

export type SessionPhase =
  | "LOBBY" | "INTRO_IDENT" | "INTRO_TRAILER" | "TUTORIAL"
  | "LOOK" | "WALK" | "PROBE" | "RESULT" | "LEADERBOARD"
  | "PODIUM" | "ENDED";

export type IntroMode = "FULL" | "SHORT";   // FULL = sesi perdana kelas

export interface SeatLayout {
  rows: number; cols: number;       // maks 8 × 10
  aisleAfterCols: number[];         // mis. [4] = lorong setelah kursi ke-4 (hanya tampilan)
  enabled: boolean;                 // false → mode NO_SEAT
}

export type IntegrityFlag =
  | "FOCUS_LOST"          // keluar aplikasi/tab saat LOOK/WALK
  | "FULLSCREEN_EXIT"
  | "TOO_FAST"            // rute ≥ 3 langkah dengan rata-rata < 400 ms per langkah
  | "SECOND_DEVICE"       // token yang sama mencoba masuk dari perangkat lain
  | "SEAT_CHANGED";       // pindah kursi setelah ronde dimulai

export interface TutorialResult {
  sessionId: string; studentId: string;
  completed: boolean;             // 5 langkah tanpa demo otomatis
  totalMs: number;
  step3Attempts: number;
  hints: number;                  // jumlah tangan bayangan yang muncul
  probeCorrect: boolean | null;   // soal ingatan langkah 4
  autoDemoSteps: number[];        // langkah yang diselesaikan demo otomatis
  steps: { step: number; attempts: number; hintsShown: number;
           invalidTaps: number; undo: number; ms: number }[];
}
```

---

## 4. Konfigurasi Ronde (shared/src/rounds.ts)

| roundId | Kondisi | Tempat/Jalan | Paket | Jebakan | lookMs | walkMs | scored |
|---|---|---|---|---|---|---|---|
| 0 | VISIBLE | 4/4 | 0 | tidak | 5000 | 20000 | false |
| 1 | VISIBLE | 5/6 | 0 | tidak | 5000 | 20000 | true |
| 2 | HIDDEN | 5/6 | 0 | tidak | 5000 | 20000 | true |
| 3 | VISIBLE | 6/7 | 0 | ya | 6000 | 25000 | true |
| 4 | HIDDEN | 6/7 | 0 | ya | 6000 | 25000 | true |
| 5 | VISIBLE | 6/8 | 0 | ya | 6000 | 25000 | true |
| 6 | HIDDEN | 6/8 | 0 | ya | 6000 | 25000 | true |
| 7 | VISIBLE | 6/8 | 1 | tidak | 6000 | 30000 | true |
| 8 | HIDDEN | 6/8 | 1 | tidak | 6000 | 30000 | true |
| 9 | VISIBLE | 7/9 | 2 | tidak | 7000 | 35000 | true |
| 10 | HIDDEN | 7/9 | 2 | tidak | 7000 | 35000 | true |

- `STANDARD` = ronde 0–10.
- `QUICK` = ronde 0, 1, 2, 3, 4, 7, 8. Tampilan nomor ronde berurutan 1–6, tetapi `roundId` asli tetap disimpan.
- Durasi tetap lainnya: `PROBE_MS = 5000`, `RESULT_MS = 3000`, `LEADERBOARD_MS = 3000`, `GRACE_MS = 2000`.
- **Empat soal per ronde:** setiap ronde 1–10 punya 4 soal setara di `poolA.json` / `poolB.json` (slot 0–3); ronde latihan 0 punya 1 soal. Siswa mendapat slot sesuai kursinya (Bagian 8.6).
- **Pasangan setara:** ronde genap (HIDDEN) memakai peta dengan parameter dan selisih biaya ke rute kedua yang sama dengan ronde ganjil sebelumnya, tetapi angka dan tata letaknya berbeda.

---

## 5. Aturan Interaksi Rute (shared/src/route.ts)

State rute per pemain per ronde:

```ts
interface RouteState {
  path: NodeId[];               // dimulai [start]
  collected: Set<NodeId>;       // stop yang sudah diambil (diturunkan dari path)
  invalidTaps: number; undo: number; revisits: number;
  tapLog: TapEvent[];
  done: boolean;
}
```

| Aksi | Kondisi | Efek |
|---|---|---|
| Ketuk node | Fase bukan WALK | Diabaikan, tidak dicatat |
| Ketuk node | Node = posisi sekarang | Diabaikan, tidak dicatat |
| Ketuk node | Tidak bertetangga dengan posisi sekarang | `invalidTaps++`, log `valid:false`, UI: node bergetar 300 ms |
| Ketuk node | Bertetangga | `path.push(node)`. Jika node sudah ada di `path` sebelumnya → `revisits++`. Log `valid:true` |
| Batal | `path.length > 1` | `path.pop()`, `undo++`, log `UNDO` |
| Batal | `path.length == 1` | Diabaikan |
| Selesai otomatis | Posisi = goal **dan** semua `stops` ada di `path` | `done = true`, kirim hasil |
| Lewat goal | Paket belum lengkap | Boleh lanjut; tampilkan "Paket belum lengkap!" |

Definisi turunan:

- `collected` = `stops ∩ path`. Jadi Batal melewati stop otomatis "melepas" paketnya.
- `playerCost` = jumlah `w` setiap edge berurutan di `path`; edge yang dilewati berulang dihitung berulang.
- `steps` (L) = `path.length - 1` pada saat selesai atau saat waktu habis.
- `tFirstMs` = `tMs` dari ketukan valid pertama; `null` bila tidak ada.

---

## 6. Alur Sesi dan Waktu (server/src/session.ts)

```
FULL : LOBBY → INTRO_IDENT → INTRO_TRAILER → TUTORIAL → ronde 1..N → PODIUM → ENDED
SHORT: LOBBY → INTRO_IDENT (ringkas) → INTRO_TRAILER (ringkas) → ronde 0..N → PODIUM → ENDED
satu ronde: LOOK → WALK → (PROBE jika HIDDEN) → RESULT → LEADERBOARD
```

| Fase | Durasi | Catatan |
|---|---|---|
| LOBBY | sampai host menekan Mulai | Pemain bergabung dengan kode 6 digit + nama panggilan. Tombol Mulai sekaligus membuka izin audio browser |
| INTRO_IDENT | 8000 ms (SHORT: 3000) | Ident hanya di proyektor; perangkat siswa menampilkan layar READY glitch (12A.9) |
| INTRO_TRAILER | 45000 ms (SHORT: 12000) | Trailer hanya di proyektor; siswa tetap di layar READY, 3 detik terakhir menjadi hitung mundur 3–2–1 lalu GO!; host bisa menahan Lewati 2 detik |
| TUTORIAL | maks 90000 ms, hanya FULL | Berakhir saat semua siswa selesai atau batas tercapai |
| LOOK | `lookMs` | Peta + angka tampil, ketukan diabaikan |
| WALK | `walkMs` atau lebih cepat | Berakhir saat **semua** pemain yang terhubung sudah selesai atau waktu habis |
| PROBE | 5000 ms | Hanya HIDDEN. 3 tombol angka |
| RESULT | 3000 ms | Host: rute optimal + % kelas yang optimal. Player: poin ronde |
| LEADERBOARD | 3000 ms | Host: 5 besar. Player: peringkat dan poin sendiri |
| PODIUM | sampai host menekan Selesai | 3 besar, tombol unduh laporan |

Ronde latihan (0) melewati fase LEADERBOARD dan tidak memberi poin, sehingga durasinya 28 detik. Pada `introMode = FULL`, ronde 0 tidak dimainkan.

Siswa yang bergabung saat intro diarahkan ke tutorial di perangkatnya. Siswa yang bergabung setelah tutorial ditutup mulai dari ronde berikutnya; ronde yang terlewat dicatat `missed`.

**Waktu dan keadilan jaringan:**

- Server mengirim `phase` beserta `durationMs`. Client memulai timer lokal saat event diterima.
- `tRouteMs` diukur di client sejak fase WALK dimulai di perangkat itu, lalu dikirim bersama rute.
- Server menerima hasil bila `clientElapsedMs ≤ walkMs` **dan** waktu terima server `≤ walkEnd + GRACE_MS`. Nilai `t` di-clamp ke `[0, walkMs]`.
- Bila tidak ada hasil diterima saat WALK berakhir → `timedOut = true`, `tRouteMs = walkMs`, path = path terakhir yang dilaporkan lewat `route:progress`.
- Pemain yang terputus seluruh ronde → `missed = true` dan **dikeluarkan dari perhitungan indeks** (berbeda dengan timeout). Reconnect memakai `studentToken` di localStorage.

---

## 7. Protokol Socket.IO

**Client → Server**

| Event | Payload |
|---|---|
| `host:create` | `{ mode, form: "A" \| "B" (Pool A/B), introMode, seatLayout }` → ack `{ sessionId, code }` |
| `host:skipIntro` | `{ sessionId }` (client mengirim hanya setelah tombol ditahan 2 detik) |
| `tutorial:step` | `{ step, attempts, hintsShown, invalidTaps, undo, ms }` |
| `tutorial:done` | `{ totalMs, autoDemoSteps }` |
| `host:start` | `{ sessionId }` |
| `host:skip` | `{ sessionId }` (lompat ke fase berikutnya) |
| `host:end` | `{ sessionId }` |
| `player:join` | `{ code, nickname, studentToken? }` → ack `{ studentId, studentToken, seatLayout }` atau error |
| `player:seat` | `{ row, col }` → ack ok / `SEAT_TAKEN` / `SEAT_LOCKED` (setelah ronde 1 dimulai) |
| `integrity:event` | `{ type: "FOCUS_LOST" \| "FOCUS_BACK" \| "FULLSCREEN_EXIT", phase, roundId, tMs }` |
| `host:seatLayout` | `{ rows, cols, aisleAfterCols, enabled }` (di lobi) |
| `host:clearSeat` | `{ row, col }` (guru mengosongkan kursi yang salah pilih) |
| `route:progress` | `{ roundId, path, tMs }` (throttle 500 ms; untuk kasus timeout) |
| `route:submit` | `{ roundId, path, clientElapsedMs, tapLog, invalidTaps, undo, revisits }` |
| `probe:answer` | `{ roundId, value, clientElapsedMs }` |

**Server → Client**

| Event | Penerima | Payload |
|---|---|---|
| `lobby:update` | host | `{ players: {nickname, seat}[] }` |
| `seat:update` | semua | `{ taken: {row, col, initials}[] }` (inisial 2 huruf, tidak nama lengkap) |
| `phase` | semua | `{ phase, introMode, roundId?, displayIndex?, totalRounds, condition?, durationMs }` |
| `tutorial:map` | player | `{ step, map }` (peta T-01..T-05) |
| `tutorial:status` | host | `{ ready, total }` |
| `round:map` | player | `{ map: MapDef (soal sesuai slot kursi, sudah diberi varian), showWeights: boolean }` (dikirim saat LOOK; **tanpa** biaya optimal, rute optimal, atau jawaban probe) |
| `round:hideWeights` | player | `{}` (awal WALK, khusus HIDDEN) |
| `walk:status` | host | `{ finished, total }` |
| `probe:question` | player | `{ edgeId, options: number[3] }` |
| `round:result` | player | `{ racePoints, streakBonus, probePoints, totalPoints, optimal: boolean, rank }` |
| `round:summary` | host | `{ items: {slot, map, optimalPath}[4], pctOptimal }` (4 gambar kecil rute terhemat, tanpa data per siswa) |
| `round:reveal` | player | `{ optimalPath (dalam varian siswa itu), optimalCost }` (hanya setelah WALK berakhir untuk semua) |
| `leaderboard` | semua | `{ top5: {nickname, points}[] }` + ke tiap player `{ myRank, myPoints }` |
| `podium` | semua | `{ top3 }` |

Validasi server: hitung ulang `playerCost`, `completed`, `revisits`, dan `steps` dari `path` terhadap peta kanonik. Jangan percaya nilai turunan dari client kecuali `invalidTaps`, `undo`, dan `tapLog`.

---

## 8. Algoritma (shared/)

### 8.1 Solver

```ts
dijkstra(map, from, to): number
optimalCost(map): number
// Coba semua permutasi map.stops (maks 2! = 2).
// Biaya = Σ dijkstra(titik[k], titik[k+1]) untuk [start, ...perm, goal].
optimalRoute(map): NodeId[]          // rute lengkap untuk ditampilkan di RESULT
optimalStopOrder(map): NodeId[]
minHops(map): number                 // sama seperti optimalCost tetapi bobot tiap edge = 1 (BFS)
```

Rute optimal harus **tunggal** (dijamin oleh validator di 8.3).

### 8.2 Generator (scripts/gen-pool.ts + shared/src/generator.ts)

Input: `RoundConfig` dan `rng` ber-seed.

1. Slot grid 3×3 dengan koordinat `(0.1 + 0.4·col, 0.15 + 0.35·row)` plus jitter ±0.04.
2. `start` ditaruh di kolom 0, `goal` di kolom 2. Node lain di slot acak sisanya.
3. Kandidat edge: pasangan node di slot bertetangga (horizontal, vertikal, diagonal). Tolak edge yang memotong edge lain (uji perpotongan segmen) atau melewati node lain.
4. Bangun spanning tree acak dari kandidat, lalu tambah edge acak sampai `nEdges` tercapai.
5. Bobot acak integer 1–9.
6. Pilih `stops` acak dari node selain start dan goal.
7. Untuk ronde HIDDEN: `probeEdgeId` = edge acak dari rute optimal.
8. Jalankan validator. Jika gagal, ulangi dari langkah 5 (maks 200 kali), lalu dari langkah 2 (maks 5000 kali total).

**Bank peta Form A dan Form B sudah disediakan dan diverifikasi** (dibuat oleh `reference/gen.py`, seed `KC-2026-A` dan `KC-2026-B`; ronde 5 Form A adalah fixture Bagian 14.1). Format:

```json
{ "form": "A", "seed": "KC-2026-A", "generatedBy": "oracle gen.py",
  "maps": [ { "roundId": 0, "id": "A-00", "nodes": [...], "edges": [...],
              "start": "n0", "goal": "n3", "stops": [], "probeEdgeId": "..." }, ... ] }
```

**Peran file:** ronde game dimainkan dari **`poolA.json` / `poolB.json`** (Bagian 8.5, dibuat oleh `reference/pool.py`, seed `RR-POOL-A` dan `RR-POOL-B`). `formA.json` / `formB.json` tetap dipakai sebagai fixture uji (T1–T24) dan sumber peta trailer A-05. Format pool:

```json
{ "pool": "A", "seed": "RR-POOL-A", "slots": 4,
  "rounds": [ { "roundId": 1, "items": [ {"id": "PA-01-0", "nodes": [...], "edges": [...], "start": "n0", "goal": "n4", "stops": []}, …4 soal ] }, … ] }
```

Generator TypeScript (`gen-pool.ts`) dibuat untuk Pool baru dan wajib deterministik terhadap seed-nya sendiri. Ia tidak perlu menghasilkan JSON yang sama dengan oracle Python, tetapi validator dan pemeriksa kesetaraan TypeScript **wajib** meluluskan seluruh 22 peta fixture dan 82 soal pool, dan menolak peta rusak di test negatif.

Koordinat `y` di semua file peta bertambah ke bawah (sama dengan koordinat SVG).

### 8.3 Validator (semua syarat wajib)

| # | Syarat |
|---|---|
| V1 | Graf tersambung; jumlah node dan edge sesuai config |
| V2 | Rute optimal tunggal (tidak ada rute lain, termasuk urutan stop lain, dengan biaya sama) |
| V3 | `1 ≤ (biaya rute terbaik kedua − optimal) ≤ 3` |
| V4 | Jika `trap`: rute dengan hop paling sedikit **tidak** optimal |
| V5 | `optimalCost ≤ 25` dan rute optimal ≤ 6 langkah |
| V6 | Tidak ada perpotongan edge; jarak antar-node ≥ 0.18 |
| V7 | Pasangan HIDDEN memiliki selisih V3 yang sama dengan pasangan VISIBLE-nya |
| V8 | Rute optimal tidak mengunjungi tempat yang sama dua kali (agar siswa yang benar tidak terkena penalti kunjungan ulang di Indeks Spasial) |
| V9 | Bobot integer 1–9; stop bukan start/goal; ronde HIDDEN punya `probeEdgeId` di rute optimal |

Peta tutorial divalidasi dengan aturan yang sama. Satu-satunya pengecualian: T-01 boleh gagal V3 karena sengaja hanya punya satu rute. Pengecualian ditulis sebagai daftar id eksplisit (`{ "T-01": ["V3"] }`), bukan dengan mematikan syarat.

"Rute terbaik kedua" dihitung dengan mengenumerasi semua rute sederhana (per segmen antar-titik wajib). Untuk ukuran peta ini, enumerasi habis cukup.

### 8.4 Varian Tampilan (shared/src/variant.ts)

`applyVariant(map, variantId: 0..7, labelSeed): MapDef`

- `variantId` memilih satu dari 8 simetri koordinat terhadap pusat (0.5, 0.5): rotasi 0/90/180/270°, masing-masing bisa dicerminkan horizontal.
- `kind` node selain start dan goal dipermutasi dengan `labelSeed = hash(studentId + roundId + "L")`.
- `id` node dan edge **tidak berubah**, sehingga solver, probe, dan validasi server tetap memakai peta kanonik.
- `variantId` ditentukan dari kursi (Bagian 8.6), bukan acak bebas.

### 8.5 Bank Soal Paralel dan Kenaikan Kesulitan

Setiap ronde 1–10 punya **4 soal setara**. Disebut setara bila keempatnya memiliki:

| Syarat setara (dalam satu ronde) | Alasan |
|---|---|
| Parameter ronde sama (tempat, jalan, paket, jebakan) | Struktur tugas sama |
| Selisih biaya ke rute terbaik kedua sama | Tingkat "ketelitian" yang dibutuhkan sama |
| Langkah rute optimal sama, `minHops` sama | Panjang perencanaan sama |
| `trapDelta` sama (biaya rute paling sedikit belokan − biaya optimal) | Daya tipu jebakan sama |
| Jumlah rute sederhana (pilihan yang dibandingkan) berselisih ≤ 1 | Beban membandingkan sama |
| Biaya optimal berselisih ≤ 3 koin | Beban berhitung sama |
| Bobot/struktur keempat soal berbeda | Jawaban satu soal tidak bisa disalin ke soal lain |

Ronde HIDDEN memakai tanda tangan (selisih, langkah, `minHops`, `trapDelta`) yang sama dengan pasangan VISIBLE-nya. Pool A dan Pool B tidak berbagi soal.

**Kenaikan kesulitan.** Kompleksitas diukur dengan Skor Kompleksitas (SK):

```latex
SK = \text{jalan} + 2 \cdot \text{paket} + \text{langkah optimal} + \min(10, \text{rute sederhana}) + 2 \cdot \text{jebakan} + (4 - \text{selisih})
```

Syarat wajib: SK terkecil di setiap pasangan ronde lebih besar dari SK terbesar pasangan sebelumnya. Rentang rute sederhana per pasangan: ronde 1–2 = 2–3, ronde 3–4 = 2–3 (ditambah jebakan), ronde 5–6 = 4–5, ronde 7–8 = 4–6, ronde 9–10 = 5–8.

| Pasangan ronde | Isi | SK Pool A | SK Pool B |
|---|---|---|---|
| 1–2 | 5 tempat, tanpa jebakan | 12 | 12 |
| 3–4 | 6 tempat, jebakan | 17–18 | 17–18 |
| 5–6 | 6 tempat, jebakan, lebih banyak pilihan | 20 | 20 |
| 7–8 | 1 paket wajib | 21–22 | 21–22 |
| 9–10 | 2 paket wajib, urutan | 23–24 | 23 |

Kenaikan ini diuji oracle (P4). Saat bank dibuat, ditemukan bahwa paket wajib bisa *mengurangi* jumlah pilihan rute, sehingga ronde berpaket justru lebih mudah. Karena itu rentang rute sederhana minimum ditetapkan untuk ronde 7–10.

### 8.6 Distribusi Soal per Kursi (shared/src/distribution.ts)

```ts
// Pola ubin 2×2: kursi bersebelahan 8 arah selalu beda nilai
seatBase(row, col) = 2 * (row % 2) + (col % 2)

// perm = permutasi acak [0..3] per sesi; offset = 0..3 per sesi (PRNG seed = sessionId)
assignSlot(row, col, roundId, perm, offset) = (perm[seatBase(row, col)] + roundId + offset) % 4

// Kursi berjarak 2 yang mendapat soal sama dijamin beda putaran peta
assignVariant(row, col, roundId, offset2) =
  (2 * (floor(row / 2) % 2) + (floor(col / 2) % 2) + 4 * ((roundId + offset2) % 2)) % 8

// Mode tanpa denah (guru tidak mengisi denah): urutan masuk
assignSlotNoSeat(joinIndex, roundId, offset) = (joinIndex + roundId + offset) % 4
assignVariantNoSeat = hash(studentId + roundId) % 8
```

Jaminan yang diuji oracle:

- **P7:** untuk denah sampai 8 × 10, semua 24 permutasi, semua offset, dan semua ronde, tidak ada dua kursi bersebelahan (depan, belakang, samping, diagonal) yang mendapat soal sama.
- **P8:** di Mode Standar setiap siswa mendapat tiap slot 2–3 kali. Bila satu slot sedikit lebih sulit, pengaruhnya tersebar merata ke semua siswa. **P8b:** di Mode Kilat tiap slot maksimal 2 kali.
- **P10:** dalam radius 2 kursi, siswa yang mendapat soal sama selalu melihat putaran peta berbeda.
- **P9:** pada mode tanpa denah, siswa yang masuk berurutan beda soal. Tetangga duduk tidak dijamin, dan laporan mencatat `seatMode = NO_SEAT`.

Contoh hasil pembagian untuk kelas 5 × 8 dengan bangku berdua ada di `docs/preview/seat_distribution.png`.

## 9. Poin Balapan (shared/src/scoring.ts)

```
Q =
  1                         jika optimalHit
  0.5 × ER                  jika completed dan tidak optimal
  0                         jika tidak selesai / timedOut / missed

racePoints = round(1000 × Q × (1 − 0.5 × t / T))
```

dengan `t = tRouteMs / 1000` dan `T = walkMs / 1000`. `round` = pembulatan ke bilangan bulat terdekat (0.5 ke atas).

**Sifat wajib** (harus ada test-nya): rute optimal di `t = T` (500 poin) selalu lebih besar daripada rute tidak optimal di `t = 0` (< 500 poin).

**Bonus beruntun:**

```
streakCount = jumlah ronde scored berturut-turut dengan optimalHit = true, berakhir di ronde ini
streakBonus = optimalHit ? min(300, 100 × (streakCount − 1)) : 0
```

Ronde `missed` memutus beruntun. Ronde latihan tidak dihitung.

**Poin soal ingatan:**

```
probePoints = probeCorrect ? round(200 × (1 − 0.5 × tProbe / 5)) : 0     (tProbe dalam detik)
```

Opsi probe: jawaban benar ditambah 2 pengecoh berbeda dalam rentang 1–9, diambil dari `benar ± {1,2,3}`. Urutan diacak per pemain. Tidak menjawab → `probeCorrect = false`, `probeMs = 5000`.

`totalPoints` = Σ (racePoints + streakBonus + probePoints) dari ronde scored.

---

## 10. Metrik Individu (shared/src/metrics.ts, indices.ts)

### 10.1 Per ronde

- `er = completed ? optimalCost / playerCost : 0`
- `optimalHit = completed && playerCost === optimalCost`
- `errorType`, dicek berurutan (yang pertama cocok dipakai):
  1. `TIMEOUT` jika timedOut
  2. `NONE` jika optimalHit
  3. `STOP_ORDER` jika `nStops ≥ 2` dan urutan stop pertama kali dikunjungi ≠ `optimalStopOrder`
  4. `FEW_ROADS_TRAP` jika `steps === minHops(map)` (dengan V8, rute optimal di ronde jebakan selalu lebih panjang dari `minHops`)
  5. `DETOUR` untuk selain itu

### 10.2 Indeks per siswa

Hanya memakai ronde `scored && !missed`. V = ronde VISIBLE, H = ronde HIDDEN.

```
IL = 100 × [ 0.6 × mean(ER_V) + 0.4 × prop(OH_V) ]

P     = prop(probeCorrect pada ronde H)
ratio = mean(ER_V) > 0 ? min(1, mean(ER_H) / mean(ER_V)) : mean(ER_H)
IM    = 100 × [ 0.5 × P + 0.5 × ratio ]
memoryCost = mean(ER_V) − mean(ER_H)

RTI = ΣTI / (ΣTI + ΣL)                 (0 jika penyebut 0)
RBB = (ΣU + ΣKU) / ΣL                  (jika ΣL = 0 → IS = null)
IS  = 100 × [ 0.5 × (1 − RTI) + 0.5 × max(0, 1 − RBB) ]

RTM            = count(optimalHit) / ( Σ t_semua_ronde / 60 )     t timeout = T
medianCorrectT = median(t pada ronde optimalHit)                   null jika tidak ada
timeoutRate    = count(timedOut) / jumlah ronde
meanER         = mean(ER semua ronde)
medianT        = median(t semua ronde)
```

Indeks bernilai `null` bila kelompok rondenya kosong (misal semua ronde V missed). `null` ditampilkan sebagai "–".

### 10.3 Kuadran profil (dihitung setelah sesi selesai)

Median kelas dihitung dari `meanER` dan `medianT` semua siswa yang punya ≥ 1 ronde tidak missed.

| | `medianT ≤ median kelas` (cepat) | `medianT > median kelas` (lambat) |
|---|---|---|
| `meanER ≥ median kelas` | `MAHIR` — "Cepat dan tepat" | `TELITI` — "Tepat, butuh waktu" |
| `meanER < median kelas` | `TERBURU` — "Terburu-buru, perlu dilatih memeriksa rute" | `DAMPINGI` — "Perlu pendampingan konsep rute hemat" |

### 10.4 Kategori dan catatan otomatis

Kategori indeks: ≥ 85 "Sangat baik"; 70–84.99 "Baik"; 55–69.99 "Cukup"; < 55 "Perlu pendampingan".

Catatan otomatis (tampilkan semua yang cocok, maksimal 3, sesuai urutan):

| Kondisi | Kalimat |
|---|---|
| ≥ 2 ronde `FEW_ROADS_TRAP` | Sering memilih jalan dengan belokan sedikit tanpa menjumlah koinnya. |
| ≥ 1 ronde `STOP_ORDER` | Masih keliru menentukan urutan mampir ke tempat paket. |
| `memoryCost ≥ 0.15` | Logika baik saat angka terlihat, tetapi menurun saat angka hilang. |
| `RTI > 0.15` | Sering mengetuk tempat yang tidak tersambung; perlu latihan membaca peta. |
| `timeoutRate ≥ 0.3` | Sering kehabisan waktu; indeks perlu dibaca hati-hati. |
| tidak ada yang cocok | Pemahaman rute hemat sudah baik dan konsisten. |

---

## 11. Pencatatan dan Ekspor (server/src/store.ts, export.ts)

- Setiap `RoundResult` di-append ke `data/sessions/<sessionId>.jsonl` segera setelah ronde berakhir. Sesi bisa dipulihkan dari file ini.
- `GET /api/sessions/:id/rounds.csv` — satu baris per `RoundResult`. Kolom snake_case sesuai field di Bagian 3 (`tap_log` sebagai string JSON). Pemisah koma, encoding UTF-8 dengan BOM agar terbuka rapi di Excel.
- `GET /api/sessions/:id/students.csv` — satu baris per siswa:
  `student_id, nickname, form, mode, intro_mode, IL, IM, IS, memory_cost, RTM, median_correct_t_s, timeout_rate, mean_er, quadrant, total_points, rounds_played, rounds_missed, tut_completed, tut_total_ms, tut_step3_attempts, tut_hints, tut_probe_correct`
- `GET /api/sessions/:id/tutorial.csv` — satu baris per siswa per langkah tutorial.
- `rounds.csv` juga memuat `item_id, item_slot, seat_mode, seat_row, seat_col, focus_lost, fullscreen_exits, integrity_flags`.
- `students.csv` juga memuat `seat_row, seat_col, integrity_flag_count, integrity_flags_summary`.
- `GET /api/sessions/:id/items.csv` — rekap per soal: `round_id, item_id, slot, n_siswa, mean_er, prop_optimal, median_t_s` untuk memeriksa kesetaraan soal.
- `GET /api/sessions/:id/report.html` — kartu laporan per siswa (siap cetak A4, 2 kartu per halaman). Isi: IL, IM, IS dengan kategori, RTM, waktu tepat median, Biaya Memori, kuadran, catatan otomatis. **Peringkat dan poin balapan tidak dicantumkan.**
- Nama kolom dan format log dibuat generik (`game = "ROUTE_RUSH"`) agar bisa digabung dengan Logic Rush, Invisible Maze, dan Escape The Traffic.

---

## 12. Spesifikasi UI

### 12.1 Umum

- Mobile-first untuk Player (tablet dan HP landscape/portrait). Host dioptimalkan untuk proyektor 16:9.
- Font sans-serif bulat, minimal 18 px untuk teks pemain, 32 px untuk teks host.
- Mode terang saja, kontras tinggi. Warna tidak boleh menjadi satu-satunya penanda: Rumah memakai ikon rumah, tujuan memakai ikon sekolah dan bendera, stop memakai ikon kotak paket.
- Ikon tempat dibuat sendiri dalam SVG sederhana (tanpa aset berhak cipta).

### 12.2 MapView (komponen bersama)

- SVG dengan `viewBox` 0..1000. Node berupa lingkaran berdiameter efektif ≥ 64 px di layar terkecil, dengan ikon dan nama di bawahnya.
- Edge berupa garis tebal abu-abu; lencana bobot berupa lingkaran kuning di titik tengah edge. Pada HIDDEN setelah LOOK, lencana menampilkan "?".
- Jejak rute: edge yang dilewati menjadi hijau tebal. Kurir (ikon skuter) beranimasi 200 ms ke node tujuan.
- Node yang tidak valid saat diketuk bergetar 300 ms.
- Area ketuk node lebih besar dari lingkaran visualnya (radius ketuk +12 px).

### 12.3 Layar Player

| Fase | Tampilan |
|---|---|
| Gabung | Input kode (keypad angka besar) dan nama panggilan (maks 12 karakter, unik dalam sesi) |
| Pilih kursi | Denah kelas dari guru, "Proyektor / papan tulis" di atas. Kursi terisi tampil abu-abu dengan inisial. Siswa mengetuk kursinya lalu "Ya, ini kursiku". Dilewati bila denah dimatikan |
| Tunggu lobi | "Kamu sudah masuk! Tunggu guru memulai." |
| INTRO_IDENT / INTRO_TRAILER | Layar READY glitch (12A.9): motif peta A-05, kata READY dengan glitch, "Halo, {nickname}!", "Lihat ke layar depan", bilah sisa waktu intro, hitung mundur 3–2–1–GO! di akhir |
| LOOK | Peta dengan angka, label "Lihat baik-baik!" (+ "Angka akan hilang!" untuk HIDDEN), bilah waktu |
| WALK | Peta, bilah waktu (merah saat sisa ≤ 5 detik), penghitung koin (hanya VISIBLE), tombol Batal ↶ |
| Selesai | "Sudah sampai! Menunggu teman…" + total koin rute |
| PROBE | Peta tanpa angka, satu jalan disorot berkedip, pertanyaan "Berapa koin di jalan ini?" + 3 tombol besar |
| RESULT | Bintang (3 = optimal, 2 = ER ≥ 0.8, 1 = selesai, 0 = tidak selesai) + poin ronde |
| LEADERBOARD | "Peringkatmu: #7 · 3.420 poin" |
| PODIUM | Posisi dan poin akhir + pesan positif |

### 12.4 Layar Host

| Fase | Tampilan |
|---|---|
| Buat sesi | Pilih Mode (Standar/Kilat), Bentuk (A/B), dan Intro ("Sesi perdana kelas ini" = FULL, "Sudah pernah main" = SHORT), tombol Buat |
| LOBBY | Kode sesi sangat besar, pengaturan denah (baris, kolom, lorong, atau matikan), denah langsung dengan inisial siswa di kursinya, kursi kosong, jumlah pemain, tombol Mulai. Guru bisa mengetuk kursi untuk mengosongkannya |
| LOOK/WALK | Nomor ronde, jenis ronde, hitung mundur besar, "18/28 sudah sampai". **Peta tidak ditampilkan** |
| RESULT | Empat gambar kecil rute terhemat (soal 1–4) + "% kelas menemukan rute terhemat". Tidak menampilkan hasil per siswa atau per kursi |
| LEADERBOARD | 5 besar (nama + poin). Tidak pernah menampilkan peringkat bawah |
| PODIUM | 3 besar, tombol Unduh rounds.csv, students.csv, dan Laporan |
| Kontrol | Tombol Lewati dan Akhiri di pojok, dengan konfirmasi |

### 12.5 Teks (shared/src/copy.ts)

```ts
export const COPY = {
  narratorIntro:
    "Siap jadi kurir? Semua teman di kelas mendapat peta pada waktu yang sama. " +
    "Lihat angkanya baik-baik, kadang angkanya akan hilang! Ketuk jalan yang paling hemat. " +
    "Yang hemat dan cepat dapat poin paling banyak. Jangan buru-buru, rute yang hemat " +
    "selalu lebih banyak poinnya. Ayo mulai!",
  rules: [
    "Kamu kurir. Antar paket dari Rumah ke Sekolah.",
    "Ketuk tempat yang mau kamu lewati, satu per satu.",
    "Angka di jalan adalah koin. Cari total koin paling sedikit.",
    "Ada kotak paket? Kamu wajib mampir ke sana.",
    "Jalan hemat yang lambat tetap lebih untung daripada jalan boros yang cepat!",
  ],
  look: "Lihat baik-baik!",
  willHide: "Angka akan hilang!",
  packagesMissing: "Paket belum lengkap!",
  arrived: "Sudah sampai! Menunggu teman…",
  probeQuestion: "Berapa koin di jalan ini?",
  timeUp: "Waktu habis! Tidak apa-apa, coba lagi di ronde berikutnya.",
  podiumCheer: "Hebat! Kamu sudah jadi kurir yang hemat.",
  gameTitle: "ROUTE RUSH",
  tagline: "Hitung. Ingat. Temukan jalannya.",
  lookFront: "Lihat ke layar depan",
  readyWord: "READY",
  readyHello: (nickname: string) => `Halo, ${nickname}!`,
  readyNoName: "Kamu sudah masuk!",
  readyCountdownHint: "Bersiap…",
  readyGo: "GO!",
  readyGoHint: { FULL: "Tutorial dimulai", SHORT: "Ronde latihan dimulai" },
  tutorialReady: "Kamu siap! Tunggu teman-temanmu…",
  tutorial: [
    "Ketuk Pasar untuk berangkat.",
    "Coba ketuk Sekolah. Bisa tidak?",
    "Cari jalan yang koinnya paling sedikit. Jumlahkan dulu!",
    "Ingat angkanya baik-baik. Sebentar lagi hilang!",
    "Ada paket di Taman. Ambil dulu, baru ke Sekolah.",
  ],
  tutorialNotConnected: "Belum tersambung. Cari jalannya!",
  tutorialRetry: "Jalan itu lebih mahal. Coba lagi!",
  undoHint: "Salah jalan? Tekan panah ini untuk mundur.",
  seatPick: "Pilih tempat dudukmu",
  seatFront: "Proyektor / papan tulis",
  seatConfirm: "Ya, ini kursiku",
  seatTaken: "Kursi ini sudah dipakai teman",
  seatLocked: "Kursi tidak bisa diganti. Minta bantuan guru.",
  fullscreenBack: "Kembali ke layar penuh untuk lanjut bermain",
  secondDevice: "Nama ini sedang dipakai di perangkat lain.",
  shortIntroVo: "Ingat, cari jalan paling hemat!",
  placeNames: {
    home: "Rumah", school: "Sekolah", market: "Pasar", park: "Taman",
    mosque: "Masjid", shop: "Toko", library: "Perpustakaan",
    clinic: "Puskesmas", field: "Lapangan",
  },
};
```

Narasi diputar dari file VO di `assets/audio/vo/` lewat speaker proyektor. Bila file VO belum tersedia (mode pengembangan), cadangannya Web Speech API (`speechSynthesis`, `lang: "id-ID"`). Teks selalu tampil sebagai subtitle.

---

## 12A. Intro Sinematik dan Tutorial

### 12A.1 Ringkasan

Intro terdiri dari tiga babak. **Ident** 8 detik dan **trailer** 45 detik diputar di proyektor untuk ditonton bersama, lalu **tutorial** 5 langkah dimainkan di perangkat siswa (maks 90 detik). Kesannya seperti pembuka film studio besar, tetapi setiap adegan memperkenalkan aturan yang nanti dipraktikkan.

Prinsip:

1. **Tunjukkan, jangan jelaskan.** Teks layar maksimal 6 kata per kartu.
2. **Satu adegan, satu aturan.** Setiap aturan dilihat di trailer, lalu dipraktikkan di tutorial.
3. **Data asli.** Peta trailer adalah A-05 dari bank. Angka 9 (jebakan) dan 8 (hemat) dihitung saat runtime dengan fungsi `shared/`, tidak diketik di komponen.
4. **Tidak memakan jatah bermain.** Versi penuh hanya di sesi perdana; sesi berikutnya ringkas 15 detik.

### 12A.2 Data timeline (`shared/intro/timeline.json`, DISEDIAKAN)

`timeline.ts` dibangun dari file ini. Struktur per shot:

```ts
interface Shot {
  id: string;            // "ident-1".."ident-6", "shot-01".."shot-10"
  startMs: number; endMs: number;
  visual: string;        // deskripsi untuk implementasi komponen shot
  sfx: string;
  vo: string | null;     // narasi; juga menjadi subtitle
  screenText: string | null;  // boleh berisi {trapCost} dan {optimalCost}
}
// + identShort {fromMs: 4000, toMs: 7000}
// + trailerShort: short-04, short-05, short-08 masing-masing 4000 ms (dari shot-04, 05, 08)
// + reducedMotionStills: ["shot-02","shot-04","shot-05","shot-06","shot-08","shot-09"]
```

### 12A.3 Ident (8 detik)

Titik-titik kota menyala, garis jalur menjalar di antaranya, lalu jaringan merapat menjadi logo pembuat. Penonton merasakan "produksi resmi" sekaligus melihat bahasa visual game.

| Shot | Waktu | Visual | Audio |
|---|---|---|---|
| ident-1 | 0–1 s | Layar #0B1E3A, satu titik kuning berdenyut | Dengung rendah naik |
| ident-2 | 1–2,5 s | Lima titik muncul dengan letup, tersebar seperti peta kota | 5 denting koin bernada naik |
| ident-3 | 2,5–4 s | Garis jalur menjalar; satu jalur berubah hijau | Desir, nada tarik |
| ident-4 | 4–5,5 s | Kamera mundur, jaringan berputar 30° menjadi logo pembuat | Sonic logo 3 nada |
| ident-5 | 5,5–7 s | Logo + nama pembuat + "mempersembahkan", kilau sekali | Gema |
| ident-6 | 7–8 s | Memudar ke hitam | Hening |

Logo pembuat dibaca dari `assets/brand/logo.svg` dan `assets/brand/name.txt`. Bila belum ada, build produksi gagal (lihat 0A.1).

### 12A.4 Trailer (45 detik)

| Shot | Waktu | Visual | Narasi / teks layar | Aturan |
|---|---|---|---|---|
| 01 | 0–4 s | Hitam, kartu teks huruf demi huruf | "Di sebuah kota kecil…" | – |
| 02 | 4–9 s | Dolly-in ke kota pagi, paralaks 3 lapis, 6 bangunan menyala | – | Tempat di peta |
| 03 | 9–13 s | Paket "Untuk: Sekolah" di depan Rumah; kurir datang dengan skuter, memasang helm | VO: "Setiap hari, ada paket yang harus diantar." | Misi |
| 04 | 13–18 s | **Match cut**: kamera naik, kota menjadi peta A-05, angka koin muncul satu per satu | VO: "Tapi setiap jalan ada harganya." | Angka = koin |
| 05 | 18–23 s | Rute jebakan merah putus-putus (total {trapCost}), lalu rute hemat hijau ({optimalCost}) | VO: "Jalan paling pendek… belum tentu paling hemat." | Jumlahkan koin |
| 06 | 23–28 s | Angka berkedip 2 kali lalu menjadi "?", zoom ke satu jalan | VO: "Dan kadang… angkanya menghilang." Teks: "INGAT!" | Memori |
| 07 | 28–33 s | Montase 4 × 1,25 s: paket di Taman, jari mengetuk, bilah waktu, papan 5 besar | VO: "Satu kelas. Satu peta. Siapa kurir paling hemat?" | Wajib mampir, balapan |
| 08 | 33–38 s | Garis hijau menulis judul **ROUTE RUSH** | – | – |
| 09 | 38–43 s | Tiga kata + ikon kalkulator, otak, peta | "Hitung. Ingat. Temukan jalannya." | Logika, memori, spasial |
| 10 | 43–45 s | Kurir melaju keluar frame, wipe | VO: "Siap? Kita latihan dulu!" | Transisi |

`{trapCost}` = biaya rute dengan hop paling sedikit di A-05 (n0→n2→n3→n5 = 9). `{optimalCost}` = `optimalCost(A-05)` = 8.

### 12A.5 Tutorial (perangkat siswa, maks 90 detik)

Anak baru bisa lanjut setelah berhasil melakukan aksinya. Bila diam lebih dari 4 detik, muncul tangan bayangan yang menunjuk tempat yang benar. Tutorial memakai `RouteState` dan aturan ketukan yang sama dengan game.

| Langkah | Peta (`tutorial.json`) | Diajarkan | Syarat lanjut | Umpan balik |
|---|---|---|---|---|
| 1 | T-01: Rumah–Pasar–Sekolah (2, 3) | Ketuk untuk bergerak | Sampai Sekolah (5 koin) | "Bagus!" + bintang kecil |
| 2 | T-02: Rumah tidak tersambung ke Sekolah | Hanya tempat tersambung | Sampai Sekolah lewat jalan mana pun | Sekolah bergetar: "Belum tersambung. Cari jalannya!" |
| 3 | T-03: jalan 2 belokan = 9, jalan 3 belokan = 7 | Jumlahkan koin | Rute 7 koin | Bila 9: kedua rute berdampingan, "Jalan itu lebih mahal. Coba lagi!", peta diulang; tombol Batal berkedip + "Salah jalan? Tekan panah ini untuk mundur." |
| 4 | T-04: angka tampil 4 s lalu "?" | Mengingat angka | Sampai Sekolah (4 koin) + jawab soal jalan Lapangan–Sekolah | Benar/salah sama-sama lanjut; angka asli ditampilkan sebentar |
| 5 | T-05: paket di Taman, ada jalan pintas 2 koin tanpa Taman | Wajib mampir | Sampai Sekolah dengan paket (6 koin) | "Paket belum lengkap!" bila lewat jalan pintas |

Setelah langkah 5: "Kamu siap! Tunggu teman-temanmu…". Siswa yang belum selesai saat batas 90 detik melihat demo otomatis langkah tersisa (5 detik per langkah) lalu ikut ronde pertama. Data tutorial tidak masuk ke IL/IM/IS.

Catatan otomatis tambahan di kartu laporan siswa: `tut_step3_attempts ≥ 3` → "Masih belajar menjumlahkan koin saat tutorial."; tutorial tidak selesai → "Tutorial tidak selesai; hasil ronde awal perlu dibaca hati-hati." Catatan ini ikut batas maksimal 3 catatan, ditempatkan setelah catatan ronde.

### 12A.6 Gaya visual

Flat 2,5D, kota kecil Indonesia pagi hari (rumah beratap genteng, masjid berkubah, pasar bertenda). Warna sama persis dengan warna game:

| Unsur | Warna |
|---|---|
| Langit malam ke pagi | #0B1E3A → #FFB38A |
| Rumah | #1565C0 |
| Sekolah | #C62828 |
| Tempat lain | #5E35B1 |
| Paket / tempat wajib mampir | #EF6C00 |
| Jalan | #9E9E9E |
| Jalur hemat, garis judul | #2E7D32 |
| Jalur jebakan (garis putus-putus) | #E53935 |
| Lencana koin | #F9A825 di atas #FFF8E1 |

- **Tipografi:** Baloo 2 untuk judul dan kartu teks, Nunito untuk subtitle dan tutorial (keduanya OFL). File font disertakan di `client/public/fonts/` (bukan dimuat dari CDN), karena jaringan sekolah sering lambat. Subtitle minimal 4% tinggi layar.
- **Kurir:** anak 12 tahun, helm kuning berkaca pelindung, rompi oranye, skuter listrik kecil. Orisinal, dibangun dari bentuk SVG dasar, netral gender, selalu berhelm.
- **Gerak:** masuk ease-out dengan overshoot 8%, keluar ease-in; letup angka skala 0 → 1,15 → 1 dalam 250 ms; paralaks 0,3× / 0,6× / 1×; transisi utama match cut kota → peta.
- **Aman untuk mata:** tidak ada kedipan lebih dari 3 kali per detik, guncangan maks 6 px, kontras teks minimal 4,5:1.

### 12A.7 Audio

- Suara hanya dari speaker proyektor. Perangkat siswa senyap secara bawaan. Subtitle tidak bisa dimatikan.
- Musik orisinal 45 detik, 100 BPM, piano di awal, drum masuk detik 28, puncak di detik 33. Lisensi tertulis disimpan di `assets/audio/LICENSES.md`.
- VO direkam pengisi suara manusia (logat Indonesia netral). Cadangan pengembangan: Web Speech API `id-ID`.
- Efek: denting koin, letup, desir, klik helm, nada salah lembut, nada benar, detak jantung, hentakan judul, sonic logo.
- Campuran −16 LUFS ±1. Musik turun 8 dB saat VO. Tidak ada efek melonjak lebih dari 6 dB di atas musik.
- Kalimat tutorial diputar sekali di proyektor saat tutorial dimulai, lalu tampil sebagai teks di perangkat sesuai langkah masing-masing.

### 12A.8 Implementasi

1. React + SVG + Web Animations API. Tanpa pustaka animasi berbayar dan tanpa file video.
2. `IntroClock` yang bisa dikendalikan, agar test bisa melompat ke detik tertentu secara deterministik.
3. Semua aset dimuat sebelum `INTRO_IDENT`; host menampilkan bilah pemuatan. Total aset intro maks 5 MB.
4. Target 60 fps di laptop sekolah kelas menengah: elemen SVG aktif kurang dari 500, tanpa filter blur, animasi hanya `transform` dan `opacity`.
5. `prefers-reduced-motion` di host: trailer diganti 6 gambar diam (`reducedMotionStills`) dengan VO dan subtitle yang sama, durasi tetap 45 detik.
6. Tombol Lewati di host harus ditahan 2 detik (mencegah terpencet tidak sengaja).

---

### 12A.9 Layar siswa saat intro: READY glitch

Intro (ident dan trailer) **hanya tampil di proyektor**. Selama `INTRO_IDENT` dan `INTRO_TRAILER`, perangkat siswa menampilkan satu layar tunggu bergaya glitch yang menegaskan "kamu sudah siap" dan mengarahkan mata ke layar depan. Acuan visual dan gerak yang wajib diikuti: `docs/reference-ui/ready-glitch.html` (buka di browser, bisa diberi `?name=Budi&ms=8000`).

**Susunan layar (rata tengah, satu fokus):**

```
        [motif peta A-05: jalur hemat tergambar pelan]
                    R E A D Y        ← glitch kanal biru/merah
                  Halo, {nickname}!
           [ikon proyektor] Lihat ke layar depan
           ━━━━━━━━━━━━━━━──────────  ← sisa waktu intro (kuning koin)
```

| Elemen | Spesifikasi |
|---|---|
| Latar | Gradien radial #10294D → #0B1E3A → #071428 (menyambung warna ident), garis pindai 1 px dengan opasitas 2,5% |
| Motif peta | Tata letak asli A-05 diskalakan, jalan tipis, rute optimal digambar dalam 3,2 s lalu "bernapas" pelan. Koordinat dibaca dari `formA.json`, tidak diketik ulang |
| Kata READY | Baloo 2 800, `clamp(60px, 20vw, 160px)`, warna #FFF8E1 |
| Glitch | Dua salinan kata: kanal biru (#4C8DFF, turunan warna Rumah) dan merah (#FF5A5A, turunan warna Sekolah), `mix-blend-mode: screen`. Saat diam: geser ±1,5 px, opasitas 35%. Saat burst: 4 irisan `clip-path` bergeser ±7 px + sedikit skew, 320 ms, `steps(4)` |
| Ritme burst | Jeda acak 2,4–3,6 s dari PRNG ber-seed (`seed = hash(studentId)`), sehingga perangkat bersebelahan tidak glitch bersamaan dan hasilnya deterministik untuk test |
| Sapaan | "Halo, {nickname}!" dari data server; bila belum ada nama: "Kamu sudah masuk!" |
| Petunjuk | Ikon proyektor + "Lihat ke layar depan" (Nunito 600, opasitas 62%) |
| Bilah waktu | Lebar 0 → 100% mengikuti sisa `durationMs` gabungan ident + trailer dari event `phase`, warna #F9A825 |
| Hitung mundur | 3 detik terakhir trailer: kata berganti 3 → 2 → 1 (tiap ganti memicu satu burst), petunjuk "Bersiap…", lalu "GO!" + "Tutorial dimulai" (FULL) atau "Ronde latihan dimulai" (SHORT) |
| Lewati | Bila host melewati trailer, perangkat langsung menampilkan "GO!" selama 600 ms lalu pindah fase |

**Aturan perilaku:**

- Layar ini tidak menerima input apa pun dan tidak berbunyi. Tujuannya membuat siswa menonton proyektor, bukan bermain dengan HP.
- Kecerahan konten rendah (latar gelap) agar perhatian tertarik ke proyektor.
- Siswa yang bergabung di tengah intro langsung melihat layar ini dengan bilah waktu yang sudah sesuai sisa durasi.
- **Aman untuk mata:** glitch hanya menggeser irisan teks; latar dan kecerahan layar tidak pernah berubah. Area yang berubah saat burst kurang dari 10% layar, burst paling sering satu kali per 2,4 s, sehingga di bawah batas 3 kedipan per detik.
- `prefers-reduced-motion`: tanpa burst dan tanpa animasi peta; kata READY diam dengan geser kanal ±2 px; hitung mundur tetap berganti angka tanpa efek.
- Animasi hanya memakai `transform`, `opacity`, dan `clip-path`; CPU rendah agar baterai HP siswa awet.

---

## 12B. Sistem Anti-Contek

Prinsipnya: **mencegah lebih dulu, mencatat bila terjadi, dan tidak menghukum otomatis.** Contekan dibuat tidak berguna lewat soal yang berbeda. Perilaku mencurigakan hanya dicatat untuk dibaca guru, karena di kelas SD banyak penyebab yang tidak disengaja (notifikasi, HP tersenggol).

### 12B.1 Lapisan pencegahan

| Lapisan | Cara kerja | Mencegah |
|---|---|---|
| 1. Soal berbeda per tetangga | 4 soal setara per ronde, dibagi per kursi (8.6). Tetangga 8 arah selalu beda soal | Menyalin rute dari layar teman |
| 2. Peta berbeda tampilan | Rotasi/cermin per kursi + nama tempat diacak per siswa | Mengenali soal yang sama dari jauh |
| 3. Kunci jawaban tidak pernah di perangkat | `round:map` tidak memuat biaya optimal, rute optimal, atau jawaban probe. Opsi probe dikirim tanpa penanda benar. Jawaban baru dikirim lewat `round:reveal` setelah WALK berakhir untuk semua siswa | Membaca jawaban dari kode atau jaringan |
| 4. Angka benar-benar hilang | Pada ronde HIDDEN, client menghapus bobot dari state dan DOM saat WALK dimulai; komponen peta dirender ulang dari data tanpa bobot | Melihat angka lewat inspeksi elemen |
| 5. Proyektor tidak membocorkan | Peta tidak pernah tampil di proyektor saat LOOK/WALK; RESULT hanya menampilkan rute terhemat setelah semua selesai | Melihat jawaban di layar depan |
| 6. Satu siswa satu perangkat | `studentToken` hanya boleh terhubung dari satu perangkat; koneksi kedua ditolak dan dicatat `SECOND_DEVICE` | Dua HP untuk satu nama, atau main untuk teman |
| 7. Kursi terkunci | Kursi tidak bisa diganti setelah ronde 1 dimulai, kecuali dikosongkan guru (dicatat `SEAT_CHANGED`) | Pindah kursi supaya soalnya sama dengan teman |
| 8. Layar penuh | Tombol Mulai di HP siswa meminta Fullscreen API bila didukung; seleksi teks, menu klik kanan, dan zoom cubit dimatikan di layar ronde | Membuka aplikasi lain dengan mudah |

### 12B.2 Pencatatan (flag integritas)

| Flag | Dicatat bila | Ditampilkan di |
|---|---|---|
| `FOCUS_LOST` | Event `visibilitychange` menjadi hidden atau `blur` saat LOOK atau WALK | Kartu laporan + `rounds.csv` |
| `FULLSCREEN_EXIT` | Keluar layar penuh saat LOOK atau WALK | Sama |
| `TOO_FAST` | Rute ≥ 3 langkah selesai dengan rata-rata < 400 ms per langkah | Sama |
| `SECOND_DEVICE` | Token yang sama mencoba terhubung dari perangkat kedua | Sama + notifikasi kecil di layar guru |
| `SEAT_CHANGED` | Guru mengosongkan kursi siswa setelah ronde dimulai | Sama |

Aturan flag:

- Flag **tidak mengubah poin, peringkat, atau indeks**. Indeks tetap dihitung, tetapi kartu laporan menulis "Catatan integritas: keluar aplikasi 2 kali saat ronde 4 dan 7" agar guru bisa menilai sendiri.
- Siswa tidak melihat kata "curang". Saat keluar layar penuh, HP menampilkan "Kembali ke layar penuh untuk lanjut bermain" dengan tombol besar. Waktu ronde tetap berjalan.
- Flag tidak pernah ditampilkan di proyektor.

### 12B.3 Pemeriksaan kesetaraan soal setelah sesi

`items.csv` dan `npm run field-check` menghitung rerata ER dan proporsi optimal per soal (slot) di setiap ronde. Bila satu slot berbeda bermakna dari tiga lainnya (Kruskal-Wallis p < 0,05, atau selisih rerata ER > 0,15), soal itu ditandai untuk diganti dengan soal baru dari generator yang lolos syarat 8.5. Dengan begitu, siswa yang mendapat soal berbeda tetap dinilai adil.

---

## 13. Hal di Luar Cakupan (jangan dikerjakan sekarang)

- Akun dan login guru, database permanen, dasbor riwayat lintas sesi.
- Mode main sendiri (non-balapan) dan norma persentil.
- Integrasi tiga game lain (cukup format log yang kompatibel).
- Pemilihan warna atau avatar kurir oleh siswa.
- Deteksi kamera/wajah atau penguncian perangkat tingkat sistem (di luar kendali aplikasi web).
- Fitur lanjutan: pilihan moda (jalan kaki/sepeda) dan jalan ditutup di tengah ronde.

---

## 14. Fixture dan Angka Uji Wajib

### 14.1 Peta fixture (Ronde 5 Form A)

```json
{
  "id": "A-05",
  "nodes": [
    { "id": "n0", "kind": "home",   "x": 0.05, "y": 0.50 },
    { "id": "n1", "kind": "market", "x": 0.30, "y": 0.15 },
    { "id": "n2", "kind": "park",   "x": 0.40, "y": 0.55 },
    { "id": "n3", "kind": "mosque", "x": 0.70, "y": 0.30 },
    { "id": "n4", "kind": "shop",   "x": 0.65, "y": 0.90 },
    { "id": "n5", "kind": "school", "x": 0.95, "y": 0.55 }
  ],
  "edges": [
    { "id": "n0-n1", "a": "n0", "b": "n1", "w": 2 },
    { "id": "n0-n2", "a": "n0", "b": "n2", "w": 5 },
    { "id": "n1-n2", "a": "n1", "b": "n2", "w": 2 },
    { "id": "n1-n3", "a": "n1", "b": "n3", "w": 6 },
    { "id": "n2-n3", "a": "n2", "b": "n3", "w": 1 },
    { "id": "n2-n4", "a": "n2", "b": "n4", "w": 4 },
    { "id": "n3-n5", "a": "n3", "b": "n5", "w": 3 },
    { "id": "n4-n5", "a": "n4", "b": "n5", "w": 2 }
  ],
  "start": "n0", "goal": "n5", "stops": []
}
```

### 14.2 Kasus uji

T1–T24, I1–I8, S1–S4, dan P1–P10 sudah dijalankan pada oracle Python (`reference/test_report.txt`, **65/65 lulus** termasuk sub-kasus). T25–T27 dan I9–I20 khusus implementasi server, client, dan aset, sehingga hanya bisa diuji di kode TypeScript dan Playwright.

Setiap baris di bawah wajib menjadi test TypeScript dengan nilai harapan yang sama persis.

| # | Uji | Hasil yang diharapkan |
|---|---|---|
| T1 | `optimalCost(fixture)` | 8 |
| T2 | `optimalRoute(fixture)` | `["n0","n1","n2","n3","n5"]` |
| T3 | `minHops(fixture)` | 3 |
| T4 | Validator pada fixture dengan config ronde 5 (`trap: true`) | lulus; `secondBestGap` = 1 |
| T5 | Ani: optimal, t = 12 s, T = 25 s | racePoints = 760 |
| T6a | Budi: path `n0,n2,n3,n5` | playerCost = 9, ER = 0.8889 (4 desimal) |
| T6b | Budi: t = 6 s, T = 25 s | racePoints = 391 |
| T6c | Budi | errorType = `FEW_ROADS_TRAP` |
| T7 | Citra: optimal, t = 24 s, T = 25 s | racePoints = 520 |
| T8 | Dodi: timeout dengan path `n0,n1` | racePoints = 0, errorType = `TIMEOUT` |
| T9 | Optimal di t = T dibanding tidak optimal ER = 0.99 di t = 0 | 500 dan 495 |
| T10 | Streak `[1,1,1,1,1]` | bonus `[0,100,200,300,300]` |
| T10b | Streak `[1,1,0,1,1]` | bonus `[0,100,0,0,100]` |
| T11 | Probe benar dalam 2 s / probe salah | 160 / 0 |
| T12 | ER_V = [1, 1, 0.89, 1, 0.8], OH_V = [1,1,0,1,0] | IL = 80.3 (tampilan 1 desimal) |
| T13 | ER_H = [1, 0.8, 0.89, 0, 1], P = 0.8, ER_V seperti T12 | IM = 79.3, memoryCost = 0.200 |
| T14 | ΣTI = 3, ΣL = 40, ΣU = 2, ΣKU = 1 / semua 0 | IS = 92.8 / `null` |
| T15 | 6 ronde optimal, Σt = 180 s | RTM = 2.0 |
| T16 | Route state: ketuk n3 dari n0 | invalidTaps = 1, path `[n0]` |
| T17 | Route state: n0 → n1 → n0 | revisits = 1, steps = 2, playerCost = 4 |
| T18 | Route state: n0 → n1, lalu Batal dua kali | path `[n0]`, undo = 1 |
| T18b | Route state: ketuk posisi sendiri (n0) | invalidTaps = 0, path `[n0]` |
| T19 | Varian 0–7 untuk **seluruh 22 peta bank** | `optimalCost` tetap, id tetap, koordinat dalam 0..1, tidak ada edge berpotongan |
| T20 | Validator untuk seluruh 22 peta bank (termasuk V7 berpasangan) | semua lulus |
| T20b | Test negatif validator: ubah satu bobot sehingga ada dua rute optimal; buat edge berpotongan; bobot 0 atau 10 | masing-masing ditolak dengan kode V2, V6, V9 |
| T21 | Peta nyata **A-09** (stop n2 dan n5), path `n0,n5,n2,n0,n4,n6` | playerCost = 26, errorType = `STOP_ORDER` |
| T22 | Peta A-05 di bank | identik dengan fixture 14.1 |
| T23 | Total durasi ronde maksimal dari `rounds.ts` (LOOK + WALK + PROBE + RESULT + LEADERBOARD) | Standar = 443 s, Kilat = 263 s |
| T24 | Golden: untuk setiap peta di `golden.json` | semua field cocok persis |
| T25 | `assertRoundIntegrity` dengan hasil yang `playerCost`-nya dimanipulasi +1 | melempar error |
| T26 | Ekspor `students.csv` dibandingkan dengan perhitungan ulang dari `rounds.csv` | identik |
| T27 | Server `NODE_ENV=production`: kirim event pembuat bot | event tidak dikenal, tidak ada pemain baru |

### 14.3 Uji intro, tutorial, dan anggaran sesi

| # | Uji | Hasil yang diharapkan |
|---|---|---|
| I1 | Durasi dari `timeline.json` | Ident 8000 ms, trailer 45000 ms, ident ringkas 3000 ms, trailer ringkas 12000 ms |
| I2 | Shot bersambung | Setiap `startMs` = `endMs` shot sebelumnya, shot pertama mulai 0 |
| I3 | Angka shot 5 | {trapCost} = 9 (rute n0→n2→n3→n5, jumlah hop = minHops), {optimalCost} = 8 |
| I4 | Tidak ada angka koin literal | Di `timeline.json` dan di folder `client/src/intro/shots/` |
| I5 | Peta tutorial | Lolos validator (T-01 dengan pengecualian V3); optimal T-01..T-05 = 5, 3, 7, 4, 6 |
| I6 | T-02: ketuk Sekolah dari Rumah | invalidTaps = 1, path `[n0]` |
| I7 | T-05: n0→n2→n4 (jalan pintas) / n0→n1→n3→n4 | tidak selesai, biaya 2 / selesai, biaya 6 |
| I8 | T-03: n0→n3→n4 | biaya 9, bukan optimal, langkah 3 tidak lanjut |
| I9 | Playwright FULL: host + 2 siswa | Ident → trailer → tutorial → ronde 1 (ronde 0 tidak muncul) |
| I10 | Playwright: tahan Lewati 2 detik / tekan sebentar | Trailer berhenti, TUTORIAL mulai / tidak terjadi apa-apa |
| I11 | Playwright dengan `prefers-reduced-motion` | 6 gambar diam, durasi tetap 45 detik |
| I12 | Screenshot jam terkendali di 5, 15, 20, 25, 35 s | Cocok dengan gambar acuan yang disetujui |
| I13 | Pemeriksaan kedipan | Tidak ada elemen berganti opasitas lebih dari 3 kali per detik |
| I14 | Tingkat suara aset (ffmpeg ebur128) | Campuran −16 LUFS ±1 |
| I15 | Data tutorial di log | Hanya dari siswa nyata; bot di sesi TEST bertanda `isBot` |
| I16 | Playwright: perangkat siswa selama INTRO_IDENT dan INTRO_TRAILER | Layar READY tampil dengan nickname dari server; tidak ada elemen ident/trailer dan tidak ada peta yang bisa diketuk di DOM siswa |
| I17 | Hitung mundur siswa | Angka 3 muncul saat sisa trailer 3000 ms ±200 ms menurut jam server; "GO!" saat fase berganti; Lewati di host memunculkan "GO!" ≤ 600 ms |
| I18 | Kedipan layar READY | Latar tidak berubah kecerahan; selang antar-burst ≥ 2400 ms pada 60 detik rekaman |
| I19 | Layar READY dengan `prefers-reduced-motion` | Tidak ada burst dan animasi peta; hitung mundur tetap berjalan |
| I20 | Ritme burst deterministik | Dua kali render dengan `studentId` sama menghasilkan jadwal burst identik; `studentId` berbeda menghasilkan jadwal berbeda |
| S1 | Perdana Standar | 30 + 53 + 90 + 415 + 20 = 608 s |
| S2 | Perdana Kilat | 30 + 53 + 90 + 235 + 20 = 428 s |
| S3 | Lanjutan Standar | 30 + 15 + 443 + 20 = 508 s |
| S4 | Lanjutan Kilat | 30 + 15 + 263 + 20 = 328 s |

### 14.3b Uji bank soal dan anti-contek

P1–P10 sudah dijalankan pada oracle (65/65 lulus). A1–A9 khusus implementasi dan wajib di Vitest/Playwright.

| # | Uji | Hasil yang diharapkan |
|---|---|---|
| P1 | Pool A dan B | Ronde 0 = 1 soal, ronde 1–10 = 4 soal; semua lolos V1–V9 |
| P2 | Kesetaraan dalam ronde | Tanda tangan sama; rute sederhana selisih ≤ 1; biaya optimal selisih ≤ 3; 4 soal berbeda |
| P3 | Pasangan VISIBLE/HIDDEN | Tanda tangan sama |
| P4 | Kenaikan kesulitan | SK min pasangan > SK maks pasangan sebelumnya |
| P5 | `pool_golden.json` | Cocok dengan hasil solver untuk 82 soal |
| P6 | Pool A vs Pool B | 0 soal kembar |
| P7 | Tetangga 8 arah | Selalu beda soal (denah ≤ 8 × 10, semua permutasi/offset/ronde) |
| P8 / P8b | Keseimbangan slot | Standar: tiap slot 2–3 kali; Kilat: maks 2 kali |
| P9 | Tanpa denah | Urutan masuk berurutan beda soal |
| P10 | Radius 2 kursi | Soal sama selalu beda varian |
| A1 | Playwright: dua siswa memilih kursi yang sama | Siswa kedua mendapat `SEAT_TAKEN` |
| A2 | Inspeksi jaringan Playwright selama LOOK/WALK | Tidak ada `optimalCost`, `optimalPath`, atau jawaban probe di payload ke siswa sebelum `round:reveal` |
| A3 | Ronde HIDDEN setelah WALK dimulai | Bobot tidak ada di DOM maupun store client |
| A4 | Dua siswa bersebelahan di sesi Playwright | `itemId` berbeda di setiap ronde |
| A5 | Halaman siswa disembunyikan saat WALK | `focusLost` +1, flag `FOCUS_LOST`, poin tidak berubah |
| A6 | Token sama dari konteks browser kedua | Ditolak, flag `SECOND_DEVICE` pada siswa itu |
| A7 | Rute 4 langkah dikirim dalam 1000 ms | Flag `TOO_FAST`, poin tetap dihitung normal |
| A8 | Ganti kursi setelah ronde 1 dari HP siswa | `SEAT_LOCKED` |
| A9 | Kartu laporan dan proyektor | Flag hanya di laporan guru, tidak pernah di proyektor atau layar siswa lain |

### 14.4 Ringkasan data acuan

Peta tutorial (`tutorial.json`): T-01 = 5 koin (satu rute), T-02 = 3, T-03 = 7 (jebakan 9), T-04 = 4 (probe Lapangan–Sekolah = 1), T-05 = 6 (wajib mampir Taman; jalan pintas tanpa paket = 2 dan ditolak).

Bank peta ronde (dari `golden.json`):

| Peta | Opt | Gap | Langkah opt | minHops | Peta | Opt | Gap | Langkah opt | minHops |
|---|---|---|---|---|---|---|---|---|---|
| A-00 | 8 | 3 | 2 | 2 | B-00 | 11 | 2 | 2 | 2 |
| A-01 | 7 | 2 | 2 | 2 | B-01 | 6 | 3 | 2 | 2 |
| A-02 | 9 | 2 | 2 | 2 | B-02 | 14 | 3 | 2 | 2 |
| A-03 | 8 | 1 | 3 | 2 | B-03 | 14 | 1 | 3 | 2 |
| A-04 | 9 | 1 | 3 | 2 | B-04 | 13 | 1 | 3 | 2 |
| A-05 | 8 | 1 | 4 | 3 | B-05 | 6 | 2 | 3 | 2 |
| A-06 | 7 | 1 | 3 | 2 | B-06 | 10 | 2 | 3 | 2 |
| A-07 | 12 | 3 | 3 | 3 | B-07 | 14 | 1 | 3 | 3 |
| A-08 | 16 | 3 | 4 | 3 | B-08 | 10 | 1 | 3 | 2 |
| A-09 | 15 | 3 | 3 | 3 | B-09 | 15 | 1 | 5 | 4 |
| A-10 | 10 | 3 | 3 | 3 | B-10 | 16 | 1 | 4 | 4 |

---

## 15. Fase Implementasi dan Kriteria Selesai

Setiap fase baru selesai bila: (1) `npm test` hijau, (2) `python3 test_oracle.py` di `reference/` tetap `65/65 lulus`, (3) `TEST_REPORT.md` diperbarui (jumlah test, cakupan, test baru), (4) `npm run lint:nodummy` lulus. Setelah itu berhenti dan laporkan sebelum lanjut.

### Fase 1 — Logika inti (`shared/`)
types, rng, graph, solver, route, scoring, metrics, indices, rounds, budget, copy, `assertRoundIntegrity`, `assertTutorialIntegrity`. Skrip `lint:nodummy` gagal bila menemukan `Math.random`, kata `dummy`, `mock`, `fake`, `lorem`, atau nama pemain contoh di folder `src/` mana pun.
**Selesai bila:** T1–T18b, T21–T25, S1–S4 lulus; cakupan `shared/` ≥ 95% baris; properti 0A.5 (kecuali varian) lulus.

### Fase 2 — Validator, varian, generator, data acuan
Validator V1–V9 (dengan daftar pengecualian tutorial), variant, `distribution.ts`, generator TypeScript, `scripts/gen-pool.ts` (menolak menimpa file bank), pemuat `poolA.json`, `poolB.json`, `tutorial.json`, dan `timeline.json`.
**Selesai bila:** T19, T20, T20b, T24, I1–I8, P1–P10 lulus; properti varian lulus; 20 peta hasil generator TypeScript dengan seed berbeda lolos validator.

### Fase 3 — Server
Express + Socket.IO, state machine lengkap termasuk INTRO_IDENT, INTRO_TRAILER, TUTORIAL; denah kursi dan penguncian; pembagian soal per kursi; pengiriman peta tanpa kunci jawaban; flag integritas; protokol Bagian 7; pemisahan LIVE/TEST; penyimpanan JSONL.
**Selesai bila:** integration test 1 host + 3 bot menyelesaikan sesi FULL dan SHORT di Mode Standar dan Kilat; tutorial berakhir lebih awal saat semua bot selesai; ronde 0 tidak dimainkan pada FULL; timeout dan missed tercatat benar; T27, A2, A4, A6, A8 lulus.

### Fase 4 — Client Player
MapView, pilih kursi, layar penuh, penangkap `visibilitychange`, alur layar Player, layar READY glitch saat intro (12A.9, mengikuti `docs/reference-ui/ready-glitch.html`), tutorial 5 langkah dengan gerbang dan tangan bayangan, reconnect, empty state.
**Selesai bila:** Playwright: 2 pemain melihat layar READY selama intro, menyelesaikan tutorial, dan bermain sampai podium; I16–I20, A1, A3, A5, A7 lulus; ketukan tidak valid bergetar; angka berubah "?" pada HIDDEN; Batal berfungsi; I6–I8 terbukti di UI.

### Fase 5 — Client Host
Layar host, pengaturan dan denah kursi langsung, penghitung "x/y sudah sampai" dan "x/y siap", 4 gambar kecil rute terhemat di RESULT, 5 besar, podium, penghitung hasil ditolak, pilihan introMode.
**Selesai bila:** A9 lulus; peta tidak pernah ada di DOM host saat LOOK/WALK; angka penghitung cocok dengan jumlah pemain nyata; lobi kosong menampilkan "Belum ada pemain".

### Fase 6 — Intro sinematik
IntroPlayer, IntroClock, ident, 10 shot trailer, versi ringkas, gambar diam reduced-motion, subtitle, Lewati tahan 2 detik. Kerjakan bertahap: (a) animatik kotak abu-abu sesuai timeline, (b) visual final.
**Selesai bila:** I9–I13 lulus; 60 fps tercapai pada profil performa Chrome dengan CPU throttling 4×; total aset intro ≤ 5 MB.

### Fase 7 — Audio dan aset
Musik, VO, efek suara, logo pembuat, font lokal. Selama aset final belum ada, aset sementara didaftarkan di `assets/PLACEHOLDERS.md`.
**Selesai bila:** I14 lulus; `LICENSES.md` lengkap; `PLACEHOLDERS.md` kosong; `npm run build` produksi berhasil.

### Fase 8 — Ekspor, laporan, dan uji tempo
rounds.csv, students.csv, tutorial.csv, items.csv, report.html, kuadran, catatan otomatis (termasuk catatan tutorial dan catatan integritas); `npm run simulate -- --players 30` untuk keempat jenis sesi.
**Selesai bila:** T26 lulus; sesi TEST ditolak tanpa `includeTest=1`; CSV terbuka rapi di Excel (BOM UTF-8); laporan tanpa poin/peringkat; durasi simulasi tidak melewati S1–S4; `README.md` lengkap (instalasi, menjalankan di LAN, membuat sesi).

### Fase 9 — Uji lapangan dengan siswa nyata
Dijalankan tim peneliti/guru. Claude Code menyiapkan `npm run field-check -- --session <id>` yang membaca sesi LIVE dan menulis `docs/field-check-<sessionId>.md`.

| Pemeriksaan | Ambang lulus |
|---|---|
| Siswa yang menyelesaikan sesi | ≥ 90% dari yang bergabung |
| Siswa yang menyelesaikan tutorial tanpa demo otomatis | ≥ 85% |
| Siswa yang lulus tutorial langkah 3 dalam ≤ 2 percobaan | ≥ 70% |
| Hasil gagal integritas | 0 |
| Per ronde: siswa sampai sebelum waktu habis | ≥ 85% |
| Per ronde: proporsi OH | 0,30–0,80; di luar rentang ditandai untuk diganti |
| Durasi sesi nyata | Tidak melewati batas S1–S4 |
| Pengaruh varian peta | Rerata ER antar `variantId` tidak berbeda bermakna (Kruskal-Wallis, p > 0,05) |
| Kesetaraan 4 soal per ronde | Rerata ER antar slot tidak berbeda bermakna (Kruskal-Wallis, p > 0,05) dan selisih ≤ 0,15 |
| Persentase siswa dengan denah kursi | ≥ 95% (mode tanpa denah hanya cadangan) |

Soal atau ronde yang gagal ambang diganti dengan soal baru dari generator yang lolos syarat 8.5 (Pool C, D, …); Pool A dan B asli disimpan sebagai arsip. Shot trailer atau langkah tutorial yang gagal ambang diperbaiki lalu diuji ulang di kelas.

### Pertanyaan terbuka (isi sebelum Fase 7)

- Nama dan logo pembuat untuk ident (`assets/brand/`).
- Pengisi suara manusia atau sementara memakai suara sintetis.
- Sumber musik: dibuat khusus atau dibeli dengan lisensi pendidikan.

import { challengeConfig, generateChallengeMap } from "./challenge";
import { signatureOf } from "./equivalence";
import { generateMap, specOf } from "./generator";
import { edgeId } from "./graph";
import { createRng } from "./rng";
import { getRoundConfig } from "./rounds";
import { analyzeRoutes } from "./solver";
import type { MapDef, NodeId } from "./types";

/**
 * Soal beda untuk tiap siswa (anti contek): setiap siswa menerima peta buatan sendiri yang setara tingkat kesulitannya dengan
 * soal acuan ronde itu, tetapi bentuk jalan dan bobotnya tidak sama dengan milik siswa lain. Ronde pertama tetap soal termudah
 * (tingkat 1 pada Tantangan, ronde 1 pada bank A/B); hanya bentuknya yang diacak.
 */

/** Sidik bentuk peta (letak tempat, jalan, dan bobot) untuk memastikan dua siswa tidak mendapat peta yang sama. */
export function mapShapeKey(m: MapDef): string {
  const nodes = m.nodes.map((n) => `${n.x},${n.y}`).join(";");
  const edges = m.edges
    .map((e) => `${e.a}-${e.b}:${e.w}`)
    .sort()
    .join(",");
  return `${nodes}|${edges}|${m.start}>${m.goal}|${m.stops.join(",")}`;
}

/** Hash singkat (FNV-1a, basis 36) untuk membentuk id peta dari benih. */
function shortHash(text: string): string {
  let h = 2166136261;
  for (let i = 0; i < text.length; i++) h = Math.imul(h ^ text.charCodeAt(i), 16777619);
  return (h >>> 0).toString(36).padStart(6, "0");
}

export interface UniqueMapRequest {
  pool: "A" | "B" | "T";
  roundId: number;
  /** Tingkat soal (Tantangan adaptif); untuk bank A/B sama dengan nomor ronde. */
  level: number;
  /** Benih deterministik: sesi, siswa, ronde, dan percobaan. */
  seed: string;
  /** Soal acuan ronde ini (bank A/B): syarat kesetaraan diambil darinya. */
  reference: MapDef;
  /** Ronde ini dimainkan sebagai soal ingatan (angka hilang): peta perlu jalan yang ditanyakan. */
  hidden: boolean;
}

const MAX_TRIES = 400;

/**
 * Membuat satu peta unik. Tantangan: peta baru dengan konfigurasi tingkat itu. Bank A/B: peta baru dengan konfigurasi ronde itu yang
 * jumlah rute sederhananya selisih ≤ 1 dan biaya optimalnya selisih ≤ 3 dari soal acuan (syarat kesetaraan 8.5).
 * Mengembalikan null bila tidak ketemu dalam batas percobaan; pemanggil memakai soal acuan sebagai cadangan.
 */
export function generateUniqueMap(req: UniqueMapRequest): MapDef | null {
  const rng = createRng(req.seed);
  const id = `${req.pool}U-${String(req.roundId).padStart(2, "0")}-${shortHash(req.seed)}`;
  try {
    if (req.pool === "T") return { ...generateChallengeMap(challengeConfig(req.level), rng, id) };
    const config = getRoundConfig(req.roundId);
    const ref = signatureOf(req.reference);
    for (let i = 0; i < MAX_TRIES; i++) {
      const { map } = generateMap(specOf(config), rng, id);
      const sig = signatureOf(map);
      if (Math.abs(sig.simple - ref.simple) > 1 || Math.abs(sig.opt - ref.opt) > 3) continue;
      if (!req.hidden) return map;
      const route = analyzeRoutes(map)?.best.path;
      if (!route) continue;
      const edges = route.slice(1).map((n, k) => edgeId(route[k] as NodeId, n));
      return { ...map, probeEdgeId: edges[rng.int(edges.length)] as string };
    }
  } catch {
    /* generator gagal: pakai soal acuan */
  }
  return null;
}

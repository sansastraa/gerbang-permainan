import { complexityScore, signatureKey, signatureOf, type PoolDef, type Signature } from "./equivalence";
import { edgeId } from "./graph";
import { generateMap, specOf } from "./generator";
import { createRng, type Rng } from "./rng";
import { ROUND_CONFIGS } from "./rounds";
import { analyzeRoutes } from "./solver";
import type { MapDef, NodeId, RoundConfig } from "./types";

/** Rentang jumlah rute sederhana per pasangan ronde (Bagian 8.5). */
const BANDS: Readonly<Record<number, readonly [number, number]>> = { 1: [2, 3], 3: [2, 3], 5: [4, 5], 7: [4, 6], 9: [5, 8] };
const SLOTS = 4;

interface Candidate {
  map: MapDef;
  sig: Signature;
}

const structure = (m: MapDef): string =>
  m.edges
    .map((e) => `${e.a}-${e.b}:${e.w}`)
    .sort()
    .join(",");

/** Cari 4 soal dengan selisih rute sederhana ≤ 1 dan selisih biaya optimal ≤ 3 yang strukturnya berbeda. */
function window(candidates: readonly Candidate[]): Candidate[] | null {
  const sorted = [...candidates].sort((a, b) => a.sig.simple - b.sig.simple || a.sig.opt - b.sig.opt);
  for (let i = 0; i < sorted.length; i++) {
    const base = (sorted[i] as Candidate).sig.simple;
    const pool = sorted.slice(i).filter((c) => c.sig.simple - base <= 1);
    for (let j = 0; j < pool.length; j++) {
      const picked: Candidate[] = [pool[j] as Candidate];
      for (const x of pool.slice(j + 1)) {
        if (picked.length === SLOTS) break;
        const opts = [...picked, x].map((c) => c.sig.opt);
        if (Math.max(...opts) - Math.min(...opts) <= 3) picked.push(x);
      }
      if (picked.length === SLOTS && new Set(picked.map((c) => structure(c.map))).size === SLOTS) return picked;
    }
  }
  return null;
}

export interface PoolBuildOptions {
  /** Jumlah peta yang dicoba per kondisi per putaran (bawaan 500). */
  samples?: number;
  /** Jumlah putaran pengambilan sampel per pasangan ronde (bawaan 4). */
  rounds?: number;
}

const cfg = (id: number): RoundConfig => ROUND_CONFIGS[id] as RoundConfig;

function sampleInto(into: Map<string, Candidate[]>, config: RoundConfig, band: readonly [number, number], n: number, rng: Rng): void {
  for (let i = 0; i < n; i++) {
    const { map } = generateMap(specOf(config), rng, "X");
    const sig = signatureOf(map);
    if (sig.simple >= band[0] && sig.simple <= band[1]) {
      const key = signatureKey(sig);
      into.set(key, [...(into.get(key) ?? []), { map, sig }]);
    }
  }
}

/**
 * Membuat bank soal paralel baru (Pool C, D, …) yang memenuhi syarat 8.5: 4 soal setara per ronde,
 * pasangan VISIBLE/HIDDEN setara, dan kompleksitas naik tiap pasangan. Deterministik terhadap `seed`;
 * huruf terakhir seed menjadi nama bank. Murni: tidak menulis berkas.
 */
export function buildPool(seed: string, options: PoolBuildOptions = {}): PoolDef {
  const samples = options.samples ?? 500;
  const maxRounds = options.rounds ?? 4;
  const letter = seed.slice(-1);
  const rng = createRng(seed);
  const practice = generateMap(specOf(cfg(0)), rng, `P${letter}-00-0`).map;
  const rounds: PoolDef["rounds"] = [{ roundId: 0, items: [practice] }];
  let prevMax = 0;

  for (const visibleId of [1, 3, 5, 7, 9]) {
    const hiddenId = visibleId + 1;
    const band = BANDS[visibleId] as readonly [number, number];
    const vis = new Map<string, Candidate[]>();
    const hid = new Map<string, Candidate[]>();
    let best: { v: Candidate[]; h: Candidate[]; top: number } | null = null;

    for (let attempt = 0; attempt < maxRounds && !best; attempt++) {
      sampleInto(vis, cfg(visibleId), band, samples, rng);
      sampleInto(hid, cfg(hiddenId), band, samples, rng);
      const keys = [...vis.keys()].sort((a, b) => Math.min(hid.get(b)?.length ?? 0, (vis.get(b) as Candidate[]).length) - Math.min(hid.get(a)?.length ?? 0, (vis.get(a) as Candidate[]).length));
      for (const key of keys) {
        const wv = window(vis.get(key) as Candidate[]);
        const wh = window(hid.get(key) ?? []);
        if (!wv || !wh) continue;
        const scores = [...wv.map((c) => complexityScore(cfg(visibleId), c.sig)), ...wh.map((c) => complexityScore(cfg(hiddenId), c.sig))];
        if (Math.min(...scores) <= prevMax || Math.max(...scores) - Math.min(...scores) > 1) continue;
        best = { v: wv, h: wh, top: Math.max(...scores) };
        break;
      }
    }
    if (!best) throw new Error(`buildPool ${seed}: pasangan ronde ${visibleId}-${hiddenId} tidak punya cukup soal setara`);
    prevMax = best.top;

    for (const [rid, picked] of [[visibleId, best.v], [hiddenId, best.h]] as const) {
      const items = picked.map((c, j) => {
        const map: MapDef = { ...c.map, id: `P${letter}-${String(rid).padStart(2, "0")}-${j}` };
        if (cfg(rid).condition === "HIDDEN") {
          const route = (analyzeRoutes(map) as NonNullable<ReturnType<typeof analyzeRoutes>>).best.path;
          const edges = route.slice(1).map((id, i) => edgeId(route[i] as NodeId, id));
          map.probeEdgeId = rng.pick(edges);
        }
        return map;
      });
      rounds.push({ roundId: rid, items });
    }
  }
  rounds.sort((a, b) => a.roundId - b.roundId);
  return { pool: letter, seed, slots: SLOTS, rounds };
}

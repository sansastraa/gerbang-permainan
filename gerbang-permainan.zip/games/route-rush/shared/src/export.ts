import { QUADRANT_LABEL, UI, type IndexCategory, type Quadrant } from "./copy";
import { autoNotes, categoryOf, classMedians, median, quadrantOf, round1, round2, summarizeStudent, type ClassMedians, type StudentSummary } from "./indices";
import { NOTE } from "./copy";
import type { SessionSettings } from "./settings";
import type { ErrorType, IntegrityFlag, RoundResult, TutorialResult } from "./types";

/** Data satu sesi yang cukup untuk semua ekspor (dibaca dari berkas JSONL oleh server). */
export interface SessionExportData {
  sessionId: string;
  kind: "LIVE" | "TEST";
  form: "A" | "B" | "T";
  mode: "STANDARD" | "QUICK";
  introMode: "FULL" | "SHORT";
  /** Waktu sesi dibuat (ms epoch) bila diketahui. */
  createdAt: number | null;
  players: { studentId: string; name: string; isBot: boolean }[];
  rounds: RoundResult[];
  tutorials: { isBot: boolean; result: TutorialResult }[];
  /** Flag tingkat sesi yang dicatat terpisah dari ronde (SECOND_DEVICE, SEAT_CHANGED). */
  integrityEvents: { studentId: string; flag: IntegrityFlag }[];
  /** Pengaturan terakhir sesi (untuk daftar ronde yang direncanakan); opsional agar data lama tetap terbaca. */
  settings?: SessionSettings | null;
  /** Penanda waktu nyata (ms epoch) bila tercatat: tombol Mulai, podium, akhir sesi. Sesi lama belum mencatatnya. */
  startedAt?: number | null;
  podiumAt?: number | null;
  endedAt?: number | null;
}

export const GAME = "ROUTE_RUSH";
export const BOM = "﻿";

// ---------------------------------------------------------------- CSV

const needsQuote = /[",\r\n;]/;
export function csvCell(v: string | number | boolean | null | undefined): string {
  if (v === null || v === undefined) return "";
  const s = typeof v === "boolean" ? (v ? "true" : "false") : String(v);
  return needsQuote.test(s) ? `"${s.replaceAll('"', '""')}"` : s;
}

/** Pemisah koma, akhir baris CRLF; BOM ditambahkan oleh penyaji HTTP (`withBom`) agar Excel membaca UTF-8. */
export function toCsv(headers: readonly string[], rows: readonly (readonly (string | number | boolean | null | undefined)[])[]): string {
  return [headers.map(csvCell).join(","), ...rows.map((r) => r.map(csvCell).join(","))].join("\r\n") + "\r\n";
}

export const withBom = (csv: string): string => (csv.startsWith(BOM) ? csv : BOM + csv);

/** Pembaca CSV sederhana (kutip ganda, koma, CRLF/LF); membuang BOM. */
export function parseCsv(text: string): string[][] {
  const src = text.startsWith(BOM) ? text.slice(1) : text;
  const rows: string[][] = [];
  let row: string[] = [];
  let cell = "";
  let quoted = false;
  for (let i = 0; i < src.length; i++) {
    const ch = src[i] as string;
    if (quoted) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          cell += '"';
          i++;
        } else quoted = false;
      } else cell += ch;
    } else if (ch === '"') quoted = true;
    else if (ch === ",") {
      row.push(cell);
      cell = "";
    } else if (ch === "\n" || ch === "\r") {
      if (ch === "\r" && src[i + 1] === "\n") i++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
    } else cell += ch;
  }
  if (cell !== "" || row.length > 0) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

const num = (s: string | undefined): number | null => (s === undefined || s === "" ? null : Number(s));
const bool = (s: string | undefined): boolean => s === "true";

// ---------------------------------------------------------------- rounds.csv

export const ROUNDS_HEADERS = [
  "game",
  "kind",
  "session_id",
  "student_id",
  "nickname",
  "form",
  "mode",
  "round_id",
  "condition",
  "variant_id",
  "item_id",
  "item_slot",
  "seat_mode",
  "seat_row",
  "seat_col",
  "focus_lost",
  "fullscreen_exits",
  "integrity_flags",
  "n_nodes",
  "n_edges",
  "n_stops",
  "time_limit_s",
  "optimal_cost",
  "player_cost",
  "player_path",
  "completed",
  "optimal_hit",
  "timed_out",
  "missed",
  "er",
  "t_first_ms",
  "t_route_ms",
  "invalid_taps",
  "undo",
  "revisits",
  "steps",
  "probe_correct",
  "probe_ms",
  "race_points",
  "streak_bonus",
  "probe_points",
  "rank_after",
  "error_type",
  "tap_log",
] as const;

/** Satu baris per RoundResult; nama kolom snake_case sesuai field Bagian 3, `tap_log` sebagai string JSON. */
export function roundsCsv(d: SessionExportData): string {
  return toCsv(
    ROUNDS_HEADERS,
    d.rounds.map((r) => [
      GAME, d.kind, r.sessionId, r.studentId, r.nickname, r.form, r.mode, r.roundId, r.condition, r.variantId, r.itemId, r.itemSlot, r.seatMode,
      r.seatRow, r.seatCol, r.focusLost, r.fullscreenExits, r.integrityFlags.join("|"), r.nNodes, r.nEdges, r.nStops, r.timeLimitS, r.optimalCost,
      r.playerCost, r.playerPath.join(">"), r.completed, r.optimalHit, r.timedOut, r.missed, r.er, r.tFirstMs, r.tRouteMs, r.invalidTaps, r.undo,
      r.revisits, r.steps, r.probeCorrect, r.probeMs, r.racePoints, r.streakBonus, r.probePoints, r.rankAfter, r.errorType, JSON.stringify(r.tapLog),
    ]),
  );
}

/** Kebalikan `roundsCsv` (dipakai uji T26 untuk menghitung ulang indeks dari berkas yang diekspor). */
export function parseRoundsCsv(text: string): RoundResult[] {
  const [head, ...rows] = parseCsv(text);
  const col = (r: string[], name: string): string | undefined => r[(head as string[]).indexOf(name)];
  return rows
    .filter((r) => r.length > 1)
    .map((r) => {
      const c = (n: string): string | undefined => col(r, n);
      const pc = c("probe_correct");
      return {
        sessionId: c("session_id") as string,
        studentId: c("student_id") as string,
        nickname: c("nickname") as string,
        form: c("form") as "A" | "B" | "T",
        mode: c("mode") as "STANDARD" | "QUICK",
        roundId: Number(c("round_id")),
        condition: c("condition") as "VISIBLE" | "HIDDEN",
        variantId: Number(c("variant_id")),
        itemId: c("item_id") as string,
        itemSlot: Number(c("item_slot")) as 0 | 1 | 2 | 3,
        seatMode: c("seat_mode") as "SEATED" | "NO_SEAT",
        seatRow: num(c("seat_row")),
        seatCol: num(c("seat_col")),
        focusLost: Number(c("focus_lost")),
        fullscreenExits: Number(c("fullscreen_exits")),
        integrityFlags: (c("integrity_flags") ?? "").split("|").filter(Boolean) as IntegrityFlag[],
        nNodes: Number(c("n_nodes")),
        nEdges: Number(c("n_edges")),
        nStops: Number(c("n_stops")),
        timeLimitS: Number(c("time_limit_s")),
        optimalCost: Number(c("optimal_cost")),
        playerCost: num(c("player_cost")),
        playerPath: (c("player_path") ?? "").split(">").filter(Boolean),
        completed: bool(c("completed")),
        optimalHit: bool(c("optimal_hit")),
        timedOut: bool(c("timed_out")),
        missed: bool(c("missed")),
        er: Number(c("er")),
        tFirstMs: num(c("t_first_ms")),
        tRouteMs: Number(c("t_route_ms")),
        invalidTaps: Number(c("invalid_taps")),
        undo: Number(c("undo")),
        revisits: Number(c("revisits")),
        steps: Number(c("steps")),
        probeCorrect: pc === undefined || pc === "" ? null : pc === "true",
        probeMs: num(c("probe_ms")),
        racePoints: Number(c("race_points")),
        streakBonus: Number(c("streak_bonus")),
        probePoints: Number(c("probe_points")),
        rankAfter: Number(c("rank_after")),
        errorType: c("error_type") as ErrorType,
        tapLog: JSON.parse(c("tap_log") ?? "[]") as RoundResult["tapLog"],
      };
    });
}

// ---------------------------------------------------------------- catatan

const listIds = (ids: readonly number[]): string => (ids.length <= 1 ? String(ids[0] ?? "") : `${ids.slice(0, -1).join(", ")} dan ${ids[ids.length - 1]}`);

export const TUTORIAL_NOTE = {
  step3: "Masih belajar menjumlahkan koin saat tutorial.",
  incomplete: "Tutorial tidak selesai; hasil ronde awal perlu dibaca hati-hati.",
} as const;

/**
 * Catatan otomatis kartu laporan: catatan ronde (10.4) lebih dulu, lalu catatan tutorial; maksimal 3 seluruhnya.
 * "Pemahaman … baik dan konsisten" hanya bila tidak ada catatan lain sama sekali.
 */
export function reportNotes(summary: StudentSummary, tut: TutorialResult | null): string[] {
  const base = autoNotes(summary);
  const roundNotes = base.length === 1 && base[0] === NOTE.allGood ? [] : base;
  const tutNotes: string[] = [];
  if (tut && tut.step3Attempts >= 3) tutNotes.push(TUTORIAL_NOTE.step3);
  if (tut && !tut.completed) tutNotes.push(TUTORIAL_NOTE.incomplete);
  const all = [...roundNotes, ...tutNotes].slice(0, 3);
  return all.length > 0 ? all : [NOTE.allGood];
}

/** Kalimat "Catatan integritas: …" untuk guru; null bila tidak ada kejadian. Tidak memengaruhi poin atau indeks. */
export function integrityNote(rounds: readonly RoundResult[], events: readonly { flag: IntegrityFlag }[]): string | null {
  const parts: string[] = [];
  const focus = rounds.filter((r) => r.focusLost > 0);
  if (focus.length > 0) parts.push(`keluar aplikasi ${focus.reduce((a, r) => a + r.focusLost, 0)} kali saat ronde ${listIds(focus.map((r) => r.roundId))}`);
  const fs = rounds.filter((r) => r.fullscreenExits > 0);
  if (fs.length > 0) parts.push(`keluar layar penuh ${fs.reduce((a, r) => a + r.fullscreenExits, 0)} kali saat ronde ${listIds(fs.map((r) => r.roundId))}`);
  const fast = rounds.filter((r) => r.integrityFlags.includes("TOO_FAST"));
  if (fast.length > 0) parts.push(`rute selesai sangat cepat pada ronde ${listIds(fast.map((r) => r.roundId))}`);
  if (events.some((e) => e.flag === "SECOND_DEVICE")) parts.push("nama dicoba dibuka dari perangkat lain");
  if (events.some((e) => e.flag === "SEAT_CHANGED")) parts.push("kursi dikosongkan guru setelah ronde dimulai");
  return parts.length > 0 ? `Catatan integritas: ${parts.join("; ")}.` : null;
}

function flagCounts(rounds: readonly RoundResult[], events: readonly { flag: IntegrityFlag }[]): Map<IntegrityFlag, number> {
  const m = new Map<IntegrityFlag, number>();
  const add = (f: IntegrityFlag, n = 1): void => void m.set(f, (m.get(f) ?? 0) + n);
  for (const r of rounds) for (const f of r.integrityFlags) add(f, f === "FOCUS_LOST" ? Math.max(1, r.focusLost) : f === "FULLSCREEN_EXIT" ? Math.max(1, r.fullscreenExits) : 1);
  for (const e of events) add(e.flag);
  return m;
}

// ---------------------------------------------------------------- students.csv

export const STUDENTS_HEADERS = [
  "game", "kind", "session_id", "student_id", "nickname", "form", "mode", "intro_mode", "IL", "IM", "IS", "memory_cost", "RTM", "median_correct_t_s", "timeout_rate",
  "mean_er", "quadrant", "total_points", "rounds_played", "rounds_missed", "tut_completed", "tut_total_ms", "tut_step3_attempts", "tut_hints", "tut_probe_correct",
  "seat_row", "seat_col", "integrity_flag_count", "integrity_flags_summary", "is_bot",
] as const;

export interface StudentReport {
  studentId: string;
  nickname: string;
  isBot: boolean;
  summary: StudentSummary;
  quadrant: Quadrant | null;
  tutorial: TutorialResult | null;
  notes: string[];
  integrity: string | null;
  rounds: RoundResult[];
  events: { flag: IntegrityFlag }[];
}

export interface SessionReport {
  data: SessionExportData;
  medians: ClassMedians | null;
  students: StudentReport[];
}

/** Menghitung semua metrik siswa dari ronde (satu-satunya sumber: fungsi shared/). Urutan siswa = urutan pertama muncul. */
export function buildReport(d: SessionExportData): SessionReport {
  const ids = [...new Set([...d.players.map((p) => p.studentId), ...d.rounds.map((r) => r.studentId)])];
  const summaries = ids.map((id) => summarizeStudent(id, d.rounds.filter((r) => r.studentId === id)));
  const medians = classMedians(summaries);
  const students = ids.map((id, i): StudentReport => {
    const rounds = d.rounds.filter((r) => r.studentId === id);
    const player = d.players.find((p) => p.studentId === id);
    const tutorial = d.tutorials.find((t) => t.result.studentId === id)?.result ?? null;
    const events = d.integrityEvents.filter((e) => e.studentId === id);
    const summary = summaries[i] as StudentSummary;
    return {
      studentId: id,
      nickname: player?.name ?? rounds[0]?.nickname ?? id,
      isBot: player?.isBot ?? false,
      summary,
      quadrant: quadrantOf(summary, medians),
      tutorial,
      notes: reportNotes(summary, tutorial),
      integrity: integrityNote(rounds, events),
      rounds,
      events,
    };
  });
  return { data: d, medians, students };
}

const fix1 = (v: number | null): number | null => (v === null ? null : round1(v));
const fix2 = (v: number | null): number | null => (v === null ? null : round2(v));

export function studentsCsv(report: SessionReport): string {
  const d = report.data;
  return toCsv(
    STUDENTS_HEADERS,
    report.students.map((s) => {
      const first = s.rounds.find((r) => r.seatRow !== null);
      const counts = flagCounts(s.rounds, s.events);
      const total = [...counts.values()].reduce((a, b) => a + b, 0);
      return [
        GAME, d.kind, d.sessionId, s.studentId, s.nickname, d.form, d.mode, d.introMode,
        fix1(s.summary.il), fix1(s.summary.im), fix1(s.summary.is), fix2(s.summary.memoryCost), fix2(s.summary.rtm), fix2(s.summary.medianCorrectT),
        round2(s.summary.timeoutRate), fix2(s.summary.meanEr), s.quadrant, s.summary.totalPoints, s.summary.roundsPlayed, s.summary.roundsMissed,
        s.tutorial ? s.tutorial.completed : null, s.tutorial ? s.tutorial.totalMs : null, s.tutorial ? s.tutorial.step3Attempts : null, s.tutorial ? s.tutorial.hints : null,
        s.tutorial ? s.tutorial.probeCorrect : null, first?.seatRow ?? null, first?.seatCol ?? null, total, [...counts.entries()].map(([f, n]) => `${f}x${n}`).join("|"), s.isBot,
      ];
    }),
  );
}

// ---------------------------------------------------------------- tutorial.csv, items.csv

export const TUTORIAL_HEADERS = ["game", "kind", "session_id", "student_id", "is_bot", "step", "attempts", "hints_shown", "invalid_taps", "undo", "ms", "auto_demo", "tut_completed", "tut_total_ms"] as const;

/** Satu baris per siswa per langkah tutorial. Data tutorial tidak masuk ke IL/IM/IS. */
export function tutorialCsv(d: SessionExportData): string {
  const rows: (string | number | boolean | null)[][] = [];
  for (const { isBot, result: t } of d.tutorials)
    for (const s of t.steps) rows.push([GAME, d.kind, d.sessionId, t.studentId, isBot, s.step, s.attempts, s.hintsShown, s.invalidTaps, s.undo, s.ms, t.autoDemoSteps.includes(s.step), t.completed, t.totalMs]);
  return toCsv(TUTORIAL_HEADERS, rows);
}

export const ITEMS_HEADERS = ["game", "kind", "session_id", "round_id", "item_id", "slot", "n_siswa", "mean_er", "prop_optimal", "median_t_s"] as const;

/** Rekap per soal untuk memeriksa kesetaraan empat soal tiap ronde (ronde yang di-missed tidak dihitung). */
export function itemsCsv(d: SessionExportData): string {
  const groups = new Map<string, RoundResult[]>();
  for (const r of d.rounds.filter((x) => !x.missed)) groups.set(`${r.roundId}|${r.itemSlot}|${r.itemId}`, [...(groups.get(`${r.roundId}|${r.itemSlot}|${r.itemId}`) ?? []), r]);
  const rows = [...groups.entries()]
    .map(([k, rs]) => ({ k, rs, round: Number(k.split("|")[0]), slot: Number(k.split("|")[1]) }))
    .sort((a, b) => a.round - b.round || a.slot - b.slot)
    .map(({ rs, round, slot }) => [
      GAME, d.kind, d.sessionId, round, (rs[0] as RoundResult).itemId, slot, rs.length,
      round2(rs.reduce((a, r) => a + r.er, 0) / rs.length), round2(rs.filter((r) => r.optimalHit).length / rs.length), round2(median(rs.map((r) => r.tRouteMs / 1000))),
    ]);
  return toCsv(ITEMS_HEADERS, rows);
}

// ---------------------------------------------------------------- report.html

const esc = (s: string): string => s.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;");
const show = (v: number | null, digits = 1): string => (v === null ? UI.noValue : v.toFixed(digits).replace(".", ","));

const CATEGORY_CLASS: Record<IndexCategory, string> = { "Sangat baik": "c-top", Baik: "c-good", Cukup: "c-mid", "Perlu pendampingan": "c-low" };

function indexRow(label: string, v: number | null, cat: IndexCategory | null): string {
  const width = v === null ? 0 : Math.max(0, Math.min(100, v));
  return `<tr><th scope="row">${esc(label)}</th><td class="num">${show(v)}</td><td class="gauge"><span class="bar ${cat ? CATEGORY_CLASS[cat] : ""}"><i style="width:${width.toFixed(1)}%"></i></span></td><td class="cat ${cat ? CATEGORY_CLASS[cat] : ""}">${cat ? esc(cat) : UI.noValue}</td></tr>`;
}

const initials = (name: string): string =>
  name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => (w[0] ?? "").toUpperCase())
    .join("");

function card(s: StudentReport): string {
  const sm = s.summary;
  return `<article class="card">
  <header>
    <span class="avatar" aria-hidden="true">${esc(initials(s.nickname))}</span>
    <div><h2>${esc(s.nickname)}</h2><p class="sub q-${s.quadrant ? s.quadrant.toLowerCase() : "none"}">${s.quadrant ? esc(QUADRANT_LABEL[s.quadrant]) : "Belum ada ronde yang dimainkan"}</p></div>
  </header>
  <table class="idx">
    <thead><tr><th>Indeks</th><th>Nilai</th><th><span class="sr">Grafik</span></th><th>Kategori</th></tr></thead>
    <tbody>
      ${indexRow("Indeks Logika (IL)", fix1(sm.il), categoryOf(sm.il))}
      ${indexRow("Indeks Memori (IM)", fix1(sm.im), categoryOf(sm.im))}
      ${indexRow("Indeks Spasial (IS)", fix1(sm.is), categoryOf(sm.is))}
    </tbody>
  </table>
  <dl class="facts">
    <div><dt>Rute hemat per menit (RTM)</dt><dd>${show(fix2(sm.rtm), 2)}</dd></div>
    <div><dt>Waktu tepat median (detik)</dt><dd>${show(fix2(sm.medianCorrectT), 2)}</dd></div>
    <div><dt>Biaya memori</dt><dd>${show(fix2(sm.memoryCost), 2)}</dd></div>
    <div><dt>Ronde dimainkan</dt><dd>${sm.roundsPlayed}${sm.roundsMissed ? ` (terlewat ${sm.roundsMissed})` : ""}</dd></div>
  </dl>
  <h3>Catatan</h3>
  <ul>${s.notes.map((n) => `<li>${esc(n)}</li>`).join("")}</ul>
  ${s.integrity ? `<p class="integrity">${esc(s.integrity)}</p>` : ""}
</article>`;
}

const REPORT_CSS = `
  @font-face { font-family: "Product Sans"; font-weight: 400; src: url("/fonts/ProductSans-Regular.ttf") format("truetype"); }
  @font-face { font-family: "Product Sans"; font-weight: 700; src: url("/fonts/ProductSans-Bold.ttf") format("truetype"); }
  @font-face { font-family: "Plus Jakarta Sans"; font-weight: 200 800; src: url("/fonts/PlusJakartaSans-Variable.ttf") format("truetype"); }
  @page { size: A4; margin: 12mm; }
  :root { --ink: #0e1a33; --mute: #56617b; --paper: #f6f3ea; --card: #fffdf8; --hair: rgba(14, 26, 51, 0.12); --coin: #f9a825; --good: #2e7d32; --mid: #e0952a; --low: #c62828; --blue: #1565c0;
    --display: "Product Sans", "Plus Jakarta Sans", "Trebuchet MS", system-ui, sans-serif; --text: "Plus Jakarta Sans", "Nunito", system-ui, sans-serif; }
  * { box-sizing: border-box; }
  body { margin: 0; font-family: var(--text); font-weight: 500; color: var(--ink); background: var(--paper); line-height: 1.4; }
  .bar-top { position: sticky; top: 0; z-index: 5; display: flex; align-items: center; gap: 16px; flex-wrap: wrap; padding: 12px 28px; background: var(--ink); color: #fff8e1; }
  .brand { font-family: var(--display); font-weight: 700; letter-spacing: 0.1em; font-size: 18px; margin-right: 8px; }
  .meta { color: rgba(255, 248, 225, 0.7); font-size: 14px; flex: 1 1 auto; }
  .tools { display: flex; align-items: center; gap: 10px; }
  .tools input { font: inherit; font-size: 15px; padding: 8px 16px; width: 240px; border-radius: 999px; border: 1px solid rgba(255, 248, 225, 0.3); background: rgba(255, 255, 255, 0.08); color: #fff8e1; }
  .tools input::placeholder { color: rgba(255, 248, 225, 0.55); }
  .tools input:focus { outline: 2px solid var(--coin); }
  .tools button { font: 700 15px var(--text); padding: 8px 20px; border-radius: 999px; border: 0; background: var(--coin); color: var(--ink); transition: transform 90ms; }
  .tools button:hover { transform: translateY(-1px); } .tools button:active { transform: scale(0.97); }
  .intro { max-width: 1240px; margin: 28px auto 0; padding: 0 28px; }
  .intro h1 { margin: 0; font-family: var(--display); font-weight: 700; font-size: 34px; letter-spacing: -0.02em; }
  .intro p { margin: 6px 0 0; color: var(--mute); }
  .summary { max-width: 1240px; margin: 18px auto 0; padding: 0 28px; display: flex; gap: 12px; flex-wrap: wrap; }
  .summary div { padding: 10px 18px; background: var(--card); border: 1px solid var(--hair); border-radius: 12px; }
  .summary b { display: block; font-family: var(--display); font-size: 24px; line-height: 1.1; }
  .summary span { font-size: 13px; color: var(--mute); font-weight: 600; }
  main { max-width: 1240px; margin: 0 auto; padding: 18px 28px 48px; }
  .page { display: grid; grid-template-columns: repeat(auto-fill, minmax(460px, 1fr)); gap: 18px; margin-bottom: 18px; }
  .card { background: var(--card); border: 1px solid var(--hair); border-radius: 16px; padding: 22px 24px; box-shadow: 0 1px 2px rgba(14, 26, 51, 0.05), 0 14px 30px -18px rgba(14, 26, 51, 0.25); break-inside: avoid; animation: rise 420ms cubic-bezier(0.2, 1, 0.3, 1) both; }
  @keyframes rise { from { transform: translateY(12px); opacity: 0; } }
  .card header { display: flex; align-items: center; gap: 14px; margin-bottom: 14px; }
  .avatar { flex: none; display: grid; place-items: center; width: 46px; height: 46px; border-radius: 50%; background: var(--ink); color: #fff8e1; font-family: var(--display); font-weight: 700; font-size: 17px; }
  .card h2 { margin: 0; font-family: var(--display); font-weight: 700; font-size: 21px; line-height: 1.15; }
  .card .sub { display: inline-block; margin: 4px 0 0; padding: 1px 12px; border-radius: 999px; font-size: 13px; font-weight: 700; background: #e9edf7; color: var(--blue); }
  .sub.q-mahir { background: #e3f3e5; color: var(--good); } .sub.q-teliti { background: #e6eefb; color: var(--blue); } .sub.q-terburu { background: #fdf0d9; color: #a86a00; } .sub.q-dampingi { background: #fbe4e4; color: var(--low); } .sub.q-none { background: #eee9dc; color: var(--mute); }
  .card h3 { margin: 16px 0 4px; font-size: 12px; letter-spacing: 0.12em; text-transform: uppercase; color: var(--mute); }
  table.idx { width: 100%; border-collapse: collapse; font-size: 14px; }
  table.idx th { text-align: left; font-size: 11px; letter-spacing: 0.1em; text-transform: uppercase; color: var(--mute); padding: 4px 6px; }
  table.idx td, table.idx tbody th { padding: 8px 6px; border-top: 1px solid var(--hair); font-weight: 600; text-align: left; }
  td.num { text-align: right; font-family: var(--display); font-weight: 700; font-size: 17px; width: 52px; }
  td.gauge { width: 34%; }
  .bar { display: block; height: 8px; border-radius: 999px; background: rgba(14, 26, 51, 0.1); overflow: hidden; }
  .bar i { display: block; height: 100%; border-radius: 999px; background: var(--mute); }
  .bar.c-top i { background: var(--good); } .bar.c-good i { background: #5aa05e; } .bar.c-mid i { background: var(--mid); } .bar.c-low i { background: var(--low); }
  td.cat { font-size: 12px; font-weight: 700; white-space: nowrap; } td.cat.c-top, td.cat.c-good { color: var(--good); } td.cat.c-mid { color: #a86a00; } td.cat.c-low { color: var(--low); }
  .sr { position: absolute; width: 1px; height: 1px; overflow: hidden; clip: rect(0 0 0 0); }
  .facts { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; margin: 14px 0 0; }
  .facts div { padding: 8px 12px; background: #f6f3ea; border-radius: 10px; }
  .facts dt { font-size: 12px; color: var(--mute); font-weight: 600; } .facts dd { margin: 2px 0 0; font-family: var(--display); font-weight: 700; font-size: 19px; }
  ul { margin: 0; padding-left: 18px; font-size: 14px; } li + li { margin-top: 3px; }
  .integrity { margin: 12px 0 0; padding: 8px 12px; background: #fdf0d9; border-left: 4px solid #e0952a; border-radius: 6px; font-size: 13px; }
  .empty { max-width: 640px; margin: 48px auto; padding: 40px; text-align: center; color: var(--mute); background: var(--card); border: 1px dashed var(--hair); border-radius: 16px; }
  .nomatch { display: none; text-align: center; color: var(--mute); padding: 32px; }
  @media (prefers-reduced-motion: reduce) { .card { animation: none; } }
  @media (max-width: 560px) { .page { grid-template-columns: 1fr; } .tools input { width: 100%; } }
  @media print {
    body { background: none; }
    .bar-top, .summary, .nomatch { display: none !important; }
    .intro { padding: 0; margin: 0 0 6mm; } .intro h1 { font-size: 20pt; }
    main { padding: 0; max-width: none; }
    .page { display: grid; grid-template-columns: 1fr; grid-template-rows: 1fr 1fr; gap: 8mm; height: 273mm; margin: 0; page-break-after: always; }
    .card { box-shadow: none; animation: none; padding: 6mm; }
    .bar i, .avatar, .sub, .facts div, .integrity { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  }
`;

const REPORT_JS = `
  (function () {
    var q = document.getElementById("q");
    var cards = Array.prototype.slice.call(document.querySelectorAll(".card"));
    var none = document.getElementById("nomatch");
    if (q) q.addEventListener("input", function () {
      var v = q.value.trim().toLowerCase(), shown = 0;
      cards.forEach(function (c) { var ok = !v || ((c.querySelector("h2") || {}).textContent || "").toLowerCase().indexOf(v) >= 0; c.style.display = ok ? "" : "none"; if (ok) shown++; });
      document.querySelectorAll(".page").forEach(function (p) { p.style.display = p.querySelector(".card:not([style*='none'])") ? "" : "none"; });
      if (none) none.style.display = shown ? "none" : "block";
    });
    var b = document.getElementById("print");
    if (b) b.addEventListener("click", function () { window.print(); });
  })();
`;

/**
 * Kartu laporan per siswa, siap cetak A4 (2 kartu per halaman) dan nyaman dibaca di layar (cari nama, simpan PDF lewat cetak).
 * Hanya untuk guru: memuat catatan integritas. Skor balapan dan urutan kelas TIDAK dicantumkan (Bagian 11).
 */
export function reportHtml(report: SessionReport): string {
  const d = report.data;
  const shown = report.students.filter((s) => s.summary.roundsPlayed > 0 || s.rounds.length > 0 || !s.isBot);
  const cards = shown.map(card);
  const pages: string[] = [];
  for (let i = 0; i < cards.length; i += 2) pages.push(`<section class="page">${cards[i]}${cards[i + 1] ?? ""}</section>`);
  const when = d.createdAt && d.createdAt > 1e12 ? new Date(d.createdAt).toLocaleDateString("id-ID", { dateStyle: "long" }) : "";
  const meta = `Sesi ${esc(d.sessionId)}${d.kind === "TEST" ? " (TEST)" : ""} · Bentuk ${d.form === "T" ? "Tantangan" : d.form} · ${d.mode === "STANDARD" ? "Standar" : "Kilat"}${when ? ` · ${esc(when)}` : ""}`;
  const played = shown.filter((s) => s.summary.roundsPlayed > 0);
  const avg = (pick: (s: StudentReport) => number | null): string => {
    const vals = played.map(pick).filter((v): v is number => v !== null);
    return vals.length ? show(vals.reduce((a, v) => a + v, 0) / vals.length) : UI.noValue;
  };
  const body = pages.length
    ? `<section class="summary" aria-label="Ringkasan kelas"><div><b>${shown.length}</b><span>siswa</span></div><div><b>${avg((s) => fix1(s.summary.il))}</b><span>rata-rata IL</span></div><div><b>${avg((s) => fix1(s.summary.im))}</b><span>rata-rata IM</span></div><div><b>${avg((s) => fix1(s.summary.is))}</b><span>rata-rata IS</span></div></section>
<main>${pages.join("\n")}<p class="nomatch" id="nomatch">Tidak ada nama yang cocok.</p></main>`
    : `<p class="empty">${UI.noSessionData}</p>`;
  return `<!doctype html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Laporan Route Rush ${esc(d.sessionId)}</title>
<style>${REPORT_CSS}</style></head><body>
<div class="bar-top"><span class="brand">ROUTE RUSH</span><span class="meta">${meta}</span><div class="tools"><input id="q" type="search" placeholder="Cari nama siswa" aria-label="Cari nama siswa"><button id="print" type="button">Cetak / simpan PDF</button></div></div>
<div class="intro"><h1>Laporan Route Rush</h1><p>${meta}. Hanya untuk guru.</p></div>
${body}
<script>${REPORT_JS}</script>
</body></html>
`;
}
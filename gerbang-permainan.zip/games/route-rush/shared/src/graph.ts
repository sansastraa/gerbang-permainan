import type { MapDef, NodeId } from "./types";

export type GraphLike = Pick<MapDef, "nodes" | "edges">;
export type Adjacency = Map<NodeId, Map<NodeId, number>>;

const nodeIndex = (id: NodeId): number => Number(id.slice(1));

/** Id edge kanonik: id node yang lebih kecil di depan ("n0-n3"). */
export function edgeId(a: NodeId, b: NodeId): string {
  return nodeIndex(a) <= nodeIndex(b) ? `${a}-${b}` : `${b}-${a}`;
}

/** Urutan tetangga mengikuti urutan edge di peta agar enumerasi rute deterministik. */
export function buildAdjacency(map: GraphLike): Adjacency {
  const adj: Adjacency = new Map();
  for (const n of map.nodes) adj.set(n.id, new Map());
  for (const e of map.edges) {
    adj.get(e.a)?.set(e.b, e.w);
    adj.get(e.b)?.set(e.a, e.w);
  }
  return adj;
}

/** Biaya terpendek `from` → `to`; `unit` membuat tiap edge berbobot 1 (jumlah langkah). Infinity bila tak tersambung. */
export function dijkstra(map: GraphLike, from: NodeId, to: NodeId, unit = false): number {
  const adj = buildAdjacency(map);
  const dist = new Map<NodeId, number>([[from, 0]]);
  const done = new Set<NodeId>();
  for (;;) {
    let u: NodeId | null = null;
    let best = Infinity;
    for (const [id, d] of dist) {
      if (!done.has(id) && d < best) {
        best = d;
        u = id;
      }
    }
    if (u === null) return Infinity;
    if (u === to) return best;
    done.add(u);
    for (const [v, w] of adj.get(u) ?? []) {
      const nd = best + (unit ? 1 : w);
      if (nd < (dist.get(v) ?? Infinity)) dist.set(v, nd);
    }
  }
}

/** Semua rute sederhana (tanpa simpul berulang) dari `from` ke `to`. */
export function simplePaths(adj: Adjacency, from: NodeId, to: NodeId): NodeId[][] {
  const out: NodeId[][] = [];
  const path: NodeId[] = [from];
  const visit = (u: NodeId): void => {
    if (u === to) {
      out.push([...path]);
      return;
    }
    for (const v of adj.get(u)?.keys() ?? []) {
      if (!path.includes(v)) {
        path.push(v);
        visit(v);
        path.pop();
      }
    }
  };
  visit(from);
  return out;
}

export function hasEdge(adj: Adjacency, a: NodeId, b: NodeId): boolean {
  return adj.get(a)?.has(b) ?? false;
}

/** Jumlah koin sepanjang `path`; null bila bukan rangkaian edge yang valid atau kosong. */
export function pathCost(map: GraphLike, path: readonly NodeId[]): number | null {
  if (path.length === 0) return null;
  const adj = buildAdjacency(map);
  let cost = 0;
  for (let i = 1; i < path.length; i++) {
    const w = adj.get(path[i - 1] as NodeId)?.get(path[i] as NodeId);
    if (w === undefined) return null;
    cost += w;
  }
  return cost;
}

/** Permutasi dalam urutan leksikografis posisi (sama dengan itertools.permutations). */
export function permutations<T>(items: readonly T[]): T[][] {
  if (items.length === 0) return [[]];
  const out: T[][] = [];
  items.forEach((item, i) => {
    const rest = items.filter((_, j) => j !== i);
    for (const p of permutations(rest)) out.push([item, ...p]);
  });
  return out;
}

/** Hasil kali kartesian; indeks terakhir berubah paling cepat (sama dengan itertools.product). */
export function cartesian<T>(lists: readonly (readonly T[])[]): T[][] {
  return lists.reduce<T[][]>((acc, list) => acc.flatMap((prefix) => list.map((item) => [...prefix, item])), [[]]);
}

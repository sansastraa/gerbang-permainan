import { buildAdjacency, cartesian, dijkstra, pathCost, permutations, simplePaths } from "./graph";
import type { MapDef, NodeId } from "./types";

export interface RouteInfo {
  path: NodeId[];
  cost: number;
  stopOrder: NodeId[];
}

function checkpoints(map: MapDef, order: readonly NodeId[]): NodeId[] {
  return [map.start, ...order, map.goal];
}

function totalLegCost(map: MapDef, unit: boolean): number {
  let best = Infinity;
  for (const order of permutations(map.stops)) {
    const pts = checkpoints(map, order);
    let sum = 0;
    for (let k = 0; k < pts.length - 1; k++) sum += dijkstra(map, pts[k] as NodeId, pts[k + 1] as NodeId, unit);
    best = Math.min(best, sum);
  }
  return best;
}

/** Biaya paling hemat melewati semua stop (urutan terbaik). */
export function optimalCost(map: MapDef): number {
  return totalLegCost(map, false);
}

/** Jumlah langkah paling sedikit melewati semua stop. */
export function minHops(map: MapDef): number {
  return totalLegCost(map, true);
}

/**
 * Semua rute yang mungkin: gabungan rute sederhana per ruas antar-titik wajib untuk tiap urutan stop.
 * Kunci rute = urutan simpulnya, sehingga rute yang sama dari urutan berbeda tidak dihitung dua kali.
 */
export function allRoutes(map: MapDef): RouteInfo[] {
  const adj = buildAdjacency(map);
  const routes = new Map<string, RouteInfo>();
  for (const order of permutations(map.stops)) {
    const pts = checkpoints(map, order);
    const legs = pts.slice(0, -1).map((from, k) => simplePaths(adj, from, pts[k + 1] as NodeId));
    for (const combo of cartesian(legs)) {
      const path = (combo[0] as NodeId[]).slice();
      for (const leg of combo.slice(1)) path.push(...leg.slice(1));
      const cost = pathCost(map, path);
      if (cost !== null) routes.set(path.join(","), { path, cost, stopOrder: [...order] });
    }
  }
  return [...routes.values()];
}

const cheapest = (routes: readonly RouteInfo[]): RouteInfo[] => {
  const best = Math.min(...routes.map((r) => r.cost));
  return routes.filter((r) => r.cost === best);
};

/** Jumlah rute berbiaya terendah; peta valid wajib bernilai 1. */
export function countOptimalRoutes(map: MapDef): number {
  return cheapest(allRoutes(map)).length;
}

/** Rute optimal lengkap untuk ditampilkan di RESULT. */
export function optimalRoute(map: MapDef): NodeId[] {
  if (map.nodes.length > 9) return (bestWalk(map) as Walk).path;
  return (cheapest(allRoutes(map))[0] as RouteInfo).path;
}

/** Urutan mampir stop pada rute optimal. */
export function optimalStopOrder(map: MapDef): NodeId[] {
  if (map.nodes.length > 9) return (bestWalk(map) as Walk).stopOrder;
  return (cheapest(allRoutes(map))[0] as RouteInfo).stopOrder;
}

/** Selisih biaya rute terbaik kedua terhadap optimal; null bila hanya ada satu tingkat biaya. */
export function secondBestGap(map: MapDef): number | null {
  const costs = [...new Set(allRoutes(map).map((r) => r.cost))].sort((a, b) => a - b);
  return costs.length > 1 ? (costs[1] as number) - (costs[0] as number) : null;
}

/** Jumlah rute sederhana (tanpa simpul berulang) yang harus dibandingkan siswa. */
export function simpleRouteCount(map: MapDef): number {
  return allRoutes(map).filter((r) => new Set(r.path).size === r.path.length).length;
}

/** Biaya rute dengan langkah paling sedikit dikurangi biaya optimal (daya tipu jebakan). */
export function trapDelta(map: MapDef): number | null {
  const hops = minHops(map);
  const fewest = allRoutes(map).filter((r) => r.path.length - 1 === hops);
  if (fewest.length === 0) return null;
  return Math.min(...fewest.map((r) => r.cost)) - optimalCost(map);
}

export interface RouteAnalysis {
  routes: RouteInfo[];
  /** Tingkat biaya berbeda, urut naik. */
  costs: number[];
  opt: number;
  optimalRoutes: RouteInfo[];
  best: RouteInfo;
  gap: number | null;
  minHops: number;
  optSteps: number;
  simple: number;
  trapDelta: number | null;
}

/** Semua ukuran rute dari satu enumerasi (dipakai validator dan pemeriksa kesetaraan agar tidak menghitung berulang). */
export function analyzeRoutes(map: MapDef): RouteAnalysis | null {
  const routes = allRoutes(map);
  if (routes.length === 0) return null;
  const costs = [...new Set(routes.map((r) => r.cost))].sort((a, b) => a - b);
  const opt = costs[0] as number;
  const optimalRoutes = routes.filter((r) => r.cost === opt);
  const best = optimalRoutes[0] as RouteInfo;
  const hops = minHops(map);
  const fewest = routes.filter((r) => r.path.length - 1 === hops);
  return {
    routes,
    costs,
    opt,
    optimalRoutes,
    best,
    gap: costs.length > 1 ? (costs[1] as number) - opt : null,
    minHops: hops,
    optSteps: best.path.length - 1,
    simple: routes.filter((r) => new Set(r.path).size === r.path.length).length,
    trapDelta: fewest.length > 0 ? Math.min(...fewest.map((r) => r.cost)) - opt : null,
  };
}

/** Kerangka rute yang tidak bergantung pada bobot: semua rute beserta indeks edge yang dilewati. */
export interface RouteSkeleton {
  paths: NodeId[][];
  /** Untuk tiap rute, indeks edge (pada `map.edges`) yang dilalui berurutan. */
  edgeIndex: number[][];
  minHops: number;
}

/** Enumerasi rute satu kali untuk satu tata letak dan pilihan stop; bobot dapat diganti-ganti tanpa menghitung ulang. */
export function routeSkeleton(map: MapDef): RouteSkeleton | null {
  const routes = allRoutes(map);
  if (routes.length === 0) return null;
  const index = new Map(map.edges.map((e, i) => [`${e.a}|${e.b}`, i]));
  const at = (a: NodeId, b: NodeId): number => (index.get(`${a}|${b}`) ?? index.get(`${b}|${a}`)) as number;
  return {
    paths: routes.map((r) => r.path),
    edgeIndex: routes.map((r) => r.path.slice(1).map((id, i) => at(r.path[i] as NodeId, id))),
    minHops: Math.min(...routes.map((r) => r.path.length - 1)),
  };
}

/** Rute termurah lewat semua stop untuk peta besar: Dijkstra per ruas dan permutasi stop, tanpa enumerasi semua rute. */
export interface Walk {
  cost: number;
  hops: number;
  path: NodeId[];
  stopOrder: NodeId[];
  /** Jumlah kombinasi rute termurah (tiap ruas termurah dihitung banyaknya); 1 berarti tunggal. */
  count: number;
}

/** Dijkstra dengan jumlah jalur terpendek dan pelacak jalur; hanya untuk peta besar, jauh lebih cepat daripada enumerasi semua rute. */
function legs(adj: ReturnType<typeof buildAdjacency>, from: NodeId, unit: boolean): { dist: Map<NodeId, number>; prev: Map<NodeId, NodeId>; ways: Map<NodeId, number> } {
  const dist = new Map<NodeId, number>([[from, 0]]);
  const ways = new Map<NodeId, number>([[from, 1]]);
  const prev = new Map<NodeId, NodeId>();
  const done = new Set<NodeId>();
  for (;;) {
    let u: NodeId | null = null;
    for (const [n, d] of dist) if (!done.has(n) && (u === null || d < (dist.get(u) as number))) u = n;
    if (u === null) break;
    done.add(u);
    for (const [v, w] of adj.get(u) ?? []) {
      const nd = (dist.get(u) as number) + (unit ? 1 : w);
      const cur = dist.get(v);
      if (cur === undefined || nd < cur) {
        dist.set(v, nd);
        ways.set(v, ways.get(u) as number);
        prev.set(v, u);
      } else if (nd === cur) ways.set(v, (ways.get(v) as number) + (ways.get(u) as number));
    }
  }
  return { dist, prev, ways };
}

export function bestWalk(map: MapDef, unit = false): Walk | null {
  const adj = buildAdjacency(map);
  const from = new Map<NodeId, ReturnType<typeof legs>>();
  const run = (n: NodeId): ReturnType<typeof legs> => {
    let r = from.get(n);
    if (!r) {
      r = legs(adj, n, unit);
      from.set(n, r);
    }
    return r;
  };
  const found: Walk[] = [];
  for (const order of permutations(map.stops)) {
    const pts = [map.start, ...order, map.goal];
    let cost = 0;
    let count = 1;
    const path: NodeId[] = [map.start];
    let ok = true;
    for (let k = 0; k < pts.length - 1 && ok; k++) {
      const a = pts[k] as NodeId;
      const b = pts[k + 1] as NodeId;
      const r = run(a);
      const d = r.dist.get(b);
      if (d === undefined) {
        ok = false;
        break;
      }
      cost += d;
      count *= r.ways.get(b) as number;
      const seg: NodeId[] = [b];
      while (seg[0] !== a) seg.unshift(r.prev.get(seg[0] as NodeId) as NodeId);
      path.push(...seg.slice(1));
    }
    if (!ok) continue;
    const candidate: Walk = { cost, hops: path.length - 1, path, stopOrder: [...order], count };
    found.push(candidate);
  }
  if (found.length === 0) return null;
  const low = Math.min(...found.map((w) => w.cost));
  const ties = found.filter((w) => w.cost === low);
  return { ...(ties[0] as Walk), count: ties.reduce((n, w) => n + w.count, 0) };
}


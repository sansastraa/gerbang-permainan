import { roundIdsFor, roundsMaxDurationMs } from "./rounds";
import type { IntroMode, SessionMode } from "./types";

export const LOBBY_MS = 30_000;
export const PODIUM_MS = 20_000;
export const TUTORIAL_MS = 90_000;

/** Durasi intro (ms). FULL = ident 8 s + trailer 45 s; SHORT = ident 3 s + trailer 12 s. */
export const INTRO_MS: Record<IntroMode, { ident: number; trailer: number }> = {
  FULL: { ident: 8000, trailer: 45000 },
  SHORT: { ident: 3000, trailer: 12000 },
};

export interface SessionBudget {
  lobbyMs: number;
  introMs: number;
  tutorialMs: number;
  roundsMs: number;
  podiumMs: number;
  totalMs: number;
}

/** Anggaran waktu maksimal sesi (S1–S4). Tutorial hanya ada pada sesi perdana (FULL). */
export function sessionBudget(mode: SessionMode, introMode: IntroMode): SessionBudget {
  const lobbyMs = LOBBY_MS;
  const introMs = INTRO_MS[introMode].ident + INTRO_MS[introMode].trailer;
  const tutorialMs = introMode === "FULL" ? TUTORIAL_MS : 0;
  const roundsMs = roundsMaxDurationMs(roundIdsFor(mode, introMode));
  const podiumMs = PODIUM_MS;
  return { lobbyMs, introMs, tutorialMs, roundsMs, podiumMs, totalMs: lobbyMs + introMs + tutorialMs + roundsMs + podiumMs };
}

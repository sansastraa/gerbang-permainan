import { challengeConfig } from "./challenge";
import { LEADERBOARD_MS, PROBE_MS, QUICK_ROUND_IDS, RESULT_MS, ROUND_CONFIGS, STANDARD_ROUND_IDS, getRoundConfig } from "./rounds";
import type { IntroMode, RoundConfig, SeatLayout, SessionMode } from "./types";

/** Pengaturan sesi yang dapat dikustomisasi guru sebelum permainan dimulai. */
export interface SessionSettings {
  mode: SessionMode;
  introMode: IntroMode;
  /** Bank soal yang dipakai: Pool A, Pool B, atau T (Tantangan: peta besar, waktu 1–2 menit per soal). */
  pool: "A" | "B" | "T";
  /** Detik menghafal (fase LOOK) untuk semua ronde; null = bawaan tiap ronde (5–7 detik). */
  lookSeconds: number | null;
  /** Detik berjalan (fase WALK) untuk semua ronde; null = bawaan tiap ronde (20–35 detik). */
  walkSeconds: number | null;
  /** Detik menjawab soal ingatan (3–180); rumus poin tetap memakai skala 5 detik. */
  probeSeconds: number;
  /** Detik layar hasil ronde (juga waktu untuk menyebut nama siswa yang benar); bawaan 3 detik. */
  resultSeconds: number;
  /** Daftar ronde khusus (0–10); null = mengikuti mode. Ronde 0 otomatis dilewati pada sesi perdana. */
  roundIds: number[] | null;
  /** Pool Tantangan: ronde (1–10) yang dimainkan sebagai soal ingatan (angka hilang saat berjalan); kosong = semua soal hitung. */
  hiddenRounds: number[];
  /** Jumlah siswa yang harus sudah masuk sebelum permainan boleh dimulai. */
  quota: number;
  seatLayout: SeatLayout;
  kind: "LIVE" | "TEST";
  /** Soal beda untuk tiap siswa (anti contek): peta buatan sendiri yang setara tingkatnya; ronde pertama tetap soal termudah. */
  uniqueMaps: boolean;
}

export const SETTING_LIMITS = {
  lookSeconds: { min: 2, max: 60 },
  walkSeconds: { min: 10, max: 180 },
  probeSeconds: { min: 3, max: 180 },
  resultSeconds: { min: 3, max: 20 },
  seatRows: { min: 1, max: 8 },
  seatCols: { min: 1, max: 10 },
} as const;

export const DEFAULT_SEAT_LAYOUT: SeatLayout = { rows: 5, cols: 8, aisleAfterCols: [4], enabled: true };

export function defaultSettings(rosterSize: number): SessionSettings {
  return {
    mode: "STANDARD",
    introMode: "FULL",
    pool: "A",
    lookSeconds: null,
    walkSeconds: null,
    probeSeconds: PROBE_MS / 1000,
    resultSeconds: RESULT_MS / 1000,
    roundIds: null,
    hiddenRounds: [],
    quota: Math.max(1, rosterSize),
    seatLayout: { ...DEFAULT_SEAT_LAYOUT },
    kind: "LIVE",
    uniqueMaps: false,
  };
}

export type SettingsResult = { ok: true; settings: SessionSettings } | { ok: false; errors: string[] };

const isObject = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);

/**
 * Menggabungkan masukan guru dengan pengaturan sekarang (atau bawaan) dan memeriksa semua batas.
 * `rosterSize` membatasi kuota.
 */
export function mergeSettings(base: SessionSettings, patch: unknown, rosterSize: number): SettingsResult {
  const errors: string[] = [];
  if (!isObject(patch)) return { ok: false, errors: ["pengaturan harus berupa objek"] };
  const next: SessionSettings = { ...base, seatLayout: { ...base.seatLayout } };

  const num = (key: string, min: number, max: number, nullable: boolean): number | null | undefined => {
    if (!(key in patch)) return undefined;
    const v = patch[key];
    if (v === null && nullable) return null;
    if (typeof v !== "number" || !Number.isFinite(v) || v < min || v > max) {
      errors.push(`${key} harus angka ${min}–${max}${nullable ? " atau null" : ""}`);
      return undefined;
    }
    return v;
  };

  if ("mode" in patch) {
    if (patch["mode"] === "STANDARD" || patch["mode"] === "QUICK") next.mode = patch["mode"];
    else errors.push("mode harus STANDARD atau QUICK");
  }
  if ("introMode" in patch) {
    if (patch["introMode"] === "FULL" || patch["introMode"] === "SHORT") next.introMode = patch["introMode"];
    else errors.push("introMode harus FULL atau SHORT");
  }
  if ("pool" in patch) {
    if (patch["pool"] === "A" || patch["pool"] === "B" || patch["pool"] === "T") next.pool = patch["pool"];
    else errors.push("pool harus A, B, atau T");
  }
  if ("kind" in patch) {
    if (patch["kind"] === "LIVE" || patch["kind"] === "TEST") next.kind = patch["kind"];
    else errors.push("kind harus LIVE atau TEST");
  }
  if ("uniqueMaps" in patch) {
    if (typeof patch["uniqueMaps"] === "boolean") next.uniqueMaps = patch["uniqueMaps"];
    else errors.push("uniqueMaps harus true atau false");
  }
  const look = num("lookSeconds", SETTING_LIMITS.lookSeconds.min, SETTING_LIMITS.lookSeconds.max, true);
  if (look !== undefined) next.lookSeconds = look;
  const walk = num("walkSeconds", SETTING_LIMITS.walkSeconds.min, SETTING_LIMITS.walkSeconds.max, true);
  if (walk !== undefined) next.walkSeconds = walk;
  const probe = num("probeSeconds", SETTING_LIMITS.probeSeconds.min, SETTING_LIMITS.probeSeconds.max, false);
  if (typeof probe === "number") next.probeSeconds = probe;
  const result = num("resultSeconds", SETTING_LIMITS.resultSeconds.min, SETTING_LIMITS.resultSeconds.max, false);
  if (typeof result === "number") next.resultSeconds = result;
  const quota = num("quota", 1, Math.max(1, rosterSize), false);
  if (typeof quota === "number") {
    if (!Number.isInteger(quota)) errors.push("quota harus bilangan bulat");
    else next.quota = quota;
  }
  if ("roundIds" in patch) {
    const ids = patch["roundIds"];
    if (ids === null) next.roundIds = null;
    else if (Array.isArray(ids) && ids.length > 0 && ids.every((i) => Number.isInteger(i) && i >= 0 && i <= 10) && new Set(ids).size === ids.length) {
      next.roundIds = [...(ids as number[])].sort((a, b) => a - b);
    } else errors.push("roundIds harus daftar ronde unik 0–10 atau null");
  }
  if ("hiddenRounds" in patch) {
    const ids = patch["hiddenRounds"];
    if (Array.isArray(ids) && ids.every((i) => Number.isInteger(i) && i >= 1 && i <= 10) && new Set(ids).size === ids.length) next.hiddenRounds = [...(ids as number[])].sort((a, b) => a - b);
    else errors.push("hiddenRounds harus daftar ronde unik 1–10");
  }
  if ("seatLayout" in patch) {
    const s = patch["seatLayout"];
    if (!isObject(s)) errors.push("seatLayout harus objek");
    else {
      const layout: SeatLayout = { ...next.seatLayout };
      if ("enabled" in s) layout.enabled = s["enabled"] === true;
      const dim = (k: "rows" | "cols", lim: { min: number; max: number }): void => {
        if (!(k in s)) return;
        const v = s[k];
        if (typeof v === "number" && Number.isInteger(v) && v >= lim.min && v <= lim.max) layout[k] = v;
        else errors.push(`seatLayout.${k} harus bilangan bulat ${lim.min}–${lim.max}`);
      };
      dim("rows", SETTING_LIMITS.seatRows);
      dim("cols", SETTING_LIMITS.seatCols);
      if ("aisleAfterCols" in s) {
        const a = s["aisleAfterCols"];
        if (Array.isArray(a) && a.every((n) => Number.isInteger(n) && n >= 1)) layout.aisleAfterCols = a as number[];
        else errors.push("seatLayout.aisleAfterCols harus daftar bilangan bulat");
      }
      next.seatLayout = layout;
    }
  }
  if (next.quota > Math.max(1, rosterSize)) errors.push(`quota melebihi jumlah siswa (${rosterSize})`);
  return errors.length > 0 ? { ok: false, errors } : { ok: true, settings: next };
}

/** Ronde yang dimainkan menurut pengaturan; ronde 0 dibuang pada sesi perdana (FULL). */
export function settingsRoundIds(s: SessionSettings): number[] {
  const base = s.roundIds ?? (s.mode === "STANDARD" ? STANDARD_ROUND_IDS : QUICK_ROUND_IDS);
  return base.filter((id) => !(s.introMode === "FULL" && id === 0));
}

/** Konfigurasi ronde setelah pengaturan guru diterapkan (waktu hafal dan berjalan). */
export function effectiveRoundConfig(roundId: number, s: SessionSettings): RoundConfig {
  const base = s.pool === "T" && roundId > 0 ? challengeConfig(roundId) : getRoundConfig(roundId);
  return {
    ...base,
    condition: s.pool === "T" && roundId > 0 && (s.hiddenRounds ?? []).includes(roundId) ? "HIDDEN" : base.condition,
    lookMs: s.lookSeconds === null ? base.lookMs : Math.round(s.lookSeconds * 1000),
    walkMs: s.walkSeconds === null ? base.walkMs : Math.round(s.walkSeconds * 1000),
  };
}

/** Durasi ronde maksimal (LOOK + WALK + PROBE + RESULT + LEADERBOARD) dengan pengaturan guru. */
export function effectiveRoundMaxMs(roundId: number, s: SessionSettings): number {
  const c = effectiveRoundConfig(roundId, s);
  return c.lookMs + c.walkMs + (c.condition === "HIDDEN" ? s.probeSeconds * 1000 : 0) + s.resultSeconds * 1000 + (c.scored ? LEADERBOARD_MS : 0);
}

export function allRoundIdsAvailable(): number[] {
  return ROUND_CONFIGS.map((c) => c.roundId);
}

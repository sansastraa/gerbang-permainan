import { analyzeRoutes } from "./solver";
import type { MapDef } from "./types";

export interface Shot {
  id: string;
  startMs: number;
  endMs: number;
  visual: string;
  sfx: string | null;
  vo: string | null;
  screenText?: string | null;
}

export interface ShortShot {
  id: string;
  fromShot: string;
  startMs: number;
  endMs: number;
}

export interface IntroTimeline {
  gameTitle: string;
  trailerMap: string;
  ident: Shot[];
  identShort: { fromMs: number; toMs: number };
  trailer: Shot[];
  trailerShort: ShortShot[];
}

const isShot = (s: unknown): s is Shot => {
  const o = s as Record<string, unknown>;
  return typeof o === "object" && o !== null && typeof o["id"] === "string" && typeof o["startMs"] === "number" && typeof o["endMs"] === "number";
};

/** Memuat timeline.json dan memastikan bentuknya benar. */
export function parseTimeline(raw: unknown): IntroTimeline {
  const o = raw as Record<string, unknown>;
  const ident = o["ident"];
  const trailer = o["trailer"];
  const short = o["trailerShort"];
  const identShort = o["identShort"] as { fromMs?: unknown; toMs?: unknown } | undefined;
  if (
    typeof o["gameTitle"] !== "string" ||
    typeof o["trailerMap"] !== "string" ||
    !Array.isArray(ident) ||
    !ident.every(isShot) ||
    !Array.isArray(trailer) ||
    !trailer.every(isShot) ||
    !Array.isArray(short) ||
    !short.every(isShot) ||
    typeof identShort?.fromMs !== "number" ||
    typeof identShort.toMs !== "number"
  ) {
    throw new TypeError("timeline.json tidak valid");
  }
  return {
    gameTitle: o["gameTitle"],
    trailerMap: o["trailerMap"],
    ident,
    identShort: { fromMs: identShort.fromMs, toMs: identShort.toMs },
    trailer,
    trailerShort: short as unknown as ShortShot[],
  };
}

export interface IntroDurations {
  identMs: number;
  trailerMs: number;
  identShortMs: number;
  trailerShortMs: number;
}

export function introDurations(t: IntroTimeline): IntroDurations {
  const last = (shots: readonly { endMs: number }[]): number => (shots[shots.length - 1] as { endMs: number }).endMs;
  return {
    identMs: last(t.ident),
    trailerMs: last(t.trailer),
    identShortMs: t.identShort.toMs - t.identShort.fromMs,
    trailerShortMs: last(t.trailerShort),
  };
}

/** Shot bersambung: yang pertama mulai di 0 dan setiap `startMs` = `endMs` shot sebelumnya. */
export function isContiguous(shots: readonly { startMs: number; endMs: number }[]): boolean {
  return shots.length > 0 && (shots[0] as { startMs: number }).startMs === 0 && shots.every((s, i) => i === 0 || s.startMs === (shots[i - 1] as { endMs: number }).endMs);
}

/** Angka koin tidak boleh tertulis literal di data intro; hanya placeholder. */
export function hasLiteralCoinNumbers(raw: unknown): boolean {
  return /\b\d+\s+vs\s+\d+\b/i.test(JSON.stringify(raw));
}

export interface TrailerNumbers {
  trapCost: number;
  optimalCost: number;
}

/** Angka shot 5 dihitung dari peta trailer: rute paling sedikit jalan dan rute paling hemat. */
export function trailerNumbers(map: MapDef): TrailerNumbers {
  const a = analyzeRoutes(map);
  if (!a || a.trapDelta === null) throw new RangeError(`peta ${map.id} tidak punya rute jebakan`);
  return { trapCost: a.opt + a.trapDelta, optimalCost: a.opt };
}

export function resolveScreenText(textValue: string, n: TrailerNumbers): string {
  return textValue.replaceAll("{trapCost}", String(n.trapCost)).replaceAll("{optimalCost}", String(n.optimalCost));
}

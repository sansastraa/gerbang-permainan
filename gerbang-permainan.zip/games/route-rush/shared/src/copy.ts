/** Semua teks UI Bahasa Indonesia yang dipakai logika bersama. */
import type { ErrorType } from "./types";

export type Quadrant = "MAHIR" | "TELITI" | "TERBURU" | "DAMPINGI";
export type IndexCategory = "Sangat baik" | "Baik" | "Cukup" | "Perlu pendampingan";

export const QUADRANT_LABEL: Record<Quadrant, string> = {
  MAHIR: "Cepat dan tepat",
  TELITI: "Tepat, butuh waktu",
  TERBURU: "Terburu-buru, perlu dilatih memeriksa rute",
  DAMPINGI: "Perlu pendampingan konsep rute hemat",
};

export const ERROR_LABEL: Record<ErrorType, string> = {
  NONE: "Rute paling hemat",
  FEW_ROADS_TRAP: "Memilih jalan paling sedikit",
  STOP_ORDER: "Urutan mampir keliru",
  DETOUR: "Memutar terlalu jauh",
  TIMEOUT: "Waktu habis",
};

export const NOTE = {
  fewRoadsTrap: "Sering memilih jalan dengan belokan sedikit tanpa menjumlah koinnya.",
  stopOrder: "Masih keliru menentukan urutan mampir ke tempat paket.",
  memoryDrop: "Logika baik saat angka terlihat, tetapi menurun saat angka hilang.",
  invalidTaps: "Sering mengetuk tempat yang tidak tersambung; perlu latihan membaca peta.",
  manyTimeouts: "Sering kehabisan waktu; indeks perlu dibaca hati-hati.",
  allGood: "Pemahaman rute hemat sudah baik dan konsisten.",
} as const;

export const UI = {
  incompletePackages: "Paket belum lengkap!",
  noPlayers: "Belum ada pemain",
  noSessionData: "Belum ada data sesi",
  noValue: "–",
} as const;

/** Teks layar siswa dan tutorial (Bagian 12.5). */
export const COPY = {
  gameTitle: "ROUTE RUSH",
  tagline: "Hitung. Ingat. Temukan jalannya.",
  look: "Lihat baik-baik!",
  willHide: "Angka akan hilang!",
  packagesMissing: "Paket belum lengkap!",
  arrived: "Sudah sampai! Menunggu teman…",
  probeQuestion: "Berapa koin di jalan ini?",
  timeUp: "Waktu habis! Tidak apa-apa, coba lagi di ronde berikutnya.",
  podiumCheer: "Hebat! Kamu sudah jadi kurir yang hemat.",
  lookFront: "Lihat ke layar depan",
  /** Lima aturan dari spek (12.5) + satu tambahan tentang angka yang hilang. */
  rules: [
    "Kamu kurir. Antar paket dari Rumah ke Sekolah.",
    "Ketuk tempat yang mau kamu lewati, satu per satu.",
    "Angka di jalan adalah koin. Cari total koin paling sedikit.",
    "Ada kotak paket? Kamu wajib mampir ke sana.",
    "Jalan hemat yang lambat tetap lebih untung daripada jalan boros yang cepat!",
    "Kadang angkanya menghilang. Ingat angkanya baik-baik!",
  ],
  howToPlay: "Cara bermain",
  rulesNext: "Berikutnya",
  rulesPrev: "Sebelumnya",
  rulesDone: "Mengerti!",
  rulesClose: "Tutup",
  readyWord: "READY",
  readyHello: (nickname: string): string => `Halo, ${nickname}!`,
  readyNoName: "Kamu sudah masuk!",
  readyCountdownHint: "Bersiap…",
  readyGo: "GO!",
  readyGoHint: { FULL: "Tutorial dimulai", SHORT: "Ronde latihan dimulai" },
  lobbyWait: "Kamu sudah masuk! Tunggu guru memulai.",
  tutorialReady: "Kamu siap! Tunggu teman-temanmu…",
  tutorial: [
    "Ketuk Pasar untuk berangkat.",
    "Coba ketuk Sekolah. Bisa tidak?",
    "Cari jalan yang koinnya paling sedikit. Jumlahkan dulu!",
    "Ingat angkanya baik-baik. Sebentar lagi hilang!",
    "Ada paket di Taman. Ambil dulu, baru ke Sekolah.",
  ],
  tutorialGood: "Bagus!",
  tutorialNotConnected: "Belum tersambung. Cari jalannya!",
  tutorialRetry: "Jalan itu lebih mahal. Coba lagi!",
  undoHint: "Salah jalan? Tekan panah ini untuk mundur.",
  tutorialAnswer: "Angka aslinya:",
  seatPick: "Pilih tempat dudukmu",
  seatFront: "Proyektor / papan tulis",
  seatConfirm: "Ya, ini kursiku",
  seatTaken: "Kursi ini sudah dipakai teman",
  seatLocked: "Kursi tidak bisa diganti. Minta bantuan guru.",
  fullscreenBack: "Kembali ke layar penuh untuk lanjut bermain",
  secondDevice: "Nama ini sedang dipakai di perangkat lain.",
  shortIntroVo: "Ingat, cari jalan paling hemat!",
  pinTitle: "Masukkan PIN dari layar depan",
  pinGo: "Masuk",
  pinDelete: "Hapus",
  nameTitle: "Pilih namamu",
  nameSearch: "Cari namamu",
  nameNone: "Tidak ada nama yang cocok.",
  nameTaken: "sudah dipakai",
  offline: "Terputus. Menyambungkan kembali…",
  undo: "Batal",
  coins: "Koin",
  endedTitle: "Sesi sudah selesai",
  endedBody: "Terima kasih sudah bermain. Sampai jumpa di sesi berikutnya!",
  waitNext: "Menunggu ronde berikutnya…",
  roundOf: (i: number, n: number): string => `Ronde ${i} dari ${n}`,
  practice: "Latihan (tidak dihitung)",
  points: (n: number): string => `${n.toLocaleString("id-ID")} poin`,
  rankLine: (rank: number, points: number): string => `Peringkatmu: #${rank} · ${points.toLocaleString("id-ID")} poin`,
  errors: {
    PIN_INVALID: "PIN tidak ditemukan. Periksa lagi angkanya di layar depan.",
    NOT_OPEN: "Intro belum selesai. Lihat layar depan dulu, lalu masukkan PIN.",
    SESSION_STARTED: "Permainan sudah dimulai. Minta bantuan guru.",
    NAME_TAKEN: "Nama ini sudah dipilih temanmu.",
    NAME_UNKNOWN: "Nama tidak ada di daftar.",
    ALREADY_CLAIMED: "Perangkat ini sudah memilih nama.",
    SECOND_DEVICE: "Nama ini sedang dipakai di perangkat lain.",
    TOKEN_INVALID: "Sesi lamamu sudah tidak berlaku. Masukkan PIN lagi.",
    SEAT_TAKEN: "Kursi ini sudah dipakai teman",
    SEAT_LOCKED: "Kursi tidak bisa diganti. Minta bantuan guru.",
    SEAT_INVALID: "Kursi tidak ada di denah.",
    GENERIC: "Ada masalah. Coba lagi atau minta bantuan guru.",
  },
  placeNames: {
    home: "Rumah",
    school: "Sekolah",
    market: "Pasar",
    park: "Taman",
    mosque: "Masjid",
    shop: "Toko",
    library: "Perpustakaan",
    clinic: "Puskesmas",
    field: "Lapangan",
  },
} as const;
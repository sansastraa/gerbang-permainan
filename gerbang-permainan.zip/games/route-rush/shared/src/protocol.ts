import type { Condition, IntegrityFlag, IntroMode, MapDef, NodeId, SeatLayout, SessionPhase, TapEvent } from "./types";
import type { SessionSettings } from "./settings";

/** Hitung mundur setelah guru menekan Mulai (3 → 2 → 1 → GO!). */
export const COUNTDOWN_MS = 3000;

/** Siswa dari data SIMPETERI; `id` stabil dan dipakai sebagai studentId. */
export interface RosterEntry {
  id: string;
  name: string;
  kelas?: string;
  /** Nomor absen (urutan di kelas, mulai 1). Dipakai untuk memilih klip suara nama: klip NN = absen NN. */
  absen?: number;
}

/** Nama siswa yang menemukan rute terhemat pada satu ronde (untuk pengumuman suara di proyektor). */
export interface CorrectEntry {
  name: string;
  absen: number | null;
}

export interface PhasePayload {
  phase: SessionPhase;
  introMode: IntroMode;
  roundId?: number;
  displayIndex?: number;
  totalRounds: number;
  condition?: Condition;
  durationMs: number | null;
}

export type ProtocolError =
  | "SESSION_NOT_FOUND"
  | "PIN_INVALID"
  | "NOT_OPEN"
  | "SESSION_STARTED"
  | "NAME_TAKEN"
  | "NAME_UNKNOWN"
  | "NOT_CLAIMED"
  | "ALREADY_CLAIMED"
  | "SECOND_DEVICE"
  | "TOKEN_INVALID"
  | "SEAT_TAKEN"
  | "SEAT_LOCKED"
  | "SEAT_INVALID"
  | "SEATS_DISABLED"
  | "QUOTA_NOT_MET"
  | "SEATS_PENDING"
  | "WRONG_PHASE"
  | "FORBIDDEN"
  | "INVALID_SETTINGS"
  | "INVALID_PAYLOAD"
  | "BOTS_DISABLED"
  | "NOT_FOUND";

export type Ack<T = object> = ({ ok: true } & T) | { ok: false; error: ProtocolError; detail?: unknown };

export interface RosterView {
  id: string;
  name: string;
  taken: boolean;
}

/** Panjang PIN guru buatan pengirim (SIMPETERI). Tanpa PIN, server membuat token acak. */
export const HOST_TOKEN_MIN = 4;
export const HOST_TOKEN_MAX = 32;

/** PIN guru yang sah: teks 4–32 karakter tanpa karakter kontrol (aman dipakai sebagai nilai header HTTP). */
export function isValidHostToken(v: unknown): v is string {
  // eslint-disable-next-line no-control-regex
  return typeof v === "string" && v.length >= HOST_TOKEN_MIN && v.length <= HOST_TOKEN_MAX && !/[\u0000-\u001f\u007f]/.test(v) && v === v.trim();
}

export interface HostCreatePayload {
  /** Guru boleh mengirim sebagian pengaturan; sisanya memakai bawaan. */
  settings?: Partial<SessionSettings>;
  roster: RosterEntry[];
  /** Opsional: PIN guru dari SIMPETERI (4–32 karakter), dipakai sebagai token guru. Tanpa ini, token acak. */
  hostToken?: string;
}

export interface HostCreateAck {
  sessionId: string;
  /** PIN 6 digit yang dibuat di dalam game dan ditampilkan setelah intro. */
  code: string;
  hostToken: string;
  settings: SessionSettings;
}

export interface HostAuth {
  sessionId: string;
  hostToken: string;
}

export interface JoinAck {
  roster: RosterView[];
  seatLayout: SeatLayout;
  phase: SessionPhase;
  /** Terisi bila token valid (sambung ulang). */
  me?: { studentId: string; name: string; seat: { row: number; col: number } | null };
  studentToken?: string;
  /** Keadaan fase sekarang dan sisa waktunya, agar perangkat yang tersambung ulang langsung sinkron. */
  phaseState?: { payload: PhasePayload; remainingMs: number | null };
}

export interface ClaimAck {
  studentId: string;
  studentToken: string;
  seatLayout: SeatLayout;
}

export interface LobbyUpdate {
  players: { id: string; name: string; seat: { row: number; col: number } | null; connected: boolean }[];
  joined: number;
  quota: number;
  seatsPending: number;
  canStart: boolean;
}

export interface RoundMapPayload {
  map: MapDef;
  showWeights: boolean;
}

export interface ProbeQuestion {
  edgeId: string;
  options: number[];
}

/** Satu soal pada layar hasil proyektor: peta, rute termurah, dan statistik jawaban kelas (tanpa nama siswa). */
export interface RoundSummaryItem {
  slot: number;
  map: MapDef;
  optimalPath: NodeId[];
  optimalCost: number;
  /** Jumlah langkah (jalan) pada rute termurah. */
  steps: number;
  nodes: number;
  /** Siswa yang mengerjakan soal ini dan yang menemukan rute termurah. */
  tried: number;
  solvers: number;
  /** Waktu tercepat di antara yang tepat (ms), null bila tidak ada. */
  fastestMs: number | null;
}

export interface RoundResultPayload {
  racePoints: number;
  streakBonus: number;
  probePoints: number;
  totalPoints: number;
  optimal: boolean;
  rank: number;
  /** 3 = optimal, 2 = ER ≥ 0,8, 1 = selesai, 0 = tidak selesai. */
  stars: 0 | 1 | 2 | 3;
  /** Tingkat soal berikutnya (hanya pool Tantangan). */
  level?: number;
}

export interface RouteSubmitPayload {
  roundId: number;
  path: NodeId[];
  clientElapsedMs: number;
  tapLog: TapEvent[];
  invalidTaps: number;
  undo: number;
  revisits: number;
}

export interface IntegrityEventPayload {
  type: "FOCUS_LOST" | "FOCUS_BACK" | "FULLSCREEN_EXIT";
  phase: SessionPhase;
  roundId: number;
  tMs: number;
}

export type { IntegrityFlag };

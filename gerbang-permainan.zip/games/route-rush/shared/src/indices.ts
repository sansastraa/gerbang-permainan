import { NOTE, type IndexCategory, type Quadrant } from "./copy";
import { totalPoints } from "./scoring";
import type { RoundResult } from "./types";

export const mean = (xs: readonly number[]): number => xs.reduce((a, b) => a + b, 0) / xs.length;

export function median(xs: readonly number[]): number {
  const s = [...xs].sort((a, b) => a - b);
  const mid = Math.floor(s.length / 2);
  return s.length % 2 === 1 ? (s[mid] as number) : ((s[mid - 1] as number) + (s[mid] as number)) / 2;
}

const proportion = (flags: readonly boolean[]): number => flags.filter(Boolean).length / flags.length;

/** Pembulatan tampilan: 1 desimal untuk indeks. */
export const round1 = (x: number): number => Math.round((x + 1e-12) * 10) / 10;
/** Pembulatan tampilan: 2 desimal untuk ER. */
export const round2 = (x: number): number => Math.round((x + 1e-12) * 100) / 100;

/** IL = 100 × [0.6 × mean(ER_V) + 0.4 × prop(OH_V)]; null bila tidak ada ronde VISIBLE. */
export function indexLogic(erV: readonly number[], ohV: readonly boolean[]): number | null {
  if (erV.length === 0) return null;
  return 100 * (0.6 * mean(erV) + 0.4 * proportion(ohV));
}

export interface MemoryIndex {
  im: number;
  memoryCost: number;
}

/** IM = 100 × [0.5 × P + 0.5 × ratio]; memoryCost = mean(ER_V) − mean(ER_H). Null bila V atau H kosong. */
export function indexMemory(erV: readonly number[], erH: readonly number[], probeP: number): MemoryIndex | null {
  if (erV.length === 0 || erH.length === 0) return null;
  const mv = mean(erV);
  const mh = mean(erH);
  const ratio = mv > 0 ? Math.min(1, mh / mv) : mh;
  return { im: 100 * (0.5 * probeP + 0.5 * ratio), memoryCost: mv - mh };
}

export interface SpatialSums {
  /** ΣTI ketukan tidak valid, ΣL langkah, ΣU batal, ΣKU kunjungan ulang. */
  ti: number;
  l: number;
  u: number;
  ku: number;
}

export function invalidTapRatio({ ti, l }: SpatialSums): number {
  return ti + l === 0 ? 0 : ti / (ti + l);
}

/** IS = 100 × [0.5 × (1 − RTI) + 0.5 × max(0, 1 − RBB)]; null bila ΣL = 0. */
export function indexSpatial(sums: SpatialSums): number | null {
  if (sums.l === 0) return null;
  const rti = invalidTapRatio(sums);
  const rbb = (sums.u + sums.ku) / sums.l;
  return 100 * (0.5 * (1 - rti) + 0.5 * Math.max(0, 1 - rbb));
}

/** RTM = jumlah ronde optimal per menit; null bila total waktu 0. */
export function rtm(optimalRounds: number, totalSeconds: number): number | null {
  return totalSeconds > 0 ? optimalRounds / (totalSeconds / 60) : null;
}

/** ≥ 85 "Sangat baik"; 70–84.99 "Baik"; 55–69.99 "Cukup"; < 55 "Perlu pendampingan". */
export function categoryOf(value: number | null): IndexCategory | null {
  if (value === null) return null;
  if (value >= 85) return "Sangat baik";
  if (value >= 70) return "Baik";
  if (value >= 55) return "Cukup";
  return "Perlu pendampingan";
}

export interface StudentSummary {
  studentId: string;
  roundsPlayed: number;
  roundsMissed: number;
  il: number | null;
  im: number | null;
  is: number | null;
  memoryCost: number | null;
  rtm: number | null;
  medianCorrectT: number | null;
  timeoutRate: number;
  meanEr: number | null;
  medianT: number | null;
  rti: number;
  trapRounds: number;
  stopOrderRounds: number;
  totalPoints: number;
}

/** Ronde latihan (0) tidak dihitung; ronde `missed` dikeluarkan dari semua indeks. */
export function summarizeStudent(studentId: string, results: readonly RoundResult[]): StudentSummary {
  const scored = results.filter((r) => r.roundId > 0);
  const played = scored.filter((r) => !r.missed);
  const visible = played.filter((r) => r.condition === "VISIBLE");
  const hidden = played.filter((r) => r.condition === "HIDDEN");
  const seconds = played.map((r) => r.tRouteMs / 1000);
  const correctSeconds = played.filter((r) => r.optimalHit).map((r) => r.tRouteMs / 1000);
  const sums: SpatialSums = {
    ti: played.reduce((a, r) => a + r.invalidTaps, 0),
    l: played.reduce((a, r) => a + r.steps, 0),
    u: played.reduce((a, r) => a + r.undo, 0),
    ku: played.reduce((a, r) => a + r.revisits, 0),
  };
  const memory = indexMemory(
    visible.map((r) => r.er),
    hidden.map((r) => r.er),
    hidden.length === 0 ? 0 : proportion(hidden.map((r) => r.probeCorrect === true)),
  );
  return {
    studentId,
    roundsPlayed: played.length,
    roundsMissed: scored.length - played.length,
    il: indexLogic(
      visible.map((r) => r.er),
      visible.map((r) => r.optimalHit),
    ),
    im: memory ? memory.im : null,
    is: indexSpatial(sums),
    memoryCost: memory ? memory.memoryCost : null,
    rtm: rtm(correctSeconds.length, seconds.reduce((a, b) => a + b, 0)),
    medianCorrectT: correctSeconds.length > 0 ? median(correctSeconds) : null,
    timeoutRate: played.length === 0 ? 0 : played.filter((r) => r.timedOut).length / played.length,
    meanEr: played.length > 0 ? mean(played.map((r) => r.er)) : null,
    medianT: played.length > 0 ? median(seconds) : null,
    rti: invalidTapRatio(sums),
    trapRounds: played.filter((r) => r.errorType === "FEW_ROADS_TRAP").length,
    stopOrderRounds: played.filter((r) => r.errorType === "STOP_ORDER").length,
    totalPoints: totalPoints(scored.filter((r) => !r.missed)),
  };
}

export interface ClassMedians {
  meanEr: number;
  medianT: number;
}

/** Median kelas dari siswa yang punya ≥ 1 ronde tidak missed; null bila tidak ada. */
export function classMedians(summaries: readonly StudentSummary[]): ClassMedians | null {
  const active = summaries.filter((s) => s.meanEr !== null && s.medianT !== null);
  if (active.length === 0) return null;
  return {
    meanEr: median(active.map((s) => s.meanEr as number)),
    medianT: median(active.map((s) => s.medianT as number)),
  };
}

/** Kuadran profil: ketepatan (meanER) × kecepatan (medianT) dibanding median kelas. */
export function quadrantOf(summary: StudentSummary, medians: ClassMedians | null): Quadrant | null {
  if (!medians || summary.meanEr === null || summary.medianT === null) return null;
  const accurate = summary.meanEr >= medians.meanEr;
  const fast = summary.medianT <= medians.medianT;
  if (accurate) return fast ? "MAHIR" : "TELITI";
  return fast ? "TERBURU" : "DAMPINGI";
}

/** Catatan otomatis: semua yang cocok, maksimal 3, sesuai urutan. */
export function autoNotes(summary: StudentSummary): string[] {
  const notes: string[] = [];
  if (summary.trapRounds >= 2) notes.push(NOTE.fewRoadsTrap);
  if (summary.stopOrderRounds >= 1) notes.push(NOTE.stopOrder);
  if (summary.memoryCost !== null && summary.memoryCost >= 0.15) notes.push(NOTE.memoryDrop);
  if (summary.rti > 0.15) notes.push(NOTE.invalidTaps);
  if (summary.timeoutRate >= 0.3) notes.push(NOTE.manyTimeouts);
  return notes.length > 0 ? notes.slice(0, 3) : [NOTE.allGood];
}

import { buildAdjacency, edgeId, simplePaths } from "./graph";
import type { PoolDef } from "./equivalence";
import { createRng, type Rng } from "./rng";
import type { MapDef, MapEdge, MapNode, NodeId, PlaceKind, RoundConfig } from "./types";
import { bestWalk } from "./solver";
import { segmentsCross } from "./validator";

/**
 * Bank "Tantangan" (pool T): peta besar (8–12 tempat, 11–21 jalan, sampai 3 paket) dengan waktu jalan 1–2 menit per soal.
 * Terpisah dari Pool A/B yang menjadi data acuan penelitian: tidak ikut uji kesetaraan 8.5 dan tidak dipakai untuk perbandingan form.
 * Syarat tiap peta: satu rute termurah (tanpa simpul berulang), tanpa jalan berpotongan, rute termurah bukan rute dengan jalan paling sedikit
 * bila `trap`, dan selisih biaya rute terbaik kedua kecil (1–2 koin) pada soal tanpa paket.
 */

export const CHALLENGE_POOL = "T";

const cfg = (roundId: number, nNodes: number, nEdges: number, nStops: number, trap: boolean, walkS: number): RoundConfig => ({
  roundId,
  condition: "VISIBLE",
  nNodes,
  nEdges,
  nStops,
  lookMs: 10_000,
  walkMs: walkS * 1000,
  trap,
  scored: true,
});

/** Ronde 1–10; ronde 0 (latihan) memakai peta latihan Pool A. */
export const CHALLENGE_CONFIGS: readonly RoundConfig[] = [
  cfg(1, 8, 11, 0, false, 60),
  cfg(2, 9, 12, 0, true, 65),
  cfg(3, 10, 14, 0, true, 75),
  cfg(4, 10, 14, 1, false, 80),
  cfg(5, 11, 16, 1, true, 90),
  cfg(6, 11, 17, 1, true, 95),
  cfg(7, 12, 18, 2, false, 105),
  cfg(8, 12, 19, 2, true, 110),
  cfg(9, 12, 20, 2, true, 115),
  cfg(10, 12, 21, 3, true, 120),
];

export function challengeConfig(roundId: number): RoundConfig {
  const found = CHALLENGE_CONFIGS.find((c) => c.roundId === roundId);
  if (!found) throw new RangeError(`ronde Tantangan ${roundId} tidak dikenal`);
  return found;
}

export const CHALLENGE_SLOTS = 4;
const COLS = 4;
const ROWS = 3;
const MIDDLE_KINDS: readonly PlaceKind[] = ["market", "park", "mosque", "shop", "library", "clinic", "field"];

type Slot = readonly [number, number];
type Point = readonly [number, number];
const idx = (id: NodeId): number => Number(id.slice(1));
const round3 = (v: number): number => Math.round(v * 1000) / 1000;
const uniform = (rng: Rng, lo: number, hi: number): number => lo + (hi - lo) * rng.next();

export interface ChallengeInfo {
  opt: number;
  steps: number;
  minHops: number;
  gap: number | null;
}

/** Pemeriksaan satu peta Tantangan terhadap konfigurasi rondenya; mengembalikan daftar masalah (kosong = lolos). */
export function checkChallengeMap(map: MapDef, c: RoundConfig): { issues: string[]; info: ChallengeInfo | null } {
  const issues: string[] = [];
  if (map.nodes.length !== c.nNodes || map.edges.length !== c.nEdges || map.stops.length !== c.nStops) issues.push("ukuran peta tidak sesuai konfigurasi");
  if (map.edges.some((e) => !Number.isInteger(e.w) || e.w < 1 || e.w > 9)) issues.push("bobot di luar 1–9");
  const pos = new Map(map.nodes.map((n) => [n.id, [n.x, n.y] as Point]));
  for (let i = 0; i < map.edges.length; i++) {
    for (let j = i + 1; j < map.edges.length; j++) {
      const a = map.edges[i] as MapEdge;
      const b = map.edges[j] as MapEdge;
      if (segmentsCross(pos.get(a.a) as Point, pos.get(a.b) as Point, pos.get(b.a) as Point, pos.get(b.b) as Point)) issues.push(`jalan ${a.id} dan ${b.id} berpotongan`);
    }
  }
  const best = bestWalk(map);
  const fewest = bestWalk(map, true);
  if (map.probeEdgeId !== undefined && best && !best.path.slice(1).some((id, i) => edgeId(best.path[i] as NodeId, id) === map.probeEdgeId)) issues.push("jalan ingatan tidak berada di rute termurah");
  if (!best || !fewest) return { issues: [...issues, "tidak ada rute"], info: null };
  if (best.count !== 1) issues.push("rute termurah tidak tunggal");
  if (new Set(best.path).size !== best.path.length) issues.push("rute termurah memuat simpul berulang");
  if (c.trap && best.hops === fewest.hops) issues.push("rute termurah sama dengan rute berjalan paling sedikit (bukan jebakan)");
  let gap: number | null = null;
  if (c.nStops === 0) {
    const adj = buildAdjacency(map);
    const costs = [...new Set(simplePaths(adj, map.start, map.goal).map((p) => p.slice(1).reduce((s, id, i) => s + (adj.get(p[i] as NodeId)?.get(id) as number), 0)))].sort((a, b) => a - b);
    gap = costs.length > 1 ? (costs[1] as number) - (costs[0] as number) : null;
    if (gap === null || gap < 1 || gap > 2) issues.push("selisih rute terbaik kedua di luar 1–2");
  }
  return { issues, info: { opt: best.cost, steps: best.hops, minHops: fewest.hops, gap } };
}

/** Membuat satu peta Tantangan yang lolos `checkChallengeMap`. Deterministik terhadap `rng`. */
export function generateChallengeMap(c: RoundConfig, rng: Rng, mapId: string): MapDef {
  const nn = c.nNodes;
  for (let layout = 0; layout < 20_000; layout++) {
    const slots: Slot[] = [];
    for (let col = 0; col < COLS; col++) for (let r = 0; r < ROWS; r++) slots.push([col, r]);
    const start = rng.pick(slots.filter((s) => s[0] === 0));
    const goal = rng.pick(slots.filter((s) => s[0] === COLS - 1));
    const rest = rng.shuffle(slots.filter((s) => s !== start && s !== goal));
    const chosen: Slot[] = [start, ...rest.slice(0, nn - 2), goal];
    const ids = chosen.map((_, i) => `n${i}`);
    const kinds = rng.shuffle(MIDDLE_KINDS);
    const nodes: MapNode[] = chosen.map(([col, r], i) => ({
      id: ids[i] as string,
      kind: i === 0 ? "home" : i === nn - 1 ? "school" : (kinds[(i - 1) % kinds.length] as PlaceKind),
      x: round3(0.1 + (0.8 * col) / (COLS - 1) + uniform(rng, -0.02, 0.02)),
      y: round3(0.15 + (0.7 * r) / (ROWS - 1) + uniform(rng, -0.03, 0.03)),
    }));
    const pos = new Map<NodeId, Point>(nodes.map((n) => [n.id, [n.x, n.y]]));
    const slotOf = new Map<NodeId, Slot>(ids.map((id, i) => [id, chosen[i] as Slot]));
    const pairs: [NodeId, NodeId][] = [];
    for (let i = 0; i < nn; i++) {
      for (let j = i + 1; j < nn; j++) {
        const a = slotOf.get(ids[i] as string) as Slot;
        const b = slotOf.get(ids[j] as string) as Slot;
        if (Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])) === 1) pairs.push([ids[i] as string, ids[j] as string]);
      }
    }
    const candidates = rng.shuffle(pairs);
    const parent = new Map<NodeId, NodeId>(ids.map((id) => [id, id]));
    const find = (x: NodeId): NodeId => {
      let r = x;
      while (parent.get(r) !== r) r = parent.get(r) as NodeId;
      return r;
    };
    const chosenEdges: [NodeId, NodeId][] = [];
    const free = (a: NodeId, b: NodeId): boolean => chosenEdges.every(([p, q]) => !segmentsCross(pos.get(a) as Point, pos.get(b) as Point, pos.get(p) as Point, pos.get(q) as Point));
    for (const [a, b] of candidates) {
      if (find(a) !== find(b) && free(a, b)) {
        parent.set(find(a), find(b));
        chosenEdges.push([a, b]);
      }
    }
    if (chosenEdges.length !== nn - 1) continue;
    for (const [a, b] of candidates) {
      if (chosenEdges.length >= c.nEdges) break;
      if (!chosenEdges.some(([p, q]) => p === a && q === b) && free(a, b)) chosenEdges.push([a, b]);
    }
    if (chosenEdges.length !== c.nEdges) continue;
    const ordered = chosenEdges
      .map(([a, b]) => ({ a: idx(a) <= idx(b) ? a : b, b: idx(a) <= idx(b) ? b : a }))
      .sort((p, q) => idx(p.a) - idx(q.a) || idx(p.b) - idx(q.b));
    const middle = ids.slice(1, -1);
    for (let stopTry = 0; stopTry < 4; stopTry++) {
      const stops = rng.shuffle(middle).slice(0, c.nStops).sort((p, q) => idx(p) - idx(q));
      for (let attempt = 0; attempt < 60; attempt++) {
        const edges: MapEdge[] = ordered.map((e) => ({ id: edgeId(e.a, e.b), a: e.a, b: e.b, w: 1 + rng.int(9) }));
        const map: MapDef = { id: mapId, nodes, edges, start: ids[0] as string, goal: ids[nn - 1] as string, stops };
        if (checkChallengeMap(map, c).issues.length > 0) continue;
        // jalan yang ditanyakan bila ronde ini dimainkan sebagai soal ingatan: selalu pada rute termurah
        const route = (bestWalk(map) as { path: NodeId[] }).path;
        const onRoute = route.slice(1).map((id, i) => edgeId(route[i] as NodeId, id));
        return { ...map, probeEdgeId: rng.pick(onRoute) };
      }
    }
  }
  throw new Error(`generateChallengeMap: gagal membuat peta ${mapId}`);
}

/** Bank Tantangan: 4 soal sekelas per ronde 1–10 ditambah peta latihan ronde 0 dari bank acuan. */
export function buildChallengePool(seed: string, practice: PoolDef["rounds"][number]): PoolDef {
  const rng = createRng(seed);
  const rounds: PoolDef["rounds"] = [practice];
  for (const c of CHALLENGE_CONFIGS) {
    const items: MapDef[] = [];
    for (let slot = 0; slot < CHALLENGE_SLOTS; slot++) items.push(generateChallengeMap(c, rng, `${CHALLENGE_POOL}-${String(c.roundId).padStart(2, "0")}-${slot}`));
    rounds.push({ roundId: c.roundId, items });
  }
  return { pool: CHALLENGE_POOL, seed, slots: CHALLENGE_SLOTS, rounds };
}

/** Tingkat tertinggi dan terendah pada mode adaptif. */
export const MIN_LEVEL = 1;
export const MAX_LEVEL = CHALLENGE_CONFIGS.length;

export interface LevelOutcome {
  missed: boolean;
  timedOut: boolean;
  completed: boolean;
  optimalHit: boolean;
  /** Rasio efisiensi rute siswa terhadap rute termurah (1 = tepat). */
  er: number;
  tRouteMs: number;
  limitMs: number;
}

/**
 * Soal berikutnya mengikuti kemampuan: rute termurah dan cepat (di bawah 40% waktu) naik dua tingkat, rute termurah naik satu,
 * rute hampir hemat (ER ≥ 0,8) bertahan, selebihnya turun satu. Tidak ikut menjawab = tingkat tetap. Dijepit pada 1–10.
 */
export function nextLevel(level: number, o: LevelOutcome): number {
  if (o.missed) return level;
  let step = -1;
  if (o.optimalHit && o.completed) step = o.tRouteMs <= o.limitMs * 0.4 ? 2 : 1;
  else if (o.completed && !o.timedOut && o.er >= 0.8) step = 0;
  return Math.min(MAX_LEVEL, Math.max(MIN_LEVEL, level + step));
}
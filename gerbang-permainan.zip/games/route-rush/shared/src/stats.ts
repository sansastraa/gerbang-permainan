/** Fungsi gamma tak-lengkap teregularisasi atas Q(a, x) (Numerical Recipes: deret untuk x < a+1, pecahan lanjut untuk sisanya). */
function gammaQ(a: number, x: number): number {
  if (x <= 0) return 1;
  const lg = lnGamma(a);
  if (x < a + 1) {
    let sum = 1 / a;
    let term = sum;
    for (let n = 1; n < 500; n++) {
      term *= x / (a + n);
      sum += term;
      if (Math.abs(term) < Math.abs(sum) * 1e-14) break;
    }
    return 1 - sum * Math.exp(-x + a * Math.log(x) - lg);
  }
  let b = x + 1 - a;
  let c = 1 / 1e-300;
  let d = 1 / b;
  let h = d;
  for (let i = 1; i < 500; i++) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < 1e-300) d = 1e-300;
    c = b + an / c;
    if (Math.abs(c) < 1e-300) c = 1e-300;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-14) break;
  }
  return Math.exp(-x + a * Math.log(x) - lg) * h;
}

function lnGamma(z: number): number {
  const g = [76.18009172947146, -86.50532032941677, 24.01409824083091, -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = z;
  const tmp = z + 5.5 - (z + 0.5) * Math.log(z + 5.5);
  let ser = 1.000000000190015;
  for (const c of g) ser += c / ++y;
  return -tmp + Math.log((2.5066282746310005 * ser) / z);
}

/** Peluang ekor atas distribusi khi-kuadrat: P(X ≥ x) dengan `df` derajat bebas. */
export function chiSquareSf(x: number, df: number): number {
  if (x <= 0) return 1;
  return Math.min(1, Math.max(0, gammaQ(df / 2, x / 2)));
}

export interface KruskalWallis {
  h: number;
  df: number;
  p: number;
  n: number;
}

/**
 * Uji Kruskal-Wallis dengan koreksi nilai kembar. Kelompok kosong diabaikan. Mengembalikan null bila ada kurang dari dua
 * kelompok berisi, atau semua nilai sama (statistik tidak terdefinisi).
 */
export function kruskalWallis(groups: readonly (readonly number[])[]): KruskalWallis | null {
  const gs = groups.filter((g) => g.length > 0);
  if (gs.length < 2) return null;
  const all = gs.flatMap((g, gi) => g.map((v) => ({ v, gi })));
  const n = all.length;
  all.sort((a, b) => a.v - b.v);
  const rankSum = new Array<number>(gs.length).fill(0);
  let tieTerm = 0;
  for (let i = 0; i < n; ) {
    let j = i;
    while (j + 1 < n && (all[j + 1] as { v: number }).v === (all[i] as { v: number }).v) j++;
    const t = j - i + 1;
    const rank = (i + j) / 2 + 1;
    for (let k = i; k <= j; k++) rankSum[(all[k] as { gi: number }).gi] = (rankSum[(all[k] as { gi: number }).gi] as number) + rank;
    tieTerm += t ** 3 - t;
    i = j + 1;
  }
  const correction = 1 - tieTerm / (n ** 3 - n);
  if (correction <= 0) return null;
  let h = 0;
  gs.forEach((g, i) => (h += (rankSum[i] as number) ** 2 / g.length));
  h = (12 / (n * (n + 1))) * h - 3 * (n + 1);
  h /= correction;
  const df = gs.length - 1;
  return { h, df, p: chiSquareSf(h, df), n };
}
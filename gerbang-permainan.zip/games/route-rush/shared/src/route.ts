import { buildAdjacency, hasEdge, pathCost } from "./graph";
import type { MapDef, NodeId, TapEvent } from "./types";

/** State rute satu pemain pada satu ronde. Semua fungsi di bawah murni: mengembalikan state baru. */
export interface RouteState {
  path: NodeId[]; // dimulai [start]
  collected: Set<NodeId>; // stop yang sudah diambil (diturunkan dari path)
  invalidTaps: number;
  undo: number;
  revisits: number;
  tapLog: TapEvent[];
  done: boolean;
}

const collectedOf = (map: MapDef, path: readonly NodeId[]): Set<NodeId> =>
  new Set(map.stops.filter((s) => path.includes(s)));

export function createRoute(map: MapDef): RouteState {
  return { path: [map.start], collected: new Set(), invalidTaps: 0, undo: 0, revisits: 0, tapLog: [], done: false };
}

export function currentNode(state: RouteState): NodeId {
  return state.path[state.path.length - 1] as NodeId;
}

/** Semua stop sudah ada di path dan posisi sekarang adalah goal. */
export function isFinished(map: MapDef, path: readonly NodeId[]): boolean {
  return path[path.length - 1] === map.goal && map.stops.every((s) => path.includes(s));
}

/** Pemain berada di goal tetapi paket belum lengkap ("Paket belum lengkap!"). */
export function packagesIncomplete(map: MapDef, state: RouteState): boolean {
  return !state.done && currentNode(state) === map.goal && !map.stops.every((s) => state.path.includes(s));
}

/**
 * Ketukan pada node. `walking` = false berarti fase bukan WALK: ketukan diabaikan dan tidak dicatat.
 * Ketukan pada posisi sekarang juga diabaikan.
 */
export function tapNode(map: MapDef, state: RouteState, nodeId: NodeId, tMs: number, walking = true): RouteState {
  if (!walking || state.done) return state;
  const here = currentNode(state);
  if (nodeId === here) return state;
  const adj = buildAdjacency(map);
  if (!hasEdge(adj, here, nodeId)) {
    return { ...state, invalidTaps: state.invalidTaps + 1, tapLog: [...state.tapLog, { tMs, nodeId, valid: false }] };
  }
  const revisit = state.path.includes(nodeId);
  const path = [...state.path, nodeId];
  return {
    ...state,
    path,
    collected: collectedOf(map, path),
    revisits: state.revisits + (revisit ? 1 : 0),
    tapLog: [...state.tapLog, { tMs, nodeId, valid: true }],
    done: isFinished(map, path),
  };
}

/**
 * Batal: hanya bila path > 1. Bila node yang dilepas adalah kunjungan ulang, hitungan `revisits`
 * ikut turun sehingga selalu sama dengan hitung ulang dari path akhir (lihat DECISIONS.md).
 */
export function undoLast(map: MapDef, state: RouteState, tMs: number, walking = true): RouteState {
  if (!walking || state.done || state.path.length <= 1) return state;
  const removed = state.path[state.path.length - 1] as NodeId;
  const path = state.path.slice(0, -1);
  return {
    ...state,
    path,
    collected: collectedOf(map, path),
    undo: state.undo + 1,
    revisits: state.revisits - (path.includes(removed) ? 1 : 0),
    tapLog: [...state.tapLog, { tMs, nodeId: "UNDO", valid: true }],
    done: false,
  };
}

/** Jumlah koin sepanjang path (edge yang diulang dihitung berulang). */
export function routeCost(map: MapDef, path: readonly NodeId[]): number | null {
  return pathCost(map, path);
}

/** L = jumlah langkah. */
export const routeSteps = (path: readonly NodeId[]): number => Math.max(0, path.length - 1);

/** Hitung ulang kunjungan ulang dari path: kemunculan ke-2 dst. suatu node. */
export function countRevisits(path: readonly NodeId[]): number {
  const seen = new Set<NodeId>();
  let n = 0;
  path.forEach((id, i) => {
    if (i > 0 && seen.has(id)) n++;
    seen.add(id);
  });
  return n;
}

/** tMs ketukan valid pertama; null bila tidak ada. */
export function firstValidTapMs(tapLog: readonly TapEvent[]): number | null {
  const first = tapLog.find((t) => t.valid && t.nodeId !== "UNDO");
  return first ? first.tMs : null;
}

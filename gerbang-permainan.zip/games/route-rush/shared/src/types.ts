export type NodeId = string; // "n0".."n7"
export type PlaceKind = "home" | "school" | "market" | "park" | "mosque" | "shop" | "library" | "clinic" | "field";

export interface MapNode {
  id: NodeId;
  kind: PlaceKind; // ikon + nama tampil
  x: number;
  y: number; // koordinat ternormalisasi 0..1
}

export interface MapEdge {
  id: string; // "n0-n1" (id kecil di depan)
  a: NodeId;
  b: NodeId;
  w: number; // koin, integer 1..9
}

export interface MapDef {
  id: string; // "A-05"
  nodes: MapNode[];
  edges: MapEdge[];
  start: NodeId; // kind "home"
  goal: NodeId; // kind "school"
  stops: NodeId[]; // tempat paket wajib singgah (0..2)
  probeEdgeId?: string; // hanya untuk ronde HIDDEN
}

export type Condition = "VISIBLE" | "HIDDEN";

export interface RoundConfig {
  roundId: number; // 0 = latihan
  condition: Condition;
  nNodes: number;
  nEdges: number;
  nStops: number;
  lookMs: number;
  walkMs: number;
  trap: boolean; // wajib: rute paling sedikit jalan ≠ optimal
  scored: boolean; // latihan = false
}

export type ErrorType = "NONE" | "FEW_ROADS_TRAP" | "STOP_ORDER" | "DETOUR" | "TIMEOUT";

export interface TapEvent {
  tMs: number; // sejak akhir fase Lihat
  nodeId: NodeId | "UNDO";
  valid: boolean;
}

export type IntegrityFlag =
  | "FOCUS_LOST" // keluar aplikasi/tab saat LOOK/WALK
  | "FULLSCREEN_EXIT"
  | "TOO_FAST" // rute ≥ 3 langkah dengan rata-rata < 400 ms per langkah
  | "SECOND_DEVICE" // token yang sama mencoba masuk dari perangkat lain
  | "SEAT_CHANGED"; // pindah kursi setelah ronde dimulai

export interface RoundResult {
  sessionId: string;
  studentId: string;
  nickname: string;
  form: "A" | "B" | "T"; // = Pool A / Pool B / T (Tantangan)
  mode: "STANDARD" | "QUICK";
  roundId: number;
  condition: Condition;
  variantId: number;
  itemId: string; // mis. "PA-05-2"
  itemSlot: 0 | 1 | 2 | 3;
  seatMode: "SEATED" | "NO_SEAT";
  seatRow: number | null;
  seatCol: number | null;
  focusLost: number; // keluar aplikasi/tab saat LOOK atau WALK
  fullscreenExits: number;
  integrityFlags: IntegrityFlag[];
  nNodes: number;
  nEdges: number;
  nStops: number;
  timeLimitS: number;
  optimalCost: number;
  playerCost: number | null;
  playerPath: NodeId[];
  completed: boolean;
  optimalHit: boolean;
  timedOut: boolean;
  missed: boolean;
  er: number;
  tFirstMs: number | null;
  tRouteMs: number;
  invalidTaps: number;
  undo: number;
  revisits: number;
  steps: number;
  probeCorrect: boolean | null;
  probeMs: number | null;
  racePoints: number;
  streakBonus: number;
  probePoints: number;
  rankAfter: number;
  errorType: ErrorType;
  tapLog: TapEvent[];
}

export type SessionPhase =
  | "INTRO_IDENT"
  | "INTRO_TRAILER"
  | "LOBBY" // PIN tampil setelah intro; siswa memilih nama dan menunggu
  | "COUNTDOWN" // hitung mundur 3 detik setelah guru menekan Mulai
  | "TUTORIAL"
  | "LOOK"
  | "WALK"
  | "PROBE"
  | "RESULT"
  | "LEADERBOARD"
  | "PODIUM"
  | "ENDED";

export type IntroMode = "FULL" | "SHORT"; // FULL = sesi perdana kelas
export type SessionMode = "STANDARD" | "QUICK";

export interface SeatLayout {
  rows: number;
  cols: number; // maks 8 × 10
  aisleAfterCols: number[]; // mis. [4] = lorong setelah kursi ke-4 (hanya tampilan)
  enabled: boolean; // false → mode NO_SEAT
}

export interface TutorialStepResult {
  step: number;
  attempts: number;
  hintsShown: number;
  invalidTaps: number;
  undo: number;
  ms: number;
}

export interface TutorialResult {
  sessionId: string;
  studentId: string;
  completed: boolean; // 5 langkah tanpa demo otomatis
  totalMs: number;
  step3Attempts: number;
  hints: number; // jumlah tangan bayangan yang muncul
  probeCorrect: boolean | null; // soal ingatan langkah 4
  autoDemoSteps: number[]; // langkah yang diselesaikan demo otomatis
  steps: TutorialStepResult[];
}

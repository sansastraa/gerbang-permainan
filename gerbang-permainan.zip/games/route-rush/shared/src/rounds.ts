import type { IntroMode, RoundConfig, SessionMode } from "./types";

const cfg = (
  roundId: number,
  condition: RoundConfig["condition"],
  nNodes: number,
  nEdges: number,
  nStops: number,
  trap: boolean,
  lookMs: number,
  walkMs: number,
): RoundConfig => ({ roundId, condition, nNodes, nEdges, nStops, lookMs, walkMs, trap, scored: roundId > 0 });

export const ROUND_CONFIGS: readonly RoundConfig[] = [
  cfg(0, "VISIBLE", 4, 4, 0, false, 5000, 20000),
  cfg(1, "VISIBLE", 5, 6, 0, false, 5000, 20000),
  cfg(2, "HIDDEN", 5, 6, 0, false, 5000, 20000),
  cfg(3, "VISIBLE", 6, 7, 0, true, 6000, 25000),
  cfg(4, "HIDDEN", 6, 7, 0, true, 6000, 25000),
  cfg(5, "VISIBLE", 6, 8, 0, true, 6000, 25000),
  cfg(6, "HIDDEN", 6, 8, 0, true, 6000, 25000),
  cfg(7, "VISIBLE", 6, 8, 1, false, 6000, 30000),
  cfg(8, "HIDDEN", 6, 8, 1, false, 6000, 30000),
  cfg(9, "VISIBLE", 7, 9, 2, false, 7000, 35000),
  cfg(10, "HIDDEN", 7, 9, 2, false, 7000, 35000),
];

export const PROBE_MS = 5000;
export const RESULT_MS = 3000;
export const LEADERBOARD_MS = 3000;
export const GRACE_MS = 2000;

export const STANDARD_ROUND_IDS: readonly number[] = ROUND_CONFIGS.map((c) => c.roundId);
export const QUICK_ROUND_IDS: readonly number[] = [0, 1, 2, 3, 4, 7, 8];

export function getRoundConfig(roundId: number): RoundConfig {
  const found = ROUND_CONFIGS.find((c) => c.roundId === roundId);
  if (!found) throw new RangeError(`ronde ${roundId} tidak dikenal`);
  return found;
}

/** Ronde yang dimainkan. Pada sesi perdana (FULL) ronde latihan 0 dilewati karena tutorial menggantikannya. */
export function roundIdsFor(mode: SessionMode, introMode: IntroMode): number[] {
  const ids = mode === "STANDARD" ? STANDARD_ROUND_IDS : QUICK_ROUND_IDS;
  return introMode === "FULL" ? ids.filter((id) => id !== 0) : [...ids];
}

/** Nomor ronde yang ditampilkan: Standar = roundId; Kilat berurutan 1–6 (latihan tetap 0). */
export function displayIndex(mode: SessionMode, roundId: number): number {
  if (mode === "STANDARD" || roundId === 0) return roundId;
  return QUICK_ROUND_IDS.filter((id) => id !== 0 && id <= roundId).length;
}

/** LOOK + WALK + PROBE (HIDDEN) + RESULT + LEADERBOARD (bukan latihan), batas maksimal. */
export function roundMaxDurationMs(config: RoundConfig): number {
  return (
    config.lookMs +
    config.walkMs +
    (config.condition === "HIDDEN" ? PROBE_MS : 0) +
    RESULT_MS +
    (config.scored ? LEADERBOARD_MS : 0)
  );
}

export function roundsMaxDurationMs(roundIds: readonly number[]): number {
  return roundIds.reduce((sum, id) => sum + roundMaxDurationMs(getRoundConfig(id)), 0);
}

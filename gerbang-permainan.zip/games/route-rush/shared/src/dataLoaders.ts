import type { PoolDef } from "./equivalence";
import type { Condition, MapDef, MapEdge, MapNode, PlaceKind } from "./types";

const KINDS: readonly PlaceKind[] = ["home", "school", "market", "park", "mosque", "shop", "library", "clinic", "field"];

class DataError extends Error {
  constructor(where: string, what: string) {
    super(`${where}: ${what}`);
    this.name = "DataError";
  }
}

const isRecord = (v: unknown): v is Record<string, unknown> => typeof v === "object" && v !== null && !Array.isArray(v);

function record(v: unknown, where: string): Record<string, unknown> {
  if (!isRecord(v)) throw new DataError(where, "bukan objek");
  return v;
}

function list(v: unknown, where: string): unknown[] {
  if (!Array.isArray(v)) throw new DataError(where, "bukan daftar");
  return v;
}

function text(v: unknown, where: string): string {
  if (typeof v !== "string" || v.length === 0) throw new DataError(where, "bukan teks");
  return v;
}

function num(v: unknown, where: string): number {
  if (typeof v !== "number" || !Number.isFinite(v)) throw new DataError(where, "bukan angka");
  return v;
}

/** Memeriksa bentuk satu peta dari JSON dan mengembalikannya bertipe. */
export function parseMap(raw: unknown, where = "peta"): MapDef {
  const o = record(raw, where);
  const id = text(o["id"], `${where}.id`);
  const nodes: MapNode[] = list(o["nodes"], `${id}.nodes`).map((n, i) => {
    const r = record(n, `${id}.nodes[${i}]`);
    const kind = text(r["kind"], `${id}.nodes[${i}].kind`);
    if (!KINDS.includes(kind as PlaceKind)) throw new DataError(id, `jenis tempat tidak dikenal: ${kind}`);
    return { id: text(r["id"], `${id}.nodes[${i}].id`), kind: kind as PlaceKind, x: num(r["x"], `${id}.x`), y: num(r["y"], `${id}.y`) };
  });
  const edges: MapEdge[] = list(o["edges"], `${id}.edges`).map((e, i) => {
    const r = record(e, `${id}.edges[${i}]`);
    return { id: text(r["id"], `${id}.edges[${i}].id`), a: text(r["a"], `${id}.a`), b: text(r["b"], `${id}.b`), w: num(r["w"], `${id}.w`) };
  });
  const map: MapDef = {
    id,
    nodes,
    edges,
    start: text(o["start"], `${id}.start`),
    goal: text(o["goal"], `${id}.goal`),
    stops: list(o["stops"], `${id}.stops`).map((s) => text(s, `${id}.stops`)),
  };
  if (typeof o["probeEdgeId"] === "string") map.probeEdgeId = o["probeEdgeId"];
  const ids = new Set(nodes.map((n) => n.id));
  if (![map.start, map.goal, ...map.stops].every((n) => ids.has(n))) throw new DataError(id, "start/goal/stops menunjuk node yang tidak ada");
  if (!edges.every((e) => ids.has(e.a) && ids.has(e.b))) throw new DataError(id, "edge menunjuk node yang tidak ada");
  return map;
}

export interface FormBank {
  form: string;
  seed: string;
  maps: (MapDef & { roundId: number })[];
}

/** Bank fixture Form A/B (formA.json, formB.json). */
export function parseFormBank(raw: unknown): FormBank {
  const o = record(raw, "form");
  return {
    form: text(o["form"], "form.form"),
    seed: text(o["seed"], "form.seed"),
    maps: list(o["maps"], "form.maps").map((m, i) => ({ ...parseMap(m, `form.maps[${i}]`), roundId: num(record(m, "peta")["roundId"], "roundId") })),
  };
}

/** Bank soal paralel (poolA.json, poolB.json). */
export function parsePool(raw: unknown): PoolDef {
  const o = record(raw, "pool");
  return {
    pool: text(o["pool"], "pool.pool"),
    seed: text(o["seed"], "pool.seed"),
    slots: num(o["slots"], "pool.slots"),
    rounds: list(o["rounds"], "pool.rounds").map((r, i) => {
      const rr = record(r, `pool.rounds[${i}]`);
      return { roundId: num(rr["roundId"], "roundId"), items: list(rr["items"], "items").map((m, j) => parseMap(m, `pool.rounds[${i}].items[${j}]`)) };
    }),
  };
}

export interface TutorialMap extends MapDef {
  title: string;
  condition: Condition;
  trap: boolean;
  golden: { optimalCost: number; optimalRoute: string[]; minHops: number; secondBestGap: number | null };
}

/** Lima peta tutorial T-01..T-05 (tutorial.json). */
export function parseTutorial(raw: unknown): TutorialMap[] {
  const o = record(raw, "tutorial");
  return list(o["maps"], "tutorial.maps").map((m, i) => {
    const r = record(m, `tutorial.maps[${i}]`);
    const g = record(r["golden"], `tutorial.maps[${i}].golden`);
    const condition = text(r["condition"], "condition");
    if (condition !== "VISIBLE" && condition !== "HIDDEN") throw new DataError("tutorial", `kondisi tidak dikenal: ${condition}`);
    return {
      ...parseMap(m, `tutorial.maps[${i}]`),
      title: text(r["title"], "title"),
      condition,
      trap: r["trap"] === true,
      golden: {
        optimalCost: num(g["optimalCost"], "golden.optimalCost"),
        optimalRoute: list(g["optimalRoute"], "golden.optimalRoute").map((n) => text(n, "golden.route")),
        minHops: num(g["minHops"], "golden.minHops"),
        secondBestGap: g["secondBestGap"] === null ? null : num(g["secondBestGap"], "golden.secondBestGap"),
      },
    };
  });
}

/** Soal untuk (ronde, slot) dari sebuah bank. */
export function poolItem(pool: PoolDef, roundId: number, slot: number): MapDef {
  const item = pool.rounds.find((r) => r.roundId === roundId)?.items[slot];
  if (!item) throw new RangeError(`bank ${pool.pool}: tidak ada soal ronde ${roundId} slot ${slot}`);
  return item;
}

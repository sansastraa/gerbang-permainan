import { evaluatePath, isValidPath } from "./metrics";
import { countRevisits, routeSteps } from "./route";
import { probePoints, racePoints } from "./scoring";
import { optimalCost } from "./solver";
import type { MapDef, RoundResult, TutorialResult } from "./types";

export class IntegrityError extends Error {
  readonly issues: string[];
  constructor(subject: string, issues: string[]) {
    super(`${subject}: ${issues.join("; ")}`);
    this.name = "IntegrityError";
    this.issues = issues;
  }
}

const EPS = 1e-9;

function checkMissed(r: RoundResult, issues: string[]): void {
  if (r.completed || r.optimalHit || r.timedOut) issues.push("ronde missed tidak boleh selesai/optimal/timeout");
  if (r.playerCost !== null || r.playerPath.length > 1) issues.push("ronde missed tidak punya rute");
  if (r.er !== 0 || r.racePoints !== 0 || r.streakBonus !== 0 || r.probePoints !== 0) issues.push("ronde missed harus bernilai 0");
}

/**
 * Memeriksa hasil satu ronde terhadap peta kanonik. Melempar IntegrityError berisi semua pelanggaran:
 * rute/edge, biaya, completed, er/optimalHit/errorType/poin, waktu, steps/revisits, dan tapLog.
 */
export function assertRoundIntegrity(result: RoundResult, map: MapDef): void {
  const issues: string[] = [];
  if (result.missed) {
    checkMissed(result, issues);
    if (issues.length) throw new IntegrityError(`ronde ${result.roundId} ${result.studentId}`, issues);
    return;
  }

  const path = result.playerPath;
  const limitMs = result.timeLimitS * 1000;

  // 1. rute dimulai di start dan hanya melewati edge yang ada
  if (!isValidPath(map, path)) issues.push("playerPath bukan rangkaian edge valid dari start");

  const ev = evaluatePath(map, path, result.timedOut);

  // 2. biaya dihitung ulang
  if (result.playerCost !== ev.playerCost) issues.push(`playerCost ${String(result.playerCost)} ≠ hitung ulang ${String(ev.playerCost)}`);
  if (result.optimalCost !== optimalCost(map)) issues.push("optimalCost tidak cocok dengan solver");

  // 3. completed benar hanya bila goal dan semua stop ada di path
  if (result.completed !== ev.completed) issues.push("completed tidak cocok dengan path");
  if (result.timedOut && result.completed) issues.push("ronde timeout tidak boleh completed");

  // 4. er, optimalHit, errorType, dan poin
  if (Math.abs(result.er - ev.er) > EPS) issues.push("er tidak cocok");
  if (result.optimalHit !== ev.optimalHit) issues.push("optimalHit tidak cocok");
  if (result.errorType !== ev.errorType) issues.push(`errorType ${result.errorType} ≠ ${ev.errorType}`);
  const expectedRace = racePoints({
    optimalHit: ev.optimalHit,
    completed: ev.completed,
    er: ev.er,
    tSec: result.tRouteMs / 1000,
    limitSec: result.timeLimitS,
  });
  if (result.racePoints !== expectedRace) issues.push(`racePoints ${result.racePoints} ≠ ${expectedRace}`);
  const expectedProbe = probePoints(result.probeCorrect, (result.probeMs ?? 0) / 1000);
  if (result.probePoints !== expectedProbe) issues.push(`probePoints ${result.probePoints} ≠ ${expectedProbe}`);
  if (result.streakBonus < 0 || result.streakBonus > 300 || (!ev.optimalHit && result.streakBonus !== 0)) {
    issues.push("streakBonus di luar aturan");
  }

  // 5. waktu
  if (result.tRouteMs < 0 || result.tRouteMs > limitMs) issues.push("tRouteMs di luar 0..walkMs");
  if (result.tFirstMs !== null && result.tFirstMs > result.tRouteMs) issues.push("tFirstMs melebihi tRouteMs");

  // 6. langkah dan kunjungan ulang
  if (result.steps !== routeSteps(path)) issues.push("steps ≠ playerPath.length − 1");
  if (result.revisits !== countRevisits(path)) issues.push("revisits tidak cocok dengan path");

  // 7. tapLog urut naik; jumlah entri tidak valid dan UNDO cocok
  for (let i = 1; i < result.tapLog.length; i++) {
    if ((result.tapLog[i] as { tMs: number }).tMs < (result.tapLog[i - 1] as { tMs: number }).tMs) {
      issues.push("tapLog tidak urut naik");
      break;
    }
  }
  if (result.tapLog.filter((t) => !t.valid).length !== result.invalidTaps) issues.push("invalidTaps ≠ entri valid:false");
  if (result.tapLog.filter((t) => t.nodeId === "UNDO").length !== result.undo) issues.push("undo ≠ entri UNDO");

  if (issues.length) throw new IntegrityError(`ronde ${result.roundId} ${result.studentId}`, issues);
}

/** Memeriksa hasil tutorial: 5 langkah, ms ≥ 0, total ≤ totalMs, completed salah bila ada demo otomatis. */
export function assertTutorialIntegrity(result: TutorialResult): void {
  const issues: string[] = [];
  if (result.steps.length !== 5) issues.push("tutorial harus berisi 5 langkah");
  result.steps.forEach((s, i) => {
    if (s.step !== i + 1) issues.push(`langkah ke-${i + 1} bernomor ${s.step}`);
    if (s.ms < 0) issues.push(`langkah ${s.step} bernilai ms negatif`);
  });
  const sum = result.steps.reduce((a, s) => a + s.ms, 0);
  if (result.totalMs < 0 || sum > result.totalMs) issues.push("jumlah ms langkah melebihi totalMs");
  if (result.autoDemoSteps.length > 0 && result.completed) issues.push("completed harus salah bila ada demo otomatis");
  if (issues.length) throw new IntegrityError(`tutorial ${result.studentId}`, issues);
}

import { buildAdjacency, edgeId } from "./graph";
import { analyzeRoutes } from "./solver";
import type { MapDef, NodeId, RoundConfig } from "./types";

export type ValidationCode = "V1" | "V2" | "V3" | "V4" | "V5" | "V6" | "V7" | "V8" | "V9";

export interface ValidationIssue {
  code: ValidationCode;
  detail?: string;
}

export interface ValidationInfo {
  opt: number;
  gap: number | null;
  route: NodeId[];
  minHops: number;
  steps: number;
}

export interface ValidationResult {
  ok: boolean;
  info: ValidationInfo | null;
  issues: ValidationIssue[];
  /** Kode unik yang gagal, urut. */
  codes: ValidationCode[];
}

export type ValidationSpec = Pick<RoundConfig, "nNodes" | "nEdges" | "nStops" | "condition" | "trap">;

/** Pengecualian peta tutorial ditulis eksplisit per id; tidak ada syarat yang dimatikan secara umum. */
export const TUTORIAL_EXCEPTIONS: Readonly<Record<string, readonly ValidationCode[]>> = { "T-01": ["V3"] };

type Point = readonly [number, number];

const orient = (a: Point, b: Point, c: Point): number => {
  const v = (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0]);
  return v > 1e-12 ? 1 : v < -1e-12 ? -1 : 0;
};

/** Dua segmen berpotongan secara sejati; segmen yang berbagi titik ujung tidak dihitung. */
export function segmentsCross(p1: Point, p2: Point, p3: Point, p4: Point): boolean {
  const distinct = new Set([p1, p2, p3, p4].map((p) => `${p[0]},${p[1]}`));
  if (distinct.size < 4) return false;
  return orient(p1, p2, p3) * orient(p1, p2, p4) < 0 && orient(p3, p4, p1) * orient(p3, p4, p2) < 0;
}

/** Pasangan edge (berdasarkan indeks) yang saling memotong. */
export function crossingEdges(map: MapDef): [string, string][] {
  const pos = new Map(map.nodes.map((n) => [n.id, [n.x, n.y] as Point]));
  const segs = map.edges.map((e) => ({ id: e.id, a: pos.get(e.a) as Point, b: pos.get(e.b) as Point }));
  const out: [string, string][] = [];
  for (let i = 0; i < segs.length; i++) {
    for (let j = i + 1; j < segs.length; j++) {
      const s = segs[i] as (typeof segs)[number];
      const t = segs[j] as (typeof segs)[number];
      if (segmentsCross(s.a, s.b, t.a, t.b)) out.push([s.id, t.id]);
    }
  }
  return out;
}

const connectedCount = (map: MapDef): number => {
  const adj = buildAdjacency(map);
  const seen = new Set<NodeId>([map.start]);
  const stack: NodeId[] = [map.start];
  while (stack.length) {
    const u = stack.pop() as NodeId;
    for (const v of adj.get(u)?.keys() ?? []) {
      if (!seen.has(v)) {
        seen.add(v);
        stack.push(v);
      }
    }
  }
  return seen.size;
};

/**
 * Validator V1–V9 (Bagian 8.3).
 * `pairGap` = selisih V3 pasangan VISIBLE untuk memeriksa V7 pada ronde HIDDEN.
 */
export function validateMap(map: MapDef, spec: ValidationSpec, pairGap: number | null = null): ValidationResult {
  const issues: ValidationIssue[] = [];
  const add = (code: ValidationCode, detail?: string): void => {
    issues.push(detail === undefined ? { code } : { code, detail });
  };

  // V1
  if (connectedCount(map) !== spec.nNodes || map.nodes.length !== spec.nNodes || map.edges.length !== spec.nEdges || map.stops.length !== spec.nStops) {
    add("V1");
  }

  // V9 (bagian bobot dan stop)
  if (map.edges.some((e) => !Number.isInteger(e.w) || e.w < 1 || e.w > 9)) add("V9", "bobot");
  if (map.stops.includes(map.start) || map.stops.includes(map.goal)) add("V9", "stop");

  const analysis = analyzeRoutes(map);
  if (!analysis) {
    add("V1", "tidak ada rute start→goal");
    return finish(issues, null);
  }
  const { opt, optimalRoutes, gap, best, minHops: hops, optSteps } = analysis;

  // V2, V3
  if (optimalRoutes.length !== 1) add("V2");
  if (gap === null || gap < 1 || gap > 3) add("V3");

  // V4, V5, V8
  if (spec.trap && optSteps === hops) add("V4");
  if (opt > 25 || optSteps > 6) add("V5");
  if (new Set(best.path).size !== best.path.length) add("V8");

  // V6
  if (crossingEdges(map).length > 0) add("V6", "perpotongan");
  for (let i = 0; i < map.nodes.length; i++) {
    for (let j = i + 1; j < map.nodes.length; j++) {
      const a = map.nodes[i] as (typeof map.nodes)[number];
      const b = map.nodes[j] as (typeof map.nodes)[number];
      if (Math.hypot(a.x - b.x, a.y - b.y) < 0.18) add("V6", "jarak");
    }
  }

  // V7
  if (pairGap !== null && gap !== pairGap) add("V7");

  // V9 (probe di rute optimal)
  if (spec.condition === "HIDDEN") {
    const onRoute = new Set(best.path.slice(1).map((id, i) => edgeId(best.path[i] as NodeId, id)));
    if (map.probeEdgeId === undefined || !onRoute.has(map.probeEdgeId)) add("V9", "probe");
  }

  return finish(issues, { opt, gap, route: best.path, minHops: hops, steps: optSteps });
}

function finish(issues: ValidationIssue[], info: ValidationInfo | null): ValidationResult {
  const codes = [...new Set(issues.map((i) => i.code))].sort();
  return { ok: issues.length === 0, info, issues, codes };
}

/** Validasi peta tutorial dengan daftar pengecualian eksplisit (hanya T-01 boleh gagal V3). */
export function validateTutorialMap(map: MapDef & { condition: RoundConfig["condition"]; trap: boolean }): ValidationResult {
  const result = validateMap(map, {
    nNodes: map.nodes.length,
    nEdges: map.edges.length,
    nStops: map.stops.length,
    condition: map.condition,
    trap: map.trap,
  });
  const allowed = TUTORIAL_EXCEPTIONS[map.id] ?? [];
  const issues = result.issues.filter((i) => !allowed.includes(i.code));
  return { ...result, ok: issues.length === 0, issues, codes: [...new Set(issues.map((i) => i.code))].sort() };
}

import { ROUND_CONFIGS } from "./rounds";
import { analyzeRoutes } from "./solver";
import { validateMap } from "./validator";
import type { MapDef, RoundConfig } from "./types";

export interface PoolRound {
  roundId: number;
  items: MapDef[];
}

export interface PoolDef {
  pool: string;
  seed: string;
  slots: number;
  rounds: PoolRound[];
}

/** Tanda tangan kesetaraan satu soal (Bagian 8.5). */
export interface Signature {
  gap: number;
  optSteps: number;
  minHops: number;
  trapDelta: number;
  /** Jumlah rute sederhana yang harus dibandingkan siswa. */
  simple: number;
  opt: number;
}

export function signatureOf(map: MapDef): Signature {
  const a = analyzeRoutes(map);
  if (!a || a.gap === null || a.trapDelta === null) throw new RangeError(`peta ${map.id} tidak punya tanda tangan (rute kedua/jebakan tidak ada)`);
  return { gap: a.gap, optSteps: a.optSteps, minHops: a.minHops, trapDelta: a.trapDelta, simple: a.simple, opt: a.opt };
}

/** Kunci kesetaraan: selisih, langkah optimal, minHops, dan trapDelta harus sama dalam satu ronde. */
export const signatureKey = (s: Signature): string => [s.gap, s.optSteps, s.minHops, s.trapDelta].join("|");

type ComplexityConfig = Pick<RoundConfig, "nEdges" | "nStops" | "trap">;

/** Skor Kompleksitas: jalan + 2·paket + langkah optimal + min(10, rute sederhana) + 2·jebakan + (4 − selisih). */
export function complexityScore(cfg: ComplexityConfig, s: Signature): number {
  return cfg.nEdges + 2 * cfg.nStops + s.optSteps + Math.min(10, s.simple) + 2 * Number(cfg.trap) + (4 - s.gap);
}

/** Struktur edge yang diurutkan, dipakai untuk membedakan soal dan mendeteksi soal kembar. */
export function edgeStructureKey(map: MapDef): string {
  return map.edges
    .map((e) => `${e.a}-${e.b}:${e.w}`)
    .sort()
    .join(",");
}

const rangeOf = (xs: readonly number[]): number => Math.max(...xs) - Math.min(...xs);

export interface PoolCheck {
  ok: boolean;
  issues: string[];
}

const cfgOf = (roundId: number): RoundConfig => ROUND_CONFIGS[roundId] as RoundConfig;

/**
 * Memeriksa satu bank soal: P1 (jumlah dan V1–V9), P2 (4 soal setara dan berbeda), P3 (pasangan
 * VISIBLE/HIDDEN setara), P4 (kompleksitas naik tiap pasangan ronde).
 */
export function checkPool(pool: PoolDef): PoolCheck {
  const issues: string[] = [];
  const byRound = new Map(pool.rounds.map((r) => [r.roundId, r.items]));
  let prevMax = 0;
  for (let rid = 0; rid <= 10; rid++) {
    const items = byRound.get(rid) ?? [];
    const cfg = cfgOf(rid);
    const expected = rid === 0 ? 1 : pool.slots;
    if (items.length !== expected) issues.push(`P1 ronde ${rid}: ${items.length} soal, seharusnya ${expected}`);
    if (items.length === 0) continue;

    const sigs = items.map(signatureOf);
    const pairGap = cfg.condition === "HIDDEN" ? signatureOf((byRound.get(rid - 1) as MapDef[])[0] as MapDef).gap : null;
    items.forEach((m) => {
      const v = validateMap(m, cfg, pairGap);
      if (!v.ok) issues.push(`P1 ${m.id}: gagal ${v.codes.join(",")}`);
    });

    if (rid >= 1) {
      if (new Set(sigs.map(signatureKey)).size !== 1) issues.push(`P2 ronde ${rid}: tanda tangan tidak sama`);
      if (rangeOf(sigs.map((s) => s.simple)) > 1) issues.push(`P2 ronde ${rid}: rute sederhana berselisih > 1`);
      if (rangeOf(sigs.map((s) => s.opt)) > 3) issues.push(`P2 ronde ${rid}: biaya optimal berselisih > 3`);
      if (new Set(items.map(edgeStructureKey)).size !== items.length) issues.push(`P2 ronde ${rid}: ada soal kembar`);
    }

    if (cfg.condition === "HIDDEN") {
      const visible = (byRound.get(rid - 1) as MapDef[])[0] as MapDef;
      if (signatureKey(signatureOf(visible)) !== signatureKey(sigs[0] as Signature)) issues.push(`P3 ronde ${rid}: tidak setara dengan pasangan ronde ${rid - 1}`);
    }

    if (rid >= 2 && rid % 2 === 0) {
      const scores = [
        ...(byRound.get(rid - 1) ?? []).map((m) => complexityScore(cfgOf(rid - 1), signatureOf(m))),
        ...items.map((m) => complexityScore(cfg, signatureOf(m))),
      ];
      if (Math.min(...scores) <= prevMax) issues.push(`P4 pasangan ronde ${rid - 1}-${rid}: kompleksitas tidak naik`);
      prevMax = Math.max(...scores);
    }
  }
  return { ok: issues.length === 0, issues };
}

/** Jumlah soal kembar (struktur edge sama) antara dua bank; harus 0 (P6). */
export function twinCount(a: PoolDef, b: PoolDef): number {
  const keys = new Set(a.rounds.flatMap((r) => r.items.map(edgeStructureKey)));
  return b.rounds.flatMap((r) => r.items.map(edgeStructureKey)).filter((k) => keys.has(k)).length;
}

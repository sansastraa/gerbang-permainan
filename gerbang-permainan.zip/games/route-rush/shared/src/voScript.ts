import type { IntroTimeline } from "./introTimeline";
import { COPY } from "./copy";

export interface VoLine {
  /** Nama berkas tanpa ekstensi: `assets/audio/vo/<id>.wav`. */
  id: string;
  text: string;
  /** Batas durasi rekaman (detik) agar muat di jendela adegannya. */
  maxSeconds: number;
  where: string;
}

/**
 * Daftar lengkap narasi yang harus direkam, diturunkan dari timeline dan COPY (bukan diketik ulang):
 * enam narasi trailer, satu narasi intro ringkas, dan lima kalimat tutorial yang diputar di proyektor saat tutorial dimulai.
 * Batas durasi = panjang jendela shot dikurangi 0,3 detik.
 */
export function voScript(tl: IntroTimeline): VoLine[] {
  const lines: VoLine[] = tl.trailer
    .filter((s) => s.vo)
    .map((s) => ({ id: s.id, text: s.vo as string, maxSeconds: +((s.endMs - s.startMs) / 1000 - 0.3).toFixed(1), where: `trailer ${s.id} (${s.startMs / 1000}–${s.endMs / 1000} detik)` }));
  lines.push({ id: "short", text: COPY.shortIntroVo, maxSeconds: 3, where: "trailer ringkas (awal, 3 detik pertama)" });
  COPY.tutorial.forEach((text, i) => lines.push({ id: `tutorial-${i + 1}`, text, maxSeconds: 8, where: `tutorial langkah ${i + 1} (dibacakan berurutan saat tutorial mulai)` }));
  return lines;
}
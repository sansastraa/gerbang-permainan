import { edgeId } from "./graph";
import type { Rng } from "./rng";
import { routeSkeleton } from "./solver";
import type { MapDef, MapEdge, MapNode, NodeId, PlaceKind, RoundConfig } from "./types";
import { segmentsCross, validateMap, type ValidationInfo, type ValidationSpec } from "./validator";

const MIDDLE_KINDS: readonly PlaceKind[] = ["market", "park", "mosque", "shop", "library", "clinic", "field"];

export type GeneratorSpec = ValidationSpec;

export const specOf = (c: RoundConfig): GeneratorSpec => ({ nNodes: c.nNodes, nEdges: c.nEdges, nStops: c.nStops, condition: c.condition, trap: c.trap });

type Slot = readonly [number, number]; // [kolom, baris] pada grid 3×3
type Point = readonly [number, number];

const idx = (id: NodeId): number => Number(id.slice(1));
const round3 = (v: number): number => Math.round(v * 1000) / 1000;
const uniform = (rng: Rng, lo: number, hi: number): number => lo + (hi - lo) * rng.next();

function sample<T>(rng: Rng, items: readonly T[], n: number): T[] {
  return rng.shuffle(items).slice(0, n);
}

export interface GeneratedMap {
  map: MapDef;
  info: ValidationInfo;
}

/**
 * Membuat satu peta yang lolos validator (Bagian 8.2).
 * Grid 3×3 dengan jitter, start di kolom 0 dan goal di kolom 2, spanning tree acak tanpa perpotongan,
 * lalu edge tambahan; bobot 1–9 diulang maks 200 kali per tata letak, tata letak maks 5000 kali.
 * Deterministik terhadap `rng`.
 */
export function generateMap(spec: GeneratorSpec, rng: Rng, mapId: string, pairGap: number | null = null): GeneratedMap {
  const { nNodes: nn, nEdges: ne, nStops: ns } = spec;
  for (let layout = 0; layout < 5000; layout++) {
    const slots: Slot[] = [];
    for (let c = 0; c < 3; c++) for (let r = 0; r < 3; r++) slots.push([c, r]);
    const start = rng.pick(slots.filter((s) => s[0] === 0));
    const goal = rng.pick(slots.filter((s) => s[0] === 2));
    const rest = rng.shuffle(slots.filter((s) => s !== start && s !== goal));
    const chosen: Slot[] = [start, ...rest.slice(0, nn - 2), goal];
    const ids = chosen.map((_, i) => `n${i}`);
    const kinds = rng.shuffle(MIDDLE_KINDS);
    const nodes: MapNode[] = chosen.map(([c, r], i) => ({
      id: ids[i] as string,
      kind: i === 0 ? "home" : i === nn - 1 ? "school" : (kinds[i - 1] as PlaceKind),
      x: round3(0.1 + 0.4 * c + uniform(rng, -0.04, 0.04)),
      y: round3(0.15 + 0.35 * r + uniform(rng, -0.04, 0.04)),
    }));
    const pos = new Map<NodeId, Point>(nodes.map((n) => [n.id, [n.x, n.y]]));
    const slotOf = new Map<NodeId, Slot>(ids.map((id, i) => [id, chosen[i] as Slot]));

    const pairs: [NodeId, NodeId][] = [];
    for (let i = 0; i < nn; i++) {
      for (let j = i + 1; j < nn; j++) {
        const a = slotOf.get(ids[i] as string) as Slot;
        const b = slotOf.get(ids[j] as string) as Slot;
        if (Math.max(Math.abs(a[0] - b[0]), Math.abs(a[1] - b[1])) === 1) pairs.push([ids[i] as string, ids[j] as string]);
      }
    }
    const candidates = rng.shuffle(pairs);

    // spanning tree acak (union-find) tanpa perpotongan
    const parent = new Map<NodeId, NodeId>(ids.map((id) => [id, id]));
    const find = (x: NodeId): NodeId => {
      let r = x;
      while (parent.get(r) !== r) r = parent.get(r) as NodeId;
      return r;
    };
    const chosenEdges: [NodeId, NodeId][] = [];
    const free = (a: NodeId, b: NodeId): boolean => chosenEdges.every(([c, d]) => !segmentsCross(pos.get(a) as Point, pos.get(b) as Point, pos.get(c) as Point, pos.get(d) as Point));
    for (const [a, b] of candidates) {
      if (find(a) !== find(b) && free(a, b)) {
        parent.set(find(a), find(b));
        chosenEdges.push([a, b]);
      }
    }
    if (chosenEdges.length !== nn - 1) continue;
    for (const [a, b] of candidates) {
      if (chosenEdges.length >= ne) break;
      if (!chosenEdges.some(([c, d]) => c === a && d === b) && free(a, b)) chosenEdges.push([a, b]);
    }
    if (chosenEdges.length !== ne) continue;

    const middle = ids.slice(1, -1);
    const stopTries = ns === 0 ? 1 : 8;
    for (let stopTry = 0; stopTry < stopTries; stopTry++) {
      const stops = sample(rng, middle, ns).sort((p, q) => idx(p) - idx(q));
      const ordered = chosenEdges
        .map(([a, b]) => ({ a: idx(a) <= idx(b) ? a : b, b: idx(a) <= idx(b) ? b : a }))
        .sort((p, q) => idx(p.a) - idx(q.a) || idx(p.b) - idx(q.b));
      const withWeights = (w: readonly number[]): MapEdge[] => ordered.map((e, i) => ({ id: edgeId(e.a, e.b), a: e.a, b: e.b, w: w[i] as number }));
      const skeleton = routeSkeleton({ id: mapId, nodes, edges: withWeights(ordered.map(() => 1)), start: ids[0] as string, goal: ids[nn - 1] as string, stops });
      if (!skeleton) continue;

      // Bobot diulang tanpa menghitung ulang rute: saringan cepat dulu, validator penuh hanya untuk kandidat yang lolos.
      for (let attempt = 0; attempt < 25; attempt++) {
        const weights = ordered.map(() => 1 + rng.int(9));
        const costs = skeleton.edgeIndex.map((edges) => edges.reduce((sum, e) => sum + (weights[e] as number), 0));
        const opt = Math.min(...costs);
        const best = costs.flatMap((c, i) => (c === opt ? [i] : []));
        if (best.length !== 1) continue;
        const second = Math.min(...costs.filter((c) => c > opt));
        const gap = second - opt;
        const route = skeleton.paths[best[0] as number] as NodeId[];
        const steps = route.length - 1;
        if (!Number.isFinite(gap) || gap < 1 || gap > 3) continue;
        if (opt > 25 || steps > 6 || new Set(route).size !== route.length) continue;
        if (spec.trap && steps === skeleton.minHops) continue;
        if (pairGap !== null && gap !== pairGap) continue;

        const map: MapDef = { id: mapId, nodes, edges: withWeights(weights), start: ids[0] as string, goal: ids[nn - 1] as string, stops };
        if (spec.condition === "HIDDEN") {
          map.probeEdgeId = edgeId(...(rng.pick(route.slice(1).map((id, i) => [route[i] as NodeId, id] as const)) as [NodeId, NodeId]));
        }
        const v = validateMap(map, spec, pairGap);
        if (v.ok && v.info) return { map, info: v.info };
      }
    }
  }  throw new Error(`generateMap: gagal membuat peta ${mapId} setelah 5000 tata letak`);
}

import { buildAdjacency, hasEdge, pathCost } from "./graph";
import { countRevisits, isFinished, routeSteps } from "./route";
import { minHops, optimalCost, optimalStopOrder } from "./solver";
import type { ErrorType, MapDef, NodeId } from "./types";

/** Urutan pertama kali stop dikunjungi sepanjang path. */
export function visitedStopOrder(map: MapDef, path: readonly NodeId[]): NodeId[] {
  const order: NodeId[] = [];
  for (const id of path) if (map.stops.includes(id) && !order.includes(id)) order.push(id);
  return order;
}

/**
 * Jenis kesalahan, dicek berurutan: TIMEOUT, NONE, STOP_ORDER, FEW_ROADS_TRAP, DETOUR.
 * `optimalHit` dan `optimal` dihitung pemanggil dari peta kanonik.
 */
export function classifyError(map: MapDef, path: readonly NodeId[], timedOut: boolean, optimalHit: boolean): ErrorType {
  if (timedOut) return "TIMEOUT";
  if (optimalHit) return "NONE";
  if (map.stops.length >= 2 && visitedStopOrder(map, path).join(",") !== optimalStopOrder(map).join(",")) return "STOP_ORDER";
  if (routeSteps(path) === minHops(map)) return "FEW_ROADS_TRAP";
  return "DETOUR";
}

export interface PathEvaluation {
  playerCost: number | null;
  completed: boolean;
  optimalHit: boolean;
  er: number;
  steps: number;
  revisits: number;
  errorType: ErrorType;
}

/** True bila path dimulai di start dan setiap pasangan berurutan adalah edge peta. */
export function isValidPath(map: MapDef, path: readonly NodeId[]): boolean {
  if (path[0] !== map.start) return false;
  const adj = buildAdjacency(map);
  return path.every((id, i) => i === 0 || hasEdge(adj, path[i - 1] as NodeId, id));
}

/** Metrik satu ronde dari path, dihitung sekali di server dengan peta kanonik. */
export function evaluatePath(map: MapDef, path: readonly NodeId[], timedOut: boolean): PathEvaluation {
  const valid = isValidPath(map, path);
  const playerCost = valid ? pathCost(map, path) : null;
  const completed = valid && isFinished(map, path);
  const opt = optimalCost(map);
  const optimalHit = completed && playerCost === opt;
  const er = completed && playerCost !== null ? opt / playerCost : 0;
  return {
    playerCost,
    completed,
    optimalHit,
    er,
    steps: routeSteps(path),
    revisits: countRevisits(path),
    errorType: classifyError(map, path, timedOut, optimalHit),
  };
}

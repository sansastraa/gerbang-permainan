import { createRng, hashString } from "./rng";
import type { MapDef, MapNode } from "./types";

export const VARIANT_COUNT = 8;

/** Seed pengacakan label tempat: hash(studentId + roundId + "L"). */
export const labelSeedFor = (studentId: string, roundId: number): number => hashString(`${studentId}${roundId}L`);

const round6 = (v: number): number => Math.round(v * 1e6) / 1e6;

/**
 * Varian tampilan 0..7: rotasi 0/90/180/270° terhadap pusat (0.5, 0.5), 4..7 ditambah cermin horizontal.
 * Jenis tempat selain start dan goal dipermutasi dengan `labelSeed`. Id node dan edge tidak berubah,
 * sehingga solver, probe, dan validasi server tetap memakai peta kanonik.
 */
export function applyVariant(map: MapDef, variantId: number, labelSeed: number | string): MapDef {
  if (!Number.isInteger(variantId) || variantId < 0 || variantId >= VARIANT_COUNT) throw new RangeError(`variantId ${variantId} di luar 0..7`);
  const turns = variantId % 4;
  const mirror = variantId >= 4;
  const moved: MapNode[] = map.nodes.map((n) => {
    let x = n.x - 0.5;
    let y = n.y - 0.5;
    for (let i = 0; i < turns; i++) [x, y] = [-y, x];
    if (mirror) x = -x;
    return { ...n, x: round6(x + 0.5), y: round6(y + 0.5) };
  });

  const movable = moved.filter((n) => n.id !== map.start && n.id !== map.goal);
  const kinds = createRng(labelSeed).shuffle(movable.map((n) => n.kind));
  const relabel = new Map(movable.map((n, i) => [n.id, kinds[i] as MapNode["kind"]]));
  return { ...map, nodes: moved.map((n) => ({ ...n, kind: relabel.get(n.id) ?? n.kind })) };
}

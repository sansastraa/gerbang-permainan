/** Normalisasi nama untuk pencocokan: huruf kecil, tanpa tanda baca dan aksen, spasi tunggal. */
export function normalizeName(name: string): string {
  return name
    .normalize("NFD")
    .replace(/\p{M}/gu, "")
    .toLowerCase()
    .replace(/[^\p{L}\p{N}\s]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
}

const tokens = (s: string): string[] => normalizeName(s).split(" ").filter(Boolean);

/**
 * Mencocokkan nama siswa pada daftar kelas dengan nama yang diucapkan di klip suara.
 * Urutan keputusan: (1) sama persis setelah normalisasi; (2) semua kata nama klip ada di nama siswa (atau sebaliknya),
 * dipilih klip dengan kata paling banyak. Bila beberapa klip sama baiknya (mis. "Adnan" saja), hasilnya null agar
 * tidak menyebut nama yang salah. Mengembalikan indeks pada `clipNames`, atau null.
 */
export function matchNameClip(studentName: string, clipNames: readonly string[]): number | null {
  const s = normalizeName(studentName);
  if (!s) return null;
  const exact = clipNames.map((c, i) => (normalizeName(c) === s ? i : -1)).filter((i) => i >= 0);
  if (exact.length === 1) return exact[0] as number;
  if (exact.length > 1) return null;
  const st = new Set(tokens(studentName));
  let best = 0;
  let winners: number[] = [];
  clipNames.forEach((c, i) => {
    const ct = tokens(c);
    if (ct.length === 0) return;
    const inStudent = ct.every((t) => st.has(t));
    const inClip = [...st].every((t) => ct.includes(t));
    if (!inStudent && !inClip) return;
    const score = Math.min(ct.length, st.size);
    if (score > best) {
      best = score;
      winners = [i];
    } else if (score === best) winners.push(i);
  });
  return winners.length === 1 && best >= 2 ? (winners[0] as number) : winners.length === 1 && st.size === 1 && best === 1 ? (winners[0] as number) : null;
}

/** Membaca `names.txt`: satu nama per baris berurutan sesuai klip 01, 02, …; baris kosong dan yang berawalan # diabaikan. */
export function parseNameList(text: string): string[] {
  return text
    .split(/\r?\n/)
    .map((l) => l.trim())
    .filter((l) => l && !l.startsWith("#"));
}
export type AnnounceStep = { kind: "correct" } | { kind: "wrong" } | { kind: "name"; clip: number; student: string };

/**
 * Urutan suara di proyektor saat hasil ronde: bunyi "benar" lalu nama siswa tercepat yang benar (maksimal `maxNames`, hanya yang
 * punya klip, dipilih lewat nomor absen bila ada); bila tidak ada yang benar tetapi ada yang salah, bunyi "salah". Siswa tanpa klip tidak disebut.
 */
/** Siswa yang benar: nama saja, atau nama + nomor absen (absen dipakai lebih dulu untuk memilih klip). */
export type CorrectInput = string | { name: string; absen?: number | null };

export function announcementPlan(correct: readonly CorrectInput[], wrong: number, clipNames: readonly string[], maxNames = 5, clipCount = clipNames.length): AnnounceStep[] {
  if (correct.length === 0) return wrong > 0 ? [{ kind: "wrong" }] : [];
  const steps: AnnounceStep[] = [{ kind: "correct" }];
  const used = new Set<number>();
  for (const entry of correct) {
    if (steps.length - 1 >= maxNames) break;
    const student = typeof entry === "string" ? entry : entry.name;
    const absen = typeof entry === "string" ? null : (entry.absen ?? null);
    // nomor absen = nomor klip bila ada klip untuk nomor itu; selain itu cocokkan lewat nama
    const clip = absen !== null && Number.isInteger(absen) && absen >= 1 && absen <= clipCount ? absen - 1 : matchNameClip(student, clipNames);
    if (clip === null || used.has(clip)) continue;
    used.add(clip);
    steps.push({ kind: "name", clip, student });
  }
  return steps;
}
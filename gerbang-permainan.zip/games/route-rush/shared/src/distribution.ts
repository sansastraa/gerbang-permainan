import { createRng, hashString } from "./rng";

export const SLOT_COUNT = 4;

/** Pola ubin 2×2: kursi bersebelahan (8 arah) selalu bernilai berbeda. */
export const seatBase = (row: number, col: number): number => 2 * (row % 2) + (col % 2);

/** Soal (slot 0–3) untuk sebuah kursi pada sebuah ronde. `perm` = permutasi sesi, `offset` = geser sesi (0..3). */
export function assignSlot(row: number, col: number, roundId: number, perm: readonly number[], offset: number): number {
  return ((perm[seatBase(row, col)] as number) + roundId + offset) % SLOT_COUNT;
}

/** Varian tampilan 0..7: kursi berjarak 2 yang mendapat soal sama dijamin beda putaran peta. */
export function assignVariant(row: number, col: number, roundId: number, offset2: number): number {
  return (2 * (Math.floor(row / 2) % 2) + (Math.floor(col / 2) % 2) + 4 * ((roundId + offset2) % 2)) % 8;
}

/** Mode tanpa denah: soal berdasarkan urutan masuk. */
export const assignSlotNoSeat = (joinIndex: number, roundId: number, offset: number): number => (joinIndex + roundId + offset) % SLOT_COUNT;

export const assignVariantNoSeat = (studentId: string, roundId: number): number => hashString(`${studentId}${roundId}`) % 8;

export interface DistributionParams {
  perm: number[];
  offset: number;
  offset2: number;
}

/** Parameter pembagian per sesi, deterministik dari `sessionId` (PRNG seed = sessionId). */
export function distributionParams(sessionId: string): DistributionParams {
  const rng = createRng(sessionId);
  return { perm: rng.shuffle([0, 1, 2, 3]), offset: rng.int(4), offset2: rng.int(2) };
}

import { COUNTDOWN_MS } from "./protocol";
import { effectiveRoundMaxMs, settingsRoundIds } from "./settings";
import { TUTORIAL_MS } from "./budget";
import { round2 } from "./indices";
import { kruskalWallis } from "./stats";
import type { SessionExportData } from "./export";
import type { RoundResult } from "./types";

export type CheckStatus = "LULUS" | "GAGAL" | "DATA KURANG" | "TIDAK BERLAKU";

export interface Check {
  id: string;
  name: string;
  threshold: string;
  value: string;
  status: CheckStatus;
  detail?: string;
}

export interface RoundCheck {
  roundId: number;
  n: number;
  reached: number;
  reachedPct: number;
  oh: number;
  ohPct: number;
  meanErBySlot: { slot: number; n: number; meanEr: number }[];
  slotP: number | null;
  slotSpread: number | null;
  /** Jumlah hasil pada soal paling sedikit; di bawah `LOW_POWER_N` selisih rerata ER mudah menyesatkan. */
  minSlotN: number;
  /** Kegagalan nyata (memicu GAGAL/penggantian). */
  issues: string[];
  /** Penanda untuk dipantau, tidak menggagalkan: selisih rerata ER antar soal > 0,15. */
  marks: string[];
}

export interface FlaggedItem {
  roundId: number;
  slot: number;
  itemId: string;
  meanEr: number;
  othersMeanEr: number;
  reason: string;
}

export interface FieldCheck {
  sessionId: string;
  kind: "LIVE" | "TEST";
  mode: string;
  introMode: string;
  joined: number;
  hasBots: boolean;
  plannedRounds: number[];
  checks: Check[];
  rounds: RoundCheck[];
  flaggedRounds: number[];
  flaggedItems: FlaggedItem[];
  /** Soal yang hanya bertanda selisih ER (uji p tidak gagal): dipantau, belum diganti. */
  watchItems: FlaggedItem[];
  variantMeans: { variantId: number; n: number; meanEr: number }[];
  /** True bila ada ronde teruji dengan < `lowPowerN` hasil per soal: tanda soal dari selisih ER perlu dibaca hati-hati. */
  lowPower: boolean;
  verdict: "LULUS" | "TIDAK LULUS" | "BELUM LENGKAP";
}

/** Ambang spek Fase 9. */
export const THRESHOLDS = {
  finished: 0.9,
  tutorialNoDemo: 0.85,
  tutorialStep3: 0.7,
  reached: 0.85,
  ohMin: 0.3,
  ohMax: 0.8,
  pAlpha: 0.05,
  slotSpread: 0.15,
  seated: 0.95,
  /** Di bawah ini (hasil per soal), selisih rerata ER antar soal banyak ditentukan kebetulan. */
  lowPowerN: 15,
  /** Jumlah minimum agar uji statistik bermakna. */
  minPerSlot: 5,
  minVariantTotal: 40,
} as const;

const pct = (x: number): string => `${(x * 100).toFixed(1).replace(".", ",")}%`;
const mean = (xs: readonly number[]): number => xs.reduce((a, b) => a + b, 0) / xs.length;
const fixed = (x: number, d = 2): string => x.toFixed(d).replace(".", ",");
const pval = (p: number): string => (p < 0.001 ? "< 0,001" : fixed(p, 3));

function ratioCheck(id: string, name: string, threshold: string, ok: number, total: number, min: number, detail?: string): Check {
  if (total === 0) return { id, name, threshold, value: "–", status: "DATA KURANG", detail: "belum ada data" };
  const r = ok / total;
  return { id, name, threshold, value: `${pct(r)} (${ok}/${total})`, status: r >= min ? "LULUS" : "GAGAL", ...(detail ? { detail } : {}) };
}

/** Menjalankan sepuluh pemeriksaan Fase 9 atas satu sesi. `rejected` = jumlah hasil yang gagal integritas (data/rejected). */
export function fieldCheck(d: SessionExportData, rejected: number): FieldCheck {
  const hasBots = d.players.some((p) => p.isBot);
  const ids = d.players.map((p) => p.studentId);
  const planned = d.settings ? settingsRoundIds(d.settings) : [...new Set(d.rounds.map((r) => r.roundId))].sort((a, b) => a - b);
  const scoredPlanned = planned.filter((i) => i > 0);
  const scored = d.rounds.filter((r) => r.roundId > 0);
  const played = scored.filter((r) => !r.missed);
  const checks: Check[] = [];

  // 1. menyelesaikan sesi: ada hasil tidak-missed untuk semua ronde yang direncanakan
  const finished = ids.filter((id) => scoredPlanned.length > 0 && scoredPlanned.every((rid) => scored.some((r) => r.studentId === id && r.roundId === rid && !r.missed)));
  checks.push(ratioCheck("C1", "Siswa yang menyelesaikan sesi", "≥ 90% dari yang bergabung", finished.length, ids.length, THRESHOLDS.finished, hasBots ? "termasuk pemain bot (sesi TEST)" : undefined));

  // 2-3. tutorial
  if (d.introMode === "SHORT") {
    for (const [id, name, th] of [["C2", "Siswa yang menyelesaikan tutorial tanpa demo otomatis", "≥ 85%"], ["C3", "Siswa yang lulus tutorial langkah 3 dalam ≤ 2 percobaan", "≥ 70%"]] as const)
      checks.push({ id, name, threshold: th, value: "–", status: "TIDAK BERLAKU", detail: "sesi lanjutan (intro ringkas) tidak punya tutorial" });
  } else {
    const tuts = ids.map((id) => d.tutorials.find((t) => t.result.studentId === id)?.result ?? null);
    const noDemo = tuts.filter((t) => t !== null && t.completed && t.autoDemoSteps.length === 0).length;
    checks.push(ratioCheck("C2", "Siswa yang menyelesaikan tutorial tanpa demo otomatis", "≥ 85%", noDemo, ids.length, THRESHOLDS.tutorialNoDemo));
    const step3 = tuts.filter((t) => t !== null && t.step3Attempts >= 1 && t.step3Attempts <= 2).length;
    checks.push(ratioCheck("C3", "Siswa yang lulus tutorial langkah 3 dalam ≤ 2 percobaan", "≥ 70%", step3, ids.length, THRESHOLDS.tutorialStep3, "siswa tanpa laporan langkah 3 dihitung belum lulus"));
  }

  // 4. hasil gagal integritas
  checks.push({ id: "C4", name: "Hasil gagal integritas", threshold: "0", value: String(rejected), status: rejected === 0 ? "LULUS" : "GAGAL", ...(rejected > 0 ? { detail: "lihat data/rejected/<id>.jsonl untuk alasannya" } : {}) });

  // 5-6, 9. per ronde
  const roundIds = [...new Set(played.map((r) => r.roundId))].sort((a, b) => a - b);
  const rounds: RoundCheck[] = roundIds.map((rid) => {
    const rs = played.filter((r) => r.roundId === rid);
    const reached = rs.filter((r) => r.completed && !r.timedOut).length;
    const oh = rs.filter((r) => r.optimalHit).length;
    const slots = [0, 1, 2, 3].map((slot) => ({ slot, rs: rs.filter((r) => r.itemSlot === slot) })).filter((g) => g.rs.length > 0);
    const meanErBySlot = slots.map((g) => ({ slot: g.slot, n: g.rs.length, meanEr: mean(g.rs.map((r) => r.er)) }));
    const testable = slots.length >= 2 && slots.every((g) => g.rs.length >= THRESHOLDS.minPerSlot);
    const kw = testable ? kruskalWallis(slots.map((g) => g.rs.map((r) => r.er))) : null;
    const means = meanErBySlot.map((m) => m.meanEr);
    const spread = testable ? Math.max(...means) - Math.min(...means) : null;
    const issues: string[] = [];
    if (reached / rs.length < THRESHOLDS.reached) issues.push(`hanya ${pct(reached / rs.length)} sampai sebelum waktu habis`);
    const ohRate = oh / rs.length;
    if (ohRate < THRESHOLDS.ohMin || ohRate > THRESHOLDS.ohMax) issues.push(`proporsi OH ${fixed(ohRate)} di luar 0,30–0,80`);
    if (kw && kw.p < THRESHOLDS.pAlpha) issues.push(`ER antar soal berbeda bermakna (p = ${pval(kw.p)})`);
    const marks: string[] = [];
    if (spread !== null && round2(spread) > THRESHOLDS.slotSpread) marks.push(`selisih rerata ER antar soal ${fixed(spread)} > 0,15`);
    return { roundId: rid, n: rs.length, reached, reachedPct: reached / rs.length, oh, ohPct: ohRate, meanErBySlot, slotP: kw ? kw.p : null, slotSpread: spread, minSlotN: slots.length > 0 ? Math.min(...slots.map((g) => g.rs.length)) : 0, issues, marks };
  });

  const reachFail = rounds.filter((r) => r.reachedPct < THRESHOLDS.reached);
  checks.push(
    rounds.length === 0
      ? { id: "C5", name: "Per ronde: siswa sampai sebelum waktu habis", threshold: "≥ 85% tiap ronde", value: "–", status: "DATA KURANG" }
      : { id: "C5", name: "Per ronde: siswa sampai sebelum waktu habis", threshold: "≥ 85% tiap ronde", value: `terendah ${pct(Math.min(...rounds.map((r) => r.reachedPct)))}`, status: reachFail.length === 0 ? "LULUS" : "GAGAL", ...(reachFail.length ? { detail: `ronde gagal: ${reachFail.map((r) => r.roundId).join(", ")}` } : {}) },
  );
  const ohFail = rounds.filter((r) => r.ohPct < THRESHOLDS.ohMin || r.ohPct > THRESHOLDS.ohMax);
  checks.push(
    rounds.length === 0
      ? { id: "C6", name: "Per ronde: proporsi OH", threshold: "0,30–0,80", value: "–", status: "DATA KURANG" }
      : { id: "C6", name: "Per ronde: proporsi OH", threshold: "0,30–0,80", value: `${fixed(Math.min(...rounds.map((r) => r.ohPct)))}–${fixed(Math.max(...rounds.map((r) => r.ohPct)))}`, status: ohFail.length === 0 ? "LULUS" : "GAGAL", ...(ohFail.length ? { detail: `ditandai untuk diganti: ronde ${ohFail.map((r) => r.roundId).join(", ")}` } : {}) },
  );

  // 7. durasi nyata (hitung mundur + tutorial + ronde, sampai podium)
  const budgetRounds = d.settings ? planned.reduce((a, id) => a + effectiveRoundMaxMs(id, d.settings as NonNullable<typeof d.settings>), 0) : null;
  if (d.startedAt != null && d.podiumAt != null && budgetRounds !== null) {
    const limit = COUNTDOWN_MS + (d.introMode === "FULL" ? TUTORIAL_MS : 0) + budgetRounds;
    const actual = d.podiumAt - d.startedAt;
    checks.push({ id: "C7", name: "Durasi sesi nyata (dari Mulai sampai podium)", threshold: "≤ batas S1–S4", value: `${Math.round(actual / 1000)} dtk dari batas ${Math.round(limit / 1000)} dtk`, status: actual <= limit ? "LULUS" : "GAGAL", detail: "batas = hitung mundur 3 dtk + tutorial 90 dtk (sesi perdana) + durasi maksimal ronde; lobi dan intro tidak dihitung" });
  } else checks.push({ id: "C7", name: "Durasi sesi nyata (dari Mulai sampai podium)", threshold: "≤ batas S1–S4", value: "–", status: "DATA KURANG", detail: "sesi ini tidak mencatat penanda Mulai/podium (dibuat sebelum Fase 9) atau belum sampai podium" });

  // 8. pengaruh varian peta
  const byVariant = new Map<number, number[]>();
  for (const r of played) byVariant.set(r.variantId, [...(byVariant.get(r.variantId) ?? []), r.er]);
  const variantMeans = [...byVariant.entries()].sort((a, b) => a[0] - b[0]).map(([variantId, ers]) => ({ variantId, n: ers.length, meanEr: mean(ers) }));
  const vkw = played.length >= THRESHOLDS.minVariantTotal ? kruskalWallis([...byVariant.values()]) : null;
  checks.push(
    vkw
      ? { id: "C8", name: "Pengaruh varian peta pada ER", threshold: "Kruskal-Wallis p > 0,05", value: `H = ${fixed(vkw.h)}, df ${vkw.df}, p = ${pval(vkw.p)}`, status: vkw.p > THRESHOLDS.pAlpha ? "LULUS" : "GAGAL" }
      : { id: "C8", name: "Pengaruh varian peta pada ER", threshold: "Kruskal-Wallis p > 0,05", value: `${played.length} hasil`, status: "DATA KURANG", detail: `butuh ≥ ${THRESHOLDS.minVariantTotal} hasil dan ≥ 2 varian` },
  );

  // 9. kesetaraan 4 soal per ronde
  const testableRounds = rounds.filter((r) => r.slotP !== null);
  const slotFail = testableRounds.filter((r) => (r.slotP as number) < THRESHOLDS.pAlpha);
  const slotMarked = testableRounds.filter((r) => r.marks.length > 0);
  checks.push(
    testableRounds.length === 0
      ? { id: "C9", name: "Kesetaraan 4 soal per ronde", threshold: "p > 0,05 (selisih ER > 0,15 = penanda)", value: "–", status: "DATA KURANG", detail: `butuh ≥ ${THRESHOLDS.minPerSlot} hasil pada tiap soal (≈ 20+ siswa per ronde)` }
      : { id: "C9", name: "Kesetaraan 4 soal per ronde", threshold: "p > 0,05 (selisih ER > 0,15 = penanda)", value: `${testableRounds.length - slotFail.length}/${testableRounds.length} ronde lolos${slotMarked.length ? `; ${slotMarked.length} ronde bertanda selisih ER` : ""}`, status: slotFail.length === 0 ? "LULUS" : "GAGAL", ...(slotFail.length || slotMarked.length ? { detail: `${slotFail.length ? `ronde gagal (p < 0,05): ${slotFail.map((r) => r.roundId).join(", ")}. ` : ""}${slotMarked.length ? `ronde bertanda selisih rerata ER > 0,15 (hanya penanda, dipantau): ${slotMarked.map((r) => r.roundId).join(", ")}` : ""}`.trim() } : {}) },
  );

  const flaggedItems: FlaggedItem[] = [];
  for (const r of slotFail) {
    const rs = played.filter((x) => x.roundId === r.roundId);
    const dev = r.meanErBySlot.map((m) => {
      const others = rs.filter((x) => x.itemSlot !== m.slot).map((x) => x.er);
      return { m, others: mean(others), diff: Math.abs(m.meanEr - mean(others)) };
    });
    const worst = dev.sort((a, b) => b.diff - a.diff)[0];
    if (worst) {
      const item = rs.find((x) => x.itemSlot === worst.m.slot) as RoundResult;
      flaggedItems.push({ roundId: r.roundId, slot: worst.m.slot, itemId: item.itemId, meanEr: worst.m.meanEr, othersMeanEr: worst.others, reason: r.issues.filter((i) => i.includes("soal")).join("; ") });
    }
  }

  const watchItems = watch(played, slotMarked.filter((r) => !slotFail.includes(r)));

  // 10. denah kursi
  const withResults = ids.filter((id) => d.rounds.some((r) => r.studentId === id));
  const seated = withResults.filter((id) => d.rounds.find((r) => r.studentId === id)?.seatMode === "SEATED").length;
  checks.push(ratioCheck("C10", "Siswa dengan denah kursi", "≥ 95%", seated, withResults.length, THRESHOLDS.seated, "mode tanpa denah hanya cadangan"));

  const flaggedRounds = rounds.filter((r) => r.issues.length > 0).map((r) => r.roundId);
  const verdict: FieldCheck["verdict"] = checks.some((c) => c.status === "GAGAL") ? "TIDAK LULUS" : checks.some((c) => c.status === "DATA KURANG") ? "BELUM LENGKAP" : "LULUS";
  return { sessionId: d.sessionId, kind: d.kind, mode: d.mode, introMode: d.introMode, joined: ids.length, hasBots, plannedRounds: planned, checks, rounds, flaggedRounds, flaggedItems, watchItems, variantMeans, lowPower: testableRounds.some((r) => r.minSlotN < THRESHOLDS.lowPowerN), verdict };
}

/** Soal dengan rerata ER paling menyimpang dari tiga lainnya pada ronde yang hanya bertanda selisih ER. */
function watch(played: readonly RoundResult[], marked: readonly RoundCheck[]): FlaggedItem[] {
  const out: FlaggedItem[] = [];
  for (const r of marked) {
    const rs = played.filter((x) => x.roundId === r.roundId);
    const dev = r.meanErBySlot.map((m) => {
      const others = mean(rs.filter((x) => x.itemSlot !== m.slot).map((x) => x.er));
      return { m, others, diff: Math.abs(m.meanEr - others) };
    });
    const worst = dev.sort((a, b) => b.diff - a.diff)[0];
    if (worst) out.push({ roundId: r.roundId, slot: worst.m.slot, itemId: (rs.find((x) => x.itemSlot === worst.m.slot) as RoundResult).itemId, meanEr: worst.m.meanEr, othersMeanEr: worst.others, reason: r.marks.join("; ") });
  }
  return out;
}

export function fieldCheckMarkdown(fc: FieldCheck): string {
  const icon = (s: CheckStatus): string => (s === "LULUS" ? "✅ LULUS" : s === "GAGAL" ? "❌ GAGAL" : s === "TIDAK BERLAKU" ? "➖ tidak berlaku" : "⚠️ data kurang");
  const lines: string[] = [
    `# Pemeriksaan lapangan — sesi ${fc.sessionId}`,
    "",
    `**Hasil: ${fc.verdict}** · jenis ${fc.kind} · ${fc.mode === "STANDARD" ? "Standar" : "Kilat"} · ${fc.introMode === "FULL" ? "sesi perdana (intro penuh + tutorial)" : "sesi lanjutan (intro ringkas)"} · ${fc.joined} siswa bergabung · ronde direncanakan: ${fc.plannedRounds.join(", ")}`,
    "",
  ];
  if (fc.kind === "TEST" || fc.hasBots) lines.push("> **Perhatian:** sesi ini berisi data TEST/bot. Angka di bawah hanya untuk mencoba skrip, bukan bukti uji lapangan.", "");
  lines.push("## Ringkasan 10 pemeriksaan", "", "| # | Pemeriksaan | Ambang | Nilai | Status |", "|---|---|---|---|---|");
  for (const c of fc.checks) lines.push(`| ${c.id} | ${c.name} | ${c.threshold} | ${c.value} | ${icon(c.status)} |`);
  const notes = fc.checks.filter((c) => c.detail);
  if (notes.length) lines.push("", "Catatan:", ...notes.map((c) => `- **${c.id}**: ${c.detail}`));

  lines.push("", "## Per ronde", "", "| Ronde | n | Sampai | Proporsi OH | Rerata ER per soal (slot 0–3) | p antar soal | Selisih ER | Masalah | Penanda |", "|---|---|---|---|---|---|---|---|---|");
  for (const r of fc.rounds) {
    const slots = [0, 1, 2, 3].map((s) => r.meanErBySlot.find((m) => m.slot === s)).map((m) => (m ? `${fixed(m.meanEr)} (n=${m.n})` : "–")).join(" · ");
    lines.push(`| ${r.roundId} | ${r.n} | ${pct(r.reachedPct)} | ${fixed(r.ohPct)} | ${slots} | ${r.slotP === null ? "–" : pval(r.slotP)} | ${r.slotSpread === null ? "–" : fixed(r.slotSpread)} | ${r.issues.length ? r.issues.join("; ") : "–"} | ${r.marks.length ? r.marks.join("; ") : "–"} |`);
  }
  lines.push("", "## Varian peta", "", "| variantId | n | Rerata ER |", "|---|---|---|", ...fc.variantMeans.map((v) => `| ${v.variantId} | ${v.n} | ${fixed(v.meanEr)} |`));

  lines.push("", "## Tindak lanjut", "");
  if (fc.flaggedRounds.length === 0 && fc.checks.every((c) => c.status !== "GAGAL")) lines.push("Tidak ada ronde atau soal yang perlu diganti berdasarkan sesi ini.");
  else {
    if (fc.flaggedRounds.length) lines.push(`- Ronde ditandai: **${fc.flaggedRounds.join(", ")}** (lihat kolom Masalah). Proporsi OH di luar 0,30–0,80 berarti ronde terlalu mudah/sulit: ganti dengan soal baru dari generator yang lolos syarat 8.5 (Pool C, D, …); Pool A dan B asli disimpan sebagai arsip.`);
    for (const f of fc.flaggedItems) lines.push(`- Soal **${f.itemId}** (ronde ${f.roundId}, slot ${f.slot}): rerata ER ${fixed(f.meanEr)} vs ${fixed(f.othersMeanEr)} pada tiga soal lain → ganti dengan soal baru yang lolos 8.5.`);
    if (fc.checks.some((c) => (c.id === "C2" || c.id === "C3") && c.status === "GAGAL")) lines.push("- Tutorial belum memenuhi ambang: perbaiki langkah yang gagal lalu uji ulang di kelas.");
  }
  if (fc.watchItems.length > 0) {
    lines.push("", "### Dipantau (penanda saja, belum diganti)", "", "Selisih rerata ER antar soal > 0,15 tetapi uji Kruskal-Wallis tidak gagal. Ini hanya penanda; soal diganti bila uji p gagal atau penanda yang sama muncul lagi setelah beberapa kelas digabung.", "");
    for (const f of fc.watchItems) lines.push(`- Soal **${f.itemId}** (ronde ${f.roundId}, slot ${f.slot}): rerata ER ${fixed(f.meanEr)} vs ${fixed(f.othersMeanEr)} pada tiga soal lain.`);
  }
  if (fc.lowPower) lines.push("", `> **Sampel kecil:** pada kelas ini tiap soal hanya dikerjakan ±${Math.min(...fc.rounds.filter((r) => r.slotP !== null).map((r) => r.minSlotN))} siswa. Selisih rerata ER ≥ 0,15 sering muncul karena kebetulan walau keempat soal setara (simulasi 30 bot dengan soal setara menandai 10 dari 10 ronde), karena itu selisih hanya penanda dan tidak menggagalkan pemeriksaan. Gabungkan beberapa kelas/sesi (≥ ${THRESHOLDS.lowPowerN} hasil per soal) sebelum mengganti soal.`);
  lines.push("", "_Dihasilkan oleh `npm run field-check`. Pemeriksaan statistik (C8, C9) membutuhkan sampel kelas penuh; pada kelas kecil statusnya \"data kurang\" dan bukan kegagalan._", "");
  return lines.join("\n");
}

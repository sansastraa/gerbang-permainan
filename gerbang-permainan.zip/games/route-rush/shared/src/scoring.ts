import { createRng } from "./rng";

/** Pembulatan ke bilangan bulat terdekat; 0.5 ke atas. */
export const roundHalfUp = (x: number): number => Math.floor(x + 0.5);

export interface RacePointsInput {
  optimalHit: boolean;
  completed: boolean;
  er: number;
  /** Waktu rute (detik) dan batas waktu ronde (detik). */
  tSec: number;
  limitSec: number;
}

/** Q = 1 (optimal), 0.5·ER (selesai tetapi tidak optimal), 0 (tidak selesai); poin = round(1000·Q·(1 − 0.5·t/T)). */
export function racePoints({ optimalHit, completed, er, tSec, limitSec }: RacePointsInput): number {
  const q = optimalHit ? 1 : completed ? 0.5 * er : 0;
  return roundHalfUp(1000 * q * (1 - (0.5 * tSec) / limitSec));
}

/** Bonus beruntun per ronde: min(300, 100·(streak − 1)) bila optimal, selain itu 0 dan memutus beruntun. */
export function streakBonuses(hits: readonly boolean[]): number[] {
  let streak = 0;
  return hits.map((hit) => {
    streak = hit ? streak + 1 : 0;
    return hit ? Math.min(300, 100 * (streak - 1)) : 0;
  });
}

export const PROBE_LIMIT_SEC = 5;

/** Poin soal ingatan: round(200·(1 − 0.5·tProbe/5)) bila benar. */
export function probePoints(correct: boolean | null, tProbeSec: number): number {
  return correct ? roundHalfUp(200 * (1 - (0.5 * tProbeSec) / PROBE_LIMIT_SEC)) : 0;
}

/** Tiga opsi probe: jawaban benar + 2 pengecoh berbeda (benar ± 1..3) dalam 1..9, urutan diacak dari `seed`. */
export function probeOptions(correct: number, seed: string): [number, number, number] {
  const rng = createRng(seed);
  const decoys = [-3, -2, -1, 1, 2, 3].map((d) => correct + d).filter((v) => v >= 1 && v <= 9);
  const chosen = rng.shuffle(decoys).slice(0, 2);
  return rng.shuffle([correct, ...chosen]) as [number, number, number];
}

export interface PointParts {
  racePoints: number;
  streakBonus: number;
  probePoints: number;
}

export const totalPoints = (rounds: readonly PointParts[]): number =>
  rounds.reduce((sum, r) => sum + r.racePoints + r.streakBonus + r.probePoints, 0);

import type { IntroTimeline, Shot } from "./introTimeline";
import type { IntroMode } from "./types";

/** Nama efek suara (berkas `assets/audio/sfx/<nama>.wav`). */
export type SfxName =
  | "hum"
  | "coin"
  | "pop"
  | "whoosh"
  | "click"
  | "wrong"
  | "right"
  | "heartbeat"
  | "title"
  | "logo"
  | "scooter"
  | "city"
  | "kick";

export const SFX_NAMES: readonly SfxName[] = ["hum", "coin", "pop", "whoosh", "click", "wrong", "right", "heartbeat", "title", "logo", "scooter", "city", "kick"];

export interface Cue {
  /** Waktu mulai (ms) sejak awal fase (ident atau trailer). */
  ms: number;
  sfx: SfxName;
  /** Pengali penguatan relatif (0..1), mis. gema sonic logo lebih pelan. */
  gain: number;
  /** Nada relatif (rasio kecepatan putar), 1 = asli. */
  rate: number;
}

export interface IntroAudioPlan {
  cues: Cue[];
  /** Bagian musik yang diputar (ms dari awal berkas musik) dan lamanya mengikuti fase; null = tanpa musik (ident). */
  music: { fromMs: number; durationMs: number } | null;
  /** Jendela musik diturunkan 8 dB karena ada narasi (ms sejak awal fase). */
  duck: { fromMs: number; toMs: number }[];
  /** Pengali penguatan musik per jendela (mis. musik turun pada shot-06); 1 di luar jendela. */
  dips: { fromMs: number; toMs: number; gain: number }[];
}

const c = (ms: number, sfx: SfxName, gain = 1, rate = 1): Cue => ({ ms: Math.round(ms), sfx, gain, rate });

const shot = (tl: IntroTimeline, id: string): Shot => tl.trailer.find((s) => s.id === id) as Shot;

/**
 * Jadwal suara intro, diturunkan dari timeline (waktu shot) dan jumlah jalan pada peta trailer.
 * Penanda 0,38/0,07/0,05/… mengikuti kemajuan adegan di `client/src/intro/scenes.tsx`.
 */
export function introAudioPlan(tl: IntroTimeline, kind: "IDENT" | "TRAILER", mode: IntroMode, edgeCount: number): IntroAudioPlan {
  if (kind === "IDENT") {
    const full: Cue[] = [
      c(0, "hum"),
      ...[0, 1, 2, 3, 4].map((i) => c(1000 + i * 260, "coin", 0.8, 1 + i * 0.12)),
      c(2500, "whoosh", 0.7),
      c(4000, "logo"),
      c(5500, "logo", 0.35, 0.5),
    ];
    if (mode === "FULL") return { cues: full, music: null, duck: [], dips: [] };
    const { fromMs, toMs } = tl.identShort;
    return { cues: full.filter((x) => x.ms >= fromMs && x.ms < toMs).map((x) => ({ ...x, ms: x.ms - fromMs })), music: null, duck: [], dips: [] };
  }
  const s3 = shot(tl, "shot-03");
  const s4 = shot(tl, "shot-04");
  const s5 = shot(tl, "shot-05");
  const s6 = shot(tl, "shot-06");
  const s8 = shot(tl, "shot-08");
  const s9 = shot(tl, "shot-09");
  const s10 = shot(tl, "shot-10");
  const at = (s: Shot, p: number): number => s.startMs + p * (s.endMs - s.startMs);
  const badges = Array.from({ length: edgeCount }, (_, i) => c(at(s4, 0.38 + i * 0.07 + 0.05), "coin", 0.7, 0.9 + (i % 4) * 0.1));
  const full: Cue[] = [
    c(0, "city"),
    c(at(s3, 0.05), "scooter", 0.8),
    c(at(s3, 0.7), "click"),
    ...badges,
    c(at(s5, 0.4), "wrong"),
    c(at(s5, 0.85), "right"),
    c(at(s6, 0.1), "heartbeat"),
    c(at(s6, 0.5), "heartbeat", 0.8),
    c(at(s8, 0.05), "title"),
    ...[0, 1, 2].map((i) => c(at(s9, i * 0.25), "kick")),
    c(at(s10, 0.1), "whoosh", 0.9),
  ];
  const duckShots = tl.trailer.filter((s) => s.vo).map((s) => ({ fromMs: s.startMs, toMs: s.endMs }));
  const dips = [{ fromMs: s6.startMs, toMs: s6.endMs, gain: 0.5 }];
  if (mode === "FULL") return { cues: full, music: { fromMs: 0, durationMs: s10.endMs }, duck: duckShots, dips };
  // ringkas: tiga potongan 4 detik (shot-04, 05, 08) berurutan, musik dari bagian drum (detik 28)
  const parts = tl.trailerShort;
  const cues: Cue[] = [];
  for (const part of parts) {
    const src = shot(tl, part.fromShot);
    const scale = (part.endMs - part.startMs) / (src.endMs - src.startMs);
    for (const q of full) if (q.ms >= src.startMs && q.ms < src.endMs) cues.push({ ...q, ms: Math.round(part.startMs + (q.ms - src.startMs) * scale) });
  }
  const total = (parts[parts.length - 1] as { endMs: number }).endMs;
  return { cues, music: { fromMs: 28_000, durationMs: total }, duck: [{ fromMs: 0, toMs: 3000 }], dips: [] };
}

/** Penguatan musik (linear) pada waktu `ms`: turun 8 dB saat narasi, dan jendela dip. Transisi 200 ms. */
export function musicGainAt(plan: IntroAudioPlan, ms: number): number {
  const ramp = 200;
  let g = 1;
  for (const d of plan.duck) {
    const w = Math.max(0, Math.min(1, Math.min((ms - d.fromMs) / ramp, (d.toMs - ms) / ramp)));
    g *= 1 - w * (1 - DUCK_GAIN);
  }
  for (const d of plan.dips) {
    const w = Math.max(0, Math.min(1, Math.min((ms - d.fromMs) / ramp, (d.toMs - ms) / ramp)));
    g *= 1 - w * (1 - d.gain);
  }
  return g;
}

/** −8 dB */
export const DUCK_GAIN = 10 ** (-8 / 20);


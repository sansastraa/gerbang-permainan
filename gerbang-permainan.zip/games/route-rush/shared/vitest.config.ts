import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    include: ["test/**/*.test.ts"],
    // beberapa uji menjalankan skrip lewat tsx (proses anak); 5 dtk bawaan terlalu sempit saat mesin sibuk
    testTimeout: 30000,
    coverage: {
      provider: "v8",
      include: ["src/**/*.ts"],
      exclude: ["src/types.ts", "src/index.ts"],
      reporter: ["text-summary", "text"],
      thresholds: { lines: 95, branches: 90 },
    },
  },
});

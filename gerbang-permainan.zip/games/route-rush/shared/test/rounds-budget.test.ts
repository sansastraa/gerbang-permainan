import { describe, expect, it } from "vitest";
import { INTRO_MS, LOBBY_MS, PODIUM_MS, TUTORIAL_MS, sessionBudget } from "../src/budget";
import {
  QUICK_ROUND_IDS,
  ROUND_CONFIGS,
  STANDARD_ROUND_IDS,
  displayIndex,
  getRoundConfig,
  roundIdsFor,
  roundMaxDurationMs,
  roundsMaxDurationMs,
} from "../src/rounds";

describe("konfigurasi ronde (Bagian 4)", () => {
  it("11 ronde; ronde 0 latihan tidak scored; parameter sesuai tabel", () => {
    expect(ROUND_CONFIGS).toHaveLength(11);
    expect(getRoundConfig(0).scored).toBe(false);
    expect(ROUND_CONFIGS.filter((c) => c.roundId > 0).every((c) => c.scored)).toBe(true);
    expect(getRoundConfig(5)).toMatchObject({ condition: "VISIBLE", nNodes: 6, nEdges: 8, nStops: 0, trap: true, lookMs: 6000, walkMs: 25000 });
    expect(getRoundConfig(10)).toMatchObject({ condition: "HIDDEN", nNodes: 7, nEdges: 9, nStops: 2, trap: false, lookMs: 7000, walkMs: 35000 });
    expect(ROUND_CONFIGS.filter((c) => c.roundId % 2 === 0 && c.roundId > 0).every((c) => c.condition === "HIDDEN")).toBe(true);
    expect(() => getRoundConfig(11)).toThrow(RangeError);
  });

  it("T23 durasi ronde maksimal: Standar 443 s, Kilat 263 s", () => {
    expect(roundsMaxDurationMs(STANDARD_ROUND_IDS) / 1000).toBe(443);
    expect(roundsMaxDurationMs(QUICK_ROUND_IDS) / 1000).toBe(263);
    expect(roundMaxDurationMs(getRoundConfig(0)) / 1000).toBe(28);
  });

  it("Mode Kilat = ronde 0, 1, 2, 3, 4, 7, 8 dengan nomor tampil berurutan 1–6", () => {
    expect(QUICK_ROUND_IDS).toEqual([0, 1, 2, 3, 4, 7, 8]);
    expect([1, 2, 3, 4, 7, 8].map((id) => displayIndex("QUICK", id))).toEqual([1, 2, 3, 4, 5, 6]);
    expect(displayIndex("QUICK", 0)).toBe(0);
    expect(displayIndex("STANDARD", 9)).toBe(9);
  });

  it("sesi perdana (FULL) melewati ronde 0; lanjutan memainkannya", () => {
    expect(roundIdsFor("STANDARD", "FULL")).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(roundIdsFor("QUICK", "FULL")).toEqual([1, 2, 3, 4, 7, 8]);
    expect(roundIdsFor("STANDARD", "SHORT")).toHaveLength(11);
    expect(roundIdsFor("QUICK", "SHORT")).toEqual([0, 1, 2, 3, 4, 7, 8]);
  });
});

describe("anggaran waktu sesi (S1–S4)", () => {
  it("S1 perdana Standar = 608 s", () => expect(sessionBudget("STANDARD", "FULL").totalMs / 1000).toBe(608));
  it("S2 perdana Kilat = 428 s", () => expect(sessionBudget("QUICK", "FULL").totalMs / 1000).toBe(428));
  it("S3 lanjutan Standar = 508 s", () => expect(sessionBudget("STANDARD", "SHORT").totalMs / 1000).toBe(508));
  it("S4 lanjutan Kilat = 328 s", () => expect(sessionBudget("QUICK", "SHORT").totalMs / 1000).toBe(328));

  it("rincian komponen: lobi 30 s, podium 20 s, tutorial 90 s hanya di FULL, intro 53 s / 15 s", () => {
    const full = sessionBudget("STANDARD", "FULL");
    expect([full.lobbyMs, full.podiumMs, full.tutorialMs, full.introMs, full.roundsMs]).toEqual([LOBBY_MS, PODIUM_MS, TUTORIAL_MS, 53_000, 415_000]);
    const short = sessionBudget("STANDARD", "SHORT");
    expect([short.tutorialMs, short.introMs]).toEqual([0, 15_000]);
    expect(INTRO_MS.SHORT.ident + INTRO_MS.SHORT.trailer).toBe(15_000);
  });
});

import { describe, expect, it } from "vitest";
import {
  BOM,
  NOTE,
  TUTORIAL_NOTE,
  buildReport,
  csvCell,
  integrityNote,
  itemsCsv,
  parseCsv,
  parseRoundsCsv,
  reportHtml,
  reportNotes,
  roundsCsv,
  round1,
  round2,
  studentsCsv,
  summarizeStudent,
  toCsv,
  tutorialCsv,
  withBom,
  type RoundResult,
  type SessionExportData,
  type TutorialResult,
} from "../src";

let seq = 0;
function round(studentId: string, roundId: number, over: Partial<RoundResult> = {}): RoundResult {
  const hit = over.optimalHit ?? true;
  seq++;
  return {
    sessionId: "S1", studentId, nickname: studentId === "s1" ? 'Ani "Si Cepat", Lestari' : `Siswa ${studentId}`, form: "A", mode: "STANDARD", roundId,
    condition: roundId % 2 === 0 ? "HIDDEN" : "VISIBLE", variantId: 3, itemId: `PA-0${roundId}-${seq % 4}`, itemSlot: (seq % 4) as 0 | 1 | 2 | 3, seatMode: "SEATED", seatRow: 1, seatCol: 2,
    focusLost: 0, fullscreenExits: 0, integrityFlags: [], nNodes: 6, nEdges: 8, nStops: 0, timeLimitS: 25, optimalCost: 8, playerCost: hit ? 8 : 10, playerPath: ["n0", "n2", "n3", "n5"],
    completed: true, optimalHit: hit, timedOut: false, missed: false, er: hit ? 1 : 0.8, tFirstMs: 900, tRouteMs: 4000 + seq * 137, invalidTaps: seq % 3 === 0 ? 1 : 0, undo: seq % 4 === 0 ? 1 : 0, revisits: 0,
    steps: 3, probeCorrect: roundId % 2 === 0 ? seq % 2 === 0 : null, probeMs: roundId % 2 === 0 ? 2100 : null, racePoints: hit ? 300 : 150, streakBonus: 0, probePoints: 0, rankAfter: 1,
    errorType: hit ? "NONE" : "DETOUR", tapLog: [{ tMs: 900, nodeId: "n2", valid: true }, { tMs: 1500, nodeId: "UNDO", valid: true }], ...over,
  };
}

const tut = (id: string, over: Partial<TutorialResult> = {}): TutorialResult => ({
  sessionId: "S1", studentId: id, completed: true, totalMs: 61_000, step3Attempts: 1, hints: 1, probeCorrect: true, autoDemoSteps: [],
  steps: [1, 2, 3, 4, 5].map((step) => ({ step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 9000 })), ...over,
});

function data(): SessionExportData {
  seq = 0;
  const rounds: RoundResult[] = [];
  for (const id of ["s1", "s2", "s3"]) for (let r = 1; r <= 4; r++) rounds.push(round(id, r, { optimalHit: !(id === "s3" && r % 2 === 1), focusLost: id === "s2" && (r === 2 || r === 4) ? 1 : 0, integrityFlags: id === "s2" && (r === 2 || r === 4) ? ["FOCUS_LOST"] : [] }));
  rounds.push(round("s1", 0, { racePoints: 0 })); // ronde latihan tidak dihitung
  return {
    sessionId: "S1", kind: "TEST", form: "A", mode: "STANDARD", introMode: "FULL", createdAt: null,
    players: [{ studentId: "s1", name: 'Ani "Si Cepat", Lestari', isBot: true }, { studentId: "s2", name: "Budi", isBot: true }, { studentId: "s3", name: "Citra", isBot: true }],
    rounds, tutorials: [{ isBot: true, result: tut("s1") }, { isBot: true, result: tut("s2", { completed: false, autoDemoSteps: [4, 5] }) }, { isBot: true, result: tut("s3", { step3Attempts: 3 }) }],
    integrityEvents: [{ studentId: "s3", flag: "SEAT_CHANGED" }],
  };
}

describe("CSV", () => {
  it("sel yang memuat koma, kutip, dan baris baru dikutip dan dapat dibaca kembali", () => {
    expect(csvCell('a,"b"\nc')).toBe('"a,""b""\nc"');
    expect(csvCell(null)).toBe("");
    expect(csvCell(false)).toBe("false");
    const csv = toCsv(["x", "y"], [['a,"b"\nc', 1], ["", null]]);
    expect(parseCsv(csv)).toEqual([["x", "y"], ['a,"b"\nc', "1"], ["", ""]]);
  });
  it("BOM UTF-8 ditambahkan sekali; akhir baris CRLF", () => {
    const csv = withBom(toCsv(["a"], [["é"]]));
    expect(csv.startsWith(BOM)).toBe(true);
    expect(withBom(csv)).toBe(csv);
    expect(csv).toContain("\r\n");
    expect(parseCsv(csv)[0]).toEqual(["a"]);
  });
});

describe("rounds.csv", () => {
  it("kolom snake_case, tap_log sebagai JSON, dan dapat dibaca kembali menjadi RoundResult yang sama", () => {
    const d = data();
    const csv = roundsCsv(d);
    const head = parseCsv(csv)[0] as string[];
    expect(head.slice(0, 4)).toEqual(["game", "kind", "session_id", "student_id"]);
    for (const col of ["item_id", "item_slot", "seat_mode", "seat_row", "seat_col", "focus_lost", "fullscreen_exits", "integrity_flags", "tap_log"]) expect(head).toContain(col);
    expect(parseCsv(csv)[1]?.[head.indexOf("game")]).toBe("ROUTE_RUSH");
    expect(parseCsv(csv)[1]?.[head.indexOf("kind")]).toBe("TEST");
    expect(parseRoundsCsv(csv)).toEqual(d.rounds);
  });
});

describe("T26: students.csv identik dengan hitung ulang dari rounds.csv", () => {
  it("semua indeks, kuadran, poin, dan jumlah ronde cocok untuk tiap siswa", () => {
    const d = data();
    const report = buildReport(d);
    const students = parseCsv(studentsCsv(report));
    const head = students[0] as string[];
    const rows = students.slice(1);
    expect(rows).toHaveLength(3);
    // hitung ulang HANYA dari rounds.csv yang diekspor
    const again = parseRoundsCsv(roundsCsv(d));
    const medians = buildReport({ ...d, rounds: again }).medians;
    expect(medians).not.toBeNull();
    for (const row of rows) {
      const col = (n: string): string => row[head.indexOf(n)] as string;
      const s = summarizeStudent(col("student_id"), again.filter((r) => r.studentId === col("student_id")));
      const f1 = (v: number | null): string => (v === null ? "" : String(round1(v)));
      const f2 = (v: number | null): string => (v === null ? "" : String(round2(v)));
      expect(col("IL")).toBe(f1(s.il));
      expect(col("IM")).toBe(f1(s.im));
      expect(col("IS")).toBe(f1(s.is));
      expect(col("memory_cost")).toBe(f2(s.memoryCost));
      expect(col("RTM")).toBe(f2(s.rtm));
      expect(col("median_correct_t_s")).toBe(f2(s.medianCorrectT));
      expect(col("timeout_rate")).toBe(String(round2(s.timeoutRate)));
      expect(col("mean_er")).toBe(f2(s.meanEr));
      expect(col("total_points")).toBe(String(s.totalPoints));
      expect(col("rounds_played")).toBe(String(s.roundsPlayed));
      expect(col("rounds_missed")).toBe(String(s.roundsMissed));
    }
    expect(head).toEqual(expect.arrayContaining(["student_id", "nickname", "form", "mode", "intro_mode", "quadrant", "tut_completed", "tut_total_ms", "tut_step3_attempts", "tut_hints", "tut_probe_correct", "seat_row", "seat_col", "integrity_flag_count", "integrity_flags_summary"]));
  });

  it("ronde latihan tidak dihitung dan nama dengan koma/kutip tetap utuh", () => {
    const rows = parseCsv(studentsCsv(buildReport(data())));
    const head = rows[0] as string[];
    const ani = rows.find((r) => r[head.indexOf("student_id")] === "s1") as string[];
    expect(ani[head.indexOf("nickname")]).toBe('Ani "Si Cepat", Lestari');
    expect(ani[head.indexOf("rounds_played")]).toBe("4");
  });

  it("ringkasan integritas: jumlah dan jenis flag per siswa", () => {
    const rows = parseCsv(studentsCsv(buildReport(data())));
    const head = rows[0] as string[];
    const get = (id: string, c: string): string => (rows.find((r) => r[head.indexOf("student_id")] === id) as string[])[head.indexOf(c)] as string;
    expect(get("s2", "integrity_flag_count")).toBe("2");
    expect(get("s2", "integrity_flags_summary")).toBe("FOCUS_LOSTx2");
    expect(get("s3", "integrity_flags_summary")).toBe("SEAT_CHANGEDx1");
    expect(get("s1", "integrity_flag_count")).toBe("0");
  });
});

describe("tutorial.csv dan items.csv", () => {
  it("tutorial.csv: satu baris per siswa per langkah, langkah demo otomatis ditandai", () => {
    const rows = parseCsv(tutorialCsv(data()));
    expect(rows).toHaveLength(1 + 15);
    const head = rows[0] as string[];
    const s2 = rows.filter((r) => r[head.indexOf("student_id")] === "s2");
    expect(s2.filter((r) => r[head.indexOf("auto_demo")] === "true").map((r) => r[head.indexOf("step")])).toEqual(["4", "5"]);
    expect(rows[1]?.[head.indexOf("is_bot")]).toBe("true");
  });
  it("items.csv: rekap per soal, ronde missed tidak dihitung", () => {
    const d = data();
    d.rounds.push(round("s3", 1, { missed: true, optimalHit: false, itemId: "PA-01-9", itemSlot: 3 }));
    const rows = parseCsv(itemsCsv(d));
    expect(rows[0]).toEqual(["game", "kind", "session_id", "round_id", "item_id", "slot", "n_siswa", "mean_er", "prop_optimal", "median_t_s"]);
    expect(rows.some((r) => r[4] === "PA-01-9")).toBe(false);
    const total = rows.slice(1).reduce((a, r) => a + Number(r[6]), 0);
    expect(total).toBe(d.rounds.filter((r) => !r.missed).length);
  });
});

describe("catatan otomatis kartu laporan", () => {
  const base = summarizeStudent("s1", [round("s1", 1), round("s1", 2), round("s1", 3), round("s1", 4)]);
  it("baik dan konsisten bila tidak ada catatan lain", () => {
    expect(reportNotes(base, tut("s1"))).toEqual([NOTE.allGood]);
    expect(reportNotes(base, null)).toEqual([NOTE.allGood]);
  });
  it("catatan tutorial: ≥ 3 percobaan langkah 3, dan tutorial tidak selesai", () => {
    expect(reportNotes(base, tut("s1", { step3Attempts: 3 }))).toEqual([TUTORIAL_NOTE.step3]);
    expect(reportNotes(base, tut("s1", { completed: false }))).toEqual([TUTORIAL_NOTE.incomplete]);
    expect(reportNotes(base, tut("s1", { step3Attempts: 4, completed: false }))).toEqual([TUTORIAL_NOTE.step3, TUTORIAL_NOTE.incomplete]);
  });
  it("catatan ronde lebih dulu, total maksimal 3", () => {
    const bad = { ...base, trapRounds: 2, stopOrderRounds: 1, memoryCost: 0.3, rti: 0.4, timeoutRate: 0.5 };
    const notes = reportNotes(bad, tut("s1", { step3Attempts: 5, completed: false }));
    expect(notes).toEqual([NOTE.fewRoadsTrap, NOTE.stopOrder, NOTE.memoryDrop]);
    const two = reportNotes({ ...base, trapRounds: 2, stopOrderRounds: 0 }, tut("s1", { step3Attempts: 5, completed: false }));
    expect(two).toEqual([NOTE.fewRoadsTrap, TUTORIAL_NOTE.step3, TUTORIAL_NOTE.incomplete]);
  });
  it("catatan integritas: kalimat guru seperti di spek, tanpa kejadian = null", () => {
    const rs = [round("s1", 4, { focusLost: 1 }), round("s1", 7, { focusLost: 1 })];
    expect(integrityNote(rs, [])).toBe("Catatan integritas: keluar aplikasi 2 kali saat ronde 4 dan 7.");
    expect(integrityNote([round("s1", 1)], [])).toBeNull();
    expect(integrityNote([round("s1", 1, { integrityFlags: ["TOO_FAST"] }), round("s1", 2, { fullscreenExits: 2 })], [{ flag: "SECOND_DEVICE" }, { flag: "SEAT_CHANGED" }])).toBe(
      "Catatan integritas: keluar layar penuh 2 kali saat ronde 2; rute selesai sangat cepat pada ronde 1; nama dicoba dibuka dari perangkat lain; kursi dikosongkan guru setelah ronde dimulai.",
    );
  });
});

describe("report.html", () => {
  const html = reportHtml(buildReport(data()));
  it("kartu per siswa, 2 kartu per halaman, A4, memuat IL/IM/IS dengan kategori, RTM, kuadran, dan catatan integritas", () => {
    expect((html.match(/<article class="card">/g) ?? []).length).toBe(3);
    expect((html.match(/<section class="page">/g) ?? []).length).toBe(2);
    expect(html).toContain("@page { size: A4");
    for (const t of ["Indeks Logika (IL)", "Indeks Memori (IM)", "Indeks Spasial (IS)", "Rute hemat per menit (RTM)", "Waktu tepat median", "Biaya memori", "Catatan integritas: keluar aplikasi 2 kali saat ronde 2 dan 4."]) expect(html).toContain(t);
    expect(html).toContain("Ani &quot;Si Cepat&quot;, Lestari");
  });
  it("tidak mencantumkan poin balapan atau peringkat", () => {
    expect(html).not.toMatch(/poin|peringkat|rank|racePoints|race_points|total_points/i);
  });
  it("sesi kosong → keadaan kosong yang jujur", () => {
    const empty = reportHtml(buildReport({ ...data(), players: [], rounds: [], tutorials: [], integrityEvents: [] }));
    expect(empty).toContain("Belum ada data sesi");
    expect(empty).not.toContain('<article class="card">');
  });
});
import { describe, expect, it } from "vitest";
import { PROBE_LIMIT_SEC, probeOptions, probePoints, racePoints, roundHalfUp, streakBonuses, totalPoints } from "../src/scoring";

const T = 25;

describe("poin balapan (Bagian 9)", () => {
  it("T5 Ani: optimal, t = 12 s → 760", () => expect(racePoints({ optimalHit: true, completed: true, er: 1, tSec: 12, limitSec: T })).toBe(760));
  it("T6b Budi: ER 8/9, t = 6 s → 391", () => expect(racePoints({ optimalHit: false, completed: true, er: 8 / 9, tSec: 6, limitSec: T })).toBe(391));
  it("T7 Citra: optimal, t = 24 s → 520", () => expect(racePoints({ optimalHit: true, completed: true, er: 1, tSec: 24, limitSec: T })).toBe(520));
  it("T8 Dodi: timeout → 0", () => expect(racePoints({ optimalHit: false, completed: false, er: 0, tSec: 25, limitSec: T })).toBe(0));
  it("T9 optimal lambat (500) mengalahkan tidak optimal ER 0.99 cepat (495)", () => {
    const slowOptimal = racePoints({ optimalHit: true, completed: true, er: 1, tSec: 25, limitSec: T });
    const fastWrong = racePoints({ optimalHit: false, completed: true, er: 0.99, tSec: 0, limitSec: T });
    expect([slowOptimal, fastWrong]).toEqual([500, 495]);
    expect(slowOptimal).toBeGreaterThan(fastWrong);
  });
  it("roundHalfUp membulatkan 0.5 ke atas", () => {
    expect([roundHalfUp(0.5), roundHalfUp(1.5), roundHalfUp(2.49), roundHalfUp(-0.4)]).toEqual([1, 2, 2, 0]);
  });
});

describe("bonus beruntun", () => {
  it("T10 lima ronde optimal → [0,100,200,300,300]", () => expect(streakBonuses([true, true, true, true, true])).toEqual([0, 100, 200, 300, 300]));
  it("T10b beruntun putus → [0,100,0,0,100]", () => expect(streakBonuses([true, true, false, true, true])).toEqual([0, 100, 0, 0, 100]));
  it("daftar kosong menghasilkan daftar kosong", () => expect(streakBonuses([])).toEqual([]));
});

describe("soal ingatan", () => {
  it("T11 benar dalam 2 s → 160; salah → 0; tidak menjawab (null) → 0", () => {
    expect(probePoints(true, 2)).toBe(160);
    expect(probePoints(false, 1)).toBe(0);
    expect(probePoints(null, 0)).toBe(0);
    expect(probePoints(true, PROBE_LIMIT_SEC)).toBe(100);
  });

  it("probeOptions: 3 opsi berbeda dalam 1..9, memuat jawaban benar, deterministik per seed", () => {
    for (let correct = 1; correct <= 9; correct++) {
      const options = probeOptions(correct, `siswa-${correct}`);
      expect(options).toHaveLength(3);
      expect(new Set(options).size).toBe(3);
      expect(options).toContain(correct);
      expect(options.every((o) => o >= 1 && o <= 9 && Math.abs(o - correct) <= 3)).toBe(true);
      expect(probeOptions(correct, `siswa-${correct}`)).toEqual(options);
    }
  });

  it("urutan opsi berbeda antar-pemain (seed berbeda)", () => {
    const orders = new Set(Array.from({ length: 12 }, (_, i) => probeOptions(5, `pemain-${i}`).join(",")));
    expect(orders.size).toBeGreaterThan(1);
  });
});

describe("totalPoints", () => {
  it("menjumlahkan poin balapan, bonus, dan probe semua ronde", () => {
    expect(totalPoints([])).toBe(0);
    expect(
      totalPoints([
        { racePoints: 760, streakBonus: 0, probePoints: 0 },
        { racePoints: 500, streakBonus: 100, probePoints: 160 },
      ]),
    ).toBe(1520);
  });
});

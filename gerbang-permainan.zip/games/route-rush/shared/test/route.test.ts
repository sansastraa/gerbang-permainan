import { describe, expect, it } from "vitest";
import {
  countRevisits,
  createRoute,
  currentNode,
  firstValidTapMs,
  isFinished,
  packagesIncomplete,
  routeCost,
  routeSteps,
  tapNode,
  undoLast,
  type RouteState,
} from "../src/route";
import type { MapDef, NodeId } from "../src/types";
import { FIXTURE, TUTORIAL_MAPS, mapById } from "./helpers";

const play = (map: MapDef, nodes: NodeId[]): RouteState =>
  nodes.reduce((state, n, i) => tapNode(map, state, n, (i + 1) * 500), createRoute(map));

describe("aturan interaksi rute (Bagian 5)", () => {
  it("T16 ketuk node yang tidak bertetangga → tidak valid, path tetap", () => {
    const s = tapNode(FIXTURE, createRoute(FIXTURE), "n3", 300);
    expect(s.invalidTaps).toBe(1);
    expect(s.path).toEqual(["n0"]);
    expect(s.tapLog).toEqual([{ tMs: 300, nodeId: "n3", valid: false }]);
  });

  it("T17 n0 → n1 → n0: revisits 1, steps 2, biaya 4", () => {
    const s = play(FIXTURE, ["n1", "n0"]);
    expect(s.revisits).toBe(1);
    expect(routeSteps(s.path)).toBe(2);
    expect(routeCost(FIXTURE, s.path)).toBe(4);
  });

  it("T18 Batal dua kali: path kembali ke [n0], undo = 1", () => {
    let s = play(FIXTURE, ["n1"]);
    s = undoLast(FIXTURE, s, 900);
    s = undoLast(FIXTURE, s, 1000);
    expect(s.path).toEqual(["n0"]);
    expect(s.undo).toBe(1);
    expect(s.tapLog.filter((t) => t.nodeId === "UNDO")).toHaveLength(1);
  });

  it("T18b ketuk posisi sendiri diabaikan dan tidak dicatat", () => {
    const s = tapNode(FIXTURE, createRoute(FIXTURE), "n0", 100);
    expect(s.invalidTaps).toBe(0);
    expect(s.path).toEqual(["n0"]);
    expect(s.tapLog).toEqual([]);
  });

  it("ketukan di luar fase WALK diabaikan dan tidak dicatat", () => {
    const s = tapNode(FIXTURE, createRoute(FIXTURE), "n1", 100, false);
    expect(s).toEqual(createRoute(FIXTURE));
    expect(undoLast(FIXTURE, play(FIXTURE, ["n1"]), 200, false).undo).toBe(0);
  });

  it("selesai otomatis di goal dan setelah itu ketukan/Batal diabaikan", () => {
    const s = play(FIXTURE, ["n1", "n2", "n3", "n5"]);
    expect(s.done).toBe(true);
    expect(tapNode(FIXTURE, s, "n3", 9000)).toBe(s);
    expect(undoLast(FIXTURE, s, 9000)).toBe(s);
    expect(currentNode(s)).toBe("n5");
  });

  it("melewati goal sebelum paket lengkap boleh lanjut, ditandai 'paket belum lengkap'", () => {
    const a09 = mapById("A-09"); // goal n6, stop n2 dan n5
    let s = play(a09, ["n4", "n6"]);
    expect(currentNode(s)).toBe(a09.goal);
    expect(s.done).toBe(false);
    expect(packagesIncomplete(a09, s)).toBe(true);
    s = tapNode(a09, s, "n5", 1500); // tetap boleh lanjut berjalan
    expect(s.path).toEqual(["n0", "n4", "n6", "n5"]);
    expect(packagesIncomplete(a09, s)).toBe(false);
  });

  it("collected = stops ∩ path dan Batal melepas paket", () => {
    const a09 = mapById("A-09");
    let s = play(a09, ["n5", "n2"]);
    expect(s.collected.has("n2")).toBe(true);
    s = undoLast(a09, s, 2000);
    expect(s.collected.has("n2")).toBe(false);
  });

  it("Batal pada kunjungan ulang menurunkan revisits sehingga selalu sama dengan hitung ulang dari path", () => {
    let s = play(FIXTURE, ["n1", "n0"]);
    expect(s.revisits).toBe(1);
    s = undoLast(FIXTURE, s, 3000);
    expect(s.revisits).toBe(0);
    expect(countRevisits(s.path)).toBe(0);
  });

  it("firstValidTapMs mengabaikan ketukan tidak valid dan UNDO", () => {
    expect(firstValidTapMs([])).toBeNull();
    expect(
      firstValidTapMs([
        { tMs: 100, nodeId: "n3", valid: false },
        { tMs: 400, nodeId: "n1", valid: true },
      ]),
    ).toBe(400);
  });

  it("isFinished membutuhkan goal dan semua stop", () => {
    expect(isFinished(FIXTURE, ["n0", "n1", "n2", "n3", "n5"])).toBe(true);
    expect(isFinished(FIXTURE, ["n0", "n1"])).toBe(false);
  });
});

describe("tutorial pada route state (I6–I8)", () => {
  const [, t02, t03, , t05] = TUTORIAL_MAPS as [MapDef, MapDef, MapDef, MapDef, MapDef];

  it("I6 T-02: mengetuk Sekolah dari Rumah tidak valid", () => {
    const s = tapNode(t02, createRoute(t02), "n3", 200);
    expect(s.invalidTaps).toBe(1);
    expect(s.path).toEqual(["n0"]);
  });

  it("I7 T-05: jalan pintas n0→n2→n4 tidak selesai (biaya 2); n0→n1→n3→n4 selesai (biaya 6)", () => {
    const shortcut = play(t05, ["n2", "n4"]);
    expect(shortcut.done).toBe(false);
    expect(routeCost(t05, shortcut.path)).toBe(2);
    const right = play(t05, ["n1", "n3", "n4"]);
    expect(right.done).toBe(true);
    expect(routeCost(t05, right.path)).toBe(6);
  });

  it("I8 T-03: n0→n3→n4 berbiaya 9, bukan optimal (7)", () => {
    const s = play(t03, ["n3", "n4"]);
    expect(routeCost(t03, s.path)).toBe(9);
    expect(routeCost(t03, s.path)).not.toBe(7);
    expect(routeSteps(s.path)).toBe(2);
  });
});

import { describe, expect, it } from "vitest";
import { COUNTDOWN_MS } from "../src/protocol";
import { allRoundIdsAvailable, defaultSettings, effectiveRoundConfig, effectiveRoundMaxMs, mergeSettings, settingsRoundIds, SETTING_LIMITS } from "../src/settings";
import { roundsMaxDurationMs } from "../src/rounds";

const base = defaultSettings(25);
const merge = (patch: unknown, size = 25) => mergeSettings(base, patch, size);

describe("pengaturan sesi (menu guru)", () => {
  it("bawaan: Standar, FULL, Pool A, kuota = jumlah siswa, waktu per ronde bawaan", () => {
    expect(base).toMatchObject({ mode: "STANDARD", introMode: "FULL", pool: "A", lookSeconds: null, walkSeconds: null, probeSeconds: 5, roundIds: null, quota: 25, kind: "LIVE" });
    expect(defaultSettings(0).quota).toBe(1);
    expect(COUNTDOWN_MS).toBe(3000);
  });

  it("menerima semua nilai sah dan menggabungkannya tanpa mengubah pengaturan lama", () => {
    const r = merge({
      mode: "QUICK",
      introMode: "SHORT",
      pool: "B",
      kind: "TEST",
      lookSeconds: 12,
      walkSeconds: 40,
      probeSeconds: 4,
      quota: 20,
      roundIds: [3, 1, 2],
      seatLayout: { rows: 4, cols: 6, aisleAfterCols: [3], enabled: false },
    });
    expect(r.ok).toBe(true);
    if (r.ok) {
      expect(r.settings).toMatchObject({ mode: "QUICK", introMode: "SHORT", pool: "B", kind: "TEST", lookSeconds: 12, walkSeconds: 40, probeSeconds: 4, quota: 20, roundIds: [1, 2, 3] });
      expect(r.settings.seatLayout).toEqual({ rows: 4, cols: 6, aisleAfterCols: [3], enabled: false });
    }
    expect(base.mode).toBe("STANDARD");
    expect(base.seatLayout.rows).toBe(5);
  });

  it("null mengembalikan waktu bawaan ronde; roundIds null mengikuti mode", () => {
    const withTimes = merge({ lookSeconds: 10, walkSeconds: 30, roundIds: [1] });
    expect(withTimes.ok && mergeSettings(withTimes.settings, { lookSeconds: null, walkSeconds: null, roundIds: null }, 25)).toMatchObject({ ok: true, settings: { lookSeconds: null, walkSeconds: null, roundIds: null } });
  });

  it("menolak nilai di luar batas dengan pesan per kolom (tidak ada yang berubah)", () => {
    const bad: unknown[] = [
      { mode: "LAIN" },
      { introMode: 1 },
      { pool: "C" },
      { kind: "X" },
      { lookSeconds: SETTING_LIMITS.lookSeconds.min - 1 },
      { lookSeconds: SETTING_LIMITS.lookSeconds.max + 1 },
      { lookSeconds: "5" },
      { walkSeconds: 9 },
      { probeSeconds: null },
      { probeSeconds: 181 },
      { probeSeconds: 2 },
      { hiddenRounds: [0] },
      { hiddenRounds: [1, 1] },
      { resultSeconds: 2 },
      { resultSeconds: 21 },
      { resultSeconds: null },
      { quota: 0 },
      { quota: 26 },
      { quota: 2.5 },
      { roundIds: [] },
      { roundIds: [1, 1] },
      { roundIds: [11] },
      { roundIds: "semua" },
      { seatLayout: "x" },
      { seatLayout: { rows: 0 } },
      { seatLayout: { cols: 11 } },
      { seatLayout: { aisleAfterCols: ["a"] } },
    ];
    for (const patch of bad) {
      const r = merge(patch);
      expect(r.ok, JSON.stringify(patch)).toBe(false);
      if (!r.ok) expect(r.errors.length).toBeGreaterThan(0);
    }
    expect(mergeSettings(base, null, 25)).toMatchObject({ ok: false });
    expect(mergeSettings(base, [], 25)).toMatchObject({ ok: false });
  });

  it("kuota tidak boleh melebihi jumlah siswa pada daftar", () => {
    expect(mergeSettings({ ...base, quota: 25 }, {}, 10)).toMatchObject({ ok: false });
    expect(mergeSettings(defaultSettings(10), { quota: 10 }, 10)).toMatchObject({ ok: true });
  });

  it("daftar ronde: mengikuti mode, ronde 0 dibuang pada sesi perdana, dan dapat dikustomisasi", () => {
    expect(settingsRoundIds(base)).toEqual([1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    expect(settingsRoundIds({ ...base, introMode: "SHORT" })).toHaveLength(11);
    expect(settingsRoundIds({ ...base, mode: "QUICK" })).toEqual([1, 2, 3, 4, 7, 8]);
    expect(settingsRoundIds({ ...base, roundIds: [0, 5, 9] })).toEqual([5, 9]);
    expect(settingsRoundIds({ ...base, introMode: "SHORT", roundIds: [0, 5, 9] })).toEqual([0, 5, 9]);
    expect(allRoundIdsAvailable()).toHaveLength(11);
  });

  it("waktu menghafal dan berjalan menimpa bawaan; durasi ronde ikut menyesuaikan", () => {
    expect(effectiveRoundConfig(5, base)).toMatchObject({ lookMs: 6000, walkMs: 25000 });
    const custom = { ...base, lookSeconds: 12.5, walkSeconds: 40, probeSeconds: 4 };
    expect(effectiveRoundConfig(5, custom)).toMatchObject({ lookMs: 12_500, walkMs: 40_000, trap: true, condition: "VISIBLE" });
    expect(effectiveRoundMaxMs(6, base) / 1000).toBe(6 + 25 + 5 + 3 + 3);
    expect(effectiveRoundMaxMs(6, custom) / 1000).toBe(12.5 + 40 + 4 + 3 + 3);
    expect(effectiveRoundMaxMs(0, custom) / 1000).toBe(12.5 + 40 + 3);
    expect(effectiveRoundMaxMs(6, { ...base, resultSeconds: 12 }) / 1000).toBe(6 + 25 + 5 + 12 + 3);
    expect(base.resultSeconds).toBe(3);
    const all = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
    expect(all.reduce((a, id) => a + effectiveRoundMaxMs(id, base), 0)).toBe(roundsMaxDurationMs(all));
  });
});

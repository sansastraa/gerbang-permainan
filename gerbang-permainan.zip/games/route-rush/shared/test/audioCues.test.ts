import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { DUCK_GAIN, SFX_NAMES, introAudioPlan, musicGainAt, parseTimeline } from "../src";

const tl = parseTimeline(JSON.parse(readFileSync(resolve(__dirname, "../intro/timeline.json"), "utf8")));
const EDGES = 8; // jumlah jalan A-05 (dihitung dari peta pada pemakaian nyata)

describe("jadwal suara intro (dari timeline)", () => {
  it("ident penuh: dengung, 5 denting koin, desir, sonic logo + gema; tanpa musik", () => {
    const p = introAudioPlan(tl, "IDENT", "FULL", EDGES);
    expect(p.music).toBeNull();
    expect(p.cues.filter((c) => c.sfx === "coin")).toHaveLength(5);
    expect(p.cues.filter((c) => c.sfx === "logo").map((c) => c.ms)).toEqual([4000, 5500]);
    for (const c of p.cues) expect(c.ms).toBeLessThan(8000);
  });

  it("ident ringkas hanya memuat potongan 4000–7000 ms, digeser ke 0", () => {
    const p = introAudioPlan(tl, "IDENT", "SHORT", EDGES);
    expect(p.cues.map((c) => c.sfx)).toEqual(["logo", "logo"]);
    expect(p.cues.map((c) => c.ms)).toEqual([0, 1500]);
  });

  it("trailer penuh: denting koin sebanyak jalan, nada salah sebelum benar, musik 45 detik, jendela narasi dari shot ber-VO", () => {
    const p = introAudioPlan(tl, "TRAILER", "FULL", EDGES);
    expect(p.music).toEqual({ fromMs: 0, durationMs: 45_000 });
    expect(p.cues.filter((c) => c.sfx === "coin")).toHaveLength(EDGES);
    const wrong = p.cues.find((c) => c.sfx === "wrong")!.ms;
    const right = p.cues.find((c) => c.sfx === "right")!.ms;
    expect(wrong).toBeLessThan(right);
    expect(wrong).toBeGreaterThanOrEqual(18_000);
    expect(right).toBeLessThan(23_000);
    expect(p.duck).toHaveLength(tl.trailer.filter((s) => s.vo).length);
    for (const c of p.cues) expect(c.ms).toBeLessThan(45_000);
    for (const n of new Set(p.cues.map((c) => c.sfx))) expect(SFX_NAMES).toContain(n);
  });

  it("trailer ringkas: 12 detik, musik dari detik 28, efek dari shot-04/05/08 diskalakan ke 4 detik", () => {
    const p = introAudioPlan(tl, "TRAILER", "SHORT", EDGES);
    expect(p.music).toEqual({ fromMs: 28_000, durationMs: 12_000 });
    for (const c of p.cues) expect(c.ms).toBeLessThan(12_000);
    expect(p.cues.some((c) => c.sfx === "wrong" && c.ms >= 4000 && c.ms < 8000)).toBe(true);
    expect(p.cues.some((c) => c.sfx === "title" && c.ms >= 8000)).toBe(true);
  });

  it("musik turun 8 dB saat narasi dan turun di shot-06; kembali normal di luar jendela", () => {
    const p = introAudioPlan(tl, "TRAILER", "FULL", EDGES);
    expect(DUCK_GAIN).toBeCloseTo(0.398, 3);
    expect(musicGainAt(p, 11_000)).toBeCloseTo(DUCK_GAIN, 3); // shot-03 (VO)
    expect(musicGainAt(p, 5_000)).toBe(1); // shot-02 tanpa VO
    expect(musicGainAt(p, 25_500)).toBeLessThan(DUCK_GAIN); // shot-06: narasi + dip 0,5
    expect(musicGainAt(p, 9_000)).toBeGreaterThan(DUCK_GAIN); // awal shot-03: transisi 200 ms
  });
});
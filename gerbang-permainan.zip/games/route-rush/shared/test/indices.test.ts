import { describe, expect, it } from "vitest";
import {
  autoNotes,
  categoryOf,
  classMedians,
  indexLogic,
  indexMemory,
  indexSpatial,
  invalidTapRatio,
  mean,
  median,
  quadrantOf,
  round1,
  round2,
  rtm,
  summarizeStudent,
  type StudentSummary,
} from "../src/indices";
import { NOTE } from "../src/copy";
import { optimalRoute } from "../src/solver";
import { FIXTURE, buildResult } from "./helpers";

describe("indeks individu (Bagian 10)", () => {
  const erV = [1, 1, 0.89, 1, 0.8];
  const ohV = [true, true, false, true, false];

  it("T12 IL = 80.3", () => expect(round1(indexLogic(erV, ohV) as number)).toBe(80.3));

  it("T13 IM = 79.3 dan memoryCost = 0.200", () => {
    const m = indexMemory(erV, [1, 0.8, 0.89, 0, 1], 0.8);
    expect(round1(m!.im)).toBe(79.3);
    expect(m!.memoryCost.toFixed(3)).toBe("0.200");
  });

  it("T14 IS = 92.8; semua nol → null", () => {
    expect(round1(indexSpatial({ ti: 3, l: 40, u: 2, ku: 1 }) as number)).toBe(92.8);
    expect(indexSpatial({ ti: 0, l: 0, u: 0, ku: 0 })).toBeNull();
    expect(invalidTapRatio({ ti: 0, l: 0, u: 0, ku: 0 })).toBe(0);
  });

  it("T15 RTM = 2.0; total waktu 0 → null", () => {
    expect(rtm(6, 180)).toBe(2);
    expect(rtm(0, 0)).toBeNull();
  });

  it("indeks null bila kelompok ronde kosong; ratio memakai mean(ER_H) bila mean(ER_V) = 0", () => {
    expect(indexLogic([], [])).toBeNull();
    expect(indexMemory([], [1], 1)).toBeNull();
    expect(indexMemory([1], [], 1)).toBeNull();
    expect(indexMemory([0, 0], [0.5], 0)!.im).toBeCloseTo(25, 12);
  });

  it("median, mean, dan pembulatan tampilan", () => {
    expect(median([3, 1, 2])).toBe(2);
    expect(median([4, 1, 2, 3])).toBe(2.5);
    expect(mean([1, 2, 3])).toBe(2);
    expect(round2(0.8889)).toBe(0.89);
  });

  it("kategori indeks mengikuti ambang 85 / 70 / 55", () => {
    expect([categoryOf(100), categoryOf(85), categoryOf(84.99), categoryOf(70), categoryOf(69.99), categoryOf(55), categoryOf(54.99), categoryOf(null)]).toEqual([
      "Sangat baik",
      "Sangat baik",
      "Baik",
      "Baik",
      "Cukup",
      "Cukup",
      "Perlu pendampingan",
      null,
    ]);
  });
});

describe("ringkasan siswa dari hasil ronde", () => {
  const best = optimalRoute(FIXTURE);
  const trap = ["n0", "n2", "n3", "n5"];
  const win = (roundId: number, condition: "VISIBLE" | "HIDDEN", t: number, correct = true) =>
    buildResult(FIXTURE, { path: best, tRouteMs: t * 1000, timeLimitS: 25, roundId, condition, probeCorrect: condition === "HIDDEN" ? correct : null, probeMs: condition === "HIDDEN" ? 2000 : null });
  const lose = (roundId: number, condition: "VISIBLE" | "HIDDEN") =>
    buildResult(FIXTURE, { path: trap, tRouteMs: 10_000, timeLimitS: 25, roundId, condition, probeCorrect: condition === "HIDDEN" ? false : null, probeMs: condition === "HIDDEN" ? 3000 : null });

  it("menghitung indeks hanya dari ronde scored dan tidak missed", () => {
    const results = [
      win(0, "VISIBLE", 5), // latihan: diabaikan
      win(1, "VISIBLE", 10),
      lose(2, "HIDDEN"),
      buildResult(FIXTURE, { path: [], tRouteMs: 0, timeLimitS: 25, roundId: 3, condition: "VISIBLE", missed: true }),
      win(4, "HIDDEN", 20),
    ];
    const s = summarizeStudent("s1", results);
    expect(s.roundsPlayed).toBe(3);
    expect(s.roundsMissed).toBe(1);
    expect(s.il).toBe(100); // hanya ronde 1 VISIBLE: ER 1, optimal
    expect(s.im).not.toBeNull();
    expect(s.rtm).toBeCloseTo(2 / ((10 + 10 + 20) / 60), 9);
    expect(s.medianCorrectT).toBe(15);
    expect(s.meanEr).toBeCloseTo((1 + 8 / 9 + 1) / 3, 12);
    expect(s.timeoutRate).toBe(0);
    expect(s.trapRounds).toBe(1);
    expect(s.totalPoints).toBeGreaterThan(0);
  });

  it("tanpa ronde sama sekali: semua indeks null", () => {
    const s = summarizeStudent("kosong", []);
    expect([s.il, s.im, s.is, s.rtm, s.meanEr, s.medianT, s.medianCorrectT, s.memoryCost]).toEqual([null, null, null, null, null, null, null, null]);
    expect(s.timeoutRate).toBe(0);
    expect(quadrantOf(s, { meanEr: 0.5, medianT: 10 })).toBeNull();
  });

  it("siswa tanpa ronde HIDDEN tidak punya IM", () => {
    expect(summarizeStudent("v", [win(1, "VISIBLE", 8)]).im).toBeNull();
  });

  it("kuadran profil memakai median kelas", () => {
    const base = summarizeStudent("a", [win(1, "VISIBLE", 5)]);
    const make = (id: string, meanEr: number, medianT: number): StudentSummary => ({ ...base, studentId: id, meanEr, medianT });
    const cls = [make("a", 1, 5), make("b", 0.7, 5), make("c", 1, 20), make("d", 0.7, 20)];
    const medians = classMedians(cls)!;
    expect(medians).toEqual({ meanEr: 0.85, medianT: 12.5 });
    expect(cls.map((s) => quadrantOf(s, medians))).toEqual(["MAHIR", "TERBURU", "TELITI", "DAMPINGI"]);
    expect(classMedians([summarizeStudent("x", [])])).toBeNull();
  });

  it("catatan otomatis: urutan tetap, maksimal 3, dan kalimat default", () => {
    const base = summarizeStudent("a", [win(1, "VISIBLE", 5)]);
    expect(autoNotes(base)).toEqual([NOTE.allGood]);
    const heavy: StudentSummary = { ...base, trapRounds: 2, stopOrderRounds: 1, memoryCost: 0.2, rti: 0.3, timeoutRate: 0.5 };
    expect(autoNotes(heavy)).toEqual([NOTE.fewRoadsTrap, NOTE.stopOrder, NOTE.memoryDrop]);
    expect(autoNotes({ ...base, rti: 0.2 })).toEqual([NOTE.invalidTaps]);
    expect(autoNotes({ ...base, timeoutRate: 0.3 })).toEqual([NOTE.manyTimeouts]);
  });
});

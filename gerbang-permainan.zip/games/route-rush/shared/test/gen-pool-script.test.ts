import { spawn } from "node:child_process";
import { mkdtempSync, readFileSync, rmSync } from "node:fs";
import { createRequire } from "node:module";
import { tmpdir } from "node:os";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { parsePool } from "../src/dataLoaders";
import { checkPool } from "../src/equivalence";

const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");
const tsx = createRequire(import.meta.url).resolve("tsx/cli");
const run = (...args: string[]): Promise<{ status: number | null; stderr: string; stdout: string }> =>
  new Promise((done, fail) => {
    const child = spawn(process.execPath, [tsx, join(ROOT, "scripts/gen-pool.ts"), ...args], { cwd: ROOT });
    let stdout = "";
    let stderr = "";
    child.stdout.on("data", (d: Buffer) => (stdout += d.toString("utf8")));
    child.stderr.on("data", (d: Buffer) => (stderr += d.toString("utf8")));
    child.on("error", fail);
    child.on("close", (status) => done({ status, stdout, stderr }));
  });

describe("scripts/gen-pool.ts membuat bank baru", () => {
  it(
    "menulis berkas ke folder sementara yang lolos pemeriksaan, lalu menolak menimpanya",
    async () => {
      const dir = mkdtempSync(join(tmpdir(), "rr-pool-"));
      try {
        const out = join(dir, "poolX.json");
        const r = await run("--seed", "RR-POOL-X", "--out", out);
        expect(r.status, r.stderr).toBe(0);
        expect(checkPool(parsePool(JSON.parse(readFileSync(out, "utf8")))).ok).toBe(true);
        const again = await run("--seed", "RR-POOL-X", "--out", out);
        expect(again.status).toBe(1);
        expect(again.stderr).toContain("sudah ada");
      } finally {
        rmSync(dir, { recursive: true, force: true });
      }
    },
    300_000,
  );
});
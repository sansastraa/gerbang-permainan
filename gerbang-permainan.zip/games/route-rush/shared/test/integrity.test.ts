import { describe, expect, it } from "vitest";
import { IntegrityError, assertRoundIntegrity, assertTutorialIntegrity } from "../src/integrity";
import { optimalRoute } from "../src/solver";
import type { RoundResult, TutorialResult } from "../src/types";
import { FIXTURE, buildResult } from "./helpers";

const best = optimalRoute(FIXTURE);
const good = (): RoundResult => buildResult(FIXTURE, { path: best, tRouteMs: 12_000, timeLimitS: 25 });
const mutate = (patch: Partial<RoundResult>): RoundResult => ({ ...good(), ...patch });
const rejects = (r: RoundResult): string[] => {
  try {
    assertRoundIntegrity(r, FIXTURE);
  } catch (e) {
    expect(e).toBeInstanceOf(IntegrityError);
    return (e as IntegrityError).issues;
  }
  return [];
};

describe("assertRoundIntegrity", () => {
  it("menerima hasil yang konsisten (optimal, jebakan, timeout, kunjungan ulang, Batal)", () => {
    expect(() => assertRoundIntegrity(good(), FIXTURE)).not.toThrow();
    expect(() => assertRoundIntegrity(buildResult(FIXTURE, { path: ["n0", "n2", "n3", "n5"], tRouteMs: 6000, timeLimitS: 25 }), FIXTURE)).not.toThrow();
    expect(() => assertRoundIntegrity(buildResult(FIXTURE, { path: ["n0", "n1"], tRouteMs: 25_000, timeLimitS: 25, timedOut: true }), FIXTURE)).not.toThrow();
    const withNoise = buildResult(FIXTURE, {
      path: best,
      tRouteMs: 9000,
      timeLimitS: 25,
      tapLog: [
        { tMs: 300, nodeId: "n3", valid: false },
        { tMs: 700, nodeId: "n1", valid: true },
        { tMs: 900, nodeId: "UNDO", valid: true },
        { tMs: 1200, nodeId: "n1", valid: true },
        { tMs: 1500, nodeId: "n2", valid: true },
        { tMs: 1800, nodeId: "n3", valid: true },
        { tMs: 2100, nodeId: "n5", valid: true },
      ],
    });
    expect(() => assertRoundIntegrity(withNoise, FIXTURE)).not.toThrow();
  });

  it("T25 playerCost dimanipulasi +1 → melempar error", () => {
    const tampered = mutate({ playerCost: (good().playerCost as number) + 1 });
    expect(() => assertRoundIntegrity(tampered, FIXTURE)).toThrow(IntegrityError);
    expect(rejects(tampered)[0]).toContain("playerCost");
  });

  it("menolak path yang tidak dimulai di start atau melewati edge yang tidak ada", () => {
    expect(rejects(mutate({ playerPath: ["n1", "n2"], playerCost: null }))).toContain("playerPath bukan rangkaian edge valid dari start");
    expect(rejects(mutate({ playerPath: ["n0", "n5"], playerCost: null })).length).toBeGreaterThan(0);
  });

  it("menolak completed, er, optimalHit, errorType, dan poin yang dimanipulasi", () => {
    expect(rejects(mutate({ completed: false }))).toContain("completed tidak cocok dengan path");
    expect(rejects(mutate({ er: 0.5 }))).toContain("er tidak cocok");
    expect(rejects(mutate({ optimalHit: false }))).toContain("optimalHit tidak cocok");
    expect(rejects(mutate({ errorType: "DETOUR" })).some((m) => m.startsWith("errorType"))).toBe(true);
    expect(rejects(mutate({ racePoints: 999 })).some((m) => m.startsWith("racePoints"))).toBe(true);
    expect(rejects(mutate({ probePoints: 50 })).some((m) => m.startsWith("probePoints"))).toBe(true);
    expect(rejects(mutate({ optimalCost: 7 }))).toContain("optimalCost tidak cocok dengan solver");
    expect(rejects(mutate({ timedOut: true }))).toContain("ronde timeout tidak boleh completed");
  });

  it("menolak bonus beruntun di luar aturan", () => {
    expect(rejects(mutate({ streakBonus: 400 }))).toContain("streakBonus di luar aturan");
    const wrong = buildResult(FIXTURE, { path: ["n0", "n2", "n3", "n5"], tRouteMs: 6000, timeLimitS: 25, streakBonus: 100 });
    expect(rejects(wrong)).toContain("streakBonus di luar aturan");
  });

  it("menolak waktu di luar batas, steps, dan revisits yang salah", () => {
    expect(rejects(mutate({ tRouteMs: -1 }))).toContain("tRouteMs di luar 0..walkMs");
    expect(rejects(mutate({ tRouteMs: 25_001 }))).toContain("tRouteMs di luar 0..walkMs");
    expect(rejects(mutate({ tFirstMs: 20_000 }))).toContain("tFirstMs melebihi tRouteMs");
    expect(rejects(mutate({ steps: 9 }))).toContain("steps ≠ playerPath.length − 1");
    expect(rejects(mutate({ revisits: 3 }))).toContain("revisits tidak cocok dengan path");
  });

  it("menolak tapLog tidak urut serta jumlah invalid/UNDO yang tidak cocok", () => {
    const log = good().tapLog;
    expect(rejects(mutate({ tapLog: [...log].reverse() }))).toContain("tapLog tidak urut naik");
    expect(rejects(mutate({ invalidTaps: 2 }))).toContain("invalidTaps ≠ entri valid:false");
    expect(rejects(mutate({ undo: 1 }))).toContain("undo ≠ entri UNDO");
  });

  it("ronde missed: tanpa rute dan semua nilai nol; pelanggaran ditolak", () => {
    const missed = buildResult(FIXTURE, { path: [], tRouteMs: 0, timeLimitS: 25, missed: true, tapLog: [] });
    expect(() => assertRoundIntegrity(missed, FIXTURE)).not.toThrow();
    expect(rejects({ ...missed, completed: true })).toContain("ronde missed tidak boleh selesai/optimal/timeout");
    expect(rejects({ ...missed, playerPath: ["n0", "n1"] })).toContain("ronde missed tidak punya rute");
    expect(rejects({ ...missed, racePoints: 10 })).toContain("ronde missed harus bernilai 0");
  });
});

const tutorial = (patch: Partial<TutorialResult> = {}): TutorialResult => ({
  sessionId: "uji",
  studentId: "s1",
  completed: true,
  totalMs: 60_000,
  step3Attempts: 1,
  hints: 0,
  probeCorrect: true,
  autoDemoSteps: [],
  steps: [1, 2, 3, 4, 5].map((step) => ({ step, attempts: 1, hintsShown: 0, invalidTaps: 0, undo: 0, ms: 10_000 })),
  ...patch,
});

describe("assertTutorialIntegrity", () => {
  it("menerima hasil tutorial yang konsisten", () => expect(() => assertTutorialIntegrity(tutorial())).not.toThrow());

  it("menolak jumlah langkah salah, nomor langkah salah, ms negatif, total kurang dari jumlah langkah", () => {
    expect(() => assertTutorialIntegrity(tutorial({ steps: tutorial().steps.slice(0, 4) }))).toThrow(IntegrityError);
    expect(() => assertTutorialIntegrity(tutorial({ steps: tutorial().steps.map((s, i) => ({ ...s, step: i + 2 })) }))).toThrow(/bernomor/);
    expect(() => assertTutorialIntegrity(tutorial({ steps: tutorial().steps.map((s, i) => (i === 2 ? { ...s, ms: -5 } : s)) }))).toThrow(/negatif/);
    expect(() => assertTutorialIntegrity(tutorial({ totalMs: 49_999 }))).toThrow(/melebihi totalMs/);
    expect(() => assertTutorialIntegrity(tutorial({ totalMs: -1 }))).toThrow(IntegrityError);
  });

  it("completed harus salah bila ada demo otomatis", () => {
    expect(() => assertTutorialIntegrity(tutorial({ autoDemoSteps: [3] }))).toThrow(/demo otomatis/);
    expect(() => assertTutorialIntegrity(tutorial({ autoDemoSteps: [3], completed: false }))).not.toThrow();
  });
});

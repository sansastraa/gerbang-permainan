import { describe, expect, it } from "vitest";
import { parseFormBank, parseMap, parsePool, parseTutorial, poolItem } from "../src/dataLoaders";
import { checkPool, complexityScore, edgeStructureKey, signatureKey, signatureOf, twinCount, type PoolDef } from "../src/equivalence";
import {
  hasLiteralCoinNumbers,
  introDurations,
  isContiguous,
  parseTimeline,
  resolveScreenText,
  trailerNumbers,
} from "../src/introTimeline";
import { ROUND_CONFIGS } from "../src/rounds";
import { minHops, optimalCost, optimalRoute, optimalStopOrder, secondBestGap } from "../src/solver";
import type { RoundConfig } from "../src/types";
import { BANK_A, BANK_B, FORM_BANK_MAPS, POOL_A, POOL_B, RAW, TIMELINE, TUTORIAL } from "./data";
import { GOLDEN, POOL_GOLDEN, mapById } from "./helpers";

const clonePool = (p: PoolDef): PoolDef => structuredClone(p);
const cfg = (id: number): RoundConfig => ROUND_CONFIGS[id] as RoundConfig;

describe("T24 golden penuh (22 peta + 5 peta tutorial)", () => {
  it("semua field golden.json cocok persis, termasuk probeEdgeId", () => {
    for (const m of FORM_BANK_MAPS) {
      const g = GOLDEN[m.id]!;
      expect(optimalCost(m), m.id).toBe(g.optimalCost);
      expect(optimalRoute(m), m.id).toEqual(g.optimalRoute);
      expect(minHops(m), m.id).toBe(g.minHops);
      expect(secondBestGap(m), m.id).toBe(g.secondBestGap);
      expect(m.stops.length ? optimalStopOrder(m) : [], m.id).toEqual(g.optimalStopOrder);
      expect(m.probeEdgeId ?? null, m.id).toBe((g as unknown as { probeEdgeId: string | null }).probeEdgeId);
    }
  });

  it("peta tutorial cocok dengan nilai golden-nya dan probe T-04 = n1-n3", () => {
    expect(TUTORIAL).toHaveLength(5);
    expect(TUTORIAL[3]!.probeEdgeId).toBe("n1-n3");
    TUTORIAL.forEach((t) => {
      expect(optimalCost(t)).toBe(t.golden.optimalCost);
      expect(optimalRoute(t)).toEqual(t.golden.optimalRoute);
    });
  });
});

describe("bank soal paralel (P1–P6)", () => {
  it("P1: ronde 0 = 1 soal, ronde 1–10 = 4 soal, total 41 per pool; P1–P4 lolos lewat checkPool", () => {
    for (const pool of [POOL_A, POOL_B]) {
      const byRound = new Map(pool.rounds.map((r) => [r.roundId, r.items.length]));
      expect(byRound.get(0)).toBe(1);
      for (let r = 1; r <= 10; r++) expect(byRound.get(r)).toBe(4);
      expect(pool.rounds.flatMap((r) => r.items)).toHaveLength(41);
      expect(checkPool(pool)).toEqual({ ok: true, issues: [] });
    }
  });

  it("P5: pool_golden.json cocok dengan solver untuk 82 soal", () => {
    let n = 0;
    for (const pool of [POOL_A, POOL_B]) {
      for (const round of pool.rounds) {
        for (const m of round.items) {
          n++;
          const g = POOL_GOLDEN[m.id]!;
          expect(optimalCost(m)).toBe(g.optimalCost);
          expect(signatureOf(m).trapDelta).toBe(g.trapDelta);
          expect(m.probeEdgeId ?? null).toBe((g as unknown as { probeEdgeId: string | null }).probeEdgeId);
        }
      }
    }
    expect(n).toBe(82);
  });

  it("P6: tidak ada soal kembar antara Pool A dan Pool B", () => {
    expect(twinCount(POOL_A, POOL_B)).toBe(0);
    expect(twinCount(POOL_A, POOL_A)).toBeGreaterThan(0);
  });

  it("kompleksitas naik: SK minimum pasangan > SK maksimum pasangan sebelumnya (contoh angka tabel 8.5)", () => {
    const sk = (pool: PoolDef, rid: number): number[] =>
      pool.rounds.find((r) => r.roundId === rid)!.items.map((m) => complexityScore(cfg(rid), signatureOf(m)));
    for (const pool of [POOL_A, POOL_B]) {
      let prev = 0;
      for (const v of [1, 3, 5, 7, 9]) {
        const scores = [...sk(pool, v), ...sk(pool, v + 1)];
        expect(Math.min(...scores)).toBeGreaterThan(prev);
        prev = Math.max(...scores);
      }
    }
  });

  it("peta A-05 bank dipakai sebagai fixture; F-A dan F-B masing-masing 11 peta", () => {
    expect(BANK_A.maps).toHaveLength(11);
    expect(BANK_B.maps).toHaveLength(11);
    expect(mapById("A-05").id).toBe("A-05");
  });
});

describe("checkPool menolak bank yang rusak", () => {
  it("P1: jumlah soal kurang", () => {
    const p = clonePool(POOL_A);
    p.rounds.find((r) => r.roundId === 3)!.items.pop();
    expect(checkPool(p).issues.some((i) => i.startsWith("P1"))).toBe(true);
  });

  it("P1: soal gagal validator (bobot 0)", () => {
    const p = clonePool(POOL_A);
    p.rounds.find((r) => r.roundId === 3)!.items[1]!.edges[0]!.w = 0;
    expect(checkPool(p).issues.some((i) => i.includes("gagal"))).toBe(true);
  });

  it("P2: soal kembar dalam satu ronde", () => {
    const p = clonePool(POOL_A);
    const items = p.rounds.find((r) => r.roundId === 5)!.items;
    items[1] = { ...structuredClone(items[0]!), id: "kembar" };
    expect(checkPool(p).issues.some((i) => i.includes("kembar"))).toBe(true);
  });

  it("P3: pasangan VISIBLE/HIDDEN tidak setara", () => {
    const p = clonePool(POOL_A);
    const r2 = p.rounds.find((r) => r.roundId === 2)!;
    r2.items = structuredClone(p.rounds.find((r) => r.roundId === 4)!.items);
    expect(checkPool(p).issues.some((i) => i.startsWith("P3"))).toBe(true);
  });

  it("P4: kompleksitas tidak naik (pasangan 5-6 diganti klon pasangan 3-4)", () => {
    const p = clonePool(POOL_A);
    const get = (id: number) => p.rounds.find((r) => r.roundId === id)!;
    get(5).items = structuredClone(get(3).items);
    get(6).items = structuredClone(get(4).items);
    expect(checkPool(p).issues.some((i) => i.startsWith("P4"))).toBe(true);
  });

  it("kunci kesetaraan dan struktur edge", () => {
    const m = POOL_A.rounds[1]!.items[0]!;
    expect(signatureKey(signatureOf(m)).split("|")).toHaveLength(4);
    expect(edgeStructureKey(m)).toContain(":");
  });

  it("signatureOf menolak peta tanpa rute kedua (T-01)", () => {
    expect(() => signatureOf(TUTORIAL[0]!)).toThrow(RangeError);
  });
});

describe("pemuat data (dataLoaders)", () => {
  it("parseMap menolak bentuk yang salah", () => {
    expect(() => parseMap(null)).toThrow(/bukan objek/);
    expect(() => parseMap({ id: "x", nodes: "salah" })).toThrow(/bukan daftar/);
    expect(() => parseMap({ id: "", nodes: [], edges: [], start: "n0", goal: "n1", stops: [] })).toThrow(/bukan teks/);
    expect(() => parseMap({ id: "x", nodes: [{ id: "n0", kind: "home", x: "a", y: 0 }], edges: [], start: "n0", goal: "n0", stops: [] })).toThrow(/bukan angka/);
    expect(() => parseMap({ id: "x", nodes: [{ id: "n0", kind: "gedung", x: 0, y: 0 }], edges: [], start: "n0", goal: "n0", stops: [] })).toThrow(/jenis tempat/);
    const ok = { id: "x", nodes: [{ id: "n0", kind: "home", x: 0, y: 0 }], edges: [], start: "n0", goal: "n0", stops: [] };
    expect(() => parseMap({ ...ok, goal: "n9" })).toThrow(/tidak ada/);
    expect(() => parseMap({ ...ok, edges: [{ id: "e", a: "n0", b: "n7", w: 1 }] })).toThrow(/tidak ada/);
    expect(parseMap({ ...ok, probeEdgeId: "n0-n1" }).probeEdgeId).toBe("n0-n1");
  });

  it("parseFormBank, parsePool, parseTutorial membaca data nyata", () => {
    expect(parseFormBank(RAW.formA).maps).toHaveLength(11);
    expect(parsePool(RAW.poolB).rounds).toHaveLength(11);
    expect(parseTutorial(RAW.tutorial)).toHaveLength(5);
    expect(() => parseTutorial({ maps: [{ ...(RAW.tutorial.maps[0] as object), condition: "ANEH" }] })).toThrow(/kondisi/);
    expect(parseTutorial(RAW.tutorial)[0]!.golden.secondBestGap).toBeNull();
  });

  it("poolItem mengambil soal per ronde dan slot", () => {
    expect(poolItem(POOL_A, 5, 2).id).toBe("PA-05-2");
    expect(() => poolItem(POOL_A, 5, 9)).toThrow(RangeError);
    expect(() => poolItem(POOL_A, 99, 0)).toThrow(RangeError);
  });
});

describe("timeline intro (I1–I4)", () => {
  it("I1 durasi ident 8000, trailer 45000, ident ringkas 3000, trailer ringkas 12000", () => {
    expect(introDurations(TIMELINE)).toEqual({ identMs: 8000, trailerMs: 45000, identShortMs: 3000, trailerShortMs: 12000 });
  });

  it("I2 shot bersambung tanpa jeda atau tumpang tindih", () => {
    expect([isContiguous(TIMELINE.ident), isContiguous(TIMELINE.trailer), isContiguous(TIMELINE.trailerShort)]).toEqual([true, true, true]);
    expect(isContiguous([])).toBe(false);
    expect(isContiguous([{ startMs: 0, endMs: 5 }, { startMs: 6, endMs: 9 }])).toBe(false);
    expect(isContiguous([{ startMs: 1, endMs: 5 }])).toBe(false);
  });

  it("I3 angka shot 5 dihitung dari A-05: trapCost 9, optimalCost 8", () => {
    const nums = trailerNumbers(mapById(TIMELINE.trailerMap));
    expect(nums).toEqual({ trapCost: 9, optimalCost: 8 });
    const shot5 = TIMELINE.trailer.find((s) => s.id === "shot-05")!;
    expect(resolveScreenText(shot5.screenText as string, nums)).toBe("9 vs 8");
  });

  it("I4 tidak ada angka koin literal di timeline.json", () => {
    expect(hasLiteralCoinNumbers(RAW.timeline)).toBe(false);
    expect(hasLiteralCoinNumbers({ t: "9 vs 8" })).toBe(true);
  });

  it("parseTimeline menolak data rusak; trailerNumbers menolak peta tanpa jebakan", () => {
    expect(() => parseTimeline({})).toThrow(TypeError);
    expect(() => parseTimeline({ ...RAW.timeline, ident: [{ id: 1 }] })).toThrow(TypeError);
    const terpisah = { ...TUTORIAL[0]!, edges: [] };
    expect(() => trailerNumbers(terpisah)).toThrow(RangeError);
  });
});

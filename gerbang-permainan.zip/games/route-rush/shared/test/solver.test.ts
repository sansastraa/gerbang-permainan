import { describe, expect, it } from "vitest";
import { classifyError, evaluatePath } from "../src/metrics";
import { pathCost } from "../src/graph";
import {
  allRoutes,
  countOptimalRoutes,
  minHops,
  optimalCost,
  optimalRoute,
  optimalStopOrder,
  secondBestGap,
  simpleRouteCount,
  trapDelta,
} from "../src/solver";
import type { MapDef } from "../src/types";
import { ALL_BANK_MAPS, FIXTURE, FORM_MAPS, GOLDEN, POOL_GOLDEN, POOL_ITEMS, TUTORIAL_GOLDEN, TUTORIAL_MAPS, mapById } from "./helpers";

describe("solver pada fixture (14.1)", () => {
  it("T1 optimalCost = 8", () => expect(optimalCost(FIXTURE)).toBe(8));
  it("T2 optimalRoute", () => expect(optimalRoute(FIXTURE)).toEqual(["n0", "n1", "n2", "n3", "n5"]));
  it("T3 minHops = 3", () => expect(minHops(FIXTURE)).toBe(3));
  it("T4 selisih rute kedua = 1 dan rute paling sedikit jalan bukan optimal (jebakan)", () => {
    expect(secondBestGap(FIXTURE)).toBe(1);
    expect(countOptimalRoutes(FIXTURE)).toBe(1);
    const optimalSteps = optimalRoute(FIXTURE).length - 1;
    expect(optimalSteps).not.toBe(minHops(FIXTURE));
  });
  it("T22 A-05 di bank identik dengan fixture", () => {
    const { roundId: _ignored, ...bank } = mapById("A-05") as MapDef & { roundId?: number };
    expect(bank).toEqual(FIXTURE);
  });
});

describe("T6c, T8, T21 jenis kesalahan", () => {
  it("T6c Budi memilih jalan paling sedikit → FEW_ROADS_TRAP", () => {
    expect(evaluatePath(FIXTURE, ["n0", "n2", "n3", "n5"], false)).toMatchObject({ playerCost: 9, errorType: "FEW_ROADS_TRAP", optimalHit: false, completed: true });
    expect(evaluatePath(FIXTURE, ["n0", "n2", "n3", "n5"], false).er).toBeCloseTo(8 / 9, 12);
  });
  it("T8 Dodi timeout → TIMEOUT dan tidak selesai", () => {
    expect(evaluatePath(FIXTURE, ["n0", "n1"], true)).toMatchObject({ errorType: "TIMEOUT", completed: false, er: 0 });
  });
  it("T21 A-09: stop salah urutan → STOP_ORDER dengan biaya 26", () => {
    const a09 = mapById("A-09");
    const path = ["n0", "n5", "n2", "n0", "n4", "n6"];
    expect(pathCost(a09, path)).toBe(26);
    expect(evaluatePath(a09, path, false).errorType).toBe("STOP_ORDER");
  });
  it("rute optimal → NONE, jalan memutar → DETOUR, path tidak valid tidak selesai", () => {
    expect(evaluatePath(FIXTURE, optimalRoute(FIXTURE), false)).toMatchObject({ errorType: "NONE", optimalHit: true, er: 1 });
    expect(classifyError(FIXTURE, ["n0", "n1", "n2", "n4", "n5"], false, false)).toBe("DETOUR");
    expect(evaluatePath(FIXTURE, ["n0", "n5"], false)).toMatchObject({ playerCost: null, completed: false });
    expect(evaluatePath(FIXTURE, ["n1", "n0"], false).playerCost).toBeNull();
  });
});

describe("kecocokan dengan data acuan", () => {
  it("peta fixture bank (22 peta) cocok dengan golden.json", () => {
    expect(FORM_MAPS).toHaveLength(22);
    for (const map of FORM_MAPS) {
      const g = GOLDEN[map.id];
      expect(g, map.id).toBeDefined();
      expect(optimalCost(map), map.id).toBe(g!.optimalCost);
      expect(optimalRoute(map), map.id).toEqual(g!.optimalRoute);
      expect(minHops(map), map.id).toBe(g!.minHops);
      expect(secondBestGap(map), map.id).toBe(g!.secondBestGap);
      expect(map.stops.length ? optimalStopOrder(map) : [], map.id).toEqual(g!.optimalStopOrder);
    }
  });

  it("82 soal pool cocok dengan pool_golden.json (termasuk rute sederhana dan trapDelta)", () => {
    expect(POOL_ITEMS).toHaveLength(82);
    for (const map of POOL_ITEMS) {
      const g = POOL_GOLDEN[map.id];
      expect(g, map.id).toBeDefined();
      expect(optimalCost(map), map.id).toBe(g!.optimalCost);
      expect(optimalRoute(map), map.id).toEqual(g!.optimalRoute);
      expect(minHops(map), map.id).toBe(g!.minHops);
      expect(secondBestGap(map), map.id).toBe(g!.secondBestGap);
      expect(simpleRouteCount(map), map.id).toBe(g!.simpleRoutes);
      expect(trapDelta(map), map.id).toBe(g!.trapDelta);
      expect(map.stops.length ? optimalStopOrder(map) : [], map.id).toEqual(g!.optimalStopOrder);
      expect(countOptimalRoutes(map), map.id).toBe(1);
    }
  });

  it("5 peta tutorial cocok dengan nilai golden-nya", () => {
    expect(TUTORIAL_MAPS).toHaveLength(5);
    TUTORIAL_MAPS.forEach((map, i) => {
      expect(optimalCost(map), map.id).toBe(TUTORIAL_GOLDEN[i]!.optimalCost);
      expect(optimalRoute(map), map.id).toEqual(TUTORIAL_GOLDEN[i]!.optimalRoute);
    });
    expect(TUTORIAL_MAPS.map((m) => optimalCost(m))).toEqual([5, 3, 7, 4, 6]);
  });
});

describe("fungsi solver lain", () => {
  it("allRoutes tidak menghasilkan rute ganda dan semua berbiaya valid", () => {
    for (const map of ALL_BANK_MAPS.slice(0, 40)) {
      const routes = allRoutes(map);
      expect(new Set(routes.map((r) => r.path.join(","))).size).toBe(routes.length);
      expect(routes.every((r) => r.cost >= optimalCost(map))).toBe(true);
    }
  });

  it("secondBestGap null bila hanya satu tingkat biaya, trapDelta null bila tidak ada rute dengan langkah minimum", () => {
    const [tutorial1] = TUTORIAL_MAPS;
    expect(secondBestGap(tutorial1 as MapDef)).toBeNull();
    const lonely: MapDef = {
      id: "X",
      nodes: [
        { id: "n0", kind: "home", x: 0.1, y: 0.5 },
        { id: "n1", kind: "school", x: 0.9, y: 0.5 },
      ],
      edges: [],
      start: "n0",
      goal: "n1",
      stops: [],
    };
    expect(trapDelta(lonely)).toBeNull();
  });
});

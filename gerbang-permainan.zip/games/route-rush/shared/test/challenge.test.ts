import { readFileSync } from "node:fs";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { MAX_LEVEL, MIN_LEVEL, nextLevel, CHALLENGE_CONFIGS, CHALLENGE_SLOTS, bestWalk, buildChallengePool, createRng, generateChallengeMap, challengeConfig, checkChallengeMap, effectiveRoundConfig, defaultSettings, optimalCost, optimalRoute, parsePool, poolItem } from "../src/index";

const dir = dirname(fileURLToPath(import.meta.url));
const pool = parsePool(JSON.parse(readFileSync(join(dir, "../maps/poolT.json"), "utf8")));

describe("bank Tantangan (pool T)", () => {
  it("10 ronde × 4 soal ditambah peta latihan ronde 0", () => {
    expect(pool.pool).toBe("T");
    expect(pool.rounds.map((r) => r.roundId)).toEqual([0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10]);
    for (const r of pool.rounds) expect(r.items).toHaveLength(r.roundId === 0 ? 1 : CHALLENGE_SLOTS);
  });

  it("setiap peta lolos pemeriksaan: tunggal, tanpa persilangan, ukuran sesuai konfigurasi", () => {
    for (const c of CHALLENGE_CONFIGS) {
      for (let slot = 0; slot < CHALLENGE_SLOTS; slot++) {
        const m = poolItem(pool, c.roundId, slot);
        expect(checkChallengeMap(m, c).issues, m.id).toEqual([]);
      }
    }
  });

  it("makin sulit: peta bertambah besar dan waktu jalan 60 sampai 120 detik", () => {
    expect(CHALLENGE_CONFIGS.map((c) => c.walkMs / 1000)).toEqual([60, 65, 75, 80, 90, 95, 105, 110, 115, 120]);
    for (let i = 1; i < CHALLENGE_CONFIGS.length; i++) {
      const a = CHALLENGE_CONFIGS[i - 1]!;
      const b = CHALLENGE_CONFIGS[i]!;
      expect(b.nNodes).toBeGreaterThanOrEqual(a.nNodes);
      expect(b.nEdges).toBeGreaterThanOrEqual(a.nEdges);
      expect(b.nStops).toBeGreaterThanOrEqual(a.nStops);
    }
    expect(CHALLENGE_CONFIGS.every((c) => c.condition === "VISIBLE" && c.scored)).toBe(true);
  });

  it("solver cepat: biaya dan rute optimal konsisten", () => {
    for (const c of CHALLENGE_CONFIGS) {
      const m = poolItem(pool, c.roundId, 0);
      const w = bestWalk(m)!;
      expect(w.cost).toBe(optimalCost(m));
      expect(optimalRoute(m)).toEqual(w.path);
      expect(w.path[0]).toBe(m.start);
      expect(w.path[w.path.length - 1]).toBe(m.goal);
      for (const s of m.stops) expect(w.path).toContain(s);
    }
  });

  it("pool T memakai konfigurasi Tantangan; ronde latihan tetap bawaan", () => {
    const s = { ...defaultSettings(5), pool: "T" as const };
    expect(effectiveRoundConfig(10, s).walkMs).toBe(120_000);
    expect(effectiveRoundConfig(10, s).nNodes).toBe(challengeConfig(10).nNodes);
    expect(effectiveRoundConfig(0, s).scored).toBe(false);
    expect(effectiveRoundConfig(10, { ...s, pool: "A" }).walkMs).not.toBe(120_000);
  });

  it("pembuat peta deterministik dan bank di berkas sama dengan hasil pembuatnya", () => {
    const a = generateChallengeMap(CHALLENGE_CONFIGS[0]!, createRng("uji"), "T-x");
    const b = generateChallengeMap(CHALLENGE_CONFIGS[0]!, createRng("uji"), "T-x");
    expect(a).toEqual(b);
    const rebuilt = buildChallengePool(pool.seed, pool.rounds[0]!);
    expect(rebuilt.rounds).toEqual(pool.rounds);
  });

  it("pemeriksa menolak peta berpotongan, rute kembar, dan peta yang bukan jebakan", () => {
    const c = CHALLENGE_CONFIGS[1]!; // trap
    const m = poolItem(pool, 2, 0);
    // dua jalan yang tidak berbagi simpul dipaksa bersilangan (X)
    const [e1, e2] = m.edges.flatMap((a, i) => m.edges.slice(i + 1).filter((b) => ![a.a, a.b].includes(b.a) && ![a.a, a.b].includes(b.b)).map((b) => [a, b] as const))[0]!;
    const at: Record<string, [number, number]> = { [e1.a]: [0.1, 0.1], [e1.b]: [0.9, 0.9], [e2.a]: [0.1, 0.9], [e2.b]: [0.9, 0.1] };
    const crossed = { ...m, nodes: m.nodes.map((n) => (at[n.id] ? { ...n, x: at[n.id]![0], y: at[n.id]![1] } : n)) };
    expect(checkChallengeMap(crossed, c).issues.join(" ")).toContain("berpotongan");
    const flat = { ...m, edges: m.edges.map((e) => ({ ...e, w: 1 })) };
    expect(checkChallengeMap(flat, c).issues.join(" ")).toMatch(/tunggal|jebakan|selisih/);
    expect(checkChallengeMap({ ...m, edges: m.edges.slice(1) }, c).issues).toContain("ukuran peta tidak sesuai konfigurasi");
    expect(() => challengeConfig(99)).toThrow(RangeError);
    expect(bestWalk({ ...m, edges: [] })).toBeNull();
  });

  it("tingkat adaptif: cepat+tepat naik 2, tepat naik 1, hampir hemat bertahan, selebihnya turun, tidak ikut tetap", () => {
    const base = { missed: false, timedOut: false, completed: true, optimalHit: true, er: 1, tRouteMs: 10_000, limitMs: 60_000 };
    expect(nextLevel(3, base)).toBe(5);
    expect(nextLevel(3, { ...base, tRouteMs: 40_000 })).toBe(4);
    expect(nextLevel(3, { ...base, optimalHit: false, er: 0.85 })).toBe(3);
    expect(nextLevel(3, { ...base, optimalHit: false, er: 0.5 })).toBe(2);
    expect(nextLevel(3, { ...base, optimalHit: false, completed: false, timedOut: true })).toBe(2);
    expect(nextLevel(3, { ...base, missed: true })).toBe(3);
    expect(nextLevel(MAX_LEVEL, base)).toBe(MAX_LEVEL);
    expect(nextLevel(MIN_LEVEL, { ...base, optimalHit: false, er: 0 })).toBe(MIN_LEVEL);
  });
});
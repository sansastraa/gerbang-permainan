import { describe, expect, it } from "vitest";
import { analyzeRoutes } from "../src/solver";
import { ROUND_CONFIGS } from "../src/rounds";
import type { MapDef, RoundConfig } from "../src/types";
import { TUTORIAL_EXCEPTIONS, crossingEdges, segmentsCross, validateMap, validateTutorialMap } from "../src/validator";
import { BANK_A, BANK_B, POOL_A, POOL_B, TUTORIAL } from "./data";
import { FIXTURE } from "./helpers";

const cfg = (id: number): RoundConfig => ROUND_CONFIGS[id] as RoundConfig;
const clone = (m: MapDef): MapDef => structuredClone(m);
const codesOf = (m: MapDef, c: RoundConfig, pairGap: number | null = null): string[] => validateMap(m, c, pairGap).codes;

describe("T20 bank peta fixture lolos V1–V9 (termasuk V7 berpasangan)", () => {
  for (const bank of [BANK_A, BANK_B]) {
    it(`Form ${bank.form}: 11 peta lolos`, () => {
      expect(bank.maps).toHaveLength(11);
      const gaps = new Map<number, number | null>();
      for (const m of bank.maps) {
        const c = cfg(m.roundId);
        const pair = c.condition === "HIDDEN" ? (gaps.get(m.roundId - 1) ?? null) : null;
        const r = validateMap(m, c, pair);
        expect(r.codes, m.id).toEqual([]);
        expect(r.ok).toBe(true);
        gaps.set(m.roundId, r.info!.gap);
      }
    });
  }

  it("seluruh 82 soal pool lolos V1–V9", () => {
    for (const pool of [POOL_A, POOL_B]) {
      for (const round of pool.rounds) {
        const first = pool.rounds.find((r) => r.roundId === round.roundId - 1)?.items[0];
        const pair = cfg(round.roundId).condition === "HIDDEN" && first ? (analyzeRoutes(first)!.gap as number) : null;
        for (const m of round.items) expect(validateMap(m, cfg(round.roundId), pair).codes, m.id).toEqual([]);
      }
    }
  });
});

describe("T20b test negatif validator", () => {
  it("dua rute optimal → V2", () => {
    const m = clone(FIXTURE);
    m.edges.find((e) => e.id === "n0-n2")!.w = 4;
    const r = validateMap(m, cfg(5));
    expect(r.ok).toBe(false);
    expect(r.codes).toContain("V2");
  });

  it("edge berpotongan → V6", () => {
    const m = clone(FIXTURE);
    m.edges.push({ id: "n1-n4", a: "n1", b: "n4", w: 5 });
    const c = { ...cfg(5), nEdges: 9 };
    const r = validateMap(m, c);
    expect(r.codes).toContain("V6");
    expect(crossingEdges(m).length).toBeGreaterThan(0);
  });

  it("bobot 0 dan bobot 10 → V9", () => {
    for (const w of [0, 10, 2.5]) {
      const m = clone(FIXTURE);
      m.edges[0]!.w = w;
      expect(codesOf(m, cfg(5)), `w=${w}`).toContain("V9");
    }
  });
});

describe("syarat validator lainnya", () => {
  it("fixture lolos ronde 5 dan info benar", () => {
    const r = validateMap(FIXTURE, cfg(5));
    expect(r.ok).toBe(true);
    expect(r.info).toMatchObject({ opt: 8, gap: 1, minHops: 3, steps: 4 });
    expect(crossingEdges(FIXTURE)).toEqual([]);
  });

  it("V1: jumlah node/edge/stop tidak sesuai config", () => {
    expect(codesOf(FIXTURE, { ...cfg(5), nNodes: 7 })).toContain("V1");
    expect(codesOf(FIXTURE, { ...cfg(5), nEdges: 9 })).toContain("V1");
    expect(codesOf(FIXTURE, { ...cfg(5), nStops: 1 })).toContain("V1");
  });

  it("V1: graf tidak tersambung / tanpa rute", () => {
    const m = clone(FIXTURE);
    m.edges = m.edges.filter((e) => e.b !== "n5" && e.a !== "n5");
    const r = validateMap(m, { ...cfg(5), nEdges: 6 });
    expect(r.codes).toContain("V1");
    expect(r.info).toBeNull();
  });

  it("V3: selisih rute kedua di luar 1..3 (T-01 satu rute, atau selisih 4)", () => {
    const [t01] = TUTORIAL;
    expect(validateMap(t01!, { nNodes: 3, nEdges: 2, nStops: 0, condition: "VISIBLE", trap: false }).codes).toEqual(["V3"]);
    const m = clone(FIXTURE);
    m.edges.find((e) => e.id === "n0-n2")!.w = 9; // rute kedua jauh lebih mahal
    m.edges.find((e) => e.id === "n1-n3")!.w = 9;
    m.edges.find((e) => e.id === "n2-n4")!.w = 9;
    m.edges.find((e) => e.id === "n4-n5")!.w = 9;
    expect(codesOf(m, cfg(5))).toContain("V3");
  });

  it("V4: ronde jebakan wajib menolak peta yang rute optimalnya juga paling sedikit jalan", () => {
    const m = clone(FIXTURE);
    m.edges.find((e) => e.id === "n0-n2")!.w = 1;
    m.edges.find((e) => e.id === "n2-n3")!.w = 1; // n0-n2-n3-n5 = 5 menjadi optimal dengan 3 langkah = minHops
    expect(codesOf(m, cfg(5))).toContain("V4");
  });

  it("V5 dan V3: rantai 8 tempat berbiaya 28", () => {
    const nodes = Array.from({ length: 8 }, (_, i) => ({ id: `n${i}`, kind: (i === 0 ? "home" : i === 7 ? "school" : "park") as MapDef["nodes"][number]["kind"], x: i / 7, y: 0.5 }));
    const edges = Array.from({ length: 7 }, (_, i) => ({ id: `n${i}-n${i + 1}`, a: `n${i}`, b: `n${i + 1}`, w: 4 }));
    const chain: MapDef = { id: "rantai", nodes, edges, start: "n0", goal: "n7", stops: [] };
    const r = validateMap(chain, { nNodes: 8, nEdges: 7, nStops: 0, condition: "VISIBLE", trap: false });
    expect(r.codes).toContain("V5");
  });

  it("V8: rute optimal yang mengunjungi tempat sama dua kali", () => {
    const m: MapDef = {
      id: "cabang",
      nodes: [
        { id: "n0", kind: "home", x: 0.1, y: 0.5 },
        { id: "n1", kind: "market", x: 0.4, y: 0.5 },
        { id: "n2", kind: "park", x: 0.4, y: 0.9 },
        { id: "n3", kind: "school", x: 0.9, y: 0.5 },
      ],
      edges: [
        { id: "n0-n1", a: "n0", b: "n1", w: 1 },
        { id: "n1-n2", a: "n1", b: "n2", w: 1 },
        { id: "n1-n3", a: "n1", b: "n3", w: 1 },
      ],
      start: "n0",
      goal: "n3",
      stops: ["n2"],
    };
    expect(validateMap(m, { nNodes: 4, nEdges: 3, nStops: 1, condition: "VISIBLE", trap: false }).codes).toContain("V8");
  });

  it("V6: dua tempat terlalu dekat (< 0.18)", () => {
    const m = clone(FIXTURE);
    m.nodes.find((n) => n.id === "n2")!.x = 0.45;
    m.nodes.find((n) => n.id === "n2")!.y = 0.5;
    m.nodes.find((n) => n.id === "n0")!.x = 0.4;
    expect(validateMap(m, cfg(5)).issues.some((i) => i.code === "V6" && i.detail === "jarak")).toBe(true);
  });

  it("V7: selisih pasangan harus sama", () => {
    expect(codesOf(FIXTURE, cfg(5), 1)).toEqual([]);
    expect(codesOf(FIXTURE, cfg(5), 2)).toContain("V7");
  });

  it("V9: stop = start/goal, dan HIDDEN wajib punya probe di rute optimal", () => {
    const m = clone(FIXTURE);
    m.stops = ["n0"];
    expect(codesOf(m, { ...cfg(5), nStops: 1 })).toContain("V9");
    const hidden = { ...cfg(6), nEdges: 8 };
    expect(codesOf(FIXTURE, hidden)).toContain("V9"); // tanpa probeEdgeId
    expect(codesOf({ ...FIXTURE, probeEdgeId: "n4-n5" }, hidden)).toContain("V9"); // di luar rute optimal
    expect(codesOf({ ...FIXTURE, probeEdgeId: "n2-n3" }, hidden)).toEqual([]);
  });
});

describe("geometri", () => {
  it("segmen berbagi titik ujung tidak dihitung berpotongan; silang sejati dihitung", () => {
    expect(segmentsCross([0, 0], [1, 1], [1, 1], [2, 0])).toBe(false);
    expect(segmentsCross([0, 0], [1, 1], [0, 1], [1, 0])).toBe(true);
    expect(segmentsCross([0, 0], [1, 0], [0, 1], [1, 1])).toBe(false);
  });
});

describe("peta tutorial (I5)", () => {
  it("lolos validator dengan pengecualian eksplisit; optimal 5, 3, 7, 4, 6 dan cocok dengan golden", () => {
    expect(TUTORIAL_EXCEPTIONS).toEqual({ "T-01": ["V3"] });
    for (const t of TUTORIAL) {
      expect(validateTutorialMap(t).codes, t.id).toEqual([]);
      const a = analyzeRoutes(t)!;
      expect(a.opt, t.id).toBe(t.golden.optimalCost);
      expect(a.best.path, t.id).toEqual(t.golden.optimalRoute);
      expect(a.minHops, t.id).toBe(t.golden.minHops);
      expect(a.gap, t.id).toBe(t.golden.secondBestGap);
    }
    expect(TUTORIAL.map((t) => t.golden.optimalCost)).toEqual([5, 3, 7, 4, 6]);
  });

  it("pengecualian hanya berlaku untuk T-01 dan hanya V3", () => {
    const [t01, t02] = TUTORIAL;
    expect(validateMap(t01!, { nNodes: 3, nEdges: 2, nStops: 0, condition: "VISIBLE", trap: false }).codes).toEqual(["V3"]);
    const broken = { ...t02!, edges: t02!.edges.map((e, i) => (i === 0 ? { ...e, w: 12 } : e)) };
    expect(validateTutorialMap(broken).codes).toContain("V9");
  });
});

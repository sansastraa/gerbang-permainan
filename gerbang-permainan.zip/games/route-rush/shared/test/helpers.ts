import formA from "../maps/formA.json";
import formB from "../maps/formB.json";
import poolA from "../maps/poolA.json";
import poolB from "../maps/poolB.json";
import tutorial from "../maps/tutorial.json";
import golden from "./golden/golden.json";
import poolGolden from "./golden/pool_golden.json";
import { evaluatePath } from "../src/metrics";
import { firstValidTapMs } from "../src/route";
import { probePoints, racePoints } from "../src/scoring";
import { optimalCost } from "../src/solver";
import type { MapDef, NodeId, RoundResult, TapEvent } from "../src/types";

/** Peta fixture Bagian 14.1 (ronde 5 Form A), ditulis ulang apa adanya dari spesifikasi. */
export const FIXTURE: MapDef = {
  id: "A-05",
  nodes: [
    { id: "n0", kind: "home", x: 0.05, y: 0.5 },
    { id: "n1", kind: "market", x: 0.3, y: 0.15 },
    { id: "n2", kind: "park", x: 0.4, y: 0.55 },
    { id: "n3", kind: "mosque", x: 0.7, y: 0.3 },
    { id: "n4", kind: "shop", x: 0.65, y: 0.9 },
    { id: "n5", kind: "school", x: 0.95, y: 0.55 },
  ],
  edges: [
    { id: "n0-n1", a: "n0", b: "n1", w: 2 },
    { id: "n0-n2", a: "n0", b: "n2", w: 5 },
    { id: "n1-n2", a: "n1", b: "n2", w: 2 },
    { id: "n1-n3", a: "n1", b: "n3", w: 6 },
    { id: "n2-n3", a: "n2", b: "n3", w: 1 },
    { id: "n2-n4", a: "n2", b: "n4", w: 4 },
    { id: "n3-n5", a: "n3", b: "n5", w: 3 },
    { id: "n4-n5", a: "n4", b: "n5", w: 2 },
  ],
  start: "n0",
  goal: "n5",
  stops: [],
};

type Loose = { id: string } & Record<string, unknown>;
const asMap = (m: unknown): MapDef => m as MapDef;

export const FORM_MAPS: MapDef[] = [...formA.maps, ...formB.maps].map(asMap);
export const POOL_ITEMS: MapDef[] = [...poolA.rounds, ...poolB.rounds].flatMap((r) => r.items.map(asMap));
export const TUTORIAL_MAPS: MapDef[] = tutorial.maps.map(asMap);
export const ALL_BANK_MAPS: MapDef[] = [...FORM_MAPS, ...POOL_ITEMS];

export const GOLDEN = golden.maps as unknown as Record<string, Loose & {
  optimalCost: number;
  optimalRoute: string[];
  minHops: number;
  secondBestGap: number | null;
  optimalStopOrder: string[];
}>;
export const POOL_GOLDEN = poolGolden.items as unknown as Record<string, Loose & {
  optimalCost: number;
  optimalRoute: string[];
  minHops: number;
  secondBestGap: number | null;
  simpleRoutes: number;
  trapDelta: number;
  optimalStopOrder: string[];
}>;
export const TUTORIAL_GOLDEN = tutorial.maps.map((m) => (m as unknown as { golden: { optimalCost: number; optimalRoute: string[] } }).golden);

export const mapById = (id: string): MapDef => {
  const found = ALL_BANK_MAPS.find((m) => m.id === id);
  if (!found) throw new Error(`peta ${id} tidak ada`);
  return found;
};

export interface BuildOptions {
  path: NodeId[];
  tRouteMs: number;
  timeLimitS: number;
  timedOut?: boolean;
  missed?: boolean;
  roundId?: number;
  condition?: "VISIBLE" | "HIDDEN";
  probeCorrect?: boolean | null;
  probeMs?: number | null;
  streakBonus?: number;
  tapLog?: TapEvent[];
  studentId?: string;
}

/** Menyusun RoundResult yang konsisten dengan fungsi shared/ (untuk test integritas dan indeks). */
export function buildResult(map: MapDef, o: BuildOptions): RoundResult {
  const timedOut = o.timedOut ?? false;
  const missed = o.missed ?? false;
  const path = missed ? [] : o.path;
  const ev = evaluatePath(map, path, timedOut);
  const tapLog: TapEvent[] =
    o.tapLog ?? path.slice(1).map((nodeId, i) => ({ tMs: (i + 1) * 800, nodeId, valid: true }));
  const probeCorrect = o.probeCorrect ?? null;
  const probeMs = o.probeMs ?? null;
  const condition = o.condition ?? "VISIBLE";
  return {
    sessionId: "uji",
    studentId: o.studentId ?? "s1",
    nickname: "uji",
    form: "A",
    mode: "STANDARD",
    roundId: o.roundId ?? 5,
    condition,
    variantId: 0,
    itemId: map.id,
    itemSlot: 0,
    seatMode: "SEATED",
    seatRow: 0,
    seatCol: 0,
    focusLost: 0,
    fullscreenExits: 0,
    integrityFlags: [],
    nNodes: map.nodes.length,
    nEdges: map.edges.length,
    nStops: map.stops.length,
    timeLimitS: o.timeLimitS,
    optimalCost: optimalCost(map),
    playerCost: missed ? null : ev.playerCost,
    playerPath: path,
    completed: missed ? false : ev.completed,
    optimalHit: missed ? false : ev.optimalHit,
    timedOut,
    missed,
    er: missed ? 0 : ev.er,
    tFirstMs: firstValidTapMs(tapLog),
    tRouteMs: o.tRouteMs,
    invalidTaps: tapLog.filter((t) => !t.valid).length,
    undo: tapLog.filter((t) => t.nodeId === "UNDO").length,
    revisits: ev.revisits,
    steps: ev.steps,
    probeCorrect,
    probeMs,
    racePoints: missed
      ? 0
      : racePoints({ optimalHit: ev.optimalHit, completed: ev.completed, er: ev.er, tSec: o.tRouteMs / 1000, limitSec: o.timeLimitS }),
    streakBonus: missed ? 0 : (o.streakBonus ?? 0),
    probePoints: missed ? 0 : probePoints(probeCorrect, (probeMs ?? 0) / 1000),
    rankAfter: 1,
    errorType: missed ? "NONE" : ev.errorType,
    tapLog,
  };
}

import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { SLOT_COUNT, assignSlot, assignSlotNoSeat, assignVariant, assignVariantNoSeat, distributionParams, seatBase } from "../src/distribution";
import { optimalCost } from "../src/solver";
import { VARIANT_COUNT, applyVariant, labelSeedFor } from "../src/variant";
import { crossingEdges } from "../src/validator";
import { ALL_BANK_MAPS, FORM_MAPS } from "./helpers";

const PERMS: number[][] = (() => {
  const out: number[][] = [];
  const walk = (cur: number[], rest: number[]): void => {
    if (rest.length === 0) out.push(cur);
    rest.forEach((r, i) => walk([...cur, r], rest.filter((_, j) => j !== i)));
  };
  walk([], [0, 1, 2, 3]);
  return out;
})();

describe("variant.ts (T19)", () => {
  it("8 simetri × 22 peta bank: optimalCost tetap, id tetap, koordinat 0..1, tidak ada edge berpotongan", () => {
    expect(FORM_MAPS).toHaveLength(22);
    for (const map of FORM_MAPS) {
      const cost = optimalCost(map);
      for (let v = 0; v < VARIANT_COUNT; v++) {
        const vm = applyVariant(map, v, labelSeedFor("siswa-1", 3));
        expect(optimalCost(vm), `${map.id} v${v}`).toBe(cost);
        expect(vm.nodes.map((n) => n.id)).toEqual(map.nodes.map((n) => n.id));
        expect(vm.edges).toEqual(map.edges);
        expect([vm.start, vm.goal, vm.stops]).toEqual([map.start, map.goal, map.stops]);
        expect(vm.nodes.every((n) => n.x >= 0 && n.x <= 1 && n.y >= 0 && n.y <= 1)).toBe(true);
        expect(crossingEdges(vm)).toEqual([]);
      }
    }
  });

  it("start dan goal tetap home/school; jenis tempat lain hanya dipermutasi", () => {
    for (const map of ALL_BANK_MAPS.slice(0, 30)) {
      const vm = applyVariant(map, 5, "seed");
      expect(vm.nodes.find((n) => n.id === map.start)!.kind).toBe("home");
      expect(vm.nodes.find((n) => n.id === map.goal)!.kind).toBe("school");
      const middle = (m: typeof map) => m.nodes.filter((n) => n.id !== m.start && n.id !== m.goal).map((n) => n.kind).sort();
      expect(middle(vm)).toEqual(middle(map));
    }
  });

  it("varian 0 tidak memutar; varian 2 memutar 180°; cermin untuk 4..7; deterministik per seed", () => {
    const m = FORM_MAPS[5]!;
    const v0 = applyVariant(m, 0, 1);
    m.nodes.forEach((n, i) => {
      expect(v0.nodes[i]!.x).toBeCloseTo(n.x, 6);
      expect(v0.nodes[i]!.y).toBeCloseTo(n.y, 6);
    });
    const v2 = applyVariant(m, 2, 1);
    m.nodes.forEach((n, i) => {
      expect(v2.nodes[i]!.x).toBeCloseTo(1 - n.x, 6);
      expect(v2.nodes[i]!.y).toBeCloseTo(1 - n.y, 6);
    });
    const v4 = applyVariant(m, 4, 1);
    m.nodes.forEach((n, i) => {
      expect(v4.nodes[i]!.x).toBeCloseTo(1 - n.x, 6);
      expect(v4.nodes[i]!.y).toBeCloseTo(n.y, 6);
    });
    expect(applyVariant(m, 3, "a")).toEqual(applyVariant(m, 3, "a"));
    expect(labelSeedFor("s", 1)).not.toBe(labelSeedFor("s", 2));
  });

  it("variantId di luar 0..7 ditolak", () => {
    expect(() => applyVariant(FORM_MAPS[0]!, 8, 1)).toThrow(RangeError);
    expect(() => applyVariant(FORM_MAPS[0]!, -1, 1)).toThrow(RangeError);
    expect(() => applyVariant(FORM_MAPS[0]!, 1.5, 1)).toThrow(RangeError);
  });

  it("properti: varian 0–7 pada peta bank mana pun menjaga optimalCost dan tanpa perpotongan", () => {
    fc.assert(
      fc.property(fc.constantFrom(...ALL_BANK_MAPS), fc.nat({ max: 7 }), fc.string(), (map, v, seed) => {
        const vm = applyVariant(map, v, seed);
        expect(optimalCost(vm)).toBe(optimalCost(map));
        expect(crossingEdges(vm)).toEqual([]);
      }),
      { numRuns: 500 },
    );
  });
});

describe("distribution.ts (P7–P10)", () => {
  // Pasangan kursi pada denah yang lebih kecil selalu juga ada pada denah 8 × 10, jadi cukup memeriksa denah terbesar.
  const FORWARD: readonly (readonly [number, number])[] = [[0, 1], [1, 0], [1, 1], [1, -1]];

  it("P7 kursi bersebelahan (8 arah) selalu beda soal: denah sampai 8 × 10, 24 permutasi, 4 offset, 11 ronde", () => {
    let pasangan = 0;
    for (const perm of PERMS) {
      for (let off = 0; off < 4; off++) {
        for (let rid = 0; rid <= 10; rid++) {
          for (let r = 0; r < 8; r++) {
            for (let c = 0; c < 10; c++) {
              const a = assignSlot(r, c, rid, perm, off);
              for (const [dr, dc] of FORWARD) {
                const r2 = r + dr;
                const c2 = c + dc;
                if (r2 < 8 && c2 >= 0 && c2 < 10) {
                  pasangan++;
                  if (assignSlot(r2, c2, rid, perm, off) === a) throw new Error(`kursi ${r},${c} dan ${r2},${c2} sama di ronde ${rid}`);
                }
              }
            }
          }
        }
      }
    }
    expect(pasangan).toBe(24 * 4 * 11 * (8 * 9 + 7 * 10 + 7 * 9 + 7 * 9));
  });
  it("P8 Standar: tiap siswa mendapat tiap slot 2–3 kali; P8b Kilat: maksimal 2 kali", () => {
    for (const perm of PERMS) {
      for (let off = 0; off < 4; off++) {
        for (let r = 0; r < 2; r++) {
          for (let c = 0; c < 2; c++) {
            const std = Array.from({ length: SLOT_COUNT }, () => 0);
            for (let rid = 1; rid <= 10; rid++) std[assignSlot(r, c, rid, perm, off)]!++;
            expect([...std].sort()).toEqual([2, 2, 3, 3]);
            const quick = Array.from({ length: SLOT_COUNT }, () => 0);
            for (const rid of [1, 2, 3, 4, 7, 8]) quick[assignSlot(r, c, rid, perm, off)]!++;
            expect(Math.max(...quick)).toBeLessThanOrEqual(2);
          }
        }
      }
    }
  });

  it("P9 tanpa denah: urutan masuk berurutan beda soal; varian dari hash id siswa dan ronde", () => {
    for (let j = 0; j < 60; j++) for (let rid = 0; rid <= 10; rid++) for (let off = 0; off < 4; off++) expect(assignSlotNoSeat(j, rid, off)).not.toBe(assignSlotNoSeat(j + 1, rid, off));
    expect(assignVariantNoSeat("siswa-a", 3)).toBe(assignVariantNoSeat("siswa-a", 3));
    for (const id of ["a", "b", "c", "d"]) expect(assignVariantNoSeat(id, 1)).toBeGreaterThanOrEqual(0);
  });

  it("P10 radius 2 kursi: yang mendapat soal sama selalu beda varian tampilan", () => {
    const radius2: [number, number][] = [];
    for (let dr = 0; dr <= 2; dr++) for (let dc = -2; dc <= 2; dc++) if (dr > 0 || dc > 0) radius2.push([dr, dc]);
    let sama = 0;
    for (const perm of PERMS) {
      for (let off = 0; off < 4; off++) {
        for (let off2 = 0; off2 < 2; off2++) {
          for (let rid = 0; rid <= 10; rid++) {
            for (let r = 0; r < 8; r++) {
              for (let c = 0; c < 10; c++) {
                for (const [dr, dc] of radius2) {
                  const r2 = r + dr;
                  const c2 = c + dc;
                  if (r2 < 8 && c2 >= 0 && c2 < 10 && assignSlot(r, c, rid, perm, off) === assignSlot(r2, c2, rid, perm, off)) {
                    sama++;
                    if (assignVariant(r, c, rid, off2) === assignVariant(r2, c2, rid, off2)) throw new Error(`varian sama untuk kursi ${r},${c} dan ${r2},${c2}`);
                  }
                }
              }
            }
          }
        }
      }
    }
    expect(sama).toBeGreaterThan(0);
  });
  it("seatBase dan parameter sesi deterministik dari sessionId", () => {
    expect([seatBase(0, 0), seatBase(0, 1), seatBase(1, 0), seatBase(1, 1), seatBase(2, 3)]).toEqual([0, 1, 2, 3, 1]);
    const a = distributionParams("sesi-123");
    expect(distributionParams("sesi-123")).toEqual(a);
    expect([...a.perm].sort()).toEqual([0, 1, 2, 3]);
    expect(a.offset).toBeGreaterThanOrEqual(0);
    expect(a.offset).toBeLessThan(4);
    expect([0, 1]).toContain(a.offset2);
    expect(new Set(Array.from({ length: 30 }, (_, i) => distributionParams(`s${i}`).perm.join(""))).size).toBeGreaterThan(1);
  });
});

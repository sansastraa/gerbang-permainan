import { describe, expect, it } from "vitest";
import { announcementPlan, matchNameClip, normalizeName, parseNameList } from "../src";

const CLIPS = ["Adnan Fahreza", "Adnan Sharif", "Budi Santoso", "Citra Dewi Lestari"];

describe("pencocokan nama siswa ke klip suara", () => {
  it("normalisasi: huruf besar/kecil, tanda baca, aksen, spasi ganda", () => {
    expect(normalizeName("  ADNAN   Fahreza. ")).toBe("adnan fahreza");
    expect(normalizeName("Zoë O'Neil-Santoso")).toBe("zoe o neil santoso");
  });

  it("cocok persis (tanpa memandang huruf besar/kecil dan spasi)", () => {
    expect(matchNameClip("adnan fahreza", CLIPS)).toBe(0);
    expect(matchNameClip("Adnan  Sharif", CLIPS)).toBe(1);
  });

  it("dua siswa berawalan sama tidak tertukar", () => {
    expect(matchNameClip("Adnan Fahreza", CLIPS)).toBe(0);
    expect(matchNameClip("Adnan Sharif", CLIPS)).toBe(1);
  });

  it("nama di daftar lebih panjang dari yang diucapkan (atau sebaliknya) tetap cocok bila semua kata ada", () => {
    expect(matchNameClip("Muhammad Adnan Fahreza Putra", CLIPS)).toBe(0);
    expect(matchNameClip("Citra Dewi", CLIPS)).toBe(3);
  });

  it("ambigu atau tidak ada → null (lebih baik diam daripada menyebut nama yang salah)", () => {
    expect(matchNameClip("Adnan", CLIPS)).toBeNull(); // cocok dengan dua klip
    expect(matchNameClip("Dewi", CLIPS)).toBe(3); // satu kata tapi hanya satu klip yang memuatnya
    expect(matchNameClip("Rina Marlina", CLIPS)).toBeNull();
    expect(matchNameClip("", CLIPS)).toBeNull();
    expect(matchNameClip("Budi Santoso", ["Budi Santoso", "Budi Santoso"])).toBeNull(); // klip kembar
  });

  it("parseNameList: satu nama per baris, mengabaikan komentar dan baris kosong", () => {
    expect(parseNameList("# daftar\r\nAdnan Fahreza\n\n  Adnan Sharif  \n#x\n")).toEqual(["Adnan Fahreza", "Adnan Sharif"]);
  });
});
describe("urutan pengumuman hasil ronde", () => {
  it("bunyi benar lalu nama yang punya klip, tercepat dulu, tanpa nama ganda dan sebatas maksimum", () => {
    const plan = announcementPlan(["Adnan Sharif", "Rina Marlina", "Adnan Fahreza", "Adnan Sharif"], 2, CLIPS, 5);
    expect(plan).toEqual([{ kind: "correct" }, { kind: "name", clip: 1, student: "Adnan Sharif" }, { kind: "name", clip: 0, student: "Adnan Fahreza" }]);
    expect(announcementPlan(["Adnan Sharif", "Adnan Fahreza", "Budi Santoso"], 0, CLIPS, 2)).toHaveLength(3);
  });
  it("tanpa yang benar: bunyi salah bila ada yang salah, kosong bila tidak ada pemain", () => {
    expect(announcementPlan([], 3, CLIPS)).toEqual([{ kind: "wrong" }]);
    expect(announcementPlan([], 0, CLIPS)).toEqual([]);
  });
  it("benar tetapi tak satu pun punya klip: hanya bunyi benar", () => {
    expect(announcementPlan(["Rina Marlina"], 0, CLIPS)).toEqual([{ kind: "correct" }]);
    expect(announcementPlan(["Adnan Sharif"], 0, [])).toEqual([{ kind: "correct" }]);
  });
});
describe("klip suara dipilih lewat nomor absen (integrasi SIMPETERI)", () => {
  it("absen N → klip N, tanpa perlu daftar nama; urutan tetap tercepat dulu", () => {
    const plan = announcementPlan([{ name: "Siapa Saja", absen: 7 }, { name: "Lain", absen: 2 }], 0, [], 5, 25);
    expect(plan).toEqual([{ kind: "correct" }, { kind: "name", clip: 6, student: "Siapa Saja" }, { kind: "name", clip: 1, student: "Lain" }]);
  });
  it("absen di luar jumlah klip atau tanpa absen → cocokkan lewat nama; dua siswa tidak memakai klip yang sama dua kali", () => {
    const plan = announcementPlan([{ name: "Adnan Sharif", absen: 40 }, { name: "Budi Santoso", absen: null }, { name: "Orang Lain", absen: 2 }, { name: "Dobel", absen: 2 }], 0, CLIPS, 5, 4);
    expect(plan.filter((s) => s.kind === "name")).toEqual([
      { kind: "name", clip: 1, student: "Adnan Sharif" },
      { kind: "name", clip: 2, student: "Budi Santoso" },
      { kind: "name", clip: 1, student: "Orang Lain" },
    ].filter((s) => s.student !== "Orang Lain"));
  });
  it("absen tidak sah (0, pecahan) diabaikan; string biasa tetap didukung", () => {
    expect(announcementPlan([{ name: "Adnan Fahreza", absen: 0 }, { name: "Citra Dewi Lestari", absen: 1.5 }], 0, CLIPS, 5, 4)).toEqual([
      { kind: "correct" },
      { kind: "name", clip: 0, student: "Adnan Fahreza" },
      { kind: "name", clip: 3, student: "Citra Dewi Lestari" },
    ]);
    expect(announcementPlan(["Budi Santoso"], 0, CLIPS)).toHaveLength(2);
  });
});
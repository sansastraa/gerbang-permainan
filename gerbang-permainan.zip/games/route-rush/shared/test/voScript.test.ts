import { readFileSync } from "node:fs";
import { resolve } from "node:path";
import { describe, expect, it } from "vitest";
import { COPY, parseTimeline, voScript } from "../src";

const tl = parseTimeline(JSON.parse(readFileSync(resolve(__dirname, "../intro/timeline.json"), "utf8")));

describe("naskah narasi (VO)", () => {
  const lines = voScript(tl);
  it("12 baris: 6 narasi trailer, 1 intro ringkas, 5 kalimat tutorial", () => {
    expect(lines.map((l) => l.id)).toEqual(["shot-03", "shot-04", "shot-05", "shot-06", "shot-07", "shot-10", "short", "tutorial-1", "tutorial-2", "tutorial-3", "tutorial-4", "tutorial-5"]);
  });
  it("teks persis sama dengan subtitle/timeline/COPY (satu sumber)", () => {
    expect(lines[0]?.text).toBe("Setiap hari, ada paket yang harus diantar.");
    expect(lines[5]?.text).toBe("Siap? Kita latihan dulu!");
    expect(lines[6]?.text).toBe(COPY.shortIntroVo);
    expect(lines.slice(7).map((l) => l.text)).toEqual([...COPY.tutorial]);
  });
  it("batas durasi: jendela shot dikurangi 0,3 detik; narasi terpendek shot-10 = 1,7 detik", () => {
    expect(lines.find((l) => l.id === "shot-03")?.maxSeconds).toBe(3.7);
    expect(lines.find((l) => l.id === "shot-10")?.maxSeconds).toBe(1.7);
    expect(lines.find((l) => l.id === "short")?.maxSeconds).toBe(3);
  });
});
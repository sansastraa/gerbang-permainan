import fc from "fast-check";
import { describe, expect, it } from "vitest";
import { assertRoundIntegrity } from "../src/integrity";
import { summarizeStudent } from "../src/indices";
import { evaluatePath } from "../src/metrics";
import { buildAdjacency } from "../src/graph";
import { createRoute, isFinished, tapNode, undoLast } from "../src/route";
import { probePoints, racePoints, streakBonuses } from "../src/scoring";
import { optimalCost } from "../src/solver";
import type { MapDef, NodeId } from "../src/types";
import { ALL_BANK_MAPS, FIXTURE, buildResult } from "./helpers";

const RUNS = { numRuns: 500 };
const bankMap = fc.constantFrom(...ALL_BANK_MAPS);

/** Jalan acak valid pada peta bank; berhenti saat rute selesai atau langkah habis. */
function randomWalk(map: MapDef, choices: readonly number[]): NodeId[] {
  const adj = buildAdjacency(map);
  const path: NodeId[] = [map.start];
  for (const c of choices) {
    if (isFinished(map, path)) break;
    const neighbours = [...(adj.get(path[path.length - 1] as NodeId)?.keys() ?? [])];
    path.push(neighbours[c % neighbours.length] as NodeId);
  }
  return path;
}

describe("properti 0A.5", () => {
  it("rute valid dan selesai: playerCost ≥ optimalCost sehingga 0 < ER ≤ 1", () => {
    fc.assert(
      fc.property(bankMap, fc.array(fc.nat(), { minLength: 1, maxLength: 60 }), (map, choices) => {
        const path = randomWalk(map, choices);
        fc.pre(isFinished(map, path));
        const ev = evaluatePath(map, path, false);
        expect(ev.completed).toBe(true);
        expect(ev.playerCost as number).toBeGreaterThanOrEqual(optimalCost(map));
        expect(ev.er).toBeGreaterThan(0);
        expect(ev.er).toBeLessThanOrEqual(1);
        expect(ev.optimalHit).toBe(ev.er === 1);
      }),
      RUNS,
    );
  });

  it("untuk er < 1: poin optimal di t = T lebih besar daripada poin tidak optimal di t = 0", () => {
    fc.assert(
      fc.property(fc.integer({ min: 1, max: 25 }), fc.integer({ min: 1, max: 9 }), fc.integer({ min: 15, max: 40 }), (opt, extra, limit) => {
        const er = opt / (opt + extra);
        const slowOptimal = racePoints({ optimalHit: true, completed: true, er: 1, tSec: limit, limitSec: limit });
        const fastWrong = racePoints({ optimalHit: false, completed: true, er, tSec: 0, limitSec: limit });
        expect(slowOptimal).toBeGreaterThan(fastWrong);
      }),
      RUNS,
    );
  });

  it("racePoints di 0–1000, probePoints di 0–200, streakBonus di 0–300", () => {
    fc.assert(
      fc.property(
        fc.boolean(),
        fc.boolean(),
        fc.double({ min: 0, max: 1, noNaN: true }),
        fc.double({ min: 0, max: 1, noNaN: true }),
        fc.double({ min: 0, max: 5, noNaN: true }),
        fc.array(fc.boolean(), { maxLength: 30 }),
        (optimalHit, completed, er, frac, probeSec, hits) => {
          const race = racePoints({ optimalHit: optimalHit && completed, completed, er, tSec: frac * 30, limitSec: 30 });
          expect(race).toBeGreaterThanOrEqual(0);
          expect(race).toBeLessThanOrEqual(1000);
          const probe = probePoints(completed, probeSec);
          expect(probe).toBeGreaterThanOrEqual(0);
          expect(probe).toBeLessThanOrEqual(200);
          for (const b of streakBonuses(hits)) {
            expect(b).toBeGreaterThanOrEqual(0);
            expect(b).toBeLessThanOrEqual(300);
          }
        },
      ),
      RUNS,
    );
  });

  it("urutan ketukan acak (valid, tidak valid, Batal) selalu menghasilkan state yang lolos assertRoundIntegrity", () => {
    fc.assert(
      fc.property(bankMap, fc.array(fc.nat({ max: 9 }), { minLength: 0, maxLength: 40 }), (map, actions) => {
        let state = createRoute(map);
        actions.forEach((a, i) => {
          const tMs = (i + 1) * 400;
          state = a === 9 ? undoLast(map, state, tMs) : tapNode(map, state, `n${a % map.nodes.length}`, tMs);
        });
        const lastMs = state.tapLog.length ? (state.tapLog[state.tapLog.length - 1] as { tMs: number }).tMs : 0;
        const result = buildResult(map, {
          path: state.path,
          tRouteMs: state.done ? lastMs : 40_000,
          timeLimitS: 40,
          timedOut: !state.done,
          tapLog: state.tapLog,
        });
        expect(() => assertRoundIntegrity(result, map)).not.toThrow();
        expect(state.invalidTaps).toBe(result.invalidTaps);
        expect(state.undo).toBe(result.undo);
        expect(state.revisits).toBe(result.revisits);
      }),
      RUNS,
    );
  });

  it("IL, IM, IS selalu di 0–100 atau null", () => {
    const candidates: NodeId[][] = [["n0", "n1", "n2", "n3", "n5"], ["n0", "n2", "n3", "n5"], ["n0", "n1", "n2", "n4", "n5"], ["n0", "n1", "n0", "n1", "n2", "n3", "n5"], ["n0", "n1"]];
    const round = fc.record({
      pathIndex: fc.nat({ max: candidates.length - 1 }),
      missed: fc.boolean(),
      hidden: fc.boolean(),
      timedOut: fc.boolean(),
      probeCorrect: fc.boolean(),
      tSec: fc.integer({ min: 0, max: 25 }),
    });
    fc.assert(
      fc.property(fc.array(round, { maxLength: 11 }), (rounds) => {
        const results = rounds.map((r, i) => {
          const path = candidates[r.pathIndex] as NodeId[];
          const timedOut = r.timedOut || r.pathIndex === 4;
          return buildResult(FIXTURE, {
            path,
            missed: r.missed,
            timedOut: !r.missed && timedOut,
            roundId: i,
            condition: r.hidden ? "HIDDEN" : "VISIBLE",
            probeCorrect: r.hidden ? r.probeCorrect : null,
            probeMs: r.hidden ? 2000 : null,
            tRouteMs: timedOut ? 25_000 : r.tSec * 1000,
            timeLimitS: 25,
          });
        });
        const s = summarizeStudent("s", results);
        for (const v of [s.il, s.im, s.is]) {
          if (v !== null) {
            expect(v).toBeGreaterThanOrEqual(0);
            expect(v).toBeLessThanOrEqual(100);
          }
        }
        expect(s.timeoutRate).toBeGreaterThanOrEqual(0);
        expect(s.timeoutRate).toBeLessThanOrEqual(1);
      }),
      RUNS,
    );
  });
});

import { describe, expect, it } from "vitest";
import { defaultSettings, fieldCheck, fieldCheckMarkdown, mulberry32, type RoundResult, type SessionExportData, type TutorialResult } from "../src";

const N = 28;
const ROUNDS = [1, 2, 3, 4];

function make(over: { oh?: (round: number, slot: number) => number; reach?: (round: number) => number; erBySlot?: (slot: number) => number } = {}): SessionExportData {
  const rnd = mulberry32(99);
  const rounds: RoundResult[] = [];
  for (let i = 0; i < N; i++) {
    for (const rid of ROUNDS) {
      const slot = ((i + rid) % 4) as 0 | 1 | 2 | 3;
      const variantId = (i * 3 + rid) % 8;
      const hit = rnd() < (over.oh ? over.oh(rid, slot) : 0.6);
      const timedOut = rnd() > (over.reach ? over.reach(rid) : 1);
      const er = timedOut ? 0 : hit ? 1 : Math.min(0.99, (over.erBySlot ? over.erBySlot(slot) : 0.8) + (rnd() - 0.5) * 0.2);
      rounds.push({
        sessionId: "F1", studentId: `s${i}`, nickname: `Siswa ${i}`, form: "A", mode: "STANDARD", roundId: rid, condition: rid % 2 === 0 ? "HIDDEN" : "VISIBLE", variantId, itemId: `PA-0${rid}-${slot}`, itemSlot: slot,
        seatMode: "SEATED", seatRow: 0, seatCol: i % 8, focusLost: 0, fullscreenExits: 0, integrityFlags: [], nNodes: 6, nEdges: 8, nStops: 0, timeLimitS: 25, optimalCost: 8, playerCost: timedOut ? null : 8,
        playerPath: [], completed: !timedOut, optimalHit: hit && !timedOut, timedOut, missed: false, er, tFirstMs: 800, tRouteMs: 6000, invalidTaps: 0, undo: 0, revisits: 0, steps: 3, probeCorrect: null, probeMs: null,
        racePoints: 0, streakBonus: 0, probePoints: 0, rankAfter: 1, errorType: "NONE", tapLog: [],
      });
    }
  }
  const tut = (i: number): TutorialResult => ({ sessionId: "F1", studentId: `s${i}`, completed: true, totalMs: 60_000, step3Attempts: 1, hints: 0, probeCorrect: true, autoDemoSteps: [], steps: [] });
  return {
    sessionId: "F1", kind: "LIVE", form: "A", mode: "STANDARD", introMode: "FULL", createdAt: 1_760_000_000_000,
    players: Array.from({ length: N }, (_, i) => ({ studentId: `s${i}`, name: `Siswa ${i}`, isBot: false })), rounds,
    tutorials: Array.from({ length: N }, (_, i) => ({ isBot: false, result: tut(i) })), integrityEvents: [],
    settings: { ...defaultSettings(N), roundIds: ROUNDS }, startedAt: 1_000_000, podiumAt: 1_000_000 + 200_000, endedAt: 1_000_000 + 220_000,
  };
}

const status = (fc: ReturnType<typeof fieldCheck>, id: string) => fc.checks.find((c) => c.id === id)?.status;

describe("pemeriksaan lapangan (Fase 9)", () => {
  it("kelas yang sehat: kesepuluh pemeriksaan lulus dan tidak ada yang ditandai", () => {
    const fc = fieldCheck(make(), 0);
    expect(fc.checks).toHaveLength(10);
    expect(fc.checks.map((c) => `${c.id}:${c.status}`)).toEqual(["C1:LULUS", "C2:LULUS", "C3:LULUS", "C4:LULUS", "C5:LULUS", "C6:LULUS", "C7:LULUS", "C8:LULUS", "C9:LULUS", "C10:LULUS"]);
    expect(fc.verdict).toBe("LULUS");
    expect(fc.flaggedRounds).toEqual([]);
    expect(fc.flaggedItems).toEqual([]);
    expect(fc.rounds).toHaveLength(4);
  });

  it("C1: kurang dari 90% menyelesaikan sesi → GAGAL", () => {
    const d = make();
    d.rounds = d.rounds.map((r) => (["s0", "s1", "s2", "s3"].includes(r.studentId) && r.roundId === 4 ? { ...r, missed: true } : r)); // 4/28 = 14% tidak selesai
    expect(status(fieldCheck(d, 0), "C1")).toBe("GAGAL");
  });

  it("C2/C3: demo otomatis, langkah 3 terlalu banyak percobaan, atau tanpa laporan → GAGAL; sesi lanjutan tidak berlaku", () => {
    const d = make();
    d.tutorials = d.tutorials.map((t, i) => (i < 6 ? { ...t, result: { ...t.result, completed: false, autoDemoSteps: [5] } } : i < 16 ? { ...t, result: { ...t.result, step3Attempts: 3 } } : t));
    const fc = fieldCheck(d, 0);
    expect(status(fc, "C2")).toBe("GAGAL"); // 22/28 = 78,6% < 85%
    expect(status(fc, "C3")).toBe("GAGAL"); // 18/28 = 64,3% < 70% (10 siswa butuh 3 percobaan)
    const short = fieldCheck({ ...make(), introMode: "SHORT" }, 0);
    expect(status(short, "C2")).toBe("TIDAK BERLAKU");
    expect(status(short, "C3")).toBe("TIDAK BERLAKU");
    expect(fieldCheck({ ...make(), tutorials: [] }, 0).checks.find((c) => c.id === "C3")?.value).toContain("0/28");
  });

  it("C4: hasil ditolak > 0 → GAGAL dengan petunjuk berkas", () => {
    const fc = fieldCheck(make(), 2);
    expect(status(fc, "C4")).toBe("GAGAL");
    expect(fc.checks.find((c) => c.id === "C4")?.detail).toContain("rejected");
    expect(fc.verdict).toBe("TIDAK LULUS");
  });

  it("C5: ronde dengan banyak yang kehabisan waktu ditandai", () => {
    const fc = fieldCheck(make({ reach: (r) => (r === 3 ? 0.6 : 0.97) }), 0);
    expect(status(fc, "C5")).toBe("GAGAL");
    expect(fc.checks.find((c) => c.id === "C5")?.detail).toContain("3");
    expect(fc.flaggedRounds).toContain(3);
  });

  it("C6: proporsi OH di luar 0,30–0,80 ditandai untuk diganti", () => {
    const fc = fieldCheck(make({ oh: (r) => (r === 2 ? 0.95 : r === 4 ? 0.05 : 0.6) }), 0);
    expect(status(fc, "C6")).toBe("GAGAL");
    expect(fc.flaggedRounds).toEqual(expect.arrayContaining([2, 4]));
    expect(fc.rounds.find((r) => r.roundId === 2)?.issues.join(" ")).toMatch(/proporsi OH/);
  });

  it("C7: durasi melewati batas (hitung mundur + tutorial + ronde maksimal) → GAGAL; tanpa penanda → data kurang", () => {
    const d = make();
    const over = fieldCheck({ ...d, podiumAt: (d.startedAt as number) + 3_000_000 }, 0);
    expect(status(over, "C7")).toBe("GAGAL");
    const none = fieldCheck({ ...d, startedAt: null, podiumAt: null }, 0);
    expect(status(none, "C7")).toBe("DATA KURANG");
    expect(none.verdict).toBe("BELUM LENGKAP");
  });

  it("C9: selisih rerata ER besar tanpa uji p yang gagal hanyalah penanda (tidak GAGAL), dan soalnya dipantau", () => {
    const d = make({ oh: () => 0.4 });
    // jadikan satu slot sedikit lebih rendah (selisih > 0,15) namun sebaran masih acak sehingga p > 0,05
    d.rounds = d.rounds.map((r) => (r.roundId === 2 && r.itemSlot === 1 && !r.optimalHit ? { ...r, er: 0.3 } : r));
    const fc = fieldCheck(d, 0);
    const r2 = fc.rounds.find((r) => r.roundId === 2)!;
    if (r2.slotP !== null && r2.slotP >= 0.05 && r2.marks.length > 0) {
      expect(status(fc, "C9")).toBe("LULUS");
      expect(fc.watchItems.some((w) => w.roundId === 2)).toBe(true);
      expect(fc.flaggedItems.some((w) => w.roundId === 2)).toBe(false);
      expect(fc.checks.find((c) => c.id === "C9")?.detail).toContain("penanda");
      expect(fieldCheckMarkdown(fc)).toContain("Dipantau (penanda saja");
    } else expect(r2.slotP).not.toBeNull(); // data acak tidak menghasilkan kasus ini: uji di bawah menutupnya secara deterministik
  });

  it("C9 (deterministik): selisih > 0,15 dengan p > 0,05 → LULUS + dipantau; p < 0,05 → GAGAL + diganti", () => {
    const mk = (ers: number[][]): SessionExportData => {
      const d = make();
      d.rounds = [];
      let i = 0;
      ers.forEach((group, slot) =>
        group.forEach((er) => {
          d.rounds.push({ ...make().rounds[0]!, studentId: `s${i++ % N}`, roundId: 1, itemSlot: slot as 0 | 1 | 2 | 3, itemId: `PA-01-${slot}`, er, optimalHit: er === 1, completed: true, timedOut: false, missed: false });
        }),
      );
      return d;
    };
    // rerata slot 0 = 0,60 vs 0,80 (selisih 0,20) tetapi sebaran tumpang-tindih → p > 0,05
    const overlap = [[0.2, 0.4, 0.6, 0.8, 1, 1], [0.4, 0.6, 0.8, 0.9, 1, 1], [0.3, 0.6, 0.7, 0.9, 1, 1], [0.5, 0.7, 0.8, 1, 1, 1]].map((g) => g.slice());
    const marked = fieldCheck(mk(overlap), 0);
    const r = marked.rounds[0]!;
    expect((r.slotSpread as number) > 0.15).toBe(true);
    expect((r.slotP as number) > 0.05).toBe(true);
    expect(status(marked, "C9")).toBe("LULUS");
    expect(marked.watchItems).toHaveLength(1);
    expect(marked.flaggedItems).toHaveLength(0);
    expect(marked.flaggedRounds).not.toContain(1);
    // sebaran terpisah jelas → p < 0,05 → gagal
    const apart = fieldCheck(mk([[0.2, 0.25, 0.3, 0.2, 0.25, 0.3], [0.8, 0.85, 0.9, 0.8, 0.85, 0.9], [0.8, 0.85, 0.9, 0.82, 0.88, 0.91], [0.81, 0.86, 0.9, 0.83, 0.87, 0.92]]), 0);
    expect(status(apart, "C9")).toBe("GAGAL");
    expect(apart.flaggedItems.map((f) => f.slot)).toEqual([0]);
    expect(apart.watchItems).toHaveLength(0);
  });

  it("C9: satu soal jauh lebih sulit → ditandai (diganti bila p gagal, dipantau bila hanya selisih) dengan rerata ER pembanding", () => {
    const fc = fieldCheck(make({ erBySlot: (s) => (s === 2 ? 0.45 : 0.85), oh: () => 0.4 }), 0);
    const all = [...fc.flaggedItems, ...fc.watchItems];
    expect(all.length).toBeGreaterThan(0);
    const f = all[0]!;
    expect(f.slot).toBe(2);
    expect(f.itemId).toMatch(/^PA-0\d-2$/);
    expect(f.meanEr).toBeLessThan(f.othersMeanEr);
    expect(["LULUS", "GAGAL"]).toContain(status(fc, "C9"));
  });

  it("C8/C9 data kurang pada sampel kecil; C10 turun bila banyak siswa tanpa denah", () => {
    const small = make();
    small.players = small.players.slice(0, 6);
    small.rounds = small.rounds.filter((r) => ["s0", "s1", "s2", "s3", "s4", "s5"].includes(r.studentId));
    const fc = fieldCheck(small, 0);
    expect(status(fc, "C8")).toBe("DATA KURANG");
    expect(status(fc, "C9")).toBe("DATA KURANG");
    const noSeat = make();
    noSeat.rounds = noSeat.rounds.map((r) => (Number(r.studentId.slice(1)) < 5 ? { ...r, seatMode: "NO_SEAT" as const } : r));
    expect(status(fieldCheck(noSeat, 0), "C10")).toBe("GAGAL"); // 23/28 = 82%
  });

  it("C8: varian yang jelas berbeda → GAGAL", () => {
    const d = make();
    d.rounds = d.rounds.map((r) => ({ ...r, er: r.variantId < 4 ? 0.4 : 1, optimalHit: r.variantId >= 4, playerCost: 8, completed: true, timedOut: false }));
    expect(status(fieldCheck(d, 0), "C8")).toBe("GAGAL");
  });

  it("laporan Markdown: ringkasan 10 baris, tabel per ronde, tindak lanjut, dan peringatan data TEST", () => {
    const fc = fieldCheck(make({ erBySlot: (s) => (s === 2 ? 0.45 : 0.85), oh: () => 0.4 }), 0);
    const md = fieldCheckMarkdown(fc);
    expect(md).toContain("# Pemeriksaan lapangan — sesi F1");
    expect(md).toContain(`**Hasil: ${fc.verdict}**`);
    expect((md.match(/^\| C\d+ \|/gm) ?? []).length).toBe(10);
    expect(md).toContain("## Per ronde");
    expect(md).toMatch(/Dipantau \(penanda saja|Pool C, D/);
    expect(md).toMatch(/Soal \*\*PA-0\d-2\*\*/);
    expect(md).not.toContain("data TEST/bot");
    expect(fieldCheckMarkdown(fieldCheck({ ...make(), kind: "TEST" }, 0))).toContain("data TEST/bot");
    expect(fieldCheckMarkdown(fieldCheck(make(), 0))).toContain("Tidak ada ronde atau soal yang perlu diganti");
    // kelas kecil: peringatan sampel (±7 siswa per soal) dan fc.lowPower
    expect(fieldCheck(make(), 0).lowPower).toBe(true);
    expect(fieldCheckMarkdown(fieldCheck(make(), 0))).toContain("Gabungkan beberapa kelas");
    expect(fieldCheckMarkdown(fieldCheck(make(), 0))).toContain("tidak menggagalkan pemeriksaan");
  });
});
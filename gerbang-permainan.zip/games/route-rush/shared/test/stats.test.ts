import { describe, expect, it } from "vitest";
import { chiSquareSf, kruskalWallis } from "../src";

describe("distribusi khi-kuadrat", () => {
  it("nilai baku: P(X ≥ 3,841; df 1) = 0,05; P(X ≥ 5,991; df 2) = 0,05; P(X ≥ 0) = 1", () => {
    expect(chiSquareSf(3.841459, 1)).toBeCloseTo(0.05, 4);
    expect(chiSquareSf(5.991465, 2)).toBeCloseTo(0.05, 4);
    expect(chiSquareSf(0, 3)).toBe(1);
    expect(chiSquareSf(-1, 3)).toBe(1);
    expect(chiSquareSf(9.487729, 4)).toBeCloseTo(0.05, 4);
    expect(chiSquareSf(100, 2)).toBeLessThan(1e-20);
    expect(chiSquareSf(1, 10)).toBeGreaterThan(0.99);
  });
});

describe("Kruskal-Wallis", () => {
  it("contoh tanpa nilai kembar: H = 7,2, df 2, p = 0,0273", () => {
    const r = kruskalWallis([[1, 2, 3], [4, 5, 6], [7, 8, 9]])!;
    expect(r.h).toBeCloseTo(7.2, 6);
    expect(r.df).toBe(2);
    expect(r.p).toBeCloseTo(0.02732, 4);
    expect(r.n).toBe(9);
  });
  it("koreksi nilai kembar: [1,1] vs [2,2] → H = 3, p = 0,0833", () => {
    const r = kruskalWallis([[1, 1], [2, 2]])!;
    expect(r.h).toBeCloseTo(3, 6);
    expect(r.p).toBeCloseTo(0.0833, 3);
  });
  it("kelompok yang sebanding → p besar; urutan kelompok dan nilai tidak memengaruhi hasil", () => {
    const a = kruskalWallis([[0.8, 1, 0.9, 1], [1, 0.9, 0.8, 1], [0.9, 1, 1, 0.8]])!;
    const b = kruskalWallis([[1, 0.9, 0.8, 1], [0.9, 1, 1, 0.8], [0.8, 1, 0.9, 1]])!;
    expect(a.p).toBeGreaterThan(0.5);
    expect(b.h).toBeCloseTo(a.h, 10);
  });
  it("tidak terdefinisi: kurang dari dua kelompok berisi, atau semua nilai sama", () => {
    expect(kruskalWallis([[1, 2, 3]])).toBeNull();
    expect(kruskalWallis([[1, 2], []])).toBeNull();
    expect(kruskalWallis([[1, 1], [1, 1]])).toBeNull();
    expect(kruskalWallis([])).toBeNull();
  });
});
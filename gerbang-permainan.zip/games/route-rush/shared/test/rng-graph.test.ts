import { describe, expect, it } from "vitest";
import { buildAdjacency, cartesian, dijkstra, edgeId, hasEdge, pathCost, permutations, simplePaths } from "../src/graph";
import { createRng, hashString, mulberry32 } from "../src/rng";
import { FIXTURE } from "./helpers";

describe("rng.ts", () => {
  it("deterministik untuk seed yang sama dan berbeda untuk seed berbeda", () => {
    const a = Array.from({ length: 5 }, mulberry32(42));
    const b = Array.from({ length: 5 }, mulberry32(42));
    expect(a).toEqual(b);
    expect(a).not.toEqual(Array.from({ length: 5 }, mulberry32(43)));
    expect(hashString("RR-POOL-A")).toBe(hashString("RR-POOL-A"));
    expect(hashString("a")).not.toBe(hashString("b"));
  });

  it("int, pick, dan shuffle bekerja dan tidak mengubah input", () => {
    const rng = createRng("uji");
    expect(Array.from({ length: 200 }, () => rng.int(7)).every((n) => n >= 0 && n < 7)).toBe(true);
    const items = [1, 2, 3, 4, 5];
    const shuffled = createRng(7).shuffle(items);
    expect(items).toEqual([1, 2, 3, 4, 5]);
    expect([...shuffled].sort()).toEqual(items);
    expect(items).toContain(createRng(1).pick(items));
    expect(() => createRng(1).pick([])).toThrow(RangeError);
    expect(createRng(5).next()).toBe(createRng(5).next());
  });

  it("seed teks dan seed angka dapat dipakai", () => {
    expect(createRng("x").next()).toBeGreaterThanOrEqual(0);
    expect(createRng(99).next()).toBeLessThan(1);
  });
});

describe("graph.ts", () => {
  it("edgeId menaruh node kecil di depan", () => {
    expect(edgeId("n3", "n0")).toBe("n0-n3");
    expect(edgeId("n1", "n2")).toBe("n1-n2");
  });

  it("buildAdjacency, hasEdge, pathCost, dan dijkstra pada fixture", () => {
    const adj = buildAdjacency(FIXTURE);
    expect(hasEdge(adj, "n0", "n1")).toBe(true);
    expect(hasEdge(adj, "n0", "n5")).toBe(false);
    expect(hasEdge(adj, "zz", "n0")).toBe(false);
    expect(pathCost(FIXTURE, ["n0", "n1", "n2"])).toBe(4);
    expect(pathCost(FIXTURE, ["n0", "n5"])).toBeNull();
    expect(pathCost(FIXTURE, [])).toBeNull();
    expect(dijkstra(FIXTURE, "n0", "n5")).toBe(8);
    expect(dijkstra(FIXTURE, "n0", "n5", true)).toBe(3);
    expect(dijkstra(FIXTURE, "n0", "n0")).toBe(0);
    expect(dijkstra({ nodes: FIXTURE.nodes, edges: [] }, "n0", "n5")).toBe(Infinity);
  });

  it("simplePaths tidak berulang node dan permutations/cartesian meniru itertools", () => {
    const adj = buildAdjacency(FIXTURE);
    const paths = simplePaths(adj, "n0", "n5");
    expect(paths.length).toBeGreaterThan(1);
    expect(paths.every((p) => new Set(p).size === p.length && p[0] === "n0" && p[p.length - 1] === "n5")).toBe(true);
    expect(permutations([])).toEqual([[]]);
    expect(permutations(["a", "b"])).toEqual([["a", "b"], ["b", "a"]]);
    expect(cartesian([[1, 2], [3, 4]])).toEqual([[1, 3], [1, 4], [2, 3], [2, 4]]);
    expect(cartesian([])).toEqual([[]]);
  });
});

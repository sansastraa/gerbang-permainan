import formA from "../maps/formA.json";
import formB from "../maps/formB.json";
import poolAJson from "../maps/poolA.json";
import poolBJson from "../maps/poolB.json";
import tutorialJson from "../maps/tutorial.json";
import timelineJson from "../intro/timeline.json";
import { parseFormBank, parsePool, parseTutorial } from "../src/dataLoaders";
import { parseTimeline } from "../src/introTimeline";

export const RAW = { formA, formB, poolA: poolAJson, poolB: poolBJson, tutorial: tutorialJson, timeline: timelineJson };

export const BANK_A = parseFormBank(formA);
export const BANK_B = parseFormBank(formB);
export const POOL_A = parsePool(poolAJson);
export const POOL_B = parsePool(poolBJson);
export const TUTORIAL = parseTutorial(tutorialJson);
export const TIMELINE = parseTimeline(timelineJson);

/** Peta fixture bank bertipe MapDef dengan `roundId` terpisah. */
export const FORM_BANK_MAPS = [...BANK_A.maps, ...BANK_B.maps];

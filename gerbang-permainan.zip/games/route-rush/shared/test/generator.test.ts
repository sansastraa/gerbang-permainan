import { spawn } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { createRequire } from "node:module";
import { dirname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";
import { describe, expect, it } from "vitest";
import { generateMap, specOf } from "../src/generator";
import { buildPool } from "../src/poolBuilder";
import { createRng } from "../src/rng";
import { ROUND_CONFIGS } from "../src/rounds";
import { analyzeRoutes } from "../src/solver";
import type { RoundConfig } from "../src/types";
import { validateMap } from "../src/validator";

const cfg = (id: number): RoundConfig => ROUND_CONFIGS[id] as RoundConfig;
const ROOT = resolve(dirname(fileURLToPath(import.meta.url)), "../..");

describe("generateMap (Bagian 8.2)", () => {
  it("20 peta dari seed berbeda dan ronde berbeda semuanya lolos validator V1–V9", () => {
    const rounds = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 1, 3, 5, 7, 9, 2, 4, 8, 10];
    rounds.forEach((rid, i) => {
      const spec = specOf(cfg(rid));
      const { map, info } = generateMap(spec, createRng(`seed-uji-${i}`), `G-${i}`);
      expect(validateMap(map, spec).codes, `seed ${i} ronde ${rid}`).toEqual([]);
      expect(info.opt).toBeGreaterThan(0);
      expect(map.nodes).toHaveLength(spec.nNodes);
      expect(map.edges).toHaveLength(spec.nEdges);
      expect(map.nodes[0]!.kind).toBe("home");
      expect(map.nodes[spec.nNodes - 1]!.kind).toBe("school");
      if (spec.condition === "HIDDEN") expect(map.probeEdgeId).toBeDefined();
      else expect(map.probeEdgeId).toBeUndefined();
    });
  });

  it("deterministik: seed sama → peta sama; seed berbeda → peta berbeda", () => {
    const spec = specOf(cfg(5));
    const a = generateMap(spec, createRng("sama"), "X").map;
    expect(generateMap(spec, createRng("sama"), "X").map).toEqual(a);
    expect(generateMap(spec, createRng("lain"), "X").map).not.toEqual(a);
  });

  it("selisih pasangan (V7) dapat dipaksakan untuk ronde HIDDEN", () => {
    const visible = generateMap(specOf(cfg(3)), createRng("pasangan"), "V");
    const hidden = generateMap(specOf(cfg(4)), createRng("pasangan-2"), "H", visible.info.gap);
    expect(analyzeRoutes(hidden.map)!.gap).toBe(visible.info.gap);
    expect(validateMap(hidden.map, cfg(4), visible.info.gap).ok).toBe(true);
  });
});

describe("buildPool (bank baru dari generator TypeScript)", () => {
  it("gagal dengan pesan jelas bila tidak ada cukup soal setara; seed menentukan huruf bank", () => {
    expect(() => buildPool("RR-POOL-Y", { samples: 1, rounds: 1 })).toThrow(/tidak punya cukup soal setara/);
  });
  // Jalur sukses (41 soal, P1–P4, deterministik) ditelusuri penuh oleh gen-pool-script.test.ts, yang menjalankan
  // skrip di proses terpisah pada kecepatan asli (±40 dtk); di dalam proses berinstrumen cakupan ia terlalu lambat.
});
describe("scripts/gen-pool.ts menolak menimpa data acuan", () => {
  const tsx = createRequire(import.meta.url).resolve("tsx/cli");
  const run = (...args: string[]): Promise<{ status: number | null; stderr: string }> =>
    new Promise((done, fail) => {
      const child = spawn(process.execPath, [tsx, join(ROOT, "scripts/gen-pool.ts"), ...args], { cwd: ROOT });
      let stderr = "";
      child.stderr.on("data", (d: Buffer) => (stderr += d.toString("utf8")));
      child.on("error", fail);
      child.on("close", (status) => done({ status, stderr }));
    });

  it("tanpa --seed → kode 2; Pool A/B → ditolak; berkas yang sudah ada → ditolak dan tidak berubah", async () => {
    const before = readFileSync(join(ROOT, "shared/maps/poolA.json"), "utf8");
    expect((await run()).status).toBe(2);
    const a = await run("--seed", "RR-POOL-A");
    expect(a.status).toBe(1);
    expect(a.stderr).toContain("DITOLAK");
    const exist = await run("--seed", "RR-POOL-C", "--out", "shared/maps/poolA.json");
    expect(exist.status).toBe(1);
    expect(exist.stderr).toContain("sudah ada");
    expect(readFileSync(join(ROOT, "shared/maps/poolA.json"), "utf8")).toBe(before);
    expect(existsSync(join(ROOT, "shared/maps/poolC.json"))).toBe(false);
  });
});

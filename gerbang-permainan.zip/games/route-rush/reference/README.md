# Oracle referensi (Python)

Implementasi acuan untuk memverifikasi angka di SPEC.md. Bukan bagian dari aplikasi.

```
cd reference
python3 test_oracle.py      # wajib: 65/65 lulus
python3 render.py           # (butuh matplotlib) gambar pratinjau peta
```

`gen.py` adalah generator yang membuat `shared/maps/formA.json` dan `formB.json`
(seed KC-2026-A dan KC-2026-B). Jangan jalankan untuk menimpa bank peta; bila
dijalankan, file keluaran ditulis ke folder `reference/`.

`pool.py` membuat bank soal paralel `shared/maps/poolA.json` dan `poolB.json`
(4 soal setara per ronde, kompleksitas naik). Fungsi pembagian soal per kursi
(`assign_slot`, `assign_variant`) ada di `oracle.py`.

import json, matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
from oracle import optimal_route
NAME={"home":"Rumah","school":"Sekolah","market":"Pasar","park":"Taman","mosque":"Masjid","shop":"Toko","library":"Perpus","clinic":"Puskesmas","field":"Lapangan"}
for f in "AB":
    bank=json.load(open(f"../shared/maps/form{f}.json")); fig,axs=plt.subplots(3,4,figsize=(16,10),dpi=80)
    for ax,m in zip(axs.flat,bank["maps"]):
        P={n["id"]:(n["x"],1-n["y"]) for n in m["nodes"]}; r,_=optimal_route(m); oe={tuple(sorted(p)) for p in zip(r,r[1:])}
        for e in m["edges"]:
            a,b=P[e["a"]],P[e["b"]]; o=tuple(sorted((e["a"],e["b"]))) in oe
            ax.plot([a[0],b[0]],[a[1],b[1]],color="#2E7D32" if o else "#aaa",lw=4 if o else 2.5,zorder=1)
            ax.text((a[0]+b[0])/2,(a[1]+b[1])/2,str(e["w"]),ha="center",va="center",fontsize=10,fontweight="bold",bbox=dict(boxstyle="circle",fc="#FFF8E1",ec="#F9A825"),zorder=3,
                    color="red" if e["id"]==m.get("probeEdgeId") else "black")
        for n in m["nodes"]:
            c="#1565C0" if n["kind"]=="home" else "#C62828" if n["kind"]=="school" else ("#EF6C00" if n["id"] in m["stops"] else "#5E35B1")
            ax.scatter(*P[n["id"]],s=500,color=c,zorder=2); ax.text(P[n["id"]][0],P[n["id"]][1]-0.09,NAME[n["kind"]],ha="center",fontsize=8)
        ax.set_title(f'{m["id"]} r{m["roundId"]}',fontsize=10); ax.set_xlim(-0.05,1.05); ax.set_ylim(-0.1,1.05); ax.axis("off")
    axs.flat[-1].axis("off"); plt.tight_layout(); plt.savefig(f"preview_form{f}.png")

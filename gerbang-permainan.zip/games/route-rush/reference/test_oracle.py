import json, copy
from oracle import *
from gen import validate, ROUNDS, FIXTURE, seg_cross
F=FIXTURE; A=json.load(open("../shared/maps/formA.json")); B=json.load(open("../shared/maps/formB.json"))
CFG={c[0]:c for c in ROUNDS}
res=[]
def check(name,got,exp):
    ok=(abs(got-exp)<1e-9) if isinstance(exp,float) and isinstance(got,(int,float)) else got==exp
    res.append((name,ok,got,exp))
fmt1=lambda x: round(x+1e-12,1)

check("T1 optimalCost fixture",optimal_cost(F),8)
check("T2 optimalRoute fixture",optimal_route(F)[0],["n0","n1","n2","n3","n5"])
check("T3 minHops fixture",min_hops(F),3)
ok,info,fails=validate(F,CFG[5]); check("T4 validator fixture trap",(ok,info["gap"]),(True,1))
check("T5 Ani",race_points(True,True,1.0,12,25),760)
erb=8/9; check("T6a Budi ER",round(erb,4),0.8889)
check("T6b Budi poin",race_points(False,True,erb,6,25),391)
check("T6c Budi error",error_type(F,["n0","n2","n3","n5"],True,False,8),"FEW_ROADS_TRAP")
check("T7 Citra",race_points(True,True,1.0,24,25),520)
check("T8 Dodi",(race_points(False,False,0,25,25),error_type(F,["n0","n1"],False,True,8)),(0,"TIMEOUT"))
check("T9 tepat>cepat",race_points(True,True,1,25,25)>race_points(False,True,0.99,0,25),True)
check("T9b nilai",(race_points(True,True,1,25,25),race_points(False,True,0.99,0,25)),(500,495))
check("T10 streak",streak_bonuses([1,1,1,1,1]),[0,100,200,300,300])
check("T10b streak putus",streak_bonuses([1,1,0,1,1]),[0,100,0,0,100])
check("T11 probe 2s",probe_points(True,2),160)
check("T11b probe salah",probe_points(False,1),0)
erv=[1,1,0.89,1,0.8]; ohv=[1,1,0,1,0]
check("T12 IL",fmt1(IL(erv,ohv)),80.3)
im,mc=IM(erv,[1,0.8,0.89,0,1],0.8)
check("T13 IM",fmt1(im),79.3); check("T13b memoryCost",round(mc,3),0.2)
check("T14 IS",fmt1(IS(3,40,2,1)),92.8)
check("T14b IS L=0",IS(0,0,0,0),None)
check("T15 RTM",RTM(6,180),2.0)
r=Route(F); r.tap("n3"); check("T16 invalid tap",(r.inv,r.path),(1,["n0"]))
r=Route(F); r.tap("n1"); r.tap("n0"); check("T17 revisit",(r.rev,r.steps,r.cost),(1,2,4))
r=Route(F); r.tap("n1"); r.undo_(); r.undo_(); check("T18 undo",(r.path,r.undo),(["n0"],1))
r=Route(F); r.tap("n0"); check("T18b ketuk posisi sendiri",(r.inv,r.path),(0,["n0"]))
# T19 varian
def variant(m,v):
    m=copy.deepcopy(m)
    for n in m["nodes"]:
        x,y=n["x"]-0.5,n["y"]-0.5
        for _ in range(v%4): x,y=-y,x
        if v>=4: x=-x
        n["x"],n["y"]=round(x+0.5,6),round(y+0.5,6)
    return m
allmaps=[("A",x) for x in A["maps"]]+[("B",x) for x in B["maps"]]
okv=True
for f,m in allmaps:
    oc=optimal_cost(m)
    for v in range(8):
        vm=variant(m,v)
        if optimal_cost(vm)!=oc or [n["id"] for n in vm["nodes"]]!=[n["id"] for n in m["nodes"]] or not all(0<=n["x"]<=1 and 0<=n["y"]<=1 for n in vm["nodes"]): okv=False
        P={n["id"]:(n["x"],n["y"]) for n in vm["nodes"]}
        E=[(P[e["a"]],P[e["b"]]) for e in vm["edges"]]
        if any(seg_cross(*E[i],*E[j]) for i in range(len(E)) for j in range(i+1,len(E))): okv=False
check("T19 varian 8 simetri x 22 peta",okv,True)
# T20 bank peta lolos V1-V8, pasangan V7
allok=True; detail=[]
for bank in (A,B):
    gaps={}
    for m in bank["maps"]:
        c=CFG[m["roundId"]]; pg=gaps.get(m["roundId"]-1) if c[1]=="HIDDEN" else None
        ok,info,fails=validate(m,c,pg); gaps[m["roundId"]]=info["gap"]
        if not ok: allok=False; detail.append((m["id"],fails))
check("T20 bank A&B lolos V1-V8",(allok,detail),(True,[]))
A9=[x for x in A["maps"] if x["roundId"]==9][0]
p=["n0","n5","n2","n0","n4","n6"]
check("T21 STOP_ORDER di A-09",(path_cost(A9,p),error_type(A9,p,True,False,optimal_cost(A9))),(26,"STOP_ORDER"))
check("T22 A-05 identik fixture",{k:v for k,v in A["maps"][5].items() if k!="roundId"}==F,True)
# durasi
look={c[0]:c[6] for c in ROUNDS}; walk={c[0]:c[7] for c in ROUNDS}
def dur(ids): return sum(look[i]+walk[i]+(5000 if CFG[i][1]=="HIDDEN" else 0)+3000+(3000 if CFG[i][8] else 0) for i in ids)/1000
std=dur(range(0,11)); quick=dur([0,1,2,3,4,7,8])
check("T23 durasi ronde Standar maks (dtk) ≤ 480",std<=480,True)
check("T23b durasi ronde Kilat maks (dtk) ≤ 270",quick<=270,True)

# T20b test negatif validator
import copy as _c
m=_c.deepcopy(F)
for e in m["edges"]:
    if e["id"]=="n0-n2": e["w"]=4      # n0-n2-n3-n5 = 8, sama dengan rute optimal → dua optimal
ok,_,fails=validate(m,CFG[5]); check("T20b-1 dua rute optimal ditolak V2",(ok,"V2" in fails),(False,True))
m=_c.deepcopy(F); m["edges"].append({"id":"n1-n4","a":"n1","b":"n4","w":5}); m["edges"]=m["edges"]
cfg9=list(CFG[5]); cfg9[3]=9
ok,_,fails=validate(m,tuple(cfg9)); check("T20b-2 edge berpotongan ditolak V6",(ok,"V6-cross" in fails),(False,True))
m=_c.deepcopy(F); m["edges"][0]["w"]=10
ok,_,fails=validate(m,CFG[5]); check("T20b-3 bobot 10 ditolak",(ok,"V9" in fails),(False,True))
m=_c.deepcopy(F); m["edges"][0]["w"]=0
ok,_,fails=validate(m,CFG[5]); check("T20b-4 bobot 0 ditolak",(ok,"V9" in fails),(False,True))
# T24 golden konsisten dengan oracle
G=json.load(open("../shared/test/golden/golden.json"))["maps"]; gok=True
for f,mm in allmaps:
    g=G[mm["id"]]; r,_=optimal_route(mm)
    if g["optimalCost"]!=optimal_cost(mm) or g["optimalRoute"]!=r or g["minHops"]!=min_hops(mm) or g["optimalStopOrder"]!=(optimal_stop_order(mm) if mm["stops"] else []): gok=False
check("T24 golden.json cocok dengan oracle (22 peta)",gok,True)
check("T23c nilai durasi",(dur(range(0,11)),dur([0,1,2,3,4,7,8])),(443.0,263.0))

# ---------- Intro, tutorial, dan anggaran sesi ----------
TL=json.load(open("../shared/intro/timeline.json"))
def contiguous(shots): return all(shots[0]["startMs"]==0 for _ in [0]) and all(a["endMs"]==b["startMs"] for a,b in zip(shots,shots[1:]))
check("I1a durasi ident",TL["ident"][-1]["endMs"],8000)
check("I1b durasi trailer",TL["trailer"][-1]["endMs"],45000)
check("I1c ident ringkas",TL["identShort"]["toMs"]-TL["identShort"]["fromMs"],3000)
check("I1d trailer ringkas",TL["trailerShort"][-1]["endMs"],12000)
check("I2 shot bersambung tanpa jeda/tumpang",(contiguous(TL["ident"]),contiguous(TL["trailer"]),contiguous(TL["trailerShort"])),(True,True,True))
A05=[x for x in A["maps"] if x["id"]=="A-05"][0]
trap=["n0","n2","n3","n5"]
check("I3 angka shot 5 dari A-05",(path_cost(A05,trap),len(trap)-1==min_hops(A05),optimal_cost(A05)),(9,True,8))
import re as _re
check("I4 tidak ada angka koin di timeline.json",bool(_re.search(r"\b(8|9) vs",json.dumps(TL,ensure_ascii=False))),False)
TU=json.load(open("../shared/maps/tutorial.json"))["maps"]; tok=True
for tm in TU:
    cfg=(0,tm["condition"],len(tm["nodes"]),len(tm["edges"]),len(tm["stops"]),tm["trap"])
    ok_,info,fails=validate(tm,cfg); ex={"T-01":{"V3"}}.get(tm["id"],set())
    if [f for f in fails if f not in ex] or info["opt"]!=tm["golden"]["optimalCost"] or info["route"]!=tm["golden"]["optimalRoute"]: tok=False
check("I5 peta tutorial lolos validator + golden",(tok,[t["golden"]["optimalCost"] for t in TU]),(True,[5,3,7,4,6]))
r=Route(TU[1]); r.tap("n3"); check("I6 T-02 ketuk Sekolah dari Rumah tidak valid",(r.inv,r.path),(1,["n0"]))
r=Route(TU[4]); r.tap("n2"); r.tap("n4"); check("I7 T-05 jalan pintas tanpa paket tidak selesai",(r.done,r.cost),(False,2))
r=Route(TU[4]); [r.tap(x) for x in ["n1","n3","n4"]]; check("I7b T-05 rute benar selesai",(r.done,r.cost),(True,6))
r=Route(TU[2]); [r.tap(x) for x in ["n3","n4"]]; check("I8 T-03 rute jebakan 9 koin bukan optimal",(r.cost,r.cost==TU[2]["golden"]["optimalCost"]),(9,False))
LOBBY,PODIUM,TUT=30,20,90
intro=(TL["ident"][-1]["endMs"]+TL["trailer"][-1]["endMs"])/1000
short=(3000+TL["trailerShort"][-1]["endMs"])/1000
std_no0=dur(range(1,11)); quick_no0=dur([1,2,3,4,7,8])
check("S1 perdana Standar (dtk)",LOBBY+intro+TUT+std_no0+PODIUM,608.0)
check("S2 perdana Kilat (dtk)",LOBBY+intro+TUT+quick_no0+PODIUM,428.0)
check("S3 lanjutan Standar (dtk)",LOBBY+short+dur(range(0,11))+PODIUM,508.0)
check("S4 lanjutan Kilat (dtk)",LOBBY+short+dur([0,1,2,3,4,7,8])+PODIUM,328.0)

# ---------- Bank soal paralel dan anti-contek ----------
from pool import signature, complexity, key as sigkey
import itertools as _it
PA=json.load(open("../shared/maps/poolA.json")); PB=json.load(open("../shared/maps/poolB.json"))
PG=json.load(open("../shared/test/golden/pool_golden.json"))["items"]
okv=True; okeq=True; okpair=True; okprog=True; okg=True; okprobe=True; bad=[]
for P in (PA,PB):
    R={r["roundId"]:r["items"] for r in P["rounds"]}
    if len(R[0])!=1 or any(len(R[i])!=4 for i in range(1,11)): okv=False
    prev_max=0
    for rid in range(0,11):
        cfg=CFG[rid]; sigs=[signature(m) for m in R[rid]]
        for m,sg in zip(R[rid],sigs):
            pg=None
            if cfg[1]=="HIDDEN": pg=signature(R[rid-1][0])["gap"]
            ok_,info,fails=validate(m,cfg,pg)
            if not ok_: okv=False; bad.append((m["id"],fails))
            g=PG[m["id"]]; rt,_=optimal_route(m)
            if g["optimalCost"]!=sg["opt"] or g["optimalRoute"]!=rt or g["simpleRoutes"]!=sg["simple"]: okg=False
        if rid>=1:
            if len({sigkey(x) for x in sigs})!=1 or max(x["simple"] for x in sigs)-min(x["simple"] for x in sigs)>1 or max(x["opt"] for x in sigs)-min(x["opt"] for x in sigs)>3: okeq=False
            ks=[tuple(sorted((e["a"],e["b"],e["w"]) for e in m["edges"])) for m in R[rid]]
            if len(set(ks))!=4: okeq=False
        if cfg[1]=="HIDDEN" and sigkey(signature(R[rid][0]))!=sigkey(signature(R[rid-1][0])): okpair=False
        if rid in (2,4,6,8,10):
            sk=[complexity(CFG[rid-1],signature(m)) for m in R[rid-1]]+[complexity(cfg,signature(m)) for m in R[rid]]
            if min(sk)<=prev_max: okprog=False
            prev_max=max(sk)
check("P1 bank soal: jumlah soal + lolos V1-V9",(okv,bad),(True,[]))
check("P2 4 soal per ronde setara dan berbeda",okeq,True)
check("P3 pasangan terlihat/tersembunyi setara",okpair,True)
check("P4 kompleksitas naik tiap pasangan ronde",okprog,True)
check("P5 pool_golden.json cocok",okg,True)
ka={tuple(sorted((e["a"],e["b"],e["w"]) for e in m["edges"])) for r in PA["rounds"] for m in r["items"]}
kb={tuple(sorted((e["a"],e["b"],e["w"]) for e in m["edges"])) for r in PB["rounds"] for m in r["items"]}
check("P6 tidak ada soal kembar antara Pool A dan B",len(ka&kb),0)
oknb=True
for rows,cols in [(r,c) for r in range(1,9) for c in range(1,11)]:
    for perm in _it.permutations(range(4)):
        for off in range(4):
            for rid in range(0,11):
                for r_ in range(rows):
                    for c_ in range(cols):
                        a=assign_slot(r_,c_,rid,perm,off)
                        for dr in (-1,0,1):
                            for dc in (-1,0,1):
                                if (dr or dc) and 0<=r_+dr<rows and 0<=c_+dc<cols and assign_slot(r_+dr,c_+dc,rid,perm,off)==a: oknb=False
check("P7 kursi bersebelahan (8 arah) selalu beda soal",oknb,True)
okbal=True
for perm in _it.permutations(range(4)):
    for off in range(4):
        for r_ in range(2):
            for c_ in range(2):
                cnt=[0]*4
                for rid in range(1,11): cnt[assign_slot(r_,c_,rid,perm,off)]+=1
                if sorted(cnt)!=[2,2,3,3]: okbal=False
check("P8 tiap siswa mendapat tiap slot 2-3 kali (ronde 1-10)",okbal,True)
okq=True
for perm in _it.permutations(range(4)):
    for off in range(4):
        for r_ in range(2):
            for c_ in range(2):
                ids=[assign_slot(r_,c_,rid,perm,off) for rid in (1,2,3,4,7,8)]
                cnt=[ids.count(k) for k in range(4)]
                if max(cnt)>2: okq=False
check("P8b Mode Kilat: tiap slot maks 2 kali",okq,True)
check("P9 tanpa denah kursi: urutan masuk berurutan beda soal",all(assign_slot_no_seat(j,rid,off)!=assign_slot_no_seat(j+1,rid,off) for j in range(60) for rid in range(11) for off in range(4)),True)

okvar=True
for perm in _it.permutations(range(4)):
    for off in range(4):
        for off2 in range(2):
            for rid in range(11):
                for r_ in range(8):
                    for c_ in range(10):
                        for dr in range(-2,3):
                            for dc in range(-2,3):
                                r2,c2=r_+dr,c_+dc
                                if (dr or dc) and 0<=r2<8 and 0<=c2<10 and assign_slot(r_,c_,rid,perm,off)==assign_slot(r2,c2,rid,perm,off):
                                    if assign_variant(r_,c_,rid,off2)==assign_variant(r2,c2,rid,off2): okvar=False
check("P10 radius 2 kursi: soal sama pasti beda varian tampilan",okvar,True)

w=max(len(n) for n,*_ in res)
for n,ok,g,e in res: print(("LULUS " if ok else "GAGAL ")+n.ljust(w)+("" if ok else f"  got={g} exp={e}"))
print(f"\n{sum(o for _,o,*_ in res)}/{len(res)} lulus")
print("durasi Standar:",std,"dtk; Kilat:",quick,"dtk")

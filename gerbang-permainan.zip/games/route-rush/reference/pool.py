"""Bank soal paralel Route Rush: 4 soal setara per ronde (Pool A dan Pool B),
dengan kompleksitas yang naik dari pasangan ronde ke pasangan ronde berikutnya."""
import json, random
from collections import defaultdict
from oracle import *
from gen import ROUNDS, generate, validate

SLOTS=4
CFG={c[0]:c for c in ROUNDS}
# Rentang jumlah rute sederhana (pilihan yang harus dibandingkan anak) per pasangan ronde
BANDS={1:(2,3),3:(2,3),5:(4,5),7:(4,6),9:(5,8)}

def simple_routes(m): return sum(1 for r in all_routes(m) if len(set(r))==len(r))

def signature(m):
    r,_=optimal_route(m); R=all_routes(m)
    costs=sorted(set(c for c,_ in R.values())); opt=costs[0]
    mh=min_hops(m); trap_cost=min(c for rr,(c,_) in R.items() if len(rr)-1==mh)
    return dict(gap=costs[1]-opt, optSteps=len(r)-1, minHops=mh, trapDelta=trap_cost-opt, simple=simple_routes(m), opt=opt)

def complexity(cfg,sig):
    """Skor Kompleksitas (SK) = jumlah jalan + 2×paket + langkah optimal + rute sederhana (maks 10) + 2×jebakan + (4 − selisih)."""
    _,_,nn,ne,ns,trap=cfg[:6]
    return ne + 2*ns + sig["optSteps"] + min(10,sig["simple"]) + 2*int(trap) + (4-sig["gap"])

def key(s): return (s["gap"],s["optSteps"],s["minHops"],s["trapDelta"])

def distinct(ms):
    ks=[tuple(sorted((e["a"],e["b"],e["w"]) for e in m["edges"])) for m in ms]
    return len(set(ks))==len(ks)

def window(lst):
    """Cari 4 soal dengan selisih rute sederhana ≤ 1 dan selisih biaya optimal ≤ 3."""
    lst=sorted(lst,key=lambda x:(x[1]["simple"],x[1]["opt"]))
    for i in range(len(lst)):
        base=lst[i][1]["simple"]
        cand=[x for x in lst[i:] if x[1]["simple"]-base<=1]
        for j in range(len(cand)):
            w=[cand[j]]
            for x in cand[j+1:]:
                if len(w)==SLOTS: break
                if max(y[1]["opt"] for y in w+[x])-min(y[1]["opt"] for y in w+[x])<=3: w.append(x)
            if len(w)==SLOTS and distinct([y[0] for y in w]): return w
    return None

def build(seed, n=500):
    rng=random.Random(seed); P=seed[-1]
    bank={"pool":P,"seed":seed,"slots":SLOTS,"generatedBy":"reference/pool.py","rounds":[]}
    m,_=generate(CFG[0],rng,"X"); m["id"]=f"P{P}-00-0"
    bank["rounds"].append({"roundId":0,"items":[m]})
    prev_max=0
    for v in (1,3,5,7,9):
        h=v+1; lo,hi=BANDS[v]
        gv=defaultdict(list); gh=defaultdict(list); best=None
        for attempt in range(4):
          for _ in range(n):
            mv,_=generate(CFG[v],rng,"X"); s=signature(mv)
            if lo<=s["simple"]<=hi: gv[key(s)].append((mv,s))
          for _ in range(n):
            mh_,_=generate(CFG[h],rng,"X"); s=signature(mh_)
            if lo<=s["simple"]<=hi: gh[key(s)].append((mh_,s))
          for k in sorted(gv, key=lambda k:-min(len(gv[k]),len(gh.get(k,[])))):
            wv=window(gv[k]); wh=window(gh.get(k,[]))
            if not wv or not wh: continue
            skv=[complexity(CFG[v],x[1]) for x in wv]; skh=[complexity(CFG[h],x[1]) for x in wh]
            if min(skv+skh)<=prev_max or max(skv+skh)-min(skv+skh)>1: continue
            best=(wv,wh,max(skv+skh)); break
          if best: break
        assert best, f"pasangan ronde {v}-{h}: tidak cukup soal setara"
        prev_max=best[2]
        for rid,w in ((v,best[0]),(h,best[1])):
            items=[]
            for j,(mm,s) in enumerate(w):
                mm=dict(mm); mm["id"]=f"P{P}-{rid:02d}-{j}"
                if CFG[rid][1]=="HIDDEN":  # probe di rute optimal soal itu sendiri
                    r,_=optimal_route(mm); es=[f"{min(a,b,key=lambda x:int(x[1:]))}-{max(a,b,key=lambda x:int(x[1:]))}" for a,b in zip(r,r[1:])]
                    mm["probeEdgeId"]=rng.choice(es)
                items.append(mm)
            bank["rounds"].append({"roundId":rid,"items":items})
    bank["rounds"].sort(key=lambda r:r["roundId"])
    return bank

if __name__=="__main__":
    for seed in ("RR-POOL-A","RR-POOL-B"):
        b=build(seed)
        json.dump(b,open(f"../shared/maps/pool{seed[-1]}.json","w"),indent=2,ensure_ascii=False)
        for r in b["rounds"]:
            cfg=CFG[r["roundId"]]; sigs=[signature(m) for m in r["items"]]
            print(seed[-1],r["roundId"],cfg[1],"opt",[s["opt"] for s in sigs],"rute",[s["simple"] for s in sigs],"SK",[complexity(cfg,s) for s in sigs],key(sigs[0]))

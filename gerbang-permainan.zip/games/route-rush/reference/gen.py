from oracle import *
ROUNDS=[ # id,cond,nodes,edges,stops,trap,look,walk,scored
 (0,"VISIBLE",4,4,0,False,5000,20000,False),
 (1,"VISIBLE",5,6,0,False,5000,20000,True),(2,"HIDDEN",5,6,0,False,5000,20000,True),
 (3,"VISIBLE",6,7,0,True,6000,25000,True),(4,"HIDDEN",6,7,0,True,6000,25000,True),
 (5,"VISIBLE",6,8,0,True,6000,25000,True),(6,"HIDDEN",6,8,0,True,6000,25000,True),
 (7,"VISIBLE",6,8,1,False,6000,30000,True),(8,"HIDDEN",6,8,1,False,6000,30000,True),
 (9,"VISIBLE",7,9,2,False,7000,35000,True),(10,"HIDDEN",7,9,2,False,7000,35000,True)]
KINDS=["market","park","mosque","shop","library","clinic","field"]

def seg_cross(p1,p2,p3,p4):
    def o(a,b,c): 
        v=(b[0]-a[0])*(c[1]-a[1])-(b[1]-a[1])*(c[0]-a[0]); return (v>1e-12)-(v<-1e-12)
    if len({p1,p2,p3,p4})<4: return False  # berbagi titik ujung
    return o(p1,p2,p3)*o(p1,p2,p4)<0 and o(p3,p4,p1)*o(p3,p4,p2)<0

def validate(m,cfg,pair_gap=None):
    """Kembalikan (lulus, info, daftar_gagal)."""
    fails=[]; nid=[n["id"] for n in m["nodes"]]; P={n["id"]:(n["x"],n["y"]) for n in m["nodes"]}
    _,_,nn,ne,ns,trap=cfg[:6]
    # V1
    A=adj(m); seen={m["start"]}; q=[m["start"]]
    while q:
        u=q.pop()
        for v in A[u]:
            if v not in seen: seen.add(v); q.append(v)
    if len(seen)!=nn or len(m["nodes"])!=nn or len(m["edges"])!=ne or len(m["stops"])!=ns: fails.append("V1")
    if any(not(1<=e["w"]<=9 and isinstance(e["w"],int)) for e in m["edges"]): fails.append("V9")
    R=all_routes(m); costs=sorted(set(c for c,_ in R.values()))
    opt=costs[0]; nopt=sum(1 for c,_ in R.values() if c==opt)
    # V2
    if nopt!=1: fails.append("V2")
    gap=(costs[1]-opt) if len(costs)>1 else None
    # V3
    if gap is None or not(1<=gap<=3): fails.append("V3")
    route,_=optimal_route(m); mh=min_hops(m)
    # V4
    if trap and len(route)-1==mh: fails.append("V4")
    # V5
    if opt>25 or len(route)-1>6: fails.append("V5")
    # V8: rute optimal tidak boleh mengunjungi tempat yang sama dua kali
    if len(set(route))!=len(route): fails.append("V8")
    # V6
    E=[(P[e["a"]],P[e["b"]]) for e in m["edges"]]
    for i in range(len(E)):
        for j in range(i+1,len(E)):
            if seg_cross(*E[i],*E[j]): fails.append("V6-cross")
    for a,b in itertools.combinations(nid,2):
        if math.dist(P[a],P[b])<0.18: fails.append("V6-dist")
    # V7
    if pair_gap is not None and gap!=pair_gap: fails.append("V7")
    if m["stops"] and (m["start"] in m["stops"] or m["goal"] in m["stops"]): fails.append("V9")
    if cfg[1]=="HIDDEN" and m.get("probeEdgeId") not in {f'{min(a,b,key=lambda x:int(x[1:]))}-{max(a,b,key=lambda x:int(x[1:]))}' for a,b in zip(route,route[1:])}: fails.append("V9")
    return (not fails), dict(opt=opt,gap=gap,route=route,minHops=mh,steps=len(route)-1), sorted(set(fails))

def eid(a,b):
    a,b=sorted([a,b],key=lambda x:int(x[1:])); return f"{a}-{b}"

def generate(cfg,rng,form,pair_gap=None):
    rid,cond,nn,ne,ns,trap=cfg[:6]
    for _ in range(5000):
        slots=[(c,r) for c in range(3) for r in range(3)]
        s=rng.choice([x for x in slots if x[0]==0]); g=rng.choice([x for x in slots if x[0]==2])
        rest=[x for x in slots if x not in (s,g)]; rng.shuffle(rest)
        chosen=[s]+rest[:nn-2]+[g]
        ids=[f"n{i}" for i in range(nn)]
        kinds=KINDS[:]; rng.shuffle(kinds)
        nodes=[]
        for i,(c,r) in enumerate(chosen):
            k="home" if i==0 else "school" if i==nn-1 else kinds[i-1]
            nodes.append({"id":ids[i],"kind":k,"x":round(0.1+0.4*c+rng.uniform(-0.04,0.04),3),"y":round(0.15+0.35*r+rng.uniform(-0.04,0.04),3)})
        P={n["id"]:(n["x"],n["y"]) for n in nodes}; slot={ids[i]:chosen[i] for i in range(nn)}
        cand=[(a,b) for a,b in itertools.combinations(ids,2) if max(abs(slot[a][0]-slot[b][0]),abs(slot[a][1]-slot[b][1]))==1]
        rng.shuffle(cand)
        # spanning tree acak (Kruskal) tanpa perpotongan
        par={i:i for i in ids}
        def f(x):
            while par[x]!=x: x=par[x]
            return x
        E=[]
        def ok(a,b): return all(not seg_cross(P[a],P[b],P[c],P[d]) for c,d in E)
        for a,b in cand:
            if f(a)!=f(b) and ok(a,b): par[f(a)]=f(b); E.append((a,b))
        if len(E)!=nn-1: continue
        for a,b in cand:
            if len(E)>=ne: break
            if (a,b) not in E and ok(a,b): E.append((a,b))
        if len(E)!=ne: continue
        mids=ids[1:-1]
        for _ in range(200):
            edges=[{"id":eid(a,b),"a":min(a,b,key=lambda x:int(x[1:])),"b":max(a,b,key=lambda x:int(x[1:])),"w":rng.randint(1,9)} for a,b in E]
            edges.sort(key=lambda e:(int(e["a"][1:]),int(e["b"][1:])))
            m={"id":f"{form}-{rid:02d}","nodes":nodes,"edges":edges,"start":ids[0],"goal":ids[-1],"stops":sorted(rng.sample(mids,ns),key=lambda x:int(x[1:]))}
            if cond=="HIDDEN":
                try: r,_=optimal_route(m)
                except Exception: continue
                pe=[eid(a,b) for a,b in zip(r,r[1:])]; m["probeEdgeId"]=rng.choice(pe)
            okv,info,fails=validate(m,cfg,pair_gap)
            if okv: return m,info
    raise RuntimeError("gagal")

FIXTURE={"id":"A-05","nodes":[
 {"id":"n0","kind":"home","x":0.05,"y":0.50},{"id":"n1","kind":"market","x":0.30,"y":0.15},
 {"id":"n2","kind":"park","x":0.40,"y":0.55},{"id":"n3","kind":"mosque","x":0.70,"y":0.30},
 {"id":"n4","kind":"shop","x":0.65,"y":0.90},{"id":"n5","kind":"school","x":0.95,"y":0.55}],
 "edges":[{"id":"n0-n1","a":"n0","b":"n1","w":2},{"id":"n0-n2","a":"n0","b":"n2","w":5},{"id":"n1-n2","a":"n1","b":"n2","w":2},
 {"id":"n1-n3","a":"n1","b":"n3","w":6},{"id":"n2-n3","a":"n2","b":"n3","w":1},{"id":"n2-n4","a":"n2","b":"n4","w":4},
 {"id":"n3-n5","a":"n3","b":"n5","w":3},{"id":"n4-n5","a":"n4","b":"n5","w":2}],"start":"n0","goal":"n5","stops":[]}

if __name__=="__main__":
    for form,seed in (("A","KC-2026-A"),("B","KC-2026-B")):
        rng=random.Random(seed); bank={"form":form,"seed":seed,"generatedBy":"oracle gen.py","maps":[]}
        gaps={}
        for cfg in ROUNDS:
            rid=cfg[0]; pg=gaps.get(rid-1) if cfg[1]=="HIDDEN" else None
            if form=="A" and rid==5:
                m=FIXTURE; ok,info,fails=validate(m,cfg); assert ok,fails
            else:
                m,info=generate(cfg,rng,form,pg)
            gaps[rid]=info["gap"]
            bank["maps"].append({"roundId":rid,**m})
            print(form,rid,cfg[1],f'{cfg[2]}/{cfg[3]} stops={cfg[4]} trap={cfg[5]}',info)
        json.dump(bank,open(f"form{form}.json","w"),indent=2,ensure_ascii=False)

"""Implementasi referensi (oracle) Route Rush untuk memverifikasi angka di SPEC."""
import heapq, itertools, math, json, random
from collections import deque
from statistics import median

def adj(m):
    A={n["id"]:{} for n in m["nodes"]}
    for e in m["edges"]:
        A[e["a"]][e["b"]]=e["w"]; A[e["b"]][e["a"]]=e["w"]
    return A

def dijkstra(m,s,t,unit=False):
    A=adj(m); d={s:0}; pq=[(0,s)]
    while pq:
        c,u=heapq.heappop(pq)
        if u==t: return c
        if c>d.get(u,1e9): continue
        for v,w in A[u].items():
            nc=c+(1 if unit else w)
            if nc<d.get(v,1e9): d[v]=nc; heapq.heappush(pq,(nc,v))
    return math.inf

def optimal_cost(m,unit=False):
    best=math.inf
    for perm in itertools.permutations(m["stops"]):
        pts=[m["start"],*perm,m["goal"]]
        best=min(best,sum(dijkstra(m,pts[k],pts[k+1],unit) for k in range(len(pts)-1)))
    return best

def min_hops(m): return optimal_cost(m,unit=True)

def simple_paths(A,s,t):
    out=[]; 
    def dfs(u,path):
        if u==t: out.append(list(path)); return
        for v in A[u]:
            if v not in path: path.append(v); dfs(v,path); path.pop()
    dfs(s,[s]); return out

def path_cost(m,path):
    A=adj(m); c=0
    for a,b in zip(path,path[1:]):
        if b not in A[a]: return None
        c+=A[a][b]
    return c

def all_routes(m):
    """Semua rute = gabungan rute sederhana antar titik wajib, untuk setiap urutan stop."""
    A=adj(m); routes={}
    for perm in itertools.permutations(m["stops"]):
        pts=[m["start"],*perm,m["goal"]]
        segs=[simple_paths(A,pts[k],pts[k+1]) for k in range(len(pts)-1)]
        for combo in itertools.product(*segs):
            r=list(combo[0])
            for s in combo[1:]: r+=s[1:]
            routes[tuple(r)]=(path_cost(m,r),list(perm))
    return routes

def optimal_route(m):
    R=all_routes(m); best=min(c for c,_ in R.values())
    opts=[r for r,(c,_) in R.items() if c==best]
    return list(opts[0]), len(opts)

def optimal_stop_order(m):
    R=all_routes(m); r,_=optimal_route(m); return R[tuple(r)][1]

# ---------- route state ----------
class Route:
    def __init__(s,m):
        s.m=m; s.A=adj(m); s.path=[m["start"]]; s.inv=0; s.undo=0; s.rev=0; s.done=False
    def tap(s,n):
        cur=s.path[-1]
        if s.done or n==cur: return
        if n not in s.A[cur]: s.inv+=1; return
        if n in s.path: s.rev+=1
        s.path.append(n)
        if n==s.m["goal"] and all(x in s.path for x in s.m["stops"]): s.done=True
    def undo_(s):
        if len(s.path)>1 and not s.done: s.path.pop(); s.undo+=1
    @property
    def steps(s): return len(s.path)-1
    @property
    def cost(s): return path_cost(s.m,s.path)

# ---------- scoring ----------
def rnd(x): return math.floor(x+0.5)
def race_points(opt_hit,completed,er,t,T):
    Q=1 if opt_hit else (0.5*er if completed else 0)
    return rnd(1000*Q*(1-0.5*t/T))
def streak_bonuses(hits):
    out=[];k=0
    for h in hits:
        k=k+1 if h else 0
        out.append(min(300,100*(k-1)) if h else 0)
    return out
def probe_points(correct,ts): return rnd(200*(1-0.5*ts/5)) if correct else 0

def error_type(m,path,completed,timed_out,opt):
    if timed_out: return "TIMEOUT"
    c=path_cost(m,path)
    if completed and c==opt: return "NONE"
    if len(m["stops"])>=2:
        first=[]
        for n in path:
            if n in m["stops"] and n not in first: first.append(n)
        if first!=optimal_stop_order(m): return "STOP_ORDER"
    if len(path)-1==min_hops(m): return "FEW_ROADS_TRAP"
    return "DETOUR"

# ---------- indices ----------
mean=lambda xs: sum(xs)/len(xs)
def IL(erv,ohv): return 100*(0.6*mean(erv)+0.4*mean(ohv))
def IM(erv,erh,P):
    mv,mh=mean(erv),mean(erh); ratio=min(1,mh/mv) if mv>0 else mh
    return 100*(0.5*P+0.5*ratio), mv-mh
def IS(TI,L,U,KU):
    if L==0: return None
    rti=TI/(TI+L) if TI+L else 0; rbb=(U+KU)/L
    return 100*(0.5*(1-rti)+0.5*max(0,1-rbb))
def RTM(nopt,sum_t): return nopt/(sum_t/60)

# ---------- Distribusi soal anti-contek ----------
def seat_base(row, col):
    """Pola ubin 2x2: kursi yang bersebelahan (termasuk diagonal) selalu beda nilai."""
    return 2*(row % 2) + (col % 2)

def assign_slot(row, col, round_id, perm, offset, slots=4):
    """perm = permutasi acak [0..3] per sesi, offset = geser acak per sesi (0..3)."""
    return (perm[seat_base(row, col)] + round_id + offset) % slots

def assign_slot_no_seat(join_index, round_id, offset, slots=4):
    return (join_index + round_id + offset) % slots

def assign_variant(row, col, round_id, offset2):
    """Varian tampilan 0..7 (rotasi/cermin). Kursi berjarak 2 yang mendapat soal sama dijamin beda varian."""
    return (2*((row // 2) % 2) + ((col // 2) % 2) + 4*((round_id + offset2) % 2)) % 8

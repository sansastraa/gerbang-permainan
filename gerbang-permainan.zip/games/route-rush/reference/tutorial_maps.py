import json
from oracle import *
from gen import validate
def N(i,k,x,y): return {"id":f"n{i}","kind":k,"x":x,"y":y}
def E(a,b,w): return {"id":f"n{a}-n{b}","a":f"n{a}","b":f"n{b}","w":w}
T=[
 ("T-01","Ketuk untuk bergerak",[N(0,"home",.1,.5),N(1,"market",.5,.5),N(2,"school",.9,.5)],[E(0,1,2),E(1,2,3)],[],False,"VISIBLE"),
 ("T-02","Hanya tempat tersambung",[N(0,"home",.1,.5),N(1,"park",.5,.15),N(2,"shop",.5,.85),N(3,"school",.9,.5)],[E(0,1,2),E(0,2,1),E(1,3,3),E(2,3,2)],[],False,"VISIBLE"),
 ("T-03","Jalan pendek belum tentu hemat",[N(0,"home",.1,.5),N(1,"market",.35,.85),N(2,"park",.65,.85),N(3,"mosque",.5,.15),N(4,"school",.9,.5)],[E(0,1,2),E(0,3,6),E(1,2,2),E(2,4,3),E(3,4,3)],[],True,"VISIBLE"),
 ("T-04","Angka hilang",[N(0,"home",.1,.5),N(1,"field",.5,.15),N(2,"library",.5,.85),N(3,"school",.9,.5)],[E(0,1,3),E(0,2,2),E(1,3,1),E(2,3,5)],[],False,"HIDDEN"),
 ("T-05","Wajib mampir",[N(0,"home",.1,.5),N(1,"park",.45,.15),N(2,"market",.45,.85),N(3,"shop",.8,.15),N(4,"school",.9,.75)],[E(0,1,3),E(0,2,1),E(1,2,3),E(1,3,1),E(2,4,1),E(3,4,2)],["n1"],False,"VISIBLE"),
]
out={"form":"TUTORIAL","verifiedBy":"reference/tutorial_maps.py","maps":[]}
for tid,title,nodes,edges,stops,trap,cond in T:
    m={"id":tid,"title":title,"nodes":nodes,"edges":edges,"start":"n0","goal":nodes[-1]["id"] if tid!="T-05" else "n4","stops":stops}
    if cond=="HIDDEN": m["probeEdgeId"]="n1-n3"
    cfg=(0,cond,len(nodes),len(edges),len(stops),trap)
    ok,info,fails=validate(m,cfg)
    exempt={"T-01":{"V3"}}.get(tid,set())
    real=[f for f in fails if f not in exempt]
    print(tid,"LULUS" if not real else "GAGAL",info,"pengecualian:",sorted(set(fails)&exempt) or "-", real or "")
    assert not real
    m["condition"]=cond; m["trap"]=trap; m["golden"]={"optimalCost":info["opt"],"optimalRoute":info["route"],"minHops":info["minHops"],"secondBestGap":info["gap"]}
    out["maps"].append(m)
# cek khusus: T-02 Rumah tidak bersebelahan dengan Sekolah; T-05 jalan pintas tanpa paket lebih murah dari optimal
A=adj(out["maps"][1]); assert "n3" not in A["n0"]
m5=out["maps"][4]; shortcut=path_cost(m5,["n0","n2","n4"]); print("T-05 jalan pintas tanpa paket =",shortcut,"< optimal",m5["golden"]["optimalCost"]); assert shortcut<m5["golden"]["optimalCost"]
r=Route(m5); [r.tap(x) for x in ["n2","n4"]]; print("T-05 sampai Sekolah tanpa paket -> selesai?",r.done); assert not r.done
json.dump(out,open("../shared/maps/tutorial.json","w"),indent=2,ensure_ascii=False)

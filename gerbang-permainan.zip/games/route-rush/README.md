> Folder ini berada di dalam repositori SIMPETERI (games/route-rush). Dari akar repositori: 
pm run rr:install, 
pm run rr:dev, 
pm run rr:test, 
pm run rr:e2e. Perintah di bawah dijalankan dari folder ini.

# Route Rush

Permainan kelas untuk mengukur penalaran rute hemat (logika, memori, spasial) pada siswa SD. Satu kelas bermain bersamaan:
guru menjalankan layar proyektor (`/host`), siswa memakai HP/tablet (`/`). Semua logika permainan ada di server; layar siswa
tidak pernah menerima kunci jawaban.

Dokumen lain: `SPEC.md` (spesifikasi), `DECISIONS.md` (keputusan di luar spek), `TEST_REPORT.md` (hasil uji tiap fase).

## 1. Instalasi

Kebutuhan: **Node.js 22+** dan **Microsoft Edge atau Google Chrome** (untuk uji Playwright dan pemrosesan audio; tidak ada
peramban yang diunduh otomatis).

```bash
npm install --ignore-scripts
```

(`--ignore-scripts` menghindari skrip pasca-pasang esbuild yang gagal di sebagian Windows; semua biner yang dibutuhkan sudah ikut terpasang.)

## 2. Menjalankan di jaringan lokal (LAN)

1. Bangun tampilan klien, lalu nyalakan server (menyajikan klien sekaligus):

   ```bash
   npm run build:dev
   npm run dev
   ```

   Server mendengarkan di semua antarmuka pada port 3000 (ubah dengan `PORT=8080`). Data sesi disimpan di folder `data/` di dalam folder `server/` saat dijalankan lewat `npm run dev`
   (ubah dengan `DATA_DIR=...`).

2. Cari alamat IP komputer guru (`ipconfig` di Windows, `ip addr` di Linux). Misalnya `192.168.1.20`.
3. **Layar guru/proyektor:** buka `http://192.168.1.20:3000/host` di komputer yang tersambung ke proyektor, lalu tekan F11.
4. **Siswa:** buka `http://192.168.1.20:3000/` di HP atau tablet (satu jaringan Wi-Fi). Izinkan port 3000 di firewall Windows bila diminta.
5. Proyektor perlu speaker dan internet bila narasi memakai suara Indonesia dari peramban (lihat bagian Suara).

> Build produksi penuh (`npm run build`) sengaja **menolak** selama masih ada aset sementara (logo/nama pembuat, font, daftar nama klip,
> persetujuan musik, dll.). Lihat `assets/PLACEHOLDERS.md`. `npm run build:dev` melewati pemeriksaan itu.

## 3. Membuat dan menjalankan sesi

1. Di `/host`, isi **daftar siswa** (satu nama per baris; boleh `Nama;Kelas`). Nantinya daftar ini datang dari SIMPETERI.
2. Pilih **intro**: "Sesi perdana kelas ini" (intro penuh + tutorial) atau "Sudah pernah main" (intro ringkas, langsung ronde latihan).
   Atur **mode** (Standar/Kilat), **bentuk soal** (A/B), waktu menghafal/berjalan/soal ingatan/layar hasil, kuota, ronde khusus, dan denah kursi.
   Tekan **Buat sesi**. Intro diputar di proyektor; tahan tombol *Lewati intro* 2 detik untuk melewatinya.
3. Setelah intro, **kode sesi 6 digit** tampil besar. Siswa memasukkan kode, **memilih namanya** dari daftar, lalu **memilih kursi** pada denah.
   Layar siswa menampilkan READY sambil menunggu; tombol *Cara bermain* membuka penjelasan bergambar.
4. Tombol **Mulai** aktif bila jumlah siswa yang masuk memenuhi kuota dan semua sudah memilih kursi. Setelah hitung mundur 3 detik:
   tutorial (sesi perdana) → ronde (LOOK → WALK → soal ingatan pada ronde angka-hilang → hasil → 5 besar) → podium.
5. **Lewati** dan **Akhiri** di pojok layar guru meminta konfirmasi. Layar guru tidak pernah menampilkan peta saat siswa bermain.

## 4. Ekspor dan laporan

Di layar podium tersedia tombol unduhan. Alamat langsung (sesi `<id>` tampil di tautan unduhan):

| Berkas | Isi |
|---|---|
| `GET /api/sessions/<id>/rounds.csv` | satu baris per hasil ronde (semua field; `tap_log` sebagai JSON) |
| `GET /api/sessions/<id>/students.csv` | satu baris per siswa: IL, IM, IS, RTM, kuadran, poin, catatan tutorial dan ringkasan integritas |
| `GET /api/sessions/<id>/tutorial.csv` | satu baris per siswa per langkah tutorial |
| `GET /api/sessions/<id>/items.csv` | rekap per soal untuk memeriksa kesetaraan empat soal tiap ronde |
| `GET /api/sessions/<id>/report.html` | kartu laporan per siswa (A4, 2 kartu per halaman); **tanpa poin dan peringkat**, memuat catatan integritas untuk guru |

- CSV berpemisah **koma**, UTF-8 **dengan BOM**. Di Excel berbahasa Indonesia (pemisah titik-koma) pakai *Data → From Text/CSV*
  dan pilih pemisah koma bila kolom tidak terpisah.
- Sesi **TEST** (bot/simulasi) ditolak (HTTP 403) kecuali ditambah `?includeTest=1`.
- Hasil yang gagal pemeriksaan integritas data disimpan terpisah di `data/rejected/` dan tidak ikut ekspor.
- Berkas sesi mentah: `data/sessions/<id>.jsonl` (LIVE) dan `data/test-sessions/<id>.jsonl` (TEST).
- Alamat ekspor tidak meminta kata sandi: gunakan hanya di jaringan kelas yang dipercaya.

## 5. Uji dan simulasi

```bash
npm test                         # shared + server + client (unit, integrasi)
npm run typecheck
npm run lint:nodummy             # larangan data dummy / Math.random di src/
npm run e2e                      # Playwright dengan Edge terpasang (memakan ± 15 menit)
npm run simulate -- --players 30 # 4 jenis sesi dengan bot di jam virtual; gagal bila melewati anggaran S1–S4
```

`simulate` menulis sesi TEST ke `data/test-sessions/` dan memeriksa bahwa `students.csv` dapat dihitung ulang dari `rounds.csv`.

## 6. Uji lapangan dengan siswa nyata (Fase 9)

Dijalankan oleh tim peneliti/guru di kelas; skrip hanya menilai hasilnya.

1. Siapkan komputer proyektor dan jaringan seperti bagian 2; buat sesi dari `/host` (bukan bot), jalankan sampai **podium**, lalu **Akhiri**.
2. Catat id sesi dari tautan unduhan di podium (mis. `rr-1a2b3c4d`) atau dari nama berkas di `data/sessions/`.
3. Jalankan:

   ```bash
   npm run field-check -- --session rr-1a2b3c4d
   ```

   Hasilnya ditulis ke `docs/field-check-<id>.md` dan diringkas di terminal (kode keluar 1 bila ada pemeriksaan yang gagal).
   Sesi TEST/bot ditolak kecuali `--include-test` (hanya untuk mencoba skrip). Opsi lain: `--data <folder>`, `--out <folder>`.
4. Laporan memuat 10 pemeriksaan (penyelesaian sesi, tutorial, hasil ditolak, sampai-tepat-waktu per ronde, proporsi OH 0,30–0,80,
   durasi vs S1–S4, pengaruh varian peta, kesetaraan 4 soal, persentase denah kursi), tabel per ronde, dan daftar ronde/soal yang
   perlu diganti dengan soal baru dari generator (Pool C, D, …; Pool A dan B asli disimpan sebagai arsip).
5. **Kesetaraan soal.** Pemeriksaan gagal hanya bila uji Kruskal-Wallis antar soal menunjukkan beda bermakna (p < 0,05). Selisih rerata ER > 0,15
   hanya **penanda** ("Dipantau"): pada satu kelas ±30 siswa tiap soal dikerjakan 7–8 anak, sehingga selisih itu sering muncul karena kebetulan.
   Gabungkan beberapa kelas sebelum mengganti soal bila hanya ada penanda. Status "data kurang" bukan kegagalan.
6. Durasi dihitung dari tombol Mulai sampai podium; sesi yang dibuat sebelum Fase 9 tidak punya penanda itu (pemeriksaan durasi "data kurang").

## 7. Aset dan suara

- Musik/efek intro dibuat oleh skrip (`npm run gen:audio -- --force`); suara jawaban benar/salah dan 25 klip nama berasal dari MP3 pemilik
  (`npx tsx scripts/build-answer-audio.ts`). Daftar nama klip: `assets/audio/names/names.txt`.
- Narasi memakai **suara peramban Indonesia** (Web Speech API); bila tidak ada, narasi dilewati dan subtitle tetap tampil.
- Lisensi: `LICENSES.md` dan `assets/audio/LICENSES.md`. Aset sementara: `assets/PLACEHOLDERS.md`.

## 8. Integrasi dengan SIMPETRI

Di SIMPETRI: menu **Clash of Git → Route Rush** (aktifkan Clash of Git lebih dulu).

1. Pilih **kelas** dan isi **alamat server Route Rush** (mis. `http://192.168.1.20:3000`).
2. **Nomor absen** = urutan abjad nama siswa di kelas itu. Tekan tombol putar pada tiap baris dan dengarkan: klip 07 harus menyebut siswa absen 7, dan seterusnya.
   Bila berbeda, geser siswa dengan tombol panah (urutan diingat per kelas di peramban ini).
3. Tekan **Buka layar guru Route Rush**. Jendela baru terbuka di `/host`, SIMPETRI mengirim daftar (ID siswa SIMPETRI, nama, kelas, absen) lewat `postMessage`, dan layar guru menampilkan "Daftar dari SIMPETERI · Kelas … · N siswa".
   Selanjutnya sama seperti bagian 3. Hanya jendela pembuka yang diterima; pesan dari sumber lain diabaikan.
4. Saat hasil ronde, proyektor menyebut nama siswa yang benar memakai klip sesuai **absen** (bukan lagi mencocokkan ejaan nama).
5. `students.csv`/`rounds.csv` memuat `student_id` = ID siswa SIMPETRI. Hasil permainan **tidak** otomatis masuk ke nilai, presensi, atau partisipasi.

Catatan jaringan: bila SIMPETRI dibuka lewat **https** (mis. versi yang dipublikasikan) dan server Route Rush hanya **http** di LAN, peramban tetap mengizinkan membuka jendela
`http://…/host` dan mengirim pesan, tetapi tidak mengizinkan halaman https mengambil sumber http. Karena itu klip suara untuk pemeriksaan disertakan di dalam SIMPETRI (`public/route-rush/names/`) dan tidak ada pemeriksaan koneksi otomatis;
keberhasilan ditandai oleh jawaban "siap" dari layar guru.

## 9. Struktur

```
shared/   logika murni (graf, solver, skor, indeks, ekspor, pengacak) + data acuan (maps/, intro/) — jangan diedit
server/   Express + Socket.IO, sesi, penyimpanan JSONL, ekspor, simulate.ts
client/   React + Vite: layar siswa (/), layar guru (/host), intro, e2e Playwright
assets/   brand/, audio/ (musik, efek, jawaban, nama), PLACEHOLDERS.md
scripts/  pembuat bank soal, audio, pemeriksa build produksi
```

## 10. Menjalankan di server online (Fly, Render, Railway, VPS)

### Keputusan arsitektur
Route Rush **tidak bisa** dijalankan di dalam Lovable/SIMPETERI. Server permainan adalah satu proses Node yang terus hidup: ia memegang jam fase dengan ketepatan detik, koneksi Socket.IO ke tiap HP siswa, dan keadaan sesi di memori. SIMPETERI berjalan di Cloudflare Workers + Supabase, yang tidak menyediakan proses panjang itu. Maka dipilih: **server Route Rush dipasang terpisah di host Node yang selalu hidup, dan SIMPETERI hanya menautkannya lewat alamat https** (SIMPETERI membuka `https://alamat-server/host` di jendela baru dan mengirim daftar siswa lewat `postMessage`; tidak ada kunci rahasia yang berpindah). Memindahkan keadaan sesi ke Supabase Realtime ditolak: itu berarti menulis ulang `session.ts` (jam fase, penilaian, anti-curang) dan menambah latensi pada permainan yang menilai ketepatan waktu.

Siswa membuka `https://alamat-server` langsung dari HP (client statis disajikan oleh server yang sama), jadi tidak ada urusan CORS antara client dan server.

### Variabel lingkungan
| Variabel | Bawaan | Fungsi |
|---|---|---|
| `PORT` | 3000 (kontainer: 8080) | Port HTTP; platform hosting biasanya mengisinya sendiri |
| `HOST` | `0.0.0.0` | Alamat yang didengarkan |
| `DATA_DIR` | `./data` (kontainer: `/data`) | Folder hasil sesi (JSONL). **Harus disk persisten** |
| `NODE_ENV` | `development` | `production` mematikan bot dan menutup Socket.IO dari asal lain |
| `ALLOWED_ORIGINS` | kosong | Halaman lain yang boleh membuka Socket.IO, pisah koma (`*` = semua). Kosong di produksi = hanya halaman dari server ini; cukup untuk pemakaian normal |
| `TRUST_PROXY` | `false` (kontainer: `1`) | Jumlah proxy di depan server |
| `SIMULATE` | kosong | `1` mengizinkan bot untuk `npm run simulate` (diabaikan di produksi) |

Server mencetak peringatan saat mulai bila pengaturan produksi berbahaya (mis. `DATA_DIR` tidak diatur, `ALLOWED_ORIGINS=*`). Contoh lengkap: `.env.example`.

### Cek kesehatan
`GET /health` → `{"ok":true,"game":"ROUTE_RUSH","sessions":0,"uptimeS":123,"storageWritable":true}`. Pakai sebagai health check platform. `storageWritable:false` berarti disk data tidak bisa ditulis: hasil sesi tidak akan tersimpan.

### Jalan cepat
Tanpa Docker (VPS, atau uji lokal produksi):
```bash
npm ci
npm run build        # gerbang aset produksi; untuk uji: npm run build:dev
NODE_ENV=production PORT=8080 DATA_DIR=/var/lib/route-rush TRUST_PROXY=1 npm start
```
Dengan Docker:
```bash
docker build -t route-rush --build-arg ALLOW_PLACEHOLDERS=1 .
docker run -p 8080:8080 -v rr-data:/data route-rush
```
Kontainer berjalan sebagai pengguna biasa, memperbaiki izin folder `/data` saat mulai, dan menutup diri dengan rapi saat menerima SIGTERM.

### Per platform
- **Fly.io** (`fly.toml`): `fly launch --no-deploy --copy-config`, `fly volumes create rr_data --size 1 --region sin`, `fly deploy`. Ubah `app` di `fly.toml`. Mesin tidak dimatikan otomatis dan jumlahnya satu.
- **Render** (`render.yaml`): buat Blueprint dari repositori. Disk persisten butuh paket berbayar; paket gratis tidur saat sepi dan datanya hilang, jadi tidak cocok untuk kelas.
- **Railway** (`railway.json`): tambahkan Volume ke servis, pasang di `/data`, lalu isi `DATA_DIR=/data` dan `NODE_ENV=production`.
- **VPS**: jalankan `npm start` di bawah systemd atau Docker, dan pasang reverse proxy dengan https (mis. Caddy: `route-rush.sekolah.id { reverse_proxy 127.0.0.1:8080 }`). Socket.IO memakai WebSocket; proxy harus meneruskan upgrade (Caddy dan Nginx dengan `proxy_set_header Upgrade` melakukannya).

### Batasan yang perlu diketahui
1. **Satu instance saja.** Keadaan sesi ada di memori satu proses; jangan menjalankan dua replika atau memakai penyeimbang beban tanpa lengket.
2. **Sesi yang sedang berjalan tidak bertahan bila server dimulai ulang** (deploy baru, crash, platform yang tidur). Hasil ronde yang sudah selesai tetap ada di `DATA_DIR`, dan ekspor/laporan tetap bisa dibuka; permainan yang berjalan harus dimulai lagi. Jangan deploy saat kelas sedang bermain. Pilih paket yang selalu hidup.
3. **Cadangkan `DATA_DIR`** (ia berisi hasil siswa). Folder `sessions/`, `test-sessions/`, `rejected/` berisi berkas JSONL biasa.
4. **Build produksi masih ditolak oleh gerbang aset** sampai logo/nama, font Baloo 2/Nunito, persetujuan musik, dan lisensi MP3 final (lihat `assets/PLACEHOLDERS.md`). `ALLOW_PLACEHOLDERS=1` di `Dockerfile`, `fly.toml`, dan `render.yaml` melewati gerbang itu untuk uji/staging; hapus setelah aset final lengkap.
5. Server tidak memakai basis data eksternal; bila nanti perlu penyimpanan terkelola, titik penggantinya adalah kelas `JsonlStore` di `server/src/store.ts`.

### Menghubungkan SIMPETERI
Di pengaturan build SIMPETERI (Lovable → Environment/Secrets) isi `VITE_ROUTE_RUSH_URL=https://alamat-server-anda`. Halaman Route Rush di SIMPETERI lalu memakainya sebagai alamat bawaan; guru masih bisa menggantinya (pilihan terakhir diingat di peramban). Halaman memperingatkan bila alamat memakai http di internet. Server online yang diakses dari SIMPETERI harus **https**, karena SIMPETERI sendiri https dan peramban dapat memblokir atau mengalihkan alamat http. Klip suara nama berada di SIMPETERI (`public/route-rush/names`), jadi tidak perlu diatur di server.

## 11. Tautan dari SIMPETERI: PIN guru, laporan, dan kembali

Dipakai oleh menu Multi Permainan SIMPETERI. Semua bidang tambahan bersifat opsional; tanpa mereka layar guru bekerja seperti biasa.

1. **Pesan roster** `route-rush:roster` (setelah `route-rush:host-ready`, dari jendela pembuka) boleh membawa `pin` (4–32 karakter, tanpa karakter kontrol dan tanpa spasi di tepi), `kembali` (URL mutlak http/https yang **satu asal** dengan pengirim pesan, tanpa kredensial) dan `multiSesi` (id huruf/angka/`-`/`_`, maksimal 64). Bidang yang ada tetapi tidak sah menolak seluruh pesan.
2. **PIN menjadi token guru.** Layar guru mengirimnya sebagai `hostToken` opsional di `host:create`; server memakainya sebagai token guru (4–32 karakter), tanpa PIN token tetap acak. Guru tidak diminta PIN di dalam game. PIN hanya hidup di memori dan `sessionStorage` tab itu (agar sesi pulih saat muat ulang); tidak masuk URL, log, atau `localStorage`. Di berkas data sesi hanya tersimpan hash bergaram (`auth`), bukan PIN.
3. **Kembali ke SIMPETERI.** Setelah guru menutup sesi (Akhiri), muncul hitung mundur 5 detik yang bisa dibatalkan atau dipercepat, lalu layar guru pindah ke `kembali` dengan `selesai=1&gameSesi=<sessionId>` ditambahkan. Di layar podium juga ada tombol "Kembali ke SIMPETERI".
4. **Menarik laporan.** `GET /api/sessions/:id/summary.json?includeTest=1` dengan header `x-host-token: <PIN>`:

| Status | Arti |
|---|---|
| 200 | PIN benar dan sesi sudah berakhir |
| 401 `PIN_SALAH` | header tidak ada atau PIN salah (juga untuk sesi yang sudah berakhir: hash-nya tersimpan) |
| 403 `BELUM_SELESAI` | PIN benar tetapi sesi masih berjalan dan peminta lintas asal (ada header `Origin`) |
| 404 | sesi tidak ada |
| 429 | terlalu banyak PIN salah dari alamat yang sama (8 kali dalam 10 menit, kunci 10 menit; berlaku juga untuk event socket guru) |

Layar guru sendiri (sama asal, tanpa `Origin`) boleh membaca laporan sesi yang masih berjalan lewat menu Laporan; tautan unduhan di podium kini mengambil berkas dengan token lalu mengunduhnya. Data lama tanpa `auth` tetap terbaca seperti semula.

**CORS:** `/api/sessions/*` hanya memberi `Access-Control-Allow-Origin` untuk asal di `ALLOWED_ORIGINS` (atau semua asal bila `*`), dengan `Access-Control-Allow-Headers: x-host-token` dan jawaban `OPTIONS` 204. Di produksi bawaannya `same-origin`, jadi **daftarkan asal SIMPETERI** di `ALLOWED_ORIGINS`.

> PIN buatan manusia lebih lemah daripada token acak. Pembatas percobaan di atas mengurangi tebakan, tetapi pakai PIN yang tidak mudah ditebak. Bila PIN memuat karakter non-Latin, header HTTP dari peramban bisa gagal: pakai karakter ASCII yang tercetak.

## 12. Soal beda untuk tiap siswa (anti contek)

Pengaturan **`uniqueMaps`** ("Soal beda tiap siswa", aktif bawaannya di layar guru; mati bawaannya bila server dipanggil langsung):

- Tiap siswa mendapat peta **buatan sendiri** per ronde, dari benih `sesi|siswa|ronde|tingkat`, sehingga tidak ada dua siswa dengan bentuk jalan atau bobot yang sama (dijaga lewat sidik bentuk peta).
- **Setara tingkatnya.** Tantangan: konfigurasi tingkat siswa itu. Bank A/B: jumlah rute sederhana selisih ≤ 1 dan biaya optimal selisih ≤ 3 dari soal acuan ronde (syarat kesetaraan 8.5). Bila generator gagal, soal acuan bank dipakai.
- **Soal pertama paling mudah**: ronde 1 (Tantangan: tingkat 1, 8 tempat), hanya bentuknya yang diacak. Selanjutnya Tantangan tetap adaptif.
- Ringkasan ronde di proyektor menampilkan paling banyak 4 peta yang dipakai siswa. Ronde latihan tetap satu peta dengan varian per siswa.
- Catatan penelitian: peta unik tidak ikut uji kesetaraan 8.5 bank A/B secara penuh; matikan pengaturan ini bila data perlu dibandingkan antarform.

## 13. HP, tablet, dan layar utama (Android, iPhone, iPad/iPadOS)

- **Aplikasi bisa dipasang (PWA):** `manifest.webmanifest`, ikon (`client/public/icons/`, dibuat ulang dengan `node scripts/gen-icons.mjs`), `sw.js`, dan tag `apple-mobile-web-app-*`. Android/Chrome menampilkan tombol "Pasang di layar utama"; iPhone/iPad (Safari) menampilkan langkah Bagikan → Tambah ke Layar Utama. Service worker hanya menyimpan kerangka halaman dan berkas statis; socket, API, dan klip suara tidak pernah disimpan, jadi permainan tetap butuh internet. Hanya didaftarkan di build produksi pada https atau localhost.
- **Sentuhan:** tanpa jeda ketuk-dua-kali, teks tidak terpilih saat menekan peta/tombol, huruf isian ≥ 16 px (iOS tidak memperbesar layar), `overscroll-behavior: none`, getar singkat di Android saat mengetuk (iPhone tidak mendukung getar web).
- **Layar berlekuk dan layar penuh:** `viewport-fit=cover` dengan `env(safe-area-inset-*)`; `100dvh` untuk bilah alamat HP.
- **Ukuran:** sasaran sentuh ≥ 44–48 px, HP kecil (≤ 380 px), HP mendatar (tinggi pendek), dan tablet (≥ 768 px, kolom lebih lebar, peta dan kursi lebih besar).
- Mode layar penuh siswa memakai Fullscreen API bila ada; di iPhone Safari tidak ada, dan tidak ada peringatan "kembali ke layar penuh" karena peringatan itu hanya muncul setelah siswa pernah masuk layar penuh.
- Belum diuji di perangkat sungguhan (hanya emulasi lebar di peramban).

## 14. Di bawah awalan jalur (gerbang satu pintu SIMPETERI)

Untuk mengakses semua game lewat satu alamat (mis. `http://<host>/games/route-rush`) tanpa port terpisah, Route Rush bisa hidup di bawah awalan jalur. Gerbang meneruskan `/games/route-rush/**` apa adanya (tanpa memotong awalan), termasuk upgrade WebSocket.

- **Variabel `BASE_PATH`** (server dan build klien harus sama). Dinormalkan: diawali `/`, tanpa `/` akhir; `games/route-rush/` menjadi `/games/route-rush`; kosong atau `/` = dari akar, perilaku lama tidak berubah. Hanya huruf, angka, `- _ . /` yang diterima; segmen `..` ditolak dengan peringatan.
- **Server** memasang halaman, fallback SPA, `/health`, `/clips`, `/api/**`, dan Socket.IO (`path: BASE_PATH + "/socket.io"`) di bawah awalan itu. `/health` tetap juga ada di akar untuk pemeriksa kesehatan platform. Jalur lain di luar awalan dijawab 404.
- **Klien** dibangun dengan Vite `base` = `BASE_PATH + "/"`. Semua jalur ke server (socket, API, unduhan, tautan Layar guru, service worker, alamat yang ditampilkan ke siswa) disusun lewat `client/src/basePath.ts` (`withBase`, `socketPath`, `routeOf`, `studentAddress`); jangan menulis jalur dari akar langsung. Manifest PWA memakai jalur relatif dan service worker mengambil awalannya dari cakupan pendaftarannya.
- **CORS dan `ALLOWED_ORIGINS`** tetap berlaku untuk akses lintas asal; di mode satu pintu semuanya satu asal.

```bash
# build klien dan jalankan server di bawah awalan (dari folder games/route-rush)
BASE_PATH=/games/route-rush npm run build:dev
BASE_PATH=/games/route-rush PORT=3000 npm start
# Windows PowerShell: $env:BASE_PATH="/games/route-rush"; npm run build:dev; npm start
# Docker: docker build --build-arg BASE_PATH=/games/route-rush ...
```

**Port bawaan server: 3000** (`PORT` di lingkungan; Dockerfile memakai 8080). Alamat untuk gerbang: `http://127.0.0.1:3000`, jalur `/games/route-rush/**`. Pemeriksaan: `GET /games/route-rush/health` harus menjawab JSON `{ ok: true, game: "ROUTE_RUSH", ... }`. `build` produksi (`npm run build`) tetap menolak selama aset sementara masih ada; `build:dev` melewatinya.
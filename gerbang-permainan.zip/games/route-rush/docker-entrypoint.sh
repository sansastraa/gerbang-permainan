#!/bin/sh
# Volume dari hosting sering dimiliki root: pastikan folder data bisa ditulis, lalu jalankan server sebagai pengguna biasa.
set -e
DIR="${DATA_DIR:-/data}"
mkdir -p "$DIR"
if [ "$(id -u)" = "0" ]; then
  chown -R node:node "$DIR" 2>/dev/null || echo "PERINGATAN: tidak dapat mengubah pemilik $DIR"
  exec setpriv --reuid=node --regid=node --init-groups "$@"
fi
exec "$@"
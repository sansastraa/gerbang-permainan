# Lisensi aset

- **Kode** dan **aset audio**: lihat `assets/audio/LICENSES.md` (semua dibuat sendiri).
- **Logo pembuat** (`assets/brand/logo.svg`): gambar sederhana buatan sendiri; sementara sampai logo pembuat sebenarnya tersedia.
- **Ikon tempat, kurir, dan adegan intro**: digambar sendiri dalam SVG (tanpa aset berhak cipta).
- **Font** Baloo 2 dan Nunito (SIL Open Font License 1.1): **belum disertakan** di `client/public/fonts/`. Saat berkas diletakkan, salin teks lisensi OFL masing-masing ke folder yang sama dan perbarui berkas ini.
- **Pustaka npm**: lisensi masing-masing paket (React, Vite, Socket.IO, Express, dll.) ada di `node_modules/*/LICENSE`.
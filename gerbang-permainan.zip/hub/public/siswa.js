// Skrip Gerbang yang disuntik ke halaman game: (1) denyut perangkat anonim, (2) popup umpan balik wajib di perangkat murid,
// (3) papan hasil umpan balik di layar proyektor. Tidak ada nama atau identitas murid yang dikirim. Gaya di /siswa.css (kelas gp-*).
(function () {
  "use strict";
  if (window.__gerbangSiswa) return;
  window.__gerbangSiswa = true;
  var skrip = document.currentScript;
  var game = (skrip && skrip.getAttribute("data-game")) || "";
  var paksa = skrip && skrip.getAttribute("data-peran");
  var dev = "";
  try { dev = localStorage.getItem("gerbang.dev") || ""; if (!/^[\w-]{8,40}$/.test(dev)) { dev = "d" + Math.random().toString(36).slice(2, 12) + Date.now().toString(36); localStorage.setItem("gerbang.dev", dev); } } catch { dev = "t" + Math.random().toString(36).slice(2, 14); }

  function peran() {
    if (paksa) return paksa;
    var p = location.pathname.toLowerCase();
    if (/\/(host|operator|admin|station|obs)(\/|$)/.test(p)) return "guru";
    if (/\/(projector|display|watch|layar)(\/|$)/.test(p)) return "proyektor";
    return "siswa";
  }
  function el(tag, kelas, teks) { var e = document.createElement(tag); if (kelas) e.className = kelas; if (teks != null) e.textContent = teks; return e; }
  function kirim(url, badan) {
    return fetch(url, { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(badan), cache: "no-store" }).then(function (r) { return r.json().then(function (j) { return { ok: r.ok, j: j }; }); });
  }

  var modal = null, layar = null, sedangKirim = false;
  // ---------- gerbang guru: halaman host/proyektor hanya untuk yang sudah memasukkan PIN guru ----------
  var jalurGuru = /\/(host|operator|admin|projector|display|watch|obs|station|layar)(\/|$)/i;
  var kunciEl = null;
  function bukaKunci() {
    if (kunciEl) return;
    kunciEl = el("div", "gp-overlay gp-guru"); kunciEl.setAttribute("role", "dialog"); kunciEl.setAttribute("aria-modal", "true");
    var k = el("div", "gp-kartu"); k.appendChild(el("div", "gp-label", "Khusus guru")); k.appendChild(el("h2", "gp-judul", "Halaman ini khusus guru."));
    k.appendChild(el("p", "gp-ket", "Layar guru dan proyektor hanya bisa dibuka dengan PIN guru. Murid, silakan kembali dan masuk dari halaman permainan."));
    var f = el("form", "gp-form"); var i = el("input", "gp-pin"); i.type = "password"; i.placeholder = "PIN guru"; i.maxLength = 32; i.autocomplete = "off"; i.setAttribute("aria-label", "PIN guru");
    var b = el("button", "gp-kirim gp-sempit", "Buka"); b.type = "submit"; var s = el("div", "gp-galat"); s.setAttribute("role", "status");
    f.onsubmit = function (e) { e.preventDefault(); s.textContent = ""; kirim("/api/pin", { pin: i.value }).then(function (r) { if (r.ok) location.reload(); else s.textContent = "PIN belum tepat."; }).catch(function () { s.textContent = "Gagal terhubung."; }); };
    f.appendChild(i); f.appendChild(b); k.appendChild(f); k.appendChild(s);
    var a = el("a", "gp-kembali", "← Kembali ke Gerbang"); a.href = "/"; k.appendChild(a);
    kunciEl.appendChild(k); document.body.appendChild(kunciEl); document.documentElement.classList.add("gp-kunci"); i.focus();
  }
  function periksaGuru(lanjut) {
    if (!jalurGuru.test(location.pathname)) { if (kunciEl) { kunciEl.remove(); kunciEl = null; document.documentElement.classList.remove("gp-kunci"); } return lanjut(true); }
    fetch("/api/guru/cek", { cache: "no-store" }).then(function (r) { return r.json(); }).then(function (j) { if (j.guru) { if (kunciEl) { kunciEl.remove(); kunciEl = null; document.documentElement.classList.remove("gp-kunci"); } lanjut(true); } else { bukaKunci(); lanjut(false); } }).catch(function () { lanjut(false); });
  }
  ["pushState", "replaceState"].forEach(function (n) { var asli = history[n]; history[n] = function () { var r = asli.apply(this, arguments); setTimeout(denyut, 0); return r; }; });
  window.addEventListener("popstate", function () { setTimeout(denyut, 0); });

  function denyut() {
    periksaGuru(function (boleh) { if (boleh) denyutIsi(); });
  }
  function denyutIsi() {
    var pr = peran();
    if (pr === "guru") { tutupModal(); tutupLayar(); return; }
    kirim("/api/siswa/denyut", { dev: dev, game: game, peran: pr, info: { lebar: screen.width, tinggi: screen.height, dpr: window.devicePixelRatio || 1, sentuh: navigator.maxTouchPoints || 0, bahasa: navigator.language || "" } })
      .then(function (r) {
        if (!r.ok) return;
        if (pr === "siswa") { if (r.j.umpan) bukaModal(r.j.umpan); else tutupModal(); }
        if (pr === "proyektor") { if (r.j.layar) gambarLayar(r.j.layar); else tutupLayar(); }
      }).catch(function () { /* jaringan putus: coba lagi di denyut berikutnya */ });
  }

  // ---------- popup siswa ----------
  function bintang(nilai, ubah) {
    var baris = el("div", "gp-bintang"); baris.setAttribute("role", "radiogroup");
    for (var i = 1; i <= 5; i++) (function (n) {
      var b = el("button", "gp-b" + (nilai >= n ? " on" : ""), "★"); b.type = "button"; b.setAttribute("aria-label", n + " bintang"); b.setAttribute("role", "radio"); b.setAttribute("aria-checked", String(nilai === n));
      b.onclick = function () { ubah(n); }; baris.appendChild(b);
    })(i);
    return baris;
  }
  function bukaModal(u) {
    if (modal || sedangKirim) return;
    var jawab = { sesiId: u.sesiId, dev: dev, favorit: "", rating: {}, kuis: [0, 0, 0] };
    var kotak = el("div", "gp-overlay"); kotak.setAttribute("role", "dialog"); kotak.setAttribute("aria-modal", "true"); kotak.setAttribute("aria-label", "Umpan balik anonim");
    var kartu = el("div", "gp-kartu");
    kotak.appendChild(kartu); document.body.appendChild(kotak); modal = kotak;
    document.documentElement.classList.add("gp-kunci");
    function gambar() {
      var lengkap = jawab.favorit && u.games.every(function (g) { return jawab.rating[g.key]; }) && jawab.kuis.every(function (n) { return n > 0; });
      kartu.textContent = "";
      kartu.appendChild(el("div", "gp-label", "Umpan balik wajib · anonim"));
      kartu.appendChild(el("h2", "gp-judul", "Bagaimana permainan hari ini?"));
      kartu.appendChild(el("p", "gp-ket", "Namamu tidak tercatat. Jawabanmu hanya dihitung bersama teman sekelas dan ditampilkan di layar proyektor."));
      kartu.appendChild(el("h3", "gp-h", "1. Game yang paling kamu suka"));
      var pil = el("div", "gp-pilih");
      u.games.forEach(function (g) { var b = el("button", "gp-chip " + g.tema + (jawab.favorit === g.key ? " on" : ""), g.label); b.type = "button"; b.setAttribute("aria-pressed", String(jawab.favorit === g.key)); b.onclick = function () { jawab.favorit = g.key; gambar(); }; pil.appendChild(b); });
      kartu.appendChild(pil);
      kartu.appendChild(el("h3", "gp-h", "2. Beri bintang tiap game"));
      u.games.forEach(function (g) { var r = el("div", "gp-baris"); r.appendChild(el("span", "gp-nama " + g.tema, g.label)); r.appendChild(bintang(jawab.rating[g.key] || 0, function (n) { jawab.rating[g.key] = n; gambar(); })); kartu.appendChild(r); });
      kartu.appendChild(el("h3", "gp-h", "3. Tiga pertanyaan singkat"));
      u.kuis.forEach(function (teks, i) {
        var blok = el("div", "gp-kuis"); blok.appendChild(el("p", "gp-tanya", teks));
        var skala = el("div", "gp-skala"); skala.setAttribute("role", "radiogroup");
        for (var n = 1; n <= 5; n++) (function (nn) { var b = el("button", "gp-n" + (jawab.kuis[i] === nn ? " on" : ""), String(nn)); b.type = "button"; b.setAttribute("role", "radio"); b.setAttribute("aria-checked", String(jawab.kuis[i] === nn)); b.onclick = function () { jawab.kuis[i] = nn; gambar(); }; skala.appendChild(b); })(n);
        blok.appendChild(skala);
        var ujung = el("div", "gp-ujung"); ujung.appendChild(el("span", null, "Tidak setuju")); ujung.appendChild(el("span", null, "Sangat setuju")); blok.appendChild(ujung);
        kartu.appendChild(blok);
      });
      var kirimBtn = el("button", "gp-kirim", lengkap ? "Kirim jawaban" : "Lengkapi semua jawaban dulu"); kirimBtn.type = "button"; kirimBtn.disabled = !lengkap;
      kirimBtn.onclick = function () {
        sedangKirim = true; kirimBtn.disabled = true; kirimBtn.textContent = "Mengirim…";
        kirim("/api/umpan/kirim", jawab).then(function (r) {
          sedangKirim = false;
          if (r.ok) { kartu.textContent = ""; var t = el("div", "gp-terima"); t.appendChild(el("div", "gp-centang", "✓")); t.appendChild(el("h2", "gp-judul", "Terima kasih!")); t.appendChild(el("p", "gp-ket", "Jawabanmu sudah masuk.")); kartu.appendChild(t); setTimeout(tutupModal, 1600); }
          else { kirimBtn.disabled = false; kirimBtn.textContent = "Gagal, coba kirim lagi"; }
        }).catch(function () { sedangKirim = false; kirimBtn.disabled = false; kirimBtn.textContent = "Gagal, coba kirim lagi"; });
      };
      kartu.appendChild(kirimBtn);
    }
    gambar();
  }
  function tutupModal() { if (sedangKirim) return; if (modal) { modal.remove(); modal = null; } document.documentElement.classList.remove("gp-kunci"); }

  // ---------- papan di proyektor ----------
  function gambarLayar(d) {
    if (!layar) { layar = el("div", "gp-layar"); layar.setAttribute("role", "dialog"); layar.setAttribute("aria-label", "Hasil umpan balik kelas"); document.body.appendChild(layar); }
    var r = d.ringkas, maks = Math.max.apply(null, [1].concat(d.games.map(function (g) { return r.favorit[g.key]; })));
    layar.textContent = "";
    var isi = el("div", "gp-isi");
    var kepala = el("div", "gp-kepala"); kepala.appendChild(el("div", "gp-label", "Umpan balik kelas · anonim")); kepala.appendChild(el("h1", "gp-besar", "Kata kalian tentang permainan hari ini"));
    var hitung = el("div", "gp-hitung"); hitung.appendChild(el("b", null, String(r.jumlah))); hitung.appendChild(el("span", null, d.terhubung ? "dari " + Math.max(d.terhubung, r.jumlah) + " siswa sudah mengisi" : "siswa sudah mengisi")); kepala.appendChild(hitung);
    isi.appendChild(kepala);
    var kolom = el("div", "gp-kolom");
    var a = el("section", "gp-seksi"); a.appendChild(el("h3", "gp-h", "Game paling disuka"));
    d.games.forEach(function (g) { var b = el("div", "gp-bar"); b.appendChild(el("span", "gp-nama " + g.tema, g.label)); var t = el("span", "gp-trek"); var i = el("i", g.tema); i.style.width = (r.favorit[g.key] / maks * 100) + "%"; t.appendChild(i); b.appendChild(t); b.appendChild(el("b", null, String(r.favorit[g.key]))); a.appendChild(b); });
    kolom.appendChild(a);
    var c = el("section", "gp-seksi"); c.appendChild(el("h3", "gp-h", "Rata-rata bintang"));
    d.games.forEach(function (g) { var b = el("div", "gp-bar"); b.appendChild(el("span", "gp-nama " + g.tema, g.label)); var t = el("span", "gp-trek"); var i = el("i", g.tema); i.style.width = (r.rating[g.key].rata / 5 * 100) + "%"; t.appendChild(i); b.appendChild(t); b.appendChild(el("b", null, r.rating[g.key].rata ? r.rating[g.key].rata.toFixed(1) + " ★" : "–")); c.appendChild(b); });
    kolom.appendChild(c);
    isi.appendChild(kolom);
    var q = el("section", "gp-seksi gp-lebar"); q.appendChild(el("h3", "gp-h", "Pendapat kelas (1 = tidak setuju, 5 = sangat setuju)"));
    r.kuis.forEach(function (k) { var b = el("div", "gp-bar gp-kq"); b.appendChild(el("span", "gp-tanya", k.teks)); var t = el("span", "gp-trek"); var i = el("i", "aksen"); i.style.width = (k.rata / 5 * 100) + "%"; t.appendChild(i); b.appendChild(t); b.appendChild(el("b", null, k.rata ? k.rata.toFixed(1) : "–")); q.appendChild(b); });
    isi.appendChild(q);
    layar.appendChild(isi);
  }
  function tutupLayar() { if (layar) { layar.remove(); layar = null; } }

  denyut();
  setInterval(denyut, 4000);
})();
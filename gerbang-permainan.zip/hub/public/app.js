import { GAMES, SEGERA, MIN_GAME, MAX_GAME, cariGame, pinSah } from "/lib/katalog.mjs";
import { LABEL_ATURAN } from "/lib/skor.mjs";
import { bangunPesan, serahkan } from "/lib/handoff.mjs";
import { namaDariTeks } from "/lib/impor.mjs";

const KUNCI_PIN = "gerbang.pin";
const s = { pin: sessionStorage.getItem(KUNCI_PIN) ?? "", buka: false, tab: "dunia", kelas: [], kelasId: localStorage.getItem("gerbang.kelas") ?? "", hidup: {}, sesi: [], aktif: null, pilih: [], aturan: "peringkat", hof: null, pesan: "", salah: false, tunda: null, hanyaHadir: localStorage.getItem("gerbang.hanyaHadir") === "1", presTgl: "", presMode: "input", hariIni: null };
const app = document.getElementById("app");

function h(tag, atribut, ...anak) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(atribut ?? {})) {
    if (v === false || v == null) continue;
    if (k.startsWith("on")) e.addEventListener(k.slice(2), v);
    else if (k === "class") e.className = v;
    else if (k === "style") e.style.cssText = v;
    else e.setAttribute(k, v === true ? "" : v);
  }
  for (const a of anak.flat()) if (a != null && a !== false) e.append(a.nodeType ? a : document.createTextNode(String(a)));
  return e;
}
const svg = (isi, vb = "0 0 24 24") => { const d = document.createElement("div"); d.innerHTML = `<svg viewBox="${vb}" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${isi}</svg>`; return d.firstChild; };
const LAMBANG = {
  rute: '<circle cx="8" cy="38" r="4"/><circle cx="40" cy="10" r="4"/><circle cx="30" cy="34" r="3"/><path d="M11 35c10-2 6-14 16-14s6-6 10-8"/>',
  klaim: '<rect x="5" y="5" width="12" height="12" rx="2"/><rect x="18" y="5" width="12" height="12" rx="2" fill="currentColor" opacity=".35"/><rect x="31" y="5" width="12" height="12" rx="2"/><rect x="5" y="18" width="12" height="12" rx="2" fill="currentColor" opacity=".35"/><rect x="18" y="18" width="12" height="12" rx="2"/><rect x="31" y="18" width="12" height="12" rx="2" fill="currentColor" opacity=".35"/><rect x="5" y="31" width="12" height="12" rx="2"/><rect x="18" y="31" width="12" height="12" rx="2" fill="currentColor" opacity=".35"/>',
  glasial: '<path d="M24 4v40M7 14l34 20M41 14L7 34M18 7l6 5 6-5M18 41l6-5 6 5"/>',
  logika: '<path d="M24 5l16 11-6 22H14L8 16z"/><path d="M8 16h32M24 5l-6 11 6 22 6-22z"/>',
  menara: '<path d="M10 42V30h8v12M20 42V18h8v24M30 42V8h8v34M6 42h36"/><circle cx="34" cy="4" r="0"/>',
  transit: '<rect x="9" y="6" width="30" height="28" rx="8"/><path d="M9 22h30M17 40l-4 4M31 40l4 4"/><circle cx="17" cy="28" r="1.8"/><circle cx="31" cy="28" r="1.8"/>',
};
const lambang = (tema) => { const e = svg(LAMBANG[tema], "0 0 48 48"); e.setAttribute("class", "lambang"); e.setAttribute("stroke-width", "2.4"); return e; };
const ikonGembok = () => svg('<rect x="5" y="11" width="14" height="10" rx="2" fill="#15171f" stroke="#15171f"/><path d="M8 11V8a4 4 0 0 1 8 0v3" stroke="#e9b44c"/>');

async function api(path, { metode = "GET", badan, pin = s.pin } = {}) {
  const r = await fetch(path, { method: metode, headers: { "x-host-token": pin, ...(badan ? { "content-type": "application/json" } : {}) }, body: badan ? JSON.stringify(badan) : undefined });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error ?? `HTTP ${r.status}`), { status: r.status });
  return j;
}
function toast(teks) {
  document.querySelector(".toast")?.remove();
  const t = h("div", { class: "toast", role: "status" }, teks);
  document.body.append(t);
  setTimeout(() => t.remove(), 5200);
}
const kelasAktif = () => s.kelas.find((k) => k.id === s.kelasId) ?? s.kelas[0] ?? null;

async function muatStatus() {
  try { const j = await (await fetch("/api/status")).json(); s.hidup = Object.fromEntries(j.games.map((g) => [g.key, g.hidup])); s.rawat = Object.fromEntries(j.games.map((g) => [g.key, !!g.perawatan])); } catch { /* server hub tak terjangkau */ }
}
async function muatData() {
  s.kelas = (await api("/api/kelas")).kelas;
  if (!s.kelas.some((k) => k.id === s.kelasId)) s.kelasId = s.kelas[0]?.id ?? "";
  s.sesi = (await api("/api/multi")).sesi;
}

async function masuk(pin) {
  try {
    await api("/api/pin", { metode: "POST", badan: { pin }, pin });
  } catch (e) {
    s.salah = true;
    s.pesan = e.status === 429 ? "Terlalu banyak percobaan. Tunggu semenit." : "PIN belum tepat. Coba lagi.";
    return false;
  }
  s.pin = pin; s.salah = false; sessionStorage.setItem(KUNCI_PIN, pin);
  return true;
}
function kunciLagi() { fetch("/api/keluar", { method: "POST" }).catch(() => {}); sessionStorage.removeItem(KUNCI_PIN); s.pin = ""; s.buka = false; s.pesan = ""; render(); }

// --- peluncuran game ---
async function luncurkan(game, multiSesi) {
  const k = kelasAktif();
  if (!k) { toast("Buat kelas dulu di tab Kelas."); s.tab = "kelas"; return render(); }
  const jendela = window.open("about:blank", "_blank");
  if (!jendela) return toast("Peramban memblokir tab baru. Izinkan popup untuk alamat ini, lalu klik lagi.");
  let siswa = k.siswa;
  if (s.hanyaHadir) {
    try {
      const r = await api(`/api/presensi/hadir?kelas=${k.id}&tanggal=${hariIni()}`);
      if (!r.tercatat) { jendela.close(); toast("Presensi hari ini belum diisi. Isi dulu, atau matikan pilihan hanya yang hadir."); s.tab = "presensi"; return render(); }
      if (!r.siswa.length) { jendela.close(); return toast("Belum ada siswa berstatus hadir hari ini."); }
      siswa = r.siswa;
    } catch { jendela.close(); return toast("Gagal membaca presensi. Coba lagi."); }
  }
  const kembali = new URL("/", location.origin);
  kembali.searchParams.set("game", game.key);
  if (multiSesi) kembali.searchParams.set("multi", multiSesi);
  const pesan = bangunPesan(game.key, k.nama, siswa, { pin: s.pin, kembali: kembali.toString(), multiSesi });
  const tunggu = serahkan(game, jendela, pesan, location.origin);
  jendela.location.href = `${game.prefix}/host`;
  tunggu.then((r) => toast(`${r.pesan}${s.hanyaHadir ? ` (${siswa.length} siswa hadir)` : ""}`));
}
const hariIni = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`; };
const geserHari = (t, n) => { const d = new Date(`${t}T00:00:00Z`); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10); };
const namaHari = (t) => new Date(`${t}T00:00:00`).toLocaleDateString("id-ID", { weekday: "long", day: "numeric", month: "long", year: "numeric" });
async function muatHariIni() {
  const k = kelasAktif();
  if (!k) { s.hariIni = null; return; }
  s.hariIni = await api(`/api/presensi?kelas=${k.id}&tanggal=${hariIni()}`).then((r) => ({ ...r, kelasId: k.id })).catch(() => null);
}
/** Sakelar "hanya yang hadir hari ini": dipakai di tab Dunia dan Multi Permainan. */
function pilihanHadir() {
  const p = s.hariIni, k = kelasAktif();
  const tercatat = p && p.kelasId === k?.id && p.ada;
  const total = k?.siswa.length ?? 0;
  const info = !k ? "" : tercatat ? `${p.ringkas.hadir} dari ${total} siswa hadir hari ini` : "Presensi hari ini belum diisi";
  return h("div", { class: `hadir-sw ${s.hanyaHadir ? "aktif" : ""}` },
    h("button", { class: "sakelar", role: "switch", "aria-checked": String(s.hanyaHadir), "aria-label": "Hanya siswa yang hadir hari ini", onclick: () => { s.hanyaHadir = !s.hanyaHadir; localStorage.setItem("gerbang.hanyaHadir", s.hanyaHadir ? "1" : "0"); render(); } }, h("i")),
    h("div", null, h("b", null, "Hanya siswa yang hadir hari ini"), h("small", null, info)),
    k && !tercatat && h("button", { class: "tbl", onclick: () => { s.tab = "presensi"; s.presTgl = hariIni(); render(); } }, "Isi presensi"));
}
// --- tampilan ---
function kepala() {
  const hidup = GAMES.filter((g) => s.hidup[g.key]).length;
  return h("header", { class: "kepala" },
    h("div", { class: "merek" }, svg('<path d="M4 21V11a8 8 0 0 1 16 0v10"/><path d="M9 21v-8a3 3 0 0 1 6 0v8"/>'), "Gerbang Permainan"),
    h("div", { class: "rapat" },
      h("span", { class: "cip", title: "Server game yang menyala" }, h("i", { class: `titik ${hidup ? "hidup" : ""}` }), `${hidup}/${GAMES.length} dunia menyala`),
      s.buka && h("button", { class: "tbl", onclick: kunciLagi }, "Kunci lagi")));
}

function kartuDunia(g, i, { terkunci, pilihMulti }) {
  const dipilih = s.pilih.includes(g.key);
  const rawat = !!s.rawat?.[g.key];
  const hidup = s.hidup[g.key] && !rawat;
  const kartu = h("div", { class: `dunia ${g.tema} ${terkunci ? "terkunci" : ""} ${dipilih ? "pilih" : ""} ${rawat ? "rawat" : ""}`, style: `--i:${i}` },
    lambang(g.tema), h("span", { class: "no" }, `DUNIA ${i + 1}`), dipilih && h("span", { class: "urutan" }, s.pilih.indexOf(g.key) + 1), h("h3", null, g.label), h("p", null, g.ringkas),
    terkunci ? h("span", { class: "kunci-kecil" }, ikonGembok()) : h("span", { class: "kunci-kecil" }, ikonGembok()),
    h("div", { class: "kaki" },
      h("span", { class: "cip" }, h("i", { class: `titik ${hidup ? "hidup" : ""}` }), rawat ? "perawatan" : hidup ? "menyala" : "padam"),
      !terkunci && (pilihMulti
        ? h("button", { class: "tbl", disabled: rawat && !dipilih, "aria-pressed": String(dipilih), onclick: () => { s.pilih = dipilih ? s.pilih.filter((k) => k !== g.key) : s.pilih.length < MAX_GAME ? [...s.pilih, g.key] : s.pilih; render(); } }, dipilih ? `Urutan ${s.pilih.indexOf(g.key) + 1}` : "Pilih")
        : h("button", { class: "tbl utama", disabled: !hidup, onclick: () => luncurkan(g) }, rawat ? "Dirawat" : "Masuk"))));
  if (!terkunci) {
    kartu.addEventListener("pointermove", (e) => { const r = kartu.getBoundingClientRect(); kartu.style.setProperty("--ry", `${((e.clientX - r.left) / r.width - .5) * 10}deg`); kartu.style.setProperty("--rx", `${-((e.clientY - r.top) / r.height - .5) * 10}deg`); kartu.classList.add("miring"); });
    kartu.addEventListener("pointerleave", () => kartu.classList.remove("miring"));
  }
  return kartu;
}

function layarGerbang() {
  const input = h("input", { type: "password", inputmode: "text", autocomplete: "off", maxlength: "32", "aria-label": "PIN guru", placeholder: "PIN guru", id: "pin" });
  const bentuk = h("form", { class: `kunci ${s.salah ? "getar" : ""}`, onsubmit: async (e) => {
    e.preventDefault();
    if (!pinSah(input.value)) { s.salah = true; s.pesan = "PIN 4–32 karakter, tanpa spasi."; return render(); }
    const ok = await masuk(input.value);
    if (ok) await bukaGerbang(); else render();
  } }, input, h("button", { class: "tbl utama", type: "submit" }, "Buka"));
  const gapura = h("div", { class: `gapura ${s.buka ? "terbuka" : ""}`, "aria-hidden": "true" },
    h("div", { class: "lengkung" }, h("div", { class: "cahaya" }), h("div", { class: "daun kiri" }), h("div", { class: "daun kanan" })),
    h("div", { class: "gembok" }, ikonGembok()));
  const layar = h("main", { class: "wadah" }, kepala(), pita(),
    h("section", { class: "panggung" },
      h("div", null,
        h("h1", { class: "judul" }, h("small", null, "Clash of Git"), "Satu ", h("em", null, "gerbang"), ", lima dunia."),
        h("p", { class: "pengantar" }, "Masukkan PIN guru untuk membuka semua permainan sekaligus: daftar kelas ikut terbawa, tanpa PIN ulang di tiap game."),
        bentuk, h("p", { class: `pesan ${s.salah ? "salah" : ""}`, role: "alert" }, s.pesan)),
      gapura),
    h("section", { class: "peta", "aria-label": "Dunia permainan (terkunci)" }, GAMES.map((g, i) => kartuDunia(g, i, { terkunci: true }))),
    segeraHadir());
  return layar;
}

async function bukaGerbang() {
  s.buka = true; s.pesan = ""; s.tab = s.tunda ? "multi" : "dunia";
  render();
  await muatData().catch(() => {});
  if (s.tunda) await selesaiDariGame();
  render();
}

/** Deretan kartu abu-abu permainan yang akan datang (tidak bisa diklik). */
function segeraHadir() {
  return h("section", { class: "segera", "aria-label": "Permainan segera hadir" },
    h("div", { class: "segera-kepala" }, h("h3", null, "Segera hadir"), h("span", null, `${SEGERA.length} permainan berikutnya`)),
    h("div", { class: "segera-grid" }, SEGERA.map((nama, i) => h("div", { class: "segera-kartu", style: `--i:${i}`, role: "img", "aria-label": `${nama}, segera hadir` },
      h("span", { class: "gembok-s" }, ikonGembok()), h("b", null, nama), h("small", null, "coming soon")))));
}
function tabDunia() {
  const k = kelasAktif();
  return h("div", null,
    h("div", { class: "panel" }, h("h2", null, "Pilih dunia"), h("p", { class: "ket" }, k ? `Kelas ${k.nama}: ${k.siswa.length} siswa akan terbawa otomatis, bersama PIN guru.` : "Belum ada kelas. Tambahkan dulu di tab Kelas."), pemilihKelas(), pilihanHadir()),
    h("div", { class: "peta" }, GAMES.map((g, i) => kartuDunia(g, i, { terkunci: false, pilihMulti: false }))),
    segeraHadir());
}
function pemilihKelas() {
  return h("label", { class: "medan" }, "Kelas",
    h("select", { onchange: (e) => { s.kelasId = e.target.value; localStorage.setItem("gerbang.kelas", s.kelasId); s.hariIni = null; render(); } },
      s.kelas.length ? s.kelas.map((k) => h("option", { value: k.id, selected: k.id === s.kelasId }, `${k.nama} (${k.siswa.length})`)) : h("option", null, "— belum ada —")));
}

function tabKelas() {
  const nama = h("input", { placeholder: "mis. 7A", maxlength: "40" });
  const daftar = h("textarea", { placeholder: "Satu nama siswa per baris", oninput: (e) => { if (/\t|;|,/.test(e.target.value)) e.target.dataset.mentah = "1"; }, onpaste: (e) => { const t = e.clipboardData.getData("text"); if (/\t|;|,/.test(t)) { e.preventDefault(); e.target.value = namaDariTeks(t).join("\n"); } } });
  const berkas = h("input", { type: "file", accept: ".csv,.txt,.tsv,text/csv,text/plain", onchange: async (e) => { const f = e.target.files[0]; if (!f) return; const n = namaDariTeks(await f.text()); daftar.value = n.join("\n"); if (!nama.value) nama.value = f.name.replace(/\.[^.]+$/, "").slice(0, 40); toast(`${n.length} nama dibaca dari ${f.name}. Periksa lalu simpan.`); } });
  const simpan = async () => {
    try { const j = await api("/api/kelas", { metode: "POST", badan: { id: nama.dataset.id, nama: nama.value, daftar: daftar.value } }); s.kelas = j.kelas; s.kelasId ||= j.kelas[0]?.id; toast("Kelas tersimpan."); render(); }
    catch (e) { toast(e.message === "siswa_kosong" ? "Isi sedikitnya satu nama." : "Nama kelas wajib diisi."); }
  };
  return h("div", null,
    h("div", { class: "panel" }, h("h2", null, "Kelas tersimpan"),
      s.kelas.length ? h("table", null, h("tbody", null, s.kelas.map((k) => h("tr", null, h("td", null, h("b", null, k.nama)), h("td", { class: "n" }, `${k.siswa.length} siswa`),
        h("td", { class: "n" }, h("button", { class: "tbl", onclick: () => { nama.value = k.nama; nama.dataset.id = k.id; daftar.value = k.siswa.map((x) => x.nama).join("\n"); nama.scrollIntoView({ behavior: "smooth", block: "center" }); } }, "Ubah"), " ",
          h("button", { class: "tbl", onclick: async () => { if (confirm(`Hapus kelas ${k.nama}?`)) { s.kelas = (await api(`/api/kelas/${k.id}`, { metode: "DELETE" })).kelas; render(); } } }, "Hapus")))))) : h("p", { class: "kosong" }, "Belum ada kelas.")),
    h("div", { class: "panel" }, h("h2", null, "Tambah atau ubah kelas"), h("p", { class: "ket" }, "Id siswa dijaga tetap selama nama sama, sehingga hasil game dicocokkan kembali dengan benar."),
      h("label", { class: "medan" }, "Nama kelas", nama), h("label", { class: "medan", style: "margin-top:.6rem" }, "Impor dari berkas (CSV/TXT dengan kolom nama)", berkas), h("label", { class: "medan", style: "margin-top:.6rem" }, "Daftar siswa (boleh ditempel dari Excel/Sheets)", daftar),
      h("div", { class: "baris" }, h("button", { class: "tbl utama", onclick: simpan }, "Simpan kelas"))),
    panelPerangkat());
}

function tabMulti() {
  if (s.aktif) return panelSesi();
  const k = kelasAktif();
  return h("div", null,
    h("div", { class: "panel" }, h("h2", null, "Susun Multi Permainan"),
      h("p", { class: "ket" }, `Pilih ${MIN_GAME}–${MAX_GAME} dunia berurutan. Hasil tiap game dikumpulkan jadi satu Hall of Fame.`),
      h("div", { class: "baris" }, pemilihKelas(),
        h("label", { class: "medan" }, "Aturan skor", h("select", { onchange: (e) => { s.aturan = e.target.value; render(); } }, Object.entries(LABEL_ATURAN).map(([v, a]) => h("option", { value: v, selected: v === s.aturan }, a.judul)))),
      ), pilihanHadir(), h("p", { class: "ket" }, LABEL_ATURAN[s.aturan].ringkas),
      h("div", { class: "rantai", "aria-label": "Urutan permainan terpilih" }, s.pilih.length ? s.pilih.flatMap((k, i) => { const g = cariGame(k); return [i > 0 && h("span", { class: "panah" }, "→"), h("span", { class: `simpul ${g.tema}` }, `${i + 1}. ${g.label}`)]; }) : h("span", { class: "ket" }, "Pilih game yang mau dimainkan; urutan klik = urutan main.")),
      h("div", { class: "peta" }, GAMES.map((g, i) => kartuDunia(g, i, { terkunci: false, pilihMulti: true }))),
      h("div", { class: "baris" }, h("button", { class: "tbl utama", disabled: !k || s.pilih.length < MIN_GAME, onclick: async () => {
        try {
          const j = await api("/api/multi", { metode: "POST", badan: { kelasId: k.id, games: s.pilih, aturan: s.aturan, ...(s.hanyaHadir ? { hanyaHadir: true, tanggal: hariIni() } : {}) } });
          s.aktif = j.sesi; s.pilih = []; await muatData(); render();
        } catch (e) { toast(e.message === "presensi_belum_diisi" ? "Presensi hari ini belum diisi. Isi dulu atau matikan pilihan hanya yang hadir." : e.message === "tidak_ada_yang_hadir" ? "Belum ada siswa berstatus hadir hari ini." : "Gagal membuat Multi Permainan."); }
      } }, "Buat Multi Permainan"), h("span", { class: "ket" }, s.pilih.length ? `${s.pilih.length} dunia dipilih` : ""))),
    daftarSesi());
}
function daftarSesi() {
  return h("div", { class: "panel" }, h("h2", null, "Sesi sebelumnya"),
    s.sesi.length ? h("table", null, h("tbody", null, s.sesi.map((m) => h("tr", null, h("td", null, h("b", null, m.judul)), h("td", null, m.games.map((g) => cariGame(g)?.label).join(" → ")), h("td", { class: "n" }, `${m.selesai}/${m.games.length}`),
      h("td", { class: "n" }, h("button", { class: "tbl", onclick: async () => { s.aktif = (await api(`/api/multi/${m.id}`)).sesi; render(); } }, "Buka")))))) : h("p", { class: "kosong" }, "Belum ada."));
}
function hitungNaik(el, ke, ms = 1100) {
  const t0 = performance.now();
  const f = (t) => { const p = Math.min(1, (t - t0) / ms); el.textContent = String(Math.round(ke * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(f); };
  requestAnimationFrame(f);
}
const MAHKOTA = '<path d="M3 8l4 4 5-7 5 7 4-4-2 11H5z"/>';
/** Papan peringkat: panggung podium gelap, daftar batang animasi, urut per game, baris bisa dibuka. */
function papanPeringkat(hof, { games = [], sesi } = {}) {
  if (!hof.length) return h("p", { class: "kosong" }, "Belum ada hasil. Selesaikan satu game dulu.");
  let urut = "total";
  const buka = new Set();
  const akar = h("div", { class: "papan" });
  const nilaiDari = (r) => (urut === "total" ? r.total : (r.perGame?.[urut]?.skor ?? 0));
  function gambar() {
    const baris = hof.map((r) => ({ r, n: nilaiDari(r) })).sort((x, y) => y.n - x.n || x.r.nama.localeCompare(y.r.nama));
    baris.forEach((b, i) => { b.p = i > 0 && b.n === baris[i - 1].n ? baris[i - 1].p : i + 1; });
    const maks = Math.max(1, ...baris.map((b) => b.n));
    const label = urut === "total" ? "poin" : "skor";
    const statistik = h("div", { class: "statistik" },
      [["Peserta", baris.length], ["Skor tertinggi", maks], sesi != null ? ["Sesi", sesi] : ["Dunia", games.length]].map(([k, v]) => h("div", null, h("b", { "data-ke": v }, "0"), h("small", null, k))));
    const urutan = [baris[1], baris[0], baris[2]].filter(Boolean);
    const panggung = h("div", { class: "panggung-juara" }, urutan.map((b) => {
      const kelas = `m${b.p > 3 ? 3 : b.p}`;
      return h("div", { class: `blok ${kelas} ${b.p === 1 ? "juara" : ""}` },
        b.p === 1 && (() => { const e = svg(MAHKOTA); e.setAttribute("class", "mahkota"); return e; })(),
        h("span", { class: "lencana" }, b.p), h("div", { class: "nm" }, b.r.nama), h("div", { class: "angka" }, h("b", { "data-ke": b.n }, "0"), h("small", null, label)));
    }));
    const sisa = baris.filter((b) => !urutan.includes(b));
    const daftar = h("ol", { class: "daftar-rank" }, sisa.map((b, i) => {
      const terbuka = buka.has(b.r.nama);
      const rincian = [games.length ? games.map((g) => h("span", { class: "chip" }, `${cariGame(g)?.label ?? g}: `, h("b", null, b.r.perGame?.[g] ? `${b.r.perGame[g].skor} (#${b.r.perGame[g].peringkat})` : "–"))) : [h("span", { class: "chip" }, "Sesi: ", h("b", null, b.r.sesi ?? 0)), h("span", { class: "chip" }, "Juara 1: ", h("b", null, b.r.juara1 ?? 0))]];
      return h("li", { class: terbuka ? "buka" : "", style: `--d:${i * 70}ms` },
        h("button", { class: "baris-rank", "aria-expanded": String(terbuka), onclick: () => { terbuka ? buka.delete(b.r.nama) : buka.add(b.r.nama); gambar(); } },
          h("span", { class: "no" }, b.p), h("span", { class: "nama" }, b.r.nama),
          h("span", { class: "batang" }, h("i", { style: `--w:${(b.n / maks) * 100}%` })), h("span", { class: "poin" }, `${b.n}`)),
        terbuka && h("div", { class: "rincian" }, ...rincian));
    }));
    const pilih = h("div", { class: "segmen", role: "group", "aria-label": "Urutkan menurut" },
      ["total", ...games].map((k) => h("button", { class: urut === k ? "aktif" : "", "aria-pressed": String(urut === k), onclick: () => { urut = k; gambar(); } }, k === "total" ? "Total" : (cariGame(k)?.label ?? k))));
    akar.replaceChildren(...[statistik, games.length ? pilih : null, panggung, sisa.length ? daftar : null].filter(Boolean));
    akar.querySelectorAll("[data-ke]").forEach((e) => hitungNaik(e, Number(e.dataset.ke)));
  }
  gambar();
  return akar;
}
function tabelHof(hof, games) { return papanPeringkat(hof, { games }); }
const pita = () => { const t = ["Route Rush","CLAIM 80","GLACIA","Logic Rush","Transit Rush","Tower Peek"].flatMap((x) => [x, "✦"]); const satu = () => t.map((x) => h("span", null, x)); return h("div", { class: "pita", "aria-hidden": "true" }, h("div", null, ...satu(), ...satu(), ...satu(), ...satu())); };
const KERTAS = ["#e8552d", "#0f9d8a", "#15171f", "#8b3fd1", "#0e7fb0", "#d97706"];
function umumkan(m) {
  const hof = m.hof ?? [];
  if (!hof.length) return toast("Belum ada hasil. Selesaikan sedikitnya satu game.");
  const juara = hof.filter((r) => r.peringkat === 1);
  const tutup = () => { clearInterval(tm); ov.remove(); };
  const ov = h("div", { id: "umum", role: "dialog", "aria-label": "Pengumuman pemenang" });
  const tengah = h("div", { class: "tengah" });
  ov.append(tengah);
  document.body.append(ov);
  let n = 3;
  const tampilHitung = () => tengah.replaceChildren(h("h2", null, `Pemenang ${m.judul}`), h("div", { class: "hitung" }, n));
  tampilHitung();
  const tm = setInterval(() => { n--; if (n > 0) return tampilHitung(); clearInterval(tm); ungkap(); }, 900);
  function ungkap() {
    const urut = [3, 2, 1].map((p) => hof.filter((r) => r.peringkat === p)).map((rs, i) => ({ p: 3 - i, rs })).filter((x) => x.rs.length);
    const kolom = urut.map(({ p, rs }) => h("div", { class: `t t${p}` }, p === 1 && svgPiala(), h("b", null, p), h("div", { class: "nm" }, rs.map((r) => r.nama).join(" & ")), h("small", null, `${rs[0].total} poin`)));
    tengah.replaceChildren(h("h2", null, juara.length > 1 ? "Juara bersama!" : "Selamat kepada juara!"), h("div", { class: "tangga" }, kolom),
      h("p", { class: "ket" }, juara.map((r) => r.nama).join(" & ") + ` memimpin dari ${m.games.length} dunia.`), h("button", { class: "tbl utama", onclick: tutup }, "Tutup"));
    kolom.slice().reverse().forEach((k, i) => setTimeout(() => k.classList.add("tampil"), 250 + i * 900));
    setTimeout(() => { for (let i = 0; i < 60; i++) ov.append(h("i", { class: "kertas", style: `left:${Math.random() * 100}%;background:${KERTAS[i % KERTAS.length]};animation-duration:${2.4 + Math.random() * 2.4}s;animation-delay:${Math.random() * 1.2}s` })); }, 250 + (kolom.length - 1) * 900);
  }
  ov.addEventListener("keydown", (e) => e.key === "Escape" && tutup());
}
const svgPiala = () => { const e = svg('<path d="M8 4h8v6a4 4 0 0 1-8 0zM8 6H4v2a4 4 0 0 0 4 4M16 6h4v2a4 4 0 0 1-4 4M12 14v4M8 21h8M10 18h4"/>'); e.setAttribute("class", "piala"); return e; };
function juaraPerDunia(m) {
  const hof = m.hof ?? [];
  return h("div", { class: "juara-dunia" }, m.games.map((k) => { const g = cariGame(k); const menang = hof.filter((r) => r.perGame[k]?.peringkat === 1); return h("div", { class: g.tema }, h("small", null, g.label), h("b", null, menang.length ? menang.map((r) => r.nama).join(" & ") : "belum selesai"), menang.length ? h("small", null, `skor ${menang[0].perGame[k].skor}`) : null); }));
}
// --- umpan balik anonim (guru) ---
function panelUmpan(m) {
  const akar = h("div", { class: "panel umpan-guru" });
  let d = null;
  const semuaSelesai = m.games.every((g) => m.hasil[g]);
  const gambar = () => {
    if (!d) return;
    const r = d.ringkas;
    const aksi = h("div", { class: "baris" },
      h("button", { class: `tbl ${d.aktif ? "" : "utama"}`, onclick: () => atur({ aktif: !d.aktif }) }, d.aktif ? "Tutup umpan balik" : "Buka umpan balik"),
      h("div", { class: `hadir-sw ${d.tampil ? "aktif" : ""}`, style: "margin:0;flex:1;min-width:240px" },
        h("button", { class: "sakelar", role: "switch", "aria-checked": String(d.tampil), "aria-label": "Tampilkan hasil di proyektor", disabled: !d.aktif, onclick: () => atur({ tampil: !d.tampil }) }, h("i")),
        h("div", null, h("b", null, "Tampilkan hasil di proyektor"), h("small", null, d.aktif ? "Muncul di layar proyektor game (projector/display/watch) dan di halaman layar Gerbang." : "Buka umpan balik dulu."))),
      h("button", { class: "tbl", onclick: () => window.open("/layar-umpan.html", "_blank") }, "Buka layar Gerbang"));
    akar.replaceChildren(
      h("div", { class: "judul-pres" }, h("h2", { style: "margin:0" }, "Umpan balik siswa"), h("span", { class: `cip ${d.aktif ? "aktif-cip" : ""}` }, h("i", { class: `titik ${d.aktif ? "hidup" : ""}` }), d.aktif ? "terbuka" : "tertutup")),
      h("p", { class: "ket" }, "Anonim. Saat dibuka, popup wajib muncul di perangkat murid yang sedang membuka game sesi ini: game paling disuka, bintang tiap game, dan tiga pertanyaan. Hasilnya dihitung bersama dan tampil tanpa nama."),
      semuaSelesai && !d.aktif && h("div", { class: "cat hijau" }, h("b", null, "Semua game sudah selesai"), "Buka umpan balik sekarang, lalu tampilkan hasilnya di proyektor game terakhir."),
      h("div", { class: "statistik" }, [["Sudah mengisi", r.jumlah], ["Perangkat terhubung", d.terhubung], ["Siswa di sesi", m.siswa.length]].map(([t, v]) => h("div", null, h("b", null, v), h("small", null, t)))),
      aksi,
      r.jumlah ? h("div", { class: "tabel-gulir" }, h("table", null, h("thead", null, h("tr", null, h("th", null, "Game"), h("th", { class: "n" }, "Disuka"), h("th", { class: "n" }, "Rata-rata bintang"))),
        h("tbody", null, m.games.map((g) => h("tr", null, h("td", null, cariGame(g)?.label ?? g), h("td", { class: "n" }, r.favorit[g]), h("td", { class: "n" }, r.rating[g].rata ? `${r.rating[g].rata.toFixed(1)} ★` : "–"))))),
        h("table", null, h("thead", null, h("tr", null, h("th", null, "Pertanyaan"), h("th", { class: "n" }, "Rata-rata (1–5)"))), h("tbody", null, r.kuis.map((k) => h("tr", null, h("td", null, k.teks), h("td", { class: "n" }, k.rata.toFixed(1))))))) : h("p", { class: "kosong" }, "Belum ada jawaban."));
  };
  const muat = async () => { try { d = await api(`/api/umpan/${m.id}`); gambar(); } catch { /* sesi hilang */ } };
  const atur = async (badan) => { try { await api(`/api/umpan/${m.id}`, { metode: "POST", badan }); await muat(); } catch { toast("Gagal mengubah umpan balik."); } };
  muat();
  clearInterval(s.umpanTimer);
  s.umpanTimer = setInterval(() => { if (!document.body.contains(akar)) return clearInterval(s.umpanTimer); muat(); }, 4000);
  return akar;
}

// --- deteksi perangkat (tab Kelas) ---
function panelPerangkat() {
  const akar = h("div", { class: "panel" });
  const gambar = (d) => {
    const hitung = (o) => Object.entries(o ?? {}).sort((x, y) => y[1] - x[1]);
    akar.replaceChildren(
      h("h2", null, "Perangkat terdeteksi"),
      h("p", { class: "ket" }, "Terbaca otomatis saat murid membuka game lewat gerbang (12 jam terakhir). Anonim: perangkat tidak dikaitkan dengan nama siswa."),
      h("div", { class: "statistik" }, [["Perangkat terlihat", d.total], ["Aktif sekarang", d.aktif], ["Ponsel", d.jenis.Ponsel ?? 0]].map(([t, v]) => h("div", null, h("b", null, v), h("small", null, t)))),
      h("div", { class: "chip-baris" }, [...hitung(d.jenis), ...hitung(d.os), ...hitung(d.peramban)].map(([k, n]) => h("span", { class: "chip" }, `${k} `, h("b", null, n)))),
      d.perangkat.length ? h("div", { class: "tabel-gulir" }, h("table", null, h("thead", null, h("tr", null, ["Perangkat", "Jenis", "Sistem", "Peramban", "Layar", "Sentuh", "Game", "Terakhir", "Lewat"].map((t) => h("th", null, t)))),
        h("tbody", null, d.perangkat.map((p) => h("tr", null, h("td", null, h("i", { class: `titik ${p.aktif ? "hidup" : ""}`, style: "display:inline-block;margin-right:.4rem" }), h("b", null, p.label)), h("td", null, p.jenis), h("td", null, p.os), h("td", null, p.peramban), h("td", null, `${p.lebar}×${p.tinggi}`), h("td", null, p.sentuh ? "ya" : "tidak"), h("td", null, cariGame(p.game)?.label ?? "–"), h("td", null, new Date(p.terakhir).toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })), h("td", null, p.app ? h("span", { class: "lencana-apl" }, "aplikasi") : "web")))))) : h("p", { class: "kosong" }, "Belum ada murid yang membuka game lewat gerbang."));
  };
  const muat = async () => { try { gambar(await api("/api/perangkat")); } catch { /* abaikan */ } };
  muat();
  clearInterval(s.perangkatTimer);
  s.perangkatTimer = setInterval(() => { if (!document.body.contains(akar)) return clearInterval(s.perangkatTimer); muat(); }, 6000);
  return akar;
}
function panelSesi() {
  const m = s.aktif;
  const berikut = m.games.find((g) => !m.hasil[g]);
  const kode = h("input", { placeholder: "kode sesi game", maxlength: "64" });
  const json = h("textarea", { placeholder: "Tempel isi summary.json" });
  const ambil = async (gameKey, badan) => {
    try { const j = await api(`/api/multi/${m.id}/hasil`, { metode: "POST", badan: { gameKey, ...badan } }); s.aktif = j.sesi; toast(j.tidakCocok.length ? `Hasil masuk. ${j.tidakCocok.length} nama tidak cocok dengan kelas.` : "Hasil masuk."); render(); }
    catch (e) { toast(`Gagal mengambil hasil: ${e.message}`); }
  };
  return h("div", null,
    h("div", { class: "panel" }, h("h2", null, m.judul), h("p", { class: "ket" }, `${LABEL_ATURAN[m.aturan].judul} · ${m.siswa.length} siswa`),
      h("ol", { class: "langkah" }, m.games.map((key, i) => { const g = cariGame(key); const sel = !!m.hasil[key]; return h("li", { class: `${sel ? "selesai" : ""} ${key === berikut ? "sekarang" : ""}` },
        h("span", { class: "no" }, sel ? "✓" : i + 1), h("span", { class: "nama" }, g.label), sel ? h("span", { class: "cip" }, `${m.hasil[key].skor.length} siswa`) : h("button", { class: `tbl ${key === berikut ? "utama" : ""}`, disabled: !s.hidup[key], onclick: () => luncurkan(g, m.id) }, "Luncurkan")); })),
      berikut && h("details", null, h("summary", null, `Ambil hasil ${cariGame(berikut).label} secara manual`),
        h("div", { class: "baris" }, kode, h("button", { class: "tbl", onclick: () => ambil(berikut, { gameSesi: kode.value.trim() }) }, "Ambil dari game")), json,
        h("button", { class: "tbl", onclick: () => { try { ambil(berikut, { gameSesi: "manual", json: JSON.parse(json.value) }); } catch { toast("JSON tidak sah."); } } }, "Pakai JSON")),
      h("div", { class: "baris" }, h("button", { class: "tbl", onclick: () => { s.aktif = null; render(); } }, "← Kembali"))),
    h("div", { class: "panel" }, h("h2", null, "Juara tiap dunia"), juaraPerDunia(m)),
    h("div", { class: "panel" }, h("h2", null, "Hall of Fame sesi"), h("div", { class: "baris" }, h("button", { class: "tbl utama", disabled: !(m.hof ?? []).length, onclick: () => umumkan(m) }, "🏆 Umumkan pemenang")), tabelHof(m.hof ?? [], m.games)),
    panelUmpan(m));
}

async function tabHof() {
  const k = kelasAktif();
  if (k && !s.hof) { s.hof = await api(`/api/hof?kelas=${k.id}`).catch(() => ({ sesi: 0, hof: [] })); }
  const hof = s.hof?.hof ?? [];
  return h("div", { class: "panel" }, h("h2", null, `Hall of Fame ${k?.nama ?? ""}`), h("p", { class: "ket" }, `Akumulasi ${s.hof?.sesi ?? 0} Multi Permainan.`), pemilihKelas2(),
    hof.length ? papanPeringkat(hof, { sesi: s.hof?.sesi ?? 0 }) : h("p", { class: "kosong" }, "Belum ada hasil Multi Permainan untuk kelas ini."));
}function pemilihKelas2() { const p = pemilihKelas(); p.querySelector("select").addEventListener("change", () => { s.hof = null; }); return p; }

async function selesaiDariGame() {
  const t = s.tunda; s.tunda = null;
  history.replaceState(null, "", "/");
  if (!t?.multi) { toast(`Sesi ${cariGame(t?.game)?.label ?? "game"} selesai.`); return; }
  try {
    const j = await api(`/api/multi/${t.multi}/hasil`, { metode: "POST", badan: { gameKey: t.game, gameSesi: t.gameSesi } });
    s.aktif = j.sesi; s.tab = "multi"; toast(j.tidakCocok.length ? `Hasil masuk. ${j.tidakCocok.length} nama tidak cocok.` : `Hasil ${cariGame(t.game)?.label} masuk ke Hall of Fame.`);
  } catch (e) {
    s.aktif = (await api(`/api/multi/${t.multi}`).catch(() => ({ sesi: null }))).sesi; s.tab = "multi";
    toast(`Hasil belum bisa diambil otomatis (${e.message}). Gunakan "Ambil hasil secara manual".`);
  }
}

function tabPin() {
  const baru = h("input", { type: "password", maxlength: "32", autocomplete: "off", placeholder: "PIN baru (4–32 karakter)" });
  const ulang = h("input", { type: "password", maxlength: "32", autocomplete: "off", placeholder: "Ulangi PIN baru" });
  const info = s.infoPin ?? { bawaan: false, terkunci: false };
  const ganti = async () => {
    if (!pinSah(baru.value)) return toast("PIN 4–32 karakter, tanpa spasi.");
    if (baru.value !== ulang.value) return toast("Kedua PIN belum sama.");
    try {
      await api("/api/pin/ubah", { metode: "POST", badan: { pinBaru: baru.value } });
      s.pin = baru.value; sessionStorage.setItem(KUNCI_PIN, s.pin); s.infoPin = { bawaan: baru.value === "1234", terkunci: false };
      toast("PIN diganti. Game dimulai ulang sebentar agar memakai PIN baru."); render();
    } catch (e) { toast(e.message === "pin_dari_env" ? "PIN diatur lewat GERBANG_PIN; ubah di sana." : "PIN gagal diganti."); }
  };
  return h("div", { class: "panel" }, h("h2", null, "PIN guru"),
    info.bawaan && h("p", { class: "ket", style: "color:var(--koral)" }, "PIN masih bawaan (1234). Ganti sebelum dipakai di jaringan kelas."),
    h("p", { class: "ket" }, info.terkunci ? "PIN diatur lewat variabel GERBANG_PIN, jadi tidak bisa diubah dari sini." : "PIN ini membuka Gerbang dan semua game. Game yang sedang menyala dimulai ulang saat PIN diganti (sesi yang berjalan terputus)."),
    !info.terkunci && h("div", { class: "baris" }, h("label", { class: "medan" }, "PIN baru", baru), h("label", { class: "medan" }, "Ulangi", ulang), h("button", { class: "tbl utama", onclick: ganti }, "Ganti PIN")));
}
async function tabPerawatan() {
  const data = (await api("/api/perawatan").catch(() => ({ games: {} }))).games;
  const kirim = async (key, aktif, pesan) => {
    try { await api("/api/perawatan", { metode: "POST", badan: { key, aktif, pesan } }); await muatStatus(); toast(aktif ? `${cariGame(key).label} masuk mode perawatan.` : `${cariGame(key).label} dibuka kembali.`); render(); }
    catch { toast("Gagal mengubah mode perawatan."); }
  };
  return h("div", { class: "panel" }, h("h2", null, "Mode perawatan"),
    h("p", { class: "ket" }, "Matikan sebuah game sementara: murid yang membukanya melihat halaman perawatan, dan terbuka sendiri saat game kembali siap. Konsol guru tetap bisa dipakai."),
    h("div", { class: "daftar-rawat" }, GAMES.map((g) => {
      const d = data[g.key] ?? { aktif: false, pesan: "" };
      const pesan = h("input", { type: "text", maxlength: "200", value: d.pesan, placeholder: "Pesan untuk murid (opsional)", "aria-label": `Pesan perawatan ${g.label}` });
      return h("div", { class: `baris-rawat ${g.tema} ${d.aktif ? "aktif" : ""}` },
        h("div", { class: "info" }, h("b", null, g.label), h("small", null, d.aktif ? "Sedang dirawat" : "Terbuka untuk murid")),
        pesan,
        h("button", { class: "sakelar", role: "switch", "aria-checked": String(d.aktif), "aria-label": `Mode perawatan ${g.label}`, onclick: () => kirim(g.key, !d.aktif, pesan.value) }, h("i")),
        d.aktif && h("button", { class: "tbl", onclick: () => kirim(g.key, true, pesan.value) }, "Simpan pesan"));
    })));
}
// --- presensi ---
const ST = [["hadir", "H", "Hadir"], ["izin", "I", "Izin"], ["sakit", "S", "Sakit"], ["alpa", "A", "Alpa"]];
const WARNA_AVATAR = ["#0e7fb0", "#d97706", "#0e9aa7", "#8b3fd1", "#2f9e55", "#e8552d"];
const inisial = (n) => n.split(" ").slice(0, 2).map((x) => x[0]).join("").toUpperCase();

async function tabPresensi() {
  const k = kelasAktif();
  s.presTgl ||= hariIni();
  const kepalaPres = h("div", { class: "panel" }, h("h2", null, "Presensi"),
    h("p", { class: "ket" }, "Catat kehadiran tiap hari. Siswa yang hadir bisa dibawa otomatis ke permainan, dan rekapnya bisa diunduh."),
    h("div", { class: "baris" }, pemilihKelas(),
      h("div", { class: "tanggal" },
        h("button", { class: "tbl", "aria-label": "Hari sebelumnya", onclick: () => { s.presTgl = geserHari(s.presTgl, -1); render(); } }, "‹"),
        h("input", { type: "date", value: s.presTgl, max: "2100-12-31", "aria-label": "Tanggal presensi", onchange: (e) => { if (e.target.value) { s.presTgl = e.target.value; render(); } } }),
        h("button", { class: "tbl", "aria-label": "Hari berikutnya", onclick: () => { s.presTgl = geserHari(s.presTgl, 1); render(); } }, "›"),
        s.presTgl !== hariIni() && h("button", { class: "tbl", onclick: () => { s.presTgl = hariIni(); render(); } }, "Hari ini"))),
    h("div", { class: "segmen", role: "group", "aria-label": "Tampilan presensi" }, [["input", "Input"], ["rekap", "Rekap dan unduh"]].map(([v, t]) => h("button", { class: s.presMode === v ? "aktif" : "", "aria-pressed": String(s.presMode === v), onclick: () => { s.presMode = v; render(); } }, t))));
  if (!k) return h("div", null, kepalaPres, h("div", { class: "panel" }, h("p", { class: "kosong" }, "Belum ada kelas. Tambahkan dulu di tab Kelas.")));
  return h("div", null, kepalaPres, s.presMode === "rekap" ? await panelRekap(k) : await panelInput(k));
}

async function panelInput(k) {
  const tgl = s.presTgl;
  const data = await api(`/api/presensi?kelas=${k.id}&tanggal=${tgl}`).catch(() => null);
  if (!data) return h("div", { class: "panel" }, h("p", { class: "kosong" }, "Presensi tidak bisa dimuat. Muat ulang halaman."));
  const status = { ...data.status };
  let cari = "";
  const akar = h("div", { class: "panel pres" });
  const simpan = async (perubahan) => {
    try { await api("/api/presensi", { metode: "POST", badan: { kelasId: k.id, tanggal: tgl, status: perubahan } }); s.hariIni = null; indikator("Tersimpan"); }
    catch { toast("Gagal menyimpan presensi. Coba lagi."); }
  };
  const indikator = (t) => { const e = akar.querySelector(".tersimpan"); if (!e) return; e.textContent = t; e.classList.remove("nyala"); void e.offsetWidth; e.classList.add("nyala"); };
  const atur = (id, st) => { const baru = status[id] === st ? null : st; if (baru) status[id] = baru; else delete status[id]; gambar(); simpan({ [id]: baru }); };
  const semua = (st) => { const perubahan = {}; k.siswa.forEach((x) => { perubahan[x.id] = st; if (st) status[x.id] = st; else delete status[x.id]; }); gambar(); simpan(perubahan); };
  function gambar() {
    const hitung = { hadir: 0, izin: 0, sakit: 0, alpa: 0, belum: 0 };
    k.siswa.forEach((x) => hitung[status[x.id] ?? "belum"]++);
    const total = k.siswa.length;
    const ubin = h("div", { class: "ubin-pres" }, ST.map(([v, , t]) => h("div", { class: `ubin ${v}` }, h("b", null, hitung[v]), h("small", null, t))), h("div", { class: "ubin belum" }, h("b", null, hitung.belum), h("small", null, "Belum diisi")));
    const batang = h("div", { class: "batang-pres", role: "img", "aria-label": `Hadir ${hitung.hadir}, izin ${hitung.izin}, sakit ${hitung.sakit}, alpa ${hitung.alpa}, belum ${hitung.belum}` }, [...ST.map(([v]) => v), "belum"].map((v) => h("i", { class: v, style: `flex:${hitung[v]}` })));
    const aksi = h("div", { class: "baris aksi-pres" },
      h("button", { class: "tbl utama", onclick: () => semua("hadir") }, "Semua hadir"),
      h("button", { class: "tbl", onclick: () => { if (Object.keys(status).length === 0 || confirm("Kosongkan presensi hari ini?")) semua(null); } }, "Kosongkan"),
      h("input", { type: "search", class: "cari", placeholder: "Cari nama…", value: cari, "aria-label": "Cari siswa", oninput: (e) => { cari = e.target.value; gambar(); const c = akar.querySelector(".cari"); c.focus(); c.setSelectionRange(cari.length, cari.length); } }),
      h("span", { class: "tersimpan", "aria-live": "polite" }));
    const daftar = h("div", { class: "siswa-pres" }, k.siswa.map((x, i) => ({ x, i })).filter(({ x }) => x.nama.toLowerCase().includes(cari.toLowerCase())).map(({ x, i }) =>
      h("div", { class: `kartu-siswa ${status[x.id] ?? ""}`, style: `--d:${Math.min(i, 14) * 30}ms` },
        h("span", { class: "avatar", style: `background:${WARNA_AVATAR[i % WARNA_AVATAR.length]}` }, inisial(x.nama)),
        h("div", { class: "id" }, h("b", null, x.nama), h("small", null, `No. ${i + 1}`)),
        h("div", { class: "pilih-st", role: "group", "aria-label": `Status ${x.nama}` }, ST.map(([v, huruf, t]) => h("button", { class: v, title: t, "aria-label": t, "aria-pressed": String(status[x.id] === v), onclick: () => atur(x.id, v) }, huruf))))));
    akar.replaceChildren(h("div", { class: "judul-pres" }, h("h3", null, namaHari(tgl)), h("small", null, `${hitung.hadir} dari ${total} siswa hadir`)), ubin, batang, aksi, daftar.children.length ? daftar : h("p", { class: "kosong" }, "Tidak ada nama yang cocok."));
  }
  gambar();
  return akar;
}

async function panelRekap(k) {
  const sampai = hariIni();
  s.rekap ??= { dari: `${sampai.slice(0, 8)}01`, sampai };
  const { dari, sampai: akhir } = s.rekap;
  const [rekap, hof] = await Promise.all([
    api(`/api/presensi/rekap?kelas=${k.id}&dari=${dari}&sampai=${akhir}`).catch(() => null),
    api(`/api/hof?kelas=${k.id}`).catch(() => ({ hof: [] })),
  ]);
  const poin = new Map((hof.hof ?? []).map((r) => [r.nama, r.total]));
  const atas = h("div", { class: "panel" },
    h("div", { class: "baris" },
      h("label", { class: "medan" }, "Dari", h("input", { type: "date", value: dari, onchange: (e) => { if (e.target.value) { s.rekap.dari = e.target.value; render(); } } })),
      h("label", { class: "medan" }, "Sampai", h("input", { type: "date", value: akhir, onchange: (e) => { if (e.target.value) { s.rekap.sampai = e.target.value; render(); } } })),
      h("button", { class: "tbl utama", disabled: !rekap || rekap.tanggal.length === 0, onclick: async () => {
        const r = await fetch(`/api/presensi/csv?kelas=${k.id}&dari=${dari}&sampai=${akhir}`, { headers: { "x-host-token": s.pin } });
        if (!r.ok) return toast("Gagal mengunduh CSV.");
        const u = URL.createObjectURL(await r.blob());
        const a = h("a", { href: u, download: `presensi-${k.nama}-${dari}_${akhir}.csv` }); document.body.append(a); a.click(); a.remove(); URL.revokeObjectURL(u);
      } }, "Unduh CSV")));
  if (!rekap) return h("div", null, atas, h("div", { class: "panel" }, h("p", { class: "kosong" }, "Rentang tanggal tidak valid.")));
  if (rekap.tanggal.length === 0) return h("div", null, atas, h("div", { class: "panel" }, h("p", { class: "kosong" }, "Belum ada presensi pada rentang ini.")));
  const rata = rekap.baris.filter((r) => r.persen != null);
  const rataPersen = rata.length ? Math.round(rata.reduce((n, r) => n + r.persen, 0) / rata.length) : 0;
  const perhatian = rekap.baris.filter((r) => r.persen != null && r.persen < 75).length;
  return h("div", null, atas,
    h("div", { class: "panel" },
      h("div", { class: "statistik" }, [["Hari tercatat", rekap.tanggal.length], ["Rata-rata hadir", `${rataPersen}%`], ["Perlu perhatian", perhatian]].map(([t, v]) => h("div", null, h("b", null, v), h("small", null, t)))),
      h("div", { class: "tabel-gulir" }, h("table", { class: "rekap" },
        h("thead", null, h("tr", null, h("th", null, "No"), h("th", null, "Nama"), ST.map(([, huruf, t]) => h("th", { class: "n", title: t }, huruf)), h("th", null, "Kehadiran"), h("th", { class: "n" }, "Poin game"))),
        h("tbody", null, rekap.baris.map((r) => h("tr", { class: r.persen != null && r.persen < 75 ? "rendah" : "" }, h("td", null, r.absen), h("td", null, h("b", null, r.nama)),
          ST.map(([v]) => h("td", { class: `n st-${v}` }, r[v])),
          h("td", null, r.persen == null ? "–" : h("div", { class: "kehadiran" }, h("span", { class: "batang" }, h("i", { style: `--w:${r.persen}%` })), h("b", null, `${r.persen}%`))),
          h("td", { class: "n" }, poin.has(r.nama) ? poin.get(r.nama) : "–")))))),
      h("p", { class: "ket", style: "margin-top:.6rem" }, "Persen hadir dihitung dari hari yang punya catatan siswa itu. Poin game diambil dari Hall of Fame kelas yang sama.")));
}
// --- aplikasi siswa (APK/iOS) ---
function tabAplikasi() {
  const akar = h("div");
  const gambar = async () => {
    const d = await api("/api/aplikasi").catch(() => null);
    const inf = await fetch("/api/aplikasi/info").then((r) => r.json()).catch(() => ({ apk: [] }));
    if (!d) return void akar.replaceChildren(h("div", { class: "panel" }, h("p", { class: "kosong" }, "Gagal memuat pengaturan aplikasi.")));
    const alamat = `${location.origin}`;
    akar.replaceChildren(
      h("div", { class: "panel" }, h("h2", null, "Aplikasi siswa"),
        h("p", { class: "ket" }, "Murid bermain lewat aplikasi Gerbang Siswa (Android .apk dan iOS) yang terisolasi: hanya membuka gerbang ini, tanpa bilah alamat, dan layar tidak bisa ditangkap. Pasangkan tiap perangkat dengan kode di bawah."),
        h("div", { class: "kode-apl" }, h("small", null, "KODE PASANGAN"), h("b", null, d.kode.replace(/(\d{3})(\d{3})/, "$1 $2")), h("button", { class: "tbl", onclick: async () => { await api("/api/aplikasi", { metode: "POST", badan: { kodeBaru: true } }); gambar(); } }, "Buat kode baru")),
        h("p", { class: "ket" }, `Di aplikasi, isi alamat `, h("b", null, location.hostname === "localhost" || location.hostname === "127.0.0.1" ? "http://<IP laptop ini>:8000" : alamat), " dan kode di atas.", location.hostname === "localhost" || location.hostname === "127.0.0.1" ? " Murid tidak bisa memakai localhost; lihat IP dengan perintah ipconfig (IPv4 Address)." : ""),
        h("div", { class: `hadir-sw ${d.wajib ? "aktif" : ""}` },
          h("button", { class: "sakelar", role: "switch", "aria-checked": String(d.wajib), "aria-label": "Wajib aplikasi untuk murid", onclick: async () => { await api("/api/aplikasi", { metode: "POST", badan: { wajib: !d.wajib } }); gambar(); } }, h("i")),
          h("div", null, h("b", null, "Wajib aplikasi untuk murid"), h("small", null, d.wajib ? "Aktif: halaman permainan murid hanya terbuka di aplikasi yang sudah dipasangkan." : "Mati: murid masih bisa bermain lewat web biasa."))),
        h("div", { class: "baris" },
          inf.apk?.length ? h("a", { class: "tbl utama", href: `/unduh/${inf.apk[0]}` }, `Unduh ${inf.apk[0]}`) : h("span", { class: "ket" }, "Berkas APK belum tersedia di server (lihat aplikasi/README.md)."),
          h("a", { class: "tbl", href: "/murid", target: "_blank" }, "Lihat halaman murid"))),
      h("div", { class: "panel" }, h("h2", null, "Perangkat terpasang"),
        d.perangkat.length ? h("div", { class: "tabel-gulir" }, h("table", null, h("thead", null, h("tr", null, ["Perangkat", "Sistem", "Versi", "Terakhir aktif", "Tangkap layar", "Rekam layar", ""].map((t) => h("th", null, t)))),
          h("tbody", null, d.perangkat.map((p) => h("tr", null, h("td", null, h("i", { class: `titik ${p.aktif ? "hidup" : ""}`, style: "display:inline-block;margin-right:.4rem" }), h("b", null, p.nama)), h("td", null, p.platform), h("td", null, p.versi || "–"), h("td", null, new Date(p.terakhir).toLocaleString("id-ID", { hour: "2-digit", minute: "2-digit", day: "numeric", month: "short" })), h("td", { class: p.tangkap ? "peringatan-n" : "" }, p.tangkap), h("td", { class: p.rekam ? "peringatan-n" : "" }, p.rekam),
            h("td", null, h("button", { class: "tbl", onclick: async () => { if (confirm(`Putuskan ${p.nama}?`)) { await api("/api/aplikasi", { metode: "POST", badan: { cabut: p.id } }); gambar(); } } }, "Putuskan"))))))) : h("p", { class: "kosong" }, "Belum ada perangkat yang dipasangkan."),
        d.perangkat.length > 0 && h("div", { class: "baris" }, h("button", { class: "tbl", onclick: async () => { if (confirm("Putuskan semua perangkat? Semua harus dipasangkan ulang.")) { await api("/api/aplikasi", { metode: "POST", badan: { cabut: "semua" } }); gambar(); } } }, "Putuskan semua")),
        h("p", { class: "ket" }, "Tangkap layar terdeteksi di iOS; di Android tangkap layar sudah diblokir sistem. Angka merah berarti ada percobaan.")));
  };
  gambar();
  clearInterval(s.aplTimer);
  s.aplTimer = setInterval(() => { if (!document.body.contains(akar)) return clearInterval(s.aplTimer); gambar(); }, 8000);
  return akar;
}
async function render() {
  clearInterval(s.umpanTimer); clearInterval(s.perangkatTimer); clearInterval(s.aplTimer);
  document.body.querySelector(".bintang") || document.body.prepend(h("div", { class: "bintang" }));
  if (!s.buka) { app.replaceChildren(layarGerbang()); const p = document.getElementById("pin"); if (p && !s.salah) p.focus(); s.salah = false; return; }
  if ((s.tab === "dunia" || s.tab === "multi") && !s.hariIni) await muatHariIni();
  let isi;
  if (s.tab === "dunia") isi = tabDunia(); else if (s.tab === "multi") isi = tabMulti(); else if (s.tab === "presensi") isi = await tabPresensi(); else if (s.tab === "hof") isi = await tabHof(); else if (s.tab === "aplikasi") isi = tabAplikasi(); else if (s.tab === "perawatan") isi = await tabPerawatan(); else if (s.tab === "pin") { s.infoPin = await api("/api/pin/info").catch(() => s.infoPin); isi = tabPin(); } else isi = tabKelas();
  const tabs = [["dunia", "Dunia"], ["multi", "Multi Permainan"], ["presensi", "Presensi"], ["hof", "Hall of Fame"], ["kelas", "Kelas"], ["aplikasi", "Aplikasi"], ["perawatan", "Perawatan"], ["pin", "PIN"]];
  app.replaceChildren(h("main", { class: "wadah" }, kepala(), pita(),
    h("section", { class: "panggung", style: "min-height:0;padding-block:.2rem 1rem" }, h("h1", { class: "judul", style: "font-size:clamp(1.6rem,3.4vw,2.3rem)" }, h("small", null, "Gerbang terbuka"), "Pilih dunia, atau satukan jadi ", h("em", null, "Multi Permainan"), "."), h("div", null)),
    h("nav", { class: "tab", role: "tablist" }, tabs.map(([k, t]) => h("button", { role: "tab", "aria-selected": String(s.tab === k), onclick: () => { s.tab = k; if (k !== "multi") s.aktif = null; s.hof = null; render(); } }, t))), isi));
}

// --- mulai ---
const q = new URLSearchParams(location.search);
if (q.get("selesai") === "1" && cariGame(q.get("game") ?? "")) s.tunda = { game: q.get("game"), multi: q.get("multi"), gameSesi: q.get("gameSesi") ?? "" };
const muat = document.getElementById("muat");
const langkah = [[18, "Menyalakan lentera…"], [46, "Memeriksa dunia yang menyala…"], [78, "Merapikan peta…"], [100, "Gerbang siap."]];
const setMuat = (i) => { document.getElementById("muat-bar").style.width = `${langkah[i][0]}%`; document.getElementById("muat-teks").textContent = langkah[i][1]; };
setMuat(0);
const minimal = new Promise((r) => setTimeout(r, 1500));
await muatStatus(); setMuat(1);
await Promise.all([document.fonts?.ready, minimal]); setMuat(2);
setInterval(async () => { await muatStatus(); if (s.buka && s.tab === "dunia") render(); else document.querySelector(".cip .titik")?.classList.toggle("hidup", Object.values(s.hidup).some(Boolean)); }, 8000);
setInterval(async () => { if (s.buka && s.tab === "multi" && s.aktif) { const j = await api(`/api/multi/${s.aktif.id}`).catch(() => null); if (j && JSON.stringify(j.sesi.hasil) !== JSON.stringify(s.aktif.hasil)) { s.aktif = j.sesi; render(); } } }, 4000);
if (s.pin && (await masuk(s.pin))) await bukaGerbang(); else { s.pin = ""; render(); }
setMuat(3); setTimeout(() => muat.classList.add("selesai"), 350); setTimeout(() => muat.remove(), 1200);

// Hub "Gerbang Permainan": satu origin untuk antarmuka hub, API (PIN, kelas, Multi Permainan, Hall of Fame), dan semua game.
import http from "node:http";
import { readFile } from "node:fs/promises";
import { readFileSync, writeFileSync } from "node:fs";
import { halamanPerawatan } from "./lib/perawatan.mjs";
import { createHmac, randomBytes, timingSafeEqual } from "node:crypto";
import { bacaCookie, halamanKhususGuru, jalurGuru, halamanWajibAplikasi } from "./lib/akses.mjs";
import { existsSync, createReadStream, statSync, readdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
import { join, extname, normalize, sep } from "node:path";
import { GAMES, MAX_GAME, MIN_GAME, cariGame, pinSah } from "./lib/katalog.mjs";
import { akumulasi, hofKelas } from "./lib/skor.mjs";
import { bacaRingkasan } from "./lib/ringkasan.mjs";
import { bukaBerkas, idBaru, siswaDariNama } from "./lib/store.mjs";
import { KUIS, MAKS_TANGGAPAN, ringkasUmpan, uraiPerangkat, validasiTanggapan } from "./lib/umpan.mjs";
import { csvRekap, hadirPada, rekapPresensi, ringkasHari, tanggalSah, terapkanStatus } from "./lib/presensi.mjs";
import { halamanGalat, tcpHidup, targetGame, teruskanHttp, teruskanUpgrade } from "./lib/proxy.mjs";

const AKAR = fileURLToPath(new URL(".", import.meta.url));
const MIME = { ".html": "text/html; charset=utf-8", ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".css": "text/css; charset=utf-8", ".svg": "image/svg+xml", ".woff2": "font/woff2", ".json": "application/json" };
const SAMA = (a, b) => { const x = Buffer.from(String(a)), y = Buffer.from(String(b)); return x.length === y.length && timingSafeEqual(x, y); };

/**
 * @param {{pin:string, dataDir:string, daftar?:ReturnType<typeof targetGame>, ambil?:typeof fetch, fontDir?:string|null, proto?:string, maksGagal?:number, jendelaMs?:number}} o
 */
export function buatHub(o) {
  if (!pinSah(o.pin)) throw new Error("PIN guru harus 4–32 karakter ASCII tanpa spasi");
  let pin = o.pin;
  // Mode perawatan per game: dikelola guru, dipaksakan di gerbang (HTTP dan WebSocket), bertahan setelah restart.
  const berkasPerawatan = join(o.dataDir, "perawatan.json");
  let perawatan = {};
  try { perawatan = JSON.parse(readFileSync(berkasPerawatan, "utf8")); } catch { /* belum ada */ }
  const simpanPerawatan = () => { try { writeFileSync(berkasPerawatan, JSON.stringify(perawatan)); } catch { /* disk penuh: tetap berlaku di memori */ } };
  const gameDariPath = (p) => daftar.find((g) => p === g.prefix || p.startsWith(g.prefix + "/"));
  const dalamPerawatan = (g) => !!g && perawatan[g.key]?.aktif === true;
  const daftar = o.daftar ?? targetGame();
  const ambil = o.ambil ?? fetch;
  const proto = o.proto ?? "http";
  const kelas = bukaBerkas(join(o.dataDir, "kelas.json"), { kelas: [] });
  const multi = bukaBerkas(join(o.dataDir, "multi.json"), { sesi: [] });
  const presensi = bukaBerkas(join(o.dataDir, "presensi.json"), { kelas: {} }); // { kelas: { [kelasId]: { [YYYY-MM-DD]: { [siswaId]: status } } } }
  // Umpan balik anonim per Multi Permainan dan deteksi perangkat. Perangkat disimpan di memori dan dibilas berkala.
  const umpan = bukaBerkas(join(o.dataDir, "umpan.json"), { sesi: {} }); // { sesi: { [id]: { aktif, tampil, tanggapan:[{dev,favorit,rating,kuis,waktu}] } } }
  const berkasPerangkat = bukaBerkas(join(o.dataDir, "perangkat.json"), { dev: {} });
  const perangkat = berkasPerangkat.data.dev;
  let kotor = false;
  const bilas = setInterval(() => { if (kotor) { kotor = false; try { berkasPerangkat.simpan(); } catch { /* disk penuh */ } } }, 20_000);
  bilas.unref?.();
  const nyata = (ms) => Date.now() - ms;
  const umpanSesi = (id) => (umpan.data.sesi[id] ??= { aktif: false, tampil: false, tanggapan: [] });
  const sesiAktif = () => multi.data.sesi.find((x) => umpan.data.sesi[x.id]?.aktif);
  // Aplikasi siswa (APK/iOS): kode pasangan, perangkat terpasang, dan mode "wajib aplikasi" yang menutup akses web untuk murid.
  const apl = bukaBerkas(join(o.dataDir, "aplikasi.json"), { wajib: false, kode: "", rahasia: "", perangkat: {} });
  if (!apl.data.rahasia) apl.data.rahasia = randomBytes(32).toString("hex");
  const kodeBaru = () => String(100000 + (randomBytes(4).readUInt32BE(0) % 900000));
  if (!apl.data.kode) apl.data.kode = kodeBaru();
  apl.simpan();
  const tokenApl = (id) => createHmac("sha256", apl.data.rahasia).update(`apl:${id}`).digest("hex");
  /** Cookie gp_app = "<id>.<hmac>". Mengembalikan id perangkat bila sah dan belum dicabut. */
  const aplId = (req) => {
    const c = bacaCookie(req.headers.cookie, "gp_app");
    const i = c.indexOf(".");
    if (i < 1) return "";
    const id = c.slice(0, i);
    return /^[\w-]{8,40}$/.test(id) && apl.data.perangkat[id] && SAMA(c.slice(i + 1), tokenApl(id)) ? id : "";
  };
  const gagalPasang = new Map();
  const apkDir = o.apkDir ?? join(AKAR, "..", "aplikasi", "dist");
  const gagal = new Map(); // ip -> {n, sejak}
  const maksGagal = o.maksGagal ?? 5;
  const jendela = o.jendelaMs ?? 60_000;

  const kirim = (res, kode, obj) => { res.writeHead(kode, { "content-type": "application/json", "cache-control": "no-store" }); res.end(JSON.stringify(obj)); };
  const baca = (req) => new Promise((ok, tolak) => {
    let s = ""; req.on("data", (c) => { s += c; if (s.length > 2_000_000) { tolak(new Error("terlalu besar")); req.destroy(); } });
    req.on("end", () => { try { ok(s ? JSON.parse(s) : {}); } catch { tolak(new Error("JSON tidak sah")); } });
  });
  // Cookie sesi guru: HMAC(rahasia acak per proses, PIN sekarang). Berubah bila PIN diganti, sehingga cookie lama otomatis tidak sah.
  const rahasiaCookie = randomBytes(24);
  const tokenGuru = () => createHmac("sha256", rahasiaCookie).update(`guru:${pin}`).digest("hex");
  const cookieGuru = (req) => SAMA(bacaCookie(req.headers.cookie, "gerbang_guru"), tokenGuru());
  const atur = (nilai, umur) => `gerbang_guru=${nilai}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${umur}${proto === "https" ? "; Secure" : ""}`;
  const guru = (req) => SAMA(req.headers["x-host-token"] ?? "", pin);
  const guruAtauCookie = (req) => guru(req) || cookieGuru(req);

  function terblokir(ip) {
    const g = gagal.get(ip);
    if (!g) return false;
    if (Date.now() - g.sejak > jendela) { gagal.delete(ip); return false; }
    return g.n >= maksGagal;
  }
  function catatGagal(ip) {
    const g = gagal.get(ip);
    if (!g || Date.now() - g.sejak > jendela) gagal.set(ip, { n: 1, sejak: Date.now() });
    else g.n++;
  }

  const hitung = (m) => {
    const games = m.games.map((key) => ({ key }));
    const skor = m.games.flatMap((key) => (m.hasil[key]?.skor ?? []).map((s) => ({ ...s, gameKey: key })));
    return akumulasi(games, skor, m.aturan);
  };
  const ringkasSesi = (m) => ({ id: m.id, judul: m.judul, kelasId: m.kelasId, kelasNama: m.kelasNama, games: m.games, aturan: m.aturan, dibuat: m.dibuat, selesai: m.games.filter((k) => m.hasil[k]).length });

  async function api(req, res, path, ip) {
    const m = req.method;
    if (path === "/api/status" && m === "GET") {
      const games = await Promise.all(daftar.map(async (g) => ({ key: g.key, hidup: await tcpHidup(g.target), perawatan: dalamPerawatan(g), pesan: dalamPerawatan(g) ? perawatan[g.key].pesan ?? "" : "" })));
      return kirim(res, 200, { gerbang: true, games });
    }
    if (path === "/api/pin" && m === "POST") {
      if (terblokir(ip)) return kirim(res, 429, { error: "terlalu_banyak_percobaan" });
      const b = await baca(req);
      if (typeof b.pin === "string" && SAMA(b.pin, pin)) { gagal.delete(ip); res.setHeader("set-cookie", atur(tokenGuru(), 28800)); return kirim(res, 200, { ok: true }); }
      catatGagal(ip);
      return kirim(res, 401, { error: "pin_salah" });
    }
    if (path === "/api/aplikasi/info" && m === "GET") {
      const berkas = existsSync(apkDir) ? readdirSync(apkDir).filter((f) => /^[\w.-]+\.apk$/i.test(f)) : [];
      return kirim(res, 200, { wajib: apl.data.wajib, apk: berkas });
    }
    if (path === "/api/aplikasi/pasang" && m === "POST") {
      const g = gagalPasang.get(ip);
      if (g && Date.now() - g.sejak < jendela && g.n >= 10) return kirim(res, 429, { error: "terlalu_banyak_percobaan" });
      const b = await baca(req);
      if (typeof b.kode !== "string" || !SAMA(b.kode.replace(/\D/g, ""), apl.data.kode)) {
        const x = g && Date.now() - g.sejak < jendela ? g : { n: 0, sejak: Date.now() };
        x.n++; gagalPasang.set(ip, x);
        return kirim(res, 401, { error: "kode_salah" });
      }
      gagalPasang.delete(ip);
      const id = `a${idBaru()}`;
      const platform = ["android", "ios"].includes(b.platform) ? b.platform : "lain";
      apl.data.perangkat[id] = { nama: String(b.nama ?? "Perangkat").slice(0, 40), platform, versi: String(b.versi ?? "").slice(0, 16), terdaftar: Date.now(), terakhir: Date.now(), tangkap: 0, rekam: 0 };
      apl.simpan();
      const cookie = `gp_app=${id}.${tokenApl(id)}`;
      res.setHeader("set-cookie", `${cookie}; Path=/; HttpOnly; SameSite=Lax; Max-Age=31536000${proto === "https" ? "; Secure" : ""}`);
      return kirim(res, 200, { ok: true, id, cookie, murid: "/murid" });
    }
    if (path === "/api/aplikasi/peristiwa" && m === "POST") {
      const id = aplId(req);
      if (!id) return kirim(res, 401, { error: "bukan_aplikasi" });
      const b = await baca(req);
      const d = apl.data.perangkat[id];
      if (b.jenis === "tangkap-layar") d.tangkap++;
      else if (b.jenis === "rekam-layar") d.rekam++;
      else if (b.jenis !== "denyut") return kirim(res, 400, { error: "jenis_tidak_sah" });
      d.terakhir = Date.now();
      apl.simpan();
      return kirim(res, 200, { ok: true });
    }    if (path === "/api/guru/cek" && m === "GET") return kirim(res, 200, { guru: guruAtauCookie(req) });
    if (path === "/api/keluar" && m === "POST") { res.setHeader("set-cookie", atur("", 0)); return kirim(res, 200, { ok: true }); }
    // --- endpoint siswa/proyektor (tanpa PIN): denyut perangkat, polling umpan balik, kirim tanggapan. Isinya anonim. ---
    if (path === "/api/siswa/denyut" && m === "POST") {
      const b = await baca(req);
      const dev = String(b.dev ?? "");
      if (!/^[\w-]{8,40}$/.test(dev)) return kirim(res, 400, { error: "data_tidak_valid" });
      const peran = b.peran === "proyektor" ? "proyektor" : "siswa";
      const game = daftar.some((g) => g.key === b.game) ? b.game : null;
      const info = b.info && typeof b.info === "object" ? b.info : {};
      const lebar = Number.isFinite(info.lebar) ? Math.min(Math.max(info.lebar | 0, 0), 10000) : 0;
      const tinggi = Number.isFinite(info.tinggi) ? Math.min(Math.max(info.tinggi | 0, 0), 10000) : 0;
      const sentuh = Number.isFinite(info.sentuh) ? Math.min(Math.max(info.sentuh | 0, 0), 20) : 0;
      if (peran === "siswa" || Object.keys(perangkat).length < 500 || perangkat[dev]) {
        const ua = String(req.headers["user-agent"] ?? "").slice(0, 300);
        const lama = perangkat[dev];
        perangkat[dev] = { ...uraiPerangkat(ua, { sentuh, lebar }), app: !!aplId(req), peran, game, lebar, tinggi, sentuh, dpr: Number(info.dpr) || 1, bahasa: String(info.bahasa ?? "").slice(0, 12), pertama: lama?.pertama ?? Date.now(), terakhir: Date.now() };
        kotor = true;
      }
      const ses = sesiAktif();
      const u = ses ? umpanSesi(ses.id) : null;
      const out = { umpan: null, layar: null };
      if (ses && u?.aktif && peran === "siswa" && game && ses.games.includes(game) && !u.tanggapan.some((t) => t.dev === dev)) {
        out.umpan = { sesiId: ses.id, judul: ses.judul, games: ses.games.map((k) => ({ key: k, label: cariGame(k)?.label ?? k, tema: cariGame(k)?.tema ?? "" })), kuis: KUIS };
      }
      if (ses && u?.aktif && u.tampil && peran === "proyektor") {
        const terhubung = Object.values(perangkat).filter((d) => d.peran === "siswa" && d.game && ses.games.includes(d.game) && d.terakhir > nyata(60_000)).length;
        out.layar = { judul: ses.judul, kelas: ses.kelasNama, games: ses.games.map((k) => ({ key: k, label: cariGame(k)?.label ?? k, tema: cariGame(k)?.tema ?? "" })), terhubung, ringkas: ringkasUmpan(ses.games, u.tanggapan) };
      }
      return kirim(res, 200, out);
    }
    if (path === "/api/umpan/kirim" && m === "POST") {
      const b = await baca(req);
      const dev = String(b.dev ?? "");
      const ses = multi.data.sesi.find((x) => x.id === b.sesiId);
      const u = ses && umpan.data.sesi[ses.id];
      if (!/^[\w-]{8,40}$/.test(dev) || !ses || !u?.aktif) return kirim(res, 409, { error: "umpan_tidak_aktif" });
      if (u.tanggapan.some((t) => t.dev === dev)) return kirim(res, 200, { ok: true, sudah: true });
      if (u.tanggapan.length >= MAKS_TANGGAPAN) return kirim(res, 429, { error: "penuh" });
      const bersih = validasiTanggapan(b, ses.games);
      if (!bersih) return kirim(res, 400, { error: "tanggapan_tidak_valid" });
      u.tanggapan.push({ dev, ...bersih, waktu: Date.now() });
      umpan.simpan();
      return kirim(res, 200, { ok: true });
    }    if (!guru(req)) { catatGagal(ip); return kirim(res, 401, { error: "pin_salah" }); }
    if (path === "/api/pin/info" && m === "GET") return kirim(res, 200, { bawaan: pin === (o.pinBawaan ?? "1234"), terkunci: !!o.pinTerkunci });
    if (path === "/api/pin/ubah" && m === "POST") {
      if (o.pinTerkunci) return kirim(res, 409, { error: "pin_dari_env" });
      const b = await baca(req);
      if (!pinSah(b.pinBaru)) return kirim(res, 400, { error: "pin_tidak_sah" });
      pin = b.pinBaru;
      res.setHeader("set-cookie", atur(tokenGuru(), 28800));
      await o.simpanPin?.(pin);
      return kirim(res, 200, { ok: true });
    }
    if (path === "/api/perawatan" && m === "GET") return kirim(res, 200, { games: Object.fromEntries(daftar.map((g) => [g.key, { aktif: dalamPerawatan(g), pesan: perawatan[g.key]?.pesan ?? "", sejak: perawatan[g.key]?.sejak ?? null }])) });
    if (path === "/api/perawatan" && m === "POST") {
      const b = await baca(req);
      const g = daftar.find((x) => x.key === b.key);
      if (!g || typeof b.aktif !== "boolean") return kirim(res, 400, { error: "data_tidak_valid" });
      const pesan = String(b.pesan ?? "").trim().slice(0, 200);
      perawatan[g.key] = { aktif: b.aktif, pesan, sejak: b.aktif ? (perawatan[g.key]?.aktif ? perawatan[g.key].sejak : Date.now()) : null };
      simpanPerawatan();
      return kirim(res, 200, { ok: true, key: g.key, aktif: b.aktif });
    }
    {
      const t2 = path.match(/^\/api\/umpan\/([\w-]+)$/);
      if (t2 && m === "GET") {
        const ses = multi.data.sesi.find((x) => x.id === t2[1]);
        if (!ses) return kirim(res, 404, { error: "tidak_ada" });
        const u = umpanSesi(ses.id);
        const terhubung = Object.values(perangkat).filter((d) => d.peran === "siswa" && d.game && ses.games.includes(d.game) && d.terakhir > nyata(60_000)).length;
        return kirim(res, 200, { aktif: u.aktif, tampil: u.tampil, terhubung, ringkas: ringkasUmpan(ses.games, u.tanggapan), kuis: KUIS });
      }
      if (t2 && m === "POST") {
        const ses = multi.data.sesi.find((x) => x.id === t2[1]);
        if (!ses) return kirim(res, 404, { error: "tidak_ada" });
        const b = await baca(req);
        const u = umpanSesi(ses.id);
        if (typeof b.aktif === "boolean") {
          if (b.aktif) for (const [id, x] of Object.entries(umpan.data.sesi)) if (id !== ses.id) { x.aktif = false; x.tampil = false; }
          u.aktif = b.aktif;
          if (!b.aktif) u.tampil = false;
        }
        if (typeof b.tampil === "boolean") u.tampil = u.aktif && b.tampil;
        umpan.simpan();
        return kirim(res, 200, { aktif: u.aktif, tampil: u.tampil, jumlah: u.tanggapan.length });
      }
      if (path === "/api/aplikasi" && m === "GET") {
        return kirim(res, 200, { wajib: apl.data.wajib, kode: apl.data.kode, perangkat: Object.entries(apl.data.perangkat).map(([id, d]) => ({ id, ...d, aktif: d.terakhir > nyata(120_000) })).sort((a, b) => b.terakhir - a.terakhir) });
      }
      if (path === "/api/aplikasi" && m === "POST") {
        const b = await baca(req);
        if (typeof b.wajib === "boolean") apl.data.wajib = b.wajib;
        if (b.kodeBaru === true) apl.data.kode = kodeBaru();
        if (b.cabut === "semua") { apl.data.perangkat = {}; apl.data.rahasia = randomBytes(32).toString("hex"); }
        else if (typeof b.cabut === "string") delete apl.data.perangkat[b.cabut];
        apl.simpan();
        return kirim(res, 200, { wajib: apl.data.wajib, kode: apl.data.kode, jumlah: Object.keys(apl.data.perangkat).length });
      }      if (path === "/api/perangkat" && m === "GET") {
        const jendelaJam = nyata(12 * 3600_000);
        const daftarP = Object.entries(perangkat).filter(([, d]) => d.terakhir > jendelaJam && d.peran === "siswa").sort((a, b) => b[1].terakhir - a[1].terakhir)
          .map(([, d], i) => ({ label: `Perangkat ${i + 1}`, app: !!d.app, jenis: d.jenis, os: d.os, peramban: d.peramban, lebar: d.lebar, tinggi: d.tinggi, sentuh: d.sentuh > 0, bahasa: d.bahasa, game: d.game, pertama: d.pertama, terakhir: d.terakhir, aktif: d.terakhir > nyata(30_000) }));
        const hitung = (k) => daftarP.reduce((a, d) => ((a[d[k]] = (a[d[k]] ?? 0) + 1), a), {});
        return kirim(res, 200, { total: daftarP.length, aktif: daftarP.filter((d) => d.aktif).length, jenis: hitung("jenis"), os: hitung("os"), peramban: hitung("peramban"), perangkat: daftarP });
      }
    }    if (path.startsWith("/api/presensi")) {
      const q = new URL(req.url, "http://x").searchParams;
      const k = kelas.data.kelas.find((x) => x.id === (q.get("kelas") ?? ""));
      const hari = presensi.data.kelas[k?.id] ?? {};
      if (path === "/api/presensi" && m === "GET") {
        const tanggal = q.get("tanggal") ?? "";
        if (!k || !tanggalSah(tanggal)) return kirim(res, 400, { error: "data_tidak_valid" });
        const catatan = hari[tanggal] ?? {};
        return kirim(res, 200, { tanggal, ada: Object.keys(catatan).length > 0, status: catatan, ringkas: ringkasHari(k.siswa, catatan) });
      }
      if (path === "/api/presensi" && m === "POST") {
        const b = await baca(req);
        const kk = kelas.data.kelas.find((x) => x.id === b.kelasId);
        if (!kk || !tanggalSah(b.tanggal)) return kirim(res, 400, { error: "data_tidak_valid" });
        const baru = terapkanStatus(presensi.data.kelas[kk.id]?.[b.tanggal], kk.siswa, b.status);
        if (!baru) return kirim(res, 400, { error: "status_tidak_valid" });
        (presensi.data.kelas[kk.id] ??= {})[b.tanggal] = baru;
        if (Object.keys(baru).length === 0) delete presensi.data.kelas[kk.id][b.tanggal];
        presensi.simpan();
        return kirim(res, 200, { tanggal: b.tanggal, ada: Object.keys(baru).length > 0, status: baru, ringkas: ringkasHari(kk.siswa, baru) });
      }
      if ((path === "/api/presensi/rekap" || path === "/api/presensi/csv") && m === "GET") {
        const dari = q.get("dari") ?? "", sampai = q.get("sampai") ?? "";
        if (!k || !tanggalSah(dari) || !tanggalSah(sampai) || dari > sampai) return kirim(res, 400, { error: "data_tidak_valid" });
        const rekap = rekapPresensi(k.siswa, hari, dari, sampai);
        if (path.endsWith("/csv")) {
          res.writeHead(200, { "content-type": "text/csv; charset=utf-8", "content-disposition": `attachment; filename="presensi-${dari}_${sampai}.csv"`, "cache-control": "no-store" });
          return void res.end(csvRekap(rekap));
        }
        return kirim(res, 200, { dari, sampai, ...rekap });
      }
      if (path === "/api/presensi/hadir" && m === "GET") {
        const tanggal = q.get("tanggal") ?? "";
        if (!k || !tanggalSah(tanggal)) return kirim(res, 400, { error: "data_tidak_valid" });
        const siswa = hadirPada(k.siswa, hari, tanggal);
        return kirim(res, 200, { tanggal, tercatat: siswa !== null, siswa: siswa ?? [] });
      }
      return kirim(res, 404, { error: "tidak_ada" });
    }    if (path === "/api/kelas" && m === "GET") return kirim(res, 200, { kelas: kelas.data.kelas });
    if (path === "/api/kelas" && m === "POST") {
      const b = await baca(req);
      const nama = String(b.nama ?? "").trim().slice(0, 40);
      if (!nama) return kirim(res, 400, { error: "nama_kosong" });
      const ada = kelas.data.kelas.find((k) => k.id === b.id);
      const siswa = siswaDariNama(b.daftar ?? "", ada?.siswa);
      if (siswa.length === 0) return kirim(res, 400, { error: "siswa_kosong" });
      if (ada) { ada.nama = nama; ada.siswa = siswa; } else kelas.data.kelas.push({ id: `k-${idBaru()}`, nama, siswa });
      kelas.simpan();
      return kirim(res, 200, { kelas: kelas.data.kelas });
    }
    let t = path.match(/^\/api\/kelas\/([\w-]+)$/);
    if (t && m === "DELETE") { kelas.data.kelas = kelas.data.kelas.filter((k) => k.id !== t[1]); kelas.simpan(); delete presensi.data.kelas[t[1]]; presensi.simpan(); return kirim(res, 200, { kelas: kelas.data.kelas }); }
    if (path === "/api/multi" && m === "GET") return kirim(res, 200, { sesi: multi.data.sesi.map(ringkasSesi) });
    if (path === "/api/multi" && m === "POST") {
      const b = await baca(req);
      const k = kelas.data.kelas.find((x) => x.id === b.kelasId);
      const games = Array.isArray(b.games) ? [...new Set(b.games)].filter((x) => cariGame(x)) : [];
      if (!k) return kirim(res, 400, { error: "kelas_tidak_ada" });
      if (games.length < MIN_GAME || games.length > MAX_GAME) return kirim(res, 400, { error: "jumlah_game" });
      let pesertaMulti = k.siswa;
      if (b.hanyaHadir === true) {
        if (!tanggalSah(b.tanggal)) return kirim(res, 400, { error: "data_tidak_valid" });
        const hadir = hadirPada(k.siswa, presensi.data.kelas[k.id], b.tanggal);
        if (hadir === null) return kirim(res, 409, { error: "presensi_belum_diisi" });
        if (hadir.length === 0) return kirim(res, 409, { error: "tidak_ada_yang_hadir" });
        pesertaMulti = hadir;
      }
      const aturan = b.aturan === "skor" ? "skor" : "peringkat";
      const sesi = { id: idBaru(), judul: String(b.judul || `Multi Permainan ${k.nama}`).slice(0, 80), kelasId: k.id, kelasNama: k.nama, siswa: pesertaMulti, games, aturan, dibuat: new Date().toISOString(), hasil: {} };
      multi.data.sesi.unshift(sesi);
      multi.simpan();
      return kirim(res, 201, { sesi: { ...sesi, hof: [] } });
    }
    t = path.match(/^\/api\/multi\/([\w-]+)(\/hasil)?$/);
    if (t) {
      const sesi = multi.data.sesi.find((s) => s.id === t[1]);
      if (!sesi) return kirim(res, 404, { error: "sesi_tidak_ada" });
      if (!t[2] && m === "GET") return kirim(res, 200, { sesi: { ...sesi, hof: hitung(sesi) } });
      if (!t[2] && m === "DELETE") { multi.data.sesi = multi.data.sesi.filter((s) => s !== sesi); multi.simpan(); return kirim(res, 200, { ok: true }); }
      if (t[2] && m === "POST") {
        const b = await baca(req);
        const game = daftar.find((g) => g.key === b.gameKey);
        if (!game || !sesi.games.includes(game.key)) return kirim(res, 400, { error: "game_tidak_dalam_sesi" });
        let mentah = b.json;
        if (mentah === undefined) {
          const id = String(b.gameSesi ?? "");
          if (!/^[A-Za-z0-9_-]{1,64}$/.test(id)) return kirim(res, 400, { error: "id_sesi_game" });
          try {
            const r = await ambil(`${game.target}${game.prefix}/api/sessions/${id}/summary.json${game.ringkasanQuery ?? ""}`, { headers: { "x-host-token": pin } });
            if (!r.ok) return kirim(res, 502, { error: "game_menolak", status: r.status });
            mentah = await r.json();
          } catch { return kirim(res, 502, { error: "game_tidak_terjangkau" }); }
        }
        let baca1;
        try { baca1 = bacaRingkasan(game.key, mentah, sesi.siswa); } catch (e) { return kirim(res, 422, { error: String(e.message) }); }
        sesi.hasil[game.key] = { gameSesi: String(b.gameSesi ?? "manual"), skor: baca1.skor, tidakCocok: baca1.tidakCocok, diambil: new Date().toISOString() };
        multi.simpan();
        return kirim(res, 200, { sesi: { ...sesi, hof: hitung(sesi) }, tidakCocok: baca1.tidakCocok });
      }
    }
    if (path === "/api/hof" && m === "GET") {
      const id = new URL(req.url, "http://x").searchParams.get("kelas");
      const sesi = multi.data.sesi.filter((s) => s.kelasId === id);
      return kirim(res, 200, { sesi: sesi.length, hof: hofKelas(sesi.map(hitung)) });
    }
    return kirim(res, 404, { error: "tidak_ada" });
  }

  async function statis(res, path) {
    let berkas = null;
    if (path.startsWith("/lib/")) berkas = join(AKAR, "lib", path.slice(5));
    else if (path.startsWith("/fonts/") && o.fontDir) berkas = join(o.fontDir, path.slice(7));
    else berkas = join(AKAR, "public", path === "/" ? "index.html" : path === "/murid" ? "murid.html" : path);
    const dasar = normalize(berkas);
    const boleh = [join(AKAR, "public"), join(AKAR, "lib"), o.fontDir && normalize(o.fontDir)].filter(Boolean);
    if (!boleh.some((b) => dasar.startsWith(b + sep)) || (path.startsWith("/lib/") && !/^\/lib\/(katalog|skor|handoff|impor|turnamen)\.mjs$/.test(path))) { res.writeHead(404); return res.end(); }
    try {
      const isi = await readFile(dasar);
      res.writeHead(200, { "content-type": MIME[extname(dasar)] ?? "application/octet-stream", "cache-control": path.startsWith("/fonts/") ? "public, max-age=31536000, immutable" : "no-cache" });
      res.end(isi);
    } catch { res.writeHead(404, { "content-type": "text/html; charset=utf-8" }); res.end(halamanGalat("Halaman tidak ditemukan", "<p>Alamat itu tidak ada di Gerbang.</p>")); }
  }

  const server = http.createServer(async (req, res) => {
    const path = (req.url ?? "/").split(/[?#]/)[0];
    const ip = req.socket.remoteAddress ?? "";
    res.setHeader("x-content-type-options", "nosniff");
    try {
      if (path === "/games/_gerbang" || path === "/games/_gerbang/") {
        const status = {};
        await Promise.all(daftar.map(async (g) => (status[g.key] = { prefix: g.prefix, hidup: await tcpHidup(g.target) })));
        return kirim(res, 200, { gerbang: true, games: status });
      }
      const gm = gameDariPath(path);
      if (dalamPerawatan(gm) && !guruAtauCookie(req)) {
        res.writeHead(503, { "content-type": "text/html; charset=utf-8", "retry-after": "300", "cache-control": "no-store" });
        return void res.end(halamanPerawatan(gm, perawatan[gm.key]));
      }
      if (gm && jalurGuru(path, gm.prefix) && req.method === "GET" && /text\/html/.test(String(req.headers.accept ?? "")) && !guruAtauCookie(req)) {
        res.writeHead(401, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
        return void res.end(halamanKhususGuru(gm.label));
      }
      if (apl.data.wajib && gm && !jalurGuru(path, gm.prefix) && req.method === "GET" && /text\/html/.test(String(req.headers.accept ?? "")) && !aplId(req) && !guruAtauCookie(req)) {
        res.writeHead(403, { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" });
        return void res.end(halamanWajibAplikasi(gm.label));
      }
      if (teruskanHttp(req, res, daftar, proto)) return;
      if (/^\/unduh\/[\w.-]+\.apk$/i.test(path)) {
        const f = join(apkDir, path.slice(7));
        if (!existsSync(f) || normalize(f) !== f.replace(/\//g, sep)) { res.writeHead(404); return void res.end(); }
        res.writeHead(200, { "content-type": "application/vnd.android.package-archive", "content-length": statSync(f).size, "content-disposition": `attachment; filename="${path.slice(7)}"` });
        return void createReadStream(f).pipe(res);
      }
      if (path.startsWith("/api/")) return await api(req, res, path, ip);
      return await statis(res, path);
    } catch (e) {
      if (!res.headersSent) kirim(res, 400, { error: String(e.message) });
    }
  });
  server.on("upgrade", (req, socket, head) => {
    const gm = gameDariPath((req.url ?? "/").split(/[?#]/)[0]);
    if (dalamPerawatan(gm) && !guruAtauCookie(req)) { socket.end("HTTP/1.1 503 Service Unavailable\r\nretry-after: 300\r\nconnection: close\r\n\r\n"); return; }
    if (apl.data.wajib && gm && !aplId(req) && !guruAtauCookie(req)) { socket.end("HTTP/1.1 403 Forbidden\r\nconnection: close\r\n\r\n"); return; }
    teruskanUpgrade(req, socket, head, daftar, proto);
  });
  return server;
}

export { GAMES };
